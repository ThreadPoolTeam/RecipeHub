import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { Rt as t, ht as n } from "./lib-BTerfQ6O.js";
import { u as r } from "./pixijs-game-zi5bgXGP.js";
var i, a, o;
function s() {
  return (s = e(() => {
    r(),
      (i = (e, t) => {
        let r = document.createElement(`canvas`);
        (r.width = t * 2), (r.height = t * 2);
        let i = r.getContext(`2d`);
        if (i) {
          try {
            let n = i.createRadialGradient(t, t, 0, t, t, t);
            e.forEach(([e, t]) => {
              n.addColorStop(t, e);
            }),
              (i.fillStyle = n),
              i.fillRect(0, 0, t * 2, t * 2);
          } catch {
            return;
          }
          return n.from(r, { pixiIdPrefix: `gradient` });
        }
      }),
      (a = (e, r, i = `horizontal`) => {
        let a = [];
        switch (i) {
          case `horizontal`:
            {
              let i = e.width / r,
                o = e.height;
              for (let s = 0; s < r; s++)
                a.push(new n(e.baseTexture, new t(s * i, 0, i, o)));
            }
            break;
          case `vertical`: {
            let i = e.width,
              o = e.height / r;
            for (let s = 0; s < r; s++)
              a.push(new n(e.baseTexture, new t(0, s * o, i, o)));
          }
        }
        return a;
      }),
      (o = (e, t, r, i = `horizontal`) => {
        let a = document.createElement(`canvas`);
        (a.width = t), (a.height = r);
        let o = a.getContext(`2d`);
        if (!o) return;
        let s = i === `horizontal` ? 0 : t / 2,
          c = i === `horizontal` ? r / 2 : 0,
          l = i === `horizontal` ? t : t / 2,
          u = i === `horizontal` ? r / 2 : r,
          d = o.createLinearGradient(s, c, l, u);
        return (
          e.forEach(([e, t]) => {
            d.addColorStop(t, e);
          }),
          (o.fillStyle = d),
          o.fillRect(0, 0, t, r),
          n.from(a)
        );
      });
  }))();
}
export { s as i, i as n, a as r, o as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/pixi-gradient-texture-DSQSb4Wv.js.map
