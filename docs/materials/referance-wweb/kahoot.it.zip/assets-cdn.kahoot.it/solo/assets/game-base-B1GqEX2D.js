import { a as e, n as t } from "./rolldown-runtime-B0Z9INg1.js";
import { Go as n, S as r, u as i } from "./app-Bv1T6OmB.js";
import {
  Bi as a,
  Ga as o,
  Ka as s,
  Li as c,
  Na as l,
  Ri as u,
  So as d,
  Ya as f,
  aa as p,
  ai as m,
  bo as h,
  ca as g,
  ci as _,
  fa as v,
  ii as y,
  ka as b,
  la as ee,
  li as x,
  ma as te,
  mo as S,
  oa as C,
  po as ne,
  sa as w,
  xo as re,
  yo as ie,
  zi as ae,
} from "./solo-z64LhsmC.js";
import {
  B as T,
  P as E,
  U as D,
  c as O,
  f as oe,
  u as k,
  w as se,
} from "./lib-BTerfQ6O.js";
import {
  d as A,
  g as ce,
  h as le,
  n as ue,
  t as de,
  u as j,
} from "./pixijs-game-zi5bgXGP.js";
import {
  n as fe,
  o as M,
  r as N,
  t as pe,
} from "./pixijs-particle-emitter-B_TZCnbP.js";
import { n as me, t as he } from "./android-webgl-hack-BKgRYXLm.js";
import { d as ge, n as _e, t as ve, u as ye } from "./confetti-CEJnA6uf.js";
import { i as be, t as xe } from "./pixi-gradient-texture-DSQSb4Wv.js";
import { n as Se, t as Ce } from "./pixi_viewport-72U2r_0l.js";
var we,
  Te,
  Ee,
  De,
  Oe,
  ke,
  Ae,
  je,
  Me,
  Ne,
  Pe,
  Fe,
  Ie,
  Le,
  Re,
  ze,
  Be,
  Ve,
  He,
  Ue,
  We,
  Ge,
  Ke,
  qe,
  Je,
  Ye,
  Xe,
  Ze,
  Qe,
  $e,
  et,
  tt,
  nt,
  rt,
  it,
  at,
  ot,
  st,
  ct,
  lt,
  ut,
  dt,
  ft,
  pt,
  mt,
  ht,
  gt,
  _t,
  vt,
  yt,
  bt,
  xt,
  St,
  Ct,
  wt,
  Tt,
  Et,
  Dt,
  Ot,
  kt,
  At,
  jt,
  Mt,
  Nt,
  Pt,
  Ft,
  It,
  Lt,
  Rt,
  zt,
  Bt,
  Vt,
  Ht,
  Ut,
  Wt,
  Gt,
  Kt,
  qt,
  Jt,
  Yt,
  Xt,
  Zt,
  Qt,
  $t,
  en,
  tn,
  nn,
  rn,
  an,
  on,
  sn,
  cn,
  ln,
  un,
  dn,
  fn,
  pn,
  mn,
  hn,
  gn,
  _n,
  vn,
  yn,
  bn,
  xn,
  Sn,
  Cn,
  wn,
  Tn,
  En,
  Dn,
  On,
  kn,
  An,
  jn,
  Mn,
  Nn,
  Pn,
  Fn,
  In,
  Ln,
  Rn,
  zn,
  Bn,
  Vn,
  Hn,
  Un,
  Wn,
  Gn,
  Kn,
  qn,
  Jn,
  Yn,
  Xn,
  Zn,
  Qn,
  $n,
  er,
  tr,
  nr,
  rr,
  ir,
  ar,
  or,
  sr,
  P,
  cr,
  F,
  lr,
  ur,
  dr,
  fr,
  pr,
  mr,
  hr,
  gr,
  _r,
  vr,
  yr,
  br,
  xr,
  Sr,
  Cr,
  wr,
  Tr,
  Er,
  Dr,
  Or,
  kr,
  Ar,
  jr,
  Mr,
  Nr,
  Pr,
  Fr,
  Ir,
  Lr,
  Rr,
  zr,
  Br,
  Vr,
  Hr,
  Ur,
  Wr,
  Gr,
  Kr,
  qr,
  Jr,
  Yr,
  Xr,
  I,
  L,
  Zr,
  Qr,
  $r,
  ei,
  ti,
  ni,
  ri,
  ii,
  ai,
  oi,
  si,
  ci,
  li,
  R,
  z,
  ui,
  B,
  di,
  fi,
  pi,
  mi,
  hi,
  gi,
  _i,
  vi,
  yi,
  bi,
  xi,
  Si,
  Ci,
  wi,
  Ti,
  Ei,
  Di,
  Oi,
  ki,
  Ai,
  ji,
  Mi,
  Ni,
  Pi,
  Fi,
  Ii,
  Li,
  Ri,
  zi,
  Bi,
  Vi,
  Hi,
  Ui,
  Wi,
  Gi,
  Ki,
  qi,
  Ji,
  Yi,
  Xi,
  Zi,
  Qi,
  $i,
  ea,
  ta,
  na,
  ra,
  ia,
  aa,
  oa,
  sa,
  ca,
  la,
  ua,
  da,
  fa,
  pa,
  ma,
  ha,
  ga,
  _a,
  va,
  ya,
  ba,
  xa,
  Sa,
  Ca,
  wa,
  Ta;
function V() {
  return (V = t(() => {
    ee(),
      (we = `ARROWS01`),
      (Te = `ARROWS02`),
      (Ee = `ARROWS03`),
      (De = `ARROWS04`),
      (Oe = `ARROWS05`),
      (ke = `ARROWS06`),
      (Ae = [we, Te, Ee, De, Oe, ke]),
      (je = `DUST_01`),
      (Me = `DUST_02`),
      (Ne = `DUST_03`),
      (Pe = `DUST_04`),
      (Fe = `DUST_05`),
      (Ie = `DUST_06`),
      (Le = `DUST_07`),
      (Re = `DUST_08`),
      (ze = `DUST_09`),
      (Be = [je, Me, Ne, Pe, Fe, Ie, Le, Re, ze]),
      (Ve = `DUST_EXPLOSION_01`),
      (He = `DUST_EXPLOSION_02`),
      (Ue = `DUST_EXPLOSION_03`),
      (We = `DUST_EXPLOSION_04`),
      (Ge = `DUST_EXPLOSION_05`),
      (Ke = `DUST_EXPLOSION_06`),
      (qe = `DUST_EXPLOSION_07`),
      (Je = `DUST_EXPLOSION_08`),
      (Ye = `DUST_EXPLOSION_09`),
      (Xe = [Ve, He, Ue, We, Ge, Ke, qe, Je, Ye]),
      (Ze = `FLOORNAME00`),
      (Qe = `FLOORNAME01`),
      ($e = `FLOORNAME02`),
      (et = [Ze, Qe, $e]),
      (tt = `FLOORNAMEXRAY00`),
      (nt = `FLOORSHADOW00`),
      (rt = `FLOORSHADOW01`),
      (it = `FLOORSHADOW02`),
      (at = [nt, rt, it]),
      (ot = `FLOORSHADOWXRAY00`),
      (st = `FLOORRAY_01`),
      (ct = `FLOORRAY_02`),
      (lt = `FLOORRAY_03`),
      (ut = `FLOORRAY_04`),
      (dt = `FLOORRAY_05`),
      (ft = `FLOORRAY_06`),
      (pt = `FLOORRAY_07`),
      (mt = `FLOORRAY_08`),
      (ht = [st, ct, lt, ut, dt, ft, pt, mt]),
      (gt = `LIGHTNING01`),
      (_t = `LIGHTNING02`),
      (vt = `LIGHTNING03`),
      (yt = `LIGHTNING04`),
      (bt = `LIGHTNING05`),
      (xt = `LIGHTNING06`),
      (St = `LIGHTNING07`),
      (Ct = `LIGHTNING08`),
      (wt = `LIGHTNING09`),
      (Tt = `LIGHTNING10`),
      (Et = `LIGHTNING11`),
      (Dt = [gt, _t, vt, yt, bt, xt, St, Ct, wt, Tt, Et]),
      (Ot = `PLAYERNAME00`),
      (kt = `PLAYERNAME01`),
      (At = `PLAYERNAME02`),
      (jt = [Ot, kt, At]),
      (Mt = `PLAYERNAMEXRAY00`),
      (Nt = `PLAYERSHADOW00`),
      (Pt = `PLAYERSHADOW01`),
      (Ft = `PLAYERSHADOW02`),
      (It = [Nt, Pt, Ft]),
      (Lt = `PLAYERSHADOWXRAY00`),
      (Rt = `PLUSONESMAIN00`),
      (zt = `PLUSONESHADOW00`),
      (Bt = `PLUSTENFONT00`),
      (Vt = `STOMPDUST01`),
      (Ht = `STOMPDUST02`),
      (Ut = `STOMPDUST03`),
      (Wt = `STOMPDUST04`),
      (Gt = `STOMPDUST05`),
      (Kt = `STOMPDUST06`),
      (qt = `STOMPDUST07`),
      (Jt = `STOMPDUST08`),
      (Yt = `STOMPDUST09`),
      (Xt = `STOMPDUST10`),
      (Zt = [Vt, Ht, Ut, Wt, Gt, Kt, qt, Jt, Yt, Xt]),
      (Qt = `RISINGSUN01`),
      ($t = `RISINGSUN02`),
      (en = `RISINGSUN03`),
      (tn = [Qt, $t, en]),
      (nn = `BONUSGIFTBOX01`),
      (rn = [9, 9, 9, 0]),
      (an = [23, 25, 23, 0]),
      (on = `BACKGROUNDCITY00`),
      (sn = [918, 374]),
      (cn = `BACKGROUNDSECONDFILE`),
      (ln = `BACKGROUNDCLOUDS01`),
      (un = `BACKGROUNDCLOUDS02`),
      (dn = `BACKGROUNDCLOUDS03`),
      (fn = [ln, un, dn]),
      (pn = `THREEBLOCKSTILEDGROUND01`),
      (mn = [899, 75]),
      (hn = `BACKGROUNDTREE`),
      (gn = `CLOSESCREENBUSH00`),
      (_n = `CLOSESCREENBUSH01`),
      (vn = `CONSTRUCTIONBLOCKB01`),
      (yn = `FALLINGBLOCKBEHIND`),
      (bn = `FALLINGBLOCKOVER`),
      (xn = `FLOORTOP`),
      (Sn = `THREEBLOCKSBASE00`),
      (Cn = `THREEBLOCKSBASE01`),
      (wn = `THREEBLOCKSBASE02`),
      (Tn = `FOURBLOCKSBASE00`),
      (En = `FOURBLOCKSBASE01`),
      (Dn = `FOURBLOCKSBASE02`),
      (On = `FIVEBLOCKSBASE00`),
      (kn = `FIVEBLOCKSBASE01`),
      (An = `FIVEBLOCKSBASE02`),
      (jn = `SIXBLOCKSBASE00`),
      (Mn = `SIXBLOCKSBASE01`),
      (Nn = `SIXBLOCKSBASE02`),
      (Pn = `SEVENBLOCKSBASE00`),
      (Fn = `SEVENBLOCKSBASE01`),
      (In = `SEVENBLOCKSBASE02`),
      (Ln = `THREEBLOCKSFLOOR01`),
      (Rn = `THREEBLOCKSFLOOR02`),
      (zn = `THREEBLOCKSFLOOR03`),
      (Bn = `FOURBLOCKSFLOOR01`),
      (Vn = `FOURBLOCKSFLOOR02`),
      (Hn = `FOURBLOCKSFLOOR03`),
      (Un = `FIVEBLOCKSFLOOR01`),
      (Wn = `FIVEBLOCKSFLOOR02`),
      (Gn = `FIVEBLOCKSFLOOR03`),
      (Kn = `SIXBLOCKSFLOOR01`),
      (qn = `SIXBLOCKSFLOOR02`),
      (Jn = `SIXBLOCKSFLOOR03`),
      (Yn = `SEVENBLOCKSFLOOR01`),
      (Xn = `SEVENBLOCKSFLOOR02`),
      (Zn = `SEVENBLOCKSFLOOR03`),
      (Qn = {
        3: { base: [Sn, Cn, wn], floor: [Ln, Rn, zn] },
        4: { base: [Tn, En, Dn], floor: [Bn, Vn, Hn] },
        5: { base: [On, kn, An], floor: [Un, Wn, Gn] },
        6: { base: [jn, Mn, Nn], floor: [Kn, qn, Jn] },
        7: { base: [Pn, Fn, In], floor: [Yn, Xn, Zn] },
      }),
      ($n = `TOPBLOCK01`),
      (er = `TOPBLOCK02`),
      (tr = `TOPBLOCK03`),
      (nr = `WINDOW01`),
      (rr = `WINDOW02`),
      (ir = `WINDOW03`),
      (ar = `WINDOW04`),
      (or = `WINDOW05`),
      (sr = `DOOR01`),
      (P = `DOOR02`),
      (cr = `DOOR03`),
      (F = `DOOR04`),
      (lr = {
        [g.Red]: P,
        [g.Blue]: F,
        [g.Yellow]: sr,
        [g.Purple]: F,
        [g.Green]: cr,
        [g.Teal]: P,
        [g.Orange]: sr,
        [g.White]: cr,
        [g.Pink]: F,
        [g.Black]: P,
      }),
      (ur = `MURETE00`),
      (dr = `MURETESTAIRS00`),
      (fr = `TRIGGER01`),
      (pr = `TRIGGER02`),
      (mr = `TRIGGER03`),
      (hr = [fr, pr, mr]),
      (gr = `TRIGGERBG`),
      (_r = `GORILLAATTACKBACKGROUND`),
      (vr = `GORILLA01`),
      (yr = `GORILLA02`),
      (br = `GORILLA03`),
      (xr = `GORILLA04`),
      (Sr = `GORILLA05`),
      (Cr = `GORILLA06`),
      (wr = `GORILLA07`),
      (Tr = `GORILLA08`),
      (Er = [vr, yr, br, xr, Sr, Cr, wr, Tr]),
      (Dr = `KINGGORILLA01`),
      (Or = `KINGGORILLA02`),
      (kr = `KINGGORILLA03`),
      (Ar = `KINGGORILLA04`),
      (jr = `KINGGORILLA05`),
      (Mr = `KINGGORILLA06`),
      (Nr = `KINGGORILLA07`),
      (Pr = `KINGGORILLA08`),
      (Fr = [Dr, Or, kr, Ar, jr, Mr, Nr, Pr]),
      (Ir = `SPACE_BACKGROUNDCITY00`),
      (Lr = [918, 374]),
      (Rr = `SPACE_BACKGROUNDCITY01`),
      (zr = `SPACE_BACKGROUNDPLANET00`),
      (Br = `SPACE_BACKGROUNDPLANET01`),
      (Vr = `SPACE_BACKGROUNDPLANET03`),
      (Hr = `SPACE_BACKGROUNDPLANET04`),
      (Ur = [zr, Br, Vr, Hr]),
      (Wr = `SPACE_BACKGROUNDSECONDFILE01`),
      (Gr = `SPACE_BACKGROUNDSECONDFILE02`),
      (Kr = `SPACE_BACKGROUNDSTARS`),
      (qr = `SPACE_BACKGROUNDHOLE00`),
      (Jr = `SPACE_BACKGROUNDHOLE01`),
      (Yr = `SPACE_BARRIER01A`),
      (Xr = `SPACE_BARRIER01B`),
      (I = `SPACE_BARRIER02A`),
      (L = `SPACE_BARRIER02B`),
      (Zr = `SPACE_BARRIER03A`),
      (Qr = `SPACE_BARRIER03B`),
      ($r = `SPACE_BARRIER04A`),
      (ei = `SPACE_BARRIER04B`),
      (ti = {
        [g.Red]: [Yr, Xr],
        [g.Blue]: [I, L],
        [g.Yellow]: [Zr, Qr],
        [g.Purple]: [$r, ei],
        [g.Green]: [Yr, Xr],
        [g.Teal]: [I, L],
        [g.Orange]: [Zr, Qr],
        [g.White]: [$r, ei],
        [g.Pink]: [Yr, Xr],
        [g.Black]: [I, L],
      }),
      (ni = `SPACE_BRIGHT00`),
      (ri = `SPACE_FLOORTOP`),
      (ii = `SPACE_CLOSESCREENBUSH00`),
      (ai = `SPACE_CLOSESCREENBUSH01`),
      (oi = `SPACE_CONSTRUCTIONBLOCKB01`),
      (si = `SPACE_FALLINGBLOCKBEHIND`),
      (ci = `SPACE_FALLINGBLOCKOVER`),
      (li = `SPACE_FALLINGBLOCKOVER2`),
      (R = `SPACE_DOOR01`),
      (z = `SPACE_DOOR02`),
      (ui = `SPACE_DOOR03`),
      (B = `SPACE_DOOR04`),
      (di = {
        [g.Red]: R,
        [g.Blue]: z,
        [g.Yellow]: z,
        [g.Green]: B,
        [g.Purple]: R,
        [g.Teal]: ui,
        [g.Orange]: B,
        [g.White]: B,
        [g.Pink]: R,
        [g.Black]: z,
      }),
      (fi = `SPACE_THREEBLOCKSTILEDGROUND01`),
      (pi = [899, 125]),
      (mi = `SPACE_THREEBLOCKSBASE00`),
      (hi = `SPACE_THREEBLOCKSBASE01`),
      (gi = `SPACE_THREEBLOCKSBASE02`),
      (_i = `SPACE_THREEBLOCKSFLOOR00`),
      (vi = `SPACE_THREEBLOCKSFLOOR01`),
      (yi = `SPACE_THREEBLOCKSFLOOR02`),
      (bi = `SPACE_FOURBLOCKSBASE00`),
      (xi = `SPACE_FOURBLOCKSBASE01`),
      (Si = `SPACE_FOURBLOCKSBASE02`),
      (Ci = `SPACE_FOURBLOCKSFLOOR00`),
      (wi = `SPACE_FOURBLOCKSFLOOR01`),
      (Ti = `SPACE_FOURBLOCKSFLOOR02`),
      (Ei = `SPACE_FIVEBLOCKSBASE00`),
      (Di = `SPACE_FIVEBLOCKSBASE01`),
      (Oi = `SPACE_FIVEBLOCKSBASE02`),
      (ki = `SPACE_FIVEBLOCKSFLOOR01`),
      (Ai = `SPACE_FIVEBLOCKSFLOOR02`),
      (ji = `SPACE_FIVEBLOCKSFLOOR03`),
      (Mi = `SPACE_SIXBLOCKSBASE00`),
      (Ni = `SPACE_SIXBLOCKSBASE01`),
      (Pi = `SPACE_SIXBLOCKSBASE02`),
      (Fi = `SPACE_SIXBLOCKSFLOOR00`),
      (Ii = `SPACE_SIXBLOCKSFLOOR01`),
      (Li = `SPACE_SIXBLOCKSFLOOR02`),
      (Ri = `SPACE_SEVENBLOCKSBASE00`),
      (zi = `SPACE_SEVENBLOCKSBASE01`),
      (Bi = `SPACE_SEVENBLOCKSBASE02`),
      (Vi = `SPACE_SEVENBLOCKSFLOOR00`),
      (Hi = `SPACE_SEVENBLOCKSFLOOR01`),
      (Ui = `SPACE_SEVENBLOCKSFLOOR02`),
      (Wi = {
        3: { base: [mi, hi, gi], floor: [_i, vi, yi] },
        4: { base: [bi, xi, Si], floor: [Ci, wi, Ti] },
        5: { base: [Ei, Di, Oi], floor: [ki, Ai, ji] },
        6: { base: [Mi, Ni, Pi], floor: [Fi, Ii, Li] },
        7: { base: [Ri, zi, Bi], floor: [Vi, Hi, Ui] },
      }),
      (Gi = `SPACE_WINDOW01`),
      (Ki = `SPACE_WINDOW02`),
      (qi = `SPACE_WINDOW03`),
      (Ji = `SPACE_WINDOW04`),
      (Yi = `SPACE_WINDOW05`),
      (Xi = `SPACE_WINDOW06`),
      (Zi = `SPACE_WINDOW07`),
      (Qi = `SPACE_TRIGGER00`),
      ($i = `SPACE_TRIGGER01`),
      (ea = `SPACE_TRIGGER02`),
      (ta = `SPACE_TRIGGER03`),
      (na = `SPACE_TRIGGER04`),
      (ra = `SPACE_TRIGGER05`),
      (ia = `SPACE_TRIGGER06`),
      (aa = `SPACE_TRIGGER07`),
      (oa = [Qi, $i, ea, ta, na, ra, ia, aa]),
      (sa = `SPACE_MONSTERTRIGGERBLOCK`),
      (ca = `SPACE_GORILLAFLAME00`),
      (la = `SPACE_GORILLAFLAME01`),
      (ua = `SPACE_GORILLAFLAME02`),
      (da = `SPACE_GORILLAFLAME03`),
      (fa = `SPACE_GORILLAFLAME04`),
      (pa = `SPACE_GORILLAFLAME05`),
      (ma = [ca, la, ua, da, fa, pa]),
      (ha = `SPACE_GORILLA01`),
      (ga = `SPACE_GORILLA02`),
      (_a = `SPACE_GORILLA03`),
      (va = `SPACE_GORILLA04`),
      (ya = `SPACE_GORILLA05`),
      (ba = `SPACE_GORILLA06`),
      (xa = `SPACE_GORILLA07`),
      (Sa = `SPACE_GORILLA08`),
      (Ca = [ha, ga, _a, va, ya, ba, xa, Sa]),
      (wa = `SPACE_MURETE00`),
      (Ta = `SPACE_MURETESTAIRS00`);
  }))();
}
var Ea, Da, Oa, ka, Aa;
function ja() {
  return (ja = t(() => {
    j(),
      y(),
      x(),
      (Ea = 1400),
      (Da = 400),
      (Oa = 100),
      (ka = 2),
      (Aa = class extends D {
        constructor(e, t, n) {
          super(), (this.xBounds = t);
          let r = n;
          (this.block = e),
            (this.block.x = 0),
            (this.block.y = r),
            (this.tween = _({
              duration: Ea,
              from: { x: t.start },
              to: { x: t.end },
              onPlay: ({ x: e }) => {
                this.block.x = e;
              },
              onTick: ({ x: e }) => {
                this.block.x = e;
              },
              onFinish: () => {
                let { from: e, to: t } = this.tween.configValues ?? {};
                this.tween.update({ to: e, from: t }), this.tween.play();
              },
            })),
            this.addChild(this.block),
            this.tween.seek(Math.random() * Ea),
            this.tween.play();
        }
        get x() {
          return this.block.x;
        }
        get y() {
          return this.block.y;
        }
        stop(e) {
          (this.block.x = e * 75), this.tween.stop();
        }
        scaleForFalling(e) {
          let t = this.block.x,
            n = 75 / 2,
            r = t - n;
          (this.scaleUpTween = _({
            duration: Oa,
            from: { s: 1, x: t },
            to: { s: ka, x: t - n },
            easing: m.EASE_IN_OUT_CIRC,
            onTick: ({ s: e, x: t }) => {
              this.block && (this.block.scale.set(e), (this.block.x = t));
            },
            onFinish: () => {
              (this.scaleDownTween = _({
                duration: Da,
                from: { t: 0 },
                to: { t: 1 },
                easing: m.EASE_IN_OUT_CUBIC,
                onTick: ({ t: e }) => {
                  this.block &&
                    ((this.block.x = r + n * e),
                    this.block.scale.set(1 + (1 - e * 1)));
                },
              })),
                this.scaleDownTween.play(),
                e();
            },
          })),
            this.scaleUpTween.play();
        }
        updateMovementSpeed(e) {
          this.tween.update({ duration: e });
        }
        dropMiss(e, t) {
          this.stop(e);
          let n = this.block.y;
          this.scaleForFalling(() => {
            this.block.animateFall(
              0,
              Math.abs(n),
              () => {
                this.removeBlock(), t();
              },
              Da
            );
          });
        }
        dropSuccess(e, t, n) {
          this.stop(e);
          let r = this.block.y,
            i = t + Math.abs(r);
          this.scaleForFalling(() => {
            this.block.animatePlace(
              0,
              i,
              () => {
                this.removeBlock(), n();
              },
              Da
            );
          });
        }
        explode(e, t) {
          this.stop(e),
            this.block.animateExplosion(
              0,
              0.5,
              () => {
                this.removeBlock(), t();
              },
              100
            );
        }
        removeBlock() {
          this.removeChild(this.block),
            this.block.destroy(),
            this.tween.destroy(),
            this.scaleUpTween?.destroy(),
            this.scaleDownTween?.destroy();
        }
      });
  }))();
}
var Ma, H, U, Na, Pa, Fa, Ia, La;
function W() {
  return (W = t(() => {
    (Ma = 1280),
      (H = 2e4),
      (U = 2e4),
      (Na = 7e3),
      (Pa = 0.1),
      (Fa = 0.5),
      (Ia = 8e3),
      (La = 1400);
  }))();
}
var Ra;
function za() {
  return (za = t(() => {
    Ra = `https://assets-cdn.kahoot.it/solo/assets/ARROWS01-B6UTiYYA.png`;
  }))();
}
var Ba;
function Va() {
  return (Va = t(() => {
    Ba = `https://assets-cdn.kahoot.it/solo/assets/ARROWS02-CaVnFjjE.png`;
  }))();
}
var Ha;
function Ua() {
  return (Ua = t(() => {
    Ha = `https://assets-cdn.kahoot.it/solo/assets/ARROWS03-ojNT7DMa.png`;
  }))();
}
var Wa;
function Ga() {
  return (Ga = t(() => {
    Wa = `https://assets-cdn.kahoot.it/solo/assets/ARROWS04-DSbs7D0K.png`;
  }))();
}
var Ka;
function qa() {
  return (qa = t(() => {
    Ka = `https://assets-cdn.kahoot.it/solo/assets/ARROWS05-CSY5CoOL.png`;
  }))();
}
var Ja;
function Ya() {
  return (Ya = t(() => {
    Ja = `https://assets-cdn.kahoot.it/solo/assets/ARROWS06-BFcQ-4Pu.png`;
  }))();
}
var Xa;
function Za() {
  return (Za = t(() => {
    Xa = `https://assets-cdn.kahoot.it/solo/assets/DUST_01-CDNzp6gC.png`;
  }))();
}
var Qa;
function $a() {
  return ($a = t(() => {
    Qa = `https://assets-cdn.kahoot.it/solo/assets/DUST_02-CSkXcSIw.png`;
  }))();
}
var eo;
function to() {
  return (to = t(() => {
    eo = `https://assets-cdn.kahoot.it/solo/assets/DUST_03-DJrh5GHZ.png`;
  }))();
}
var no;
function ro() {
  return (ro = t(() => {
    no = `https://assets-cdn.kahoot.it/solo/assets/DUST_04-B_P8s8w0.png`;
  }))();
}
var io;
function ao() {
  return (ao = t(() => {
    io = `https://assets-cdn.kahoot.it/solo/assets/DUST_05-BcGmEAdh.png`;
  }))();
}
var oo;
function so() {
  return (so = t(() => {
    oo = `https://assets-cdn.kahoot.it/solo/assets/DUST_06-ChJwX235.png`;
  }))();
}
var co;
function lo() {
  return (lo = t(() => {
    co = `https://assets-cdn.kahoot.it/solo/assets/DUST_07-gytARXNg.png`;
  }))();
}
var uo;
function fo() {
  return (fo = t(() => {
    uo = `https://assets-cdn.kahoot.it/solo/assets/DUST_08-ThJmX2tF.png`;
  }))();
}
var po;
function mo() {
  return (mo = t(() => {
    po = `https://assets-cdn.kahoot.it/solo/assets/DUST_09-7PxYG1Yi.png`;
  }))();
}
var ho;
function go() {
  return (go = t(() => {
    ho = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_01-DFTbZ9fx.png`;
  }))();
}
var _o;
function vo() {
  return (vo = t(() => {
    _o = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_02-B7g-3GOq.png`;
  }))();
}
var yo;
function bo() {
  return (bo = t(() => {
    yo = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_03-DvcwAWYk.png`;
  }))();
}
var xo;
function So() {
  return (So = t(() => {
    xo = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_04--qlqk_re.png`;
  }))();
}
var Co;
function wo() {
  return (wo = t(() => {
    Co = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_05-CVWofz9_.png`;
  }))();
}
var To;
function Eo() {
  return (Eo = t(() => {
    To = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_06-DbM9QH1R.png`;
  }))();
}
var Do;
function Oo() {
  return (Oo = t(() => {
    Do = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_07-Cwta44s3.png`;
  }))();
}
var ko;
function Ao() {
  return (Ao = t(() => {
    ko = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_08-CfGd4It_.png`;
  }))();
}
var jo;
function Mo() {
  return (Mo = t(() => {
    jo = `https://assets-cdn.kahoot.it/solo/assets/DUST_EXPLOSION_09-dRWwjCCy.png`;
  }))();
}
var No;
function Po() {
  return (Po = t(() => {
    No = `https://assets-cdn.kahoot.it/solo/assets/FLOORNAME00-DAgLDzH8.png`;
  }))();
}
var Fo;
function Io() {
  return (Io = t(() => {
    Fo = `https://assets-cdn.kahoot.it/solo/assets/FLOORNAME01-CsjoWQu5.png`;
  }))();
}
var Lo;
function Ro() {
  return (Ro = t(() => {
    Lo = `https://assets-cdn.kahoot.it/solo/assets/FLOORNAME02-BDGRdA4P.png`;
  }))();
}
var zo;
function Bo() {
  return (Bo = t(() => {
    zo = `https://assets-cdn.kahoot.it/solo/assets/FLOORNAMEXRAY00-DENIDVDW.png`;
  }))();
}
var Vo;
function Ho() {
  return (Ho = t(() => {
    Vo = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_01-wiGfzxy0.png`;
  }))();
}
var Uo;
function Wo() {
  return (Wo = t(() => {
    Uo = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_02-DGA6FhuL.png`;
  }))();
}
var Go;
function Ko() {
  return (Ko = t(() => {
    Go = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_03-BygMUsAl.png`;
  }))();
}
var qo;
function Jo() {
  return (Jo = t(() => {
    qo = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_04-wFwWae6O.png`;
  }))();
}
var Yo;
function Xo() {
  return (Xo = t(() => {
    Yo = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_05-CPEl2Zhi.png`;
  }))();
}
var Zo;
function Qo() {
  return (Qo = t(() => {
    Zo = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_06-BpK8A_rn.png`;
  }))();
}
var $o;
function es() {
  return (es = t(() => {
    $o = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_07-Bj82TB6m.png`;
  }))();
}
var ts;
function ns() {
  return (ns = t(() => {
    ts = `https://assets-cdn.kahoot.it/solo/assets/FLOORRAY_08-DBJHYLyh.png`;
  }))();
}
var rs;
function is() {
  return (is = t(() => {
    rs = `https://assets-cdn.kahoot.it/solo/assets/FLOORSHADOW00-8zIkzSOI.png`;
  }))();
}
var as;
function os() {
  return (os = t(() => {
    as = `https://assets-cdn.kahoot.it/solo/assets/FLOORSHADOW01-DEo6c1Ti.png`;
  }))();
}
var ss;
function cs() {
  return (cs = t(() => {
    ss = `https://assets-cdn.kahoot.it/solo/assets/FLOORSHADOW02-Dz8K5tQl.png`;
  }))();
}
var ls;
function us() {
  return (us = t(() => {
    ls = `https://assets-cdn.kahoot.it/solo/assets/FLOORSHADOWXRAY00-Qj-7-YVt.png`;
  }))();
}
var ds;
function fs() {
  return (fs = t(() => {
    ds = `https://assets-cdn.kahoot.it/solo/assets/GIFT01-D5s_u7St.png`;
  }))();
}
var ps;
function ms() {
  return (ms = t(() => {
    ps = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING01-DjZ-fY6P.png`;
  }))();
}
var hs;
function gs() {
  return (gs = t(() => {
    hs = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING02-6AnCVsFK.png`;
  }))();
}
var _s;
function vs() {
  return (vs = t(() => {
    _s = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING03-CnzSUaHY.png`;
  }))();
}
var ys;
function bs() {
  return (bs = t(() => {
    ys = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING04-BD6amW8q.png`;
  }))();
}
var xs;
function Ss() {
  return (Ss = t(() => {
    xs = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING05-BSV0y_9l.png`;
  }))();
}
var Cs;
function ws() {
  return (ws = t(() => {
    Cs = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING06-Bs3_NDPm.png`;
  }))();
}
var Ts;
function Es() {
  return (Es = t(() => {
    Ts = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING07-BNKL2vGJ.png`;
  }))();
}
var Ds;
function Os() {
  return (Os = t(() => {
    Ds = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING08-DugMLXeW.png`;
  }))();
}
var ks;
function As() {
  return (As = t(() => {
    ks = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING09-BokvWmgG.png`;
  }))();
}
var js;
function Ms() {
  return (Ms = t(() => {
    js = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING10-D0yDTIZt.png`;
  }))();
}
var Ns;
function Ps() {
  return (Ps = t(() => {
    Ns = `https://assets-cdn.kahoot.it/solo/assets/LIGHTNING11-BjXjlit9.png`;
  }))();
}
var Fs;
function Is() {
  return (Is = t(() => {
    Fs = `https://assets-cdn.kahoot.it/solo/assets/PLAYERNAME00-B7AsYPVl.png`;
  }))();
}
var Ls;
function Rs() {
  return (Rs = t(() => {
    Ls = `https://assets-cdn.kahoot.it/solo/assets/PLAYERNAME01-DZa3cIwG.png`;
  }))();
}
var zs;
function Bs() {
  return (Bs = t(() => {
    zs = `https://assets-cdn.kahoot.it/solo/assets/PLAYERNAME02-SyLYIjLy.png`;
  }))();
}
var Vs;
function Hs() {
  return (Hs = t(() => {
    Vs = `https://assets-cdn.kahoot.it/solo/assets/PLAYERNAMEXRAY00-BYHH4Ell.png`;
  }))();
}
var Us;
function Ws() {
  return (Ws = t(() => {
    Us = `https://assets-cdn.kahoot.it/solo/assets/PLAYERSHADOW00-BWax6Mss.png`;
  }))();
}
var Gs;
function Ks() {
  return (Ks = t(() => {
    Gs = `https://assets-cdn.kahoot.it/solo/assets/PLAYERSHADOW01-RIorcpoM.png`;
  }))();
}
var qs;
function Js() {
  return (Js = t(() => {
    qs = `https://assets-cdn.kahoot.it/solo/assets/PLAYERSHADOW02-Bq9y5uZS.png`;
  }))();
}
var Ys;
function Xs() {
  return (Xs = t(() => {
    Ys = `https://assets-cdn.kahoot.it/solo/assets/PLAYERSHADOWXRAY00-C_LIy29t.png`;
  }))();
}
var Zs;
function Qs() {
  return (Qs = t(() => {
    Zs = `https://assets-cdn.kahoot.it/solo/assets/PLUSONESHADOW00-CrEZiRE8.png`;
  }))();
}
var $s;
function ec() {
  return (ec = t(() => {
    $s = `https://assets-cdn.kahoot.it/solo/assets/PLUSONESMAIN00-B26G4gyd.png`;
  }))();
}
var tc;
function nc() {
  return (nc = t(() => {
    tc = `https://assets-cdn.kahoot.it/solo/assets/PLUSTENFONT00-CXh5J4XL.png`;
  }))();
}
var rc;
function ic() {
  return (ic = t(() => {
    rc = `https://assets-cdn.kahoot.it/solo/assets/RISINGSUN01-5rKIiEi_.png`;
  }))();
}
var ac;
function oc() {
  return (oc = t(() => {
    ac = `https://assets-cdn.kahoot.it/solo/assets/RISINGSUN02-DJywsFBX.png`;
  }))();
}
var sc;
function cc() {
  return (cc = t(() => {
    sc = `https://assets-cdn.kahoot.it/solo/assets/RISINGSUN03-Dg9EhlfT.png`;
  }))();
}
var lc;
function uc() {
  return (uc = t(() => {
    lc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST01-Cwfqzo8o.png`;
  }))();
}
var dc;
function fc() {
  return (fc = t(() => {
    dc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST02-CF5_zUoO.png`;
  }))();
}
var pc;
function mc() {
  return (mc = t(() => {
    pc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST03-CasGJ0h1.png`;
  }))();
}
var hc;
function gc() {
  return (gc = t(() => {
    hc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST04-Bx696Rjb.png`;
  }))();
}
var _c;
function vc() {
  return (vc = t(() => {
    _c = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST05-CMdvHj7U.png`;
  }))();
}
var yc;
function bc() {
  return (bc = t(() => {
    yc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST06-BRPbOfrO.png`;
  }))();
}
var xc;
function Sc() {
  return (Sc = t(() => {
    xc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST07-BNgNSfkO.png`;
  }))();
}
var Cc;
function wc() {
  return (wc = t(() => {
    Cc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST08-CtciwT1X.png`;
  }))();
}
var Tc;
function Ec() {
  return (Ec = t(() => {
    Tc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST09-CTHywWYV.png`;
  }))();
}
var Dc;
function Oc() {
  return (Oc = t(() => {
    Dc = `https://assets-cdn.kahoot.it/solo/assets/STOMPDUST10-DRZfLX12.png`;
  }))();
}
var kc;
function Ac() {
  return (Ac = t(() => {
    kc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCITY00-BIIS1_B3.png`;
  }))();
}
var jc;
function Mc() {
  return (Mc = t(() => {
    jc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCLOUDS01-Dn1QNXUw.png`;
  }))();
}
var Nc;
function Pc() {
  return (Pc = t(() => {
    Nc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCLOUDS02-CFPC15hu.png`;
  }))();
}
var Fc;
function Ic() {
  return (Ic = t(() => {
    Fc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCLOUDS03-p4VjxeJ3.png`;
  }))();
}
var Lc;
function Rc() {
  return (Rc = t(() => {
    Lc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDSECONDFILE-BD13vFZl.png`;
  }))();
}
var zc;
function Bc() {
  return (Bc = t(() => {
    zc = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDTREE-CHO8lOz7.png`;
  }))();
}
var Vc;
function Hc() {
  return (Hc = t(() => {
    Vc = `https://assets-cdn.kahoot.it/solo/assets/CLOSESCREENBUSH00-ivurJzJq.png`;
  }))();
}
var Uc;
function Wc() {
  return (Wc = t(() => {
    Uc = `https://assets-cdn.kahoot.it/solo/assets/CLOSESCREENBUSH01-CNWtdYFg.png`;
  }))();
}
var Gc;
function Kc() {
  return (Kc = t(() => {
    Gc = `https://assets-cdn.kahoot.it/solo/assets/CONSTRUCTIONBLOCKB01-WnMT3iBJ.png`;
  }))();
}
var qc;
function Jc() {
  return (Jc = t(() => {
    qc = `https://assets-cdn.kahoot.it/solo/assets/DOOR01-fFHLJBD9.png`;
  }))();
}
var Yc;
function Xc() {
  return (Xc = t(() => {
    Yc = `https://assets-cdn.kahoot.it/solo/assets/DOOR02-BSiVpZxk.png`;
  }))();
}
var Zc;
function Qc() {
  return (Qc = t(() => {
    Zc = `https://assets-cdn.kahoot.it/solo/assets/DOOR03-C1dodjQ0.png`;
  }))();
}
var $c;
function el() {
  return (el = t(() => {
    $c = `https://assets-cdn.kahoot.it/solo/assets/DOOR04-CBYOkFWa.png`;
  }))();
}
var tl;
function nl() {
  return (nl = t(() => {
    tl = `https://assets-cdn.kahoot.it/solo/assets/FALLINGBLOCKBEHIND-CJ0xjEPa.png`;
  }))();
}
var rl;
function il() {
  return (il = t(() => {
    rl = `https://assets-cdn.kahoot.it/solo/assets/FALLINGBLOCKOVER-4qDBkrph.png`;
  }))();
}
var al;
function ol() {
  return (ol = t(() => {
    al = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE00-DRKitfEx.png`;
  }))();
}
var sl;
function cl() {
  return (cl = t(() => {
    sl = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE01-D50imlYl.png`;
  }))();
}
var ll;
function ul() {
  return (ul = t(() => {
    ll = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE02-DYy5IDrY.png`;
  }))();
}
var dl;
function fl() {
  return (fl = t(() => {
    dl = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR01-DB6d_wTo.png`;
  }))();
}
var pl;
function ml() {
  return (ml = t(() => {
    pl = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR02-CwZgrmqt.png`;
  }))();
}
var hl;
function gl() {
  return (gl = t(() => {
    hl = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR03-B8FgBA1j.png`;
  }))();
}
var _l;
function vl() {
  return (vl = t(() => {
    _l = `https://assets-cdn.kahoot.it/solo/assets/FLOORTOP-D8FHA7Lz.png`;
  }))();
}
var yl;
function bl() {
  return (bl = t(() => {
    yl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE00-0ZAqH5lE.png`;
  }))();
}
var xl;
function Sl() {
  return (Sl = t(() => {
    xl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE01-cuQf0tXz.png`;
  }))();
}
var Cl;
function wl() {
  return (wl = t(() => {
    Cl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE02-Bw-ClDdD.png`;
  }))();
}
var Tl;
function El() {
  return (El = t(() => {
    Tl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR00-BbtNCNab.png`;
  }))();
}
var Dl;
function Ol() {
  return (Ol = t(() => {
    Dl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR01-1cL2OjFG.png`;
  }))();
}
var kl;
function Al() {
  return (Al = t(() => {
    kl = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR02-NVUehXw0.png`;
  }))();
}
var jl;
function Ml() {
  return (Ml = t(() => {
    jl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA01-CRadNIZo.png`;
  }))();
}
var Nl;
function Pl() {
  return (Pl = t(() => {
    Nl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA02-BnDK5sr1.png`;
  }))();
}
var Fl;
function Il() {
  return (Il = t(() => {
    Fl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA03-BiDTduOn.png`;
  }))();
}
var Ll;
function Rl() {
  return (Rl = t(() => {
    Ll = `https://assets-cdn.kahoot.it/solo/assets/GORILLA04-BNwD7WZL.png`;
  }))();
}
var zl;
function Bl() {
  return (Bl = t(() => {
    zl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA05-B86NYyYW.png`;
  }))();
}
var Vl;
function Hl() {
  return (Hl = t(() => {
    Vl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA06-cwFwuTOA.png`;
  }))();
}
var Ul;
function Wl() {
  return (Wl = t(() => {
    Ul = `https://assets-cdn.kahoot.it/solo/assets/GORILLA07-B72kUz1t.png`;
  }))();
}
var Gl;
function Kl() {
  return (Kl = t(() => {
    Gl = `https://assets-cdn.kahoot.it/solo/assets/GORILLA08-BXfzamH1.png`;
  }))();
}
var ql;
function Jl() {
  return (Jl = t(() => {
    ql = `https://assets-cdn.kahoot.it/solo/assets/GORILLAATTACKBACKGROUND-DiTnEeyO.png`;
  }))();
}
var Yl;
function Xl() {
  return (Xl = t(() => {
    Yl = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA01-BYKaOpMc.png`;
  }))();
}
var Zl;
function Ql() {
  return (Ql = t(() => {
    Zl = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA02-C0RixNOh.png`;
  }))();
}
var $l;
function eu() {
  return (eu = t(() => {
    $l = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA03-B78MX-_L.png`;
  }))();
}
var tu;
function nu() {
  return (nu = t(() => {
    tu = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA04-DbJevdph.png`;
  }))();
}
var ru;
function iu() {
  return (iu = t(() => {
    ru = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA05-C5qtQT4a.png`;
  }))();
}
var au;
function ou() {
  return (ou = t(() => {
    au = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA06-CGtVPWrc.png`;
  }))();
}
var su;
function cu() {
  return (cu = t(() => {
    su = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA07-CwooR0nF.png`;
  }))();
}
var lu;
function uu() {
  return (uu = t(() => {
    lu = `https://assets-cdn.kahoot.it/solo/assets/KINGGORILLA08-BISIla1z.png`;
  }))();
}
var du;
function fu() {
  return (fu = t(() => {
    du = `https://assets-cdn.kahoot.it/solo/assets/MURETE00-C4xADeRn.png`;
  }))();
}
var pu;
function mu() {
  return (mu = t(() => {
    pu = `https://assets-cdn.kahoot.it/solo/assets/MURETESTAIRS00-D1nmdAkC.png`;
  }))();
}
var hu;
function gu() {
  return (gu = t(() => {
    hu = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE00-DQrK4TyX.png`;
  }))();
}
var _u;
function vu() {
  return (vu = t(() => {
    _u = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE01-CiNNXVq-.png`;
  }))();
}
var yu;
function bu() {
  return (bu = t(() => {
    yu = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE02-5tuUThPP.png`;
  }))();
}
var xu;
function Su() {
  return (Su = t(() => {
    xu = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR00-B08BzNAi.png`;
  }))();
}
var Cu;
function wu() {
  return (wu = t(() => {
    Cu = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR01-CBrJ8Cng.png`;
  }))();
}
var Tu;
function Eu() {
  return (Eu = t(() => {
    Tu = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR02-Wl613Ich.png`;
  }))();
}
var Du;
function Ou() {
  return (Ou = t(() => {
    Du = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE00-7TYISl8h.png`;
  }))();
}
var ku;
function Au() {
  return (Au = t(() => {
    ku = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE01-BaFYJijb.png`;
  }))();
}
var ju;
function Mu() {
  return (Mu = t(() => {
    ju = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE02-D3VZ5Zp_.png`;
  }))();
}
var Nu;
function Pu() {
  return (Pu = t(() => {
    Nu = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR00-CK6oJB46.png`;
  }))();
}
var Fu;
function Iu() {
  return (Iu = t(() => {
    Fu = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR01-qcRxW5E4.png`;
  }))();
}
var Lu;
function Ru() {
  return (Ru = t(() => {
    Lu = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR02-CunFaOmv.png`;
  }))();
}
var zu;
function Bu() {
  return (Bu = t(() => {
    zu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE00-DVQdG0Ww.png`;
  }))();
}
var Vu;
function Hu() {
  return (Hu = t(() => {
    Vu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE01-DpYJEEaq.png`;
  }))();
}
var Uu;
function Wu() {
  return (Wu = t(() => {
    Uu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE02-CjPyMN5m.png`;
  }))();
}
var Gu;
function Ku() {
  return (Ku = t(() => {
    Gu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR00-BoTuIInP.png`;
  }))();
}
var qu;
function Ju() {
  return (Ju = t(() => {
    qu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR01-DjO4HUA5.png`;
  }))();
}
var Yu;
function Xu() {
  return (Xu = t(() => {
    Yu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR02-B7qtGuvW.png`;
  }))();
}
var Zu;
function Qu() {
  return (Qu = t(() => {
    Zu = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSTILEDGROUND01-Cl7F9zJn.png`;
  }))();
}
var $u;
function ed() {
  return (ed = t(() => {
    $u = `https://assets-cdn.kahoot.it/solo/assets/TOPBLOCK01-CGjWdL43.png`;
  }))();
}
var td;
function nd() {
  return (nd = t(() => {
    td = `https://assets-cdn.kahoot.it/solo/assets/TOPBLOCK02-SrXdpl_t.png`;
  }))();
}
var rd;
function id() {
  return (id = t(() => {
    rd = `https://assets-cdn.kahoot.it/solo/assets/TOPBLOCK03-Oxqy6fu3.png`;
  }))();
}
var ad;
function od() {
  return (od = t(() => {
    ad = `https://assets-cdn.kahoot.it/solo/assets/TRIGGER01-Bb-DkDnE.png`;
  }))();
}
var sd;
function cd() {
  return (cd = t(() => {
    sd = `https://assets-cdn.kahoot.it/solo/assets/TRIGGER02-Dejt9C1y.png`;
  }))();
}
var ld;
function ud() {
  return (ud = t(() => {
    ld = `https://assets-cdn.kahoot.it/solo/assets/TRIGGER03-BMaKLPYn.png`;
  }))();
}
var dd;
function fd() {
  return (fd = t(() => {
    dd = `https://assets-cdn.kahoot.it/solo/assets/TRIGGERBG-DM2YA7HB.png`;
  }))();
}
var pd;
function md() {
  return (md = t(() => {
    pd = `https://assets-cdn.kahoot.it/solo/assets/WINDOW01-0rhTws0i.png`;
  }))();
}
var hd;
function gd() {
  return (gd = t(() => {
    hd = `https://assets-cdn.kahoot.it/solo/assets/WINDOW02-0DPv2aw4.png`;
  }))();
}
var _d;
function vd() {
  return (vd = t(() => {
    _d = `https://assets-cdn.kahoot.it/solo/assets/WINDOW03-Cd-_e4K7.png`;
  }))();
}
var yd;
function bd() {
  return (bd = t(() => {
    yd = `https://assets-cdn.kahoot.it/solo/assets/WINDOW04-p6AvxoUd.png`;
  }))();
}
var xd;
function Sd() {
  return (Sd = t(() => {
    xd = `https://assets-cdn.kahoot.it/solo/assets/WINDOW05-DaiwMcbf.png`;
  }))();
}
var Cd;
function wd() {
  return (wd = t(() => {
    Cd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK01-C7d2uX_g.png`;
  }))();
}
var Td;
function Ed() {
  return (Ed = t(() => {
    Td = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK02-DyA9-hJE.png`;
  }))();
}
var Dd;
function Od() {
  return (Od = t(() => {
    Dd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK03-Beyovmsj.png`;
  }))();
}
var kd;
function Ad() {
  return (Ad = t(() => {
    kd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK04-C_xpeaUe.png`;
  }))();
}
var jd;
function Md() {
  return (Md = t(() => {
    jd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK05-9360JN46.png`;
  }))();
}
var Nd;
function Pd() {
  return (Pd = t(() => {
    Nd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK06-ClsuduhJ.png`;
  }))();
}
var Fd;
function Id() {
  return (Id = t(() => {
    Fd = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK07-CZKRNROt.png`;
  }))();
}
var Ld;
function Rd() {
  return (Rd = t(() => {
    Ld = `https://assets-cdn.kahoot.it/solo/assets/ALIENATTACK08-D_zU2Weh.png`;
  }))();
}
var zd;
function Bd() {
  return (Bd = t(() => {
    zd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER00-DM2Ybxg0.png`;
  }))();
}
var Vd;
function Hd() {
  return (Hd = t(() => {
    Vd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER01-DvrkVpUT.png`;
  }))();
}
var Ud;
function Wd() {
  return (Wd = t(() => {
    Ud = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER02-BchoweNg.png`;
  }))();
}
var Gd;
function Kd() {
  return (Kd = t(() => {
    Gd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER03-gjtig_Og.png`;
  }))();
}
var qd;
function Jd() {
  return (Jd = t(() => {
    qd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER04-CFrID6Um.png`;
  }))();
}
var Yd;
function Xd() {
  return (Xd = t(() => {
    Yd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER05-Cpn4pi1y.png`;
  }))();
}
var Zd;
function Qd() {
  return (Qd = t(() => {
    Zd = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER06-B1kOsgpJ.png`;
  }))();
}
var $d;
function ef() {
  return (ef = t(() => {
    $d = `https://assets-cdn.kahoot.it/solo/assets/ALIENGORILLATRIGGER07-BhM3yyL7.png`;
  }))();
}
var tf;
function nf() {
  return (nf = t(() => {
    tf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCITY00-V-dmBpK1.png`;
  }))();
}
var rf;
function af() {
  return (af = t(() => {
    rf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDCITY01-BAA3aaGA.png`;
  }))();
}
var of;
function sf() {
  return (sf = t(() => {
    of = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDHOLE00-BgnmEkCu.png`;
  }))();
}
var cf;
function lf() {
  return (lf = t(() => {
    cf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDHOLE01-BDvlrBDz.png`;
  }))();
}
var uf;
function df() {
  return (df = t(() => {
    uf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDPLANET00-t_Ac5gKs.png`;
  }))();
}
var ff;
function pf() {
  return (pf = t(() => {
    ff = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDPLANET01-DEFamU8d.png`;
  }))();
}
var mf;
function hf() {
  return (hf = t(() => {
    mf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDPLANET03-Di_Gidqc.png`;
  }))();
}
var gf;
function _f() {
  return (_f = t(() => {
    gf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDPLANET04-M45r_ZKn.png`;
  }))();
}
var vf;
function yf() {
  return (yf = t(() => {
    vf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDSECONDFILE01-8CQrx5S1.png`;
  }))();
}
var bf;
function xf() {
  return (xf = t(() => {
    bf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDSECONDFILE02-LbAHD_r6.png`;
  }))();
}
var Sf;
function Cf() {
  return (Cf = t(() => {
    Sf = `https://assets-cdn.kahoot.it/solo/assets/BACKGROUNDSTARS-Bn22M9SN.png`;
  }))();
}
var wf;
function Tf() {
  return (Tf = t(() => {
    wf = `https://assets-cdn.kahoot.it/solo/assets/BARRIER01A-B3ZVQBLq.png`;
  }))();
}
var Ef;
function Df() {
  return (Df = t(() => {
    Ef = `https://assets-cdn.kahoot.it/solo/assets/BARRIER01B-DISD2XvH.png`;
  }))();
}
var Of;
function kf() {
  return (kf = t(() => {
    Of = `https://assets-cdn.kahoot.it/solo/assets/BARRIER02A-B-tzNiQl.png`;
  }))();
}
var Af;
function jf() {
  return (jf = t(() => {
    Af = `https://assets-cdn.kahoot.it/solo/assets/BARRIER02B-DrSQWQEQ.png`;
  }))();
}
var Mf;
function Nf() {
  return (Nf = t(() => {
    Mf = `https://assets-cdn.kahoot.it/solo/assets/BARRIER03A-D-iJY6bN.png`;
  }))();
}
var Pf;
function Ff() {
  return (Ff = t(() => {
    Pf = `https://assets-cdn.kahoot.it/solo/assets/BARRIER03B-B65mR34a.png`;
  }))();
}
var If;
function Lf() {
  return (Lf = t(() => {
    If = `https://assets-cdn.kahoot.it/solo/assets/BARRIER04A-B92QAB4h.png`;
  }))();
}
var Rf;
function zf() {
  return (zf = t(() => {
    Rf = `https://assets-cdn.kahoot.it/solo/assets/BARRIER04B-BKCjqQkV.png`;
  }))();
}
var Bf;
function Vf() {
  return (Vf = t(() => {
    Bf = `https://assets-cdn.kahoot.it/solo/assets/BRIGHT00-CaulZ5WJ.png`;
  }))();
}
var Hf;
function Uf() {
  return (Uf = t(() => {
    Hf = `https://assets-cdn.kahoot.it/solo/assets/CLOSESCREENBUSH00-BPcaMu2x.png`;
  }))();
}
var Wf;
function Gf() {
  return (Gf = t(() => {
    Wf = `https://assets-cdn.kahoot.it/solo/assets/CLOSESCREENBUSH01-sqQP3upf.png`;
  }))();
}
var Kf;
function qf() {
  return (qf = t(() => {
    Kf = `https://assets-cdn.kahoot.it/solo/assets/CONSTRUCTIONBLOCKB01-C8tQPnb9.png`;
  }))();
}
var Jf;
function Yf() {
  return (Yf = t(() => {
    Jf = `https://assets-cdn.kahoot.it/solo/assets/DOOR01-ekJXhV-B.png`;
  }))();
}
var Xf;
function Zf() {
  return (Zf = t(() => {
    Xf = `https://assets-cdn.kahoot.it/solo/assets/DOOR02-DgxhWtEz.png`;
  }))();
}
var Qf;
function $f() {
  return ($f = t(() => {
    Qf = `https://assets-cdn.kahoot.it/solo/assets/DOOR03-DXVParst.png`;
  }))();
}
var ep;
function tp() {
  return (tp = t(() => {
    ep = `https://assets-cdn.kahoot.it/solo/assets/DOOR04-s1zB00-3.png`;
  }))();
}
var np;
function rp() {
  return (rp = t(() => {
    np = `https://assets-cdn.kahoot.it/solo/assets/FALLINGBLOCKBEHIND-DjQPBdlg.png`;
  }))();
}
var ip;
function ap() {
  return (ap = t(() => {
    ip = `https://assets-cdn.kahoot.it/solo/assets/FALLINGBLOCKOVER2-QFVYIhZn.png`;
  }))();
}
var op;
function sp() {
  return (sp = t(() => {
    op = `https://assets-cdn.kahoot.it/solo/assets/FALLINGBLOCKOVER-Dy1mwT05.png`;
  }))();
}
var cp;
function lp() {
  return (lp = t(() => {
    cp = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE00-yN5AuUb6.png`;
  }))();
}
var up;
function dp() {
  return (dp = t(() => {
    up = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE01-sjT8sCYf.png`;
  }))();
}
var fp;
function pp() {
  return (pp = t(() => {
    fp = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSBASE02-BAuSOhbo.png`;
  }))();
}
var mp;
function hp() {
  return (hp = t(() => {
    mp = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR01-j9RtaQaO.png`;
  }))();
}
var gp;
function _p() {
  return (_p = t(() => {
    gp = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR02-DF-iFpO1.png`;
  }))();
}
var vp;
function yp() {
  return (yp = t(() => {
    vp = `https://assets-cdn.kahoot.it/solo/assets/FIVEBLOCKSFLOOR03-CWBgsUP-.png`;
  }))();
}
var bp;
function xp() {
  return (xp = t(() => {
    bp = `https://assets-cdn.kahoot.it/solo/assets/FLAME00-UWHcvTgR.png`;
  }))();
}
var Sp;
function Cp() {
  return (Cp = t(() => {
    Sp = `https://assets-cdn.kahoot.it/solo/assets/FLAME01-CuS-1t04.png`;
  }))();
}
var wp;
function Tp() {
  return (Tp = t(() => {
    wp = `https://assets-cdn.kahoot.it/solo/assets/FLAME02-BoNvf7Kt.png`;
  }))();
}
var Ep;
function Dp() {
  return (Dp = t(() => {
    Ep = `https://assets-cdn.kahoot.it/solo/assets/FLAME03-CvdqPFMh.png`;
  }))();
}
var Op;
function kp() {
  return (kp = t(() => {
    Op = `https://assets-cdn.kahoot.it/solo/assets/FLAME04-DqtTz9tA.png`;
  }))();
}
var Ap;
function jp() {
  return (jp = t(() => {
    Ap = `https://assets-cdn.kahoot.it/solo/assets/FLAME05-iFoCWTFE.png`;
  }))();
}
var Mp;
function Np() {
  return (Np = t(() => {
    Mp = `https://assets-cdn.kahoot.it/solo/assets/FLOORTOP-DMkPSVO-.png`;
  }))();
}
var Pp;
function Fp() {
  return (Fp = t(() => {
    Pp = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE00-5f-4TfiQ.png`;
  }))();
}
var Ip;
function Lp() {
  return (Lp = t(() => {
    Ip = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE01-Brc_JTN1.png`;
  }))();
}
var Rp;
function zp() {
  return (zp = t(() => {
    Rp = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSBASE02-BhmJCH6A.png`;
  }))();
}
var Bp;
function Vp() {
  return (Vp = t(() => {
    Bp = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR00-fefz65yf.png`;
  }))();
}
var Hp;
function Up() {
  return (Up = t(() => {
    Hp = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR01-etK-mixZ.png`;
  }))();
}
var Wp;
function Gp() {
  return (Gp = t(() => {
    Wp = `https://assets-cdn.kahoot.it/solo/assets/FOURBLOCKSFLOOR02-D0aunjXq.png`;
  }))();
}
var Kp;
function qp() {
  return (qp = t(() => {
    Kp = `https://assets-cdn.kahoot.it/solo/assets/MONSTERTRIGGERBLOCK-BtPkzNjx.png`;
  }))();
}
var Jp;
function Yp() {
  return (Yp = t(() => {
    Jp = `https://assets-cdn.kahoot.it/solo/assets/MURETE00-BzWoT4al.png`;
  }))();
}
var Xp;
function Zp() {
  return (Zp = t(() => {
    Xp = `https://assets-cdn.kahoot.it/solo/assets/MURETESTAIRS00-BAcdq15z.png`;
  }))();
}
var Qp;
function $p() {
  return ($p = t(() => {
    Qp = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE00-Da1XVsES.png`;
  }))();
}
var em;
function tm() {
  return (tm = t(() => {
    em = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE01-CT6wRPsd.png`;
  }))();
}
var nm;
function rm() {
  return (rm = t(() => {
    nm = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSBASE02-DNjDZ5c9.png`;
  }))();
}
var im;
function am() {
  return (am = t(() => {
    im = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR00-B65gBis7.png`;
  }))();
}
var om;
function sm() {
  return (sm = t(() => {
    om = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR01-1KYvOkjD.png`;
  }))();
}
var cm;
function lm() {
  return (lm = t(() => {
    cm = `https://assets-cdn.kahoot.it/solo/assets/SEVENBLOCKSFLOOR02-B3TVD-At.png`;
  }))();
}
var um;
function dm() {
  return (dm = t(() => {
    um = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE00-DWGGGaqp.png`;
  }))();
}
var fm;
function pm() {
  return (pm = t(() => {
    fm = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE01-J03diNJD.png`;
  }))();
}
var mm;
function hm() {
  return (hm = t(() => {
    mm = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSBASE02-Q-RPkSDJ.png`;
  }))();
}
var gm;
function _m() {
  return (_m = t(() => {
    gm = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR00-Domn7HgU.png`;
  }))();
}
var vm;
function ym() {
  return (ym = t(() => {
    vm = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR01-3c8YygWY.png`;
  }))();
}
var bm;
function xm() {
  return (xm = t(() => {
    bm = `https://assets-cdn.kahoot.it/solo/assets/SIXBLOCKSFLOOR02-Ckx9lnDR.png`;
  }))();
}
var Sm;
function Cm() {
  return (Cm = t(() => {
    Sm = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE00-C1ITRwgu.png`;
  }))();
}
var wm;
function Tm() {
  return (Tm = t(() => {
    wm = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE01-C7byEr8X.png`;
  }))();
}
var Em;
function Dm() {
  return (Dm = t(() => {
    Em = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSBASE02-D9_39euk.png`;
  }))();
}
var Om;
function km() {
  return (km = t(() => {
    Om = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR00-DvMM28J6.png`;
  }))();
}
var Am;
function jm() {
  return (jm = t(() => {
    Am = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR01-Z1Z9Te20.png`;
  }))();
}
var Mm;
function Nm() {
  return (Nm = t(() => {
    Mm = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSFLOOR02-DwlqoOol.png`;
  }))();
}
var Pm;
function Fm() {
  return (Fm = t(() => {
    Pm = `https://assets-cdn.kahoot.it/solo/assets/THREEBLOCKSTILEDGROUND01-D4JGNfPP.png`;
  }))();
}
var Im;
function Lm() {
  return (Lm = t(() => {
    Im = `https://assets-cdn.kahoot.it/solo/assets/WINDOW01-79IDZZNq.png`;
  }))();
}
var Rm;
function zm() {
  return (zm = t(() => {
    Rm = `https://assets-cdn.kahoot.it/solo/assets/WINDOW02-CPwekbVz.png`;
  }))();
}
var Bm;
function Vm() {
  return (Vm = t(() => {
    Bm = `https://assets-cdn.kahoot.it/solo/assets/WINDOW03-CA52XEmL.png`;
  }))();
}
var Hm;
function Um() {
  return (Um = t(() => {
    Hm = `https://assets-cdn.kahoot.it/solo/assets/WINDOW04-CeruIakc.png`;
  }))();
}
var Wm;
function Gm() {
  return (Gm = t(() => {
    Wm = `https://assets-cdn.kahoot.it/solo/assets/WINDOW05-C8p5I-kV.png`;
  }))();
}
var Km;
function qm() {
  return (qm = t(() => {
    Km = `https://assets-cdn.kahoot.it/solo/assets/WINDOW06-D2LHPGhA.png`;
  }))();
}
var Jm;
function Ym() {
  return (Ym = t(() => {
    Jm = `https://assets-cdn.kahoot.it/solo/assets/WINDOW07-CFd_48oq.png`;
  }))();
}
var Xm, Zm, Qm, $m;
function eh() {
  return (eh = t(() => {
    f(),
      l(),
      za(),
      Va(),
      Ua(),
      Ga(),
      qa(),
      Ya(),
      Za(),
      $a(),
      to(),
      ro(),
      ao(),
      so(),
      lo(),
      fo(),
      mo(),
      go(),
      vo(),
      bo(),
      So(),
      wo(),
      Eo(),
      Oo(),
      Ao(),
      Mo(),
      Po(),
      Io(),
      Ro(),
      Bo(),
      Ho(),
      Wo(),
      Ko(),
      Jo(),
      Xo(),
      Qo(),
      es(),
      ns(),
      is(),
      os(),
      cs(),
      us(),
      fs(),
      ms(),
      gs(),
      vs(),
      bs(),
      Ss(),
      ws(),
      Es(),
      Os(),
      As(),
      Ms(),
      Ps(),
      Is(),
      Rs(),
      Bs(),
      Hs(),
      Ws(),
      Ks(),
      Js(),
      Xs(),
      Qs(),
      ec(),
      nc(),
      ic(),
      oc(),
      cc(),
      uc(),
      fc(),
      mc(),
      gc(),
      vc(),
      bc(),
      Sc(),
      wc(),
      Ec(),
      Oc(),
      V(),
      Ac(),
      Mc(),
      Pc(),
      Ic(),
      Rc(),
      Bc(),
      Hc(),
      Wc(),
      Kc(),
      Jc(),
      Xc(),
      Qc(),
      el(),
      nl(),
      il(),
      ol(),
      cl(),
      ul(),
      fl(),
      ml(),
      gl(),
      vl(),
      bl(),
      Sl(),
      wl(),
      El(),
      Ol(),
      Al(),
      Ml(),
      Pl(),
      Il(),
      Rl(),
      Bl(),
      Hl(),
      Wl(),
      Kl(),
      Jl(),
      Xl(),
      Ql(),
      eu(),
      nu(),
      iu(),
      ou(),
      cu(),
      uu(),
      fu(),
      mu(),
      gu(),
      vu(),
      bu(),
      Su(),
      wu(),
      Eu(),
      Ou(),
      Au(),
      Mu(),
      Pu(),
      Iu(),
      Ru(),
      Bu(),
      Hu(),
      Wu(),
      Ku(),
      Ju(),
      Xu(),
      Qu(),
      ed(),
      nd(),
      id(),
      od(),
      cd(),
      ud(),
      fd(),
      md(),
      gd(),
      vd(),
      bd(),
      Sd(),
      wd(),
      Ed(),
      Od(),
      Ad(),
      Md(),
      Pd(),
      Id(),
      Rd(),
      Bd(),
      Hd(),
      Wd(),
      Kd(),
      Jd(),
      Xd(),
      Qd(),
      ef(),
      nf(),
      af(),
      sf(),
      lf(),
      df(),
      pf(),
      hf(),
      _f(),
      yf(),
      xf(),
      Cf(),
      Tf(),
      Df(),
      kf(),
      jf(),
      Nf(),
      Ff(),
      Lf(),
      zf(),
      Vf(),
      Uf(),
      Gf(),
      qf(),
      Yf(),
      Zf(),
      $f(),
      tp(),
      rp(),
      ap(),
      sp(),
      lp(),
      dp(),
      pp(),
      hp(),
      _p(),
      yp(),
      xp(),
      Cp(),
      Tp(),
      Dp(),
      kp(),
      jp(),
      Np(),
      Fp(),
      Lp(),
      zp(),
      Vp(),
      Up(),
      Gp(),
      qp(),
      Yp(),
      Zp(),
      $p(),
      tm(),
      rm(),
      am(),
      sm(),
      lm(),
      dm(),
      pm(),
      hm(),
      _m(),
      ym(),
      xm(),
      Cm(),
      Tm(),
      Dm(),
      km(),
      jm(),
      Nm(),
      Fm(),
      Lm(),
      zm(),
      Vm(),
      Um(),
      Gm(),
      qm(),
      Ym(),
      (Xm = [
        { name: je, url: Xa },
        { name: Me, url: Qa },
        { name: Ne, url: eo },
        { name: Pe, url: no },
        { name: Fe, url: io },
        { name: Ie, url: oo },
        { name: Le, url: co },
        { name: Re, url: uo },
        { name: ze, url: po },
        { name: Ve, url: ho },
        { name: He, url: _o },
        { name: Ue, url: yo },
        { name: We, url: xo },
        { name: Ge, url: Co },
        { name: Ke, url: To },
        { name: qe, url: Do },
        { name: Je, url: ko },
        { name: Ye, url: jo },
        { name: st, url: Vo },
        { name: ct, url: Uo },
        { name: lt, url: Go },
        { name: ut, url: qo },
        { name: dt, url: Yo },
        { name: ft, url: Zo },
        { name: pt, url: $o },
        { name: mt, url: ts },
        { name: Ot, url: Fs },
        { name: kt, url: Ls },
        { name: At, url: zs },
        { name: Mt, url: Vs },
        { name: Nt, url: Us },
        { name: Pt, url: Gs },
        { name: Ft, url: qs },
        { name: Lt, url: Ys },
        { name: Ze, url: No },
        { name: Qe, url: Fo },
        { name: $e, url: Lo },
        { name: tt, url: zo },
        { name: nt, url: rs },
        { name: rt, url: as },
        { name: it, url: ss },
        { name: ot, url: ls },
        { name: Rt, url: $s },
        { name: zt, url: Zs },
        { name: Bt, url: tc },
        { name: we, url: Ra },
        { name: Te, url: Ba },
        { name: Ee, url: Ha },
        { name: De, url: Wa },
        { name: Oe, url: Ka },
        { name: ke, url: Ja },
        { name: Qt, url: rc },
        { name: $t, url: ac },
        { name: en, url: sc },
        { name: nn, url: ds },
        { name: gt, url: ps },
        { name: _t, url: hs },
        { name: vt, url: _s },
        { name: yt, url: ys },
        { name: bt, url: xs },
        { name: xt, url: Cs },
        { name: St, url: Ts },
        { name: Ct, url: Ds },
        { name: wt, url: ks },
        { name: Tt, url: js },
        { name: Et, url: Ns },
        { name: Vt, url: lc },
        { name: Ht, url: dc },
        { name: Ut, url: pc },
        { name: Wt, url: hc },
        { name: Gt, url: _c },
        { name: Kt, url: yc },
        { name: qt, url: xc },
        { name: Jt, url: Cc },
        { name: Yt, url: Tc },
        { name: Xt, url: Dc },
      ]),
      (Zm = [
        { name: on, url: kc, width: sn[0], height: sn[1] },
        { name: cn, url: Lc },
        { name: ln, url: jc },
        { name: un, url: Nc },
        { name: dn, url: Fc },
        { name: pn, url: Zu, width: mn[0], height: mn[1] },
        { name: hn, url: zc },
        { name: gn, url: Vc },
        { name: _n, url: Uc },
        { name: vn, url: Gc },
        { name: yn, url: tl },
        { name: bn, url: rl },
        { name: xn, url: _l },
        { name: Sn, url: zu },
        { name: Cn, url: Vu },
        { name: wn, url: Uu },
        { name: Ln, url: Gu },
        { name: Rn, url: qu },
        { name: zn, url: Yu },
        { name: Tn, url: yl },
        { name: En, url: xl },
        { name: Dn, url: Cl },
        { name: Bn, url: Tl },
        { name: Vn, url: Dl },
        { name: Hn, url: kl },
        { name: On, url: al },
        { name: kn, url: sl },
        { name: An, url: ll },
        { name: Un, url: dl },
        { name: Wn, url: pl },
        { name: Gn, url: hl },
        { name: jn, url: Du },
        { name: Mn, url: ku },
        { name: Nn, url: ju },
        { name: Kn, url: Nu },
        { name: qn, url: Fu },
        { name: Jn, url: Lu },
        { name: Pn, url: hu },
        { name: Fn, url: _u },
        { name: In, url: yu },
        { name: Yn, url: xu },
        { name: Xn, url: Cu },
        { name: Zn, url: Tu },
        { name: $n, url: $u },
        { name: er, url: td },
        { name: tr, url: rd },
        { name: nr, url: pd },
        { name: rr, url: hd },
        { name: ir, url: _d },
        { name: ar, url: yd },
        { name: or, url: xd },
        { name: sr, url: qc },
        { name: P, url: Yc },
        { name: cr, url: Zc },
        { name: F, url: $c },
        { name: ur, url: du },
        { name: dr, url: pu },
        { name: fr, url: ad },
        { name: pr, url: sd },
        { name: mr, url: ld },
        { name: gr, url: dd },
        { name: _r, url: ql },
        { name: vr, url: jl },
        { name: yr, url: Nl },
        { name: br, url: Fl },
        { name: xr, url: Ll },
        { name: Sr, url: zl },
        { name: Cr, url: Vl },
        { name: wr, url: Ul },
        { name: Tr, url: Gl },
        { name: Dr, url: Yl },
        { name: Or, url: Zl },
        { name: kr, url: $l },
        { name: Ar, url: tu },
        { name: jr, url: ru },
        { name: Mr, url: au },
        { name: Nr, url: su },
        { name: Pr, url: lu },
      ]),
      (Qm = [
        { name: Ir, url: tf, width: Lr[0], height: Lr[1] },
        { name: Rr, url: rf },
        { name: qr, url: of },
        { name: Jr, url: cf },
        { name: zr, url: uf },
        { name: Br, url: ff },
        { name: Vr, url: mf },
        { name: Hr, url: gf },
        { name: Wr, url: vf },
        { name: Gr, url: bf },
        { name: Kr, url: Sf },
        { name: Yr, url: wf },
        { name: Xr, url: Ef },
        { name: I, url: Of },
        { name: L, url: Af },
        { name: Zr, url: Mf },
        { name: Qr, url: Pf },
        { name: $r, url: If },
        { name: ei, url: Rf },
        { name: ni, url: Bf },
        { name: ii, url: Hf },
        { name: ai, url: Wf },
        { name: oi, url: Kf },
        { name: R, url: Jf },
        { name: z, url: Xf },
        { name: ui, url: Qf },
        { name: B, url: ep },
        { name: si, url: np },
        { name: ci, url: op },
        { name: li, url: ip },
        { name: Ei, url: cp },
        { name: Di, url: up },
        { name: Oi, url: fp },
        { name: ki, url: mp },
        { name: Ai, url: gp },
        { name: ji, url: vp },
        { name: ri, url: Mp },
        { name: bi, url: Pp },
        { name: xi, url: Ip },
        { name: Si, url: Rp },
        { name: Ci, url: Bp },
        { name: wi, url: Hp },
        { name: Ti, url: Wp },
        { name: sa, url: Kp },
        { name: wa, url: Jp },
        { name: Ta, url: Xp },
        { name: Ri, url: Qp },
        { name: zi, url: em },
        { name: Bi, url: nm },
        { name: Vi, url: im },
        { name: Hi, url: om },
        { name: Ui, url: cm },
        { name: Mi, url: um },
        { name: Ni, url: fm },
        { name: Pi, url: mm },
        { name: Fi, url: gm },
        { name: Ii, url: vm },
        { name: Li, url: bm },
        { name: mi, url: Sm },
        { name: hi, url: wm },
        { name: gi, url: Em },
        { name: _i, url: Om },
        { name: vi, url: Am },
        { name: yi, url: Mm },
        { name: fi, url: Pm, width: pi[0], height: pi[1] },
        { name: Gi, url: Im },
        { name: Ki, url: Rm },
        { name: qi, url: Bm },
        { name: Ji, url: Hm },
        { name: Yi, url: Wm },
        { name: Xi, url: Km },
        { name: Zi, url: Jm },
        { name: ha, url: Cd },
        { name: ga, url: Td },
        { name: _a, url: Dd },
        { name: va, url: kd },
        { name: ya, url: jd },
        { name: ba, url: Nd },
        { name: xa, url: Fd },
        { name: Sa, url: Ld },
        { name: Qi, url: zd },
        { name: $i, url: Vd },
        { name: ea, url: Ud },
        { name: ta, url: Gd },
        { name: na, url: qd },
        { name: ra, url: Yd },
        { name: ia, url: Zd },
        { name: aa, url: $d },
        { name: ca, url: bp },
        { name: la, url: Sp },
        { name: ua, url: wp },
        { name: da, url: Ep },
        { name: fa, url: Op },
        { name: pa, url: Ap },
      ]),
      ($m = (e) => {
        let t = [];
        switch (e) {
          case void 0:
          case b.HighestTowersCity:
            t = Zm;
            break;
          case b.HighestTowersSpace:
            t = Qm;
            break;
          default:
            t = Zm;
        }
        return [...Xm, ...t];
      });
  }))();
}
var th, G, nh;
function K() {
  return (K = t(() => {
    W(),
      (th = (
        { left: e, right: t, top: n, bottom: r },
        { left: i, right: a, top: o, bottom: s }
      ) => e === i && t === a && n === o && r === s),
      (G = (e) => {
        let { left: t, right: n, top: r, bottom: i } = e;
        return {
          vpWidth: n - t,
          vpHeight: i - r,
          vpHorizontalOffset: n - H,
          vpVerticalOffset: i - U,
          vpRelativeTop: U - r,
          vpRelativeBottom: U - i,
          vpRelativeLeft: H - t,
          vpRelativeRight: H - n,
        };
      }),
      (nh = (e) => e + 150);
  }))();
}
var rh, ih, ah, oh, sh, ch;
function lh() {
  return (lh = t(() => {
    (rh = e(i())),
      j(),
      (ih = 3),
      (ah = 10),
      (oh = 0.5),
      (sh = 1),
      (ch = class extends T {
        constructor(e, t, n) {
          super(e),
            (this.name = `Cloud`),
            this.anchor.set(0.5, 0.5),
            (this.x = t),
            (this.alpha = (0, rh.default)(oh, sh, !0)),
            (this._initialX = t),
            (this._maxDisplacement = n),
            (this._direction = Math.random() >= 0.5 ? -1 : 1),
            (this._speed = (0, rh.default)(ih, ah, !0));
        }
        update(e) {
          this.x += this._direction * (e / 1e3) * this._speed;
          let t = this._initialX - this._maxDisplacement,
            n = this._initialX + this._maxDisplacement;
          ((this._direction < 0 && this.x < t) ||
            (this._direction > 0 && this.x > n)) &&
            (this._direction *= -1);
        }
      });
  }))();
}
var q, uh, dh, fh, ph, mh, hh, gh, _h;
function vh() {
  return (vh = t(() => {
    (q = e(i())),
      (uh = e(r())),
      j(),
      W(),
      K(),
      lh(),
      (dh = 300),
      (fh = 75),
      (ph = 200),
      (mh = -25),
      (hh = 10),
      (gh = 20),
      (_h = class extends D {
        createGradient(e) {
          let t = new E();
          return (
            (t.name = `Gradient`),
            t
              .beginTextureFill({ texture: e })
              .drawRect(0, 0, 250, 500)
              .endFill(),
            t
          );
        }
        createItemSprite() {
          let e = new T((0, uh.default)(this._itemsTextures));
          return (
            (e.name = `BG Item`),
            e.anchor.set(0.5, 1),
            (e.x = this._towerX),
            (e.y = mh),
            e
          );
        }
        createCloudSprite(e) {
          let t = this._towerX - e / 2,
            n = this._towerX + e / 2;
          return new ch(
            (0, uh.default)(this._cloudTextures),
            (0, q.default)(t, n),
            e
          );
        }
        addItems() {
          let e = this.createItemSprite();
          (e.x += -this._towerWidth / 2 - (0, q.default)(hh, gh)),
            this.addChild(e);
          let t = this.createItemSprite();
          (t.x += this._towerWidth / 2 + (0, q.default)(hh, gh)),
            this.addChild(t);
        }
        updateClouds() {
          if (!this._viewportBounds) return;
          let {
            vpWidth: e,
            vpRelativeTop: t,
            vpRelativeBottom: n,
          } = G(this._viewportBounds);
          for (; this._lastCloudY > -t; ) {
            let t = this._lastCloudY - dh + (0, q.default)(-75, fh),
              n = this.createCloudSprite(e);
            (n.y = t),
              this._cloudsContainer.addChild(n),
              (this._lastCloudY = t);
          }
          for (let e = this._cloudsContainer.children.length - 1; e >= 0; e--) {
            let t = this._cloudsContainer.children[e];
            ph - t.y < n && (this._cloudsContainer.removeChild(t), t.destroy());
          }
        }
        updateBackground() {
          if (!this._viewportBounds) return;
          let { left: e } = this._viewportBounds,
            {
              vpWidth: t,
              vpHeight: n,
              vpRelativeBottom: r,
              vpVerticalOffset: i,
              vpRelativeTop: a,
            } = G(this._viewportBounds),
            o = n * 2,
            s = e,
            c = Math.min(r - o + i, -a);
          (this._gradientGraphics.width = t),
            (this._gradientGraphics.height = n * 2),
            (this._gradientGraphics.x = s),
            (this._gradientGraphics.y = c);
        }
        constructor({
          towerX: e,
          towerWidth: t,
          cloudTextures: n,
          baseTilingSprites: r,
          itemsTextures: i = [],
          gradientTexture: a,
        }) {
          super(),
            (this._lastCloudY = -275 + (0, q.default)(-75, fh)),
            (this._baseTilingSprites = []),
            (this._towerX = e),
            (this._towerWidth = t),
            (this._gradientGraphics = this.createGradient(a)),
            this.addChild(this._gradientGraphics),
            (this._cloudTextures = n),
            (this._baseTilingSprites = r),
            this._baseTilingSprites.forEach((e) => {
              (e.width = H), this.addChild(e);
            }),
            (this._itemsTextures = i),
            this.addItems(),
            (this._cloudsContainer = new D()),
            (this._cloudsContainer.name = `Clouds Container`),
            this.addChild(this._cloudsContainer);
        }
        update(e) {
          for (let t of this._cloudsContainer.children)
            t.destroyed || t.update(e);
        }
        set viewportBounds(e) {
          this.destroyed ||
            (this._viewportBounds && th(this._viewportBounds, e)) ||
            ((this._viewportBounds = e),
            this.updateBackground(),
            this.updateClouds());
        }
      });
  }))();
}
var yh, bh, xh, Sh, Ch, wh, Th;
function Eh() {
  return (Eh = t(() => {
    (yh = e(i())),
      (bh = e(r())),
      j(),
      W(),
      (xh = 35),
      (Sh = -30),
      (Ch = 20),
      (wh = 100),
      (Th = class extends D {
        createSoilItemSprite() {
          let e = new T((0, bh.default)(this._itemsTextures));
          return (
            (e.name = `Soil Item`),
            e.anchor.set(0.5, 1),
            (e.x = this._towerX),
            (e.y = Sh),
            e
          );
        }
        createFirstLevelSprite() {
          let e = new T((0, bh.default)(this._firstLevelTextures));
          return (
            (e.name = `First Level Item`),
            e.anchor.set(0.5, 1),
            (e.x = this._towerX),
            (e.scale.x = Math.random() <= 0.5 ? -1 : 1),
            e
          );
        }
        addSoilItems() {
          let e = this.createSoilItemSprite();
          (e.x += -this._towerWidth / 2 - (0, yh.default)(Ch, wh)),
            this.addChild(e);
          let t = this.createSoilItemSprite();
          (t.x += this._towerWidth / 2 + (0, yh.default)(Ch, wh)),
            this.addChild(t);
        }
        addFirstLevelItems() {
          let e = this.createFirstLevelSprite();
          (e.x += (0, yh.default)(-this._towerWidth / 2, this._towerWidth / 2)),
            this.addChild(e);
        }
        constructor({
          towerX: e,
          towerWidth: t,
          tilingSprite: n,
          itemsTextures: r = [],
          firstLevelTextures: i = [],
        }) {
          super(),
            (this._towerX = e),
            (this._towerWidth = t),
            (this._tilingSprite = n),
            (this._tilingSprite.name = `Tiling Soil`),
            (this._tilingSprite.y = xh),
            (this._tilingSprite.width = H),
            this.addChild(this._tilingSprite),
            (this._itemsTextures = r),
            this.addSoilItems(),
            (this._firstLevelTextures = i),
            this.addFirstLevelItems();
        }
      });
  }))();
}
var J, Dh, Oh, kh, Ah, jh, Mh, Nh;
function Ph() {
  return (Ph = t(() => {
    (J = e(i())),
      (Dh = e(r())),
      j(),
      W(),
      K(),
      (Oh = 300),
      (kh = 75),
      (Ah = -25),
      (jh = 40),
      (Mh = 120),
      (Nh = class extends D {
        createGradient(e) {
          let t = new E();
          return (
            (t.name = `Gradient`),
            t
              .beginTextureFill({ texture: e })
              .drawRect(0, 0, 250, 500)
              .endFill(),
            t
          );
        }
        createItemSprite() {
          let e = new T((0, Dh.default)(this._itemsTextures));
          return (
            (e.name = `BG Item`),
            e.anchor.set(0.5, 1),
            (e.x = this._towerX),
            (e.y = Ah),
            e
          );
        }
        addItems() {
          let e = this.createItemSprite();
          (e.x += -this._towerWidth / 2 - (0, J.default)(jh, Mh)),
            this.addChild(e);
          let t = this.createItemSprite();
          (t.x += this._towerWidth / 2 + (0, J.default)(jh, Mh)),
            this.addChild(t);
        }
        createPlanet() {
          let e = new T((0, Dh.default)(this._planetsTextures));
          return (
            (e.name = `Planet`),
            e.anchor.set(0.5, 0.5),
            (e.x = (0, J.default)(this._towerX - 300, this._towerX + 300)),
            (e.y = (0, J.default)(-500, -200)),
            e
          );
        }
        addPlanets() {
          let e = this.createPlanet();
          this.addChild(e);
        }
        createStarSprite(e) {
          if (!this._starsTexture) return new T();
          let t = this._towerX - e / 2,
            n = this._towerX + e / 2,
            r = new T(this._starsTexture);
          return (
            (r.name = `Stars`),
            r.anchor.set(0.5, 1),
            (r.x = (0, J.default)(t, n)),
            (r.y = 0),
            r
          );
        }
        updateStars() {
          if (!this._viewportBounds) return;
          let {
            vpWidth: e,
            vpRelativeTop: t,
            vpRelativeBottom: n,
          } = G(this._viewportBounds);
          for (; this._lastStarY > -t; ) {
            let t = this._lastStarY - Oh + (0, J.default)(-75, kh),
              n = this.createStarSprite(e);
            (n.y = t), this._starsContainer.addChild(n), (this._lastStarY = t);
          }
          for (let e = this._starsContainer.children.length - 1; e >= 0; e--) {
            let t = this._starsContainer.children[e];
            t.y * -1.5 < n &&
              (this._starsContainer.removeChild(t), t.destroy());
          }
        }
        updateBackground() {
          if (!this._viewportBounds) return;
          let { left: e } = this._viewportBounds,
            {
              vpWidth: t,
              vpHeight: n,
              vpRelativeBottom: r,
              vpVerticalOffset: i,
              vpRelativeTop: a,
            } = G(this._viewportBounds),
            o = n * 2,
            s = e,
            c = Math.min(r - o + i, -a);
          (this._gradientGraphics.width = t),
            (this._gradientGraphics.height = n * 2),
            (this._gradientGraphics.x = s),
            (this._gradientGraphics.y = c);
        }
        constructor({
          towerX: e,
          towerWidth: t,
          baseTilingSprites: n,
          itemsTextures: r = [],
          gradientTexture: i,
          planetsTextures: a,
          starsTexture: o,
        }) {
          super(),
            (this._lastStarY = -275 + (0, J.default)(-75, kh)),
            (this._baseTilingSprites = []),
            (this._towerX = e),
            (this._towerWidth = t),
            (this._gradientGraphics = this.createGradient(i)),
            this.addChild(this._gradientGraphics),
            (this._starsTexture = o),
            (this._planetsTextures = a),
            this.addPlanets(),
            (this._baseTilingSprites = n),
            this._baseTilingSprites.forEach((e) => {
              (e.width = H), this.addChild(e);
            }),
            (this._itemsTextures = r),
            this.addItems(),
            (this._starsContainer = new D()),
            (this._starsContainer.name = `Stars Container`),
            this.addChild(this._starsContainer);
        }
        update() {}
        set viewportBounds(e) {
          this.destroyed ||
            (this._viewportBounds && th(this._viewportBounds, e)) ||
            ((this._viewportBounds = e),
            this.updateBackground(),
            this.updateStars());
        }
      });
  }))();
}
var Fh, Ih, Lh, Rh, zh, Bh;
function Vh() {
  return (Vh = t(() => {
    (Fh = e(i())),
      (Ih = e(r())),
      j(),
      W(),
      (Lh = (e) => e - 5),
      (Rh = (e) => -e + 10),
      (zh = 20),
      (Bh = class extends D {
        createSoilItemSprite(e) {
          let t = new T(this._itemsTextures[e]);
          return (
            (t.name = `Soil Item`),
            t.anchor.set(0.5, 1),
            (t.x = this._towerX),
            (t.y = Rh(this._towerBottomOffset)),
            t
          );
        }
        createFirstLevelSprite() {
          let e = new T((0, Ih.default)(this._firstLevelTextures));
          return (
            (e.name = `First Level Item`),
            e.anchor.set(0.5, 0.8),
            (e.x = this._towerX),
            (e.scale.x = Math.random() <= 0.5 ? -1 : 1),
            e
          );
        }
        addSoilItems() {
          let e = this.createSoilItemSprite(1);
          (e.x += -this._towerWidth / 2 - zh), this.addChild(e);
          let t = this.createSoilItemSprite(0);
          (t.x += this._towerWidth / 2 + zh), this.addChild(t);
        }
        addFirstLevelItems() {
          let e = this.createFirstLevelSprite();
          (e.x += (0, Fh.default)(-this._towerWidth / 2, this._towerWidth / 2)),
            this.addChild(e);
        }
        addHole(e, t) {
          let n = (0, Fh.default)(this._towerX - 200, this._towerX + 200),
            r = new T(e);
          (r.name = `Hole`),
            r.anchor.set(0.5, 0.5),
            (r.x = n),
            (r.y = -90),
            r.scale.set(1.5),
            this.addChild(r);
          let i = new T(t);
          (i.name = `Hole Light`),
            i.anchor.set(0.5, 0.5),
            (i.x = n),
            (i.y = -90),
            i.scale.set(1.5),
            (i.alpha = 0.85),
            this.addChild(i);
        }
        constructor({
          towerX: e,
          towerWidth: t,
          towerBottomOffset: n,
          tilingSprite: r,
          itemsTextures: i = [],
          firstLevelTextures: a = [],
          backgroundHoleTexture: o,
          backgroundHoleLightTexture: s,
        }) {
          super(),
            (this._towerX = e),
            (this._towerWidth = t),
            (this._towerBottomOffset = n),
            (this._itemsTextures = i),
            this.addSoilItems(),
            (this._tilingSprite = r),
            (this._tilingSprite.name = `Tiling Soil`),
            (this._tilingSprite.y = Lh(this._towerBottomOffset)),
            (this._tilingSprite.width = H),
            this.addChild(this._tilingSprite),
            o && s && this.addHole(o, s),
            (this._firstLevelTextures = a),
            this.addFirstLevelItems();
        }
      });
  }))();
}
var Hh;
function Uh() {
  return (Uh = t(() => {
    j(),
      s(),
      y(),
      x(),
      (Hh = class e extends D {
        static {
          this.dropDuration = 700;
        }
        static {
          this.explosionDuration = 500;
        }
        removeEffects() {
          this._spriteContainer.removeChild(...this._spriteEffects);
        }
        constructor({
          texture: t,
          effectTextureBack: n,
          effectTextureFront: r,
          effectFire: i,
          effectExplode: a,
          gridRow: s,
          gridCol: c,
        }) {
          super(),
            (this._gridRow = s),
            (this._gridCol = c),
            (this._uuid = o()),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Sprites Container`),
            this.addChild(this._spriteContainer),
            (this._sprite = new T(t)),
            (this._sprite.name = `Block Sprite`),
            this._sprite.anchor.set(0.5, 1),
            (this._sprite.x = 75 / 2),
            this._spriteContainer.addChild(this._sprite),
            (this._fallEffectBack = new T(n)),
            (this._fallEffectBack.name = `EffectSpriteBack`),
            this._fallEffectBack.anchor.set(0.5, 1),
            (this._fallEffectFront = new T(r)),
            this._fallEffectFront.anchor.set(0.5, 1),
            (this._fallEffectFront.name = `EffectSpriteFront`),
            (this._fallEffectBack.x = this._fallEffectFront.x = 75 / 2),
            (this._fallEffectBack.alpha = this._fallEffectFront.alpha = 0);
          let l = a.map((t) => ({
            texture: t,
            time: e.explosionDuration / a.length,
          }));
          if (
            ((this._spriteExplosionEffect = new A(l, !1)),
            (this._spriteExplosionEffect.loop = !1),
            (this._spriteExplosionEffect.name = `FloorPlayerNameShadowBg`),
            this._spriteExplosionEffect.anchor.set(0.5, 0.5),
            (this._spriteExplosionEffect.x = 75 / 2),
            (this._spriteEffects = [
              this._fallEffectBack,
              this._fallEffectFront,
            ]),
            this._spriteContainer.addChildAt(this._fallEffectBack, 0),
            this._spriteContainer.addChild(this._fallEffectFront),
            i)
          ) {
            let e = new T(i);
            e.anchor.set(0.5, 1),
              (e.name = `EffectSpriteFire`),
              (e.x = 75 / 2),
              (e.y = 20),
              (e.alpha = 0.75),
              this._spriteEffects.push(e),
              this._spriteContainer.addChild(e);
          }
        }
        get gridRow() {
          return this._gridRow;
        }
        get gridCol() {
          return this._gridCol;
        }
        get uuid() {
          return this._uuid;
        }
        animatePlace(t, n, r, i = e.dropDuration) {
          (this._tween = _({
            from: { v: t, a: 0 },
            to: { v: n, a: 1 },
            duration: i,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e, a: t }) => {
              (this._spriteContainer.y = e),
                (this._fallEffectBack.alpha = this._fallEffectFront.alpha =
                  Math.min(t * 3, 1));
            },
            onFinish: () => {
              this._tween?.destroy(),
                this.removeEffects(),
                r(),
                (this._tween = _({
                  from: { v: 0 },
                  to: { v: 0.5 },
                  duration: 200,
                  easing: (e) => Math.sin(e * Math.PI),
                  onTick: ({ v: e }) => {
                    e !== 0.5 && this._sprite.scale.set(1 + e, 1 - e);
                  },
                  onFinish: () => this._sprite.scale.set(1, 1),
                })),
                this._tween.play();
            },
          })),
            this._tween.play();
        }
        animateFall(t, n, r, i = e.dropDuration) {
          (this._tween = _({
            from: { v: t, a: 0 },
            to: { v: n, a: 1 },
            duration: i,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e, a: t }) => {
              (this._spriteContainer.y = e),
                (this._fallEffectBack.alpha = this._fallEffectFront.alpha =
                  Math.min(t * 3, 1));
            },
            onFinish: () => {
              this._tween?.destroy(), this.removeEffects(), r();
            },
          })),
            this._tween.play();
        }
        animateIncorrect(t, n, r, i = e.dropDuration) {
          (this._tween = _({
            from: { v: t },
            to: { v: n },
            duration: i,
            easing: m.EASE_IN_EXPO,
            onTick: ({ v: e }) => (this._spriteContainer.y = e),
            onFinish: () => {
              this._tween?.destroy(),
                this.removeEffects(),
                (this._tween = _({
                  from: { v: 1 },
                  to: { v: 0 },
                  duration: 300,
                  onTick: ({ v: e }) => {
                    this._spriteContainer.alpha = e;
                  },
                  onFinish: () => {
                    r();
                  },
                })),
                this._tween.play();
            },
          })),
            this._tween.play();
        }
        animateExplosion(t, n, r, i = e.explosionDuration) {
          _({
            from: { y: t },
            to: { y: n },
            duration: i,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ y: e }) => {
              (this._spriteExplosionEffect.y = e),
                (this._spriteContainer.y = e);
            },
            onFinish: () => {
              (this._spriteContainer.alpha = 0),
                this.addChild(this._spriteExplosionEffect),
                this._spriteExplosionEffect.play(),
                setTimeout(() => {
                  r?.(),
                    this.removeChild(this._spriteExplosionEffect),
                    this._spriteExplosionEffect.destroy();
                }, e.explosionDuration);
            },
          }).play();
        }
        update(e) {
          this.destroyed ||
            (this._spriteExplosionEffect &&
              this._spriteExplosionEffect.update(e));
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var Wh;
function Gh() {
  return (Gh = t(() => {
    j(),
      V(),
      (Wh = class extends D {
        get _towerWidth() {
          return this._towerCells * 75;
        }
        constructor({ towerCells: e, neonTexture: t, texture: n }) {
          super(),
            (this._towerCells = e),
            (this._neonTexture = t),
            (this._texture = n);
          let r = new se(this._texture, ...rn);
          if (
            ((r.x = -10),
            (r.name = `BR Top Deco`),
            (r.width = this._towerWidth + 20),
            this.addChild(r),
            this._neonTexture)
          )
            for (let e = 0; e < this._towerCells; e++) {
              if (this._towerCells >= 5 && this._towerCells <= 7 && e % 2 != 0)
                continue;
              let t = new T(this._neonTexture);
              t.anchor.set(0.5, 0.5);
              let n = this._towerCells === 6 ? 75 : 75 / 2;
              (t.x = e * 75 + n),
                (t.y = 3),
                (t.name = `BR Top Deco Neon`),
                (t.height = 7.5),
                this.addChild(t);
            }
        }
      });
  }))();
}
var Kh, qh, Jh;
function Yh() {
  return (Yh = t(() => {
    (Kh = e(r())),
      j(),
      w(),
      V(),
      Gh(),
      (qh = 5),
      (Jh = class extends D {
        get _towerWidth() {
          return this._towerCells * 75;
        }
        addDecorationSprites(e) {
          let t = (t) => {
              let n = new T((0, Kh.default)(this._decoTextures));
              (n.name = `BBR Deco`),
                n.scale.set(1.3, 1.3),
                n.anchor.set(0.5, 0.5),
                (n.x = t),
                (n.y = -150 / 2),
                (n.tint = e),
                this._spriteContainer.addChild(n);
            },
            n = this._towerWidth / 2,
            r = n - 150,
            i = n + 150;
          r >= 75 && t(r), i <= this._towerWidth - 75 && t(i);
        }
        addBlockTopSprites() {
          if (!(!this._topSpritesContainer || !this._blockTopTextures))
            for (let e = 0; e < this._towerCells; e++) {
              if (Math.random() <= 0.5) continue;
              let t = new T((0, Kh.default)(this._blockTopTextures));
              (t.name = `BBR Top Deco ${e}`),
                t.anchor.set(0, 1),
                (t.x = e * 75),
                (t.y = -150),
                this._topSpritesContainer.addChild(t);
            }
        }
        constructor({
          skin: e,
          theme: t,
          towerCells: n,
          texture: r,
          topTexture: i,
          neonTexture: a,
          blockTopTextures: o,
          decoTextures: s,
          doorTexture: c,
          baseTexture: l,
          stairsTexture: u,
        }) {
          super(),
            (this._skin = e),
            (this._theme = t),
            (this._towerCells = n),
            (this._blockTopTextures = o),
            (this._decoTextures = s),
            (this._topSpritesContainer = new D()),
            this.addChild(this._topSpritesContainer),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Main Container`),
            this.addChild(this._spriteContainer),
            (this._sprite = new T(r)),
            (this._sprite.name = `BBR Base`),
            this._sprite.anchor.set(0.5),
            (this._sprite.x = this._towerWidth / 2),
            (this._sprite.y = -150 / 2),
            (this._sprite.tint = C(this._theme, this._skin)),
            this._spriteContainer.addChild(this._sprite);
          let d = p(this._theme, this._skin);
          if ((this.addDecorationSprites(d), this.addBlockTopSprites(), i)) {
            let e = new Wh({ texture: i, neonTexture: a, towerCells: n });
            (e.y = -150), this._spriteContainer.addChild(e);
          }
          if (l) {
            let e = new se(l, ...an);
            (e.x = -15),
              (e.y = -25),
              (e.name = `BBR Base`),
              (e.width = this._towerWidth + 30),
              this._spriteContainer.addChild(e);
          }
          let f = new T(c);
          (f.name = `BBR Door`),
            f.anchor.set(0.5, 1),
            (f.x = this._towerWidth / 2),
            (f.y = -20),
            this._spriteContainer.addChild(f);
          let m = new T(u);
          (m.name = `BBR Stairs`),
            m.anchor.set(0.5, 1),
            (m.x = this._towerWidth / 2 + qh),
            (m.tint = d),
            this._spriteContainer.addChild(m);
        }
        removeTopDecorations() {
          this._topSpritesContainer &&=
            (this.removeChild(this._topSpritesContainer), void 0);
        }
      });
  }))();
}
var Xh, Zh, Qh;
function $h() {
  return ($h = t(() => {
    (Xh = e(i())),
      (Zh = e(r())),
      j(),
      w(),
      x(),
      Gh(),
      (Qh = class extends D {
        get _towerWidth() {
          return this._towerCells * 75;
        }
        addDecorationSprites() {
          let e = Math.floor(this._towerWidth / 75),
            t = (t) => {
              let n = 75 / 2 + t * 75,
                r = t === 0 ? 75 / 2 : t === e - 1 ? -75 / 2 : 0,
                i = (0, Xh.default)(-75 / 5, 75 / 5, !0);
              return n + r + i;
            };
          for (let n = this._gridRow % 2; n < e; n += 2) {
            let e = new T((0, Zh.default)(this._decoTextures));
            (e.name = `BR Deco ${n}`),
              e.anchor.set(0.5, 0.5),
              (e.x = t(n)),
              (e.y = -75 / 2),
              (e.tint = p(this._theme, this._skin)),
              this._spriteContainer.addChild(e);
          }
        }
        addBlockTopSprites() {
          if (!(!this._topSpritesContainer || !this._blockTopTextures))
            for (let e = 0; e < this._towerCells; e++) {
              if (Math.random() <= 0.5) continue;
              let t = new T((0, Zh.default)(this._blockTopTextures));
              (t.name = `BR Top Deco ${e}`),
                t.anchor.set(0, 1),
                (t.x = e * 75),
                (t.y = -75),
                this._topSpritesContainer.addChild(t);
            }
        }
        constructor({
          skin: e,
          theme: t,
          gridRow: n,
          towerCells: r,
          texture: i,
          topTexture: a,
          blockTopTextures: o,
          decoTextures: s,
          neonTexture: c,
        }) {
          if (
            (super(),
            (this._skin = e),
            (this._theme = t),
            (this._gridRow = n),
            (this._towerCells = r),
            (this._blockTopTextures = o),
            (this._decoTextures = s),
            (this._topSpritesContainer = new D()),
            this.addChild(this._topSpritesContainer),
            (this._spriteContainer = new D()),
            this.addChild(this._spriteContainer),
            (this._sprite = new T(i)),
            this._sprite.anchor.set(0.5),
            (this._sprite.x = this._towerWidth / 2),
            (this._sprite.y = -75 / 2),
            (this._sprite.tint = C(this._theme, this._skin)),
            this._spriteContainer.addChild(this._sprite),
            this.addBlockTopSprites(),
            a)
          ) {
            let e = new Wh({ texture: a, neonTexture: c, towerCells: r });
            (e.y = -75), this._spriteContainer.addChild(e);
          }
          this.addDecorationSprites(),
            (this._perfectEffect = new E()),
            (this._perfectEffect.name = `Debug`),
            this._perfectEffect.beginFill(16777215),
            this._perfectEffect.drawRoundedRect(
              0,
              -75,
              this._towerWidth,
              75,
              5
            ),
            this._perfectEffect.endFill(),
            (this._perfectEffect.alpha = 0),
            this._spriteContainer.addChild(this._perfectEffect);
        }
        animate(e) {
          (this._tween = _({
            from: { v: 0 },
            to: { v: 1 },
            duration: 800,
            easing: (e) => -4 * e ** 2 + 4 * e,
            onTick: ({ v: e }) => {
              e !== 1 && (this._perfectEffect.alpha = e);
            },
            onFinish: () => {
              (this._perfectEffect.alpha = 0), e?.();
            },
          })),
            this._tween.play();
        }
        update() {
          this.destroyed;
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var eg;
function tg() {
  return (tg = t(() => {
    j(),
      be(),
      (eg = class extends D {
        constructor({
          bonusArrowTextures: e,
          bonusFrameTexture: t,
          bonusSunTextures: n,
          gridRow: r,
          gridCol: i,
          length: a,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._bonusArrowSprites = []),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Bg Sprites Container`),
            this.addChild(this._spriteContainer);
          let o = e.map((e) => ({ texture: e, time: 50 }));
          for (let e = 0; e < a - 1; e++) {
            let t = new A(o, !1);
            (t.name = `Bonus Bg Arrow Sprite`),
              (t.loop = !1),
              (t.x = 75 / 2),
              (t.y = -e * 75),
              t.anchor.set(0.5, 0),
              this._bonusArrowSprites.push(t);
          }
          for (let e = 0; e < this._bonusArrowSprites.length; e++) {
            let t = e === this._bonusArrowSprites.length - 1 ? 0 : e + 1;
            this._bonusArrowSprites[e].onComplete = () => {
              this._bonusArrowSprites[e].gotoAndStop(0),
                this._bonusArrowSprites[t].play();
            };
          }
          this._bonusArrowSprites[0].play(),
            (this.x = i * 75),
            (this.y = (150 + r * 75 - 35) * -1);
          let s = new T(t);
          (s.name = `Bonus Bg Frame Sprite`),
            s.anchor.set(0.5, 0),
            s.scale.set(1.4, 1.4),
            (s.x = 75 / 2),
            (s.y = -(a - 1) * 75 - 20);
          let c = n.map((e) => ({ texture: e, time: 150 })),
            l = new A(c, !1);
          (l.name = `Bonus Bg Sun Sprite`),
            (l.loop = !0),
            l.play(),
            l.anchor.set(0.5, 0),
            (l.x = 75 / 2),
            (l.y = -a * 75 - 35),
            this._spriteEffects.push(l);
          let u = xe(
              [
                [`transparent`, 0],
                [`#51F0AD`, 0.5],
              ],
              1,
              640,
              `vertical`
            ),
            d = new E()
              .beginTextureFill({ texture: u, alpha: 0.75 })
              .drawRect(0, 0, 75, 640)
              .endFill();
          (d.x = 0),
            d.pivot.set(0, 520),
            this._spriteContainer.addChild(
              d,
              ...this._bonusArrowSprites,
              ...this._spriteEffects,
              s
            );
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._bonusArrowSprites) t.update(e);
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          super.destroy();
        }
      });
  }))();
}
var ng;
function rg() {
  return (rg = t(() => {
    j(),
      y(),
      x(),
      (ng = class extends D {
        constructor({
          bonusMonsterTextures: e,
          gridRow: t,
          gridCol: n,
          length: r,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Sprites Container`),
            this.addChild(this._spriteContainer),
            (this.x = n * 75),
            (this.y = (150 + t * 75 - 35) * -1);
          let i = e.map((e) => ({ texture: e, time: 150 }));
          (this._bonusMonsterSprite = new A(i, !1)),
            (this._bonusMonsterSprite.name = `Bonus Monster Sprite`),
            (this._bonusMonsterSprite.loop = !0),
            this._bonusMonsterSprite.play(),
            this._bonusMonsterSprite.anchor.set(0.5, 0.5),
            this._bonusMonsterSprite.scale.set(1.4, 1.4),
            (this._bonusMonsterSprite.x = 75 / 2),
            (this._bonusMonsterSprite.y =
              -(r - 1) * 75 - 20 + this._bonusMonsterSprite.height / 2),
            this._spriteContainer.addChild(this._bonusMonsterSprite),
            this._spriteEffects.push(this._bonusMonsterSprite);
        }
        animateDisappear(e) {
          (this._tween = _({
            from: { v: 1.4 },
            to: { v: 4 },
            duration: 1500,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e }) => this._bonusMonsterSprite.scale.set(e, e),
            onFinish: () => {
              this._tween?.destroy(), e?.();
            },
          })),
            this._tween.play();
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var ig;
function ag() {
  return (ag = t(() => {
    j(),
      y(),
      x(),
      (ig = class extends D {
        constructor({
          starTexture: e,
          textures: t,
          stompDustTextures: n,
          stageWidth: r,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._stompDustSprites = []),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Sprites Container`),
            this.addChild(this._spriteContainer);
          let i = t.map((e) => ({ texture: e, time: 150 }));
          (this._gorillaSprite = new A(i, !1)),
            (this._gorillaSprite.name = `Bonus Arrow Sprite`),
            (this._gorillaSprite.loop = !0),
            this._gorillaSprite.play(),
            this._gorillaSprite.anchor.set(0.5, 0.5),
            this._gorillaSprite.scale.set(1.25, 1.25),
            this._spriteEffects.push(this._gorillaSprite);
          let a = new T(e);
          (a.name = `Star Sprite`),
            (a.y = 50),
            a.anchor.set(0.5, 0.5),
            a.scale.set(0.6, 0.6);
          let o = n.map((e) => ({ texture: e, time: 35 })),
            s = new A(o, !1);
          (s.name = `Stomp Dust Sprite`),
            (s.loop = !1),
            (s.x = -230),
            (s.y = 150),
            s.scale.set(1.4, 1.4),
            (s.alpha = 0),
            (s.onComplete = () => {
              (s.alpha = 0), s.gotoAndStop(0);
            });
          let c = new A(o, !1);
          (c.name = `Stomp Dust Sprite`),
            (c.loop = !1),
            (c.x = 75),
            (c.y = 150),
            (c.alpha = 0),
            c.scale.set(-1.4, 1.4),
            c.anchor.set(1, 0),
            (c.onComplete = () => {
              (c.alpha = 0), c.gotoAndStop(0);
            }),
            (this._gorillaSprite.onFrameChange = (e) => {
              e === 7
                ? ((s.alpha = 1), s.play())
                : e === 3 && ((c.alpha = 1), c.play());
            }),
            this._stompDustSprites.push(s, c),
            this._spriteContainer.addChild(
              a,
              ...this._spriteEffects,
              ...this._stompDustSprites
            );
          let l = Math.min(r / a.getBounds().width, 1);
          this._spriteContainer.scale.set(l, l);
        }
        animateMovement(e, t, n = 0, r) {
          (this._tween = _({
            from: { v: e },
            to: { v: t },
            duration: 1500,
            delay: n,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e }) => (this._spriteContainer.y = e),
            onFinish: () => {
              this._tween?.destroy(), r?.();
            },
          })),
            this._tween.play();
        }
        bump(e) {
          this._tween?.isPlaying ||
            ((this._tween = _({
              from: { v: 1 },
              to: { v: 1.2 },
              duration: 100,
              easing: m.EASE_IN_CUBIC,
              onTick: ({ v: e }) => {
                this._gorillaSprite.scale.set(e, e);
              },
              onFinish: () => {
                if (!this._tween) return;
                let { from: t, to: n } = this._tween.configValues ?? {};
                n.v === 1
                  ? (this._tween?.destroy(), e())
                  : (this._tween.update({ to: t, from: n }),
                    this._tween.play());
              },
            })),
            this._tween.play());
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._stompDustSprites) t.update(e);
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var Y, og;
function sg() {
  return (sg = t(() => {
    (Y = e(r())),
      j(),
      ne(),
      w(),
      x(),
      K(),
      (og = class extends D {
        constructor({
          skin: e,
          theme: t,
          playerName: n,
          gridRow: r,
          rowWidth: i,
          rowCells: a,
          variant: o = `regular`,
          floorPlayerNameTextures: s,
          floorPlayerNameXRayTextures: c,
          floorPlayerNameShadowTextures: l,
          floorPlayerNameShadowXRayTextures: u,
          floorNumberTextures: d,
          floorNumberXRayTextures: f,
          floorNumberShadowTextures: p,
          floorNumberShadowXRayTextures: m,
          floorPoint: h,
          floorPointShadow: g,
          floorPointIndicator: _,
          viewportBounds: v,
        }) {
          super(),
            (this._effectsSprites = []),
            (this._skin = e),
            (this._theme = t),
            (this._playerName = n),
            (this._gridRow = r),
            (this._rowWidth = i),
            (this._rowCells = a),
            (this._viewportBounds = v),
            (this._floorPlayerNameTextures = s),
            (this._floorPlayerNameXRayTextures = c),
            (this._floorPlayerNameShadowTextures = l),
            (this._floorPlayerNameShadowXRayTextures = u),
            (this._floorNumberTextures = d),
            (this._floorNumberXRayTextures = f),
            (this._floorNumberShadowTextures = p),
            (this._floorNumberShadowXRayTextures = m),
            (this._floorPoint = h),
            (this._floorPointShadow = g),
            (this._floorPointIndicator = _),
            (this.y = -150),
            o === `solo` && this.addFloorIndicator(),
            o === `regular` &&
              (this.addFloorPlayerName(),
              this.addFloorPoints(),
              this.addFloorIndicator()),
            o === `little-time-left` &&
              (this.addFloorPlayerName(), this.addFloorPoints()),
            o === `podium` && this.addEndOfGameFloorIndicator();
        }
        get relativeY() {
          return -this._gridRow * 75;
        }
        formatGridRow(e) {
          return e < 10 ? `0${e}` : `${e}`;
        }
        getContainerOffsetX() {
          let e = this._viewportBounds.right - this._viewportBounds.left,
            t = (this._rowCells - 4) * 75;
          return nh(t) + 75 < e ? 75 : 0;
        }
        getPlayerNameContainerInitialFinalX() {
          let e = 262.5 - this.getContainerOffsetX();
          return [e, e - 75];
        }
        getFloorNumberContainerInitialFinalX() {
          let e =
            (this._rowCells - 2) * 75 - 187.5 / 2 + this.getContainerOffsetX();
          return [e, e + 75];
        }
        addFloorPlayerName() {
          let e = (0, Y.default)(this._floorPlayerNameXRayTextures),
            t = new T(e);
          (t.name = `FloorPlayerNameXRay`), t.anchor.set(0.5, 0.5);
          let n = (0, Y.default)(this._floorPlayerNameShadowXRayTextures),
            r = new T(n);
          (r.name = `FloorPlayerNameShadowXRay`), r.anchor.set(0.5, 0.5);
          let i = this._floorPlayerNameTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            a = new A(i, !1);
          (a.name = `FloorPlayerNameBg`),
            (a.loop = !0),
            a.play(),
            a.anchor.set(0.5, 0.5),
            (a.tint = C(this._theme, this._skin));
          let o = this._floorPlayerNameShadowTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            s = new A(o, !1);
          (s.name = `FloorPlayerNameShadowBg`),
            (s.loop = !0),
            s.play(),
            s.anchor.set(0.5, 0.5);
          let c = new k({
              fontFamily: `'Slackey', ${S.primaryFamily}`,
              fontSize: 26,
              fontWeight: `700`,
              fill: `white`,
            }),
            { width: l, height: u } = oe.measureText(this._playerName, c),
            d = a.width / -2 + 25,
            f = u / -2 + 5,
            p = new E();
          p.beginFill(16777215).drawRect(0, 0, 150, 75).endFill(),
            (p.x = d),
            (p.y = f - 75 / 2);
          let m = new O(this._playerName, c);
          m.anchor.set(0, 0.5), (m.x = d), (m.y = f), (m.mask = p);
          let [h, g] = this.getPlayerNameContainerInitialFinalX();
          if (
            ((this._playerNameContainer = new D()),
            (this._playerNameContainer.name = `FloorPlayerName`),
            (this._playerNameContainer.x = h),
            (this._playerNameContainer.y = this.relativeY - 30),
            (this._playerNameContainer.zIndex = 20),
            this._playerNameContainer.addChild(s, a, m, p),
            l > 150)
          ) {
            let e = new O(`…`, c);
            e.anchor.set(0, 0.5),
              (e.x = d + 150),
              (e.y = f),
              this._playerNameContainer.addChild(e);
          }
          this._playerNameContainer.addChild(r, t),
            this.addChild(this._playerNameContainer);
          let v = _({
            from: { v: 1 },
            to: { v: 0 },
            duration: 500,
            onTick: ({ v: e }) => {
              let n = (g - h) * (1 - e);
              (this._playerNameContainer.x = h + n),
                e <= 0.5 && ((r.alpha = e * 2), (t.alpha = e * 2));
            },
            onFinish: () => {
              v?.destroy(), this._effectsSprites.push(s, a);
            },
          });
          v.play();
        }
        addFloorPoints() {
          let e = (0, Y.default)(this._floorPoint),
            t = new T(e);
          (t.name = `PlusOne`),
            (t.alpha = 1),
            t.anchor.set(1, 1),
            (t.tint = C(this._theme, this._skin));
          let n = (0, Y.default)(this._floorPointShadow),
            r = new T(n);
          (r.name = `PlusOneShadow`), (r.alpha = 0), r.anchor.set(1, 1);
          let i = (0, Y.default)(this._floorPointIndicator),
            a = new T(i);
          (a.name = `PlusOneIndicator`),
            (a.alpha = 0),
            a.anchor.set(1, 1),
            (this._floorPointsContainer = new D()),
            (this._floorPointsContainer.name = `OnePointIndicator`),
            (this._floorPointsContainer.x =
              this._rowWidth / 2 + t.width / 2 + 50),
            (this._floorPointsContainer.y = this.relativeY + 75 / 2 - 30),
            this._floorPointsContainer.addChild(r, t, a),
            this.addChild(this._floorPointsContainer);
          let o = _({
            from: { v: 0 },
            to: { v: 1 },
            duration: 1250,
            onTick: ({ v: e }) => {
              this._floorPointsContainer.y =
                this._floorPointsContainer.y - e * 3;
              let n = e * 2;
              n < 1
                ? ((r.alpha = n), (t.alpha = n), (a.alpha = n))
                : ((t.alpha = 2 - n), (r.alpha = 2 - n), (a.alpha = 2 - n));
            },
            onFinish: () => {
              o?.destroy();
            },
          });
          o.play();
        }
        addFloorIndicator() {
          let e = (0, Y.default)(this._floorNumberXRayTextures),
            t = new T(e);
          (t.name = `FloorNumberXRay`), t.anchor.set(0.5, 0.5);
          let n = (0, Y.default)(this._floorNumberShadowXRayTextures),
            r = new T(n);
          (r.name = `FloorNumberShadowXRay`), r.anchor.set(0.5, 0.5);
          let i = this._floorNumberTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            a = new A(i, !1);
          (a.name = `FloorNumberBg`),
            (a.loop = !0),
            a.play(),
            a.anchor.set(0.5, 0.5),
            (a.tint = C(this._theme, this._skin));
          let o = this._floorNumberShadowTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            s = new A(o, !1);
          (s.name = `FloorNumberShadowBg`),
            (s.loop = !0),
            s.play(),
            s.anchor.set(0.5, 0.5);
          let c = new k({
              fontFamily: `'Slackey', ${S.primaryFamily}`,
              fontSize: 72,
              fontWeight: `700`,
              fill: `white`,
            }),
            l = this.formatGridRow(this._gridRow + 1),
            u = new O(l, c);
          u.anchor.set(0.5, 0.5), (u.x = 15), (u.y = 2);
          let [d, f] = this.getFloorNumberContainerInitialFinalX();
          (this._floorNumberContainer = new D()),
            (this._floorNumberContainer.name = `FloorNumber`),
            (this._floorNumberContainer.x = d),
            (this._floorNumberContainer.y = this.relativeY - 75 + 20),
            this._floorNumberContainer.addChild(s, a, u, r, t),
            this.addChild(this._floorNumberContainer);
          let p = _({
            from: { v: 1 },
            to: { v: 0 },
            duration: 500,
            onTick: ({ v: e }) => {
              let n = (f - d) * (1 - e);
              (this._floorNumberContainer.x = d + n),
                e <= 0.5 && ((r.alpha = e * 2), (t.alpha = e * 2));
            },
            onFinish: () => {
              p?.destroy(), this._effectsSprites.push(s, a);
            },
          });
          p.play();
        }
        addEndOfGameFloorIndicator() {
          let e = this._floorNumberTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            t = new A(e, !1);
          (t.name = `EndOfGameFloorNumberBg`),
            (t.loop = !0),
            t.play(),
            t.anchor.set(0.5, 0.5),
            (t.tint = C(this._theme, this._skin));
          let n = this._floorNumberShadowTextures.map((e) => ({
              texture: e,
              time: 150,
            })),
            r = new A(n, !1);
          (r.name = `EndOfGameFloorNumberShadowBg`),
            (r.loop = !0),
            r.play(),
            r.anchor.set(0.5, 0.5);
          let i = new k({
              fontFamily: `'Slackey', ${S.primaryFamily}`,
              fontSize: 72,
              fontWeight: `700`,
              fill: `white`,
            }),
            a = this.formatGridRow(this._gridRow + 1),
            o = new O(a, i);
          o.anchor.set(0.5, 0.5),
            (o.x = 15),
            (o.y = 2),
            (this._floorNumberContainer = new D()),
            (this._floorNumberContainer.name = `EndOfGameFloorNumber`),
            (this._floorNumberContainer.x =
              t.width / 2 + (this._rowCells - 3.75) * 75),
            (this._floorNumberContainer.y = this.relativeY - 75 + 20),
            this._floorNumberContainer.addChild(r, t, o),
            this.addChild(this._floorNumberContainer),
            _({
              from: { v: 0 },
              to: { v: 0.5 },
              duration: 200,
              easing: (e) => Math.sin(e * Math.PI),
              onTick: ({ v: e }) => {
                e !== 0.5 && this._floorNumberContainer.scale.set(1 + e, 1 - e);
              },
              onFinish: () => this._floorNumberContainer.scale.set(1, 1),
            }).play();
        }
        set viewportBounds(e) {
          this._viewportBounds = e;
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._effectsSprites) t.update(e);
            for (let e = this._effectsSprites.length - 1; e >= 0; e--) {
              let t = this._effectsSprites[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._effectsSprites.splice(e, 1));
            }
          }
        }
        destroy() {
          super.destroy();
        }
      });
  }))();
}
var cg, lg;
function ug() {
  return (ug = t(() => {
    j(),
      y(),
      x(),
      (cg = 750),
      (lg = class extends D {
        constructor({
          bonusGiftTexture: e,
          effectExplode: t,
          gridRow: n,
          gridCol: r,
          length: i,
        }) {
          if (!e)
            throw Error(`No gift box texture provided to GiftBonus class`);
          super(),
            (this._startExplosionTimeout = -1),
            (this._repeatAnimationTimeout = -1),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Sprites Container`),
            this.addChild(this._spriteContainer),
            (this.x = r * 75),
            (this.y = (150 + n * 75 - 35) * -1),
            (this._bonusGiftSprite = new T(e)),
            (this._bonusGiftSprite.name = `Bonus Gift Box Sprite`),
            this._bonusGiftSprite.anchor.set(0.5, 0.5),
            this._bonusGiftSprite.scale.set(0.5, 0.5),
            (this._bonusGiftSprite.x = 75 / 2),
            (this._bonusGiftSprite.y = -(i - 1) * 75 + 55);
          let a = t.map((e) => ({ texture: e, time: cg / t.length }));
          (this._explosionSprite = new A(a, !1)),
            (this._explosionSprite.loop = !1),
            (this._explosionSprite.name = `Bonus Gift Explosion Sprite`),
            this._explosionSprite.anchor.set(0.5, 0.5),
            this._explosionSprite.pivot.set(0, -75),
            (this._explosionSprite.x = 75 / 2),
            (this._explosionSprite.y = -(i - 1) * 75 - 20),
            this._spriteContainer.addChild(this._bonusGiftSprite),
            this.animate();
        }
        animate() {
          let e = 0;
          this._shakeTween = _({
            duration: 75,
            from: { v: -2 },
            to: { v: 2 },
            onPlay: () => {
              this._bonusGiftSprite.angle = -2;
            },
            onTick: ({ v: e }) => {
              this._bonusGiftSprite.angle = e;
            },
            onFinish: () => {
              if (!this._shakeTween || e > 3) return;
              let { from: t, to: n } = this._shakeTween.configValues ?? {};
              this._shakeTween.update({ to: t, from: n }),
                this._shakeTween.play(),
                e++;
            },
          });
          let t = this._bonusGiftSprite.y,
            n = t - 5;
          (this._bumpTween = _({
            from: { v: t },
            to: { v: n },
            duration: 200,
            easing: m.LINEAR,
            onPlay: ({ v: n }) => {
              n === t && ((e = 0), this._shakeTween?.play());
            },
            onTick: ({ v: e }) => {
              this._bonusGiftSprite.position.set(this._bonusGiftSprite.x, e);
            },
            onFinish: () => {
              if (!this._bumpTween) return;
              let { from: e, to: t } = this._bumpTween.configValues ?? {};
              t.v === n
                ? (this._bumpTween.update({ to: e, from: t }),
                  this._bumpTween?.play())
                : ((this._bonusGiftSprite.angle = 0),
                  clearTimeout(this._repeatAnimationTimeout),
                  (this._repeatAnimationTimeout = window.setTimeout(() => {
                    this._bumpTween &&
                      (this._bumpTween.update({ to: e, from: t }),
                      this._bumpTween?.play());
                  }, 750)));
            },
          })),
            this._bumpTween.play();
        }
        animateDisappear(e) {
          clearTimeout(this._repeatAnimationTimeout),
            this._shakeTween?.destroy(),
            this._bumpTween?.destroy(),
            (this._shakeTween = _({
              duration: 50,
              from: { v: -10 },
              to: { v: 10 },
              onPlay: () => {
                this._bonusGiftSprite.angle = -10;
              },
              onTick: ({ v: e }) => {
                this._bonusGiftSprite.angle = e;
              },
              onFinish: () => {
                if (!this._shakeTween) return;
                let { from: e, to: t } = this._shakeTween.configValues ?? {};
                this._shakeTween.update({ to: e, from: t }),
                  this._shakeTween.play();
              },
            })),
            (this._bumpTween = _({
              from: { v: 0.5 },
              to: { v: 0.8 },
              duration: cg,
              easing: m.LINEAR,
              onTick: ({ v: e }) => {
                this._bonusGiftSprite.scale.set(e, e);
              },
              onFinish: () => {
                this._bumpTween?.destroy();
              },
            })),
            (this._tween = _({
              from: { v: 1 },
              to: { v: 0 },
              duration: cg,
              easing: m.EASE_OUT_CUBIC,
              onPlay: () => {
                this._spriteContainer.addChild(this._explosionSprite),
                  this._explosionSprite.play();
              },
              onTick: ({ v: e }) => {
                this._bonusGiftSprite.alpha = e;
              },
              onFinish: () => {
                this._spriteContainer.removeChild(this._explosionSprite),
                  this._explosionSprite.destroy(),
                  this._shakeTween?.destroy(),
                  this._bumpTween?.destroy(),
                  this._tween?.destroy(),
                  e?.();
              },
            })),
            this._shakeTween.play(),
            this._bumpTween.play(),
            (this._startExplosionTimeout = window.setTimeout(() => {
              this._tween?.play();
            }, 650));
        }
        update(e) {
          this.destroyed ||
            (this._explosionSprite && this._explosionSprite.update(e));
        }
        destroy() {
          clearTimeout(this._repeatAnimationTimeout),
            clearTimeout(this._startExplosionTimeout),
            this._shakeTween?.destroy(),
            this._bumpTween?.destroy(),
            this._tween?.destroy(),
            super.destroy();
        }
      });
  }))();
}
var dg, fg, pg, X, mg, Z, hg, gg, _g;
function vg() {
  return (vg = t(() => {
    j(),
      f(),
      y(),
      x(),
      (dg = 25),
      (fg = -2),
      (pg = 4),
      (X = 10),
      (mg = 4),
      (Z = 15),
      (hg = 4205956),
      (gg = 16711680),
      (_g = class extends D {
        constructor({ name: e, type: t, position: n, onCompleted: r }) {
          super(),
            (this._type = t),
            (this._onCompletedCallback = r),
            (this._labelContainer = this.getLabel(e, t, n)),
            this.addChild(this._labelContainer),
            this.animate();
        }
        getBGColor(e) {
          return e === `correct` ? hg : gg;
        }
        getTextStyle() {
          return new k({
            fontFamily: `Montserrat`,
            fontSize: dg,
            fontWeight: `700`,
            fill: `white`,
          });
        }
        getLabelOffset(e, t, n) {
          let r = 11.5;
          return n === `top`
            ? [-e / 2, r]
            : n === `top-right`
            ? [-e + X, r]
            : n === `top-left`
            ? [-10, r]
            : n === `bottom`
            ? [-e / 2, -(t + r)]
            : n === `bottom-right`
            ? [-e + X, -(t + r)]
            : n === `bottom-left`
            ? [-10, -(t + r)]
            : n === `left`
            ? [-(e + X + Z / 2), -t / 2]
            : n === `right`
            ? [17.5, -t / 2]
            : [0, 0];
        }
        getLabelArrow(e, t, n, r) {
          let i = new E().beginFill(e).lineStyle(0, e),
            a = (e) => {
              let t = e === `up` ? -1 : 1;
              i.moveTo(Z, 0)
                .lineTo(Z / 2, (t * Z) / 2)
                .lineTo(0, 0)
                .lineTo(Z, 0);
            },
            o = (e) => {
              let t = e === `right` ? -1 : 1;
              i.moveTo(0, Z)
                .lineTo((t * Z) / 2, Z / 2)
                .lineTo(0, 0)
                .lineTo(0, Z);
            };
          switch (r) {
            case `top`:
              (i.x = (t - Z) / 2), (i.y = -4), a(`up`);
              break;
            case `top-right`:
              (i.x = t - X - Z / 2), (i.y = -4), a(`up`);
              break;
            case `top-left`:
              (i.x = X - Z / 2), (i.y = -4), a(`up`);
              break;
            case `bottom`:
              (i.x = (t - Z) / 2), (i.y = n + mg), a(`down`);
              break;
            case `bottom-right`:
              (i.x = t - X - Z / 2), (i.y = n + mg), a(`down`);
              break;
            case `bottom-left`:
              (i.x = X - Z / 2), (i.y = n + mg), a(`down`);
              break;
            case `left`:
              (i.x = t + X), (i.y = (n - Z) / 2), o(`left`);
              break;
            case `right`:
              (i.x = -10), (i.y = (n - Z) / 2), o(`right`);
          }
          return i.endFill(), i;
        }
        getLabel(e, t, n) {
          let r = this.getBGColor(t),
            i = this.getTextStyle(),
            { width: a, height: o } = oe.measureText(e, i),
            s = new E()
              .beginFill(r)
              .drawRoundedRect(-10, -4, a + 20, o + 8, pg),
            c = this.getLabelArrow(r, a, o, n),
            l = new O(e, i);
          (l.resolution = 4), (l.y = fg);
          let [u, d] = this.getLabelOffset(a, o, n);
          (s.x += u),
            (s.y += d),
            (c.x += u),
            (c.y += d),
            (l.x += u),
            (l.y += d);
          let f = new T();
          return f.addChild(s), f.addChild(c), f.addChild(l), f;
        }
        animate() {
          (this._tweenShow = _({
            from: { scale: 0 },
            to: { scale: 1 },
            duration: 700,
            delay: this._type === `correct` ? 700 : 0,
            easing: m.BOUNCE_PAST,
            onTick: ({ scale: e }) => this._labelContainer.scale.set(e, e),
            onFinish: () => this._tweenHide?.play(),
          })),
            (this._tweenHide = _({
              from: { alpha: 1 },
              to: { alpha: 0 },
              delay: 700,
              duration: 500,
              easing: m.EASE_IN_SINE,
              onTick: ({ alpha: e }) => (this._labelContainer.alpha = e),
              onFinish: () => {
                this._onCompletedCallback?.(this);
              },
            })),
            this._tweenShow.play();
        }
        destroy() {
          this._tweenShow?.destroy(),
            this._tweenHide?.destroy(),
            super.destroy();
        }
      });
  }))();
}
var yg;
function bg() {
  return (bg = t(() => {
    j(),
      y(),
      x(),
      (yg = class extends D {
        constructor({
          bonusMonsterTextures: e,
          gridRow: t,
          gridCol: n,
          length: r,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Sprites Container`),
            this.addChild(this._spriteContainer),
            (this.x = n * 75),
            (this.y = (150 + t * 75 - 35) * -1);
          let i = e.map((e) => ({ texture: e, time: 100 }));
          (this._bonusMonsterSprite = new A(i, !1)),
            (this._bonusMonsterSprite.name = `Bonus Monster Head Sprite`),
            (this._bonusMonsterSprite.loop = !0),
            this._bonusMonsterSprite.play(),
            this._bonusMonsterSprite.anchor.set(0.5, 0.5),
            this._bonusMonsterSprite.scale.set(1.4, 1.4),
            (this._bonusMonsterSprite.x = 75 / 2),
            (this._bonusMonsterSprite.y =
              -(r - 1) * 75 - 50 + this._bonusMonsterSprite.height / 2),
            this._spriteContainer.addChild(this._bonusMonsterSprite),
            this._spriteEffects.push(this._bonusMonsterSprite);
        }
        animateDisappear(e) {
          (this._tween = _({
            from: { v: 1.4 },
            to: { v: 4 },
            duration: 1500,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e }) => this._bonusMonsterSprite.scale.set(e, e),
            onFinish: () => {
              this._tween?.destroy(), e?.();
            },
          })),
            this._tween.play();
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var xg;
function Sg() {
  return (Sg = t(() => {
    j(),
      y(),
      x(),
      (xg = class extends D {
        constructor({
          textures: e,
          stompDustTextures: t,
          flamesTextures: n,
          stageWidth: r,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._stompDustSprites = []),
            (this._spriteContainer = new D()),
            (this._spriteContainer.name = `Bonus Sprites Container`),
            this.addChild(this._spriteContainer);
          let i = e.map((e) => ({ texture: e, time: 150 }));
          (this._gorillaSprite = new A(i, !1)),
            (this._gorillaSprite.name = `Bonus Arrow Sprite`),
            (this._gorillaSprite.loop = !0),
            this._gorillaSprite.play(),
            this._gorillaSprite.anchor.set(0.5, 0.5),
            this._gorillaSprite.scale.set(1.25, 1.25),
            this._spriteEffects.push(this._gorillaSprite),
            (this._gorillaSprite.onFrameChange = (e) => {
              e === 7
                ? ((o.alpha = 1), o.play())
                : e === 3 && ((s.alpha = 1), s.play());
            });
          let a = t.map((e) => ({ texture: e, time: 35 })),
            o = new A(a, !1);
          (o.name = `Stomp Dust Sprite`),
            (o.loop = !1),
            (o.x = -230),
            (o.y = 150),
            o.scale.set(1.4, 1.4),
            (o.alpha = 0),
            (o.onComplete = () => {
              (o.alpha = 0), o.gotoAndStop(0);
            });
          let s = new A(a, !1);
          if (
            ((s.name = `Stomp Dust Sprite`),
            (s.loop = !1),
            (s.x = 75),
            (s.y = 150),
            (s.alpha = 0),
            s.scale.set(-1.4, 1.4),
            s.anchor.set(1, 0),
            (s.onComplete = () => {
              (s.alpha = 0), s.gotoAndStop(0);
            }),
            this._stompDustSprites.push(o, s),
            n)
          ) {
            let e = n.map((e) => ({ texture: e, time: 100 })),
              t = new A(e, !1);
            (t.name = `Flames Sprite`),
              (t.loop = !0),
              t.play(),
              t.anchor.set(0.5, 0.5),
              (t.alpha = 0.35),
              (t.x = -25),
              (t.y = -75),
              (this._flames = t),
              this._spriteContainer.addChild(this._flames);
          }
          this._spriteContainer.addChild(
            ...this._spriteEffects,
            ...this._stompDustSprites
          );
          let c = Math.min(r / this._gorillaSprite.getBounds().width + 200, 1);
          this._spriteContainer.scale.set(c, c);
        }
        animateMovement(e, t, n = 0, r) {
          (this._tween = _({
            from: { v: e },
            to: { v: t },
            duration: 1500,
            delay: n,
            easing: m.EASE_IN_CUBIC,
            onTick: ({ v: e }) => (this._spriteContainer.y = e),
            onFinish: () => {
              this._tween?.destroy(), r?.();
            },
          })),
            this._tween.play();
        }
        bump(e) {
          this._tween?.isPlaying ||
            ((this._tween = _({
              from: { v: 1 },
              to: { v: 1.2 },
              duration: 100,
              easing: m.EASE_IN_CUBIC,
              onTick: ({ v: e }) => {
                this._gorillaSprite.scale.set(e, e);
              },
              onFinish: () => {
                if (!this._tween) return;
                let { from: t, to: n } = this._tween.configValues ?? {};
                n.v === 1
                  ? (this._tween?.destroy(), e())
                  : (this._tween.update({ to: t, from: n }),
                    this._tween.play());
              },
            })),
            this._tween.play());
        }
        update(e) {
          if (!this.destroyed) {
            this._flames && this._flames.update(e);
            for (let t of this._stompDustSprites) t.update(e);
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          this._tween?.destroy(), super.destroy();
        }
      });
  }))();
}
var Cg, wg;
function Tg() {
  return (Tg = t(() => {
    (Cg = e(r())),
      j(),
      l(),
      be(),
      W(),
      Yh(),
      Uh(),
      $h(),
      tg(),
      rg(),
      ag(),
      sg(),
      ug(),
      vg(),
      bg(),
      Sg(),
      (wg = class {
        constructor({
          blockTextures: e,
          blockTopTextures: t,
          blockTopNeonTexture: n,
          blockFallEffectBack: r,
          blockFallEffectFront: i,
          blockFireEffect: a,
          baseFloorTextures: o,
          baseFloorDoorTexture: s,
          baseFloorBaseTexture: c,
          baseFloorStairsTexture: l,
          floorTextures: u,
          floorTopTexture: d,
          floorDecoTextures: f,
          dustTextures: p,
          dustExplosionTextures: m,
          floorRayTextures: h,
          floorPlayerNameTextures: g,
          floorPlayerNameXRayTextures: _,
          floorPlayerNameShadowTextures: v,
          floorPlayerNameShadowXRayTextures: y,
          floorNumberTextures: b,
          floorNumberXRayTextures: ee,
          floorNumberShadowTextures: x,
          floorNumberShadowXRayTextures: te,
          floorPoint: S,
          floorPointShadow: C,
          floorPointIndicator: ne,
          bonusArrowsTextures: w,
          bonusMonsterTriggerTextures: re,
          bonusMonsterTriggerBgTexture: ie,
          bonusRisingSunTextures: ae,
          bonusGiftBoxTexture: T,
          lightningTextures: E,
          gorillaTextures: D,
          gorillaStar: O,
          gorillaFlames: oe,
          stompDustTextures: k,
        }) {
          (this._viewportScale = 1),
            (this._blockTextures = e),
            (this._blockTopTextures = t),
            (this._blockTopNeonTexture = n),
            (this._blockFallEffectBack = r),
            (this._blockFallEffectFront = i),
            (this._blockFireEffect = a),
            (this._baseFloorTextures = o),
            (this._baseFloorDoorTexture = s),
            (this._baseFloorBaseTexture = c),
            (this._baseFloorStairsTexture = l),
            (this._floorTextures = u),
            (this._floorTopTexture = d),
            (this._floorDecoTextures = f),
            (this._dustTextures = p),
            (this._dustExplosionTextures = m),
            (this._floorRayTextures = h),
            (this._floorPlayerNameTextures = g),
            (this._floorPlayerNameXRayTextures = _),
            (this._floorPlayerNameShadowTextures = v),
            (this._floorPlayerNameShadowXRayTextures = y),
            (this._floorNumberTextures = b),
            (this._floorNumberXRayTextures = ee),
            (this._floorNumberShadowTextures = x),
            (this._floorNumberShadowXRayTextures = te),
            (this._floorPoint = S),
            (this._floorPointShadow = C),
            (this._floorPointIndicator = ne),
            (this._bonusArrowsTextures = w),
            (this._bonusMonsterTriggerTextures = re),
            (this._bonusMonsterTriggerBgTexture = ie),
            (this._bonusRisingSunTextures = ae),
            (this._bonusGiftBoxTexture = T),
            (this._lightningTextures = E),
            (this._gorillaTextures = D),
            (this._gorillaStar = O),
            (this._gorillaFlames = oe),
            (this._stompDustTextures = k);
        }
        set viewportScale(e) {
          this._viewportScale = e;
        }
        createLabel(e, t, n) {
          let r = new _g(n);
          (r.x = e), (r.y = t);
          let i = 1 + (1 - this._viewportScale);
          return r.scale.set(i, i), r;
        }
        createBlock(e, t) {
          let n = (0, Cg.default)(this._blockTextures);
          return new Hh({
            gridRow: e,
            gridCol: t,
            texture: n,
            effectTextureBack: this._blockFallEffectBack,
            effectTextureFront: this._blockFallEffectFront,
            effectFire: this._blockFireEffect,
            effectExplode: this._dustExplosionTextures,
          });
        }
        createCityGorilla(e) {
          return new ig({
            textures: this._gorillaTextures,
            stompDustTextures: this._stompDustTextures,
            starTexture: this._gorillaStar,
            stageWidth: e,
          });
        }
        createSpaceGorilla(e) {
          return new xg({
            textures: this._gorillaTextures,
            stompDustTextures: this._stompDustTextures,
            flamesTextures: this._gorillaFlames,
            stageWidth: e,
          });
        }
        createGorilla(e, t) {
          switch (e) {
            case b.HighestTowersCity:
              return this.createCityGorilla(t);
            case b.HighestTowersSpace:
              return this.createSpaceGorilla(t);
            default:
              throw Error(`Unknown skin: ${e}`);
          }
        }
        createCityBonus(e, t, n) {
          return new ng({
            length: n,
            gridRow: e,
            gridCol: t,
            bonusMonsterTextures: this._bonusMonsterTriggerTextures,
          });
        }
        createSpaceBonus(e, t, n) {
          return new yg({
            length: n,
            gridRow: e,
            gridCol: t,
            bonusMonsterTextures: this._bonusMonsterTriggerTextures,
          });
        }
        createGiftBonus(e, t, n) {
          return new lg({
            length: n,
            gridRow: e,
            gridCol: t,
            bonusGiftTexture: this._bonusGiftBoxTexture[0],
            effectExplode: this._dustExplosionTextures,
          });
        }
        createBonusBg(e, t, n) {
          return new eg({
            length: n,
            gridRow: e,
            gridCol: t,
            bonusArrowTextures: this._bonusArrowsTextures,
            bonusFrameTexture: this._bonusMonsterTriggerBgTexture,
            bonusSunTextures: this._bonusRisingSunTextures,
          });
        }
        createBonus(e, t, n, r) {
          switch (e) {
            case b.HighestTowersCity:
              return this.createCityBonus(t, n, r);
            case b.HighestTowersSpace:
              return this.createSpaceBonus(t, n, r);
            case `gift`:
              return this.createGiftBonus(t, n, r);
            default:
              throw Error(`Unknown skin: ${e}`);
          }
        }
        createBaseBlockRow(e, t, n) {
          let r = (0, Cg.default)(this._baseFloorTextures);
          return new Jh({
            skin: e,
            theme: t,
            towerCells: n,
            texture: r,
            topTexture: this._floorTopTexture,
            neonTexture: this._blockTopNeonTexture,
            blockTopTextures:
              e === b.HighestTowersSpace ? void 0 : this._blockTopTextures,
            decoTextures: this._floorDecoTextures,
            doorTexture: this._baseFloorDoorTexture,
            baseTexture: this._baseFloorBaseTexture,
            stairsTexture: this._baseFloorStairsTexture,
          });
        }
        createBlockRow(e, t, n, r) {
          let i = (0, Cg.default)(this._floorTextures);
          return new Qh({
            skin: e,
            theme: n,
            towerCells: r,
            gridRow: t,
            texture: i,
            topTexture: this._floorTopTexture,
            blockTopTextures:
              e === b.HighestTowersSpace ? void 0 : this._blockTopTextures,
            decoTextures: this._floorDecoTextures,
            neonTexture: this._blockTopNeonTexture,
          });
        }
        createCompleteFloor(e, t) {
          return new og({
            ...t,
            skin: e,
            floorPlayerNameTextures: this._floorPlayerNameTextures,
            floorPlayerNameXRayTextures: this._floorPlayerNameXRayTextures,
            floorPlayerNameShadowTextures: this._floorPlayerNameShadowTextures,
            floorPlayerNameShadowXRayTextures:
              this._floorPlayerNameShadowXRayTextures,
            floorNumberTextures: this._floorNumberTextures,
            floorNumberXRayTextures: this._floorNumberXRayTextures,
            floorNumberShadowTextures: this._floorNumberShadowTextures,
            floorNumberShadowXRayTextures: this._floorNumberShadowXRayTextures,
            floorPoint: this._floorPoint,
            floorPointShadow: this._floorPointShadow,
            floorPointIndicator: this._floorPointIndicator,
          });
        }
        createDustSprite() {
          let e = this._dustTextures.map((e) => ({ texture: e, time: 100 })),
            t = new A(e, !1);
          return (
            (t.name = `Dust`),
            t.scale.set(1.5, 1.5),
            t.anchor.set(0.5, 1),
            (t.loop = !1),
            t.play(),
            t
          );
        }
        createFloorRay(e, t, n) {
          let r = this._floorRayTextures.map((e) => ({
              texture: e,
              time: 100,
            })),
            i = new A(r, !1);
          return (
            (i.name = `Ray`),
            i.scale.set(1.5, 1.5),
            (i.loop = !1),
            i.play(),
            i.anchor.set(1, 1),
            e === `left` && (i.scale.x *= -1),
            (i.x = t),
            (i.y = n),
            i
          );
        }
        createLightningSprite() {
          let e = this._lightningTextures.map((e) => ({
              texture: e,
              time: 75,
            })),
            t = new A(e, !1);
          return (
            (t.animationSpeed = 0.5),
            (t.name = `Lightning`),
            (t.loop = !1),
            t.play(),
            t.anchor.set(0, 0),
            t
          );
        }
        getHighlightedColumnsGradient(e) {
          switch (e) {
            case b.HighestTowersSpace:
              return [
                [`transparent`, 0],
                [`#ff59a4`, 1],
              ];
            case b.HighestTowersCity:
            default:
              return [
                [`transparent`, 0],
                [`#46178F`, 1],
              ];
          }
        }
        createTowerHighlightedColumns(e, t, n) {
          let r = 2048,
            i = xe(this.getHighlightedColumnsGradient(e), 1, r, `vertical`),
            a = [];
          for (let e = 0; e < t; e += 2) {
            let t = new E()
              .beginTextureFill({ texture: i, alpha: 0.5 })
              .drawRect(0, 0, 75, r)
              .endFill();
            (t.x = -n / 2 + e * 75), t.pivot.set(0, r), a.push(t);
          }
          return a;
        }
        createBlink() {
          let e = new E()
            .beginFill(16777215)
            .drawRect(-H / 2, 0, H, U)
            .endFill();
          return e.pivot.set(0, U), (e.alpha = 0), e;
        }
        getMonsterBackgroundGradient(e) {
          switch (e) {
            case b.HighestTowersSpace:
              return [
                [`#BB0055`, 0],
                [`#b83972`, 0.5],
                [`#ff59a4`, 0.8],
              ];
            case b.HighestTowersCity:
            default:
              return [
                [`transparent`, 0],
                [`#ff4c01`, 0.2],
                [`#ff4c01`, 1],
              ];
          }
        }
        createMonsterBg(e, t, n) {
          let r = xe(this.getMonsterBackgroundGradient(e), 1, n, `vertical`);
          return new E()
            .beginTextureFill({ texture: r, alpha: 0.75 })
            .drawRect(0, 0, t, n)
            .endFill();
        }
      });
  }))();
}
var Eg, Dg, Q, $, Og, kg, Ag;
function jg() {
  return (jg = t(() => {
    (Eg = e(n())),
      (Dg = e(r())),
      j(),
      le(),
      ie(),
      y(),
      x(),
      te(),
      W(),
      a(),
      K(),
      Uh(),
      ja(),
      Tg(),
      (Q = 5),
      ($ = 0),
      (Og = -10),
      (kg = d() ? v(0) : Math.random),
      (Ag = class extends D {
        get _rowWidth() {
          return this._rowCells * 75;
        }
        getEmptyGridRow() {
          return Array(this._rowCells).fill(u.Empty);
        }
        getTowerClosestPitGridRowPos() {
          let [e, t] = this.getTowerGridRowPos();
          return [Math.max(e - 1, 0), Math.min(t + 1, this._rowCells - 1)];
        }
        initGrid() {
          (this._grid = [this.getEmptyGridRow()]),
            (this._highestFinishedGridRow = -1),
            (this._highestInProgressGridRow = -1);
        }
        findBlockGridRow(e) {
          let t = -1;
          for (let n = this._highestInProgressGridRow; n >= 0; n--)
            if (this._grid[n][e] !== u.Empty) {
              t = n;
              break;
            }
          if (t < 0) {
            let [t, n] = this.getTowerGridRowPos();
            return e >= t && e <= n ? 0 : null;
          }
          return t + 1;
        }
        checkFinishedGridRow(e) {
          let [t, n] = this.getTowerGridRowPos();
          for (let r = t; r <= n; r++)
            if (this._grid[e]?.[r] === void 0 || this._grid[e]?.[r] === u.Empty)
              return !1;
          return !0;
        }
        writeBlockToGrid(e, t) {
          if (
            (this._grid[e] || (this._grid[e] = this.getEmptyGridRow()),
            t < 0 || t >= this._rowCells)
          )
            throw Error(`Cell out of bounds!`);
          if (this._grid[e][t] !== u.Empty)
            throw Error(`Cell grid is not empty!`);
          (this._grid[e][t] = u.InProgress),
            (this._highestInProgressGridRow = Math.max(
              this._highestInProgressGridRow,
              e
            ));
        }
        writeFinishedRowToGrid(e) {
          let [t, n] = this.getTowerGridRowPos();
          for (let r = t; r <= n; r++) {
            if (this._grid[e]?.[r] !== u.InProgress)
              throw Error(`Cell grid is not in-progress!`);
            this._grid[e][r] = u.Finished;
          }
          this._highestFinishedGridRow = Math.max(
            this._highestFinishedGridRow,
            e
          );
        }
        createLabel(e, t, { onCompleted: n, ...r }) {
          return this._towerUI.createLabel(e, t, {
            ...r,
            onCompleted: (e) => {
              this._tempContainer.removeChild(e), e.destroy(), n?.(e);
            },
          });
        }
        addDust(e) {
          let t = e.x + 75 / 2,
            n = e.y + 75 / 2,
            r = this._towerUI.createDustSprite();
          (r.x = t),
            (r.y = n),
            this._blocksContainer.addChild(r),
            this._effectsSprites.push(r);
        }
        addFloorRays(e) {
          let [t, n] = this.getTowerGridRowPos(),
            r = -e * 75,
            i = this._towerUI.createFloorRay(
              `left`,
              t * 75 - 75,
              r + 75 / 2 + Og
            ),
            a = this._towerUI.createFloorRay(
              `right`,
              n * 75 + 150,
              r + 75 / 2 + Og
            );
          this._blocksContainer.addChild(i),
            this._blocksContainer.addChild(a),
            this._effectsSprites.push(i),
            this._effectsSprites.push(a);
        }
        addBlockLabel(e, t, n = `top`) {
          if ((0, Eg.default)(e)) return;
          let r = t.x + 75 / 2,
            i = t.y + Q - 75 / 2 + this._blocksContainer.y;
          this.createLabel(r, i, { type: `correct`, name: e, position: n });
        }
        addStaticBlockToTower(e, t = !1, n = !1) {
          let r = e;
          (e < 0 || e >= this._rowCells) &&
            (console.warn(
              `Tower.addStaticBlockToTower(): Cell out of bounds!`,
              e
            ),
            (r = Math.max(0, Math.min(e, this._rowCells - 1))));
          let i = this.findBlockGridRow(r);
          if (i !== null)
            if ((this.writeBlockToGrid(i, r), this.checkFinishedGridRow(i)))
              (this._completedRows += 1),
                (this._lastCompleteRowTimestamp = Math.max(
                  this._lastCompleteRowTimestamp,
                  Date.now()
                )),
                this.writeFinishedRowToGrid(i),
                this.addRowToTower(i, n);
            else {
              let n = e * 75,
                r = -i * 75,
                a = this._towerUI.createBlock(i, e);
              (a.x = n),
                (a.y = r),
                this._blocksContainer.addChild(a),
                t && this.addDust(a);
            }
        }
        addBlockToTower(e, t, n, r, i, a) {
          let o = n * 75,
            s = -t * 75,
            c = this._towerUI.createBlock(t, n);
          (c.x = o), (c.y = s), this._blocksContainer.addChild(c);
          let l = (this.y + s - this._viewportBounds.top + $) * -1;
          c.animatePlace(
            l,
            0,
            () => {
              if ((this.addDust(c), !r)) {
                let [t, r] = this.getTowerGridRowPos(),
                  i = n === t ? `top-left` : n === r ? `top-right` : `top`;
                this.addBlockLabel(e, c, i);
              }
              i();
            },
            a
          ),
            (this.debugWIPPeak.y = -(this._highestInProgressGridRow + 1) * 75),
            (this.debugCompletedPeak.y =
              -(this._highestFinishedGridRow + 1) * 75),
            (this.debugCenter.y = this.debugCompletedPeak.y),
            (this.debugCenter.height = -this.debugCenter.y);
        }
        catchBlockByMonster(e, t) {
          let n = t * 75,
            r = e === null ? this._viewportBounds.bottom - this.y + $ : -e * 75,
            i = this._towerUI.createBlock(e ?? 0, t);
          (i.x = n),
            (i.y = r),
            this._tempContainer.addChild(i),
            this._animatedBlocks.push(i);
          let a = this._viewportBounds.bottom - this._viewportBounds.top,
            o = this._viewportBounds.top - this.y - r + a / 2,
            s = this.y + r - this._viewportBounds.top + $;
          i.animateExplosion(-s, o, () => {
            this._animatedBlocks = this._animatedBlocks.filter(
              (e) => e.uuid !== i.uuid
            );
          });
        }
        addBaseRowToTower() {
          let [e] = this.getTowerGridRowPos(),
            t = e * 75;
          (this._baseBlockRow = this._towerUI.createBaseBlockRow(
            this._skin,
            this._theme,
            this._towerCells
          )),
            (this._baseBlockRow.x = t),
            this._baseContainer.addChild(this._baseBlockRow);
        }
        addRowToTower(e, t = !0) {
          let [n] = this.getTowerGridRowPos(),
            r = n * 75,
            i = -e * 75,
            a = this._towerUI.createBlockRow(
              this._skin,
              e,
              this._theme,
              this._towerCells
            );
          (a.x = r),
            (a.y = i),
            this._blocksContainer.addChild(a),
            this._baseBlockRow?.removeTopDecorations();
          for (let t = this._blocksContainer.children.length - 1; t >= 0; t--) {
            let n = this._blocksContainer.children[t];
            n instanceof Hh &&
              n.gridRow <= e &&
              this._blocksContainer.removeChild(n);
          }
          t && a.animate();
        }
        addMissedLabel(e, t) {
          if ((0, Eg.default)(e)) return;
          let n = Math.min(0, this._viewportBounds.bottom - this.y),
            r = t * 75 + 75 / 2,
            i = n - Q,
            [a, o] = this.getTowerGridRowPos(),
            s = this._towerUI.createLabel(r, i, {
              type: `incorrect`,
              name: e,
              position:
                t < a ? `bottom-left` : t > o ? `bottom-right` : `bottom`,
              onCompleted: () => {
                let e = this._missedLabels.indexOf(s);
                e >= 0 && this._missedLabels.splice(e, 1);
              },
            });
          this._missedLabels.push(s);
        }
        addMissedBlock(e, t, n) {
          let r = this.getTowerClosestPitGridRowPos().reduce((e, n) =>
              Math.abs(n - t) < Math.abs(e - t) ? n : e
            ),
            i = r * 75,
            a = this._viewportBounds.bottom - this.y + $,
            o = this._towerUI.createBlock(0, r);
          (o.x = i), (o.y = a), this._tempContainer.addChild(o);
          let s = this._viewportBounds.bottom - this._viewportBounds.top + $;
          o.animateFall(-s, 0, () => {
            this._tempContainer.removeChild(o),
              o.destroy(),
              this.addMissedLabel(e, r),
              n(c.Misses);
          });
        }
        addTooHighLabel(e, t) {
          if ((0, Eg.default)(e)) return;
          let n = t.x + 75 / 2,
            r = t.y - 75 - Q + this._blocksContainer.y;
          this._towerUI.createLabel(n, r, {
            type: `incorrect`,
            name: e,
            position: `bottom`,
          });
        }
        addTooHighBlock(e, t, n, r) {
          let i = n * 75,
            a = -t * 75,
            o = this._towerUI.createBlock(t, n);
          (o.x = i), (o.y = a), this._tempContainer.addChild(o);
          let s = this.y + a - this._viewportBounds.top + $;
          o.animateIncorrect(-s, 0, () => {
            this.addTooHighLabel(e, o),
              this._tempContainer.removeChild(o),
              o.destroy(),
              r(c.TooHigh);
          });
        }
        addTowerHighlightedColumns() {
          let e = this._towerUI.createTowerHighlightedColumns(
            this._skin,
            this._towerCells,
            this.towerWidth
          );
          this._limitsContainer.addChild(...e);
        }
        addBlink() {
          let e = this._towerUI.createBlink();
          this.addChild(e);
          let t = 0,
            n = () => {
              (e.alpha = +(e.alpha === 0)), t++, t < 4 && setTimeout(n, 50);
            };
          setTimeout(n, 100);
        }
        addLightning(e) {
          let t = this._towerUI.createLightningSprite(),
            n = this._viewportBounds.bottom - this._viewportBounds.top;
          (t.x = -this._rowWidth / 2 + e * 75 - 20),
            (t.y = this._viewportBounds.top - this.y),
            (t.height = n),
            this._effectsSprites.push(t),
            this.addChild(t);
        }
        addBonus(e, t, n, r) {
          let i = r ? `gift` : this._skin;
          (this._bonus = this._towerUI.createBonus(i, e, t, n)),
            (this._bonusBg = this._towerUI.createBonusBg(e, t, n)),
            this._blocksContainer.addChildAt(this._bonusBg, 0),
            this._blocksContainer.addChild(this._bonus);
        }
        addMonsterBackground() {
          let e = this._viewportBounds.right - this._viewportBounds.left,
            t = (this._viewportBounds.bottom - this._viewportBounds.top) * 2,
            n = this._towerUI.createMonsterBg(this._skin, e, t);
          (n.x = e / -2),
            (n.y = this._viewportBounds.top - this.y),
            (this._monsterBackgroundContainer.alpha = 1),
            this._monsterBackgroundContainer.addChild(n),
            _({
              from: { v: 0 },
              to: { v: 1 },
              duration: 1500,
              delay: 700,
              onTick: ({ v: e }) => {
                this._monsterBackgroundContainer.alpha = e;
              },
            }).play();
        }
        removeMonsterBackground() {
          _({
            from: { v: 1 },
            to: { v: 0 },
            duration: 200,
            onTick: ({ v: e }) => {
              this._monsterBackgroundContainer.alpha = e;
            },
          }).play();
        }
        addMonster(e) {
          this.addMonsterBackground(),
            (this._monster = this._towerUI.createGorilla(
              this._skin,
              this._viewportBounds.right - this._viewportBounds.left
            ));
          let t = this._viewportBounds.bottom - this._viewportBounds.top,
            n = this._viewportBounds.top - this.y + t / 2,
            r = this._viewportBounds.top - this.y + t + this._monster.height;
          this._monster.animateMovement(r, n, 1500, e),
            this._monsterBackgroundContainer.addChild(this._monster);
        }
        viewportChanged() {
          this._missedLabels.forEach((e) => {
            e.y = this._viewportBounds.bottom - this.y - Q;
          });
          let e = this._viewportBounds.bottom - this._viewportBounds.top;
          (this._limitsContainer.y = this._viewportBounds.bottom - this.y),
            (this._limitsContainer.height = e),
            this._completeFloor &&
              (this._completeFloor.viewportBounds = this._viewportBounds);
        }
        addFloorAnimation(e, t, n) {
          re() ||
            (this.removeFloorAnimation(),
            (this._completeFloor = this._towerUI.createCompleteFloor(
              this._skin,
              {
                theme: this._theme,
                rowCells: this._rowCells,
                rowWidth: this._rowWidth,
                viewportBounds: this._viewportBounds,
                gridRow: e,
                playerName: t,
                variant:
                  n ??
                  (this._isLittleTimeLeft ? `little-time-left` : `regular`),
              }
            )),
            this._tempContainer.addChild(this._completeFloor));
        }
        removeFloorAnimation() {
          this._completeFloor &&=
            (this._tempContainer.removeChild(this._completeFloor),
            this._completeFloor.destroy(),
            null);
        }
        constructor({
          skin: e,
          theme: t,
          cells: n,
          initialViewportBounds: r,
          withHighlightedColumns: i = !0,
          blocks: a,
          ...o
        }) {
          super(),
            (this._grid = []),
            (this._highestFinishedGridRow = -1),
            (this._highestInProgressGridRow = -1),
            (this._isLittleTimeLeft = !1),
            (this._lastCompleteRowTimestamp = 0),
            (this._completedRows = 0),
            (this._bonus = null),
            (this._bonusBg = null),
            (this._bonusPosition = null),
            (this._monster = null),
            (this._animatedBlocks = []),
            (this._completeFloor = null),
            (this._missedLabels = []),
            (this._effectsSprites = []),
            (this._skin = e),
            (this._theme = t),
            (this._towerCells = n),
            (this._rowCells = n + 4),
            (this._viewportBounds = r),
            (this._withHighlightedColumns = !!i),
            (this._towerUI = new wg(o));
          let s = (e) => {
            let t = new D();
            return (t.name = e), (t.x = -this._rowWidth / 2), t;
          };
          (this._limitsContainer = new D()),
            (this._limitsContainer.name = `LimitsContainer`),
            this.addChild(this._limitsContainer),
            (this._blocksContainer = s(`BlocksContainer`)),
            (this._blocksContainer.y = -150),
            this.addChild(this._blocksContainer),
            (this._baseContainer = s(`BaseContainer`)),
            this.addChild(this._baseContainer),
            (this._monsterBackgroundContainer = new D()),
            (this._monsterBackgroundContainer.name = `MonsterContainer`),
            this.addChild(this._monsterBackgroundContainer),
            (this._tempContainer = s(`TempContainer`)),
            this.addChild(this._tempContainer),
            this._withHighlightedColumns && this.addTowerHighlightedColumns(),
            this.initGrid(),
            (this.debugCenter = new E()
              .beginFill(16777215)
              .drawRect(0, 0, 1, 1)
              .endFill()),
            (this.debugCenter.name = `DebugCenter`),
            (this.debugCompletedPeak = new E()
              .beginFill(16711680)
              .drawRect(-this._rowWidth / 2, 0, this._rowWidth, 3)
              .endFill()),
            (this.debugCompletedPeak.name = `DebugCompletedPeak`),
            (this.debugWIPPeak = new E()
              .beginFill(15262236)
              .drawRect(-this._rowWidth / 2, 0, this._rowWidth, 3)
              .endFill()),
            (this.debugWIPPeak.name = `DebugWIPPeak`),
            this.addBaseRowToTower(),
            a.forEach((e) => {
              this.addStaticBlockToTower(e.column);
            });
        }
        getTowerGridRowPos() {
          return [2, Math.min(2 + this._towerCells - 1, this._rowCells - 1)];
        }
        get towerWidth() {
          return this._towerCells * 75;
        }
        get highestFinishedGridRow() {
          return this._highestFinishedGridRow + 1;
        }
        get points() {
          return (
            1e3 * this._completedRows +
            Math.min(10 * this.inProgressBlocks, 900)
          );
        }
        get completedRows() {
          return this._completedRows;
        }
        get inProgressBlocks() {
          let e = 0;
          if (this._highestFinishedGridRow < 0) return e;
          for (let t = this._highestFinishedGridRow; t < this._grid.length; t++)
            for (let n = 0; n < this._grid[t].length; n++)
              e += +(this._grid[t][n] === u.InProgress);
          return e;
        }
        get lastCompleteRowTimestamp() {
          return this._lastCompleteRowTimestamp;
        }
        set viewportBounds(e) {
          this.destroyed ||
            th(this._viewportBounds, e) ||
            ((this._viewportBounds = e), this.viewportChanged());
        }
        set viewportScale(e) {
          this._towerUI.viewportScale = e;
        }
        set isLittleTimeLeft(e) {
          this._isLittleTimeLeft = e;
        }
        dropHangingBlock(e) {
          let t = this.getHangingBlockCol(),
            n = t;
          (t < 0 || t >= this._rowCells) &&
            (console.warn(`Tower.dropHangingBlock(): Cell out of bounds!`, t),
            (n = Math.max(0, Math.min(t, this._rowCells - 1))));
          let r = this.findBlockGridRow(n);
          if (r === null) {
            this._hangingBlock?.dropMiss(t, () => {
              e(n, c.Misses);
            });
            return;
          }
          if (
            r * 75 + 150 > Math.abs(this._hangingBlock?.y || 0) &&
            this._hangingBlock
          ) {
            this._animatedBlocks.push(this._hangingBlock.block);
            let r = this._hangingBlock.block.uuid;
            this._hangingBlock.explode(t, () => {
              e(n, c.Misses),
                (this._animatedBlocks = this._animatedBlocks.filter(
                  (e) => e.uuid !== r
                ));
            });
            return;
          }
          let i = -r * 75 - Math.abs(this._blocksContainer.y);
          this._hangingBlock?.dropSuccess(t, i, () => {
            this.addStaticBlockToTower(t, !0, !0),
              this._bonus &&
                this._blocksContainer.setChildIndex(
                  this._bonus,
                  this._blocksContainer.children.length - 1
                );
            let i =
                !!this._bonusPosition &&
                this._bonusPosition[0] === n &&
                this._bonusPosition[1] === r,
              a =
                !!this._bonusPosition &&
                this._bonusPosition[0] === n &&
                this._bonusPosition[1] !== r,
              o = this.checkFinishedGridRow(r);
            o && (this.addFloorRays(r), this.addFloorAnimation(r, ``, `solo`)),
              e(n, o ? c.CompletesRow : c.ContinuesRow, i, a);
          });
        }
        getHangingBlockCol() {
          if (!this._hangingBlock) return -1;
          let e = this._hangingBlock.x,
            t = Array(this._towerCells + 4)
              .fill(null)
              .map((e, t) => t * 75),
            n = t.reduce((t, n) => (Math.abs(n - e) < Math.abs(t - e) ? n : t));
          return t.findIndex((e) => e === n);
        }
        addHangingBlock() {
          this.removeHangingBlock();
          let e = this._viewportBounds.top - this.y + 300,
            t = (this._rowCells - 1.5) * 75;
          (this._hangingBlock = new Aa(
            this._towerUI.createBlock(0, 0),
            { start: 37.5, end: t },
            e
          )),
            this._tempContainer.addChild(this._hangingBlock);
        }
        removeHangingBlock() {
          this._hangingBlock &&
            (this._tempContainer.removeChild(this._hangingBlock),
            this._hangingBlock?.destroy());
        }
        updateHangingBlockMovementSpeed(e) {
          this._hangingBlock?.updateMovementSpeed(e);
        }
        addBonusBlock(e, t, n) {
          let [r, i] = this.getTowerGridRowPos(),
            a = n === void 0 ? Math.floor(kg() * (i - r + 1)) + r : n;
          this.addBlock(``, a, Date.now(), (t) => e(a, t), 200, t);
        }
        addBlock(e, t, n, r, i, a) {
          let o = t;
          (t < 0 || t >= this._rowCells) &&
            (console.warn(`Tower.addBlock(): Cell out of bounds!`, e, t),
            (o = Math.max(0, Math.min(t, this._rowCells - 1))));
          let s = this.findBlockGridRow(o);
          if (this._monster) return this.catchBlockByMonster(s, o), c.Misses;
          if (s === null) return this.addMissedBlock(e, o, r), c.Misses;
          if (s > this._highestFinishedGridRow + 20)
            return this.addTooHighBlock(e, s, o, r), c.TooHigh;
          this.writeBlockToGrid(s, o);
          let l = this.checkFinishedGridRow(s);
          return (
            l &&
              ((this._completedRows += 1),
              (this._lastCompleteRowTimestamp = Math.max(
                this._lastCompleteRowTimestamp,
                n
              )),
              this.writeFinishedRowToGrid(s)),
            this.addBlockToTower(
              e,
              s,
              o,
              l,
              () => {
                let t =
                    !!this._bonusPosition &&
                    this._bonusPosition[0] === o &&
                    this._bonusPosition[1] === s,
                  n =
                    !!this._bonusPosition &&
                    this._bonusPosition[0] === o &&
                    this._bonusPosition[1] !== s;
                t && this.showThunder(this._bonusPosition?.[0] || 0),
                  l
                    ? (this.addRowToTower(s),
                      this.addFloorRays(s),
                      this.addFloorAnimation(s, e, a),
                      r(c.CompletesRow, s, t, n))
                    : r(c.ContinuesRow, s, t, n);
              },
              i
            ),
            l ? c.CompletesRow : c.ContinuesRow
          );
        }
        update(e) {
          if (!this.destroyed) {
            this._bonus && this._bonus?.update(e),
              this._bonusBg && this._bonusBg?.update(e),
              this._monster && this._monster?.update(e),
              this._completeFloor && this._completeFloor?.update(e);
            for (let t of this._animatedBlocks) t.update(e);
            for (let t of this._effectsSprites) t.update(e);
            for (let e = this._effectsSprites.length - 1; e >= 0; e--) {
              let t = this._effectsSprites[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._effectsSprites.splice(e, 1));
            }
          }
        }
        destroy() {
          this.removeMonster(),
            this.removeBonus(),
            this.removeFloorAnimation(),
            this._hangingBlock?.destroy(),
            super.destroy();
        }
        enableMonster(e) {
          this._monster || (this.removeFloorAnimation(), this.addMonster(e));
        }
        removeMonster() {
          this._monster &&=
            (this._monsterBackgroundContainer.removeChild(this._monster),
            this.removeMonsterBackground(),
            this._monster.destroy(),
            null);
        }
        bumpMonster(e) {
          this._monster?.bump(e);
        }
        disableMonster(e) {
          if (!this._monster) return;
          if (!e) {
            this.removeMonster();
            return;
          }
          let t = this._viewportBounds.bottom - this._viewportBounds.top,
            n = this._viewportBounds.top - this.y + t / 2,
            r = this._viewportBounds.top - this.y + t * 2;
          this._monster.animateMovement(n, r, 0, () => {
            this.removeMonster(), e();
          });
        }
        showThunder(e) {
          this.addLightning(e || this._bonusPosition?.[0] || 0),
            this.addBlink();
        }
        enableBonus(e = 6, t) {
          if (this._bonus) return;
          let [n, r] = this.getTowerGridRowPos(),
            i = this._highestFinishedGridRow + 1,
            a = this._grid[i],
            o = d()
              ? 2
              : (0, Dg.default)(
                  a
                    ?.slice(n, r + 1)
                    .map((e, t) => ({ value: e, index: t + n }))
                    .filter(({ value: e }) => e === u.Empty)
                    .map(({ index: e }) => e)
                ) || Math.floor(Math.random() * (r - n + 1)) + n;
          this.addBonus(i, o, e, t);
          let s = [o, i + (e - 1)];
          this._bonusPosition = s;
        }
        removeBonus() {
          !this._bonus ||
            !this._bonusBg ||
            (this._blocksContainer.removeChild(this._bonusBg, this._bonus),
            this._bonusBg.destroy(),
            (this._bonusBg = null),
            this._bonus.destroy(),
            (this._bonus = null),
            (this._bonusPosition = null));
        }
        disableBonus(e = !1, t) {
          this._bonus &&
            (e
              ? (this._blocksContainer.setChildIndex(
                  this._bonus,
                  this._blocksContainer.children.length - 1
                ),
                this._bonus?.animateDisappear(() => {
                  this.removeBonus(), t?.();
                }))
              : this.removeBonus());
        }
        animateForEndGame(e, t, n, r) {
          this.removeMonster(), this.removeBonus(), this.removeFloorAnimation();
          let i = this._colorFilter ?? new ce();
          (this._blocksContainer.filters = [i]),
            (this._baseContainer.filters = [i]);
          let a = 0.3,
            o = () => {
              let t = !1;
              _({
                from: { v: -1, b: a, a: 0 },
                to: { v: 1, b: 1, a: 1 },
                duration: 500,
                delay: e * 5e3 + 2e3,
                easing: m.EASE_OUT_CUBIC,
                onTick: ({ v: e, b: n, a }) => {
                  i.saturate(e),
                    i.brightness(n, !1),
                    (this._limitsContainer.alpha = a),
                    !t && a && ((t = !0), r());
                },
                onFinish: () => {
                  this.addFloorAnimation(this.completedRows - 1, ``, `podium`);
                },
              }).play();
            };
          if (!t) {
            _({
              from: { v: 1, b: 1, a: 1 },
              to: { v: -1, b: a, a: 0 },
              duration: 3e3,
              onTick: ({ v: e, b: t, a: n }) => {
                i.saturate(e),
                  i.brightness(t, !1),
                  (this._limitsContainer.alpha = n);
              },
              onFinish: () => {
                o();
              },
            }).play();
            return;
          }
          _({
            from: { a: 1 },
            to: { a: 0 },
            duration: 3e3,
            onTick: ({ a: e }) => {
              this._blocksContainer.alpha =
                this._baseContainer.alpha =
                this._limitsContainer.alpha =
                  e;
            },
            onFinish: () => {
              n(),
                i.saturate(-1),
                i.brightness(a, !1),
                _({
                  from: { a: 0 },
                  to: { a: 1 },
                  duration: 800,
                  delay: 4e3,
                  onTick: ({ a: e }) => {
                    this._blocksContainer.alpha = this._baseContainer.alpha = e;
                  },
                  onFinish: () => {
                    o();
                  },
                }).play();
            },
          }).play();
        }
      });
  }))();
}
var Mg;
function Ng() {
  return (Ng = t(() => {
    Se(),
      j(),
      (Mg = class extends D {
        constructor({
          viewportHeight: e,
          viewportWidth: t,
          worldHeight: n,
          worldWidth: r,
          onViewportChanged: i,
          events: a,
        }) {
          super(),
            (this._onViewportChangedCallback = i),
            (this._viewport = new Ce({
              screenWidth: t,
              screenHeight: e,
              worldWidth: r,
              worldHeight: n,
              events: a,
            })),
            this._viewport.clamp({ direction: `all` }),
            this._viewport.addListener(`moved`, () => {
              this._onViewportChangedCallback?.(this.viewportBounds);
            }),
            this._viewport.addListener(`moved-end`, () => {
              this._onViewportChangedCallback?.(this.viewportBounds);
            }),
            (this._viewportCamera = new D()),
            (this._viewportCamera.zIndex = 1e3),
            (this._viewportCamera.name = `TowerViewportCamera`),
            this._viewport.addChild(this._viewportCamera),
            this._viewport.follow(this._viewportCamera, {
              acceleration: 0.1,
              speed: 5,
            }),
            (this._viewportMask = new E()
              .beginFill(0)
              .drawRect(0, 0, 10, 10)
              .endFill()),
            (this._viewportMask.name = `TowerViewportMask`),
            (this._viewportMask.width = t),
            (this._viewportMask.height = e),
            super.addChild(this._viewport),
            super.addChild(this._viewportMask),
            (this.mask = this._viewportMask);
        }
        get viewportBounds() {
          let { left: e, top: t, right: n, bottom: r } = this._viewport;
          return { left: e, top: t, right: n, bottom: r };
        }
        get viewportScale() {
          let { scale: e } = this._viewport;
          return e.x;
        }
        set viewportScale(e) {
          this._viewport.setZoom(e);
        }
        get viewportUnscaledWidth() {
          let { left: e, right: t } = this.viewportBounds;
          return t - e;
        }
        get viewportUnscaledHeight() {
          let { top: e, bottom: t } = this.viewportBounds;
          return t - e;
        }
        get viewportWidth() {
          return this.viewportUnscaledWidth * this.viewportScale;
        }
        get viewportHeight() {
          return this.viewportUnscaledHeight * this.viewportScale;
        }
        addChild(...e) {
          return this._viewport.addChild(...e);
        }
        addChildAt(e, t) {
          return this._viewport.addChildAt(e, t);
        }
        removeChild(...e) {
          return this._viewport.removeChild(...e);
        }
        resize(e, t) {
          this._viewport.resize(e, t),
            (this._viewportMask.width = e),
            (this._viewportMask.height = t);
        }
        moveCamera(e, t, n) {
          (this._viewportCamera.x = e),
            (this._viewportCamera.y = t),
            n && this._viewport.moveCenter(e, t);
        }
        moveCameraEndOfGame(e, t, n) {
          let r = t - this._viewportCamera.y,
            i = n * 2,
            a = Math.abs(r / i);
          a !== 0 &&
            (this._viewport.plugins.remove(`follow`),
            this._viewport.follow(this._viewportCamera, {
              acceleration: 0.3,
              speed: a,
            }),
            (this._viewportCamera.x = e),
            (this._viewportCamera.y = t));
        }
        update() {
          this.destroyed;
        }
        destroy() {
          this._viewportMask.destroy(!0), this._viewport.destroy();
        }
      });
  }))();
}
var Pg, Fg;
function Ig() {
  return (Ig = t(() => {
    j(),
      M(),
      l(),
      ie(),
      ue(),
      fe(),
      me(),
      ge(),
      be(),
      ve(),
      eh(),
      V(),
      vh(),
      Eh(),
      Ph(),
      Vh(),
      jg(),
      Ng(),
      W(),
      a(),
      K(),
      (Pg = 70),
      (Fg = class extends de {
        get _towerBottomOffset() {
          return this._skin === b.HighestTowersSpace ? 65 : 40;
        }
        get _teamsNumber() {
          return this.gameConfig?.towers.length ?? 0;
        }
        constructor(e, t = ae.Live, n = Ma, r = 720) {
          super({
            width: n,
            height: r,
            backgroundColor: 16777215,
            withTweening: !0,
            antialias: !h() && void 0,
          }),
            (this._teams = []),
            (this._iBlock = 0),
            (this._confettiTextures = []),
            (this._skin = e),
            (this._mode = t),
            N.registerBehavior(ye);
        }
        getCommonTextures() {
          return {
            dustTextures: this.loader.getResourceTextures(Be),
            dustExplosionTextures: this.loader.getResourceTextures(Xe),
            floorRayTextures: this.loader.getResourceTextures(ht),
            floorPlayerNameTextures: this.loader.getResourceTextures(jt),
            floorPlayerNameXRayTextures: this.loader.getResourceTextures([Mt]),
            floorPlayerNameShadowTextures: this.loader.getResourceTextures(It),
            floorPlayerNameShadowXRayTextures: this.loader.getResourceTextures([
              Lt,
            ]),
            floorNumberTextures: this.loader.getResourceTextures(et),
            floorNumberXRayTextures: this.loader.getResourceTextures([tt]),
            floorNumberShadowTextures: this.loader.getResourceTextures(at),
            floorNumberShadowXRayTextures: this.loader.getResourceTextures([
              ot,
            ]),
            floorPoint: this.loader.getResourceTextures([Rt]),
            floorPointShadow: this.loader.getResourceTextures([zt]),
            floorPointIndicator: this.loader.getResourceTextures([Bt]),
            bonusArrowsTextures: this.loader.getResourceTextures(Ae),
            lightningTextures: this.loader.getResourceTextures(Dt),
            stompDustTextures: this.loader.getResourceTextures(Zt),
            bonusRisingSunTextures: this.loader.getResourceTextures(tn),
            bonusGiftBoxTexture: this.loader.getResourceTextures([nn]),
          };
        }
        getCityTextures(e, t) {
          return {
            blockTextures: this.loader.getResourceTextures([vn]),
            blockTopTextures: this.loader.getResourceTextures([$n, er, tr]),
            blockTopNeonTexture: void 0,
            blockFallEffectBack: this.loader.getResourceTexture(yn),
            blockFallEffectFront: this.loader.getResourceTexture(bn),
            blockFireEffect: void 0,
            baseFloorTextures: this.loader.getResourceTextures(
              Qn[t]?.base ?? []
            ),
            baseFloorDoorTexture: this.loader.getResourceTexture(lr[e]),
            baseFloorBaseTexture: this.loader.getResourceTexture(ur),
            baseFloorStairsTexture: this.loader.getResourceTexture(dr),
            floorTextures: this.loader.getResourceTextures(Qn[t]?.floor ?? []),
            floorTopTexture: this.loader.getResourceTexture(xn),
            floorDecoTextures: this.loader.getResourceTextures([
              nr,
              rr,
              ir,
              ar,
              or,
            ]),
            bonusMonsterTriggerTextures: this.loader.getResourceTextures(hr),
            bonusMonsterTriggerBgTexture: this.loader.getResourceTexture(gr),
            gorillaTextures: this.loader.getResourceTextures(Er),
            gorillaStar: this.loader.getResourceTexture(_r),
            gorillaFlames: void 0,
          };
        }
        getSpaceTextures(e, t) {
          return {
            blockTextures: this.loader.getResourceTextures([oi]),
            blockTopTextures: [],
            blockTopNeonTexture: this.loader.getResourceTexture(ni),
            blockFallEffectBack: this.loader.getResourceTexture(si),
            blockFallEffectFront: this.loader.getResourceTexture(ci),
            blockFireEffect: this.loader.getResourceTexture(li),
            baseFloorTextures: this.loader.getResourceTextures(
              Wi[t]?.base ?? []
            ),
            baseFloorDoorTexture: this.loader.getResourceTexture(di[e]),
            baseFloorBaseTexture: this.loader.getResourceTexture(wa),
            baseFloorStairsTexture: this.loader.getResourceTexture(Ta),
            floorTextures: this.loader.getResourceTextures(Wi[t]?.floor ?? []),
            floorTopTexture: this.loader.getResourceTexture(ri),
            floorDecoTextures: this.loader.getResourceTextures([
              Gi,
              Ki,
              qi,
              Ji,
              Yi,
              Xi,
              Zi,
            ]),
            bonusMonsterTriggerTextures: this.loader.getResourceTextures(oa),
            bonusMonsterTriggerBgTexture: this.loader.getResourceTexture(sa),
            gorillaTextures: this.loader.getResourceTextures(Ca),
            gorillaStar: void 0,
            gorillaFlames: this.loader.getResourceTextures(ma),
            gorillaKing: void 0,
          };
        }
        getTextures(e, t) {
          let n = this.getCommonTextures();
          switch (this._skin) {
            case b.HighestTowersCity:
              return { ...n, ...this.getCityTextures(e, t) };
            case b.HighestTowersSpace:
              return { ...n, ...this.getSpaceTextures(e, t) };
            default:
              throw Error(`Unknown skin: ${this._skin}`);
          }
        }
        getGradientData() {
          switch (this._skin) {
            case b.HighestTowersCity:
              return [
                [`#000000`, 0 / 2],
                [`#44348c`, 0.5 / 2],
                [`#665FCB`, 1 / 2],
                [`#5EA0D9`, 1.21 / 2],
                [`#80D7D6`, (0.36 + 1) / 2],
                [`#BAECD3`, 1.49 / 2],
                [`#EEF8CC`, 1.62 / 2],
                [`#EEF8CC`, 2 / 2],
              ];
            case b.HighestTowersSpace:
              return [
                [`#53186F`, 0 / 2],
                [`#53186F`, 0.5 / 2],
                [`#53186F`, 1 / 2],
                [`#5C339F`, 1.21 / 2],
                [`#6B56D8`, 1.45 / 2],
                [`#BFA5FF`, 1.65 / 2],
                [`#DFCEFF`, 1.85 / 2],
              ];
            default:
              return [];
          }
        }
        createBackgroundGradientTexture() {
          return xe(this.getGradientData(), 250, 500, `vertical`);
        }
        createCityBackground(e, t) {
          let n = [on].filter((e) => this.loader.hasLoadedResource(e)),
            r = this.loader.getResources(n).map((e, t) => {
              let {
                  name: n,
                  addedResource: { width: r, height: i },
                } = e,
                a = this.getTilingSprite({
                  name: `bg_${t}`,
                  textureName: n,
                  width: r,
                  height: i,
                });
              return (a.name = `Background_${t}`), a.anchor.set(0, 1), a;
            }),
            i = [cn],
            a = this.loader.getResourceTextures(i),
            o = this.loader.getResourceTextures(fn),
            s = new _h({
              towerX: e,
              towerWidth: t,
              cloudTextures: o,
              baseTilingSprites: r,
              itemsTextures: a,
              gradientTexture: this._gradientTexture,
            });
          return (s.name = `Background`), (s.y = U), s;
        }
        createSpaceBackground(e, t) {
          let n = [Ir, Rr].filter((e) => this.loader.hasLoadedResource(e)),
            r = this.loader.getResources(n).map((e, t) => {
              let {
                  name: n,
                  addedResource: { width: r, height: i },
                } = e,
                a = this.getTilingSprite({
                  name: `bg_${t}`,
                  textureName: n,
                  width: r,
                  height: i,
                });
              return (
                (a.name = `Background_${t}`),
                a.anchor.set(0, 1),
                n === `SPACE_BACKGROUNDCITY01` &&
                  ((a.y = -65), a.scale.set(1.25)),
                n === `SPACE_BACKGROUNDCITY00` && (a.alpha = 0.5),
                a
              );
            }),
            i = [Gr, Wr],
            a = this.loader.getResourceTextures(i),
            o = this.loader.getResourceTextures(Ur),
            s = this.loader.getResourceTexture(Kr),
            c = new Nh({
              towerX: e,
              towerWidth: t,
              baseTilingSprites: r,
              itemsTextures: a,
              gradientTexture: this._gradientTexture,
              planetsTextures: o,
              starsTexture: s,
            });
          return (c.name = `Background`), (c.y = U), c;
        }
        createBackground(e, t) {
          switch (this._skin) {
            case b.HighestTowersCity:
              return this.createCityBackground(e, t);
            case b.HighestTowersSpace:
              return this.createSpaceBackground(e, t);
            default:
              throw Error(`Unknown skin: ${this._skin}`);
          }
        }
        createCitySoil(e, t) {
          let n = this.loader.getResource(pn);
          if (!n)
            return new Th({ towerX: e, towerWidth: t, tilingSprite: new T() });
          let {
              addedResource: { width: r, height: i },
            } = n,
            a = this.getTilingSprite({
              name: `soil`,
              textureName: pn,
              width: r,
              height: i,
            });
          a.anchor.set(0, 1);
          let o = [hn],
            s = this.loader.getResourceTextures(o),
            c = [gn, _n],
            l = this.loader.getResourceTextures(c),
            u = new Th({
              towerX: e,
              towerWidth: t,
              tilingSprite: a,
              itemsTextures: s,
              firstLevelTextures: l,
            });
          return (u.name = `Soil`), (u.y = U), u;
        }
        createSpaceSoil(e, t, n) {
          let r = this.loader.getResource(fi);
          if (!r)
            return new Bh({
              towerX: e,
              towerWidth: t,
              towerBottomOffset: this._towerBottomOffset,
              tilingSprite: new T(),
            });
          let {
              addedResource: { width: i, height: a },
            } = r,
            o = this.getTilingSprite({
              name: `soil`,
              textureName: fi,
              width: i,
              height: a,
            });
          o.anchor.set(0, 1);
          let s = ti[n],
            c = this.loader.getResourceTextures(s),
            l = [ii, ai],
            u = this.loader.getResourceTextures(l),
            d = this.loader.getResourceTexture(qr),
            f = this.loader.getResourceTexture(Jr),
            p = new Bh({
              towerX: e,
              towerWidth: t,
              towerBottomOffset: this._towerBottomOffset,
              tilingSprite: o,
              itemsTextures: c,
              firstLevelTextures: u,
              backgroundHoleTexture: d,
              backgroundHoleLightTexture: f,
            });
          return (p.name = `Soil`), (p.y = U), p;
        }
        createSoil(e, t, n) {
          switch (this._skin) {
            case b.HighestTowersCity:
              return this.createCitySoil(e, t);
            case b.HighestTowersSpace:
              return this.createSpaceSoil(e, t, n);
            default:
              throw Error(`Unknown skin: ${this._skin}`);
          }
        }
        createTeam(e, t, n) {
          let r = this.stageWidth() / this._teamsNumber,
            i = this.stageHeight(),
            a = this.gameConfig?.towerCells ?? 5,
            {
              baseFloorTextures: o,
              baseFloorDoorTexture: s,
              baseFloorBaseTexture: c,
              baseFloorStairsTexture: l,
              blockTextures: u,
              blockTopTextures: d,
              blockTopNeonTexture: f,
              blockFallEffectBack: p,
              blockFallEffectFront: m,
              blockFireEffect: h,
              floorTextures: g,
              floorTopTexture: _,
              floorDecoTextures: v,
              dustTextures: y,
              dustExplosionTextures: ee,
              floorRayTextures: x,
              floorPlayerNameTextures: te,
              floorPlayerNameXRayTextures: S,
              floorPlayerNameShadowTextures: C,
              floorPlayerNameShadowXRayTextures: ne,
              floorNumberTextures: w,
              floorNumberXRayTextures: re,
              floorNumberShadowTextures: ie,
              floorNumberShadowXRayTextures: T,
              floorPoint: E,
              floorPointShadow: D,
              floorPointIndicator: O,
              bonusArrowsTextures: oe,
              bonusMonsterTriggerTextures: k,
              bonusMonsterTriggerBgTexture: se,
              bonusRisingSunTextures: A,
              bonusGiftBoxTexture: ce,
              lightningTextures: le,
              gorillaTextures: ue,
              gorillaStar: de,
              gorillaFlames: j,
              stompDustTextures: fe,
            } = this.getTextures(n, a),
            M = new Mg({
              viewportWidth: Math.ceil(r),
              viewportHeight: i,
              worldWidth: H,
              worldHeight: U,
              onViewportChanged: (e) => {
                (N.viewportBounds = e), (pe.viewportBounds = e);
              },
              events: this.app.renderer.events,
            });
          this._viewportsLayer.addChild(M);
          let N = new Ag({
            skin: this._skin || b.HighestTowersCity,
            theme: n,
            cells: a,
            initialViewportBounds: M.viewportBounds,
            withHighlightedColumns: this._mode === ae.Live,
            blocks: this.gameConfig?.blocks || [],
            baseFloorTextures: o,
            baseFloorDoorTexture: s,
            baseFloorBaseTexture: c,
            baseFloorStairsTexture: l,
            blockTextures: u,
            blockTopTextures: d,
            blockTopNeonTexture: f,
            blockFallEffectBack: p,
            blockFallEffectFront: m,
            blockFireEffect: h,
            floorTextures: g,
            floorTopTexture: _,
            floorDecoTextures: v,
            dustTextures: y,
            dustExplosionTextures: ee,
            floorRayTextures: x,
            floorPlayerNameTextures: te,
            floorPlayerNameXRayTextures: S,
            floorPlayerNameShadowTextures: C,
            floorPlayerNameShadowXRayTextures: ne,
            floorNumberTextures: w,
            floorNumberXRayTextures: re,
            floorNumberShadowTextures: ie,
            floorNumberShadowXRayTextures: T,
            floorPoint: E,
            floorPointShadow: D,
            floorPointIndicator: O,
            bonusArrowsTextures: oe,
            bonusMonsterTriggerTextures: k,
            bonusMonsterTriggerBgTexture: se,
            bonusRisingSunTextures: A,
            bonusGiftBoxTexture: ce,
            lightningTextures: le,
            gorillaTextures: ue,
            gorillaStar: de,
            gorillaFlames: j,
            stompDustTextures: fe,
          });
          (N.x = H / 2 - (r * this._teamsNumber) / 2 + (1 + e) * r - r / 2),
            (N.y = U - this._towerBottomOffset);
          let pe = this.createBackground(N.x, N.towerWidth),
            me = this.createSoil(N.x, N.towerWidth, n);
          M.addChild(pe),
            M.addChild(N),
            M.addChild(me),
            (M.x = Math.floor(e * r)),
            this._teams.push({
              lane: e,
              id: t,
              background: pe,
              tower: N,
              viewport: M,
            });
        }
        updateViewportsScale() {
          let e = this.teamViewportsSizes;
          for (let { id: t, viewport: n, tower: r } of this._teams) {
            let i = e[t].width,
              a = e[t].height,
              o = i / nh(r.towerWidth),
              s = a / 750,
              c = Math.min(1, o, s);
            (n.viewportScale = c), (r.viewportScale = c);
          }
        }
        createConfetti(e) {
          let { viewport: t } = e,
            n = new E().beginFill(16777215).drawRect(0, 0, 20, 20).endFill(),
            r = this.app.renderer.generateTexture(n);
          this._confettiTextures.push(r);
          let i = new E().beginFill(16777215).drawRect(0, 0, 20, 40).endFill(),
            a = this.app.renderer.generateTexture(i);
          this._confettiTextures.push(a);
          let o = new E()
              .beginFill(16777215)
              .drawCircle(0, 0, 20 / 2)
              .endFill(),
            s = this.app.renderer.generateTexture(o);
          this._confettiTextures.push(s);
          let c = new pe({ textures: this._confettiTextures, config: _e({}) });
          (c.name = `confetti-emitter`),
            t.addChild(c),
            c.play(),
            (e.confettiEmitter = c);
        }
        getTeam(e) {
          return this._teams.find(({ id: t }) => t === e);
        }
        get teamViewportsSizes() {
          return Object.fromEntries(
            this._teams.map(({ id: e, viewport: t }) => {
              let { x: n, y: r, viewportWidth: i, viewportHeight: a } = t;
              return [e, { x: n, y: r, width: i, height: a }];
            })
          );
        }
        static preload(e) {
          let t = $m(e);
          super.preloadResources(t);
        }
        getResources() {
          return $m(this._skin);
        }
        gameSetup() {
          he(),
            (this._viewportsLayer = new D()),
            (this._viewportsLayer.name = `Viewports Layer`),
            this.addChild(this._viewportsLayer),
            (this._uiLayer = new D()),
            (this._uiLayer.name = `UI Layer`),
            this.addChild(this._uiLayer),
            (this._gradientTexture = this.createBackgroundGradientTexture()),
            (this.gameConfig?.towers ?? []).forEach(
              ({ id: e, theme: t }, n) => {
                this.createTeam(n, e, t);
              }
            ),
            this.updateViewportsScale(),
            this.updateViewportsCamera(!0);
        }
        gameResize(e, t) {
          let n = e / this._teamsNumber;
          for (let {
            lane: e,
            viewport: r,
            tower: i,
            confettiEmitter: a,
          } of this._teams)
            if (((r.x = Math.floor(e * n)), r.resize(Math.ceil(n), t), a)) {
              let { top: e, bottom: t } = r.viewportBounds;
              (a.x = i.x), (a.y = i.y + this._towerBottomOffset - (t - e) - Pg);
            }
          this.updateViewportsScale(), this.updateViewportsCamera(!0);
        }
        gameDestroy() {
          this._gradientTexture?.destroy(!0),
            this._confettiTextures.forEach((e) => {
              e.destroy(!0);
            });
        }
      });
  }))();
}
export {
  La as a,
  U as c,
  Rt as d,
  zt as f,
  Ia as i,
  W as l,
  V as m,
  Ig as n,
  Fa as o,
  Fr as p,
  Na as r,
  Pa as s,
  Fg as t,
  ja as u,
};
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/game-base-B1GqEX2D.js.map
