import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { Ct as t, Y as n, gn as r, pn as i } from "./lib-BTerfQ6O.js";
var a, o, s, c;
function l() {
  return (l = e(() => {
    n(),
      (a = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
}`),
      (o = `varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform vec4 filterClamp;

uniform float uAlpha;
uniform vec2 uThickness;
uniform vec4 uColor;
uniform bool uKnockout;

const float DOUBLE_PI = 2. * 3.14159265358979323846264;
const float ANGLE_STEP = \${angleStep};

float outlineMaxAlphaAtPos(vec2 pos) {
    if (uThickness.x == 0. || uThickness.y == 0.) {
        return 0.;
    }

    vec4 displacedColor;
    vec2 displacedPos;
    float maxAlpha = 0.;

    for (float angle = 0.; angle <= DOUBLE_PI; angle += ANGLE_STEP) {
        displacedPos.x = vTextureCoord.x + uThickness.x * cos(angle);
        displacedPos.y = vTextureCoord.y + uThickness.y * sin(angle);
        displacedColor = texture2D(uSampler, clamp(displacedPos, filterClamp.xy, filterClamp.zw));
        maxAlpha = max(maxAlpha, displacedColor.a);
    }

    return maxAlpha;
}

void main(void) {
    vec4 sourceColor = texture2D(uSampler, vTextureCoord);
    vec4 contentColor = sourceColor * float(!uKnockout);
    float outlineAlpha = uAlpha * outlineMaxAlphaAtPos(vTextureCoord.xy) * (1.-sourceColor.a);
    vec4 outlineColor = vec4(vec3(uColor) * outlineAlpha, outlineAlpha);
    gl_FragColor = contentColor + outlineColor;
}
`),
      (s = class extends t {
        constructor(e = 1, t = 0, n = 0.1, r = 1, i = !1) {
          super(a, o.replace(/\$\{angleStep\}/, s.getAngleStep(n))),
            (this._thickness = 1),
            (this._alpha = 1),
            (this._knockout = !1),
            (this.uniforms.uThickness = new Float32Array([0, 0])),
            (this.uniforms.uColor = new Float32Array([0, 0, 0, 1])),
            (this.uniforms.uAlpha = r),
            (this.uniforms.uKnockout = i),
            Object.assign(this, {
              thickness: e,
              color: t,
              quality: n,
              alpha: r,
              knockout: i,
            });
        }
        static getAngleStep(e) {
          let t = Math.max(e * s.MAX_SAMPLES, s.MIN_SAMPLES);
          return ((Math.PI * 2) / t).toFixed(7);
        }
        apply(e, t, n, r) {
          (this.uniforms.uThickness[0] = this._thickness / t._frame.width),
            (this.uniforms.uThickness[1] = this._thickness / t._frame.height),
            (this.uniforms.uAlpha = this._alpha),
            (this.uniforms.uKnockout = this._knockout),
            e.applyFilter(this, t, n, r);
        }
        get alpha() {
          return this._alpha;
        }
        set alpha(e) {
          this._alpha = e;
        }
        get color() {
          return r(this.uniforms.uColor);
        }
        set color(e) {
          i(e, this.uniforms.uColor);
        }
        get knockout() {
          return this._knockout;
        }
        set knockout(e) {
          this._knockout = e;
        }
        get thickness() {
          return this._thickness;
        }
        set thickness(e) {
          (this._thickness = e), (this.padding = e);
        }
      }),
      (c = s),
      (c.MIN_SAMPLES = 1),
      (c.MAX_SAMPLES = 100);
  }))();
}
export { l as n, c as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/filter-outline-DZFGJaGV.js.map
