import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import {
  B as t,
  Bt as n,
  Dt as r,
  H as i,
  Ln as a,
  On as o,
  U as s,
  Y as c,
  at as ee,
  ht as l,
  it as te,
  z as ne,
} from "./lib-BTerfQ6O.js";
import { u as re } from "./pixijs-game-zi5bgXGP.js";
function u(e, t) {
  if (!e) return;
  let n = Math.sin(e),
    r = Math.cos(e),
    i = t.x * r - t.y * n,
    a = t.x * n + t.y * r;
  (t.x = i), (t.y = a);
}
function d(e, t, n) {
  return (e << 16) | (t << 8) | n;
}
function f(e) {
  return Math.sqrt(e.x * e.x + e.y * e.y);
}
function ie(e) {
  let t = 1 / f(e);
  (e.x *= t), (e.y *= t);
}
function ae(e, t) {
  (e.x *= t), (e.y *= t);
}
function p(e, t) {
  (t ||= {}),
    e.charAt(0) === `#`
      ? (e = e.substr(1))
      : e.indexOf(`0x`) === 0 && (e = e.substr(2));
  let n;
  return (
    e.length === 8 && ((n = e.substr(0, 2)), (e = e.substr(2))),
    (t.r = parseInt(e.substr(0, 2), 16)),
    (t.g = parseInt(e.substr(2, 2), 16)),
    (t.b = parseInt(e.substr(4, 2), 16)),
    n && (t.a = parseInt(n, 16)),
    t
  );
}
function m(e) {
  let t = e.length,
    n = 1 / t;
  return function (r) {
    let i = (t * r) | 0,
      a = (r - i * n) * t,
      o = e[i] || e[t - 1];
    return o.s + a * (2 * (1 - a) * (o.cp - o.s) + a * (o.e - o.s));
  };
}
function oe(e) {
  return e
    ? ((e = e.toUpperCase().replace(/ /g, `_`)), o[e] || o.NORMAL)
    : o.NORMAL;
}
function se(e) {
  return (
    this.ease && (e = this.ease(e)),
    (this.first.next.value - this.first.value) * e + this.first.value
  );
}
function ce(e) {
  this.ease && (e = this.ease(e));
  let t = this.first.value,
    n = this.first.next.value;
  return d((n.r - t.r) * e + t.r, (n.g - t.g) * e + t.g, (n.b - t.b) * e + t.b);
}
function le(e) {
  this.ease && (e = this.ease(e));
  let t = this.first,
    n = t.next;
  for (; e > n.time; ) (t = n), (n = n.next);
  return (
    (e = (e - t.time) / (n.time - t.time)), (n.value - t.value) * e + t.value
  );
}
function ue(e) {
  this.ease && (e = this.ease(e));
  let t = this.first,
    n = t.next;
  for (; e > n.time; ) (t = n), (n = n.next);
  e = (e - t.time) / (n.time - t.time);
  let r = t.value,
    i = n.value;
  return d((i.r - r.r) * e + r.r, (i.g - r.g) * e + r.g, (i.b - r.b) * e + r.b);
}
function de(e) {
  this.ease && (e = this.ease(e));
  let t = this.first;
  for (; t.next && e > t.next.time; ) t = t.next;
  return t.value;
}
function fe(e) {
  this.ease && (e = this.ease(e));
  let t = this.first;
  for (; t.next && e > t.next.time; ) t = t.next;
  let n = t.value;
  return d(n.r, n.g, n.b);
}
function h(e) {
  let t = [];
  for (let n = 0; n < e.length; ++n) {
    let r = e[n];
    if (typeof r == `string`) t.push(_(r));
    else if (r instanceof l) t.push(r);
    else {
      let e = r.count || 1;
      for (
        r = typeof r.texture == `string` ? _(r.texture) : r.texture;
        e > 0;
        --e
      )
        t.push(r);
    }
  }
  return t;
}
function pe(e) {
  let t = e.match(B);
  for (let e = t.length - 1; e >= 0; --e)
    z.indexOf(t[e]) >= 0 && (t[e] = `Math.${t[e]}`);
  return (e = t.join(``)), Function(`x`, `return ${e};`);
}
var g,
  _,
  v,
  y,
  b,
  x,
  S,
  C,
  w,
  T,
  E,
  D,
  O,
  k,
  A,
  j,
  M,
  N,
  P,
  F,
  I,
  L,
  R,
  z,
  B,
  V,
  H,
  U,
  W,
  G,
  K,
  q,
  J,
  Y,
  X,
  Z,
  Q;
function $() {
  return ($ = e(() => {
    c(),
      a(),
      ne(),
      r(),
      te(),
      i(),
      (g = class e {
        constructor(e, t, n) {
          (this.value = e),
            (this.time = t),
            (this.next = null),
            (this.isStepped = !1),
            (this.ease = n ? (typeof n == `function` ? n : m(n)) : null);
        }
        static createList(t) {
          if (`list` in t) {
            let n = t.list,
              r,
              { value: i, time: a } = n[0],
              o = (r = new e(typeof i == `string` ? p(i) : i, a, t.ease));
            if (n.length > 2 || (n.length === 2 && n[1].value !== i))
              for (let t = 1; t < n.length; ++t) {
                let { value: i, time: a } = n[t];
                (r.next = new e(typeof i == `string` ? p(i) : i, a)),
                  (r = r.next);
              }
            return (o.isStepped = !!t.isStepped), o;
          }
          let n = new e(typeof t.start == `string` ? p(t.start) : t.start, 0);
          return (
            t.end !== t.start &&
              (n.next = new e(typeof t.end == `string` ? p(t.end) : t.end, 1)),
            n
          );
        }
      }),
      (_ = l.from),
      (v = Math.PI / 180),
      (y = class extends t {
        constructor(e) {
          super(),
            (this.prevChild = this.nextChild = null),
            (this.emitter = e),
            (this.config = {}),
            (this.anchor.x = this.anchor.y = 0.5),
            (this.maxLife = 0),
            (this.age = 0),
            (this.agePercent = 0),
            (this.oneOverLife = 0),
            (this.next = null),
            (this.prev = null),
            (this.init = this.init),
            (this.kill = this.kill);
        }
        init(e) {
          (this.maxLife = e),
            (this.age = this.agePercent = 0),
            (this.rotation = 0),
            (this.position.x = this.position.y = 0),
            (this.scale.x = this.scale.y = 1),
            (this.tint = 16777215),
            (this.alpha = 1),
            (this.oneOverLife = 1 / this.maxLife),
            (this.visible = !0);
        }
        kill() {
          this.emitter.recycle(this);
        }
        destroy() {
          this.parent && this.parent.removeChild(this),
            (this.emitter = this.next = this.prev = null),
            super.destroy();
        }
      }),
      (function (e) {
        (e[(e.Spawn = 0)] = `Spawn`),
          (e[(e.Normal = 2)] = `Normal`),
          (e[(e.Late = 5)] = `Late`);
      })((b ||= {})),
      (x = ee.shared),
      (S = Symbol(`Position particle per emitter position`)),
      (C = class e {
        constructor(e, t) {
          (this.initBehaviors = []),
            (this.updateBehaviors = []),
            (this.recycleBehaviors = []),
            (this.minLifetime = 0),
            (this.maxLifetime = 0),
            (this.customEase = null),
            (this._frequency = 1),
            (this.spawnChance = 1),
            (this.maxParticles = 1e3),
            (this.emitterLifetime = -1),
            (this.spawnPos = new n()),
            (this.particlesPerWave = 1),
            (this.rotation = 0),
            (this.ownerPos = new n()),
            (this._prevEmitterPos = new n()),
            (this._prevPosIsValid = !1),
            (this._posChanged = !1),
            (this._parent = null),
            (this.addAtBack = !1),
            (this.particleCount = 0),
            (this._emit = !1),
            (this._spawnTimer = 0),
            (this._emitterLife = -1),
            (this._activeParticlesFirst = null),
            (this._activeParticlesLast = null),
            (this._poolFirst = null),
            (this._origConfig = null),
            (this._autoUpdate = !1),
            (this._destroyWhenComplete = !1),
            (this._completeCallback = null),
            (this.parent = e),
            t && this.init(t),
            (this.recycle = this.recycle),
            (this.update = this.update),
            (this.rotate = this.rotate),
            (this.updateSpawnPos = this.updateSpawnPos),
            (this.updateOwnerPos = this.updateOwnerPos);
        }
        static registerBehavior(t) {
          e.knownBehaviors[t.type] = t;
        }
        get frequency() {
          return this._frequency;
        }
        set frequency(e) {
          this._frequency = typeof e == `number` && e > 0 ? e : 1;
        }
        get parent() {
          return this._parent;
        }
        set parent(e) {
          this.cleanup(), (this._parent = e);
        }
        init(t) {
          if (!t) return;
          this.cleanup(),
            (this._origConfig = t),
            (this.minLifetime = t.lifetime.min),
            (this.maxLifetime = t.lifetime.max),
            (this.customEase = t.ease
              ? typeof t.ease == `function`
                ? t.ease
                : m(t.ease)
              : null),
            (this.particlesPerWave = 1),
            t.particlesPerWave &&
              t.particlesPerWave > 1 &&
              (this.particlesPerWave = t.particlesPerWave),
            (this.frequency = t.frequency),
            (this.spawnChance =
              typeof t.spawnChance == `number` && t.spawnChance > 0
                ? t.spawnChance
                : 1),
            (this.emitterLifetime = t.emitterLifetime || -1),
            (this.maxParticles = t.maxParticles > 0 ? t.maxParticles : 1e3),
            (this.addAtBack = !!t.addAtBack),
            (this.rotation = 0),
            this.ownerPos.set(0),
            t.pos ? this.spawnPos.copyFrom(t.pos) : this.spawnPos.set(0),
            this._prevEmitterPos.copyFrom(this.spawnPos),
            (this._prevPosIsValid = !1),
            (this._spawnTimer = 0),
            (this.emit = t.emit === void 0 || !!t.emit),
            (this.autoUpdate = !!t.autoUpdate);
          let n = t.behaviors
            .map((t) => {
              let n = e.knownBehaviors[t.type];
              return n
                ? new n(t.config)
                : (console.error(`Unknown behavior: ${t.type}`), null);
            })
            .filter((e) => !!e);
          n.push(S),
            n.sort((e, t) =>
              e === S
                ? t.order === b.Spawn
                  ? 1
                  : -1
                : t === S
                ? e.order === b.Spawn
                  ? -1
                  : 1
                : e.order - t.order
            ),
            (this.initBehaviors = n.slice()),
            (this.updateBehaviors = n.filter(
              (e) => e !== S && e.updateParticle
            )),
            (this.recycleBehaviors = n.filter(
              (e) => e !== S && e.recycleParticle
            ));
        }
        getBehavior(t) {
          return (
            (e.knownBehaviors[t] &&
              this.initBehaviors.find(
                (n) => n instanceof e.knownBehaviors[t]
              )) ||
            null
          );
        }
        fillPool(e) {
          for (; e > 0; --e) {
            let e = new y(this);
            (e.next = this._poolFirst), (this._poolFirst = e);
          }
        }
        recycle(e, t = !1) {
          for (let n = 0; n < this.recycleBehaviors.length; ++n)
            this.recycleBehaviors[n].recycleParticle(e, !t);
          e.next && (e.next.prev = e.prev),
            e.prev && (e.prev.next = e.next),
            e === this._activeParticlesLast &&
              (this._activeParticlesLast = e.prev),
            e === this._activeParticlesFirst &&
              (this._activeParticlesFirst = e.next),
            (e.prev = null),
            (e.next = this._poolFirst),
            (this._poolFirst = e),
            e.parent && e.parent.removeChild(e),
            --this.particleCount;
        }
        rotate(e) {
          if (this.rotation === e) return;
          let t = e - this.rotation;
          (this.rotation = e), u(t, this.spawnPos), (this._posChanged = !0);
        }
        updateSpawnPos(e, t) {
          (this._posChanged = !0), (this.spawnPos.x = e), (this.spawnPos.y = t);
        }
        updateOwnerPos(e, t) {
          (this._posChanged = !0), (this.ownerPos.x = e), (this.ownerPos.y = t);
        }
        resetPositionTracking() {
          this._prevPosIsValid = !1;
        }
        get emit() {
          return this._emit;
        }
        set emit(e) {
          (this._emit = !!e), (this._emitterLife = this.emitterLifetime);
        }
        get autoUpdate() {
          return this._autoUpdate;
        }
        set autoUpdate(e) {
          this._autoUpdate && !e
            ? x.remove(this.update, this)
            : !this._autoUpdate && e && x.add(this.update, this),
            (this._autoUpdate = !!e);
        }
        playOnceAndDestroy(e) {
          (this.autoUpdate = !0),
            (this.emit = !0),
            (this._destroyWhenComplete = !0),
            (this._completeCallback = e);
        }
        playOnce(e) {
          (this.emit = !0), (this._completeCallback = e);
        }
        update(e) {
          if ((this._autoUpdate && (e = x.elapsedMS * 0.001), !this._parent))
            return;
          for (let t = this._activeParticlesFirst, n; t; t = n)
            if (((n = t.next), (t.age += e), t.age > t.maxLife || t.age < 0))
              this.recycle(t);
            else {
              let n = t.age * t.oneOverLife;
              this.customEase &&
                (n =
                  this.customEase.length === 4
                    ? this.customEase(n, 0, 1, 1)
                    : this.customEase(n)),
                (t.agePercent = n);
              for (let n = 0; n < this.updateBehaviors.length; ++n)
                if (this.updateBehaviors[n].updateParticle(t, e)) {
                  this.recycle(t);
                  break;
                }
            }
          let t, n;
          this._prevPosIsValid &&
            ((t = this._prevEmitterPos.x), (n = this._prevEmitterPos.y));
          let r = this.ownerPos.x + this.spawnPos.x,
            i = this.ownerPos.y + this.spawnPos.y;
          if (this._emit)
            for (this._spawnTimer -= e < 0 ? 0 : e; this._spawnTimer <= 0; ) {
              if (
                this._emitterLife >= 0 &&
                ((this._emitterLife -= this._frequency), this._emitterLife <= 0)
              ) {
                (this._spawnTimer = 0),
                  (this._emitterLife = 0),
                  (this.emit = !1);
                break;
              }
              if (this.particleCount >= this.maxParticles) {
                this._spawnTimer += this._frequency;
                continue;
              }
              let a, o;
              if (this._prevPosIsValid && this._posChanged) {
                let s = 1 + this._spawnTimer / e;
                (a = (r - t) * s + t), (o = (i - n) * s + n);
              } else (a = r), (o = i);
              let s = null,
                c = null;
              for (
                let e = Math.min(
                    this.particlesPerWave,
                    this.maxParticles - this.particleCount
                  ),
                  t = 0;
                t < e;
                ++t
              ) {
                if (this.spawnChance < 1 && Math.random() >= this.spawnChance)
                  continue;
                let e;
                if (
                  ((e =
                    this.minLifetime === this.maxLifetime
                      ? this.minLifetime
                      : Math.random() * (this.maxLifetime - this.minLifetime) +
                        this.minLifetime),
                  -this._spawnTimer >= e)
                )
                  continue;
                let t;
                this._poolFirst
                  ? ((t = this._poolFirst),
                    (this._poolFirst = this._poolFirst.next),
                    (t.next = null))
                  : (t = new y(this)),
                  t.init(e),
                  this.addAtBack
                    ? this._parent.addChildAt(t, 0)
                    : this._parent.addChild(t),
                  s ? ((c.next = t), (t.prev = c), (c = t)) : (c = s = t),
                  ++this.particleCount;
              }
              if (s) {
                this._activeParticlesLast
                  ? ((this._activeParticlesLast.next = s),
                    (s.prev = this._activeParticlesLast),
                    (this._activeParticlesLast = c))
                  : ((this._activeParticlesFirst = s),
                    (this._activeParticlesLast = c));
                for (let e = 0; e < this.initBehaviors.length; ++e) {
                  let t = this.initBehaviors[e];
                  if (t === S)
                    for (let e = s, t; e; e = t) {
                      (t = e.next),
                        this.rotation !== 0 &&
                          (u(this.rotation, e.position),
                          (e.rotation += this.rotation)),
                        (e.position.x += a),
                        (e.position.y += o),
                        (e.age += -this._spawnTimer);
                      let n = e.age * e.oneOverLife;
                      this.customEase &&
                        (n =
                          this.customEase.length === 4
                            ? this.customEase(n, 0, 1, 1)
                            : this.customEase(n)),
                        (e.agePercent = n);
                    }
                  else t.initParticles(s);
                }
                for (let e = s, t; e; e = t) {
                  t = e.next;
                  for (let t = 0; t < this.updateBehaviors.length; ++t)
                    if (
                      this.updateBehaviors[t].updateParticle(
                        e,
                        -this._spawnTimer
                      )
                    ) {
                      this.recycle(e);
                      break;
                    }
                }
              }
              this._spawnTimer += this._frequency;
            }
          if (
            ((this._posChanged &&=
              ((this._prevEmitterPos.x = r),
              (this._prevEmitterPos.y = i),
              (this._prevPosIsValid = !0),
              !1)),
            !this._emit && !this._activeParticlesFirst)
          ) {
            if (this._completeCallback) {
              let e = this._completeCallback;
              (this._completeCallback = null), e();
            }
            this._destroyWhenComplete && this.destroy();
          }
        }
        emitNow() {
          let e = this.ownerPos.x + this.spawnPos.x,
            t = this.ownerPos.y + this.spawnPos.y,
            n = null,
            r = null;
          for (
            let e = Math.min(
                this.particlesPerWave,
                this.maxParticles - this.particleCount
              ),
              t = 0;
            t < e;
            ++t
          ) {
            if (this.spawnChance < 1 && Math.random() >= this.spawnChance)
              continue;
            let e;
            this._poolFirst
              ? ((e = this._poolFirst),
                (this._poolFirst = this._poolFirst.next),
                (e.next = null))
              : (e = new y(this));
            let t;
            (t =
              this.minLifetime === this.maxLifetime
                ? this.minLifetime
                : Math.random() * (this.maxLifetime - this.minLifetime) +
                  this.minLifetime),
              e.init(t),
              this.addAtBack
                ? this._parent.addChildAt(e, 0)
                : this._parent.addChild(e),
              n ? ((r.next = e), (e.prev = r), (r = e)) : (r = n = e),
              ++this.particleCount;
          }
          if (n) {
            this._activeParticlesLast
              ? ((this._activeParticlesLast.next = n),
                (n.prev = this._activeParticlesLast),
                (this._activeParticlesLast = r))
              : ((this._activeParticlesFirst = n),
                (this._activeParticlesLast = r));
            for (let r = 0; r < this.initBehaviors.length; ++r) {
              let i = this.initBehaviors[r];
              if (i === S)
                for (let r = n, i; r; r = i)
                  (i = r.next),
                    this.rotation !== 0 &&
                      (u(this.rotation, r.position),
                      (r.rotation += this.rotation)),
                    (r.position.x += e),
                    (r.position.y += t);
              else i.initParticles(n);
            }
          }
        }
        cleanup() {
          let e, t;
          for (e = this._activeParticlesFirst; e; e = t)
            (t = e.next), this.recycle(e, !0);
          (this._activeParticlesFirst = this._activeParticlesLast = null),
            (this.particleCount = 0);
        }
        get destroyed() {
          return !(this._parent && this.initBehaviors.length);
        }
        destroy() {
          (this.autoUpdate = !1), this.cleanup();
          let e;
          for (let t = this._poolFirst; t; t = e) (e = t.next), t.destroy();
          (this._poolFirst =
            this._parent =
            this.spawnPos =
            this.ownerPos =
            this.customEase =
            this._completeCallback =
              null),
            (this.initBehaviors.length =
              this.updateBehaviors.length =
              this.recycleBehaviors.length =
                0);
        }
      }),
      (C.knownBehaviors = {}),
      (w = class {
        constructor(e) {
          (this.x = e.x), (this.y = e.y), (this.w = e.w), (this.h = e.h);
        }
        getRandPos(e) {
          (e.x = Math.random() * this.w + this.x),
            (e.y = Math.random() * this.h + this.y);
        }
      }),
      (w.type = `rect`),
      (w.editorConfig = null),
      (T = class {
        constructor(e) {
          (this.x = e.x || 0),
            (this.y = e.y || 0),
            (this.radius = e.radius),
            (this.innerRadius = e.innerRadius || 0),
            (this.rotation = !!e.affectRotation);
        }
        getRandPos(e) {
          (e.x =
            this.innerRadius === this.radius
              ? this.radius
              : Math.random() * (this.radius - this.innerRadius) +
                this.innerRadius),
            (e.y = 0);
          let t = Math.random() * Math.PI * 2;
          this.rotation && (e.rotation += t),
            u(t, e.position),
            (e.position.x += this.x),
            (e.position.y += this.y);
        }
      }),
      (T.type = `torus`),
      (T.editorConfig = null),
      (E = class {
        constructor(e) {
          (this.segments = []),
            (this.countingLengths = []),
            (this.totalLength = 0),
            this.init(e);
        }
        init(e) {
          if (!e || !e.length)
            this.segments.push({
              p1: { x: 0, y: 0 },
              p2: { x: 0, y: 0 },
              l: 0,
            });
          else if (Array.isArray(e[0]))
            for (let t = 0; t < e.length; ++t) {
              let n = e[t],
                r = n[0];
              for (let e = 1; e < n.length; ++e) {
                let t = n[e];
                this.segments.push({ p1: r, p2: t, l: 0 }), (r = t);
              }
            }
          else {
            let t = e[0];
            for (let n = 1; n < e.length; ++n) {
              let r = e[n];
              this.segments.push({ p1: t, p2: r, l: 0 }), (t = r);
            }
          }
          for (let e = 0; e < this.segments.length; ++e) {
            let { p1: t, p2: n } = this.segments[e],
              r = Math.sqrt(
                (n.x - t.x) * (n.x - t.x) + (n.y - t.y) * (n.y - t.y)
              );
            (this.segments[e].l = r),
              (this.totalLength += r),
              this.countingLengths.push(this.totalLength);
          }
        }
        getRandPos(e) {
          let t = Math.random() * this.totalLength,
            n,
            r;
          if (this.segments.length === 1) (n = this.segments[0]), (r = t);
          else
            for (let e = 0; e < this.countingLengths.length; ++e)
              if (t < this.countingLengths[e]) {
                (n = this.segments[e]),
                  (r = e === 0 ? t : t - this.countingLengths[e - 1]);
                break;
              }
          r /= n.l || 1;
          let { p1: i, p2: a } = n;
          (e.x = i.x + r * (a.x - i.x)), (e.y = i.y + r * (a.y - i.y));
        }
      }),
      (E.type = `polygonalChain`),
      (E.editorConfig = null),
      (D = class {
        constructor(e) {
          (this.order = b.Late),
            (this.minStart = e.minStart),
            (this.maxStart = e.maxStart),
            (this.accel = e.accel),
            (this.rotate = !!e.rotate),
            (this.maxSpeed = e.maxSpeed ?? 0);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e =
              Math.random() * (this.maxStart - this.minStart) + this.minStart;
            t.config.velocity
              ? t.config.velocity.set(e, 0)
              : (t.config.velocity = new n(e, 0)),
              u(t.rotation, t.config.velocity),
              (t = t.next);
          }
        }
        updateParticle(e, t) {
          let n = e.config.velocity,
            r = n.x,
            i = n.y;
          if (
            ((n.x += this.accel.x * t),
            (n.y += this.accel.y * t),
            this.maxSpeed)
          ) {
            let e = f(n);
            e > this.maxSpeed && ae(n, this.maxSpeed / e);
          }
          (e.x += ((r + n.x) / 2) * t),
            (e.y += ((i + n.y) / 2) * t),
            this.rotate && (e.rotation = Math.atan2(n.y, n.x));
        }
      }),
      (D.type = `moveAcceleration`),
      (D.editorConfig = null),
      (O = class {
        constructor(e = !1) {
          (this.first = null),
            (this.isColor = !!e),
            (this.interpolate = null),
            (this.ease = null);
        }
        reset(e) {
          (this.first = e),
            (this.interpolate =
              e.next && e.next.time >= 1
                ? this.isColor
                  ? ce
                  : se
                : e.isStepped
                ? this.isColor
                  ? fe
                  : de
                : this.isColor
                ? ue
                : le),
            (this.ease = this.first.ease);
        }
      }),
      (k = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.list = new O(!1)),
            this.list.reset(g.createList(e.alpha));
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.alpha = this.list.first.value), (t = t.next);
        }
        updateParticle(e) {
          e.alpha = this.list.interpolate(e.agePercent);
        }
      }),
      (k.type = `alpha`),
      (k.editorConfig = null),
      (A = class {
        constructor(e) {
          (this.order = b.Normal), (this.value = e.alpha);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.alpha = this.value), (t = t.next);
        }
      }),
      (A.type = `alphaStatic`),
      (A.editorConfig = null),
      (j = class {
        constructor(e) {
          (this.order = b.Normal), (this.anims = []);
          for (let t = 0; t < e.anims.length; ++t) {
            let n = e.anims[t],
              r = h(n.textures),
              i = n.framerate < 0 ? -1 : n.framerate > 0 ? n.framerate : 60,
              a = {
                textures: r,
                duration: i > 0 ? r.length / i : 0,
                framerate: i,
                loop: i > 0 && !!n.loop,
              };
            this.anims.push(a);
          }
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.floor(Math.random() * this.anims.length),
              n = (t.config.anim = this.anims[e]);
            (t.texture = n.textures[0]),
              (t.config.animElapsed = 0),
              n.framerate === -1
                ? ((t.config.animDuration = t.maxLife),
                  (t.config.animFramerate = n.textures.length / t.maxLife))
                : ((t.config.animDuration = n.duration),
                  (t.config.animFramerate = n.framerate)),
              (t = t.next);
          }
        }
        updateParticle(e, t) {
          let n = e.config,
            r = n.anim;
          (n.animElapsed += t),
            n.animElapsed >= n.animDuration &&
              (n.anim.loop
                ? (n.animElapsed %= n.animDuration)
                : (n.animElapsed = n.animDuration - 1e-6));
          let i = (n.animElapsed * n.animFramerate + 1e-7) | 0;
          e.texture =
            r.textures[i] || r.textures[r.textures.length - 1] || l.EMPTY;
        }
      }),
      (j.type = `animatedRandom`),
      (j.editorConfig = null),
      (M = class {
        constructor(e) {
          this.order = b.Normal;
          let t = e.anim,
            n = h(t.textures),
            r = t.framerate < 0 ? -1 : t.framerate > 0 ? t.framerate : 60;
          this.anim = {
            textures: n,
            duration: r > 0 ? n.length / r : 0,
            framerate: r,
            loop: r > 0 && !!t.loop,
          };
        }
        initParticles(e) {
          let t = e,
            n = this.anim;
          for (; t; )
            (t.texture = n.textures[0]),
              (t.config.animElapsed = 0),
              n.framerate === -1
                ? ((t.config.animDuration = t.maxLife),
                  (t.config.animFramerate = n.textures.length / t.maxLife))
                : ((t.config.animDuration = n.duration),
                  (t.config.animFramerate = n.framerate)),
              (t = t.next);
        }
        updateParticle(e, t) {
          let n = this.anim,
            r = e.config;
          (r.animElapsed += t),
            r.animElapsed >= r.animDuration &&
              (n.loop
                ? (r.animElapsed %= r.animDuration)
                : (r.animElapsed = r.animDuration - 1e-6));
          let i = (r.animElapsed * r.animFramerate + 1e-7) | 0;
          e.texture =
            n.textures[i] || n.textures[n.textures.length - 1] || l.EMPTY;
        }
      }),
      (M.type = `animatedSingle`),
      (M.editorConfig = null),
      (N = class {
        constructor(e) {
          (this.order = b.Normal), (this.value = e.blendMode);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.blendMode = oe(this.value)), (t = t.next);
        }
      }),
      (N.type = `blendMode`),
      (N.editorConfig = null),
      (P = class {
        constructor(e) {
          (this.order = b.Spawn),
            (this.spacing = e.spacing * v),
            (this.start = e.start * v),
            (this.distance = e.distance);
        }
        initParticles(e) {
          let t = 0,
            n = e;
          for (; n; ) {
            let e;
            (e = this.spacing
              ? this.start + this.spacing * t
              : Math.random() * Math.PI * 2),
              (n.rotation = e),
              this.distance &&
                ((n.position.x = this.distance), u(e, n.position)),
              (n = n.next),
              ++t;
          }
        }
      }),
      (P.type = `spawnBurst`),
      (P.editorConfig = null),
      (F = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.list = new O(!0)),
            this.list.reset(g.createList(e.color));
        }
        initParticles(e) {
          let t = e,
            n = this.list.first.value,
            r = d(n.r, n.g, n.b);
          for (; t; ) (t.tint = r), (t = t.next);
        }
        updateParticle(e) {
          e.tint = this.list.interpolate(e.agePercent);
        }
      }),
      (F.type = `color`),
      (F.editorConfig = null),
      (I = class {
        constructor(e) {
          this.order = b.Normal;
          let t = e.color;
          t.charAt(0) === `#`
            ? (t = t.substr(1))
            : t.indexOf(`0x`) === 0 && (t = t.substr(2)),
            (this.value = parseInt(t, 16));
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.tint = this.value), (t = t.next);
        }
      }),
      (I.type = `colorStatic`),
      (I.editorConfig = null),
      (L = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.index = 0),
            (this.textures = e.textures.map((e) =>
              typeof e == `string` ? _(e) : e
            ));
        }
        initParticles(e) {
          let t = e;
          for (; t; )
            (t.texture = this.textures[this.index]),
              ++this.index >= this.textures.length && (this.index = 0),
              (t = t.next);
        }
      }),
      (L.type = `textureOrdered`),
      (L.editorConfig = null),
      (R = new n()),
      (z =
        `E.LN2.LN10.LOG2E.LOG10E.PI.SQRT1_2.SQRT2.abs.acos.acosh.asin.asinh.atan.atanh.atan2.cbrt.ceil.cos.cosh.exp.expm1.floor.fround.hypot.log.log1p.log10.log2.max.min.pow.random.round.sign.sin.sinh.sqrt.tan.tanh`.split(
          `.`
        )),
      (B = new RegExp(
        [`[01234567890\\.\\*\\-\\+\\/\\(\\)x ,]`].concat(z).join(`|`),
        `g`
      )),
      (V = class {
        constructor(e) {
          if (((this.order = b.Late), e.path))
            if (typeof e.path == `function`) this.path = e.path;
            else
              try {
                this.path = pe(e.path);
              } catch {
                this.path = null;
              }
          else this.path = (e) => e;
          (this.list = new O(!1)),
            this.list.reset(g.createList(e.speed)),
            (this.minMult = e.minMult ?? 1);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            (t.config.initRotation = t.rotation),
              t.config.initPosition
                ? t.config.initPosition.copyFrom(t.position)
                : (t.config.initPosition = new n(t.x, t.y)),
              (t.config.movement = 0);
            let e = Math.random() * (1 - this.minMult) + this.minMult;
            (t.config.speedMult = e), (t = t.next);
          }
        }
        updateParticle(e, t) {
          let n = this.list.interpolate(e.agePercent) * e.config.speedMult;
          (e.config.movement += n * t),
            (R.x = e.config.movement),
            (R.y = this.path(R.x)),
            u(e.config.initRotation, R),
            (e.position.x = e.config.initPosition.x + R.x),
            (e.position.y = e.config.initPosition.y + R.y);
        }
      }),
      (V.type = `movePath`),
      (V.editorConfig = null),
      (H = class {
        constructor() {
          this.order = b.Spawn;
        }
        initParticles(e) {}
      }),
      (H.type = `spawnPoint`),
      (H.editorConfig = null),
      (U = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.textures = e.textures.map((e) =>
              typeof e == `string` ? _(e) : e
            ));
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.floor(Math.random() * this.textures.length);
            (t.texture = this.textures[e]), (t = t.next);
          }
        }
      }),
      (U.type = `textureRandom`),
      (U.editorConfig = null),
      (W = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.minStart = e.minStart * v),
            (this.maxStart = e.maxStart * v),
            (this.minSpeed = e.minSpeed * v),
            (this.maxSpeed = e.maxSpeed * v),
            (this.accel = e.accel * v);
        }
        initParticles(e) {
          let t = e;
          for (; t; )
            this.minStart === this.maxStart
              ? (t.rotation += this.maxStart)
              : (t.rotation +=
                  Math.random() * (this.maxStart - this.minStart) +
                  this.minStart),
              (t.config.rotSpeed =
                Math.random() * (this.maxSpeed - this.minSpeed) +
                this.minSpeed),
              (t = t.next);
        }
        updateParticle(e, t) {
          if (this.accel) {
            let n = e.config.rotSpeed;
            (e.config.rotSpeed += this.accel * t),
              (e.rotation += ((e.config.rotSpeed + n) / 2) * t);
          } else e.rotation += e.config.rotSpeed * t;
        }
      }),
      (W.type = `rotation`),
      (W.editorConfig = null),
      (G = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.min = e.min * v),
            (this.max = e.max * v);
        }
        initParticles(e) {
          let t = e;
          for (; t; )
            this.min === this.max
              ? (t.rotation += this.max)
              : (t.rotation +=
                  Math.random() * (this.max - this.min) + this.min),
              (t = t.next);
        }
      }),
      (G.type = `rotationStatic`),
      (G.editorConfig = null),
      (K = class {
        constructor(e) {
          (this.order = b.Late + 1), (this.rotation = (e.rotation || 0) * v);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.rotation = this.rotation), (t = t.next);
        }
      }),
      (K.type = `noRotation`),
      (K.editorConfig = null),
      (q = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.list = new O(!1)),
            this.list.reset(g.createList(e.scale)),
            (this.minMult = e.minMult ?? 1);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.random() * (1 - this.minMult) + this.minMult;
            (t.config.scaleMult = e),
              (t.scale.x = t.scale.y = this.list.first.value * e),
              (t = t.next);
          }
        }
        updateParticle(e) {
          e.scale.x = e.scale.y =
            this.list.interpolate(e.agePercent) * e.config.scaleMult;
        }
      }),
      (q.type = `scale`),
      (q.editorConfig = null),
      (J = class {
        constructor(e) {
          (this.order = b.Normal), (this.min = e.min), (this.max = e.max);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.random() * (this.max - this.min) + this.min;
            (t.scale.x = t.scale.y = e), (t = t.next);
          }
        }
      }),
      (J.type = `scaleStatic`),
      (J.editorConfig = null),
      (Y = class e {
        constructor(t) {
          this.order = b.Spawn;
          let n = e.shapes[t.type];
          if (!n) throw Error(`No shape found with type '${t.type}'`);
          this.shape = new n(t.data);
        }
        static registerShape(t, n) {
          e.shapes[n || t.type] = t;
        }
        initParticles(e) {
          let t = e;
          for (; t; ) this.shape.getRandPos(t), (t = t.next);
        }
      }),
      (Y.type = `spawnShape`),
      (Y.editorConfig = null),
      (Y.shapes = {}),
      Y.registerShape(E),
      Y.registerShape(w),
      Y.registerShape(T),
      Y.registerShape(T, `circle`),
      (X = class {
        constructor(e) {
          (this.order = b.Normal),
            (this.texture =
              typeof e.texture == `string` ? _(e.texture) : e.texture);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) (t.texture = this.texture), (t = t.next);
        }
      }),
      (X.type = `textureSingle`),
      (X.editorConfig = null),
      (Z = class {
        constructor(e) {
          (this.order = b.Late),
            (this.list = new O(!1)),
            this.list.reset(g.createList(e.speed)),
            (this.minMult = e.minMult ?? 1);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.random() * (1 - this.minMult) + this.minMult;
            (t.config.speedMult = e),
              t.config.velocity
                ? t.config.velocity.set(this.list.first.value * e, 0)
                : (t.config.velocity = new n(this.list.first.value * e, 0)),
              u(t.rotation, t.config.velocity),
              (t = t.next);
          }
        }
        updateParticle(e, t) {
          let n = this.list.interpolate(e.agePercent) * e.config.speedMult,
            r = e.config.velocity;
          ie(r), ae(r, n), (e.x += r.x * t), (e.y += r.y * t);
        }
      }),
      (Z.type = `moveSpeed`),
      (Z.editorConfig = null),
      (Q = class {
        constructor(e) {
          (this.order = b.Late), (this.min = e.min), (this.max = e.max);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.random() * (this.max - this.min) + this.min;
            t.config.velocity
              ? t.config.velocity.set(e, 0)
              : (t.config.velocity = new n(e, 0)),
              u(t.rotation, t.config.velocity),
              (t = t.next);
          }
        }
        updateParticle(e, t) {
          let n = e.config.velocity;
          (e.x += n.x * t), (e.y += n.y * t);
        }
      }),
      (Q.type = `moveSpeedStatic`),
      (Q.editorConfig = null),
      C.registerBehavior(D),
      C.registerBehavior(k),
      C.registerBehavior(A),
      C.registerBehavior(j),
      C.registerBehavior(M),
      C.registerBehavior(N),
      C.registerBehavior(P),
      C.registerBehavior(F),
      C.registerBehavior(I),
      C.registerBehavior(L),
      C.registerBehavior(V),
      C.registerBehavior(H),
      C.registerBehavior(U),
      C.registerBehavior(W),
      C.registerBehavior(G),
      C.registerBehavior(K),
      C.registerBehavior(q),
      C.registerBehavior(J),
      C.registerBehavior(Y),
      C.registerBehavior(X),
      C.registerBehavior(Z),
      C.registerBehavior(Q);
  }))();
}
var me;
function he() {
  return (he = e(() => {
    re(),
      $(),
      (me = class extends s {
        constructor({ textures: e, config: t, mode: n = `trail` }) {
          super(), (this.textures = Array.isArray(e) ? e : [e]);
          let r = t.behaviors.filter((e) => {
            switch (e.type) {
              case `animatedRandom`:
              case `animatedSingle`:
              case `textureOrdered`:
              case `textureRandom`:
              case `textureSingle`:
                return (
                  console.warn(
                    `PixiJSParticleEmitterCtor: textures behaviors are not supported in config. Behavior will be omitted:`,
                    e
                  ),
                  !1
                );
              default:
                return !0;
            }
          });
          (this.config = {
            ...t,
            behaviors: [
              ...r,
              { type: `textureRandom`, config: { textures: this.textures } },
            ],
          }),
            (this.mode = n),
            (this.particleParent = new s()),
            this.addChild(this.particleParent),
            (this.emitter = new C(this, this.config)),
            (this.emitter.emit = !1);
        }
        get x() {
          return this.mode === `trail` ? this.particleParent.x : super.x;
        }
        set x(e) {
          if (this.mode === `trail`) {
            (this.particleParent.x = e),
              this.emitter.updateOwnerPos(
                this.particleParent.x,
                this.particleParent.y
              ),
              this.emitter.resetPositionTracking();
            return;
          }
          super.x = e;
        }
        get y() {
          return this.mode === `trail` ? this.particleParent.y : super.y;
        }
        set y(e) {
          if (this.mode === `trail`) {
            (this.particleParent.y = e),
              this.emitter.updateOwnerPos(
                this.particleParent.x,
                this.particleParent.y
              ),
              this.emitter.resetPositionTracking();
            return;
          }
          super.y = e;
        }
        get position() {
          return this.mode === `trail`
            ? this.particleParent.position
            : super.position;
        }
        set position(e) {
          if (this.mode === `trail`) {
            (this.particleParent.position = e),
              this.emitter.updateOwnerPos(
                this.particleParent.x,
                this.particleParent.y
              );
            return;
          }
          super.position = e;
        }
        update(e) {
          this.emitter.update(e);
        }
        play(e) {
          if (
            e &&
            (this.config.emitterLifetime === void 0 ||
              this.config.emitterLifetime <= 0)
          ) {
            console.warn(
              `playOnce() will never end when emitterLifetime is infinite (onComplete() will never be called)`
            ),
              this.emitter.playOnce();
            return;
          }
          this.emitter.playOnce(e);
        }
        playOne() {
          this.emitter.emitNow();
        }
        stop() {
          this.emitter.emit = !1;
        }
        getBehavior(e) {
          return this.emitter.getBehavior(e);
        }
        destroy(e) {
          if (
            (this.emitter.destroy(),
            e === !0 || (typeof e == `object` && (e.baseTexture || e.texture)))
          ) {
            let t = e === !0 || e.baseTexture;
            this.textures.forEach((e) => e.destroy(t));
          }
          super.destroy(e);
        }
      });
  }))();
}
export { g as a, O as i, he as n, $ as o, C as r, me as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/pixijs-particle-emitter-B_TZCnbP.js.map
