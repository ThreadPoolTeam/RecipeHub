import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
function t() {
  return (t = e(() => {
    (function () {
      let e = document.createElement(`link`).relList;
      if (e && e.supports && e.supports(`modulepreload`)) return;
      for (let e of document.querySelectorAll(`link[rel="modulepreload"]`))
        n(e);
      new MutationObserver((e) => {
        for (let t of e)
          if (t.type === `childList`)
            for (let e of t.addedNodes)
              e.tagName === `LINK` && e.rel === `modulepreload` && n(e);
      }).observe(document, { childList: !0, subtree: !0 });
      function t(e) {
        let t = {};
        return (
          e.integrity && (t.integrity = e.integrity),
          e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy),
          (t.credentials =
            e.crossOrigin === `use-credentials`
              ? `include`
              : e.crossOrigin === `anonymous`
              ? `omit`
              : `same-origin`),
          t
        );
      }
      function n(e) {
        if (e.ep) return;
        e.ep = !0;
        let n = t(e);
        fetch(e.href, n);
      }
    })();
  }))();
}
var n,
  r,
  i,
  a,
  o = e(() => {
    (n = `modulepreload`),
      (r = function (e) {
        return `https://assets-cdn.kahoot.it/solo/` + e;
      }),
      (i = {}),
      (a = function (e, t, a) {
        let o = Promise.resolve();
        if (t && t.length > 0) {
          let e = document.getElementsByTagName(`link`),
            s = document.querySelector(`meta[property=csp-nonce]`),
            c = s?.nonce || s?.getAttribute(`nonce`);
          function l(e) {
            return Promise.all(
              e.map((e) =>
                Promise.resolve(e).then(
                  (e) => ({ status: `fulfilled`, value: e }),
                  (e) => ({ status: `rejected`, reason: e })
                )
              )
            );
          }
          function u(e) {
            return import.meta.resolve
              ? import.meta.resolve(e)
              : new URL(e, import.meta.url).href;
          }
          o = l(
            t.map((t) => {
              if (((t = r(t, a)), (t = u(t)), t in i)) return;
              i[t] = !0;
              let o = t.endsWith(`.css`);
              for (let n = e.length - 1; n >= 0; n--) {
                let r = e[n];
                if (r.href === t && (!o || r.rel === `stylesheet`)) return;
              }
              let s = document.createElement(`link`);
              if (
                ((s.rel = o ? `stylesheet` : n),
                o || (s.as = `script`),
                (s.crossOrigin = ``),
                (s.href = t),
                c && s.setAttribute(`nonce`, c),
                document.head.appendChild(s),
                o)
              )
                return new Promise((e, n) => {
                  s.addEventListener(`load`, e),
                    s.addEventListener(`error`, () =>
                      n(Error(`Unable to preload CSS for ${t}`))
                    );
                });
            })
          );
        }
        function s(e) {
          let t = new Event(`vite:preloadError`, { cancelable: !0 });
          if (((t.payload = e), window.dispatchEvent(t), !t.defaultPrevented))
            throw e;
        }
        return o.then((t) => {
          for (let e of t || []) e.status === `rejected` && s(e.reason);
          return e().catch(s);
        });
      });
  }),
  s;
function c() {
  return (c = e(() => {
    s = (e, t, n) => {
      let r = t.lastIndexOf(`?`),
        i = e[r === -1 || r < t.lastIndexOf(`/`) ? t : t.slice(0, r)];
      return i
        ? typeof i == `function`
          ? i()
          : Promise.resolve(i)
        : new Promise((e, r) => {
            (typeof queueMicrotask == `function` ? queueMicrotask : setTimeout)(
              r.bind(
                null,
                Error(
                  `Unknown variable dynamic import: ` +
                    t +
                    (t.split(`/`).length === n
                      ? ``
                      : `. Note that variables only represent file names one level deep.`)
                )
              )
            );
          });
    };
  }))();
}
export { t as a, o as i, c as n, a as r, s as t };
