import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { Ct as t, Y as n, gn as r, pn as i } from "./lib-BTerfQ6O.js";
var a, o, s, c;
function l() {
  return (l = e(() => {
    n(),
      (a = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
}`),
      (o = `varying vec2 vTextureCoord;
varying vec4 vColor;

uniform sampler2D uSampler;

uniform float outerStrength;
uniform float innerStrength;

uniform vec4 glowColor;

uniform vec4 filterArea;
uniform vec4 filterClamp;
uniform bool knockout;
uniform float alpha;

const float PI = 3.14159265358979323846264;

const float DIST = __DIST__;
const float ANGLE_STEP_SIZE = min(__ANGLE_STEP_SIZE__, PI * 2.0);
const float ANGLE_STEP_NUM = ceil(PI * 2.0 / ANGLE_STEP_SIZE);

const float MAX_TOTAL_ALPHA = ANGLE_STEP_NUM * DIST * (DIST + 1.0) / 2.0;

void main(void) {
    vec2 px = vec2(1.0 / filterArea.x, 1.0 / filterArea.y);

    float totalAlpha = 0.0;

    vec2 direction;
    vec2 displaced;
    vec4 curColor;

    for (float angle = 0.0; angle < PI * 2.0; angle += ANGLE_STEP_SIZE) {
       direction = vec2(cos(angle), sin(angle)) * px;

       for (float curDistance = 0.0; curDistance < DIST; curDistance++) {
           displaced = clamp(vTextureCoord + direction * 
                   (curDistance + 1.0), filterClamp.xy, filterClamp.zw);

           curColor = texture2D(uSampler, displaced);

           totalAlpha += (DIST - curDistance) * curColor.a;
       }
    }
    
    curColor = texture2D(uSampler, vTextureCoord);

    float alphaRatio = (totalAlpha / MAX_TOTAL_ALPHA);

    float innerGlowAlpha = (1.0 - alphaRatio) * innerStrength * curColor.a;
    float innerGlowStrength = min(1.0, innerGlowAlpha);
    
    vec4 innerColor = mix(curColor, glowColor, innerGlowStrength);

    float outerGlowAlpha = alphaRatio * outerStrength * (1. - curColor.a);
    float outerGlowStrength = min(1.0 - innerColor.a, outerGlowAlpha);

    if (knockout) {
      float resultAlpha = (outerGlowAlpha + innerGlowAlpha) * alpha;
      gl_FragColor = vec4(glowColor.rgb * resultAlpha, resultAlpha);
    }
    else {
      vec4 outerGlowColor = outerGlowStrength * glowColor.rgba * alpha;
      gl_FragColor = innerColor + outerGlowColor;
    }
}
`),
      (s = class extends t {
        constructor(e) {
          let t = Object.assign({}, s.defaults, e),
            {
              outerStrength: n,
              innerStrength: r,
              color: i,
              knockout: c,
              quality: l,
              alpha: u,
            } = t,
            d = Math.round(t.distance);
          super(
            a,
            o
              .replace(/__ANGLE_STEP_SIZE__/gi, `${(1 / l / d).toFixed(7)}`)
              .replace(/__DIST__/gi, `${d.toFixed(0)}.0`)
          ),
            (this.uniforms.glowColor = new Float32Array([0, 0, 0, 1])),
            (this.uniforms.alpha = 1),
            Object.assign(this, {
              color: i,
              outerStrength: n,
              innerStrength: r,
              padding: d,
              knockout: c,
              alpha: u,
            });
        }
        get color() {
          return r(this.uniforms.glowColor);
        }
        set color(e) {
          i(e, this.uniforms.glowColor);
        }
        get outerStrength() {
          return this.uniforms.outerStrength;
        }
        set outerStrength(e) {
          this.uniforms.outerStrength = e;
        }
        get innerStrength() {
          return this.uniforms.innerStrength;
        }
        set innerStrength(e) {
          this.uniforms.innerStrength = e;
        }
        get knockout() {
          return this.uniforms.knockout;
        }
        set knockout(e) {
          this.uniforms.knockout = e;
        }
        get alpha() {
          return this.uniforms.alpha;
        }
        set alpha(e) {
          this.uniforms.alpha = e;
        }
      }),
      (c = s),
      (c.defaults = {
        distance: 10,
        outerStrength: 4,
        innerStrength: 0,
        color: 16777215,
        quality: 0.1,
        knockout: !1,
        alpha: 1,
      });
  }))();
}
export { c as n, l as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/filter-glow-BQjf2rFW.js.map
