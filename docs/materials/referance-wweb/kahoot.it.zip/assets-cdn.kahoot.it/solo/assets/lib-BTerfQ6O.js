import { a as e, n as t, r as n, t as r } from "./rolldown-runtime-B0Z9INg1.js";
import { S as i } from "./pixijs-game-zi5bgXGP.js";
var a, o, s, c, l, u, d, f, p, m, h, g, _, v, y, b, x, S, C;
function w() {
  return (w = t(() => {
    (a = ((e) => (
      (e[(e.WEBGL_LEGACY = 0)] = `WEBGL_LEGACY`),
      (e[(e.WEBGL = 1)] = `WEBGL`),
      (e[(e.WEBGL2 = 2)] = `WEBGL2`),
      e
    ))(a || {})),
      (o = ((e) => (
        (e[(e.UNKNOWN = 0)] = `UNKNOWN`),
        (e[(e.WEBGL = 1)] = `WEBGL`),
        (e[(e.CANVAS = 2)] = `CANVAS`),
        e
      ))(o || {})),
      (s = ((e) => (
        (e[(e.COLOR = 16384)] = `COLOR`),
        (e[(e.DEPTH = 256)] = `DEPTH`),
        (e[(e.STENCIL = 1024)] = `STENCIL`),
        e
      ))(s || {})),
      (c = ((e) => (
        (e[(e.NORMAL = 0)] = `NORMAL`),
        (e[(e.ADD = 1)] = `ADD`),
        (e[(e.MULTIPLY = 2)] = `MULTIPLY`),
        (e[(e.SCREEN = 3)] = `SCREEN`),
        (e[(e.OVERLAY = 4)] = `OVERLAY`),
        (e[(e.DARKEN = 5)] = `DARKEN`),
        (e[(e.LIGHTEN = 6)] = `LIGHTEN`),
        (e[(e.COLOR_DODGE = 7)] = `COLOR_DODGE`),
        (e[(e.COLOR_BURN = 8)] = `COLOR_BURN`),
        (e[(e.HARD_LIGHT = 9)] = `HARD_LIGHT`),
        (e[(e.SOFT_LIGHT = 10)] = `SOFT_LIGHT`),
        (e[(e.DIFFERENCE = 11)] = `DIFFERENCE`),
        (e[(e.EXCLUSION = 12)] = `EXCLUSION`),
        (e[(e.HUE = 13)] = `HUE`),
        (e[(e.SATURATION = 14)] = `SATURATION`),
        (e[(e.COLOR = 15)] = `COLOR`),
        (e[(e.LUMINOSITY = 16)] = `LUMINOSITY`),
        (e[(e.NORMAL_NPM = 17)] = `NORMAL_NPM`),
        (e[(e.ADD_NPM = 18)] = `ADD_NPM`),
        (e[(e.SCREEN_NPM = 19)] = `SCREEN_NPM`),
        (e[(e.NONE = 20)] = `NONE`),
        (e[(e.SRC_OVER = 0)] = `SRC_OVER`),
        (e[(e.SRC_IN = 21)] = `SRC_IN`),
        (e[(e.SRC_OUT = 22)] = `SRC_OUT`),
        (e[(e.SRC_ATOP = 23)] = `SRC_ATOP`),
        (e[(e.DST_OVER = 24)] = `DST_OVER`),
        (e[(e.DST_IN = 25)] = `DST_IN`),
        (e[(e.DST_OUT = 26)] = `DST_OUT`),
        (e[(e.DST_ATOP = 27)] = `DST_ATOP`),
        (e[(e.ERASE = 26)] = `ERASE`),
        (e[(e.SUBTRACT = 28)] = `SUBTRACT`),
        (e[(e.XOR = 29)] = `XOR`),
        e
      ))(c || {})),
      (l = ((e) => (
        (e[(e.POINTS = 0)] = `POINTS`),
        (e[(e.LINES = 1)] = `LINES`),
        (e[(e.LINE_LOOP = 2)] = `LINE_LOOP`),
        (e[(e.LINE_STRIP = 3)] = `LINE_STRIP`),
        (e[(e.TRIANGLES = 4)] = `TRIANGLES`),
        (e[(e.TRIANGLE_STRIP = 5)] = `TRIANGLE_STRIP`),
        (e[(e.TRIANGLE_FAN = 6)] = `TRIANGLE_FAN`),
        e
      ))(l || {})),
      (u = ((e) => (
        (e[(e.RGBA = 6408)] = `RGBA`),
        (e[(e.RGB = 6407)] = `RGB`),
        (e[(e.RG = 33319)] = `RG`),
        (e[(e.RED = 6403)] = `RED`),
        (e[(e.RGBA_INTEGER = 36249)] = `RGBA_INTEGER`),
        (e[(e.RGB_INTEGER = 36248)] = `RGB_INTEGER`),
        (e[(e.RG_INTEGER = 33320)] = `RG_INTEGER`),
        (e[(e.RED_INTEGER = 36244)] = `RED_INTEGER`),
        (e[(e.ALPHA = 6406)] = `ALPHA`),
        (e[(e.LUMINANCE = 6409)] = `LUMINANCE`),
        (e[(e.LUMINANCE_ALPHA = 6410)] = `LUMINANCE_ALPHA`),
        (e[(e.DEPTH_COMPONENT = 6402)] = `DEPTH_COMPONENT`),
        (e[(e.DEPTH_STENCIL = 34041)] = `DEPTH_STENCIL`),
        e
      ))(u || {})),
      (d = ((e) => (
        (e[(e.TEXTURE_2D = 3553)] = `TEXTURE_2D`),
        (e[(e.TEXTURE_CUBE_MAP = 34067)] = `TEXTURE_CUBE_MAP`),
        (e[(e.TEXTURE_2D_ARRAY = 35866)] = `TEXTURE_2D_ARRAY`),
        (e[
          (e.TEXTURE_CUBE_MAP_POSITIVE_X = 34069)
        ] = `TEXTURE_CUBE_MAP_POSITIVE_X`),
        (e[
          (e.TEXTURE_CUBE_MAP_NEGATIVE_X = 34070)
        ] = `TEXTURE_CUBE_MAP_NEGATIVE_X`),
        (e[
          (e.TEXTURE_CUBE_MAP_POSITIVE_Y = 34071)
        ] = `TEXTURE_CUBE_MAP_POSITIVE_Y`),
        (e[
          (e.TEXTURE_CUBE_MAP_NEGATIVE_Y = 34072)
        ] = `TEXTURE_CUBE_MAP_NEGATIVE_Y`),
        (e[
          (e.TEXTURE_CUBE_MAP_POSITIVE_Z = 34073)
        ] = `TEXTURE_CUBE_MAP_POSITIVE_Z`),
        (e[
          (e.TEXTURE_CUBE_MAP_NEGATIVE_Z = 34074)
        ] = `TEXTURE_CUBE_MAP_NEGATIVE_Z`),
        e
      ))(d || {})),
      (f = ((e) => (
        (e[(e.UNSIGNED_BYTE = 5121)] = `UNSIGNED_BYTE`),
        (e[(e.UNSIGNED_SHORT = 5123)] = `UNSIGNED_SHORT`),
        (e[(e.UNSIGNED_SHORT_5_6_5 = 33635)] = `UNSIGNED_SHORT_5_6_5`),
        (e[(e.UNSIGNED_SHORT_4_4_4_4 = 32819)] = `UNSIGNED_SHORT_4_4_4_4`),
        (e[(e.UNSIGNED_SHORT_5_5_5_1 = 32820)] = `UNSIGNED_SHORT_5_5_5_1`),
        (e[(e.UNSIGNED_INT = 5125)] = `UNSIGNED_INT`),
        (e[
          (e.UNSIGNED_INT_10F_11F_11F_REV = 35899)
        ] = `UNSIGNED_INT_10F_11F_11F_REV`),
        (e[
          (e.UNSIGNED_INT_2_10_10_10_REV = 33640)
        ] = `UNSIGNED_INT_2_10_10_10_REV`),
        (e[(e.UNSIGNED_INT_24_8 = 34042)] = `UNSIGNED_INT_24_8`),
        (e[(e.UNSIGNED_INT_5_9_9_9_REV = 35902)] = `UNSIGNED_INT_5_9_9_9_REV`),
        (e[(e.BYTE = 5120)] = `BYTE`),
        (e[(e.SHORT = 5122)] = `SHORT`),
        (e[(e.INT = 5124)] = `INT`),
        (e[(e.FLOAT = 5126)] = `FLOAT`),
        (e[
          (e.FLOAT_32_UNSIGNED_INT_24_8_REV = 36269)
        ] = `FLOAT_32_UNSIGNED_INT_24_8_REV`),
        (e[(e.HALF_FLOAT = 36193)] = `HALF_FLOAT`),
        e
      ))(f || {})),
      (p = ((e) => (
        (e[(e.FLOAT = 0)] = `FLOAT`),
        (e[(e.INT = 1)] = `INT`),
        (e[(e.UINT = 2)] = `UINT`),
        e
      ))(p || {})),
      (m = ((e) => (
        (e[(e.NEAREST = 0)] = `NEAREST`), (e[(e.LINEAR = 1)] = `LINEAR`), e
      ))(m || {})),
      (h = ((e) => (
        (e[(e.CLAMP = 33071)] = `CLAMP`),
        (e[(e.REPEAT = 10497)] = `REPEAT`),
        (e[(e.MIRRORED_REPEAT = 33648)] = `MIRRORED_REPEAT`),
        e
      ))(h || {})),
      (g = ((e) => (
        (e[(e.OFF = 0)] = `OFF`),
        (e[(e.POW2 = 1)] = `POW2`),
        (e[(e.ON = 2)] = `ON`),
        (e[(e.ON_MANUAL = 3)] = `ON_MANUAL`),
        e
      ))(g || {})),
      (_ = ((e) => (
        (e[(e.NPM = 0)] = `NPM`),
        (e[(e.UNPACK = 1)] = `UNPACK`),
        (e[(e.PMA = 2)] = `PMA`),
        (e[(e.NO_PREMULTIPLIED_ALPHA = 0)] = `NO_PREMULTIPLIED_ALPHA`),
        (e[(e.PREMULTIPLY_ON_UPLOAD = 1)] = `PREMULTIPLY_ON_UPLOAD`),
        (e[(e.PREMULTIPLIED_ALPHA = 2)] = `PREMULTIPLIED_ALPHA`),
        e
      ))(_ || {})),
      (v = ((e) => (
        (e[(e.NO = 0)] = `NO`),
        (e[(e.YES = 1)] = `YES`),
        (e[(e.AUTO = 2)] = `AUTO`),
        (e[(e.BLEND = 0)] = `BLEND`),
        (e[(e.CLEAR = 1)] = `CLEAR`),
        (e[(e.BLIT = 2)] = `BLIT`),
        e
      ))(v || {})),
      (y = ((e) => (
        (e[(e.AUTO = 0)] = `AUTO`), (e[(e.MANUAL = 1)] = `MANUAL`), e
      ))(y || {})),
      (b = ((e) => (
        (e.LOW = `lowp`), (e.MEDIUM = `mediump`), (e.HIGH = `highp`), e
      ))(b || {})),
      (x = ((e) => (
        (e[(e.NONE = 0)] = `NONE`),
        (e[(e.SCISSOR = 1)] = `SCISSOR`),
        (e[(e.STENCIL = 2)] = `STENCIL`),
        (e[(e.SPRITE = 3)] = `SPRITE`),
        (e[(e.COLOR = 4)] = `COLOR`),
        e
      ))(x || {})),
      (S = ((e) => (
        (e[(e.NONE = 0)] = `NONE`),
        (e[(e.LOW = 2)] = `LOW`),
        (e[(e.MEDIUM = 4)] = `MEDIUM`),
        (e[(e.HIGH = 8)] = `HIGH`),
        e
      ))(S || {})),
      (C = ((e) => (
        (e[(e.ELEMENT_ARRAY_BUFFER = 34963)] = `ELEMENT_ARRAY_BUFFER`),
        (e[(e.ARRAY_BUFFER = 34962)] = `ARRAY_BUFFER`),
        (e[(e.UNIFORM_BUFFER = 35345)] = `UNIFORM_BUFFER`),
        e
      ))(C || {}));
  }))();
}
var T;
function E() {
  return (E = t(() => {
    T = {
      createCanvas: (e, t) => {
        let n = document.createElement(`canvas`);
        return (n.width = e), (n.height = t), n;
      },
      getCanvasRenderingContext2D: () => CanvasRenderingContext2D,
      getWebGLRenderingContext: () => WebGLRenderingContext,
      getNavigator: () => navigator,
      getBaseUrl: () => document.baseURI ?? window.location.href,
      getFontFaceSet: () => document.fonts,
      fetch: (e, t) => fetch(e, t),
      parseXML: (e) => new DOMParser().parseFromString(e, `text/xml`),
    };
  }))();
}
var D;
function O() {
  return (O = t(() => {
    E(),
      (D = {
        ADAPTER: T,
        RESOLUTION: 1,
        CREATE_IMAGE_BITMAP: !1,
        ROUND_PIXELS: !1,
      });
  }))();
}
function k(e) {
  return function (t) {
    return t.test(e);
  };
}
function A(e) {
  var t = { userAgent: ``, platform: ``, maxTouchPoints: 0 };
  !e && typeof navigator < `u`
    ? (t = {
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        maxTouchPoints: navigator.maxTouchPoints || 0,
      })
    : typeof e == `string`
    ? (t.userAgent = e)
    : e &&
      e.userAgent &&
      (t = {
        userAgent: e.userAgent,
        platform: e.platform,
        maxTouchPoints: e.maxTouchPoints || 0,
      });
  var n = t.userAgent,
    r = n.split(`[FBAN`);
  r[1] !== void 0 && (n = r[0]),
    (r = n.split(`Twitter`)),
    r[1] !== void 0 && (n = r[0]);
  var i = k(n),
    a = {
      apple: {
        phone: i(j) && !i(oe),
        ipod: i(ee),
        tablet: !i(j) && (i(M) || pe(t)) && !i(oe),
        universal: i(te),
        device: (i(j) || i(ee) || i(M) || i(te) || pe(t)) && !i(oe),
      },
      amazon: { phone: i(ie), tablet: !i(ie) && i(ae), device: i(ie) || i(ae) },
      android: {
        phone: (!i(oe) && i(ie)) || (!i(oe) && i(ne)),
        tablet: !i(oe) && !i(ie) && !i(ne) && (i(ae) || i(re)),
        device:
          (!i(oe) && (i(ie) || i(ae) || i(ne) || i(re))) || i(/\bokhttp\b/i),
      },
      windows: { phone: i(oe), tablet: i(se), device: i(oe) || i(se) },
      other: {
        blackberry: i(ce),
        blackberry10: i(le),
        opera: i(ue),
        firefox: i(fe),
        chrome: i(de),
        device: i(ce) || i(le) || i(ue) || i(fe) || i(de),
      },
      any: !1,
      phone: !1,
      tablet: !1,
    };
  return (
    (a.any =
      a.apple.device || a.android.device || a.windows.device || a.other.device),
    (a.phone = a.apple.phone || a.android.phone || a.windows.phone),
    (a.tablet = a.apple.tablet || a.android.tablet || a.windows.tablet),
    a
  );
}
var j, ee, M, te, ne, re, ie, ae, oe, se, ce, le, ue, de, fe, pe;
function me() {
  return (me = t(() => {
    (j = /iPhone/i),
      (ee = /iPod/i),
      (M = /iPad/i),
      (te = /\biOS-universal(?:.+)Mac\b/i),
      (ne = /\bAndroid(?:.+)Mobile\b/i),
      (re = /Android/i),
      (ie = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i),
      (ae = /Silk/i),
      (oe = /Windows Phone/i),
      (se = /\bWindows(?:.+)ARM\b/i),
      (ce = /BlackBerry/i),
      (le = /BB10/i),
      (ue = /Opera Mini/i),
      (de = /\b(CriOS|Chrome)(?:.+)Mobile/i),
      (fe = /Mobile(?:.+)Firefox\b/i),
      (pe = function (e) {
        return (
          e !== void 0 &&
          e.platform === `MacIntel` &&
          typeof e.maxTouchPoints == `number` &&
          e.maxTouchPoints > 1 &&
          typeof MSStream > `u`
        );
      });
  }))();
}
var he;
function ge() {
  return (ge = t(() => {
    me(), (he = (A.default ?? A)(globalThis.navigator));
  }))();
}
function N() {
  return (N = t(() => {
    O(), ge();
  }))();
}
function _e() {
  return (_e = t(() => {
    N(),
      (D.RETINA_PREFIX = /@([0-9\.]+)x/),
      (D.FAIL_IF_MAJOR_PERFORMANCE_CAVEAT = !1);
  }))();
}
var ve = r((e, t) => {
    var n = Object.prototype.hasOwnProperty,
      r = `~`;
    function i() {}
    Object.create &&
      ((i.prototype = Object.create(null)), new i().__proto__ || (r = !1));
    function a(e, t, n) {
      (this.fn = e), (this.context = t), (this.once = n || !1);
    }
    function o(e, t, n, i, o) {
      if (typeof n != `function`)
        throw TypeError(`The listener must be a function`);
      var s = new a(n, i || e, o),
        c = r ? r + t : t;
      return (
        e._events[c]
          ? e._events[c].fn
            ? (e._events[c] = [e._events[c], s])
            : e._events[c].push(s)
          : ((e._events[c] = s), e._eventsCount++),
        e
      );
    }
    function s(e, t) {
      --e._eventsCount === 0 ? (e._events = new i()) : delete e._events[t];
    }
    function c() {
      (this._events = new i()), (this._eventsCount = 0);
    }
    (c.prototype.eventNames = function () {
      var e = [],
        t,
        i;
      if (this._eventsCount === 0) return e;
      for (i in (t = this._events)) n.call(t, i) && e.push(r ? i.slice(1) : i);
      return Object.getOwnPropertySymbols
        ? e.concat(Object.getOwnPropertySymbols(t))
        : e;
    }),
      (c.prototype.listeners = function (e) {
        var t = r ? r + e : e,
          n = this._events[t];
        if (!n) return [];
        if (n.fn) return [n.fn];
        for (var i = 0, a = n.length, o = Array(a); i < a; i++) o[i] = n[i].fn;
        return o;
      }),
      (c.prototype.listenerCount = function (e) {
        var t = r ? r + e : e,
          n = this._events[t];
        return n ? (n.fn ? 1 : n.length) : 0;
      }),
      (c.prototype.emit = function (e, t, n, i, a, o) {
        var s = r ? r + e : e;
        if (!this._events[s]) return !1;
        var c = this._events[s],
          l = arguments.length,
          u,
          d;
        if (c.fn) {
          switch ((c.once && this.removeListener(e, c.fn, void 0, !0), l)) {
            case 1:
              return c.fn.call(c.context), !0;
            case 2:
              return c.fn.call(c.context, t), !0;
            case 3:
              return c.fn.call(c.context, t, n), !0;
            case 4:
              return c.fn.call(c.context, t, n, i), !0;
            case 5:
              return c.fn.call(c.context, t, n, i, a), !0;
            case 6:
              return c.fn.call(c.context, t, n, i, a, o), !0;
          }
          for (d = 1, u = Array(l - 1); d < l; d++) u[d - 1] = arguments[d];
          c.fn.apply(c.context, u);
        } else {
          var f = c.length,
            p;
          for (d = 0; d < f; d++)
            switch (
              (c[d].once && this.removeListener(e, c[d].fn, void 0, !0), l)
            ) {
              case 1:
                c[d].fn.call(c[d].context);
                break;
              case 2:
                c[d].fn.call(c[d].context, t);
                break;
              case 3:
                c[d].fn.call(c[d].context, t, n);
                break;
              case 4:
                c[d].fn.call(c[d].context, t, n, i);
                break;
              default:
                if (!u)
                  for (p = 1, u = Array(l - 1); p < l; p++)
                    u[p - 1] = arguments[p];
                c[d].fn.apply(c[d].context, u);
            }
        }
        return !0;
      }),
      (c.prototype.on = function (e, t, n) {
        return o(this, e, t, n, !1);
      }),
      (c.prototype.once = function (e, t, n) {
        return o(this, e, t, n, !0);
      }),
      (c.prototype.removeListener = function (e, t, n, i) {
        var a = r ? r + e : e;
        if (!this._events[a]) return this;
        if (!t) return s(this, a), this;
        var o = this._events[a];
        if (o.fn)
          o.fn === t && (!i || o.once) && (!n || o.context === n) && s(this, a);
        else {
          for (var c = 0, l = [], u = o.length; c < u; c++)
            (o[c].fn !== t || (i && !o[c].once) || (n && o[c].context !== n)) &&
              l.push(o[c]);
          l.length ? (this._events[a] = l.length === 1 ? l[0] : l) : s(this, a);
        }
        return this;
      }),
      (c.prototype.removeAllListeners = function (e) {
        var t;
        return (
          e
            ? ((t = r ? r + e : e), this._events[t] && s(this, t))
            : ((this._events = new i()), (this._eventsCount = 0)),
          this
        );
      }),
      (c.prototype.off = c.prototype.removeListener),
      (c.prototype.addListener = c.prototype.on),
      (c.prefixed = r),
      (c.EventEmitter = c),
      t !== void 0 && (t.exports = c);
  }),
  ye = r((e, t) => {
    (t.exports = n), (t.exports.default = n);
    function n(e, t, n) {
      n ||= 2;
      var i = t && t.length,
        o = i ? t[0] * n : e.length,
        s = r(e, 0, o, n, !0),
        c = [];
      if (!s || s.next === s.prev) return c;
      var l, d, f, p, m, h, g;
      if ((i && (s = u(e, t, s, n)), e.length > 80 * n)) {
        (l = f = e[0]), (d = p = e[1]);
        for (var _ = n; _ < o; _ += n)
          (m = e[_]),
            (h = e[_ + 1]),
            m < l && (l = m),
            h < d && (d = h),
            m > f && (f = m),
            h > p && (p = h);
        (g = Math.max(f - l, p - d)), (g = g === 0 ? 0 : 32767 / g);
      }
      return a(s, c, n, l, d, g, 0), c;
    }
    function r(e, t, n, r, i) {
      var a, o;
      if (i === M(e, t, n, r) > 0)
        for (a = t; a < n; a += r) o = A(a, e[a], e[a + 1], o);
      else for (a = n - r; a >= t; a -= r) o = A(a, e[a], e[a + 1], o);
      return o && S(o, o.next) && (j(o), (o = o.next)), o;
    }
    function i(e, t) {
      if (!e) return e;
      t ||= e;
      var n = e,
        r;
      do
        if (
          ((r = !1), !n.steiner && (S(n, n.next) || x(n.prev, n, n.next) === 0))
        ) {
          if ((j(n), (n = t = n.prev), n === n.next)) break;
          r = !0;
        } else n = n.next;
      while (r || n !== t);
      return t;
    }
    function a(e, t, n, r, u, d, f) {
      if (e) {
        !f && d && h(e, r, u, d);
        for (var p = e, m, g; e.prev !== e.next; ) {
          if (((m = e.prev), (g = e.next), d ? s(e, r, u, d) : o(e))) {
            t.push((m.i / n) | 0),
              t.push((e.i / n) | 0),
              t.push((g.i / n) | 0),
              j(e),
              (e = g.next),
              (p = g.next);
            continue;
          }
          if (((e = g), e === p)) {
            f
              ? f === 1
                ? ((e = c(i(e), t, n)), a(e, t, n, r, u, d, 2))
                : f === 2 && l(e, t, n, r, u, d)
              : a(i(e), t, n, r, u, d, 1);
            break;
          }
        }
      }
    }
    function o(e) {
      var t = e.prev,
        n = e,
        r = e.next;
      if (x(t, n, r) >= 0) return !1;
      for (
        var i = t.x,
          a = n.x,
          o = r.x,
          s = t.y,
          c = n.y,
          l = r.y,
          u = i < a ? (i < o ? i : o) : a < o ? a : o,
          d = s < c ? (s < l ? s : l) : c < l ? c : l,
          f = i > a ? (i > o ? i : o) : a > o ? a : o,
          p = s > c ? (s > l ? s : l) : c > l ? c : l,
          m = r.next;
        m !== t;

      ) {
        if (
          m.x >= u &&
          m.x <= f &&
          m.y >= d &&
          m.y <= p &&
          y(i, s, a, c, o, l, m.x, m.y) &&
          x(m.prev, m, m.next) >= 0
        )
          return !1;
        m = m.next;
      }
      return !0;
    }
    function s(e, t, n, r) {
      var i = e.prev,
        a = e,
        o = e.next;
      if (x(i, a, o) >= 0) return !1;
      for (
        var s = i.x,
          c = a.x,
          l = o.x,
          u = i.y,
          d = a.y,
          f = o.y,
          p = s < c ? (s < l ? s : l) : c < l ? c : l,
          m = u < d ? (u < f ? u : f) : d < f ? d : f,
          h = s > c ? (s > l ? s : l) : c > l ? c : l,
          g = u > d ? (u > f ? u : f) : d > f ? d : f,
          v = _(p, m, t, n, r),
          b = _(h, g, t, n, r),
          S = e.prevZ,
          C = e.nextZ;
        S && S.z >= v && C && C.z <= b;

      ) {
        if (
          (S.x >= p &&
            S.x <= h &&
            S.y >= m &&
            S.y <= g &&
            S !== i &&
            S !== o &&
            y(s, u, c, d, l, f, S.x, S.y) &&
            x(S.prev, S, S.next) >= 0) ||
          ((S = S.prevZ),
          C.x >= p &&
            C.x <= h &&
            C.y >= m &&
            C.y <= g &&
            C !== i &&
            C !== o &&
            y(s, u, c, d, l, f, C.x, C.y) &&
            x(C.prev, C, C.next) >= 0)
        )
          return !1;
        C = C.nextZ;
      }
      for (; S && S.z >= v; ) {
        if (
          S.x >= p &&
          S.x <= h &&
          S.y >= m &&
          S.y <= g &&
          S !== i &&
          S !== o &&
          y(s, u, c, d, l, f, S.x, S.y) &&
          x(S.prev, S, S.next) >= 0
        )
          return !1;
        S = S.prevZ;
      }
      for (; C && C.z <= b; ) {
        if (
          C.x >= p &&
          C.x <= h &&
          C.y >= m &&
          C.y <= g &&
          C !== i &&
          C !== o &&
          y(s, u, c, d, l, f, C.x, C.y) &&
          x(C.prev, C, C.next) >= 0
        )
          return !1;
        C = C.nextZ;
      }
      return !0;
    }
    function c(e, t, n) {
      var r = e;
      do {
        var a = r.prev,
          o = r.next.next;
        !S(a, o) &&
          C(a, r, r.next, o) &&
          D(a, o) &&
          D(o, a) &&
          (t.push((a.i / n) | 0),
          t.push((r.i / n) | 0),
          t.push((o.i / n) | 0),
          j(r),
          j(r.next),
          (r = e = o)),
          (r = r.next);
      } while (r !== e);
      return i(r);
    }
    function l(e, t, n, r, o, s) {
      var c = e;
      do {
        for (var l = c.next.next; l !== c.prev; ) {
          if (c.i !== l.i && b(c, l)) {
            var u = k(c, l);
            (c = i(c, c.next)),
              (u = i(u, u.next)),
              a(c, t, n, r, o, s, 0),
              a(u, t, n, r, o, s, 0);
            return;
          }
          l = l.next;
        }
        c = c.next;
      } while (c !== e);
    }
    function u(e, t, n, i) {
      var a = [],
        o,
        s,
        c,
        l,
        u;
      for (o = 0, s = t.length; o < s; o++)
        (c = t[o] * i),
          (l = o < s - 1 ? t[o + 1] * i : e.length),
          (u = r(e, c, l, i, !1)),
          u === u.next && (u.steiner = !0),
          a.push(v(u));
      for (a.sort(d), o = 0; o < a.length; o++) n = f(a[o], n);
      return n;
    }
    function d(e, t) {
      return e.x - t.x;
    }
    function f(e, t) {
      var n = p(e, t);
      if (!n) return t;
      var r = k(n, e);
      return i(r, r.next), i(n, n.next);
    }
    function p(e, t) {
      var n = t,
        r = e.x,
        i = e.y,
        a = -1 / 0,
        o;
      do {
        if (i <= n.y && i >= n.next.y && n.next.y !== n.y) {
          var s = n.x + ((i - n.y) * (n.next.x - n.x)) / (n.next.y - n.y);
          if (
            s <= r &&
            s > a &&
            ((a = s), (o = n.x < n.next.x ? n : n.next), s === r)
          )
            return o;
        }
        n = n.next;
      } while (n !== t);
      if (!o) return null;
      var c = o,
        l = o.x,
        u = o.y,
        d = 1 / 0,
        f;
      n = o;
      do
        r >= n.x &&
          n.x >= l &&
          r !== n.x &&
          y(i < u ? r : a, i, l, u, i < u ? a : r, i, n.x, n.y) &&
          ((f = Math.abs(i - n.y) / (r - n.x)),
          D(n, e) &&
            (f < d || (f === d && (n.x > o.x || (n.x === o.x && m(o, n))))) &&
            ((o = n), (d = f))),
          (n = n.next);
      while (n !== c);
      return o;
    }
    function m(e, t) {
      return x(e.prev, e, t.prev) < 0 && x(t.next, e, e.next) < 0;
    }
    function h(e, t, n, r) {
      var i = e;
      do
        i.z === 0 && (i.z = _(i.x, i.y, t, n, r)),
          (i.prevZ = i.prev),
          (i.nextZ = i.next),
          (i = i.next);
      while (i !== e);
      (i.prevZ.nextZ = null), (i.prevZ = null), g(i);
    }
    function g(e) {
      var t,
        n,
        r,
        i,
        a,
        o,
        s,
        c,
        l = 1;
      do {
        for (n = e, e = null, a = null, o = 0; n; ) {
          for (o++, r = n, s = 0, t = 0; t < l && (s++, (r = r.nextZ), r); t++);
          for (c = l; s > 0 || (c > 0 && r); )
            s !== 0 && (c === 0 || !r || n.z <= r.z)
              ? ((i = n), (n = n.nextZ), s--)
              : ((i = r), (r = r.nextZ), c--),
              a ? (a.nextZ = i) : (e = i),
              (i.prevZ = a),
              (a = i);
          n = r;
        }
        (a.nextZ = null), (l *= 2);
      } while (o > 1);
      return e;
    }
    function _(e, t, n, r, i) {
      return (
        (e = ((e - n) * i) | 0),
        (t = ((t - r) * i) | 0),
        (e = (e | (e << 8)) & 16711935),
        (e = (e | (e << 4)) & 252645135),
        (e = (e | (e << 2)) & 858993459),
        (e = (e | (e << 1)) & 1431655765),
        (t = (t | (t << 8)) & 16711935),
        (t = (t | (t << 4)) & 252645135),
        (t = (t | (t << 2)) & 858993459),
        (t = (t | (t << 1)) & 1431655765),
        e | (t << 1)
      );
    }
    function v(e) {
      var t = e,
        n = e;
      do (t.x < n.x || (t.x === n.x && t.y < n.y)) && (n = t), (t = t.next);
      while (t !== e);
      return n;
    }
    function y(e, t, n, r, i, a, o, s) {
      return (
        (i - o) * (t - s) >= (e - o) * (a - s) &&
        (e - o) * (r - s) >= (n - o) * (t - s) &&
        (n - o) * (a - s) >= (i - o) * (r - s)
      );
    }
    function b(e, t) {
      return (
        e.next.i !== t.i &&
        e.prev.i !== t.i &&
        !E(e, t) &&
        ((D(e, t) &&
          D(t, e) &&
          O(e, t) &&
          (x(e.prev, e, t.prev) || x(e, t.prev, t))) ||
          (S(e, t) && x(e.prev, e, e.next) > 0 && x(t.prev, t, t.next) > 0))
      );
    }
    function x(e, t, n) {
      return (t.y - e.y) * (n.x - t.x) - (t.x - e.x) * (n.y - t.y);
    }
    function S(e, t) {
      return e.x === t.x && e.y === t.y;
    }
    function C(e, t, n, r) {
      var i = T(x(e, t, n)),
        a = T(x(e, t, r)),
        o = T(x(n, r, e)),
        s = T(x(n, r, t));
      return !!(
        (i !== a && o !== s) ||
        (i === 0 && w(e, n, t)) ||
        (a === 0 && w(e, r, t)) ||
        (o === 0 && w(n, e, r)) ||
        (s === 0 && w(n, t, r))
      );
    }
    function w(e, t, n) {
      return (
        t.x <= Math.max(e.x, n.x) &&
        t.x >= Math.min(e.x, n.x) &&
        t.y <= Math.max(e.y, n.y) &&
        t.y >= Math.min(e.y, n.y)
      );
    }
    function T(e) {
      return e > 0 ? 1 : e < 0 ? -1 : 0;
    }
    function E(e, t) {
      var n = e;
      do {
        if (
          n.i !== e.i &&
          n.next.i !== e.i &&
          n.i !== t.i &&
          n.next.i !== t.i &&
          C(n, n.next, e, t)
        )
          return !0;
        n = n.next;
      } while (n !== e);
      return !1;
    }
    function D(e, t) {
      return x(e.prev, e, e.next) < 0
        ? x(e, t, e.next) >= 0 && x(e, e.prev, t) >= 0
        : x(e, t, e.prev) < 0 || x(e, e.next, t) < 0;
    }
    function O(e, t) {
      var n = e,
        r = !1,
        i = (e.x + t.x) / 2,
        a = (e.y + t.y) / 2;
      do
        n.y > a != n.next.y > a &&
          n.next.y !== n.y &&
          i < ((n.next.x - n.x) * (a - n.y)) / (n.next.y - n.y) + n.x &&
          (r = !r),
          (n = n.next);
      while (n !== e);
      return r;
    }
    function k(e, t) {
      var n = new ee(e.i, e.x, e.y),
        r = new ee(t.i, t.x, t.y),
        i = e.next,
        a = t.prev;
      return (
        (e.next = t),
        (t.prev = e),
        (n.next = i),
        (i.prev = n),
        (r.next = n),
        (n.prev = r),
        (a.next = r),
        (r.prev = a),
        r
      );
    }
    function A(e, t, n, r) {
      var i = new ee(e, t, n);
      return (
        r
          ? ((i.next = r.next), (i.prev = r), (r.next.prev = i), (r.next = i))
          : ((i.prev = i), (i.next = i)),
        i
      );
    }
    function j(e) {
      (e.next.prev = e.prev),
        (e.prev.next = e.next),
        e.prevZ && (e.prevZ.nextZ = e.nextZ),
        e.nextZ && (e.nextZ.prevZ = e.prevZ);
    }
    function ee(e, t, n) {
      (this.i = e),
        (this.x = t),
        (this.y = n),
        (this.prev = null),
        (this.next = null),
        (this.z = 0),
        (this.prevZ = null),
        (this.nextZ = null),
        (this.steiner = !1);
    }
    n.deviation = function (e, t, n, r) {
      var i = t && t.length,
        a = i ? t[0] * n : e.length,
        o = Math.abs(M(e, 0, a, n));
      if (i)
        for (var s = 0, c = t.length; s < c; s++) {
          var l = t[s] * n,
            u = s < c - 1 ? t[s + 1] * n : e.length;
          o -= Math.abs(M(e, l, u, n));
        }
      var d = 0;
      for (s = 0; s < r.length; s += 3) {
        var f = r[s] * n,
          p = r[s + 1] * n,
          m = r[s + 2] * n;
        d += Math.abs(
          (e[f] - e[m]) * (e[p + 1] - e[f + 1]) -
            (e[f] - e[p]) * (e[m + 1] - e[f + 1])
        );
      }
      return o === 0 && d === 0 ? 0 : Math.abs((d - o) / o);
    };
    function M(e, t, n, r) {
      for (var i = 0, a = t, o = n - r; a < n; a += r)
        (i += (e[o] - e[a]) * (e[a + 1] + e[o + 1])), (o = a);
      return i;
    }
    n.flatten = function (e) {
      for (
        var t = e[0][0].length,
          n = { vertices: [], holes: [], dimensions: t },
          r = 0,
          i = 0;
        i < e.length;
        i++
      ) {
        for (var a = 0; a < e[i].length; a++)
          for (var o = 0; o < t; o++) n.vertices.push(e[i][a][o]);
        i > 0 && ((r += e[i - 1].length), n.holes.push(r));
      }
      return n;
    };
  }),
  be = r((e, t) => {
    (function (n) {
      var r = typeof e == `object` && e && !e.nodeType && e,
        i = typeof t == `object` && t && !t.nodeType && t,
        a = typeof global == `object` && global;
      (a.global === a || a.window === a || a.self === a) && (n = a);
      var o,
        s = 2147483647,
        c = 36,
        l = 1,
        u = 26,
        d = 38,
        f = 700,
        p = 72,
        m = 128,
        h = `-`,
        g = /^xn--/,
        _ = /[^\x20-\x7E]/,
        v = /[\x2E\u3002\uFF0E\uFF61]/g,
        y = {
          overflow: `Overflow: input needs wider integers to process`,
          "not-basic": `Illegal input >= 0x80 (not a basic code point)`,
          "invalid-input": `Invalid input`,
        },
        b = c - l,
        x = Math.floor,
        S = String.fromCharCode,
        C;
      function w(e) {
        throw RangeError(y[e]);
      }
      function T(e, t) {
        for (var n = e.length, r = []; n--; ) r[n] = t(e[n]);
        return r;
      }
      function E(e, t) {
        var n = e.split(`@`),
          r = ``;
        n.length > 1 && ((r = n[0] + `@`), (e = n[1])), (e = e.replace(v, `.`));
        var i = T(e.split(`.`), t).join(`.`);
        return r + i;
      }
      function D(e) {
        for (var t = [], n = 0, r = e.length, i, a; n < r; )
          (i = e.charCodeAt(n++)),
            i >= 55296 && i <= 56319 && n < r
              ? ((a = e.charCodeAt(n++)),
                (a & 64512) == 56320
                  ? t.push(((i & 1023) << 10) + (a & 1023) + 65536)
                  : (t.push(i), n--))
              : t.push(i);
        return t;
      }
      function O(e) {
        return T(e, function (e) {
          var t = ``;
          return (
            e > 65535 &&
              ((e -= 65536),
              (t += S(((e >>> 10) & 1023) | 55296)),
              (e = 56320 | (e & 1023))),
            (t += S(e)),
            t
          );
        }).join(``);
      }
      function k(e) {
        return e - 48 < 10
          ? e - 22
          : e - 65 < 26
          ? e - 65
          : e - 97 < 26
          ? e - 97
          : c;
      }
      function A(e, t) {
        return e + 22 + 75 * (e < 26) - ((t != 0) << 5);
      }
      function j(e, t, n) {
        var r = 0;
        for (e = n ? x(e / f) : e >> 1, e += x(e / t); e > (b * u) >> 1; r += c)
          e = x(e / b);
        return x(r + ((b + 1) * e) / (e + d));
      }
      function ee(e) {
        var t = [],
          n = e.length,
          r,
          i = 0,
          a = m,
          o = p,
          d = e.lastIndexOf(h),
          f,
          g,
          _,
          v,
          y,
          b,
          S,
          C;
        for (d < 0 && (d = 0), f = 0; f < d; ++f)
          e.charCodeAt(f) >= 128 && w(`not-basic`), t.push(e.charCodeAt(f));
        for (g = d > 0 ? d + 1 : 0; g < n; ) {
          for (
            _ = i, v = 1, y = c;
            g >= n && w(`invalid-input`),
              (b = k(e.charCodeAt(g++))),
              (b >= c || b > x((s - i) / v)) && w(`overflow`),
              (i += b * v),
              (S = y <= o ? l : y >= o + u ? u : y - o),
              !(b < S);
            y += c
          )
            (C = c - S), v > x(s / C) && w(`overflow`), (v *= C);
          (r = t.length + 1),
            (o = j(i - _, r, _ == 0)),
            x(i / r) > s - a && w(`overflow`),
            (a += x(i / r)),
            (i %= r),
            t.splice(i++, 0, a);
        }
        return O(t);
      }
      function M(e) {
        var t,
          n,
          r,
          i,
          a,
          o,
          d,
          f,
          g,
          _,
          v,
          y = [],
          b,
          C,
          T,
          E;
        for (e = D(e), b = e.length, t = m, n = 0, a = p, o = 0; o < b; ++o)
          (v = e[o]), v < 128 && y.push(S(v));
        for (r = i = y.length, i && y.push(h); r < b; ) {
          for (d = s, o = 0; o < b; ++o) (v = e[o]), v >= t && v < d && (d = v);
          for (
            C = r + 1,
              d - t > x((s - n) / C) && w(`overflow`),
              n += (d - t) * C,
              t = d,
              o = 0;
            o < b;
            ++o
          )
            if (((v = e[o]), v < t && ++n > s && w(`overflow`), v == t)) {
              for (
                f = n, g = c;
                (_ = g <= a ? l : g >= a + u ? u : g - a), !(f < _);
                g += c
              )
                (E = f - _),
                  (T = c - _),
                  y.push(S(A(_ + (E % T), 0))),
                  (f = x(E / T));
              y.push(S(A(f, 0))), (a = j(n, C, r == i)), (n = 0), ++r;
            }
          ++n, ++t;
        }
        return y.join(``);
      }
      function te(e) {
        return E(e, function (e) {
          return g.test(e) ? ee(e.slice(4).toLowerCase()) : e;
        });
      }
      function ne(e) {
        return E(e, function (e) {
          return _.test(e) ? `xn--` + M(e) : e;
        });
      }
      if (
        ((o = {
          version: `1.3.2`,
          ucs2: { decode: D, encode: O },
          decode: ee,
          encode: M,
          toASCII: ne,
          toUnicode: te,
        }),
        typeof define == `function` &&
          typeof define.amd == `object` &&
          define.amd)
      )
        define(`punycode`, function () {
          return o;
        });
      else if (r && i)
        if (t.exports == r) i.exports = o;
        else for (C in o) o.hasOwnProperty(C) && (r[C] = o[C]);
      else n.punycode = o;
    })(e);
  }),
  xe = r((e, t) => {
    t.exports = {
      isString: function (e) {
        return typeof e == `string`;
      },
      isObject: function (e) {
        return typeof e == `object` && !!e;
      },
      isNull: function (e) {
        return e === null;
      },
      isNullOrUndefined: function (e) {
        return e == null;
      },
    };
  }),
  Se = r((e, t) => {
    function n(e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }
    t.exports = function (e, t, r, i) {
      (t ||= `&`), (r ||= `=`);
      var a = {};
      if (typeof e != `string` || e.length === 0) return a;
      var o = /\+/g;
      e = e.split(t);
      var s = 1e3;
      i && typeof i.maxKeys == `number` && (s = i.maxKeys);
      var c = e.length;
      s > 0 && c > s && (c = s);
      for (var l = 0; l < c; ++l) {
        var u = e[l].replace(o, `%20`),
          d = u.indexOf(r),
          f,
          p,
          m,
          h;
        d >= 0
          ? ((f = u.substr(0, d)), (p = u.substr(d + 1)))
          : ((f = u), (p = ``)),
          (m = decodeURIComponent(f)),
          (h = decodeURIComponent(p)),
          n(a, m)
            ? Array.isArray(a[m])
              ? a[m].push(h)
              : (a[m] = [a[m], h])
            : (a[m] = h);
      }
      return a;
    };
  }),
  Ce = r((e, t) => {
    var n = function (e) {
      switch (typeof e) {
        case `string`:
          return e;
        case `boolean`:
          return e ? `true` : `false`;
        case `number`:
          return isFinite(e) ? e : ``;
        default:
          return ``;
      }
    };
    t.exports = function (e, t, r, i) {
      return (
        (t ||= `&`),
        (r ||= `=`),
        e === null && (e = void 0),
        typeof e == `object`
          ? Object.keys(e)
              .map(function (i) {
                var a = encodeURIComponent(n(i)) + r;
                return Array.isArray(e[i])
                  ? e[i]
                      .map(function (e) {
                        return a + encodeURIComponent(n(e));
                      })
                      .join(t)
                  : a + encodeURIComponent(n(e[i]));
              })
              .join(t)
          : i
          ? encodeURIComponent(n(i)) + r + encodeURIComponent(n(e))
          : ``
      );
    };
  }),
  we = r((e) => {
    (e.decode = e.parse = Se()), (e.encode = e.stringify = Ce());
  }),
  Te = r((e) => {
    var t = be(),
      n = xe();
    (e.parse = _), (e.resolve = y), (e.format = v);
    function r() {
      (this.protocol = null),
        (this.slashes = null),
        (this.auth = null),
        (this.host = null),
        (this.port = null),
        (this.hostname = null),
        (this.hash = null),
        (this.search = null),
        (this.query = null),
        (this.pathname = null),
        (this.path = null),
        (this.href = null);
    }
    var i = /^([a-z0-9.+-]+:)/i,
      a = /:[0-9]*$/,
      o = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/,
      s = [
        `'`,
        `{`,
        `}`,
        `|`,
        `\\`,
        `^`,
        "`",
        `<`,
        `>`,
        `"`,
        "`",
        ` `,
        `\r`,
        `
`,
        `	`,
      ],
      c = [`%`, `/`, `?`, `;`, `#`].concat(s),
      l = [`/`, `?`, `#`],
      u = 255,
      d = /^[+a-z0-9A-Z_-]{0,63}$/,
      f = /^([+a-z0-9A-Z_-]{0,63})(.*)$/,
      p = { javascript: !0, "javascript:": !0 },
      m = { javascript: !0, "javascript:": !0 },
      h = {
        http: !0,
        https: !0,
        ftp: !0,
        gopher: !0,
        file: !0,
        "http:": !0,
        "https:": !0,
        "ftp:": !0,
        "gopher:": !0,
        "file:": !0,
      },
      g = we();
    function _(e, t, i) {
      if (e && n.isObject(e) && e instanceof r) return e;
      var a = new r();
      return a.parse(e, t, i), a;
    }
    r.prototype.parse = function (e, r, a) {
      if (!n.isString(e))
        throw TypeError(`Parameter 'url' must be a string, not ` + typeof e);
      var _ = e.indexOf(`?`),
        v = _ !== -1 && _ < e.indexOf(`#`) ? `?` : `#`,
        y = e.split(v);
      (y[0] = y[0].replace(/\\/g, `/`)), (e = y.join(v));
      var b = e;
      if (((b = b.trim()), !a && e.split(`#`).length === 1)) {
        var x = o.exec(b);
        if (x)
          return (
            (this.path = b),
            (this.href = b),
            (this.pathname = x[1]),
            x[2]
              ? ((this.search = x[2]),
                (this.query = r
                  ? g.parse(this.search.substr(1))
                  : this.search.substr(1)))
              : r && ((this.search = ``), (this.query = {})),
            this
          );
      }
      var S = i.exec(b);
      if (S) {
        S = S[0];
        var C = S.toLowerCase();
        (this.protocol = C), (b = b.substr(S.length));
      }
      if (a || S || b.match(/^\/\/[^@\/]+@[^@\/]+/)) {
        var w = b.substr(0, 2) === `//`;
        w && !(S && m[S]) && ((b = b.substr(2)), (this.slashes = !0));
      }
      if (!m[S] && (w || (S && !h[S]))) {
        for (var T = -1, E = 0; E < l.length; E++) {
          var D = b.indexOf(l[E]);
          D !== -1 && (T === -1 || D < T) && (T = D);
        }
        var O,
          k = T === -1 ? b.lastIndexOf(`@`) : b.lastIndexOf(`@`, T);
        k !== -1 &&
          ((O = b.slice(0, k)),
          (b = b.slice(k + 1)),
          (this.auth = decodeURIComponent(O))),
          (T = -1);
        for (var E = 0; E < c.length; E++) {
          var D = b.indexOf(c[E]);
          D !== -1 && (T === -1 || D < T) && (T = D);
        }
        T === -1 && (T = b.length),
          (this.host = b.slice(0, T)),
          (b = b.slice(T)),
          this.parseHost(),
          (this.hostname = this.hostname || ``);
        var A =
          this.hostname[0] === `[` &&
          this.hostname[this.hostname.length - 1] === `]`;
        if (!A)
          for (
            var j = this.hostname.split(/\./), E = 0, ee = j.length;
            E < ee;
            E++
          ) {
            var M = j[E];
            if (M && !M.match(d)) {
              for (var te = ``, ne = 0, re = M.length; ne < re; ne++)
                M.charCodeAt(ne) > 127 ? (te += `x`) : (te += M[ne]);
              if (!te.match(d)) {
                var ie = j.slice(0, E),
                  ae = j.slice(E + 1),
                  oe = M.match(f);
                oe && (ie.push(oe[1]), ae.unshift(oe[2])),
                  ae.length && (b = `/` + ae.join(`.`) + b),
                  (this.hostname = ie.join(`.`));
                break;
              }
            }
          }
        (this.hostname =
          this.hostname.length > u ? `` : this.hostname.toLowerCase()),
          A || (this.hostname = t.toASCII(this.hostname));
        var se = this.port ? `:` + this.port : ``,
          ce = this.hostname || ``;
        (this.host = ce + se),
          (this.href += this.host),
          A &&
            ((this.hostname = this.hostname.substr(
              1,
              this.hostname.length - 2
            )),
            b[0] !== `/` && (b = `/` + b));
      }
      if (!p[C])
        for (var E = 0, ee = s.length; E < ee; E++) {
          var le = s[E];
          if (b.indexOf(le) !== -1) {
            var ue = encodeURIComponent(le);
            ue === le && (ue = escape(le)), (b = b.split(le).join(ue));
          }
        }
      var de = b.indexOf(`#`);
      de !== -1 && ((this.hash = b.substr(de)), (b = b.slice(0, de)));
      var fe = b.indexOf(`?`);
      if (
        (fe === -1
          ? r && ((this.search = ``), (this.query = {}))
          : ((this.search = b.substr(fe)),
            (this.query = b.substr(fe + 1)),
            r && (this.query = g.parse(this.query)),
            (b = b.slice(0, fe))),
        b && (this.pathname = b),
        h[C] && this.hostname && !this.pathname && (this.pathname = `/`),
        this.pathname || this.search)
      ) {
        var se = this.pathname || ``,
          pe = this.search || ``;
        this.path = se + pe;
      }
      return (this.href = this.format()), this;
    };
    function v(e) {
      return (
        n.isString(e) && (e = _(e)),
        e instanceof r ? e.format() : r.prototype.format.call(e)
      );
    }
    r.prototype.format = function () {
      var e = this.auth || ``;
      e &&
        ((e = encodeURIComponent(e)), (e = e.replace(/%3A/i, `:`)), (e += `@`));
      var t = this.protocol || ``,
        r = this.pathname || ``,
        i = this.hash || ``,
        a = !1,
        o = ``;
      this.host
        ? (a = e + this.host)
        : this.hostname &&
          ((a =
            e +
            (this.hostname.indexOf(`:`) === -1
              ? this.hostname
              : `[` + this.hostname + `]`)),
          this.port && (a += `:` + this.port)),
        this.query &&
          n.isObject(this.query) &&
          Object.keys(this.query).length &&
          (o = g.stringify(this.query));
      var s = this.search || (o && `?` + o) || ``;
      return (
        t && t.substr(-1) !== `:` && (t += `:`),
        this.slashes || ((!t || h[t]) && a !== !1)
          ? ((a = `//` + (a || ``)), r && r.charAt(0) !== `/` && (r = `/` + r))
          : (a ||= ``),
        i && i.charAt(0) !== `#` && (i = `#` + i),
        s && s.charAt(0) !== `?` && (s = `?` + s),
        (r = r.replace(/[?#]/g, function (e) {
          return encodeURIComponent(e);
        })),
        (s = s.replace(`#`, `%23`)),
        t + a + r + s + i
      );
    };
    function y(e, t) {
      return _(e, !1, !0).resolve(t);
    }
    (r.prototype.resolve = function (e) {
      return this.resolveObject(_(e, !1, !0)).format();
    }),
      (r.prototype.resolveObject = function (e) {
        if (n.isString(e)) {
          var t = new r();
          t.parse(e, !1, !0), (e = t);
        }
        for (var i = new r(), a = Object.keys(this), o = 0; o < a.length; o++) {
          var s = a[o];
          i[s] = this[s];
        }
        if (((i.hash = e.hash), e.href === ``)) return (i.href = i.format()), i;
        if (e.slashes && !e.protocol) {
          for (var c = Object.keys(e), l = 0; l < c.length; l++) {
            var u = c[l];
            u !== `protocol` && (i[u] = e[u]);
          }
          return (
            h[i.protocol] &&
              i.hostname &&
              !i.pathname &&
              (i.path = i.pathname = `/`),
            (i.href = i.format()),
            i
          );
        }
        if (e.protocol && e.protocol !== i.protocol) {
          if (!h[e.protocol]) {
            for (var d = Object.keys(e), f = 0; f < d.length; f++) {
              var p = d[f];
              i[p] = e[p];
            }
            return (i.href = i.format()), i;
          }
          if (((i.protocol = e.protocol), !e.host && !m[e.protocol])) {
            for (
              var g = (e.pathname || ``).split(`/`);
              g.length && !(e.host = g.shift());

            );
            e.host || (e.host = ``),
              e.hostname || (e.hostname = ``),
              g[0] !== `` && g.unshift(``),
              g.length < 2 && g.unshift(``),
              (i.pathname = g.join(`/`));
          } else i.pathname = e.pathname;
          return (
            (i.search = e.search),
            (i.query = e.query),
            (i.host = e.host || ``),
            (i.auth = e.auth),
            (i.hostname = e.hostname || e.host),
            (i.port = e.port),
            (i.pathname || i.search) &&
              (i.path = (i.pathname || ``) + (i.search || ``)),
            (i.slashes = i.slashes || e.slashes),
            (i.href = i.format()),
            i
          );
        }
        var _ = i.pathname && i.pathname.charAt(0) === `/`,
          v = e.host || (e.pathname && e.pathname.charAt(0) === `/`),
          y = v || _ || (i.host && e.pathname),
          b = y,
          x = (i.pathname && i.pathname.split(`/`)) || [],
          g = (e.pathname && e.pathname.split(`/`)) || [],
          S = i.protocol && !h[i.protocol];
        if (
          (S &&
            ((i.hostname = ``),
            (i.port = null),
            i.host && (x[0] === `` ? (x[0] = i.host) : x.unshift(i.host)),
            (i.host = ``),
            e.protocol &&
              ((e.hostname = null),
              (e.port = null),
              e.host && (g[0] === `` ? (g[0] = e.host) : g.unshift(e.host)),
              (e.host = null)),
            (y &&= g[0] === `` || x[0] === ``)),
          v)
        )
          (i.host = e.host || e.host === `` ? e.host : i.host),
            (i.hostname =
              e.hostname || e.hostname === `` ? e.hostname : i.hostname),
            (i.search = e.search),
            (i.query = e.query),
            (x = g);
        else if (g.length)
          (x ||= []),
            x.pop(),
            (x = x.concat(g)),
            (i.search = e.search),
            (i.query = e.query);
        else if (!n.isNullOrUndefined(e.search)) {
          if (S) {
            i.hostname = i.host = x.shift();
            var C = i.host && i.host.indexOf(`@`) > 0 ? i.host.split(`@`) : !1;
            C && ((i.auth = C.shift()), (i.host = i.hostname = C.shift()));
          }
          return (
            (i.search = e.search),
            (i.query = e.query),
            (!n.isNull(i.pathname) || !n.isNull(i.search)) &&
              (i.path =
                (i.pathname ? i.pathname : ``) + (i.search ? i.search : ``)),
            (i.href = i.format()),
            i
          );
        }
        if (!x.length)
          return (
            (i.pathname = null),
            (i.path = i.search ? `/` + i.search : null),
            (i.href = i.format()),
            i
          );
        for (
          var w = x.slice(-1)[0],
            T =
              ((i.host || e.host || x.length > 1) &&
                (w === `.` || w === `..`)) ||
              w === ``,
            E = 0,
            D = x.length;
          D >= 0;
          D--
        )
          (w = x[D]),
            w === `.`
              ? x.splice(D, 1)
              : w === `..`
              ? (x.splice(D, 1), E++)
              : E && (x.splice(D, 1), E--);
        if (!y && !b) for (; E--; ) x.unshift(`..`);
        y && x[0] !== `` && (!x[0] || x[0].charAt(0) !== `/`) && x.unshift(``),
          T && x.join(`/`).substr(-1) !== `/` && x.push(``);
        var O = x[0] === `` || (x[0] && x[0].charAt(0) === `/`);
        if (S) {
          i.hostname = i.host = O ? `` : x.length ? x.shift() : ``;
          var C = i.host && i.host.indexOf(`@`) > 0 ? i.host.split(`@`) : !1;
          C && ((i.auth = C.shift()), (i.host = i.hostname = C.shift()));
        }
        return (
          (y ||= i.host && x.length),
          y && !O && x.unshift(``),
          x.length
            ? (i.pathname = x.join(`/`))
            : ((i.pathname = null), (i.path = null)),
          (!n.isNull(i.pathname) || !n.isNull(i.search)) &&
            (i.path =
              (i.pathname ? i.pathname : ``) + (i.search ? i.search : ``)),
          (i.auth = e.auth || i.auth),
          (i.slashes = i.slashes || e.slashes),
          (i.href = i.format()),
          i
        );
      }),
      (r.prototype.parseHost = function () {
        var e = this.host,
          t = a.exec(e);
        t &&
          ((t = t[0]),
          t !== `:` && (this.port = t.substr(1)),
          (e = e.substr(0, e.length - t.length))),
          e && (this.hostname = e);
      });
  }),
  Ee,
  De;
function Oe() {
  return (Oe = t(() => {
    (Ee = Te()),
      (De = { parse: Ee.parse, format: Ee.format, resolve: Ee.resolve });
  }))();
}
function ke(e) {
  if (typeof e != `string`)
    throw TypeError(`Path must be a string. Received ${JSON.stringify(e)}`);
}
function Ae(e) {
  return e.split(`?`)[0].split(`#`)[0];
}
function je(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`);
}
function Me(e, t, n) {
  return e.replace(new RegExp(je(t), `g`), n);
}
function Ne(e, t) {
  let n = ``,
    r = 0,
    i = -1,
    a = 0,
    o = -1;
  for (let s = 0; s <= e.length; ++s) {
    if (s < e.length) o = e.charCodeAt(s);
    else if (o === 47) break;
    else o = 47;
    if (o === 47) {
      if (i !== s - 1 && a !== 1)
        if (i !== s - 1 && a === 2) {
          if (
            n.length < 2 ||
            r !== 2 ||
            n.charCodeAt(n.length - 1) !== 46 ||
            n.charCodeAt(n.length - 2) !== 46
          ) {
            if (n.length > 2) {
              let e = n.lastIndexOf(`/`);
              if (e !== n.length - 1) {
                e === -1
                  ? ((n = ``), (r = 0))
                  : ((n = n.slice(0, e)),
                    (r = n.length - 1 - n.lastIndexOf(`/`))),
                  (i = s),
                  (a = 0);
                continue;
              }
            } else if (n.length === 2 || n.length === 1) {
              (n = ``), (r = 0), (i = s), (a = 0);
              continue;
            }
          }
          t && (n.length > 0 ? (n += `/..`) : (n = `..`), (r = 2));
        } else
          n.length > 0
            ? (n += `/${e.slice(i + 1, s)}`)
            : (n = e.slice(i + 1, s)),
            (r = s - i - 1);
      (i = s), (a = 0);
    } else o === 46 && a !== -1 ? ++a : (a = -1);
  }
  return n;
}
var Pe;
function Fe() {
  return (Fe = t(() => {
    N(),
      (Pe = {
        toPosix(e) {
          return Me(e, `\\`, `/`);
        },
        isUrl(e) {
          return /^https?:/.test(this.toPosix(e));
        },
        isDataUrl(e) {
          return /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}()_|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s<>]*?)$/i.test(
            e
          );
        },
        hasProtocol(e) {
          return /^[^/:]+:\//.test(this.toPosix(e));
        },
        getProtocol(e) {
          ke(e), (e = this.toPosix(e));
          let t = ``,
            n = /^file:\/\/\//.exec(e),
            r = /^[^/:]+:\/\//.exec(e),
            i = /^[^/:]+:\//.exec(e);
          if (n || r || i) {
            let a = n?.[0] || r?.[0] || i?.[0];
            (t = a), (e = e.slice(a.length));
          }
          return t;
        },
        toAbsolute(e, t, n) {
          if (this.isDataUrl(e)) return e;
          let r = Ae(this.toPosix(t ?? D.ADAPTER.getBaseUrl())),
            i = Ae(this.toPosix(n ?? this.rootname(r)));
          return (
            ke(e),
            (e = this.toPosix(e)),
            e.startsWith(`/`)
              ? Pe.join(i, e.slice(1))
              : this.isAbsolute(e)
              ? e
              : this.join(r, e)
          );
        },
        normalize(e) {
          if (((e = this.toPosix(e)), ke(e), e.length === 0)) return `.`;
          let t = ``,
            n = e.startsWith(`/`);
          this.hasProtocol(e) &&
            ((t = this.rootname(e)), (e = e.slice(t.length)));
          let r = e.endsWith(`/`);
          return (
            (e = Ne(e, !1)),
            e.length > 0 && r && (e += `/`),
            n ? `/${e}` : t + e
          );
        },
        isAbsolute(e) {
          return (
            ke(e),
            (e = this.toPosix(e)),
            this.hasProtocol(e) ? !0 : e.startsWith(`/`)
          );
        },
        join(...e) {
          if (e.length === 0) return `.`;
          let t;
          for (let n = 0; n < e.length; ++n) {
            let r = e[n];
            if ((ke(r), r.length > 0))
              if (t === void 0) t = r;
              else {
                let i = e[n - 1] ?? ``;
                this.extname(i) ? (t += `/../${r}`) : (t += `/${r}`);
              }
          }
          return t === void 0 ? `.` : this.normalize(t);
        },
        dirname(e) {
          if ((ke(e), e.length === 0)) return `.`;
          e = this.toPosix(e);
          let t = e.charCodeAt(0),
            n = t === 47,
            r = -1,
            i = !0,
            a = this.getProtocol(e),
            o = e;
          e = e.slice(a.length);
          for (let n = e.length - 1; n >= 1; --n)
            if (((t = e.charCodeAt(n)), t === 47)) {
              if (!i) {
                r = n;
                break;
              }
            } else i = !1;
          return r === -1
            ? n
              ? `/`
              : this.isUrl(o)
              ? a + e
              : a
            : n && r === 1
            ? `//`
            : a + e.slice(0, r);
        },
        rootname(e) {
          ke(e), (e = this.toPosix(e));
          let t = ``;
          if (
            ((t = e.startsWith(`/`) ? `/` : this.getProtocol(e)), this.isUrl(e))
          ) {
            let n = e.indexOf(`/`, t.length);
            (t = n === -1 ? e : e.slice(0, n)), t.endsWith(`/`) || (t += `/`);
          }
          return t;
        },
        basename(e, t) {
          ke(e), t && ke(t), (e = Ae(this.toPosix(e)));
          let n = 0,
            r = -1,
            i = !0,
            a;
          if (t !== void 0 && t.length > 0 && t.length <= e.length) {
            if (t.length === e.length && t === e) return ``;
            let o = t.length - 1,
              s = -1;
            for (a = e.length - 1; a >= 0; --a) {
              let c = e.charCodeAt(a);
              if (c === 47) {
                if (!i) {
                  n = a + 1;
                  break;
                }
              } else
                s === -1 && ((i = !1), (s = a + 1)),
                  o >= 0 &&
                    (c === t.charCodeAt(o)
                      ? --o === -1 && (r = a)
                      : ((o = -1), (r = s)));
            }
            return (
              n === r ? (r = s) : r === -1 && (r = e.length), e.slice(n, r)
            );
          }
          for (a = e.length - 1; a >= 0; --a)
            if (e.charCodeAt(a) === 47) {
              if (!i) {
                n = a + 1;
                break;
              }
            } else r === -1 && ((i = !1), (r = a + 1));
          return r === -1 ? `` : e.slice(n, r);
        },
        extname(e) {
          ke(e), (e = Ae(this.toPosix(e)));
          let t = -1,
            n = 0,
            r = -1,
            i = !0,
            a = 0;
          for (let o = e.length - 1; o >= 0; --o) {
            let s = e.charCodeAt(o);
            if (s === 47) {
              if (!i) {
                n = o + 1;
                break;
              }
              continue;
            }
            r === -1 && ((i = !1), (r = o + 1)),
              s === 46
                ? t === -1
                  ? (t = o)
                  : a !== 1 && (a = 1)
                : t !== -1 && (a = -1);
          }
          return t === -1 ||
            r === -1 ||
            a === 0 ||
            (a === 1 && t === r - 1 && t === n + 1)
            ? ``
            : e.slice(t, r);
        },
        parse(e) {
          ke(e);
          let t = { root: ``, dir: ``, base: ``, ext: ``, name: `` };
          if (e.length === 0) return t;
          e = Ae(this.toPosix(e));
          let n = e.charCodeAt(0),
            r = this.isAbsolute(e),
            i;
          (t.root = this.rootname(e)), (i = r || this.hasProtocol(e) ? 1 : 0);
          let a = -1,
            o = 0,
            s = -1,
            c = !0,
            l = e.length - 1,
            u = 0;
          for (; l >= i; --l) {
            if (((n = e.charCodeAt(l)), n === 47)) {
              if (!c) {
                o = l + 1;
                break;
              }
              continue;
            }
            s === -1 && ((c = !1), (s = l + 1)),
              n === 46
                ? a === -1
                  ? (a = l)
                  : u !== 1 && (u = 1)
                : a !== -1 && (u = -1);
          }
          return (
            a === -1 ||
            s === -1 ||
            u === 0 ||
            (u === 1 && a === s - 1 && a === o + 1)
              ? s !== -1 &&
                (t.base = t.name = o === 0 && r ? e.slice(1, s) : e.slice(o, s))
              : (o === 0 && r
                  ? ((t.name = e.slice(1, a)), (t.base = e.slice(1, s)))
                  : ((t.name = e.slice(o, a)), (t.base = e.slice(o, s))),
                (t.ext = e.slice(a, s))),
            (t.dir = this.dirname(e)),
            t
          );
        },
        sep: `/`,
        delimiter: `:`,
      });
  }))();
}
function P(e, t, n = 3) {
  if (Ie[t]) return;
  let r = Error().stack;
  r === void 0
    ? console.warn(
        `PixiJS Deprecation Warning: `,
        `${t}
Deprecated since v${e}`
      )
    : ((r = r
        .split(
          `
`
        )
        .splice(n).join(`
`)),
      console.groupCollapsed
        ? (console.groupCollapsed(
            `%cPixiJS Deprecation Warning: %c%s`,
            `color:#614108;background:#fffbe6`,
            `font-weight:normal;color:#614108;background:#fffbe6`,
            `${t}
Deprecated since v${e}`
          ),
          console.warn(r),
          console.groupEnd())
        : (console.warn(
            `PixiJS Deprecation Warning: `,
            `${t}
Deprecated since v${e}`
          ),
          console.warn(r))),
    (Ie[t] = !0);
}
var Ie;
function Le() {
  return (Le = t(() => {
    Ie = {};
  }))();
}
function Re() {
  P(
    `7.0.0`,
    `skipHello is deprecated, please use settings.RENDER_OPTIONS.hello`
  );
}
function ze() {
  P(`7.0.0`, `sayHello is deprecated, please use Renderer's "hello" option`);
}
function Be() {
  return (Be = t(() => {
    Le();
  }))();
}
function Ve() {
  return (
    He === void 0 &&
      (He = (function () {
        let e = {
          stencil: !0,
          failIfMajorPerformanceCaveat: D.FAIL_IF_MAJOR_PERFORMANCE_CAVEAT,
        };
        try {
          if (!D.ADAPTER.getWebGLRenderingContext()) return !1;
          let t = D.ADAPTER.createCanvas(),
            n =
              t.getContext(`webgl`, e) || t.getContext(`experimental-webgl`, e),
            r = !!n?.getContextAttributes()?.stencil;
          if (n) {
            let e = n.getExtension(`WEBGL_lose_context`);
            e && e.loseContext();
          }
          return (n = null), r;
        } catch {
          return !1;
        }
      })()),
    He
  );
}
var He;
function Ue() {
  return (Ue = t(() => {
    _e(), N();
  }))();
}
var We,
  Ge,
  F,
  Ke,
  qe,
  Je,
  Ye,
  Xe,
  Ze,
  Qe,
  $e,
  et,
  tt,
  nt,
  rt,
  it,
  at,
  ot,
  st,
  ct,
  lt,
  ut,
  dt,
  ft,
  pt,
  mt,
  ht,
  gt,
  _t,
  vt,
  yt,
  bt,
  xt,
  St;
function Ct() {
  return (Ct = t(() => {
    for (
      We = { grad: 0.9, turn: 360, rad: 360 / (2 * Math.PI) },
        Ge = function (e) {
          return typeof e == `string` ? e.length > 0 : typeof e == `number`;
        },
        F = function (e, t, n) {
          return (
            t === void 0 && (t = 0),
            n === void 0 && (n = 10 ** t),
            Math.round(n * e) / n + 0
          );
        },
        Ke = function (e, t, n) {
          return (
            t === void 0 && (t = 0),
            n === void 0 && (n = 1),
            e > n ? n : e > t ? e : t
          );
        },
        qe = function (e) {
          return (e = isFinite(e) ? e % 360 : 0) < 0 ? e + 360 : e;
        },
        Je = function (e, t) {
          return t === void 0 && (t = 0), F(e, t) % 360;
        },
        Ye = function (e) {
          return {
            r: Ke(e.r, 0, 255),
            g: Ke(e.g, 0, 255),
            b: Ke(e.b, 0, 255),
            a: Ke(e.a),
          };
        },
        Xe = function (e) {
          return { r: F(e.r), g: F(e.g), b: F(e.b), a: F(e.a, 3) };
        },
        Ze = /^#([0-9a-f]{3,8})$/i,
        Qe = function (e, t) {
          var n = e.charCodeAt(t);
          return (15 & n) + 9 * (n >> 6);
        },
        $e = function (e, t) {
          return (Qe(e, t) << 4) | Qe(e, t + 1);
        },
        et = [],
        tt = 0;
      tt < 256;
      tt++
    )
      et.push((tt < 16 ? `0` : ``) + tt.toString(16));
    (nt = function (e) {
      return et[Ke(e, 0, 255)];
    }),
      (rt = function (e) {
        var t = e.r,
          n = e.g,
          r = e.b,
          i = e.a,
          a = Math.max(t, n, r),
          o = a - Math.min(t, n, r),
          s = o
            ? a === t
              ? (n - r) / o
              : a === n
              ? 2 + (r - t) / o
              : 4 + (t - n) / o
            : 0;
        return {
          h: 60 * (s < 0 ? s + 6 : s),
          s: a ? (o / a) * 100 : 0,
          v: (a / 255) * 100,
          a: i,
        };
      }),
      (it = function (e) {
        var t = e.h,
          n = e.s,
          r = e.v,
          i = e.a;
        (t = (t / 360) * 6), (n /= 100), (r /= 100);
        var a = Math.floor(t),
          o = r * (1 - n),
          s = r * (1 - (t - a) * n),
          c = r * (1 - (1 - t + a) * n),
          l = a % 6;
        return {
          r: 255 * [r, s, o, o, c, r][l],
          g: 255 * [c, r, r, s, o, o][l],
          b: 255 * [o, o, c, r, r, s][l],
          a: i,
        };
      }),
      (at = function (e) {
        return {
          h: qe(e.h),
          s: Ke(e.s, 0, 100),
          l: Ke(e.l, 0, 100),
          a: Ke(e.a),
        };
      }),
      (ot = function (e) {
        return { h: Je(e.h), s: F(e.s), l: F(e.l), a: F(e.a, 3) };
      }),
      (st = function (e) {
        return it(
          ((n = (t = e).s),
          {
            h: t.h,
            s:
              (n *= ((r = t.l) < 50 ? r : 100 - r) / 100) > 0
                ? ((2 * n) / (r + n)) * 100
                : 0,
            v: r + n,
            a: t.a,
          })
        );
        var t, n, r;
      }),
      (ct = function (e) {
        return {
          h: (t = rt(e)).h,
          s:
            (i = ((200 - (n = t.s)) * (r = t.v)) / 100) > 0 && i < 200
              ? ((n * r) / 100 / (i <= 100 ? i : 200 - i)) * 100
              : 0,
          l: i / 2,
          a: t.a,
        };
        var t, n, r, i;
      }),
      (lt =
        /^hsla?\(\s*([+-]?(?:\d*\.\d+|\d+))(deg|rad|grad|turn)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))%\s*,\s*([+-]?(?:\d*\.\d+|\d+))%\s*(?:,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i),
      (ut =
        /^hsla?\(\s*([+-]?(?:\d*\.\d+|\d+))(deg|rad|grad|turn)?\s+([+-]?(?:\d*\.\d+|\d+))%\s+([+-]?(?:\d*\.\d+|\d+))%\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i),
      (dt =
        /^rgba?\(\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*(?:,\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i),
      (ft =
        /^rgba?\(\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s+([+-]?(?:\d*\.\d+|\d+))(%)?\s*(?:\/\s*([+-]?(?:\d*\.\d+|\d+))(%)?\s*)?\)$/i),
      (pt = {
        string: [
          [
            function (e) {
              if (!Ze.test(e)) return null;
              var t = e.length;
              return t <= 5
                ? {
                    r: 17 * Qe(e, 1),
                    g: 17 * Qe(e, 2),
                    b: 17 * Qe(e, 3),
                    a: t === 5 ? F((17 * Qe(e, 4)) / 255, 2) : 1,
                  }
                : t === 7 || t === 9
                ? {
                    r: $e(e, 1),
                    g: $e(e, 3),
                    b: $e(e, 5),
                    a: t === 9 ? F($e(e, 7) / 255, 2) : 1,
                  }
                : null;
            },
            `hex`,
          ],
          [
            function (e) {
              var t = dt.exec(e) || ft.exec(e);
              return t
                ? t[2] !== t[4] || t[4] !== t[6]
                  ? null
                  : Ye({
                      r: Number(t[1]) / (t[2] ? 100 / 255 : 1),
                      g: Number(t[3]) / (t[4] ? 100 / 255 : 1),
                      b: Number(t[5]) / (t[6] ? 100 / 255 : 1),
                      a: t[7] === void 0 ? 1 : Number(t[7]) / (t[8] ? 100 : 1),
                    })
                : null;
            },
            `rgb`,
          ],
          [
            function (e) {
              var t = lt.exec(e) || ut.exec(e);
              if (!t) return null;
              var n, r;
              return st(
                at({
                  h:
                    ((n = t[1]),
                    (r = t[2]),
                    r === void 0 && (r = `deg`),
                    Number(n) * (We[r] || 1)),
                  s: Number(t[3]),
                  l: Number(t[4]),
                  a: t[5] === void 0 ? 1 : Number(t[5]) / (t[6] ? 100 : 1),
                })
              );
            },
            `hsl`,
          ],
        ],
        object: [
          [
            function (e) {
              var t = e.r,
                n = e.g,
                r = e.b,
                i = e.a,
                a = i === void 0 ? 1 : i;
              return Ge(t) && Ge(n) && Ge(r)
                ? Ye({ r: Number(t), g: Number(n), b: Number(r), a: Number(a) })
                : null;
            },
            `rgb`,
          ],
          [
            function (e) {
              var t = e.h,
                n = e.s,
                r = e.l,
                i = e.a,
                a = i === void 0 ? 1 : i;
              return !Ge(t) || !Ge(n) || !Ge(r)
                ? null
                : st(
                    at({
                      h: Number(t),
                      s: Number(n),
                      l: Number(r),
                      a: Number(a),
                    })
                  );
            },
            `hsl`,
          ],
          [
            function (e) {
              var t = e.h,
                n = e.s,
                r = e.v,
                i = e.a,
                a = i === void 0 ? 1 : i;
              return !Ge(t) || !Ge(n) || !Ge(r)
                ? null
                : it(
                    (function (e) {
                      return {
                        h: qe(e.h),
                        s: Ke(e.s, 0, 100),
                        v: Ke(e.v, 0, 100),
                        a: Ke(e.a),
                      };
                    })({
                      h: Number(t),
                      s: Number(n),
                      v: Number(r),
                      a: Number(a),
                    })
                  );
            },
            `hsv`,
          ],
        ],
      }),
      (mt = function (e, t) {
        for (var n = 0; n < t.length; n++) {
          var r = t[n][0](e);
          if (r) return [r, t[n][1]];
        }
        return [null, void 0];
      }),
      (ht = function (e) {
        return typeof e == `string`
          ? mt(e.trim(), pt.string)
          : typeof e == `object` && e
          ? mt(e, pt.object)
          : [null, void 0];
      }),
      (gt = function (e, t) {
        var n = ct(e);
        return { h: n.h, s: Ke(n.s + 100 * t, 0, 100), l: n.l, a: n.a };
      }),
      (_t = function (e) {
        return (299 * e.r + 587 * e.g + 114 * e.b) / 1e3 / 255;
      }),
      (vt = function (e, t) {
        var n = ct(e);
        return { h: n.h, s: n.s, l: Ke(n.l + 100 * t, 0, 100), a: n.a };
      }),
      (yt = (function () {
        function e(e) {
          (this.parsed = ht(e)[0]),
            (this.rgba = this.parsed || { r: 0, g: 0, b: 0, a: 1 });
        }
        return (
          (e.prototype.isValid = function () {
            return this.parsed !== null;
          }),
          (e.prototype.brightness = function () {
            return F(_t(this.rgba), 2);
          }),
          (e.prototype.isDark = function () {
            return _t(this.rgba) < 0.5;
          }),
          (e.prototype.isLight = function () {
            return _t(this.rgba) >= 0.5;
          }),
          (e.prototype.toHex = function () {
            return (
              (e = Xe(this.rgba)),
              (t = e.r),
              (n = e.g),
              (r = e.b),
              (a = (i = e.a) < 1 ? nt(F(255 * i)) : ``),
              `#` + nt(t) + nt(n) + nt(r) + a
            );
            var e, t, n, r, i, a;
          }),
          (e.prototype.toRgb = function () {
            return Xe(this.rgba);
          }),
          (e.prototype.toRgbString = function () {
            return (
              (e = Xe(this.rgba)),
              (t = e.r),
              (n = e.g),
              (r = e.b),
              (i = e.a) < 1
                ? `rgba(` + t + `, ` + n + `, ` + r + `, ` + i + `)`
                : `rgb(` + t + `, ` + n + `, ` + r + `)`
            );
            var e, t, n, r, i;
          }),
          (e.prototype.toHsl = function () {
            return ot(ct(this.rgba));
          }),
          (e.prototype.toHslString = function () {
            return (
              (e = ot(ct(this.rgba))),
              (t = e.h),
              (n = e.s),
              (r = e.l),
              (i = e.a) < 1
                ? `hsla(` + t + `, ` + n + `%, ` + r + `%, ` + i + `)`
                : `hsl(` + t + `, ` + n + `%, ` + r + `%)`
            );
            var e, t, n, r, i;
          }),
          (e.prototype.toHsv = function () {
            return (
              (e = rt(this.rgba)),
              { h: Je(e.h), s: F(e.s), v: F(e.v), a: F(e.a, 3) }
            );
            var e;
          }),
          (e.prototype.invert = function () {
            return bt({
              r: 255 - (e = this.rgba).r,
              g: 255 - e.g,
              b: 255 - e.b,
              a: e.a,
            });
            var e;
          }),
          (e.prototype.saturate = function (e) {
            return e === void 0 && (e = 0.1), bt(gt(this.rgba, e));
          }),
          (e.prototype.desaturate = function (e) {
            return e === void 0 && (e = 0.1), bt(gt(this.rgba, -e));
          }),
          (e.prototype.grayscale = function () {
            return bt(gt(this.rgba, -1));
          }),
          (e.prototype.lighten = function (e) {
            return e === void 0 && (e = 0.1), bt(vt(this.rgba, e));
          }),
          (e.prototype.darken = function (e) {
            return e === void 0 && (e = 0.1), bt(vt(this.rgba, -e));
          }),
          (e.prototype.rotate = function (e) {
            return e === void 0 && (e = 15), this.hue(ct(this.rgba).h + e);
          }),
          (e.prototype.alpha = function (e) {
            return typeof e == `number`
              ? bt({ r: (t = this.rgba).r, g: t.g, b: t.b, a: e })
              : F(this.rgba.a, 3);
            var t;
          }),
          (e.prototype.hue = function (e) {
            var t = ct(this.rgba);
            return typeof e == `number`
              ? bt({ h: e, s: t.s, l: t.l, a: t.a })
              : Je(t.h);
          }),
          (e.prototype.isEqual = function (e) {
            return this.toHex() === bt(e).toHex();
          }),
          e
        );
      })()),
      (bt = function (e) {
        return e instanceof yt ? e : new yt(e);
      }),
      (xt = []),
      (St = function (e) {
        e.forEach(function (e) {
          xt.indexOf(e) < 0 && (e(yt, pt), xt.push(e));
        });
      });
  }))();
}
var wt;
function Tt() {
  return (Tt = t(() => {
    wt = function (e, t) {
      var n = {
          white: `#ffffff`,
          bisque: `#ffe4c4`,
          blue: `#0000ff`,
          cadetblue: `#5f9ea0`,
          chartreuse: `#7fff00`,
          chocolate: `#d2691e`,
          coral: `#ff7f50`,
          antiquewhite: `#faebd7`,
          aqua: `#00ffff`,
          azure: `#f0ffff`,
          whitesmoke: `#f5f5f5`,
          papayawhip: `#ffefd5`,
          plum: `#dda0dd`,
          blanchedalmond: `#ffebcd`,
          black: `#000000`,
          gold: `#ffd700`,
          goldenrod: `#daa520`,
          gainsboro: `#dcdcdc`,
          cornsilk: `#fff8dc`,
          cornflowerblue: `#6495ed`,
          burlywood: `#deb887`,
          aquamarine: `#7fffd4`,
          beige: `#f5f5dc`,
          crimson: `#dc143c`,
          cyan: `#00ffff`,
          darkblue: `#00008b`,
          darkcyan: `#008b8b`,
          darkgoldenrod: `#b8860b`,
          darkkhaki: `#bdb76b`,
          darkgray: `#a9a9a9`,
          darkgreen: `#006400`,
          darkgrey: `#a9a9a9`,
          peachpuff: `#ffdab9`,
          darkmagenta: `#8b008b`,
          darkred: `#8b0000`,
          darkorchid: `#9932cc`,
          darkorange: `#ff8c00`,
          darkslateblue: `#483d8b`,
          gray: `#808080`,
          darkslategray: `#2f4f4f`,
          darkslategrey: `#2f4f4f`,
          deeppink: `#ff1493`,
          deepskyblue: `#00bfff`,
          wheat: `#f5deb3`,
          firebrick: `#b22222`,
          floralwhite: `#fffaf0`,
          ghostwhite: `#f8f8ff`,
          darkviolet: `#9400d3`,
          magenta: `#ff00ff`,
          green: `#008000`,
          dodgerblue: `#1e90ff`,
          grey: `#808080`,
          honeydew: `#f0fff0`,
          hotpink: `#ff69b4`,
          blueviolet: `#8a2be2`,
          forestgreen: `#228b22`,
          lawngreen: `#7cfc00`,
          indianred: `#cd5c5c`,
          indigo: `#4b0082`,
          fuchsia: `#ff00ff`,
          brown: `#a52a2a`,
          maroon: `#800000`,
          mediumblue: `#0000cd`,
          lightcoral: `#f08080`,
          darkturquoise: `#00ced1`,
          lightcyan: `#e0ffff`,
          ivory: `#fffff0`,
          lightyellow: `#ffffe0`,
          lightsalmon: `#ffa07a`,
          lightseagreen: `#20b2aa`,
          linen: `#faf0e6`,
          mediumaquamarine: `#66cdaa`,
          lemonchiffon: `#fffacd`,
          lime: `#00ff00`,
          khaki: `#f0e68c`,
          mediumseagreen: `#3cb371`,
          limegreen: `#32cd32`,
          mediumspringgreen: `#00fa9a`,
          lightskyblue: `#87cefa`,
          lightblue: `#add8e6`,
          midnightblue: `#191970`,
          lightpink: `#ffb6c1`,
          mistyrose: `#ffe4e1`,
          moccasin: `#ffe4b5`,
          mintcream: `#f5fffa`,
          lightslategray: `#778899`,
          lightslategrey: `#778899`,
          navajowhite: `#ffdead`,
          navy: `#000080`,
          mediumvioletred: `#c71585`,
          powderblue: `#b0e0e6`,
          palegoldenrod: `#eee8aa`,
          oldlace: `#fdf5e6`,
          paleturquoise: `#afeeee`,
          mediumturquoise: `#48d1cc`,
          mediumorchid: `#ba55d3`,
          rebeccapurple: `#663399`,
          lightsteelblue: `#b0c4de`,
          mediumslateblue: `#7b68ee`,
          thistle: `#d8bfd8`,
          tan: `#d2b48c`,
          orchid: `#da70d6`,
          mediumpurple: `#9370db`,
          purple: `#800080`,
          pink: `#ffc0cb`,
          skyblue: `#87ceeb`,
          springgreen: `#00ff7f`,
          palegreen: `#98fb98`,
          red: `#ff0000`,
          yellow: `#ffff00`,
          slateblue: `#6a5acd`,
          lavenderblush: `#fff0f5`,
          peru: `#cd853f`,
          palevioletred: `#db7093`,
          violet: `#ee82ee`,
          teal: `#008080`,
          slategray: `#708090`,
          slategrey: `#708090`,
          aliceblue: `#f0f8ff`,
          darkseagreen: `#8fbc8f`,
          darkolivegreen: `#556b2f`,
          greenyellow: `#adff2f`,
          seagreen: `#2e8b57`,
          seashell: `#fff5ee`,
          tomato: `#ff6347`,
          silver: `#c0c0c0`,
          sienna: `#a0522d`,
          lavender: `#e6e6fa`,
          lightgreen: `#90ee90`,
          orange: `#ffa500`,
          orangered: `#ff4500`,
          steelblue: `#4682b4`,
          royalblue: `#4169e1`,
          turquoise: `#40e0d0`,
          yellowgreen: `#9acd32`,
          salmon: `#fa8072`,
          saddlebrown: `#8b4513`,
          sandybrown: `#f4a460`,
          rosybrown: `#bc8f8f`,
          darksalmon: `#e9967a`,
          lightgoldenrodyellow: `#fafad2`,
          snow: `#fffafa`,
          lightgrey: `#d3d3d3`,
          lightgray: `#d3d3d3`,
          dimgray: `#696969`,
          dimgrey: `#696969`,
          olivedrab: `#6b8e23`,
          olive: `#808000`,
        },
        r = {};
      for (var i in n) r[n[i]] = i;
      var a = {};
      (e.prototype.toName = function (t) {
        if (!(this.rgba.a || this.rgba.r || this.rgba.g || this.rgba.b))
          return `transparent`;
        var i,
          o,
          s = r[this.toHex()];
        if (s) return s;
        if (t?.closest) {
          var c = this.toRgb(),
            l = 1 / 0,
            u = `black`;
          if (!a.length) for (var d in n) a[d] = new e(n[d]).toRgb();
          for (var f in n) {
            var p =
              ((i = c),
              (o = a[f]),
              (i.r - o.r) ** 2 + (i.g - o.g) ** 2 + (i.b - o.b) ** 2);
            p < l && ((l = p), (u = f));
          }
          return u;
        }
      }),
        t.string.push([
          function (t) {
            var r = t.toLowerCase(),
              i = r === `transparent` ? `#0000` : n[r];
            return i ? new e(i).toRgb() : null;
          },
          `name`,
        ]);
    };
  }))();
}
var Et, I;
function Dt() {
  return (Dt = t(() => {
    Ct(),
      Tt(),
      St([wt]),
      (Et = class {
        constructor(e = 16777215) {
          (this._value = null),
            (this._components = new Float32Array(4)),
            this._components.fill(1),
            (this._int = 16777215),
            (this.value = e);
        }
        get red() {
          return this._components[0];
        }
        get green() {
          return this._components[1];
        }
        get blue() {
          return this._components[2];
        }
        get alpha() {
          return this._components[3];
        }
        setValue(e) {
          return (this.value = e), this;
        }
        set value(e) {
          if (e instanceof Et)
            (this._value = this.cloneSource(e._value)),
              (this._int = e._int),
              this._components.set(e._components);
          else if (e === null)
            throw Error(`Cannot set PIXI.Color#value to null`);
          else
            (this._value === null || !this.isSourceEqual(this._value, e)) &&
              (this.normalize(e), (this._value = this.cloneSource(e)));
        }
        get value() {
          return this._value;
        }
        cloneSource(e) {
          return typeof e == `string` ||
            typeof e == `number` ||
            e instanceof Number ||
            e === null
            ? e
            : Array.isArray(e) || ArrayBuffer.isView(e)
            ? e.slice(0)
            : typeof e == `object` && e
            ? { ...e }
            : e;
        }
        isSourceEqual(e, t) {
          let n = typeof e;
          if (n !== typeof t) return !1;
          if (n === `number` || n === `string` || e instanceof Number)
            return e === t;
          if (
            (Array.isArray(e) && Array.isArray(t)) ||
            (ArrayBuffer.isView(e) && ArrayBuffer.isView(t))
          )
            return e.length === t.length && e.every((e, n) => e === t[n]);
          if (e !== null && t !== null) {
            let n = Object.keys(e),
              r = Object.keys(t);
            return n.length === r.length && n.every((n) => e[n] === t[n]);
          }
          return e === t;
        }
        toRgba() {
          let [e, t, n, r] = this._components;
          return { r: e, g: t, b: n, a: r };
        }
        toRgb() {
          let [e, t, n] = this._components;
          return { r: e, g: t, b: n };
        }
        toRgbaString() {
          let [e, t, n] = this.toUint8RgbArray();
          return `rgba(${e},${t},${n},${this.alpha})`;
        }
        toUint8RgbArray(e) {
          let [t, n, r] = this._components;
          return (
            (e ??= []),
            (e[0] = Math.round(t * 255)),
            (e[1] = Math.round(n * 255)),
            (e[2] = Math.round(r * 255)),
            e
          );
        }
        toRgbArray(e) {
          e ??= [];
          let [t, n, r] = this._components;
          return (e[0] = t), (e[1] = n), (e[2] = r), e;
        }
        toNumber() {
          return this._int;
        }
        toLittleEndianNumber() {
          let e = this._int;
          return (e >> 16) + (e & 65280) + ((e & 255) << 16);
        }
        multiply(e) {
          let [t, n, r, i] = Et.temp.setValue(e)._components;
          return (
            (this._components[0] *= t),
            (this._components[1] *= n),
            (this._components[2] *= r),
            (this._components[3] *= i),
            this.refreshInt(),
            (this._value = null),
            this
          );
        }
        premultiply(e, t = !0) {
          return (
            t &&
              ((this._components[0] *= e),
              (this._components[1] *= e),
              (this._components[2] *= e)),
            (this._components[3] = e),
            this.refreshInt(),
            (this._value = null),
            this
          );
        }
        toPremultiplied(e) {
          if (e === 1) return ((e * 255) << 24) + this._int;
          if (e === 0) return 0;
          let t = (this._int >> 16) & 255,
            n = (this._int >> 8) & 255,
            r = this._int & 255;
          return (
            (t = (t * e + 0.5) | 0),
            (n = (n * e + 0.5) | 0),
            (r = (r * e + 0.5) | 0),
            ((e * 255) << 24) + (t << 16) + (n << 8) + r
          );
        }
        toHex() {
          let e = this._int.toString(16);
          return `#${`000000`.substring(0, 6 - e.length) + e}`;
        }
        toHexa() {
          let e = Math.round(this._components[3] * 255).toString(16);
          return this.toHex() + `00`.substring(0, 2 - e.length) + e;
        }
        setAlpha(e) {
          return (this._components[3] = this._clamp(e)), this;
        }
        round(e) {
          let [t, n, r] = this._components;
          return (
            (this._components[0] = Math.round(t * e) / e),
            (this._components[1] = Math.round(n * e) / e),
            (this._components[2] = Math.round(r * e) / e),
            this.refreshInt(),
            (this._value = null),
            this
          );
        }
        toArray(e) {
          e ??= [];
          let [t, n, r, i] = this._components;
          return (e[0] = t), (e[1] = n), (e[2] = r), (e[3] = i), e;
        }
        normalize(e) {
          let t;
          if (
            (typeof e == `number` || e instanceof Number) &&
            e >= 0 &&
            e <= 16777215
          ) {
            let n = e;
            t = [
              ((n >> 16) & 255) / 255,
              ((n >> 8) & 255) / 255,
              (n & 255) / 255,
              1,
            ];
          } else if (
            (Array.isArray(e) || e instanceof Float32Array) &&
            e.length >= 3 &&
            e.length <= 4
          ) {
            e = this._clamp(e);
            let [n, r, i, a = 1] = e;
            t = [n, r, i, a];
          } else if (
            (e instanceof Uint8Array || e instanceof Uint8ClampedArray) &&
            e.length >= 3 &&
            e.length <= 4
          ) {
            e = this._clamp(e, 0, 255);
            let [n, r, i, a = 255] = e;
            t = [n / 255, r / 255, i / 255, a / 255];
          } else if (typeof e == `string` || typeof e == `object`) {
            if (typeof e == `string`) {
              let t = Et.HEX_PATTERN.exec(e);
              t && (e = `#${t[2]}`);
            }
            let n = bt(e);
            if (n.isValid()) {
              let { r: e, g: r, b: i, a } = n.rgba;
              t = [e / 255, r / 255, i / 255, a];
            }
          }
          if (t) this._components.set(t), this.refreshInt();
          else throw Error(`Unable to convert color ${e}`);
        }
        refreshInt() {
          this._clamp(this._components);
          let [e, t, n] = this._components;
          this._int = ((e * 255) << 16) + ((t * 255) << 8) + ((n * 255) | 0);
        }
        _clamp(e, t = 0, n = 1) {
          return typeof e == `number`
            ? Math.min(Math.max(e, t), n)
            : (e.forEach((r, i) => {
                e[i] = Math.min(Math.max(r, t), n);
              }),
              e);
        }
      }),
      (I = Et),
      (I.shared = new Et()),
      (I.temp = new Et()),
      (I.HEX_PATTERN = /^(#|0x)?(([a-f0-9]{3}){1,2}([a-f0-9]{2})?)$/i);
  }))();
}
function Ot() {
  return (Ot = t(() => {
    Dt();
  }))();
}
function kt(e, t = []) {
  return (
    P(`7.2.0`, `utils.hex2rgb is deprecated, use Color#toRgbArray instead`),
    I.shared.setValue(e).toRgbArray(t)
  );
}
function At(e) {
  return (
    P(`7.2.0`, `utils.hex2string is deprecated, use Color#toHex instead`),
    I.shared.setValue(e).toHex()
  );
}
function jt(e) {
  return (
    P(`7.2.0`, `utils.string2hex is deprecated, use Color#toNumber instead`),
    I.shared.setValue(e).toNumber()
  );
}
function Mt(e) {
  return (
    P(`7.2.0`, `utils.rgb2hex is deprecated, use Color#toNumber instead`),
    I.shared.setValue(e).toNumber()
  );
}
function Nt() {
  return (Nt = t(() => {
    Ot(), Le();
  }))();
}
function Pt() {
  let e = [],
    t = [];
  for (let n = 0; n < 32; n++) (e[n] = n), (t[n] = n);
  (e[c.NORMAL_NPM] = c.NORMAL),
    (e[c.ADD_NPM] = c.ADD),
    (e[c.SCREEN_NPM] = c.SCREEN),
    (t[c.NORMAL] = c.NORMAL_NPM),
    (t[c.ADD] = c.ADD_NPM),
    (t[c.SCREEN] = c.SCREEN_NPM);
  let n = [];
  return n.push(t), n.push(e), n;
}
function Ft(e, t) {
  return zt[+!!t][e];
}
function It(e, t, n, r = !0) {
  return (
    P(`7.2.0`, `utils.premultiplyRgba has moved to Color.premultiply`),
    I.shared
      .setValue(e)
      .premultiply(t, r)
      .toArray(n ?? new Float32Array(4))
  );
}
function Lt(e, t) {
  return (
    P(`7.2.0`, `utils.premultiplyTint has moved to Color.toPremultiplied`),
    I.shared.setValue(e).toPremultiplied(t)
  );
}
function Rt(e, t, n, r = !0) {
  return (
    P(`7.2.0`, `utils.premultiplyTintToRgba has moved to Color.premultiply`),
    I.shared
      .setValue(e)
      .premultiply(t, r)
      .toArray(n ?? new Float32Array(4))
  );
}
var zt;
function Bt() {
  return (Bt = t(() => {
    Ot(), w(), Le(), (zt = Pt());
  }))();
}
var Vt;
function Ht() {
  return (Ht = t(() => {
    Vt =
      /^\s*data:(?:([\w-]+)\/([\w+.-]+))?(?:;charset=([\w-]+))?(?:;(base64))?,(.*)/i;
  }))();
}
function Ut(e, t = null) {
  let n = e * 6;
  if (((t ||= new Uint16Array(n)), t.length !== n))
    throw Error(
      `Out buffer length is incorrect, got ${t.length} and expected ${n}`
    );
  for (let e = 0, r = 0; e < n; e += 6, r += 4)
    (t[e + 0] = r + 0),
      (t[e + 1] = r + 1),
      (t[e + 2] = r + 2),
      (t[e + 3] = r + 0),
      (t[e + 4] = r + 2),
      (t[e + 5] = r + 3);
  return t;
}
function Wt(e) {
  if (e.BYTES_PER_ELEMENT === 4)
    return e instanceof Float32Array
      ? `Float32Array`
      : e instanceof Uint32Array
      ? `Uint32Array`
      : `Int32Array`;
  if (e.BYTES_PER_ELEMENT === 2) {
    if (e instanceof Uint16Array) return `Uint16Array`;
  } else if (e.BYTES_PER_ELEMENT === 1 && e instanceof Uint8Array)
    return `Uint8Array`;
  return null;
}
function Gt(e, t) {
  let n = 0,
    r = 0,
    i = {};
  for (let i = 0; i < e.length; i++) (r += t[i]), (n += e[i].length);
  let a = new ArrayBuffer(n * 4),
    o = null,
    s = 0;
  for (let n = 0; n < e.length; n++) {
    let c = t[n],
      l = e[n],
      u = Wt(l);
    i[u] || (i[u] = new Kt[u](a)), (o = i[u]);
    for (let e = 0; e < l.length; e++) {
      let t = ((e / c) | 0) * r + s,
        n = e % c;
      o[t + n] = l[e];
    }
    s += c;
  }
  return new Float32Array(a);
}
var Kt;
function qt() {
  return (qt = t(() => {
    Kt = { Float32Array, Uint32Array, Int32Array, Uint8Array };
  }))();
}
function Jt(e) {
  return (
    (e += +(e === 0)),
    --e,
    (e |= e >>> 1),
    (e |= e >>> 2),
    (e |= e >>> 4),
    (e |= e >>> 8),
    (e |= e >>> 16),
    e + 1
  );
}
function Yt(e) {
  return !(e & (e - 1)) && !!e;
}
function Xt(e) {
  let t = (e > 65535) << 4;
  e >>>= t;
  let n = (e > 255) << 3;
  return (
    (e >>>= n),
    (t |= n),
    (n = (e > 15) << 2),
    (e >>>= n),
    (t |= n),
    (n = (e > 3) << 1),
    (e >>>= n),
    (t |= n),
    t | (e >> 1)
  );
}
function Zt(e, t, n) {
  let r = e.length,
    i;
  if (t >= r || n === 0) return;
  n = t + n > r ? r - t : n;
  let a = r - n;
  for (i = t; i < a; ++i) e[i] = e[i + n];
  e.length = a;
}
function Qt() {
  return (Qt = t(() => {}))();
}
function $t(e) {
  return e === 0 ? 0 : e < 0 ? -1 : 1;
}
function en() {
  return (en = t(() => {}))();
}
function tn() {
  return ++nn;
}
var nn;
function rn() {
  return (rn = t(() => {
    nn = 0;
  }))();
}
var an, on;
function sn() {
  return (sn = t(() => {
    (an = class {
      constructor(e, t, n, r) {
        (this.left = e), (this.top = t), (this.right = n), (this.bottom = r);
      }
      get width() {
        return this.right - this.left;
      }
      get height() {
        return this.bottom - this.top;
      }
      isEmpty() {
        return this.left === this.right || this.top === this.bottom;
      }
    }),
      (on = an),
      (on.EMPTY = new an(0, 0, 0, 0));
  }))();
}
function cn() {
  let e;
  for (e in L) L[e].destroy();
  for (e in dn) dn[e].destroy();
}
function ln() {
  let e;
  for (e in L) delete L[e];
  for (e in dn) delete dn[e];
}
var un, L, dn;
function fn() {
  return (fn = t(() => {
    (un = {}), (L = Object.create(null)), (dn = Object.create(null));
  }))();
}
var pn;
function mn() {
  return (mn = t(() => {
    N(),
      (pn = class {
        constructor(e, t, n) {
          (this._canvas = D.ADAPTER.createCanvas()),
            (this._context = this._canvas.getContext(`2d`)),
            (this.resolution = n || D.RESOLUTION),
            this.resize(e, t);
        }
        clear() {
          this._checkDestroyed(),
            this._context.setTransform(1, 0, 0, 1, 0, 0),
            this._context.clearRect(
              0,
              0,
              this._canvas.width,
              this._canvas.height
            );
        }
        resize(e, t) {
          this._checkDestroyed(),
            (this._canvas.width = Math.round(e * this.resolution)),
            (this._canvas.height = Math.round(t * this.resolution));
        }
        destroy() {
          (this._context = null), (this._canvas = null);
        }
        get width() {
          return this._checkDestroyed(), this._canvas.width;
        }
        set width(e) {
          this._checkDestroyed(), (this._canvas.width = Math.round(e));
        }
        get height() {
          return this._checkDestroyed(), this._canvas.height;
        }
        set height(e) {
          this._checkDestroyed(), (this._canvas.height = Math.round(e));
        }
        get canvas() {
          return this._checkDestroyed(), this._canvas;
        }
        get context() {
          return this._checkDestroyed(), this._context;
        }
        _checkDestroyed() {
          if (this._canvas === null)
            throw TypeError(
              `The CanvasRenderTarget has already been destroyed`
            );
        }
      });
  }))();
}
function hn(e, t, n) {
  for (let r = 0, i = 4 * n * t; r < t; ++r, i += 4)
    if (e[i + 3] !== 0) return !1;
  return !0;
}
function gn(e, t, n, r, i) {
  let a = 4 * t;
  for (let t = r, o = r * a + 4 * n; t <= i; ++t, o += a)
    if (e[o + 3] !== 0) return !1;
  return !0;
}
function _n(e) {
  let { width: t, height: n } = e,
    r = e.getContext(`2d`, { willReadFrequently: !0 });
  if (r === null) throw TypeError(`Failed to get canvas 2D context`);
  let i = r.getImageData(0, 0, t, n).data,
    a = 0,
    o = 0,
    s = t - 1,
    c = n - 1;
  for (; o < n && hn(i, t, o); ) ++o;
  if (o === n) return on.EMPTY;
  for (; hn(i, t, c); ) --c;
  for (; gn(i, t, a, o, c); ) ++a;
  for (; gn(i, t, s, o, c); ) --s;
  return ++s, ++c, new on(a, o, s, c);
}
function vn() {
  return (vn = t(() => {
    sn();
  }))();
}
function yn(e) {
  let t = _n(e),
    { width: n, height: r } = t,
    i = null;
  if (!t.isEmpty()) {
    let a = e.getContext(`2d`);
    if (a === null) throw TypeError(`Failed to get canvas 2D context`);
    i = a.getImageData(t.left, t.top, n, r);
  }
  return { width: n, height: r, data: i };
}
function bn() {
  return (bn = t(() => {
    vn();
  }))();
}
function xn(e) {
  let t = Vt.exec(e);
  if (t)
    return {
      mediaType: t[1] ? t[1].toLowerCase() : void 0,
      subType: t[2] ? t[2].toLowerCase() : void 0,
      charset: t[3] ? t[3].toLowerCase() : void 0,
      encoding: t[4] ? t[4].toLowerCase() : void 0,
      data: t[5],
    };
}
function Sn() {
  return (Sn = t(() => {
    Ht();
  }))();
}
function Cn(e, t = globalThis.location) {
  if (e.startsWith(`data:`)) return ``;
  (t ||= globalThis.location),
    (wn ||= document.createElement(`a`)),
    (wn.href = e);
  let n = De.parse(wn.href),
    r = (!n.port && t.port === ``) || n.port === t.port;
  return n.hostname !== t.hostname || !r || n.protocol !== t.protocol
    ? `anonymous`
    : ``;
}
var wn;
function Tn() {
  return (Tn = t(() => {
    Oe();
  }))();
}
function En(e, t = 1) {
  let n = D.RETINA_PREFIX?.exec(e);
  return n ? parseFloat(n[1]) : t;
}
function Dn() {
  return (Dn = t(() => {
    _e(), N();
  }))();
}
var On = n({
    BaseTextureCache: () => dn,
    BoundingBox: () => on,
    CanvasRenderTarget: () => pn,
    DATA_URI: () => Vt,
    EventEmitter: () => kn.default,
    ProgramCache: () => un,
    TextureCache: () => L,
    clearTextureCache: () => ln,
    correctBlendMode: () => Ft,
    createIndicesForQuads: () => Ut,
    decomposeDataUri: () => xn,
    deprecation: () => P,
    destroyTextureCache: () => cn,
    determineCrossOrigin: () => Cn,
    earcut: () => An.default,
    getBufferType: () => Wt,
    getCanvasBoundingBox: () => _n,
    getResolutionOfUrl: () => En,
    hex2rgb: () => kt,
    hex2string: () => At,
    interleaveTypedArrays: () => Gt,
    isMobile: () => he,
    isPow2: () => Yt,
    isWebGLSupported: () => Ve,
    log2: () => Xt,
    nextPow2: () => Jt,
    path: () => Pe,
    premultiplyBlendMode: () => zt,
    premultiplyRgba: () => It,
    premultiplyTint: () => Lt,
    premultiplyTintToRgba: () => Rt,
    removeItems: () => Zt,
    rgb2hex: () => Mt,
    sayHello: () => ze,
    sign: () => $t,
    skipHello: () => Re,
    string2hex: () => jt,
    trimCanvas: () => yn,
    uid: () => tn,
    url: () => De,
  }),
  kn,
  An;
function R() {
  return (R = t(() => {
    _e(),
      N(),
      (kn = e(ve(), 1)),
      (An = e(ye(), 1)),
      Oe(),
      Fe(),
      Be(),
      Ue(),
      Nt(),
      Bt(),
      Ht(),
      qt(),
      rn(),
      Le(),
      sn(),
      fn(),
      mn(),
      vn(),
      bn(),
      Sn(),
      Tn(),
      Dn();
  }))();
}
var z, jn, Mn, B;
function V() {
  return (V = t(() => {
    (z = ((e) => (
      (e.Renderer = `renderer`),
      (e.Application = `application`),
      (e.RendererSystem = `renderer-webgl-system`),
      (e.RendererPlugin = `renderer-webgl-plugin`),
      (e.CanvasRendererSystem = `renderer-canvas-system`),
      (e.CanvasRendererPlugin = `renderer-canvas-plugin`),
      (e.Asset = `asset`),
      (e.LoadParser = `load-parser`),
      (e.ResolveParser = `resolve-parser`),
      (e.CacheParser = `cache-parser`),
      (e.DetectionParser = `detection-parser`),
      e
    ))(z || {})),
      (jn = (e) => {
        if (typeof e == `function` || (typeof e == `object` && e.extension)) {
          if (!e.extension)
            throw Error(`Extension class must have an extension object`);
          e = {
            ...(typeof e.extension == `object`
              ? e.extension
              : { type: e.extension }),
            ref: e,
          };
        }
        if (typeof e == `object`) e = { ...e };
        else throw Error(`Invalid extension type`);
        return typeof e.type == `string` && (e.type = [e.type]), e;
      }),
      (Mn = (e, t) => jn(e).priority ?? t),
      (B = {
        _addHandlers: {},
        _removeHandlers: {},
        _queue: {},
        remove(...e) {
          return (
            e.map(jn).forEach((e) => {
              e.type.forEach((t) => this._removeHandlers[t]?.(e));
            }),
            this
          );
        },
        add(...e) {
          return (
            e.map(jn).forEach((e) => {
              e.type.forEach((t) => {
                let n = this._addHandlers,
                  r = this._queue;
                n[t] ? n[t](e) : ((r[t] = r[t] || []), r[t].push(e));
              });
            }),
            this
          );
        },
        handle(e, t, n) {
          let r = this._addHandlers,
            i = this._removeHandlers;
          if (r[e] || i[e])
            throw Error(`Extension type ${e} already has a handler`);
          (r[e] = t), (i[e] = n);
          let a = this._queue;
          return a[e] && (a[e].forEach((e) => t(e)), delete a[e]), this;
        },
        handleByMap(e, t) {
          return this.handle(
            e,
            (e) => {
              t[e.name] = e.ref;
            },
            (e) => {
              delete t[e.name];
            }
          );
        },
        handleByList(e, t, n = -1) {
          return this.handle(
            e,
            (e) => {
              t.includes(e.ref) ||
                (t.push(e.ref), t.sort((e, t) => Mn(t, n) - Mn(e, n)));
            },
            (e) => {
              let n = t.indexOf(e.ref);
              n !== -1 && t.splice(n, 1);
            }
          );
        },
      });
  }))();
}
var Nn;
function Pn() {
  return (Pn = t(() => {
    Nn = class {
      constructor(e) {
        (this.rawBinaryData =
          typeof e == `number`
            ? new ArrayBuffer(e)
            : e instanceof Uint8Array
            ? e.buffer
            : e),
          (this.uint32View = new Uint32Array(this.rawBinaryData)),
          (this.float32View = new Float32Array(this.rawBinaryData));
      }
      get int8View() {
        return (
          (this._int8View ||= new Int8Array(this.rawBinaryData)), this._int8View
        );
      }
      get uint8View() {
        return (
          (this._uint8View ||= new Uint8Array(this.rawBinaryData)),
          this._uint8View
        );
      }
      get int16View() {
        return (
          (this._int16View ||= new Int16Array(this.rawBinaryData)),
          this._int16View
        );
      }
      get uint16View() {
        return (
          (this._uint16View ||= new Uint16Array(this.rawBinaryData)),
          this._uint16View
        );
      }
      get int32View() {
        return (
          (this._int32View ||= new Int32Array(this.rawBinaryData)),
          this._int32View
        );
      }
      view(e) {
        return this[`${e}View`];
      }
      destroy() {
        (this.rawBinaryData = null),
          (this._int8View = null),
          (this._uint8View = null),
          (this._int16View = null),
          (this._uint16View = null),
          (this._int32View = null),
          (this.uint32View = null),
          (this.float32View = null);
      }
      static sizeOf(e) {
        switch (e) {
          case `int8`:
          case `uint8`:
            return 1;
          case `int16`:
          case `uint16`:
            return 2;
          case `int32`:
          case `uint32`:
          case `float32`:
            return 4;
          default:
            throw Error(`${e} isn't a valid view type`);
        }
      }
    };
  }))();
}
function Fn(e) {
  let t = ``;
  for (let n = 0; n < e; ++n)
    n > 0 &&
      (t += `
else `),
      n < e - 1 && (t += `if(test == ${n}.0){}`);
  return t;
}
function In(e, t) {
  if (e === 0)
    throw Error(
      "Invalid value of `0` passed to `checkMaxIfStatementsInShader`"
    );
  let n = t.createShader(t.FRAGMENT_SHADER);
  for (;;) {
    let r = Ln.replace(/%forloop%/gi, Fn(e));
    if (
      (t.shaderSource(n, r),
      t.compileShader(n),
      !t.getShaderParameter(n, t.COMPILE_STATUS))
    )
      e = (e / 2) | 0;
    else break;
  }
  return e;
}
var Ln;
function Rn() {
  return (Rn = t(() => {
    Ln = [
      `precision mediump float;`,
      `void main(void){`,
      `float test = 0.1;`,
      `%forloop%`,
      `gl_FragColor = vec4(0.0);`,
      `}`,
    ].join(`
`);
  }))();
}
var zn;
function Bn() {
  return (Bn = t(() => {
    w(),
      (zn = class e {
        constructor() {
          (this.data = 0),
            (this.blendMode = c.NORMAL),
            (this.polygonOffset = 0),
            (this.blend = !0),
            (this.depthMask = !0);
        }
        get blend() {
          return !!(this.data & 1);
        }
        set blend(e) {
          !!(this.data & 1) !== e && (this.data ^= 1);
        }
        get offsets() {
          return !!(this.data & 2);
        }
        set offsets(e) {
          !!(this.data & 2) !== e && (this.data ^= 2);
        }
        get culling() {
          return !!(this.data & 4);
        }
        set culling(e) {
          !!(this.data & 4) !== e && (this.data ^= 4);
        }
        get depthTest() {
          return !!(this.data & 8);
        }
        set depthTest(e) {
          !!(this.data & 8) !== e && (this.data ^= 8);
        }
        get depthMask() {
          return !!(this.data & 32);
        }
        set depthMask(e) {
          !!(this.data & 32) !== e && (this.data ^= 32);
        }
        get clockwiseFrontFace() {
          return !!(this.data & 16);
        }
        set clockwiseFrontFace(e) {
          !!(this.data & 16) !== e && (this.data ^= 16);
        }
        get blendMode() {
          return this._blendMode;
        }
        set blendMode(e) {
          (this.blend = e !== c.NONE), (this._blendMode = e);
        }
        get polygonOffset() {
          return this._polygonOffset;
        }
        set polygonOffset(e) {
          (this.offsets = !!e), (this._polygonOffset = e);
        }
        toString() {
          return `[@pixi/core:State blendMode=${this.blendMode} clockwiseFrontFace=${this.clockwiseFrontFace} culling=${this.culling} depthMask=${this.depthMask} polygonOffset=${this.polygonOffset}]`;
        }
        static for2d() {
          let t = new e();
          return (t.depthTest = !1), (t.blend = !0), t;
        }
      });
  }))();
}
function Vn(e, t) {
  if (!e) return null;
  let n = ``;
  if (typeof e == `string`) {
    let t = /\.(\w{3,4})(?:$|\?|#)/i.exec(e);
    t && (n = t[1].toLowerCase());
  }
  for (let r = Hn.length - 1; r >= 0; --r) {
    let i = Hn[r];
    if (i.test && i.test(e, n)) return new i(e, t);
  }
  throw Error(`Unrecognized source type to auto-detect Resource`);
}
var Hn;
function Un() {
  return (Un = t(() => {
    Hn = [];
  }))();
}
var Wn;
function Gn() {
  return (Gn = t(() => {
    (Wn = class {
      constructor(e) {
        (this.items = []), (this._name = e), (this._aliasCount = 0);
      }
      emit(e, t, n, r, i, a, o, s) {
        if (arguments.length > 8) throw Error(`max arguments reached`);
        let { name: c, items: l } = this;
        this._aliasCount++;
        for (let u = 0, d = l.length; u < d; u++)
          l[u][c](e, t, n, r, i, a, o, s);
        return l === this.items && this._aliasCount--, this;
      }
      ensureNonAliasedItems() {
        this._aliasCount > 0 &&
          this.items.length > 1 &&
          ((this._aliasCount = 0), (this.items = this.items.slice(0)));
      }
      add(e) {
        return (
          e[this._name] &&
            (this.ensureNonAliasedItems(), this.remove(e), this.items.push(e)),
          this
        );
      }
      remove(e) {
        let t = this.items.indexOf(e);
        return (
          t !== -1 && (this.ensureNonAliasedItems(), this.items.splice(t, 1)),
          this
        );
      }
      contains(e) {
        return this.items.includes(e);
      }
      removeAll() {
        return this.ensureNonAliasedItems(), (this.items.length = 0), this;
      }
      destroy() {
        this.removeAll(), (this.items = null), (this._name = null);
      }
      get empty() {
        return this.items.length === 0;
      }
      get name() {
        return this._name;
      }
    }),
      Object.defineProperties(Wn.prototype, {
        dispatch: { value: Wn.prototype.emit },
        run: { value: Wn.prototype.emit },
      });
  }))();
}
function Kn() {
  return (Kn = t(() => {
    Gn();
  }))();
}
var qn;
function Jn() {
  return (Jn = t(() => {
    Kn(),
      (qn = class {
        constructor(e = 0, t = 0) {
          (this._width = e),
            (this._height = t),
            (this.destroyed = !1),
            (this.internal = !1),
            (this.onResize = new Wn(`setRealSize`)),
            (this.onUpdate = new Wn(`update`)),
            (this.onError = new Wn(`onError`));
        }
        bind(e) {
          this.onResize.add(e),
            this.onUpdate.add(e),
            this.onError.add(e),
            (this._width || this._height) &&
              this.onResize.emit(this._width, this._height);
        }
        unbind(e) {
          this.onResize.remove(e),
            this.onUpdate.remove(e),
            this.onError.remove(e);
        }
        resize(e, t) {
          (e !== this._width || t !== this._height) &&
            ((this._width = e), (this._height = t), this.onResize.emit(e, t));
        }
        get valid() {
          return !!this._width && !!this._height;
        }
        update() {
          this.destroyed || this.onUpdate.emit();
        }
        load() {
          return Promise.resolve(this);
        }
        get width() {
          return this._width;
        }
        get height() {
          return this._height;
        }
        style(e, t, n) {
          return !1;
        }
        dispose() {}
        destroy() {
          this.destroyed ||
            ((this.destroyed = !0),
            this.dispose(),
            this.onError.removeAll(),
            (this.onError = null),
            this.onResize.removeAll(),
            (this.onResize = null),
            this.onUpdate.removeAll(),
            (this.onUpdate = null));
        }
        static test(e, t) {
          return !1;
        }
      });
  }))();
}
var Yn;
function Xn() {
  return (Xn = t(() => {
    w(),
      Jn(),
      (Yn = class extends qn {
        constructor(e, t) {
          let { width: n, height: r } = t || {};
          if (!n || !r) throw Error(`BufferResource width or height invalid`);
          super(n, r), (this.data = e);
        }
        upload(e, t, n) {
          let r = e.gl;
          r.pixelStorei(
            r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
            t.alphaMode === _.UNPACK
          );
          let i = t.realWidth,
            a = t.realHeight;
          return (
            n.width === i && n.height === a
              ? r.texSubImage2D(
                  t.target,
                  0,
                  0,
                  0,
                  i,
                  a,
                  t.format,
                  n.type,
                  this.data
                )
              : ((n.width = i),
                (n.height = a),
                r.texImage2D(
                  t.target,
                  0,
                  n.internalFormat,
                  i,
                  a,
                  0,
                  t.format,
                  n.type,
                  this.data
                )),
            !0
          );
        }
        dispose() {
          this.data = null;
        }
        static test(e) {
          return (
            e instanceof Float32Array ||
            e instanceof Uint8Array ||
            e instanceof Uint32Array
          );
        }
      });
  }))();
}
var Zn, Qn, H;
function $n() {
  return ($n = t(() => {
    w(),
      N(),
      R(),
      Un(),
      Xn(),
      Jn(),
      (Zn = { scaleMode: m.NEAREST, format: u.RGBA, alphaMode: _.NPM }),
      (Qn = class extends kn.default {
        constructor(e = null, t = null) {
          super(), (t = Object.assign({}, Qn.defaultOptions, t));
          let {
            alphaMode: n,
            mipmap: r,
            anisotropicLevel: i,
            scaleMode: a,
            width: o,
            height: s,
            wrapMode: c,
            format: l,
            type: u,
            target: d,
            resolution: f,
            resourceOptions: p,
          } = t;
          e && !(e instanceof qn) && ((e = Vn(e, p)), (e.internal = !0)),
            (this.resolution = f || D.RESOLUTION),
            (this.width =
              Math.round((o || 0) * this.resolution) / this.resolution),
            (this.height =
              Math.round((s || 0) * this.resolution) / this.resolution),
            (this._mipmap = r),
            (this.anisotropicLevel = i),
            (this._wrapMode = c),
            (this._scaleMode = a),
            (this.format = l),
            (this.type = u),
            (this.target = d),
            (this.alphaMode = n),
            (this.uid = tn()),
            (this.touched = 0),
            (this.isPowerOfTwo = !1),
            this._refreshPOT(),
            (this._glTextures = {}),
            (this.dirtyId = 0),
            (this.dirtyStyleId = 0),
            (this.cacheId = null),
            (this.valid = o > 0 && s > 0),
            (this.textureCacheIds = []),
            (this.destroyed = !1),
            (this.resource = null),
            (this._batchEnabled = 0),
            (this._batchLocation = 0),
            (this.parentTextureArray = null),
            this.setResource(e);
        }
        get realWidth() {
          return Math.round(this.width * this.resolution);
        }
        get realHeight() {
          return Math.round(this.height * this.resolution);
        }
        get mipmap() {
          return this._mipmap;
        }
        set mipmap(e) {
          this._mipmap !== e && ((this._mipmap = e), this.dirtyStyleId++);
        }
        get scaleMode() {
          return this._scaleMode;
        }
        set scaleMode(e) {
          this._scaleMode !== e && ((this._scaleMode = e), this.dirtyStyleId++);
        }
        get wrapMode() {
          return this._wrapMode;
        }
        set wrapMode(e) {
          this._wrapMode !== e && ((this._wrapMode = e), this.dirtyStyleId++);
        }
        setStyle(e, t) {
          let n;
          return (
            e !== void 0 &&
              e !== this.scaleMode &&
              ((this.scaleMode = e), (n = !0)),
            t !== void 0 && t !== this.mipmap && ((this.mipmap = t), (n = !0)),
            n && this.dirtyStyleId++,
            this
          );
        }
        setSize(e, t, n) {
          return (n ||= this.resolution), this.setRealSize(e * n, t * n, n);
        }
        setRealSize(e, t, n) {
          return (
            (this.resolution = n || this.resolution),
            (this.width = Math.round(e) / this.resolution),
            (this.height = Math.round(t) / this.resolution),
            this._refreshPOT(),
            this.update(),
            this
          );
        }
        _refreshPOT() {
          this.isPowerOfTwo = Yt(this.realWidth) && Yt(this.realHeight);
        }
        setResolution(e) {
          let t = this.resolution;
          return t === e
            ? this
            : ((this.resolution = e),
              this.valid &&
                ((this.width = Math.round(this.width * t) / e),
                (this.height = Math.round(this.height * t) / e),
                this.emit(`update`, this)),
              this._refreshPOT(),
              this);
        }
        setResource(e) {
          if (this.resource === e) return this;
          if (this.resource) throw Error(`Resource can be set only once`);
          return e.bind(this), (this.resource = e), this;
        }
        update() {
          this.valid
            ? (this.dirtyId++, this.dirtyStyleId++, this.emit(`update`, this))
            : this.width > 0 &&
              this.height > 0 &&
              ((this.valid = !0),
              this.emit(`loaded`, this),
              this.emit(`update`, this));
        }
        onError(e) {
          this.emit(`error`, this, e);
        }
        destroy() {
          (this.resource &&=
            (this.resource.unbind(this),
            this.resource.internal && this.resource.destroy(),
            null)),
            (this.cacheId &&=
              (delete dn[this.cacheId], delete L[this.cacheId], null)),
            this.dispose(),
            Qn.removeFromCache(this),
            (this.textureCacheIds = null),
            (this.destroyed = !0);
        }
        dispose() {
          this.emit(`dispose`, this);
        }
        castToBaseTexture() {
          return this;
        }
        static from(e, t, n = D.STRICT_TEXTURE_CACHE) {
          let r = typeof e == `string`,
            i = null;
          r
            ? (i = e)
            : ((e._pixiId ||= `${t?.pixiIdPrefix || `pixiid`}_${tn()}`),
              (i = e._pixiId));
          let a = dn[i];
          if (r && n && !a)
            throw Error(
              `The cacheId "${i}" does not exist in BaseTextureCache.`
            );
          return (
            a || ((a = new Qn(e, t)), (a.cacheId = i), Qn.addToCache(a, i)), a
          );
        }
        static fromBuffer(e, t, n, r) {
          e ||= new Float32Array(t * n * 4);
          let i = new Yn(e, { width: t, height: n }),
            a = e instanceof Float32Array ? f.FLOAT : f.UNSIGNED_BYTE;
          return new Qn(
            i,
            Object.assign({}, Zn, r || { width: t, height: n, type: a })
          );
        }
        static addToCache(e, t) {
          t &&
            (e.textureCacheIds.includes(t) || e.textureCacheIds.push(t),
            dn[t] &&
              dn[t] !== e &&
              console.warn(
                `BaseTexture added to the cache with an id [${t}] that already had an entry`
              ),
            (dn[t] = e));
        }
        static removeFromCache(e) {
          if (typeof e == `string`) {
            let t = dn[e];
            if (t) {
              let n = t.textureCacheIds.indexOf(e);
              return n > -1 && t.textureCacheIds.splice(n, 1), delete dn[e], t;
            }
          } else if (e?.textureCacheIds) {
            for (let t = 0; t < e.textureCacheIds.length; ++t)
              delete dn[e.textureCacheIds[t]];
            return (e.textureCacheIds.length = 0), e;
          }
          return null;
        }
      }),
      (H = Qn),
      (H.defaultOptions = {
        mipmap: g.POW2,
        anisotropicLevel: 0,
        scaleMode: m.LINEAR,
        wrapMode: h.CLAMP,
        alphaMode: _.UNPACK,
        target: d.TEXTURE_2D,
        format: u.RGBA,
        type: f.UNSIGNED_BYTE,
      }),
      (H._globalBatch = 0);
  }))();
}
var er;
function tr() {
  return (tr = t(() => {
    w(),
      (er = class {
        constructor() {
          (this.texArray = null),
            (this.blend = 0),
            (this.type = l.TRIANGLES),
            (this.start = 0),
            (this.size = 0),
            (this.data = null);
        }
      });
  }))();
}
var nr, U;
function rr() {
  return (rr = t(() => {
    w(),
      Kn(),
      (nr = 0),
      (U = class e {
        constructor(e, t = !0, n = !1) {
          (this.data = e || new Float32Array(1)),
            (this._glBuffers = {}),
            (this._updateID = 0),
            (this.index = n),
            (this.static = t),
            (this.id = nr++),
            (this.disposeRunner = new Wn(`disposeBuffer`));
        }
        update(e) {
          e instanceof Array && (e = new Float32Array(e)),
            (this.data = e || this.data),
            this._updateID++;
        }
        dispose() {
          this.disposeRunner.emit(this, !1);
        }
        destroy() {
          this.dispose(), (this.data = null);
        }
        set index(e) {
          this.type = e ? C.ELEMENT_ARRAY_BUFFER : C.ARRAY_BUFFER;
        }
        get index() {
          return this.type === C.ELEMENT_ARRAY_BUFFER;
        }
        static from(t) {
          return t instanceof Array && (t = new Float32Array(t)), new e(t);
        }
      });
  }))();
}
var ir;
function ar() {
  return (ar = t(() => {
    w(),
      (ir = class e {
        constructor(e, t = 0, n = !1, r = f.FLOAT, i, a, o, s = 1) {
          (this.buffer = e),
            (this.size = t),
            (this.normalized = n),
            (this.type = r),
            (this.stride = i),
            (this.start = a),
            (this.instance = o),
            (this.divisor = s);
        }
        destroy() {
          this.buffer = null;
        }
        static from(t, n, r, i, a) {
          return new e(t, n, r, i, a);
        }
      });
  }))();
}
function or(e, t) {
  let n = 0,
    r = 0,
    i = {};
  for (let i = 0; i < e.length; i++) (r += t[i]), (n += e[i].length);
  let a = new ArrayBuffer(n * 4),
    o = null,
    s = 0;
  for (let n = 0; n < e.length; n++) {
    let c = t[n],
      l = e[n],
      u = Wt(l);
    i[u] || (i[u] = new sr[u](a)), (o = i[u]);
    for (let e = 0; e < l.length; e++) {
      let t = ((e / c) | 0) * r + s,
        n = e % c;
      o[t + n] = l[e];
    }
    s += c;
  }
  return new Float32Array(a);
}
var sr;
function cr() {
  return (cr = t(() => {
    R(), (sr = { Float32Array, Uint32Array, Int32Array, Uint8Array });
  }))();
}
var lr, ur, dr, fr;
function pr() {
  return (pr = t(() => {
    w(),
      Kn(),
      R(),
      ar(),
      rr(),
      cr(),
      (lr = { 5126: 4, 5123: 2, 5121: 1 }),
      (ur = 0),
      (dr = { Float32Array, Uint32Array, Int32Array, Uint8Array, Uint16Array }),
      (fr = class e {
        constructor(e = [], t = {}) {
          (this.buffers = e),
            (this.indexBuffer = null),
            (this.attributes = t),
            (this.glVertexArrayObjects = {}),
            (this.id = ur++),
            (this.instanced = !1),
            (this.instanceCount = 1),
            (this.disposeRunner = new Wn(`disposeGeometry`)),
            (this.refCount = 0);
        }
        addAttribute(e, t, n = 0, r = !1, i, a, o, s = !1) {
          if (!t)
            throw Error(`You must pass a buffer when creating an attribute`);
          t instanceof U ||
            (t instanceof Array && (t = new Float32Array(t)), (t = new U(t)));
          let c = e.split(`|`);
          if (c.length > 1) {
            for (let e = 0; e < c.length; e++)
              this.addAttribute(c[e], t, n, r, i);
            return this;
          }
          let l = this.buffers.indexOf(t);
          return (
            l === -1 && (this.buffers.push(t), (l = this.buffers.length - 1)),
            (this.attributes[e] = new ir(l, n, r, i, a, o, s)),
            (this.instanced = this.instanced || s),
            this
          );
        }
        getAttribute(e) {
          return this.attributes[e];
        }
        getBuffer(e) {
          return this.buffers[this.getAttribute(e).buffer];
        }
        addIndex(e) {
          return (
            e instanceof U ||
              (e instanceof Array && (e = new Uint16Array(e)), (e = new U(e))),
            (e.type = C.ELEMENT_ARRAY_BUFFER),
            (this.indexBuffer = e),
            this.buffers.includes(e) || this.buffers.push(e),
            this
          );
        }
        getIndex() {
          return this.indexBuffer;
        }
        interleave() {
          if (
            this.buffers.length === 1 ||
            (this.buffers.length === 2 && this.indexBuffer)
          )
            return this;
          let e = [],
            t = [],
            n = new U(),
            r;
          for (r in this.attributes) {
            let n = this.attributes[r],
              i = this.buffers[n.buffer];
            e.push(i.data), t.push((n.size * lr[n.type]) / 4), (n.buffer = 0);
          }
          for (n.data = or(e, t), r = 0; r < this.buffers.length; r++)
            this.buffers[r] !== this.indexBuffer && this.buffers[r].destroy();
          return (
            (this.buffers = [n]),
            this.indexBuffer && this.buffers.push(this.indexBuffer),
            this
          );
        }
        getSize() {
          for (let e in this.attributes) {
            let t = this.attributes[e];
            return (
              this.buffers[t.buffer].data.length / (t.stride / 4 || t.size)
            );
          }
          return 0;
        }
        dispose() {
          this.disposeRunner.emit(this, !1);
        }
        destroy() {
          this.dispose(),
            (this.buffers = null),
            (this.indexBuffer = null),
            (this.attributes = null);
        }
        clone() {
          let t = new e();
          for (let e = 0; e < this.buffers.length; e++)
            t.buffers[e] = new U(this.buffers[e].data.slice(0));
          for (let e in this.attributes) {
            let n = this.attributes[e];
            t.attributes[e] = new ir(
              n.buffer,
              n.size,
              n.normalized,
              n.type,
              n.stride,
              n.start,
              n.instance
            );
          }
          return (
            this.indexBuffer &&
              ((t.indexBuffer =
                t.buffers[this.buffers.indexOf(this.indexBuffer)]),
              (t.indexBuffer.type = C.ELEMENT_ARRAY_BUFFER)),
            t
          );
        }
        static merge(t) {
          let n = new e(),
            r = [],
            i = [],
            a = [],
            o;
          for (let e = 0; e < t.length; e++) {
            o = t[e];
            for (let e = 0; e < o.buffers.length; e++)
              (i[e] = i[e] || 0),
                (i[e] += o.buffers[e].data.length),
                (a[e] = 0);
          }
          for (let e = 0; e < o.buffers.length; e++)
            (r[e] = new dr[Wt(o.buffers[e].data)](i[e])),
              (n.buffers[e] = new U(r[e]));
          for (let e = 0; e < t.length; e++) {
            o = t[e];
            for (let e = 0; e < o.buffers.length; e++)
              r[e].set(o.buffers[e].data, a[e]),
                (a[e] += o.buffers[e].data.length);
          }
          if (((n.attributes = o.attributes), o.indexBuffer)) {
            (n.indexBuffer = n.buffers[o.buffers.indexOf(o.indexBuffer)]),
              (n.indexBuffer.type = C.ELEMENT_ARRAY_BUFFER);
            let e = 0,
              r = 0,
              i = 0,
              a = 0;
            for (let e = 0; e < o.buffers.length; e++)
              if (o.buffers[e] !== o.indexBuffer) {
                a = e;
                break;
              }
            for (let e in o.attributes) {
              let t = o.attributes[e];
              (t.buffer | 0) === a && (r += (t.size * lr[t.type]) / 4);
            }
            for (let o = 0; o < t.length; o++) {
              let s = t[o].indexBuffer.data;
              for (let t = 0; t < s.length; t++) n.indexBuffer.data[t + i] += e;
              (e += t[o].buffers[a].data.length / r), (i += s.length);
            }
          }
          return n;
        }
      });
  }))();
}
var mr;
function hr() {
  return (hr = t(() => {
    w(),
      rr(),
      pr(),
      (mr = class extends fr {
        constructor(e = !1) {
          super(),
            (this._buffer = new U(null, e, !1)),
            (this._indexBuffer = new U(null, e, !0)),
            this.addAttribute(`aVertexPosition`, this._buffer, 2, !1, f.FLOAT)
              .addAttribute(`aTextureCoord`, this._buffer, 2, !1, f.FLOAT)
              .addAttribute(`aColor`, this._buffer, 4, !0, f.UNSIGNED_BYTE)
              .addAttribute(`aTextureId`, this._buffer, 1, !0, f.FLOAT)
              .addIndex(this._indexBuffer);
        }
      });
  }))();
}
var gr, _r, vr, W;
function yr() {
  return (yr = t(() => {
    (gr = Math.PI * 2),
      (_r = 180 / Math.PI),
      (vr = Math.PI / 180),
      (W = ((e) => (
        (e[(e.POLY = 0)] = `POLY`),
        (e[(e.RECT = 1)] = `RECT`),
        (e[(e.CIRC = 2)] = `CIRC`),
        (e[(e.ELIP = 3)] = `ELIP`),
        (e[(e.RREC = 4)] = `RREC`),
        e
      ))(W || {}));
  }))();
}
var G;
function br() {
  return (br = t(() => {
    G = class e {
      constructor(e = 0, t = 0) {
        (this.x = 0), (this.y = 0), (this.x = e), (this.y = t);
      }
      clone() {
        return new e(this.x, this.y);
      }
      copyFrom(e) {
        return this.set(e.x, e.y), this;
      }
      copyTo(e) {
        return e.set(this.x, this.y), e;
      }
      equals(e) {
        return e.x === this.x && e.y === this.y;
      }
      set(e = 0, t = e) {
        return (this.x = e), (this.y = t), this;
      }
      toString() {
        return `[@pixi/math:Point x=${this.x} y=${this.y}]`;
      }
    };
  }))();
}
var xr, K;
function Sr() {
  return (Sr = t(() => {
    yr(),
      br(),
      (xr = [new G(), new G(), new G(), new G()]),
      (K = class e {
        constructor(e = 0, t = 0, n = 0, r = 0) {
          (this.x = Number(e)),
            (this.y = Number(t)),
            (this.width = Number(n)),
            (this.height = Number(r)),
            (this.type = W.RECT);
        }
        get left() {
          return this.x;
        }
        get right() {
          return this.x + this.width;
        }
        get top() {
          return this.y;
        }
        get bottom() {
          return this.y + this.height;
        }
        static get EMPTY() {
          return new e(0, 0, 0, 0);
        }
        clone() {
          return new e(this.x, this.y, this.width, this.height);
        }
        copyFrom(e) {
          return (
            (this.x = e.x),
            (this.y = e.y),
            (this.width = e.width),
            (this.height = e.height),
            this
          );
        }
        copyTo(e) {
          return (
            (e.x = this.x),
            (e.y = this.y),
            (e.width = this.width),
            (e.height = this.height),
            e
          );
        }
        contains(e, t) {
          return this.width <= 0 || this.height <= 0
            ? !1
            : e >= this.x &&
                e < this.x + this.width &&
                t >= this.y &&
                t < this.y + this.height;
        }
        intersects(e, t) {
          if (!t) {
            let t = this.x < e.x ? e.x : this.x;
            if ((this.right > e.right ? e.right : this.right) <= t) return !1;
            let n = this.y < e.y ? e.y : this.y;
            return (this.bottom > e.bottom ? e.bottom : this.bottom) > n;
          }
          let n = this.left,
            r = this.right,
            i = this.top,
            a = this.bottom;
          if (r <= n || a <= i) return !1;
          let o = xr[0].set(e.left, e.top),
            s = xr[1].set(e.left, e.bottom),
            c = xr[2].set(e.right, e.top),
            l = xr[3].set(e.right, e.bottom);
          if (c.x <= o.x || s.y <= o.y) return !1;
          let u = Math.sign(t.a * t.d - t.b * t.c);
          if (
            u === 0 ||
            (t.apply(o, o),
            t.apply(s, s),
            t.apply(c, c),
            t.apply(l, l),
            Math.max(o.x, s.x, c.x, l.x) <= n ||
              Math.min(o.x, s.x, c.x, l.x) >= r ||
              Math.max(o.y, s.y, c.y, l.y) <= i ||
              Math.min(o.y, s.y, c.y, l.y) >= a)
          )
            return !1;
          let d = u * (s.y - o.y),
            f = u * (o.x - s.x),
            p = d * n + f * i,
            m = d * r + f * i,
            h = d * n + f * a,
            g = d * r + f * a;
          if (
            Math.max(p, m, h, g) <= d * o.x + f * o.y ||
            Math.min(p, m, h, g) >= d * l.x + f * l.y
          )
            return !1;
          let _ = u * (o.y - c.y),
            v = u * (c.x - o.x),
            y = _ * n + v * i,
            b = _ * r + v * i,
            x = _ * n + v * a,
            S = _ * r + v * a;
          return !(
            Math.max(y, b, x, S) <= _ * o.x + v * o.y ||
            Math.min(y, b, x, S) >= _ * l.x + v * l.y
          );
        }
        pad(e = 0, t = e) {
          return (
            (this.x -= e),
            (this.y -= t),
            (this.width += e * 2),
            (this.height += t * 2),
            this
          );
        }
        fit(e) {
          let t = Math.max(this.x, e.x),
            n = Math.min(this.x + this.width, e.x + e.width),
            r = Math.max(this.y, e.y),
            i = Math.min(this.y + this.height, e.y + e.height);
          return (
            (this.x = t),
            (this.width = Math.max(n - t, 0)),
            (this.y = r),
            (this.height = Math.max(i - r, 0)),
            this
          );
        }
        ceil(e = 1, t = 0.001) {
          let n = Math.ceil((this.x + this.width - t) * e) / e,
            r = Math.ceil((this.y + this.height - t) * e) / e;
          return (
            (this.x = Math.floor((this.x + t) * e) / e),
            (this.y = Math.floor((this.y + t) * e) / e),
            (this.width = n - this.x),
            (this.height = r - this.y),
            this
          );
        }
        enlarge(e) {
          let t = Math.min(this.x, e.x),
            n = Math.max(this.x + this.width, e.x + e.width),
            r = Math.min(this.y, e.y),
            i = Math.max(this.y + this.height, e.y + e.height);
          return (
            (this.x = t),
            (this.width = n - t),
            (this.y = r),
            (this.height = i - r),
            this
          );
        }
        toString() {
          return `[@pixi/math:Rectangle x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
        }
      });
  }))();
}
var Cr;
function wr() {
  return (wr = t(() => {
    yr(),
      Sr(),
      (Cr = class e {
        constructor(e = 0, t = 0, n = 0) {
          (this.x = e), (this.y = t), (this.radius = n), (this.type = W.CIRC);
        }
        clone() {
          return new e(this.x, this.y, this.radius);
        }
        contains(e, t) {
          if (this.radius <= 0) return !1;
          let n = this.radius * this.radius,
            r = this.x - e,
            i = this.y - t;
          return (r *= r), (i *= i), r + i <= n;
        }
        getBounds() {
          return new K(
            this.x - this.radius,
            this.y - this.radius,
            this.radius * 2,
            this.radius * 2
          );
        }
        toString() {
          return `[@pixi/math:Circle x=${this.x} y=${this.y} radius=${this.radius}]`;
        }
      });
  }))();
}
var Tr;
function Er() {
  return (Er = t(() => {
    yr(),
      Sr(),
      (Tr = class e {
        constructor(e = 0, t = 0, n = 0, r = 0) {
          (this.x = e),
            (this.y = t),
            (this.width = n),
            (this.height = r),
            (this.type = W.ELIP);
        }
        clone() {
          return new e(this.x, this.y, this.width, this.height);
        }
        contains(e, t) {
          if (this.width <= 0 || this.height <= 0) return !1;
          let n = (e - this.x) / this.width,
            r = (t - this.y) / this.height;
          return (n *= n), (r *= r), n + r <= 1;
        }
        getBounds() {
          return new K(
            this.x - this.width,
            this.y - this.height,
            this.width,
            this.height
          );
        }
        toString() {
          return `[@pixi/math:Ellipse x=${this.x} y=${this.y} width=${this.width} height=${this.height}]`;
        }
      });
  }))();
}
var Dr;
function Or() {
  return (Or = t(() => {
    yr(),
      (Dr = class e {
        constructor(...e) {
          let t = Array.isArray(e[0]) ? e[0] : e;
          if (typeof t[0] != `number`) {
            let e = [];
            for (let n = 0, r = t.length; n < r; n++) e.push(t[n].x, t[n].y);
            t = e;
          }
          (this.points = t), (this.type = W.POLY), (this.closeStroke = !0);
        }
        clone() {
          let t = this.points.slice(),
            n = new e(t);
          return (n.closeStroke = this.closeStroke), n;
        }
        contains(e, t) {
          let n = !1,
            r = this.points.length / 2;
          for (let i = 0, a = r - 1; i < r; a = i++) {
            let r = this.points[i * 2],
              o = this.points[i * 2 + 1],
              s = this.points[a * 2],
              c = this.points[a * 2 + 1];
            o > t != c > t && e < (s - r) * ((t - o) / (c - o)) + r && (n = !n);
          }
          return n;
        }
        toString() {
          return `[@pixi/math:PolygoncloseStroke=${
            this.closeStroke
          }points=${this.points.reduce((e, t) => `${e}, ${t}`, ``)}]`;
        }
      });
  }))();
}
var kr;
function Ar() {
  return (Ar = t(() => {
    yr(),
      (kr = class e {
        constructor(e = 0, t = 0, n = 0, r = 0, i = 20) {
          (this.x = e),
            (this.y = t),
            (this.width = n),
            (this.height = r),
            (this.radius = i),
            (this.type = W.RREC);
        }
        clone() {
          return new e(this.x, this.y, this.width, this.height, this.radius);
        }
        contains(e, t) {
          if (this.width <= 0 || this.height <= 0) return !1;
          if (
            e >= this.x &&
            e <= this.x + this.width &&
            t >= this.y &&
            t <= this.y + this.height
          ) {
            let n = Math.max(
              0,
              Math.min(this.radius, Math.min(this.width, this.height) / 2)
            );
            if (
              (t >= this.y + n && t <= this.y + this.height - n) ||
              (e >= this.x + n && e <= this.x + this.width - n)
            )
              return !0;
            let r = e - (this.x + n),
              i = t - (this.y + n),
              a = n * n;
            if (
              r * r + i * i <= a ||
              ((r = e - (this.x + this.width - n)), r * r + i * i <= a) ||
              ((i = t - (this.y + this.height - n)), r * r + i * i <= a) ||
              ((r = e - (this.x + n)), r * r + i * i <= a)
            )
              return !0;
          }
          return !1;
        }
        toString() {
          return `[@pixi/math:RoundedRectangle x=${this.x} y=${this.y}width=${this.width} height=${this.height} radius=${this.radius}]`;
        }
      });
  }))();
}
var q;
function jr() {
  return (jr = t(() => {
    yr(),
      br(),
      (q = class e {
        constructor(e = 1, t = 0, n = 0, r = 1, i = 0, a = 0) {
          (this.array = null),
            (this.a = e),
            (this.b = t),
            (this.c = n),
            (this.d = r),
            (this.tx = i),
            (this.ty = a);
        }
        fromArray(e) {
          (this.a = e[0]),
            (this.b = e[1]),
            (this.c = e[3]),
            (this.d = e[4]),
            (this.tx = e[2]),
            (this.ty = e[5]);
        }
        set(e, t, n, r, i, a) {
          return (
            (this.a = e),
            (this.b = t),
            (this.c = n),
            (this.d = r),
            (this.tx = i),
            (this.ty = a),
            this
          );
        }
        toArray(e, t) {
          this.array ||= new Float32Array(9);
          let n = t || this.array;
          return (
            e
              ? ((n[0] = this.a),
                (n[1] = this.b),
                (n[2] = 0),
                (n[3] = this.c),
                (n[4] = this.d),
                (n[5] = 0),
                (n[6] = this.tx),
                (n[7] = this.ty),
                (n[8] = 1))
              : ((n[0] = this.a),
                (n[1] = this.c),
                (n[2] = this.tx),
                (n[3] = this.b),
                (n[4] = this.d),
                (n[5] = this.ty),
                (n[6] = 0),
                (n[7] = 0),
                (n[8] = 1)),
            n
          );
        }
        apply(e, t) {
          t ||= new G();
          let n = e.x,
            r = e.y;
          return (
            (t.x = this.a * n + this.c * r + this.tx),
            (t.y = this.b * n + this.d * r + this.ty),
            t
          );
        }
        applyInverse(e, t) {
          t ||= new G();
          let n = 1 / (this.a * this.d + this.c * -this.b),
            r = e.x,
            i = e.y;
          return (
            (t.x =
              this.d * n * r +
              -this.c * n * i +
              (this.ty * this.c - this.tx * this.d) * n),
            (t.y =
              this.a * n * i +
              -this.b * n * r +
              (-this.ty * this.a + this.tx * this.b) * n),
            t
          );
        }
        translate(e, t) {
          return (this.tx += e), (this.ty += t), this;
        }
        scale(e, t) {
          return (
            (this.a *= e),
            (this.d *= t),
            (this.c *= e),
            (this.b *= t),
            (this.tx *= e),
            (this.ty *= t),
            this
          );
        }
        rotate(e) {
          let t = Math.cos(e),
            n = Math.sin(e),
            r = this.a,
            i = this.c,
            a = this.tx;
          return (
            (this.a = r * t - this.b * n),
            (this.b = r * n + this.b * t),
            (this.c = i * t - this.d * n),
            (this.d = i * n + this.d * t),
            (this.tx = a * t - this.ty * n),
            (this.ty = a * n + this.ty * t),
            this
          );
        }
        append(e) {
          let t = this.a,
            n = this.b,
            r = this.c,
            i = this.d;
          return (
            (this.a = e.a * t + e.b * r),
            (this.b = e.a * n + e.b * i),
            (this.c = e.c * t + e.d * r),
            (this.d = e.c * n + e.d * i),
            (this.tx = e.tx * t + e.ty * r + this.tx),
            (this.ty = e.tx * n + e.ty * i + this.ty),
            this
          );
        }
        setTransform(e, t, n, r, i, a, o, s, c) {
          return (
            (this.a = Math.cos(o + c) * i),
            (this.b = Math.sin(o + c) * i),
            (this.c = -Math.sin(o - s) * a),
            (this.d = Math.cos(o - s) * a),
            (this.tx = e - (n * this.a + r * this.c)),
            (this.ty = t - (n * this.b + r * this.d)),
            this
          );
        }
        prepend(e) {
          let t = this.tx;
          if (e.a !== 1 || e.b !== 0 || e.c !== 0 || e.d !== 1) {
            let t = this.a,
              n = this.c;
            (this.a = t * e.a + this.b * e.c),
              (this.b = t * e.b + this.b * e.d),
              (this.c = n * e.a + this.d * e.c),
              (this.d = n * e.b + this.d * e.d);
          }
          return (
            (this.tx = t * e.a + this.ty * e.c + e.tx),
            (this.ty = t * e.b + this.ty * e.d + e.ty),
            this
          );
        }
        decompose(e) {
          let t = this.a,
            n = this.b,
            r = this.c,
            i = this.d,
            a = e.pivot,
            o = -Math.atan2(-r, i),
            s = Math.atan2(n, t),
            c = Math.abs(o + s);
          return (
            c < 1e-5 || Math.abs(gr - c) < 1e-5
              ? ((e.rotation = s), (e.skew.x = e.skew.y = 0))
              : ((e.rotation = 0), (e.skew.x = o), (e.skew.y = s)),
            (e.scale.x = Math.sqrt(t * t + n * n)),
            (e.scale.y = Math.sqrt(r * r + i * i)),
            (e.position.x = this.tx + (a.x * t + a.y * r)),
            (e.position.y = this.ty + (a.x * n + a.y * i)),
            e
          );
        }
        invert() {
          let e = this.a,
            t = this.b,
            n = this.c,
            r = this.d,
            i = this.tx,
            a = e * r - t * n;
          return (
            (this.a = r / a),
            (this.b = -t / a),
            (this.c = -n / a),
            (this.d = e / a),
            (this.tx = (n * this.ty - r * i) / a),
            (this.ty = -(e * this.ty - t * i) / a),
            this
          );
        }
        identity() {
          return (
            (this.a = 1),
            (this.b = 0),
            (this.c = 0),
            (this.d = 1),
            (this.tx = 0),
            (this.ty = 0),
            this
          );
        }
        clone() {
          let t = new e();
          return (
            (t.a = this.a),
            (t.b = this.b),
            (t.c = this.c),
            (t.d = this.d),
            (t.tx = this.tx),
            (t.ty = this.ty),
            t
          );
        }
        copyTo(e) {
          return (
            (e.a = this.a),
            (e.b = this.b),
            (e.c = this.c),
            (e.d = this.d),
            (e.tx = this.tx),
            (e.ty = this.ty),
            e
          );
        }
        copyFrom(e) {
          return (
            (this.a = e.a),
            (this.b = e.b),
            (this.c = e.c),
            (this.d = e.d),
            (this.tx = e.tx),
            (this.ty = e.ty),
            this
          );
        }
        toString() {
          return `[@pixi/math:Matrix a=${this.a} b=${this.b} c=${this.c} d=${this.d} tx=${this.tx} ty=${this.ty}]`;
        }
        static get IDENTITY() {
          return new e();
        }
        static get TEMP_MATRIX() {
          return new e();
        }
      });
  }))();
}
function Mr() {
  for (let e = 0; e < 16; e++) {
    let t = [];
    Lr.push(t);
    for (let n = 0; n < 16; n++) {
      let r = zr(Nr[e] * Nr[n] + Fr[e] * Pr[n]),
        i = zr(Pr[e] * Nr[n] + Ir[e] * Pr[n]),
        a = zr(Nr[e] * Fr[n] + Fr[e] * Ir[n]),
        o = zr(Pr[e] * Fr[n] + Ir[e] * Ir[n]);
      for (let e = 0; e < 16; e++)
        if (Nr[e] === r && Pr[e] === i && Fr[e] === a && Ir[e] === o) {
          t.push(e);
          break;
        }
    }
  }
  for (let e = 0; e < 16; e++) {
    let t = new q();
    t.set(Nr[e], Pr[e], Fr[e], Ir[e], 0, 0), Rr.push(t);
  }
}
var Nr, Pr, Fr, Ir, Lr, Rr, zr, J;
function Br() {
  return (Br = t(() => {
    jr(),
      (Nr = [1, 1, 0, -1, -1, -1, 0, 1, 1, 1, 0, -1, -1, -1, 0, 1]),
      (Pr = [0, 1, 1, 1, 0, -1, -1, -1, 0, 1, 1, 1, 0, -1, -1, -1]),
      (Fr = [0, -1, -1, -1, 0, 1, 1, 1, 0, 1, 1, 1, 0, -1, -1, -1]),
      (Ir = [1, 1, 0, -1, -1, -1, 0, 1, -1, -1, 0, 1, 1, 1, 0, -1]),
      (Lr = []),
      (Rr = []),
      (zr = Math.sign),
      Mr(),
      (J = {
        E: 0,
        SE: 1,
        S: 2,
        SW: 3,
        W: 4,
        NW: 5,
        N: 6,
        NE: 7,
        MIRROR_VERTICAL: 8,
        MAIN_DIAGONAL: 10,
        MIRROR_HORIZONTAL: 12,
        REVERSE_DIAGONAL: 14,
        uX: (e) => Nr[e],
        uY: (e) => Pr[e],
        vX: (e) => Fr[e],
        vY: (e) => Ir[e],
        inv: (e) => (e & 8 ? e & 15 : -e & 7),
        add: (e, t) => Lr[e][t],
        sub: (e, t) => Lr[e][J.inv(t)],
        rotate180: (e) => e ^ 4,
        isVertical: (e) => (e & 3) == 2,
        byDirection: (e, t) =>
          Math.abs(e) * 2 <= Math.abs(t)
            ? t >= 0
              ? J.S
              : J.N
            : Math.abs(t) * 2 <= Math.abs(e)
            ? e > 0
              ? J.E
              : J.W
            : t > 0
            ? e > 0
              ? J.SE
              : J.SW
            : e > 0
            ? J.NE
            : J.NW,
        matrixAppendRotationInv: (e, t, n = 0, r = 0) => {
          let i = Rr[J.inv(t)];
          (i.tx = n), (i.ty = r), e.append(i);
        },
      });
  }))();
}
var Vr;
function Hr() {
  return (Hr = t(() => {
    Vr = class e {
      constructor(e, t, n = 0, r = 0) {
        (this._x = n), (this._y = r), (this.cb = e), (this.scope = t);
      }
      clone(t = this.cb, n = this.scope) {
        return new e(t, n, this._x, this._y);
      }
      set(e = 0, t = e) {
        return (
          (this._x !== e || this._y !== t) &&
            ((this._x = e), (this._y = t), this.cb.call(this.scope)),
          this
        );
      }
      copyFrom(e) {
        return (
          (this._x !== e.x || this._y !== e.y) &&
            ((this._x = e.x), (this._y = e.y), this.cb.call(this.scope)),
          this
        );
      }
      copyTo(e) {
        return e.set(this._x, this._y), e;
      }
      equals(e) {
        return e.x === this._x && e.y === this._y;
      }
      toString() {
        return `[@pixi/math:ObservablePoint x=0 y=0 scope=${this.scope}]`;
      }
      get x() {
        return this._x;
      }
      set x(e) {
        this._x !== e && ((this._x = e), this.cb.call(this.scope));
      }
      get y() {
        return this._y;
      }
      set y(e) {
        this._y !== e && ((this._y = e), this.cb.call(this.scope));
      }
    };
  }))();
}
var Ur, Wr;
function Gr() {
  return (Gr = t(() => {
    jr(),
      Hr(),
      (Ur = class {
        constructor() {
          (this.worldTransform = new q()),
            (this.localTransform = new q()),
            (this.position = new Vr(this.onChange, this, 0, 0)),
            (this.scale = new Vr(this.onChange, this, 1, 1)),
            (this.pivot = new Vr(this.onChange, this, 0, 0)),
            (this.skew = new Vr(this.updateSkew, this, 0, 0)),
            (this._rotation = 0),
            (this._cx = 1),
            (this._sx = 0),
            (this._cy = 0),
            (this._sy = 1),
            (this._localID = 0),
            (this._currentLocalID = 0),
            (this._worldID = 0),
            (this._parentID = 0);
        }
        onChange() {
          this._localID++;
        }
        updateSkew() {
          (this._cx = Math.cos(this._rotation + this.skew.y)),
            (this._sx = Math.sin(this._rotation + this.skew.y)),
            (this._cy = -Math.sin(this._rotation - this.skew.x)),
            (this._sy = Math.cos(this._rotation - this.skew.x)),
            this._localID++;
        }
        toString() {
          return `[@pixi/math:Transform position=(${this.position.x}, ${this.position.y}) rotation=${this.rotation} scale=(${this.scale.x}, ${this.scale.y}) skew=(${this.skew.x}, ${this.skew.y}) ]`;
        }
        updateLocalTransform() {
          let e = this.localTransform;
          this._localID !== this._currentLocalID &&
            ((e.a = this._cx * this.scale.x),
            (e.b = this._sx * this.scale.x),
            (e.c = this._cy * this.scale.y),
            (e.d = this._sy * this.scale.y),
            (e.tx =
              this.position.x - (this.pivot.x * e.a + this.pivot.y * e.c)),
            (e.ty =
              this.position.y - (this.pivot.x * e.b + this.pivot.y * e.d)),
            (this._currentLocalID = this._localID),
            (this._parentID = -1));
        }
        updateTransform(e) {
          let t = this.localTransform;
          if (
            (this._localID !== this._currentLocalID &&
              ((t.a = this._cx * this.scale.x),
              (t.b = this._sx * this.scale.x),
              (t.c = this._cy * this.scale.y),
              (t.d = this._sy * this.scale.y),
              (t.tx =
                this.position.x - (this.pivot.x * t.a + this.pivot.y * t.c)),
              (t.ty =
                this.position.y - (this.pivot.x * t.b + this.pivot.y * t.d)),
              (this._currentLocalID = this._localID),
              (this._parentID = -1)),
            this._parentID !== e._worldID)
          ) {
            let n = e.worldTransform,
              r = this.worldTransform;
            (r.a = t.a * n.a + t.b * n.c),
              (r.b = t.a * n.b + t.b * n.d),
              (r.c = t.c * n.a + t.d * n.c),
              (r.d = t.c * n.b + t.d * n.d),
              (r.tx = t.tx * n.a + t.ty * n.c + n.tx),
              (r.ty = t.tx * n.b + t.ty * n.d + n.ty),
              (this._parentID = e._worldID),
              this._worldID++;
          }
        }
        setFromMatrix(e) {
          e.decompose(this), this._localID++;
        }
        get rotation() {
          return this._rotation;
        }
        set rotation(e) {
          this._rotation !== e && ((this._rotation = e), this.updateSkew());
        }
      }),
      (Wr = Ur),
      (Wr.IDENTITY = new Ur());
  }))();
}
function Y() {
  return (Y = t(() => {
    wr(), Er(), Or(), Sr(), Ar(), Br(), jr(), Hr(), br(), Gr(), yr();
  }))();
}
var Kr;
function qr() {
  return (qr = t(() => {
    Kr = `varying vec2 vTextureCoord;

uniform sampler2D uSampler;

void main(void){
   gl_FragColor *= texture2D(uSampler, vTextureCoord);
}`;
  }))();
}
var Jr;
function Yr() {
  return (Yr = t(() => {
    Jr = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void){
   gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
   vTextureCoord = aTextureCoord;
}
`;
  }))();
}
function Xr(e, t, n) {
  let r = e.createShader(t);
  return e.shaderSource(r, n), e.compileShader(r), r;
}
function Zr(e) {
  let t = Array(e);
  for (let e = 0; e < t.length; e++) t[e] = !1;
  return t;
}
function Qr(e, t) {
  switch (e) {
    case `float`:
      return 0;
    case `vec2`:
      return new Float32Array(2 * t);
    case `vec3`:
      return new Float32Array(3 * t);
    case `vec4`:
      return new Float32Array(4 * t);
    case `int`:
    case `uint`:
    case `sampler2D`:
    case `sampler2DArray`:
      return 0;
    case `ivec2`:
      return new Int32Array(2 * t);
    case `ivec3`:
      return new Int32Array(3 * t);
    case `ivec4`:
      return new Int32Array(4 * t);
    case `uvec2`:
      return new Uint32Array(2 * t);
    case `uvec3`:
      return new Uint32Array(3 * t);
    case `uvec4`:
      return new Uint32Array(4 * t);
    case `bool`:
      return !1;
    case `bvec2`:
      return Zr(2 * t);
    case `bvec3`:
      return Zr(3 * t);
    case `bvec4`:
      return Zr(4 * t);
    case `mat2`:
      return new Float32Array([1, 0, 0, 1]);
    case `mat3`:
      return new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
    case `mat4`:
      return new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
  }
  return null;
}
var $r;
function ei() {
  return (ei = t(() => {
    $r = [
      {
        test: (e) => e.type === `float` && e.size === 1 && !e.isArray,
        code: (e) => `
            if(uv["${e}"] !== ud["${e}"].value)
            {
                ud["${e}"].value = uv["${e}"]
                gl.uniform1f(ud["${e}"].location, uv["${e}"])
            }
            `,
      },
      {
        test: (e, t) =>
          (e.type === `sampler2D` ||
            e.type === `samplerCube` ||
            e.type === `sampler2DArray`) &&
          e.size === 1 &&
          !e.isArray &&
          (t == null || t.castToBaseTexture !== void 0),
        code: (e) => `t = syncData.textureCount++;

            renderer.texture.bind(uv["${e}"], t);

            if(ud["${e}"].value !== t)
            {
                ud["${e}"].value = t;
                gl.uniform1i(ud["${e}"].location, t);
; // eslint-disable-line max-len
            }`,
      },
      {
        test: (e, t) =>
          e.type === `mat3` && e.size === 1 && !e.isArray && t.a !== void 0,
        code: (e) => `
            gl.uniformMatrix3fv(ud["${e}"].location, false, uv["${e}"].toArray(true));
            `,
        codeUbo: (e) => `
                var ${e}_matrix = uv.${e}.toArray(true);

                data[offset] = ${e}_matrix[0];
                data[offset+1] = ${e}_matrix[1];
                data[offset+2] = ${e}_matrix[2];
        
                data[offset + 4] = ${e}_matrix[3];
                data[offset + 5] = ${e}_matrix[4];
                data[offset + 6] = ${e}_matrix[5];
        
                data[offset + 8] = ${e}_matrix[6];
                data[offset + 9] = ${e}_matrix[7];
                data[offset + 10] = ${e}_matrix[8];
            `,
      },
      {
        test: (e, t) =>
          e.type === `vec2` && e.size === 1 && !e.isArray && t.x !== void 0,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v.x || cv[1] !== v.y)
                {
                    cv[0] = v.x;
                    cv[1] = v.y;
                    gl.uniform2f(ud["${e}"].location, v.x, v.y);
                }`,
        codeUbo: (e) => `
                v = uv.${e};

                data[offset] = v.x;
                data[offset+1] = v.y;
            `,
      },
      {
        test: (e) => e.type === `vec2` && e.size === 1 && !e.isArray,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v[0] || cv[1] !== v[1])
                {
                    cv[0] = v[0];
                    cv[1] = v[1];
                    gl.uniform2f(ud["${e}"].location, v[0], v[1]);
                }
            `,
      },
      {
        test: (e, t) =>
          e.type === `vec4` && e.size === 1 && !e.isArray && t.width !== void 0,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v.x || cv[1] !== v.y || cv[2] !== v.width || cv[3] !== v.height)
                {
                    cv[0] = v.x;
                    cv[1] = v.y;
                    cv[2] = v.width;
                    cv[3] = v.height;
                    gl.uniform4f(ud["${e}"].location, v.x, v.y, v.width, v.height)
                }`,
        codeUbo: (e) => `
                    v = uv.${e};

                    data[offset] = v.x;
                    data[offset+1] = v.y;
                    data[offset+2] = v.width;
                    data[offset+3] = v.height;
                `,
      },
      {
        test: (e, t) =>
          e.type === `vec4` && e.size === 1 && !e.isArray && t.red !== void 0,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue || cv[3] !== v.alpha)
                {
                    cv[0] = v.red;
                    cv[1] = v.green;
                    cv[2] = v.blue;
                    cv[3] = v.alpha;
                    gl.uniform4f(ud["${e}"].location, v.red, v.green, v.blue, v.alpha)
                }`,
        codeUbo: (e) => `
                    v = uv.${e};

                    data[offset] = v.red;
                    data[offset+1] = v.green;
                    data[offset+2] = v.blue;
                    data[offset+3] = v.alpha;
                `,
      },
      {
        test: (e, t) =>
          e.type === `vec3` && e.size === 1 && !e.isArray && t.red !== void 0,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v.red || cv[1] !== v.green || cv[2] !== v.blue || cv[3] !== v.a)
                {
                    cv[0] = v.red;
                    cv[1] = v.green;
                    cv[2] = v.blue;
    
                    gl.uniform3f(ud["${e}"].location, v.red, v.green, v.blue)
                }`,
        codeUbo: (e) => `
                    v = uv.${e};

                    data[offset] = v.red;
                    data[offset+1] = v.green;
                    data[offset+2] = v.blue;
                `,
      },
      {
        test: (e) => e.type === `vec4` && e.size === 1 && !e.isArray,
        code: (e) => `
                cv = ud["${e}"].value;
                v = uv["${e}"];

                if(cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])
                {
                    cv[0] = v[0];
                    cv[1] = v[1];
                    cv[2] = v[2];
                    cv[3] = v[3];

                    gl.uniform4f(ud["${e}"].location, v[0], v[1], v[2], v[3])
                }`,
      },
    ];
  }))();
}
function ti(e, t) {
  let n = [
    `
        var v = null;
        var cv = null;
        var cu = null;
        var t = 0;
        var gl = renderer.gl;
    `,
  ];
  for (let r in e.uniforms) {
    let i = t[r];
    if (!i) {
      e.uniforms[r]?.group &&
        (e.uniforms[r].ubo
          ? n.push(`
                        renderer.shader.syncUniformBufferGroup(uv.${r}, '${r}');
                    `)
          : n.push(`
                        renderer.shader.syncUniformGroup(uv.${r}, syncData);
                    `));
      continue;
    }
    let a = e.uniforms[r],
      o = !1;
    for (let e = 0; e < $r.length; e++)
      if ($r[e].test(i, a)) {
        n.push($r[e].code(r, a)), (o = !0);
        break;
      }
    if (!o) {
      let e = (i.size === 1 && !i.isArray ? ni : ri)[i.type].replace(
        `location`,
        `ud["${r}"].location`
      );
      n.push(`
            cu = ud["${r}"];
            cv = cu.value;
            v = uv["${r}"];
            ${e};`);
    }
  }
  return Function(
    `ud`,
    `uv`,
    `renderer`,
    `syncData`,
    n.join(`
`)
  );
}
var ni, ri;
function ii() {
  return (ii = t(() => {
    ei(),
      (ni = {
        float: `
    if (cv !== v)
    {
        cu.value = v;
        gl.uniform1f(location, v);
    }`,
        vec2: `
    if (cv[0] !== v[0] || cv[1] !== v[1])
    {
        cv[0] = v[0];
        cv[1] = v[1];

        gl.uniform2f(location, v[0], v[1])
    }`,
        vec3: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];

        gl.uniform3f(location, v[0], v[1], v[2])
    }`,
        vec4: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];
        cv[3] = v[3];

        gl.uniform4f(location, v[0], v[1], v[2], v[3]);
    }`,
        int: `
    if (cv !== v)
    {
        cu.value = v;

        gl.uniform1i(location, v);
    }`,
        ivec2: `
    if (cv[0] !== v[0] || cv[1] !== v[1])
    {
        cv[0] = v[0];
        cv[1] = v[1];

        gl.uniform2i(location, v[0], v[1]);
    }`,
        ivec3: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];

        gl.uniform3i(location, v[0], v[1], v[2]);
    }`,
        ivec4: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];
        cv[3] = v[3];

        gl.uniform4i(location, v[0], v[1], v[2], v[3]);
    }`,
        uint: `
    if (cv !== v)
    {
        cu.value = v;

        gl.uniform1ui(location, v);
    }`,
        uvec2: `
    if (cv[0] !== v[0] || cv[1] !== v[1])
    {
        cv[0] = v[0];
        cv[1] = v[1];

        gl.uniform2ui(location, v[0], v[1]);
    }`,
        uvec3: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];

        gl.uniform3ui(location, v[0], v[1], v[2]);
    }`,
        uvec4: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];
        cv[3] = v[3];

        gl.uniform4ui(location, v[0], v[1], v[2], v[3]);
    }`,
        bool: `
    if (cv !== v)
    {
        cu.value = v;
        gl.uniform1i(location, v);
    }`,
        bvec2: `
    if (cv[0] != v[0] || cv[1] != v[1])
    {
        cv[0] = v[0];
        cv[1] = v[1];

        gl.uniform2i(location, v[0], v[1]);
    }`,
        bvec3: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];

        gl.uniform3i(location, v[0], v[1], v[2]);
    }`,
        bvec4: `
    if (cv[0] !== v[0] || cv[1] !== v[1] || cv[2] !== v[2] || cv[3] !== v[3])
    {
        cv[0] = v[0];
        cv[1] = v[1];
        cv[2] = v[2];
        cv[3] = v[3];

        gl.uniform4i(location, v[0], v[1], v[2], v[3]);
    }`,
        mat2: `gl.uniformMatrix2fv(location, false, v)`,
        mat3: `gl.uniformMatrix3fv(location, false, v)`,
        mat4: `gl.uniformMatrix4fv(location, false, v)`,
        sampler2D: `
    if (cv !== v)
    {
        cu.value = v;

        gl.uniform1i(location, v);
    }`,
        samplerCube: `
    if (cv !== v)
    {
        cu.value = v;

        gl.uniform1i(location, v);
    }`,
        sampler2DArray: `
    if (cv !== v)
    {
        cu.value = v;

        gl.uniform1i(location, v);
    }`,
      }),
      (ri = {
        float: `gl.uniform1fv(location, v)`,
        vec2: `gl.uniform2fv(location, v)`,
        vec3: `gl.uniform3fv(location, v)`,
        vec4: `gl.uniform4fv(location, v)`,
        mat4: `gl.uniformMatrix4fv(location, false, v)`,
        mat3: `gl.uniformMatrix3fv(location, false, v)`,
        mat2: `gl.uniformMatrix2fv(location, false, v)`,
        int: `gl.uniform1iv(location, v)`,
        ivec2: `gl.uniform2iv(location, v)`,
        ivec3: `gl.uniform3iv(location, v)`,
        ivec4: `gl.uniform4iv(location, v)`,
        uint: `gl.uniform1uiv(location, v)`,
        uvec2: `gl.uniform2uiv(location, v)`,
        uvec3: `gl.uniform3uiv(location, v)`,
        uvec4: `gl.uniform4uiv(location, v)`,
        bool: `gl.uniform1iv(location, v)`,
        bvec2: `gl.uniform2iv(location, v)`,
        bvec3: `gl.uniform3iv(location, v)`,
        bvec4: `gl.uniform4iv(location, v)`,
        sampler2D: `gl.uniform1iv(location, v)`,
        samplerCube: `gl.uniform1iv(location, v)`,
        sampler2DArray: `gl.uniform1iv(location, v)`,
      });
  }))();
}
function ai() {
  if (si === oi || si?.isContextLost()) {
    let e = D.ADAPTER.createCanvas(),
      t;
    D.PREFER_ENV >= a.WEBGL2 && (t = e.getContext(`webgl2`, {})),
      t ||
        ((t =
          e.getContext(`webgl`, {}) || e.getContext(`experimental-webgl`, {})),
        t ? t.getExtension(`WEBGL_draw_buffers`) : (t = null)),
      (si = t);
  }
  return si;
}
var oi, si;
function ci() {
  return (ci = t(() => {
    w(), N(), (oi = {}), (si = oi);
  }))();
}
function li() {
  if (!ui) {
    ui = b.MEDIUM;
    let e = ai();
    if (e && e.getShaderPrecisionFormat) {
      let t = e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT);
      t && (ui = t.precision ? b.HIGH : b.MEDIUM);
    }
  }
  return ui;
}
var ui;
function di() {
  return (di = t(() => {
    w(), ci();
  }))();
}
function fi(e, t) {
  let n = e
      .getShaderSource(t)
      .split(
        `
`
      )
      .map((e, t) => `${t}: ${e}`),
    r = e.getShaderInfoLog(t),
    i = r.split(`
`),
    a = {},
    o = i
      .map((e) => parseFloat(e.replace(/^ERROR\: 0\:([\d]+)\:.*$/, `$1`)))
      .filter((e) => (e && !a[e] ? ((a[e] = !0), !0) : !1)),
    s = [``];
  o.forEach((e) => {
    (n[e - 1] = `%c${n[e - 1]}%c`),
      s.push(
        `background: #FF0000; color:#FFFFFF; font-size: 10px`,
        `font-size: 10px`
      );
  }),
    (s[0] = n.join(`
`)),
    console.error(r),
    console.groupCollapsed(`click to view full shader code`),
    console.warn(...s),
    console.groupEnd();
}
function pi(e, t, n, r) {
  e.getProgramParameter(t, e.LINK_STATUS) ||
    (e.getShaderParameter(n, e.COMPILE_STATUS) || fi(e, n),
    e.getShaderParameter(r, e.COMPILE_STATUS) || fi(e, r),
    console.error(`PixiJS Error: Could not initialize shader.`),
    e.getProgramInfoLog(t) !== `` &&
      console.warn(
        `PixiJS Warning: gl.getProgramInfoLog()`,
        e.getProgramInfoLog(t)
      ));
}
function mi(e) {
  return hi[e];
}
var hi;
function gi() {
  return (gi = t(() => {
    hi = {
      float: 1,
      vec2: 2,
      vec3: 3,
      vec4: 4,
      int: 1,
      ivec2: 2,
      ivec3: 3,
      ivec4: 4,
      uint: 1,
      uvec2: 2,
      uvec3: 3,
      uvec4: 4,
      bool: 1,
      bvec2: 2,
      bvec3: 3,
      bvec4: 4,
      mat2: 4,
      mat3: 9,
      mat4: 16,
      sampler2D: 1,
    };
  }))();
}
function _i(e, t) {
  if (!vi) {
    let t = Object.keys(yi);
    vi = {};
    for (let n = 0; n < t.length; ++n) {
      let r = t[n];
      vi[e[r]] = yi[r];
    }
  }
  return vi[t];
}
var vi, yi;
function bi() {
  return (bi = t(() => {
    (vi = null),
      (yi = {
        FLOAT: `float`,
        FLOAT_VEC2: `vec2`,
        FLOAT_VEC3: `vec3`,
        FLOAT_VEC4: `vec4`,
        INT: `int`,
        INT_VEC2: `ivec2`,
        INT_VEC3: `ivec3`,
        INT_VEC4: `ivec4`,
        UNSIGNED_INT: `uint`,
        UNSIGNED_INT_VEC2: `uvec2`,
        UNSIGNED_INT_VEC3: `uvec3`,
        UNSIGNED_INT_VEC4: `uvec4`,
        BOOL: `bool`,
        BOOL_VEC2: `bvec2`,
        BOOL_VEC3: `bvec3`,
        BOOL_VEC4: `bvec4`,
        FLOAT_MAT2: `mat2`,
        FLOAT_MAT3: `mat3`,
        FLOAT_MAT4: `mat4`,
        SAMPLER_2D: `sampler2D`,
        INT_SAMPLER_2D: `sampler2D`,
        UNSIGNED_INT_SAMPLER_2D: `sampler2D`,
        SAMPLER_CUBE: `samplerCube`,
        INT_SAMPLER_CUBE: `samplerCube`,
        UNSIGNED_INT_SAMPLER_CUBE: `samplerCube`,
        SAMPLER_2D_ARRAY: `sampler2DArray`,
        INT_SAMPLER_2D_ARRAY: `sampler2DArray`,
        UNSIGNED_INT_SAMPLER_2D_ARRAY: `sampler2DArray`,
      });
  }))();
}
function xi(e, t, n) {
  if (e.substring(0, 9) !== `precision`) {
    let r = t;
    return (
      t === b.HIGH && n !== b.HIGH && (r = b.MEDIUM),
      `precision ${r} float;
${e}`
    );
  }
  return n !== b.HIGH && e.substring(0, 15) === `precision highp`
    ? e.replace(`precision highp`, `precision mediump`)
    : e;
}
function Si() {
  return (Si = t(() => {
    w();
  }))();
}
function Ci() {
  if (typeof wi == `boolean`) return wi;
  try {
    wi =
      Function(
        `param1`,
        `param2`,
        `param3`,
        `return param1[param2] === param3;`
      )({ a: `b` }, `a`, `b`) === !0;
  } catch {
    wi = !1;
  }
  return wi;
}
var wi;
function Ti() {
  return (Ti = t(() => {}))();
}
function Ei() {
  return (Ei = t(() => {
    Rn(), di(), ci();
  }))();
}
var Di, Oi, ki, Ai;
function ji() {
  return (ji = t(() => {
    w(),
      R(),
      qr(),
      Yr(),
      Ei(),
      Si(),
      di(),
      (Di = 0),
      (Oi = {}),
      (ki = class {
        constructor(e, t, n = `pixi-shader`, r = {}) {
          (this.extra = {}),
            (this.id = Di++),
            (this.vertexSrc = e || ki.defaultVertexSrc),
            (this.fragmentSrc = t || ki.defaultFragmentSrc),
            (this.vertexSrc = this.vertexSrc.trim()),
            (this.fragmentSrc = this.fragmentSrc.trim()),
            (this.extra = r),
            this.vertexSrc.substring(0, 8) !== `#version` &&
              ((n = n.replace(/\s+/g, `-`)),
              Oi[n] ? (Oi[n]++, (n += `-${Oi[n]}`)) : (Oi[n] = 1),
              (this.vertexSrc = `#define SHADER_NAME ${n}
${this.vertexSrc}`),
              (this.fragmentSrc = `#define SHADER_NAME ${n}
${this.fragmentSrc}`),
              (this.vertexSrc = xi(
                this.vertexSrc,
                ki.defaultVertexPrecision,
                b.HIGH
              )),
              (this.fragmentSrc = xi(
                this.fragmentSrc,
                ki.defaultFragmentPrecision,
                li()
              ))),
            (this.glPrograms = {}),
            (this.syncUniforms = null);
        }
        static get defaultVertexSrc() {
          return Jr;
        }
        static get defaultFragmentSrc() {
          return Kr;
        }
        static from(e, t, n) {
          let r = e + t,
            i = un[r];
          return i || (un[r] = i = new ki(e, t, n)), i;
        }
      }),
      (Ai = ki),
      (Ai.defaultVertexPrecision = b.HIGH),
      (Ai.defaultFragmentPrecision = he.apple.device ? b.HIGH : b.MEDIUM);
  }))();
}
var Mi, Ni;
function Pi() {
  return (Pi = t(() => {
    w(),
      rr(),
      (Mi = 0),
      (Ni = class e {
        constructor(e, t, n) {
          (this.group = !0),
            (this.syncUniforms = {}),
            (this.dirtyId = 0),
            (this.id = Mi++),
            (this.static = !!t),
            (this.ubo = !!n),
            e instanceof U
              ? ((this.buffer = e),
                (this.buffer.type = C.UNIFORM_BUFFER),
                (this.autoManage = !1),
                (this.ubo = !0))
              : ((this.uniforms = e),
                this.ubo &&
                  ((this.buffer = new U(new Float32Array(1))),
                  (this.buffer.type = C.UNIFORM_BUFFER),
                  (this.autoManage = !0)));
        }
        update() {
          this.dirtyId++,
            !this.autoManage && this.buffer && this.buffer.update();
        }
        add(t, n, r) {
          if (!this.ubo) this.uniforms[t] = new e(n, r);
          else
            throw Error(
              `[UniformGroup] uniform groups in ubo mode cannot be modified, or have uniform groups nested in them`
            );
        }
        static from(t, n, r) {
          return new e(t, n, r);
        }
        static uboFrom(t, n) {
          return new e(t, n ?? !0, !0);
        }
      });
  }))();
}
var Fi;
function Ii() {
  return (Ii = t(() => {
    Kn(),
      ji(),
      Pi(),
      (Fi = class e {
        constructor(e, t) {
          (this.uniformBindCount = 0),
            (this.program = e),
            (this.uniformGroup = t
              ? t instanceof Ni
                ? t
                : new Ni(t)
              : new Ni({})),
            (this.disposeRunner = new Wn(`disposeShader`));
        }
        checkUniformExists(e, t) {
          if (t.uniforms[e]) return !0;
          for (let n in t.uniforms) {
            let r = t.uniforms[n];
            if (r.group && this.checkUniformExists(e, r)) return !0;
          }
          return !1;
        }
        destroy() {
          (this.uniformGroup = null),
            this.disposeRunner.emit(this),
            this.disposeRunner.destroy();
        }
        get uniforms() {
          return this.uniformGroup.uniforms;
        }
        static from(t, n, r) {
          let i = Ai.from(t, n);
          return new e(i, r);
        }
      });
  }))();
}
var Li;
function Ri() {
  return (Ri = t(() => {
    Y(),
      ji(),
      Ii(),
      Pi(),
      (Li = class {
        constructor(e, t) {
          if (
            ((this.vertexSrc = e),
            (this.fragTemplate = t),
            (this.programCache = {}),
            (this.defaultGroupCache = {}),
            !t.includes(`%count%`))
          )
            throw Error(`Fragment template must contain "%count%".`);
          if (!t.includes(`%forloop%`))
            throw Error(`Fragment template must contain "%forloop%".`);
        }
        generateShader(e) {
          if (!this.programCache[e]) {
            let t = new Int32Array(e);
            for (let n = 0; n < e; n++) t[n] = n;
            this.defaultGroupCache[e] = Ni.from({ uSamplers: t }, !0);
            let n = this.fragTemplate;
            (n = n.replace(/%count%/gi, `${e}`)),
              (n = n.replace(/%forloop%/gi, this.generateSampleSrc(e))),
              (this.programCache[e] = new Ai(this.vertexSrc, n));
          }
          let t = {
            tint: new Float32Array([1, 1, 1, 1]),
            translationMatrix: new q(),
            default: this.defaultGroupCache[e],
          };
          return new Fi(this.programCache[e], t);
        }
        generateSampleSrc(e) {
          let t = ``;
          (t += `
`),
            (t += `
`);
          for (let n = 0; n < e; n++)
            n > 0 &&
              (t += `
else `),
              n < e - 1 && (t += `if(vTextureId < ${n}.5)`),
              (t += `
{`),
              (t += `
	color = texture2D(uSamplers[${n}], vTextureCoord);`),
              (t += `
}`);
          return (
            (t += `
`),
            (t += `
`),
            t
          );
        }
      });
  }))();
}
var zi;
function Bi() {
  return (Bi = t(() => {
    zi = class {
      constructor() {
        (this.elements = []), (this.ids = []), (this.count = 0);
      }
      clear() {
        for (let e = 0; e < this.count; e++) this.elements[e] = null;
        this.count = 0;
      }
    };
  }))();
}
function Vi() {
  return !he.apple.device;
}
function Hi() {
  return (Hi = t(() => {
    N();
  }))();
}
function Ui(e) {
  let t = !0,
    n = D.ADAPTER.getNavigator();
  if (he.tablet || he.phone) {
    if (he.apple.device) {
      let e = n.userAgent.match(/OS (\d+)_(\d+)?/);
      e && parseInt(e[1], 10) < 11 && (t = !1);
    }
    if (he.android.device) {
      let e = n.userAgent.match(/Android\s([0-9.]*)/);
      e && parseInt(e[1], 10) < 7 && (t = !1);
    }
  }
  return t ? e : 4;
}
function Wi() {
  return (Wi = t(() => {
    N();
  }))();
}
var Gi;
function Ki() {
  return (Ki = t(() => {
    Gi = class {
      constructor(e) {
        this.renderer = e;
      }
      flush() {}
      destroy() {
        this.renderer = null;
      }
      start() {}
      stop() {
        this.flush();
      }
      render(e) {}
    };
  }))();
}
var qi;
function Ji() {
  return (Ji = t(() => {
    qi = `varying vec2 vTextureCoord;
varying vec4 vColor;
varying float vTextureId;
uniform sampler2D uSamplers[%count%];

void main(void){
    vec4 color;
    %forloop%
    gl_FragColor = color * vColor;
}
`;
  }))();
}
var Yi;
function Xi() {
  return (Xi = t(() => {
    Yi = `precision highp float;
attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;
attribute vec4 aColor;
attribute float aTextureId;

uniform mat3 projectionMatrix;
uniform mat3 translationMatrix;
uniform vec4 tint;

varying vec2 vTextureCoord;
varying vec4 vColor;
varying float vTextureId;

void main(void){
    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = aTextureCoord;
    vTextureId = aTextureId;
    vColor = aColor * tint;
}
`;
  }))();
}
var Zi, Qi;
function $i() {
  return ($i = t(() => {
    Ot(),
      w(),
      V(),
      N(),
      R(),
      Pn(),
      Rn(),
      Bn(),
      $n(),
      tr(),
      hr(),
      Ri(),
      Bi(),
      Hi(),
      Wi(),
      Ki(),
      Ji(),
      Xi(),
      (Zi = class extends Gi {
        constructor(e) {
          super(e),
            this.setShaderGenerator(),
            (this.geometryClass = mr),
            (this.vertexSize = 6),
            (this.state = zn.for2d()),
            (this.size = Zi.defaultBatchSize * 4),
            (this._vertexCount = 0),
            (this._indexCount = 0),
            (this._bufferedElements = []),
            (this._bufferedTextures = []),
            (this._bufferSize = 0),
            (this._shader = null),
            (this._packedGeometries = []),
            (this._packedGeometryPoolSize = 2),
            (this._flushId = 0),
            (this._aBuffers = {}),
            (this._iBuffers = {}),
            (this.maxTextures = 1),
            this.renderer.on(`prerender`, this.onPrerender, this),
            e.runners.contextChange.add(this),
            (this._dcIndex = 0),
            (this._aIndex = 0),
            (this._iIndex = 0),
            (this._attributeBuffer = null),
            (this._indexBuffer = null),
            (this._tempBoundTextures = []);
        }
        static get defaultMaxTextures() {
          return (
            (this._defaultMaxTextures = this._defaultMaxTextures ?? Ui(32)),
            this._defaultMaxTextures
          );
        }
        static set defaultMaxTextures(e) {
          this._defaultMaxTextures = e;
        }
        static get canUploadSameBuffer() {
          return (
            (this._canUploadSameBuffer = this._canUploadSameBuffer ?? Vi()),
            this._canUploadSameBuffer
          );
        }
        static set canUploadSameBuffer(e) {
          this._canUploadSameBuffer = e;
        }
        get MAX_TEXTURES() {
          return (
            P(
              `7.1.0`,
              `BatchRenderer#MAX_TEXTURES renamed to BatchRenderer#maxTextures`
            ),
            this.maxTextures
          );
        }
        static get defaultVertexSrc() {
          return Yi;
        }
        static get defaultFragmentTemplate() {
          return qi;
        }
        setShaderGenerator({
          vertex: e = Zi.defaultVertexSrc,
          fragment: t = Zi.defaultFragmentTemplate,
        } = {}) {
          this.shaderGenerator = new Li(e, t);
        }
        contextChange() {
          let e = this.renderer.gl;
          D.PREFER_ENV === a.WEBGL_LEGACY
            ? (this.maxTextures = 1)
            : ((this.maxTextures = Math.min(
                e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),
                Zi.defaultMaxTextures
              )),
              (this.maxTextures = In(this.maxTextures, e))),
            (this._shader = this.shaderGenerator.generateShader(
              this.maxTextures
            ));
          for (let e = 0; e < this._packedGeometryPoolSize; e++)
            this._packedGeometries[e] = new this.geometryClass();
          this.initFlushBuffers();
        }
        initFlushBuffers() {
          let { _drawCallPool: e, _textureArrayPool: t } = Zi,
            n = this.size / 4,
            r = Math.floor(n / this.maxTextures) + 1;
          for (; e.length < n; ) e.push(new er());
          for (; t.length < r; ) t.push(new zi());
          for (let e = 0; e < this.maxTextures; e++)
            this._tempBoundTextures[e] = null;
        }
        onPrerender() {
          this._flushId = 0;
        }
        render(e) {
          e._texture.valid &&
            (this._vertexCount + e.vertexData.length / 2 > this.size &&
              this.flush(),
            (this._vertexCount += e.vertexData.length / 2),
            (this._indexCount += e.indices.length),
            (this._bufferedTextures[this._bufferSize] = e._texture.baseTexture),
            (this._bufferedElements[this._bufferSize++] = e));
        }
        buildTexturesAndDrawCalls() {
          let { _bufferedTextures: e, maxTextures: t } = this,
            n = Zi._textureArrayPool,
            r = this.renderer.batch,
            i = this._tempBoundTextures,
            a = this.renderer.textureGC.count,
            o = ++H._globalBatch,
            s = 0,
            c = n[0],
            l = 0;
          r.copyBoundTextures(i, t);
          for (let u = 0; u < this._bufferSize; ++u) {
            let d = e[u];
            (e[u] = null),
              d._batchEnabled !== o &&
                (c.count >= t &&
                  (r.boundArray(c, i, o, t),
                  this.buildDrawCalls(c, l, u),
                  (l = u),
                  (c = n[++s]),
                  ++o),
                (d._batchEnabled = o),
                (d.touched = a),
                (c.elements[c.count++] = d));
          }
          c.count > 0 &&
            (r.boundArray(c, i, o, t),
            this.buildDrawCalls(c, l, this._bufferSize),
            ++s,
            ++o);
          for (let e = 0; e < i.length; e++) i[e] = null;
          H._globalBatch = o;
        }
        buildDrawCalls(e, t, n) {
          let {
              _bufferedElements: r,
              _attributeBuffer: i,
              _indexBuffer: a,
              vertexSize: o,
            } = this,
            s = Zi._drawCallPool,
            c = this._dcIndex,
            l = this._aIndex,
            u = this._iIndex,
            d = s[c];
          (d.start = this._iIndex), (d.texArray = e);
          for (let f = t; f < n; ++f) {
            let n = r[f],
              p = n._texture.baseTexture,
              m = zt[+!!p.alphaMode][n.blendMode];
            (r[f] = null),
              t < f &&
                d.blend !== m &&
                ((d.size = u - d.start),
                (t = f),
                (d = s[++c]),
                (d.texArray = e),
                (d.start = u)),
              this.packInterleavedGeometry(n, i, a, l, u),
              (l += (n.vertexData.length / 2) * o),
              (u += n.indices.length),
              (d.blend = m);
          }
          t < n && ((d.size = u - d.start), ++c),
            (this._dcIndex = c),
            (this._aIndex = l),
            (this._iIndex = u);
        }
        bindAndClearTexArray(e) {
          let t = this.renderer.texture;
          for (let n = 0; n < e.count; n++)
            t.bind(e.elements[n], e.ids[n]), (e.elements[n] = null);
          e.count = 0;
        }
        updateGeometry() {
          let {
            _packedGeometries: e,
            _attributeBuffer: t,
            _indexBuffer: n,
          } = this;
          Zi.canUploadSameBuffer
            ? (e[this._flushId]._buffer.update(t.rawBinaryData),
              e[this._flushId]._indexBuffer.update(n),
              this.renderer.geometry.updateBuffers())
            : (this._packedGeometryPoolSize <= this._flushId &&
                (this._packedGeometryPoolSize++,
                (e[this._flushId] = new this.geometryClass())),
              e[this._flushId]._buffer.update(t.rawBinaryData),
              e[this._flushId]._indexBuffer.update(n),
              this.renderer.geometry.bind(e[this._flushId]),
              this.renderer.geometry.updateBuffers(),
              this._flushId++);
        }
        drawBatches() {
          let e = this._dcIndex,
            { gl: t, state: n } = this.renderer,
            r = Zi._drawCallPool,
            i = null;
          for (let a = 0; a < e; a++) {
            let { texArray: e, type: o, size: s, start: c, blend: l } = r[a];
            i !== e && ((i = e), this.bindAndClearTexArray(e)),
              (this.state.blendMode = l),
              n.set(this.state),
              t.drawElements(o, s, t.UNSIGNED_SHORT, c * 2);
          }
        }
        flush() {
          this._vertexCount !== 0 &&
            ((this._attributeBuffer = this.getAttributeBuffer(
              this._vertexCount
            )),
            (this._indexBuffer = this.getIndexBuffer(this._indexCount)),
            (this._aIndex = 0),
            (this._iIndex = 0),
            (this._dcIndex = 0),
            this.buildTexturesAndDrawCalls(),
            this.updateGeometry(),
            this.drawBatches(),
            (this._bufferSize = 0),
            (this._vertexCount = 0),
            (this._indexCount = 0));
        }
        start() {
          this.renderer.state.set(this.state),
            this.renderer.texture.ensureSamplerType(this.maxTextures),
            this.renderer.shader.bind(this._shader),
            Zi.canUploadSameBuffer &&
              this.renderer.geometry.bind(
                this._packedGeometries[this._flushId]
              );
        }
        stop() {
          this.flush();
        }
        destroy() {
          for (let e = 0; e < this._packedGeometryPoolSize; e++)
            this._packedGeometries[e] && this._packedGeometries[e].destroy();
          this.renderer.off(`prerender`, this.onPrerender, this),
            (this._aBuffers = null),
            (this._iBuffers = null),
            (this._packedGeometries = null),
            (this._attributeBuffer = null),
            (this._indexBuffer = null),
            (this._shader &&= (this._shader.destroy(), null)),
            super.destroy();
        }
        getAttributeBuffer(e) {
          let t = Jt(Math.ceil(e / 8)),
            n = Xt(t),
            r = t * 8;
          this._aBuffers.length <= n && (this._iBuffers.length = n + 1);
          let i = this._aBuffers[r];
          return (
            i || (this._aBuffers[r] = i = new Nn(r * this.vertexSize * 4)), i
          );
        }
        getIndexBuffer(e) {
          let t = Jt(Math.ceil(e / 12)),
            n = Xt(t),
            r = t * 12;
          this._iBuffers.length <= n && (this._iBuffers.length = n + 1);
          let i = this._iBuffers[n];
          return i || (this._iBuffers[n] = i = new Uint16Array(r)), i;
        }
        packInterleavedGeometry(e, t, n, r, i) {
          let { uint32View: a, float32View: o } = t,
            s = r / this.vertexSize,
            c = e.uvs,
            l = e.indices,
            u = e.vertexData,
            d = e._texture.baseTexture._batchLocation,
            f = Math.min(e.worldAlpha, 1),
            p = I.shared.setValue(e._tintRGB).toPremultiplied(f);
          for (let e = 0; e < u.length; e += 2)
            (o[r++] = u[e]),
              (o[r++] = u[e + 1]),
              (o[r++] = c[e]),
              (o[r++] = c[e + 1]),
              (a[r++] = p),
              (o[r++] = d);
          for (let e = 0; e < l.length; e++) n[i++] = s + l[e];
        }
      }),
      (Qi = Zi),
      (Qi.defaultBatchSize = 4096),
      (Qi.extension = { name: `batch`, type: z.RendererPlugin }),
      (Qi._drawCallPool = []),
      (Qi._textureArrayPool = []),
      B.add(Qi);
  }))();
}
var ea;
function ta() {
  return (ta = t(() => {
    ea = `varying vec2 vTextureCoord;

uniform sampler2D uSampler;

void main(void){
   gl_FragColor = texture2D(uSampler, vTextureCoord);
}
`;
  }))();
}
var na;
function ra() {
  return (ra = t(() => {
    na = `attribute vec2 aVertexPosition;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

uniform vec4 inputSize;
uniform vec4 outputFrame;

vec4 filterVertexPosition( void )
{
    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;

    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
}

vec2 filterTextureCoord( void )
{
    return aVertexPosition * (outputFrame.zw * inputSize.zw);
}

void main(void)
{
    gl_Position = filterVertexPosition();
    vTextureCoord = filterTextureCoord();
}
`;
  }))();
}
var ia, aa;
function oa() {
  return (oa = t(() => {
    w(),
      ji(),
      Ii(),
      Bn(),
      ta(),
      ra(),
      (ia = class extends Fi {
        constructor(e, t, n) {
          let r = Ai.from(e || ia.defaultVertexSrc, t || ia.defaultFragmentSrc);
          super(r, n),
            (this.padding = 0),
            (this.resolution = ia.defaultResolution),
            (this.multisample = ia.defaultMultisample),
            (this.enabled = !0),
            (this.autoFit = !0),
            (this.state = new zn());
        }
        apply(e, t, n, r, i) {
          e.applyFilter(this, t, n, r);
        }
        get blendMode() {
          return this.state.blendMode;
        }
        set blendMode(e) {
          this.state.blendMode = e;
        }
        get resolution() {
          return this._resolution;
        }
        set resolution(e) {
          this._resolution = e;
        }
        static get defaultVertexSrc() {
          return na;
        }
        static get defaultFragmentSrc() {
          return ea;
        }
      }),
      (aa = ia),
      (aa.defaultResolution = 1),
      (aa.defaultMultisample = S.NONE);
  }))();
}
var sa;
function ca() {
  return (ca = t(() => {
    Ot(),
      V(),
      (sa = class {
        constructor() {
          (this.clearBeforeRender = !0),
            (this._backgroundColor = new I(0)),
            (this.alpha = 1);
        }
        init(e) {
          this.clearBeforeRender = e.clearBeforeRender;
          let { backgroundColor: t, background: n, backgroundAlpha: r } = e,
            i = n ?? t;
          i !== void 0 && (this.color = i), (this.alpha = r);
        }
        get color() {
          return this._backgroundColor.value;
        }
        set color(e) {
          this._backgroundColor.setValue(e);
        }
        get alpha() {
          return this._backgroundColor.alpha;
        }
        set alpha(e) {
          this._backgroundColor.setAlpha(e);
        }
        get backgroundColor() {
          return this._backgroundColor;
        }
        destroy() {}
      }),
      (sa.defaultOptions = {
        backgroundAlpha: 1,
        backgroundColor: 0,
        clearBeforeRender: !0,
      }),
      (sa.extension = {
        type: [z.RendererSystem, z.CanvasRendererSystem],
        name: `background`,
      }),
      B.add(sa);
  }))();
}
var la;
function ua() {
  return (ua = t(() => {
    V(),
      Ki(),
      (la = class {
        constructor(e) {
          (this.renderer = e),
            (this.emptyRenderer = new Gi(e)),
            (this.currentRenderer = this.emptyRenderer);
        }
        setObjectRenderer(e) {
          this.currentRenderer !== e &&
            (this.currentRenderer.stop(),
            (this.currentRenderer = e),
            this.currentRenderer.start());
        }
        flush() {
          this.setObjectRenderer(this.emptyRenderer);
        }
        reset() {
          this.setObjectRenderer(this.emptyRenderer);
        }
        copyBoundTextures(e, t) {
          let { boundTextures: n } = this.renderer.texture;
          for (let r = t - 1; r >= 0; --r)
            (e[r] = n[r] || null), e[r] && (e[r]._batchLocation = r);
        }
        boundArray(e, t, n, r) {
          let { elements: i, ids: a, count: o } = e,
            s = 0;
          for (let e = 0; e < o; e++) {
            let o = i[e],
              c = o._batchLocation;
            if (c >= 0 && c < r && t[c] === o) {
              a[e] = c;
              continue;
            }
            for (; s < r; ) {
              let r = t[s];
              if (r && r._batchEnabled === n && r._batchLocation === s) {
                s++;
                continue;
              }
              (a[e] = s), (o._batchLocation = s), (t[s] = o);
              break;
            }
          }
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (la.extension = { type: z.RendererSystem, name: `batch` }),
      B.add(la);
  }))();
}
var da, fa;
function pa() {
  return (pa = t(() => {
    w(),
      V(),
      N(),
      (da = 0),
      (fa = class {
        constructor(e) {
          (this.renderer = e),
            (this.webGLVersion = 1),
            (this.extensions = {}),
            (this.supports = { uint32Indices: !1 }),
            (this.handleContextLost = this.handleContextLost.bind(this)),
            (this.handleContextRestored =
              this.handleContextRestored.bind(this));
        }
        get isLost() {
          return !this.gl || this.gl.isContextLost();
        }
        contextChange(e) {
          (this.gl = e),
            (this.renderer.gl = e),
            (this.renderer.CONTEXT_UID = da++);
        }
        init(e) {
          if (e.context) this.initFromContext(e.context);
          else {
            let t = this.renderer.background.alpha < 1,
              n = e.premultipliedAlpha;
            (this.preserveDrawingBuffer = e.preserveDrawingBuffer),
              (this.useContextAlpha = e.useContextAlpha),
              (this.powerPreference = e.powerPreference),
              this.initFromOptions({
                alpha: t,
                premultipliedAlpha: n,
                antialias: e.antialias,
                stencil: !0,
                preserveDrawingBuffer: e.preserveDrawingBuffer,
                powerPreference: e.powerPreference,
              });
          }
        }
        initFromContext(e) {
          (this.gl = e),
            this.validateContext(e),
            (this.renderer.gl = e),
            (this.renderer.CONTEXT_UID = da++),
            this.renderer.runners.contextChange.emit(e);
          let t = this.renderer.view;
          t.addEventListener !== void 0 &&
            (t.addEventListener(`webglcontextlost`, this.handleContextLost, !1),
            t.addEventListener(
              `webglcontextrestored`,
              this.handleContextRestored,
              !1
            ));
        }
        initFromOptions(e) {
          let t = this.createContext(this.renderer.view, e);
          this.initFromContext(t);
        }
        createContext(e, t) {
          let n;
          if ((D.PREFER_ENV >= a.WEBGL2 && (n = e.getContext(`webgl2`, t)), n))
            this.webGLVersion = 2;
          else if (
            ((this.webGLVersion = 1),
            (n =
              e.getContext(`webgl`, t) ||
              e.getContext(`experimental-webgl`, t)),
            !n)
          )
            throw Error(
              `This browser does not support WebGL. Try using the canvas renderer`
            );
          return (this.gl = n), this.getExtensions(), this.gl;
        }
        getExtensions() {
          let { gl: e } = this,
            t = {
              loseContext: e.getExtension(`WEBGL_lose_context`),
              anisotropicFiltering: e.getExtension(
                `EXT_texture_filter_anisotropic`
              ),
              floatTextureLinear: e.getExtension(`OES_texture_float_linear`),
              s3tc: e.getExtension(`WEBGL_compressed_texture_s3tc`),
              s3tc_sRGB: e.getExtension(`WEBGL_compressed_texture_s3tc_srgb`),
              etc: e.getExtension(`WEBGL_compressed_texture_etc`),
              etc1: e.getExtension(`WEBGL_compressed_texture_etc1`),
              pvrtc:
                e.getExtension(`WEBGL_compressed_texture_pvrtc`) ||
                e.getExtension(`WEBKIT_WEBGL_compressed_texture_pvrtc`),
              atc: e.getExtension(`WEBGL_compressed_texture_atc`),
              astc: e.getExtension(`WEBGL_compressed_texture_astc`),
            };
          this.webGLVersion === 1
            ? Object.assign(this.extensions, t, {
                drawBuffers: e.getExtension(`WEBGL_draw_buffers`),
                depthTexture: e.getExtension(`WEBGL_depth_texture`),
                vertexArrayObject:
                  e.getExtension(`OES_vertex_array_object`) ||
                  e.getExtension(`MOZ_OES_vertex_array_object`) ||
                  e.getExtension(`WEBKIT_OES_vertex_array_object`),
                uint32ElementIndex: e.getExtension(`OES_element_index_uint`),
                floatTexture: e.getExtension(`OES_texture_float`),
                floatTextureLinear: e.getExtension(`OES_texture_float_linear`),
                textureHalfFloat: e.getExtension(`OES_texture_half_float`),
                textureHalfFloatLinear: e.getExtension(
                  `OES_texture_half_float_linear`
                ),
              })
            : this.webGLVersion === 2 &&
              Object.assign(this.extensions, t, {
                colorBufferFloat: e.getExtension(`EXT_color_buffer_float`),
              });
        }
        handleContextLost(e) {
          e.preventDefault(),
            setTimeout(() => {
              this.gl.isContextLost() &&
                this.extensions.loseContext &&
                this.extensions.loseContext.restoreContext();
            }, 0);
        }
        handleContextRestored() {
          this.renderer.runners.contextChange.emit(this.gl);
        }
        destroy() {
          let e = this.renderer.view;
          (this.renderer = null),
            e.removeEventListener !== void 0 &&
              (e.removeEventListener(
                `webglcontextlost`,
                this.handleContextLost
              ),
              e.removeEventListener(
                `webglcontextrestored`,
                this.handleContextRestored
              )),
            this.gl.useProgram(null),
            this.extensions.loseContext &&
              this.extensions.loseContext.loseContext();
        }
        postrender() {
          this.renderer.objectRenderer.renderingToScreen && this.gl.flush();
        }
        validateContext(e) {
          let t = e.getContextAttributes(),
            n =
              `WebGL2RenderingContext` in globalThis &&
              e instanceof globalThis.WebGL2RenderingContext;
          n && (this.webGLVersion = 2),
            t &&
              !t.stencil &&
              console.warn(
                `Provided WebGL context does not have a stencil buffer, masks may not render correctly`
              );
          let r = n || !!e.getExtension(`OES_element_index_uint`);
          (this.supports.uint32Indices = r),
            r ||
              console.warn(
                `Provided WebGL context does not support 32 index buffer, complex graphics may not render correctly`
              );
        }
      }),
      (fa.defaultOptions = {
        context: null,
        antialias: !1,
        premultipliedAlpha: !0,
        preserveDrawingBuffer: !1,
        powerPreference: `default`,
      }),
      (fa.extension = { type: z.RendererSystem, name: `context` }),
      B.add(fa);
  }))();
}
var ma;
function ha() {
  return (ha = t(() => {
    w(),
      Xn(),
      (ma = class extends Yn {
        upload(e, t, n) {
          let r = e.gl;
          r.pixelStorei(
            r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
            t.alphaMode === _.UNPACK
          );
          let i = t.realWidth,
            a = t.realHeight;
          return (
            n.width === i && n.height === a
              ? r.texSubImage2D(
                  t.target,
                  0,
                  0,
                  0,
                  i,
                  a,
                  t.format,
                  n.type,
                  this.data
                )
              : ((n.width = i),
                (n.height = a),
                r.texImage2D(
                  t.target,
                  0,
                  n.internalFormat,
                  i,
                  a,
                  0,
                  t.format,
                  n.type,
                  this.data
                )),
            !0
          );
        }
      });
  }))();
}
var ga;
function _a() {
  return (_a = t(() => {
    w(),
      Kn(),
      $n(),
      ha(),
      (ga = class {
        constructor(e, t) {
          (this.width = Math.round(e || 100)),
            (this.height = Math.round(t || 100)),
            (this.stencil = !1),
            (this.depth = !1),
            (this.dirtyId = 0),
            (this.dirtyFormat = 0),
            (this.dirtySize = 0),
            (this.depthTexture = null),
            (this.colorTextures = []),
            (this.glFramebuffers = {}),
            (this.disposeRunner = new Wn(`disposeFramebuffer`)),
            (this.multisample = S.NONE);
        }
        get colorTexture() {
          return this.colorTextures[0];
        }
        addColorTexture(e = 0, t) {
          return (
            (this.colorTextures[e] =
              t ||
              new H(null, {
                scaleMode: m.NEAREST,
                resolution: 1,
                mipmap: g.OFF,
                width: this.width,
                height: this.height,
              })),
            this.dirtyId++,
            this.dirtyFormat++,
            this
          );
        }
        addDepthTexture(e) {
          return (
            (this.depthTexture =
              e ||
              new H(new ma(null, { width: this.width, height: this.height }), {
                scaleMode: m.NEAREST,
                resolution: 1,
                width: this.width,
                height: this.height,
                mipmap: g.OFF,
                format: u.DEPTH_COMPONENT,
                type: f.UNSIGNED_SHORT,
              })),
            this.dirtyId++,
            this.dirtyFormat++,
            this
          );
        }
        enableDepth() {
          return (this.depth = !0), this.dirtyId++, this.dirtyFormat++, this;
        }
        enableStencil() {
          return (this.stencil = !0), this.dirtyId++, this.dirtyFormat++, this;
        }
        resize(e, t) {
          if (
            ((e = Math.round(e)),
            (t = Math.round(t)),
            e !== this.width || t !== this.height)
          ) {
            (this.width = e),
              (this.height = t),
              this.dirtyId++,
              this.dirtySize++;
            for (let n = 0; n < this.colorTextures.length; n++) {
              let r = this.colorTextures[n],
                i = r.resolution;
              r.setSize(e / i, t / i);
            }
            if (this.depthTexture) {
              let n = this.depthTexture.resolution;
              this.depthTexture.setSize(e / n, t / n);
            }
          }
        }
        dispose() {
          this.disposeRunner.emit(this, !1);
        }
        destroyDepthTexture() {
          this.depthTexture &&
            (this.depthTexture.destroy(),
            (this.depthTexture = null),
            ++this.dirtyId,
            ++this.dirtyFormat);
        }
      });
  }))();
}
var va;
function ya() {
  return (ya = t(() => {
    Ot(),
      w(),
      _a(),
      $n(),
      (va = class extends H {
        constructor(e = {}) {
          typeof e == `number` &&
            (e = {
              width: arguments[0],
              height: arguments[1],
              scaleMode: arguments[2],
              resolution: arguments[3],
            }),
            (e.width = e.width || 100),
            (e.height = e.height || 100),
            e.multisample ?? (e.multisample = S.NONE),
            super(null, e),
            (this.mipmap = g.OFF),
            (this.valid = !0),
            (this._clear = new I([0, 0, 0, 0])),
            (this.framebuffer = new ga(
              this.realWidth,
              this.realHeight
            ).addColorTexture(0, this)),
            (this.framebuffer.multisample = e.multisample),
            (this.maskStack = []),
            (this.filterStack = [{}]);
        }
        set clearColor(e) {
          this._clear.setValue(e);
        }
        get clearColor() {
          return this._clear.value;
        }
        get clear() {
          return this._clear;
        }
        resize(e, t) {
          this.framebuffer.resize(e * this.resolution, t * this.resolution),
            this.setRealSize(this.framebuffer.width, this.framebuffer.height);
        }
        dispose() {
          this.framebuffer.dispose(), super.dispose();
        }
        destroy() {
          super.destroy(),
            this.framebuffer.destroyDepthTexture(),
            (this.framebuffer = null);
        }
      });
  }))();
}
var ba;
function xa() {
  return (xa = t(() => {
    w(),
      R(),
      Jn(),
      (ba = class extends qn {
        constructor(e) {
          let t = e,
            n = t.naturalWidth || t.videoWidth || t.width,
            r = t.naturalHeight || t.videoHeight || t.height;
          super(n, r), (this.source = e), (this.noSubImage = !1);
        }
        static crossOrigin(e, t, n) {
          n === void 0 && !t.startsWith(`data:`)
            ? (e.crossOrigin = Cn(t))
            : n !== !1 &&
              (e.crossOrigin = typeof n == `string` ? n : `anonymous`);
        }
        upload(e, t, n, r) {
          let i = e.gl,
            a = t.realWidth,
            o = t.realHeight;
          if (
            ((r ||= this.source),
            typeof HTMLImageElement < `u` && r instanceof HTMLImageElement)
          ) {
            if (!r.complete || r.naturalWidth === 0) return !1;
          } else if (
            typeof HTMLVideoElement < `u` &&
            r instanceof HTMLVideoElement &&
            r.readyState <= 1 &&
            r.buffered.length === 0
          )
            return !1;
          return (
            i.pixelStorei(
              i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,
              t.alphaMode === _.UNPACK
            ),
            !this.noSubImage &&
            t.target === i.TEXTURE_2D &&
            n.width === a &&
            n.height === o
              ? i.texSubImage2D(i.TEXTURE_2D, 0, 0, 0, t.format, n.type, r)
              : ((n.width = a),
                (n.height = o),
                i.texImage2D(
                  t.target,
                  0,
                  n.internalFormat,
                  t.format,
                  n.type,
                  r
                )),
            !0
          );
        }
        update() {
          if (this.destroyed) return;
          let e = this.source,
            t = e.naturalWidth || e.videoWidth || e.width,
            n = e.naturalHeight || e.videoHeight || e.height;
          this.resize(t, n), super.update();
        }
        dispose() {
          this.source = null;
        }
      });
  }))();
}
var Sa;
function Ca() {
  return (Ca = t(() => {
    w(),
      N(),
      xa(),
      (Sa = class extends ba {
        constructor(e, t) {
          if (((t ||= {}), typeof e == `string`)) {
            let n = new Image();
            ba.crossOrigin(n, e, t.crossorigin), (n.src = e), (e = n);
          }
          super(e),
            !e.complete &&
              this._width &&
              this._height &&
              ((this._width = 0), (this._height = 0)),
            (this.url = e.src),
            (this._process = null),
            (this.preserveBitmap = !1),
            (this.createBitmap =
              (t.createBitmap ?? D.CREATE_IMAGE_BITMAP) &&
              !!globalThis.createImageBitmap),
            (this.alphaMode =
              typeof t.alphaMode == `number` ? t.alphaMode : null),
            (this.bitmap = null),
            (this._load = null),
            t.autoLoad !== !1 && this.load();
        }
        load(e) {
          return this._load
            ? this._load
            : (e !== void 0 && (this.createBitmap = e),
              (this._load = new Promise((e, t) => {
                let n = this.source;
                this.url = n.src;
                let r = () => {
                  this.destroyed ||
                    ((n.onload = null),
                    (n.onerror = null),
                    this.resize(n.width, n.height),
                    (this._load = null),
                    this.createBitmap ? e(this.process()) : e(this));
                };
                n.complete && n.src
                  ? r()
                  : ((n.onload = r),
                    (n.onerror = (e) => {
                      t(e), this.onError.emit(e);
                    }));
              })),
              this._load);
        }
        process() {
          let e = this.source;
          if (this._process !== null) return this._process;
          if (this.bitmap !== null || !globalThis.createImageBitmap)
            return Promise.resolve(this);
          let t = globalThis.createImageBitmap,
            n = !e.crossOrigin || e.crossOrigin === `anonymous`;
          return (
            (this._process = fetch(e.src, { mode: n ? `cors` : `no-cors` })
              .then((e) => e.blob())
              .then((n) =>
                t(n, 0, 0, e.width, e.height, {
                  premultiplyAlpha:
                    this.alphaMode === null || this.alphaMode === _.UNPACK
                      ? `premultiply`
                      : `none`,
                })
              )
              .then((e) =>
                this.destroyed
                  ? Promise.reject()
                  : ((this.bitmap = e),
                    this.update(),
                    (this._process = null),
                    Promise.resolve(this))
              )),
            this._process
          );
        }
        upload(e, t, n) {
          if (
            (typeof this.alphaMode == `number` &&
              (t.alphaMode = this.alphaMode),
            !this.createBitmap)
          )
            return super.upload(e, t, n);
          if (!this.bitmap && (this.process(), !this.bitmap)) return !1;
          if ((super.upload(e, t, n, this.bitmap), !this.preserveBitmap)) {
            let e = !0,
              r = t._glTextures;
            for (let i in r) {
              let a = r[i];
              if (a !== n && a.dirtyId !== t.dirtyId) {
                e = !1;
                break;
              }
            }
            e &&
              (this.bitmap.close && this.bitmap.close(), (this.bitmap = null));
          }
          return !0;
        }
        dispose() {
          (this.source.onload = null),
            (this.source.onerror = null),
            super.dispose(),
            (this.bitmap &&= (this.bitmap.close(), null)),
            (this._process = null),
            (this._load = null);
        }
        static test(e) {
          return (
            typeof HTMLImageElement < `u` &&
            (typeof e == `string` || e instanceof HTMLImageElement)
          );
        }
      });
  }))();
}
var wa;
function Ta() {
  return (Ta = t(() => {
    Y(),
      (wa = class {
        constructor() {
          (this.x0 = 0),
            (this.y0 = 0),
            (this.x1 = 1),
            (this.y1 = 0),
            (this.x2 = 1),
            (this.y2 = 1),
            (this.x3 = 0),
            (this.y3 = 1),
            (this.uvsFloat32 = new Float32Array(8));
        }
        set(e, t, n) {
          let r = t.width,
            i = t.height;
          if (n) {
            let t = e.width / 2 / r,
              a = e.height / 2 / i,
              o = e.x / r + t,
              s = e.y / i + a;
            (n = J.add(n, J.NW)),
              (this.x0 = o + t * J.uX(n)),
              (this.y0 = s + a * J.uY(n)),
              (n = J.add(n, 2)),
              (this.x1 = o + t * J.uX(n)),
              (this.y1 = s + a * J.uY(n)),
              (n = J.add(n, 2)),
              (this.x2 = o + t * J.uX(n)),
              (this.y2 = s + a * J.uY(n)),
              (n = J.add(n, 2)),
              (this.x3 = o + t * J.uX(n)),
              (this.y3 = s + a * J.uY(n));
          } else
            (this.x0 = e.x / r),
              (this.y0 = e.y / i),
              (this.x1 = (e.x + e.width) / r),
              (this.y1 = e.y / i),
              (this.x2 = (e.x + e.width) / r),
              (this.y2 = (e.y + e.height) / i),
              (this.x3 = e.x / r),
              (this.y3 = (e.y + e.height) / i);
          (this.uvsFloat32[0] = this.x0),
            (this.uvsFloat32[1] = this.y0),
            (this.uvsFloat32[2] = this.x1),
            (this.uvsFloat32[3] = this.y1),
            (this.uvsFloat32[4] = this.x2),
            (this.uvsFloat32[5] = this.y2),
            (this.uvsFloat32[6] = this.x3),
            (this.uvsFloat32[7] = this.y3);
        }
        toString() {
          return `[@pixi/core:TextureUvs x0=${this.x0} y0=${this.y0} x1=${this.x1} y1=${this.y1} x2=${this.x2} y2=${this.y2} x3=${this.x3} y3=${this.y3}]`;
        }
      });
  }))();
}
function Ea(e) {
  (e.destroy = function () {}),
    (e.on = function () {}),
    (e.once = function () {}),
    (e.emit = function () {});
}
var Da, X;
function Oa() {
  return (Oa = t(() => {
    Y(),
      N(),
      R(),
      $n(),
      Ca(),
      Ta(),
      (Da = new wa()),
      (X = class e extends kn.default {
        constructor(t, n, r, i, a, o, s) {
          if (
            (super(),
            (this.noFrame = !1),
            (n ||= ((this.noFrame = !0), new K(0, 0, 1, 1))),
            t instanceof e && (t = t.baseTexture),
            (this.baseTexture = t),
            (this._frame = n),
            (this.trim = i),
            (this.valid = !1),
            (this._uvs = Da),
            (this.uvMatrix = null),
            (this.orig = r || n),
            (this._rotate = Number(a || 0)),
            a === !0)
          )
            this._rotate = 2;
          else if (this._rotate % 2 != 0)
            throw Error(
              `attempt to use diamond-shaped UVs. If you are sure, set rotation manually`
            );
          (this.defaultAnchor = o ? new G(o.x, o.y) : new G(0, 0)),
            (this.defaultBorders = s),
            (this._updateID = 0),
            (this.textureCacheIds = []),
            t.valid
              ? this.noFrame
                ? t.valid && this.onBaseTextureUpdated(t)
                : (this.frame = n)
              : t.once(`loaded`, this.onBaseTextureUpdated, this),
            this.noFrame && t.on(`update`, this.onBaseTextureUpdated, this);
        }
        update() {
          this.baseTexture.resource && this.baseTexture.resource.update();
        }
        onBaseTextureUpdated(e) {
          if (this.noFrame) {
            if (!this.baseTexture.valid) return;
            (this._frame.width = e.width),
              (this._frame.height = e.height),
              (this.valid = !0),
              this.updateUvs();
          } else this.frame = this._frame;
          this.emit(`update`, this);
        }
        destroy(t) {
          if (this.baseTexture) {
            if (t) {
              let { resource: t } = this.baseTexture;
              t?.url && L[t.url] && e.removeFromCache(t.url),
                this.baseTexture.destroy();
            }
            this.baseTexture.off(`loaded`, this.onBaseTextureUpdated, this),
              this.baseTexture.off(`update`, this.onBaseTextureUpdated, this),
              (this.baseTexture = null);
          }
          (this._frame = null),
            (this._uvs = null),
            (this.trim = null),
            (this.orig = null),
            (this.valid = !1),
            e.removeFromCache(this),
            (this.textureCacheIds = null);
        }
        clone() {
          let t = this._frame.clone(),
            n = this._frame === this.orig ? t : this.orig.clone(),
            r = new e(
              this.baseTexture,
              !this.noFrame && t,
              n,
              this.trim?.clone(),
              this.rotate,
              this.defaultAnchor,
              this.defaultBorders
            );
          return this.noFrame && (r._frame = t), r;
        }
        updateUvs() {
          this._uvs === Da && (this._uvs = new wa()),
            this._uvs.set(this._frame, this.baseTexture, this.rotate),
            this._updateID++;
        }
        static from(t, n = {}, r = D.STRICT_TEXTURE_CACHE) {
          let i = typeof t == `string`,
            a = null;
          i
            ? (a = t)
            : t instanceof H
            ? (t.cacheId ||
                ((t.cacheId = `${n?.pixiIdPrefix || `pixiid`}-${tn()}`),
                H.addToCache(t, t.cacheId)),
              (a = t.cacheId))
            : ((t._pixiId ||= `${n?.pixiIdPrefix || `pixiid`}_${tn()}`),
              (a = t._pixiId));
          let o = L[a];
          if (i && r && !o)
            throw Error(`The cacheId "${a}" does not exist in TextureCache.`);
          return (
            !o && !(t instanceof H)
              ? ((n.resolution ||= En(t)),
                (o = new e(new H(t, n))),
                (o.baseTexture.cacheId = a),
                H.addToCache(o.baseTexture, a),
                e.addToCache(o, a))
              : !o && t instanceof H && ((o = new e(t)), e.addToCache(o, a)),
            o
          );
        }
        static fromURL(t, n) {
          let r = Object.assign({ autoLoad: !1 }, n?.resourceOptions),
            i = e.from(t, Object.assign({ resourceOptions: r }, n), !1),
            a = i.baseTexture.resource;
          return i.baseTexture.valid
            ? Promise.resolve(i)
            : a.load().then(() => Promise.resolve(i));
        }
        static fromBuffer(t, n, r, i) {
          return new e(H.fromBuffer(t, n, r, i));
        }
        static fromLoader(t, n, r, i) {
          let a = new H(
              t,
              Object.assign(
                { scaleMode: H.defaultOptions.scaleMode, resolution: En(n) },
                i
              )
            ),
            { resource: o } = a;
          o instanceof Sa && (o.url = n);
          let s = new e(a);
          return (
            (r ||= n),
            H.addToCache(s.baseTexture, r),
            e.addToCache(s, r),
            r !== n && (H.addToCache(s.baseTexture, n), e.addToCache(s, n)),
            s.baseTexture.valid
              ? Promise.resolve(s)
              : new Promise((e) => {
                  s.baseTexture.once(`loaded`, () => e(s));
                })
          );
        }
        static addToCache(e, t) {
          t &&
            (e.textureCacheIds.includes(t) || e.textureCacheIds.push(t),
            L[t] &&
              L[t] !== e &&
              console.warn(
                `Texture added to the cache with an id [${t}] that already had an entry`
              ),
            (L[t] = e));
        }
        static removeFromCache(e) {
          if (typeof e == `string`) {
            let t = L[e];
            if (t) {
              let n = t.textureCacheIds.indexOf(e);
              return n > -1 && t.textureCacheIds.splice(n, 1), delete L[e], t;
            }
          } else if (e?.textureCacheIds) {
            for (let t = 0; t < e.textureCacheIds.length; ++t)
              L[e.textureCacheIds[t]] === e && delete L[e.textureCacheIds[t]];
            return (e.textureCacheIds.length = 0), e;
          }
          return null;
        }
        get resolution() {
          return this.baseTexture.resolution;
        }
        get frame() {
          return this._frame;
        }
        set frame(e) {
          (this._frame = e), (this.noFrame = !1);
          let { x: t, y: n, width: r, height: i } = e,
            a = t + r > this.baseTexture.width,
            o = n + i > this.baseTexture.height;
          if (a || o) {
            let e = a && o ? `and` : `or`,
              s = `X: ${t} + ${r} = ${t + r} > ${this.baseTexture.width}`,
              c = `Y: ${n} + ${i} = ${n + i} > ${this.baseTexture.height}`;
            throw Error(
              `Texture Error: frame does not fit inside the base Texture dimensions: ${s} ${e} ${c}`
            );
          }
          (this.valid = r && i && this.baseTexture.valid),
            !this.trim && !this.rotate && (this.orig = e),
            this.valid && this.updateUvs();
        }
        get rotate() {
          return this._rotate;
        }
        set rotate(e) {
          (this._rotate = e), this.valid && this.updateUvs();
        }
        get width() {
          return this.orig.width;
        }
        get height() {
          return this.orig.height;
        }
        castToBaseTexture() {
          return this.baseTexture;
        }
        static get EMPTY() {
          return (
            e._EMPTY ||
              ((e._EMPTY = new e(new H())),
              Ea(e._EMPTY),
              Ea(e._EMPTY.baseTexture)),
            e._EMPTY
          );
        }
        static get WHITE() {
          if (!e._WHITE) {
            let t = D.ADAPTER.createCanvas(16, 16),
              n = t.getContext(`2d`);
            (t.width = 16),
              (t.height = 16),
              (n.fillStyle = `white`),
              n.fillRect(0, 0, 16, 16),
              (e._WHITE = new e(H.from(t))),
              Ea(e._WHITE),
              Ea(e._WHITE.baseTexture);
          }
          return e._WHITE;
        }
      });
  }))();
}
var ka;
function Aa() {
  return (Aa = t(() => {
    Oa(),
      ya(),
      (ka = class e extends X {
        constructor(e, t) {
          super(e, t),
            (this.valid = !0),
            (this.filterFrame = null),
            (this.filterPoolKey = null),
            this.updateUvs();
        }
        get framebuffer() {
          return this.baseTexture.framebuffer;
        }
        get multisample() {
          return this.framebuffer.multisample;
        }
        set multisample(e) {
          this.framebuffer.multisample = e;
        }
        resize(e, t, n = !0) {
          let r = this.baseTexture.resolution,
            i = Math.round(e * r) / r,
            a = Math.round(t * r) / r;
          (this.valid = i > 0 && a > 0),
            (this._frame.width = this.orig.width = i),
            (this._frame.height = this.orig.height = a),
            n && this.baseTexture.resize(i, a),
            this.updateUvs();
        }
        setResolution(e) {
          let { baseTexture: t } = this;
          t.resolution !== e &&
            (t.setResolution(e), this.resize(t.width, t.height, !1));
        }
        static create(t) {
          return new e(new va(t));
        }
      });
  }))();
}
var ja;
function Ma() {
  return (Ma = t(() => {
    w(),
      R(),
      ya(),
      Aa(),
      (ja = class {
        constructor(e) {
          (this.texturePool = {}),
            (this.textureOptions = e || {}),
            (this.enableFullScreen = !1),
            (this._pixelsWidth = 0),
            (this._pixelsHeight = 0);
        }
        createTexture(e, t, n = S.NONE) {
          let r = new va(
            Object.assign(
              { width: e, height: t, resolution: 1, multisample: n },
              this.textureOptions
            )
          );
          return new ka(r);
        }
        getOptimalTexture(e, t, n = 1, r = S.NONE) {
          let i;
          (e = Math.ceil(e * n - 1e-6)),
            (t = Math.ceil(t * n - 1e-6)),
            !this.enableFullScreen ||
            e !== this._pixelsWidth ||
            t !== this._pixelsHeight
              ? ((e = Jt(e)),
                (t = Jt(t)),
                (i = (((e & 65535) << 16) | (t & 65535)) >>> 0),
                r > 1 && (i += r * 4294967296))
              : (i = r > 1 ? -r : -1),
            this.texturePool[i] || (this.texturePool[i] = []);
          let a = this.texturePool[i].pop();
          return (
            (a ||= this.createTexture(e, t, r)),
            (a.filterPoolKey = i),
            a.setResolution(n),
            a
          );
        }
        getFilterTexture(e, t, n) {
          let r = this.getOptimalTexture(
            e.width,
            e.height,
            t || e.resolution,
            n || S.NONE
          );
          return (r.filterFrame = e.filterFrame), r;
        }
        returnTexture(e) {
          let t = e.filterPoolKey;
          (e.filterFrame = null), this.texturePool[t].push(e);
        }
        returnFilterTexture(e) {
          this.returnTexture(e);
        }
        clear(e) {
          if (((e = e !== !1), e))
            for (let e in this.texturePool) {
              let t = this.texturePool[e];
              if (t) for (let e = 0; e < t.length; e++) t[e].destroy(!0);
            }
          this.texturePool = {};
        }
        setScreenSize(e) {
          if (
            e.width !== this._pixelsWidth ||
            e.height !== this._pixelsHeight
          ) {
            this.enableFullScreen = e.width > 0 && e.height > 0;
            for (let e in this.texturePool) {
              if (!(Number(e) < 0)) continue;
              let t = this.texturePool[e];
              if (t) for (let e = 0; e < t.length; e++) t[e].destroy(!0);
              this.texturePool[e] = [];
            }
            (this._pixelsWidth = e.width), (this._pixelsHeight = e.height);
          }
        }
      }),
      (ja.SCREEN_KEY = -1);
  }))();
}
var Na;
function Pa() {
  return (Pa = t(() => {
    pr(),
      (Na = class extends fr {
        constructor() {
          super(),
            this.addAttribute(
              `aVertexPosition`,
              new Float32Array([0, 0, 1, 0, 1, 1, 0, 1])
            ).addIndex([0, 1, 3, 2]);
        }
      });
  }))();
}
var Fa;
function Ia() {
  return (Ia = t(() => {
    rr(),
      pr(),
      (Fa = class extends fr {
        constructor() {
          super(),
            (this.vertices = new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1])),
            (this.uvs = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1])),
            (this.vertexBuffer = new U(this.vertices)),
            (this.uvBuffer = new U(this.uvs)),
            this.addAttribute(`aVertexPosition`, this.vertexBuffer)
              .addAttribute(`aTextureCoord`, this.uvBuffer)
              .addIndex([0, 1, 2, 0, 2, 3]);
        }
        map(e, t) {
          let n = 0,
            r = 0;
          return (
            (this.uvs[0] = n),
            (this.uvs[1] = r),
            (this.uvs[2] = n + t.width / e.width),
            (this.uvs[3] = r),
            (this.uvs[4] = n + t.width / e.width),
            (this.uvs[5] = r + t.height / e.height),
            (this.uvs[6] = n),
            (this.uvs[7] = r + t.height / e.height),
            (n = t.x),
            (r = t.y),
            (this.vertices[0] = n),
            (this.vertices[1] = r),
            (this.vertices[2] = n + t.width),
            (this.vertices[3] = r),
            (this.vertices[4] = n + t.width),
            (this.vertices[5] = r + t.height),
            (this.vertices[6] = n),
            (this.vertices[7] = r + t.height),
            this.invalidate(),
            this
          );
        }
        invalidate() {
          return this.vertexBuffer._updateID++, this.uvBuffer._updateID++, this;
        }
      });
  }))();
}
var La;
function Ra() {
  return (Ra = t(() => {
    w(),
      Y(),
      (La = class {
        constructor() {
          (this.renderTexture = null),
            (this.target = null),
            (this.legacy = !1),
            (this.resolution = 1),
            (this.multisample = S.NONE),
            (this.sourceFrame = new K()),
            (this.destinationFrame = new K()),
            (this.bindingSourceFrame = new K()),
            (this.bindingDestinationFrame = new K()),
            (this.filters = []),
            (this.transform = null);
        }
        clear() {
          (this.target = null),
            (this.filters = null),
            (this.renderTexture = null);
        }
      });
  }))();
}
var za, Ba, Va;
function Ha() {
  return (Ha = t(() => {
    w(),
      V(),
      Y(),
      Ma(),
      Pi(),
      Pa(),
      Ia(),
      Ra(),
      (za = [new G(), new G(), new G(), new G()]),
      (Ba = new q()),
      (Va = class {
        constructor(e) {
          (this.renderer = e),
            (this.defaultFilterStack = [{}]),
            (this.texturePool = new ja()),
            (this.statePool = []),
            (this.quad = new Na()),
            (this.quadUv = new Fa()),
            (this.tempRect = new K()),
            (this.activeState = {}),
            (this.globalUniforms = new Ni(
              {
                outputFrame: new K(),
                inputSize: new Float32Array(4),
                inputPixel: new Float32Array(4),
                inputClamp: new Float32Array(4),
                resolution: 1,
                filterArea: new Float32Array(4),
                filterClamp: new Float32Array(4),
              },
              !0
            )),
            (this.forceClear = !1),
            (this.useMaxPadding = !1);
        }
        init() {
          this.texturePool.setScreenSize(this.renderer.view);
        }
        push(e, t) {
          let n = this.renderer,
            r = this.defaultFilterStack,
            i = this.statePool.pop() || new La(),
            a = this.renderer.renderTexture,
            o = t[0].resolution,
            s = t[0].multisample,
            c = t[0].padding,
            l = t[0].autoFit,
            u = t[0].legacy ?? !0;
          for (let e = 1; e < t.length; e++) {
            let n = t[e];
            (o = Math.min(o, n.resolution)),
              (s = Math.min(s, n.multisample)),
              (c = this.useMaxPadding ? Math.max(c, n.padding) : c + n.padding),
              (l &&= n.autoFit),
              (u ||= n.legacy ?? !0);
          }
          r.length === 1 &&
            (this.defaultFilterStack[0].renderTexture = a.current),
            r.push(i),
            (i.resolution = o),
            (i.multisample = s),
            (i.legacy = u),
            (i.target = e),
            i.sourceFrame.copyFrom(e.filterArea || e.getBounds(!0)),
            i.sourceFrame.pad(c);
          let d = this.tempRect.copyFrom(a.sourceFrame);
          n.projection.transform &&
            this.transformAABB(Ba.copyFrom(n.projection.transform).invert(), d),
            l
              ? (i.sourceFrame.fit(d),
                (i.sourceFrame.width <= 0 || i.sourceFrame.height <= 0) &&
                  ((i.sourceFrame.width = 0), (i.sourceFrame.height = 0)))
              : i.sourceFrame.intersects(d) ||
                ((i.sourceFrame.width = 0), (i.sourceFrame.height = 0)),
            this.roundFrame(
              i.sourceFrame,
              a.current ? a.current.resolution : n.resolution,
              a.sourceFrame,
              a.destinationFrame,
              n.projection.transform
            ),
            (i.renderTexture = this.getOptimalFilterTexture(
              i.sourceFrame.width,
              i.sourceFrame.height,
              o,
              s
            )),
            (i.filters = t),
            (i.destinationFrame.width = i.renderTexture.width),
            (i.destinationFrame.height = i.renderTexture.height);
          let f = this.tempRect;
          (f.x = 0),
            (f.y = 0),
            (f.width = i.sourceFrame.width),
            (f.height = i.sourceFrame.height),
            (i.renderTexture.filterFrame = i.sourceFrame),
            i.bindingSourceFrame.copyFrom(a.sourceFrame),
            i.bindingDestinationFrame.copyFrom(a.destinationFrame),
            (i.transform = n.projection.transform),
            (n.projection.transform = null),
            a.bind(i.renderTexture, i.sourceFrame, f),
            n.framebuffer.clear(0, 0, 0, 0);
        }
        pop() {
          let e = this.defaultFilterStack,
            t = e.pop(),
            n = t.filters;
          this.activeState = t;
          let r = this.globalUniforms.uniforms;
          (r.outputFrame = t.sourceFrame), (r.resolution = t.resolution);
          let i = r.inputSize,
            a = r.inputPixel,
            o = r.inputClamp;
          if (
            ((i[0] = t.destinationFrame.width),
            (i[1] = t.destinationFrame.height),
            (i[2] = 1 / i[0]),
            (i[3] = 1 / i[1]),
            (a[0] = Math.round(i[0] * t.resolution)),
            (a[1] = Math.round(i[1] * t.resolution)),
            (a[2] = 1 / a[0]),
            (a[3] = 1 / a[1]),
            (o[0] = 0.5 * a[2]),
            (o[1] = 0.5 * a[3]),
            (o[2] = t.sourceFrame.width * i[2] - 0.5 * a[2]),
            (o[3] = t.sourceFrame.height * i[3] - 0.5 * a[3]),
            t.legacy)
          ) {
            let e = r.filterArea;
            (e[0] = t.destinationFrame.width),
              (e[1] = t.destinationFrame.height),
              (e[2] = t.sourceFrame.x),
              (e[3] = t.sourceFrame.y),
              (r.filterClamp = r.inputClamp);
          }
          this.globalUniforms.update();
          let s = e[e.length - 1];
          if ((this.renderer.framebuffer.blit(), n.length === 1))
            n[0].apply(this, t.renderTexture, s.renderTexture, v.BLEND, t),
              this.returnFilterTexture(t.renderTexture);
          else {
            let e = t.renderTexture,
              r = this.getOptimalFilterTexture(e.width, e.height, t.resolution);
            r.filterFrame = e.filterFrame;
            let i = 0;
            for (i = 0; i < n.length - 1; ++i) {
              i === 1 &&
                t.multisample > 1 &&
                ((r = this.getOptimalFilterTexture(
                  e.width,
                  e.height,
                  t.resolution
                )),
                (r.filterFrame = e.filterFrame)),
                n[i].apply(this, e, r, v.CLEAR, t);
              let a = e;
              (e = r), (r = a);
            }
            n[i].apply(this, e, s.renderTexture, v.BLEND, t),
              i > 1 &&
                t.multisample > 1 &&
                this.returnFilterTexture(t.renderTexture),
              this.returnFilterTexture(e),
              this.returnFilterTexture(r);
          }
          t.clear(), this.statePool.push(t);
        }
        bindAndClear(e, t = v.CLEAR) {
          let { renderTexture: n, state: r } = this.renderer;
          if (
            (e ===
            this.defaultFilterStack[this.defaultFilterStack.length - 1]
              .renderTexture
              ? (this.renderer.projection.transform =
                  this.activeState.transform)
              : (this.renderer.projection.transform = null),
            e?.filterFrame)
          ) {
            let t = this.tempRect;
            (t.x = 0),
              (t.y = 0),
              (t.width = e.filterFrame.width),
              (t.height = e.filterFrame.height),
              n.bind(e, e.filterFrame, t);
          } else
            e ===
            this.defaultFilterStack[this.defaultFilterStack.length - 1]
              .renderTexture
              ? this.renderer.renderTexture.bind(
                  e,
                  this.activeState.bindingSourceFrame,
                  this.activeState.bindingDestinationFrame
                )
              : n.bind(e);
          let i = r.stateId & 1 || this.forceClear;
          (t === v.CLEAR || (t === v.BLIT && i)) &&
            this.renderer.framebuffer.clear(0, 0, 0, 0);
        }
        applyFilter(e, t, n, r) {
          let i = this.renderer;
          i.state.set(e.state),
            this.bindAndClear(n, r),
            (e.uniforms.uSampler = t),
            (e.uniforms.filterGlobals = this.globalUniforms),
            i.shader.bind(e),
            (e.legacy = !!e.program.attributeData.aTextureCoord),
            e.legacy
              ? (this.quadUv.map(t._frame, t.filterFrame),
                i.geometry.bind(this.quadUv),
                i.geometry.draw(l.TRIANGLES))
              : (i.geometry.bind(this.quad), i.geometry.draw(l.TRIANGLE_STRIP));
        }
        calculateSpriteMatrix(e, t) {
          let { sourceFrame: n, destinationFrame: r } = this.activeState,
            { orig: i } = t._texture,
            a = e.set(r.width, 0, 0, r.height, n.x, n.y),
            o = t.worldTransform.copyTo(q.TEMP_MATRIX);
          return (
            o.invert(),
            a.prepend(o),
            a.scale(1 / i.width, 1 / i.height),
            a.translate(t.anchor.x, t.anchor.y),
            a
          );
        }
        destroy() {
          (this.renderer = null), this.texturePool.clear(!1);
        }
        getOptimalFilterTexture(e, t, n = 1, r = S.NONE) {
          return this.texturePool.getOptimalTexture(e, t, n, r);
        }
        getFilterTexture(e, t, n) {
          if (typeof e == `number`) {
            let n = e;
            (e = t), (t = n);
          }
          e ||= this.activeState.renderTexture;
          let r = this.texturePool.getOptimalTexture(
            e.width,
            e.height,
            t || e.resolution,
            n || S.NONE
          );
          return (r.filterFrame = e.filterFrame), r;
        }
        returnFilterTexture(e) {
          this.texturePool.returnTexture(e);
        }
        emptyPool() {
          this.texturePool.clear(!0);
        }
        resize() {
          this.texturePool.setScreenSize(this.renderer.view);
        }
        transformAABB(e, t) {
          let n = za[0],
            r = za[1],
            i = za[2],
            a = za[3];
          n.set(t.left, t.top),
            r.set(t.left, t.bottom),
            i.set(t.right, t.top),
            a.set(t.right, t.bottom),
            e.apply(n, n),
            e.apply(r, r),
            e.apply(i, i),
            e.apply(a, a);
          let o = Math.min(n.x, r.x, i.x, a.x),
            s = Math.min(n.y, r.y, i.y, a.y),
            c = Math.max(n.x, r.x, i.x, a.x),
            l = Math.max(n.y, r.y, i.y, a.y);
          (t.x = o), (t.y = s), (t.width = c - o), (t.height = l - s);
        }
        roundFrame(e, t, n, r, i) {
          if (
            !(e.width <= 0 || e.height <= 0 || n.width <= 0 || n.height <= 0)
          ) {
            if (i) {
              let { a: e, b: t, c: n, d: r } = i;
              if (
                (Math.abs(t) > 1e-4 || Math.abs(n) > 1e-4) &&
                (Math.abs(e) > 1e-4 || Math.abs(r) > 1e-4)
              )
                return;
            }
            (i = i ? Ba.copyFrom(i) : Ba.identity()),
              i
                .translate(-n.x, -n.y)
                .scale(r.width / n.width, r.height / n.height)
                .translate(r.x, r.y),
              this.transformAABB(i, e),
              e.ceil(t),
              this.transformAABB(i.invert(), e);
          }
        }
      }),
      (Va.extension = { type: z.RendererSystem, name: `filter` }),
      B.add(Va);
  }))();
}
var Ua;
function Wa() {
  return (Wa = t(() => {
    w(),
      (Ua = class {
        constructor(e) {
          (this.framebuffer = e),
            (this.stencil = null),
            (this.dirtyId = -1),
            (this.dirtyFormat = -1),
            (this.dirtySize = -1),
            (this.multisample = S.NONE),
            (this.msaaBuffer = null),
            (this.blitFramebuffer = null),
            (this.mipLevel = 0);
        }
      });
  }))();
}
var Ga, Ka;
function qa() {
  return (qa = t(() => {
    w(),
      V(),
      Y(),
      N(),
      _a(),
      Wa(),
      (Ga = new K()),
      (Ka = class {
        constructor(e) {
          (this.renderer = e),
            (this.managedFramebuffers = []),
            (this.unknownFramebuffer = new ga(10, 10)),
            (this.msaaSamples = null);
        }
        contextChange() {
          this.disposeAll(!0);
          let e = (this.gl = this.renderer.gl);
          if (
            ((this.CONTEXT_UID = this.renderer.CONTEXT_UID),
            (this.current = this.unknownFramebuffer),
            (this.viewport = new K()),
            (this.hasMRT = !0),
            (this.writeDepthTexture = !0),
            this.renderer.context.webGLVersion === 1)
          ) {
            let t = this.renderer.context.extensions.drawBuffers,
              n = this.renderer.context.extensions.depthTexture;
            D.PREFER_ENV === a.WEBGL_LEGACY && ((t = null), (n = null)),
              t
                ? (e.drawBuffers = (e) => t.drawBuffersWEBGL(e))
                : ((this.hasMRT = !1), (e.drawBuffers = () => {})),
              n || (this.writeDepthTexture = !1);
          } else
            this.msaaSamples = e.getInternalformatParameter(
              e.RENDERBUFFER,
              e.RGBA8,
              e.SAMPLES
            );
        }
        bind(e, t, n = 0) {
          let { gl: r } = this;
          if (e) {
            let i =
              e.glFramebuffers[this.CONTEXT_UID] || this.initFramebuffer(e);
            this.current !== e &&
              ((this.current = e),
              r.bindFramebuffer(r.FRAMEBUFFER, i.framebuffer)),
              i.mipLevel !== n &&
                (e.dirtyId++, e.dirtyFormat++, (i.mipLevel = n)),
              i.dirtyId !== e.dirtyId &&
                ((i.dirtyId = e.dirtyId),
                i.dirtyFormat === e.dirtyFormat
                  ? i.dirtySize !== e.dirtySize &&
                    ((i.dirtySize = e.dirtySize), this.resizeFramebuffer(e))
                  : ((i.dirtyFormat = e.dirtyFormat),
                    (i.dirtySize = e.dirtySize),
                    this.updateFramebuffer(e, n)));
            for (let t = 0; t < e.colorTextures.length; t++) {
              let n = e.colorTextures[t];
              this.renderer.texture.unbind(n.parentTextureArray || n);
            }
            if (
              (e.depthTexture && this.renderer.texture.unbind(e.depthTexture),
              t)
            ) {
              let e = t.width >> n,
                r = t.height >> n,
                i = e / t.width;
              this.setViewport(t.x * i, t.y * i, e, r);
            } else {
              let t = e.width >> n,
                r = e.height >> n;
              this.setViewport(0, 0, t, r);
            }
          } else
            this.current &&
              ((this.current = null), r.bindFramebuffer(r.FRAMEBUFFER, null)),
              t
                ? this.setViewport(t.x, t.y, t.width, t.height)
                : this.setViewport(
                    0,
                    0,
                    this.renderer.width,
                    this.renderer.height
                  );
        }
        setViewport(e, t, n, r) {
          let i = this.viewport;
          (e = Math.round(e)),
            (t = Math.round(t)),
            (n = Math.round(n)),
            (r = Math.round(r)),
            (i.width !== n || i.height !== r || i.x !== e || i.y !== t) &&
              ((i.x = e),
              (i.y = t),
              (i.width = n),
              (i.height = r),
              this.gl.viewport(e, t, n, r));
        }
        get size() {
          return this.current
            ? {
                x: 0,
                y: 0,
                width: this.current.width,
                height: this.current.height,
              }
            : {
                x: 0,
                y: 0,
                width: this.renderer.width,
                height: this.renderer.height,
              };
        }
        clear(e, t, n, r, i = s.COLOR | s.DEPTH) {
          let { gl: a } = this;
          a.clearColor(e, t, n, r), a.clear(i);
        }
        initFramebuffer(e) {
          let { gl: t } = this,
            n = new Ua(t.createFramebuffer());
          return (
            (n.multisample = this.detectSamples(e.multisample)),
            (e.glFramebuffers[this.CONTEXT_UID] = n),
            this.managedFramebuffers.push(e),
            e.disposeRunner.add(this),
            n
          );
        }
        resizeFramebuffer(e) {
          let { gl: t } = this,
            n = e.glFramebuffers[this.CONTEXT_UID];
          n.stencil &&
            (t.bindRenderbuffer(t.RENDERBUFFER, n.stencil),
            n.msaaBuffer
              ? t.renderbufferStorageMultisample(
                  t.RENDERBUFFER,
                  n.multisample,
                  t.DEPTH24_STENCIL8,
                  e.width,
                  e.height
                )
              : t.renderbufferStorage(
                  t.RENDERBUFFER,
                  t.DEPTH_STENCIL,
                  e.width,
                  e.height
                ));
          let r = e.colorTextures,
            i = r.length;
          t.drawBuffers || (i = Math.min(i, 1));
          for (let a = 0; a < i; a++) {
            let i = r[a],
              o = i.parentTextureArray || i;
            this.renderer.texture.bind(o, 0),
              a === 0 &&
                n.msaaBuffer &&
                (t.bindRenderbuffer(t.RENDERBUFFER, n.msaaBuffer),
                t.renderbufferStorageMultisample(
                  t.RENDERBUFFER,
                  n.multisample,
                  o._glTextures[this.CONTEXT_UID].internalFormat,
                  e.width,
                  e.height
                ));
          }
          e.depthTexture &&
            this.writeDepthTexture &&
            this.renderer.texture.bind(e.depthTexture, 0);
        }
        updateFramebuffer(e, t) {
          let { gl: n } = this,
            r = e.glFramebuffers[this.CONTEXT_UID],
            i = e.colorTextures,
            a = i.length;
          n.drawBuffers || (a = Math.min(a, 1)),
            r.multisample > 1 && this.canMultisampleFramebuffer(e)
              ? (r.msaaBuffer = r.msaaBuffer || n.createRenderbuffer())
              : r.msaaBuffer &&
                (n.deleteRenderbuffer(r.msaaBuffer),
                (r.msaaBuffer = null),
                (r.blitFramebuffer &&= (r.blitFramebuffer.dispose(), null)));
          let o = [];
          for (let s = 0; s < a; s++) {
            let a = i[s],
              c = a.parentTextureArray || a;
            this.renderer.texture.bind(c, 0),
              s === 0 && r.msaaBuffer
                ? (n.bindRenderbuffer(n.RENDERBUFFER, r.msaaBuffer),
                  n.renderbufferStorageMultisample(
                    n.RENDERBUFFER,
                    r.multisample,
                    c._glTextures[this.CONTEXT_UID].internalFormat,
                    e.width,
                    e.height
                  ),
                  n.framebufferRenderbuffer(
                    n.FRAMEBUFFER,
                    n.COLOR_ATTACHMENT0,
                    n.RENDERBUFFER,
                    r.msaaBuffer
                  ))
                : (n.framebufferTexture2D(
                    n.FRAMEBUFFER,
                    n.COLOR_ATTACHMENT0 + s,
                    a.target,
                    c._glTextures[this.CONTEXT_UID].texture,
                    t
                  ),
                  o.push(n.COLOR_ATTACHMENT0 + s));
          }
          if (
            (o.length > 1 && n.drawBuffers(o),
            e.depthTexture && this.writeDepthTexture)
          ) {
            let r = e.depthTexture;
            this.renderer.texture.bind(r, 0),
              n.framebufferTexture2D(
                n.FRAMEBUFFER,
                n.DEPTH_ATTACHMENT,
                n.TEXTURE_2D,
                r._glTextures[this.CONTEXT_UID].texture,
                t
              );
          }
          (e.stencil || e.depth) && !(e.depthTexture && this.writeDepthTexture)
            ? ((r.stencil = r.stencil || n.createRenderbuffer()),
              n.bindRenderbuffer(n.RENDERBUFFER, r.stencil),
              r.msaaBuffer
                ? n.renderbufferStorageMultisample(
                    n.RENDERBUFFER,
                    r.multisample,
                    n.DEPTH24_STENCIL8,
                    e.width,
                    e.height
                  )
                : n.renderbufferStorage(
                    n.RENDERBUFFER,
                    n.DEPTH_STENCIL,
                    e.width,
                    e.height
                  ),
              n.framebufferRenderbuffer(
                n.FRAMEBUFFER,
                n.DEPTH_STENCIL_ATTACHMENT,
                n.RENDERBUFFER,
                r.stencil
              ))
            : (r.stencil &&= (n.deleteRenderbuffer(r.stencil), null));
        }
        canMultisampleFramebuffer(e) {
          return (
            this.renderer.context.webGLVersion !== 1 &&
            e.colorTextures.length <= 1 &&
            !e.depthTexture
          );
        }
        detectSamples(e) {
          let { msaaSamples: t } = this,
            n = S.NONE;
          if (e <= 1 || t === null) return n;
          for (let r = 0; r < t.length; r++)
            if (t[r] <= e) {
              n = t[r];
              break;
            }
          return n === 1 && (n = S.NONE), n;
        }
        blit(e, t, n) {
          let { current: r, renderer: i, gl: a, CONTEXT_UID: o } = this;
          if (i.context.webGLVersion !== 2 || !r) return;
          let s = r.glFramebuffers[o];
          if (!s) return;
          if (!e) {
            if (!s.msaaBuffer) return;
            let t = r.colorTextures[0];
            if (!t) return;
            s.blitFramebuffer ||
              ((s.blitFramebuffer = new ga(r.width, r.height)),
              s.blitFramebuffer.addColorTexture(0, t)),
              (e = s.blitFramebuffer),
              e.colorTextures[0] !== t &&
                ((e.colorTextures[0] = t), e.dirtyId++, e.dirtyFormat++),
              (e.width !== r.width || e.height !== r.height) &&
                ((e.width = r.width),
                (e.height = r.height),
                e.dirtyId++,
                e.dirtySize++);
          }
          t || ((t = Ga), (t.width = r.width), (t.height = r.height)),
            (n ||= t);
          let c = t.width === n.width && t.height === n.height;
          this.bind(e),
            a.bindFramebuffer(a.READ_FRAMEBUFFER, s.framebuffer),
            a.blitFramebuffer(
              t.left,
              t.top,
              t.right,
              t.bottom,
              n.left,
              n.top,
              n.right,
              n.bottom,
              a.COLOR_BUFFER_BIT,
              c ? a.NEAREST : a.LINEAR
            );
        }
        disposeFramebuffer(e, t) {
          let n = e.glFramebuffers[this.CONTEXT_UID],
            r = this.gl;
          if (!n) return;
          delete e.glFramebuffers[this.CONTEXT_UID];
          let i = this.managedFramebuffers.indexOf(e);
          i >= 0 && this.managedFramebuffers.splice(i, 1),
            e.disposeRunner.remove(this),
            t ||
              (r.deleteFramebuffer(n.framebuffer),
              n.msaaBuffer && r.deleteRenderbuffer(n.msaaBuffer),
              n.stencil && r.deleteRenderbuffer(n.stencil)),
            n.blitFramebuffer && this.disposeFramebuffer(n.blitFramebuffer, t);
        }
        disposeAll(e) {
          let t = this.managedFramebuffers;
          this.managedFramebuffers = [];
          for (let n = 0; n < t.length; n++) this.disposeFramebuffer(t[n], e);
        }
        forceStencil() {
          let e = this.current;
          if (!e) return;
          let t = e.glFramebuffers[this.CONTEXT_UID];
          if (!t || t.stencil) return;
          e.stencil = !0;
          let n = e.width,
            r = e.height,
            i = this.gl,
            a = i.createRenderbuffer();
          i.bindRenderbuffer(i.RENDERBUFFER, a),
            t.msaaBuffer
              ? i.renderbufferStorageMultisample(
                  i.RENDERBUFFER,
                  t.multisample,
                  i.DEPTH24_STENCIL8,
                  n,
                  r
                )
              : i.renderbufferStorage(i.RENDERBUFFER, i.DEPTH_STENCIL, n, r),
            (t.stencil = a),
            i.framebufferRenderbuffer(
              i.FRAMEBUFFER,
              i.DEPTH_STENCIL_ATTACHMENT,
              i.RENDERBUFFER,
              a
            );
        }
        reset() {
          (this.current = this.unknownFramebuffer), (this.viewport = new K());
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (Ka.extension = { type: z.RendererSystem, name: `framebuffer` }),
      B.add(Ka);
  }))();
}
var Ja, Ya;
function Xa() {
  return (Xa = t(() => {
    w(),
      V(),
      N(),
      (Ja = { 5126: 4, 5123: 2, 5121: 1 }),
      (Ya = class {
        constructor(e) {
          (this.renderer = e),
            (this._activeGeometry = null),
            (this._activeVao = null),
            (this.hasVao = !0),
            (this.hasInstance = !0),
            (this.canUseUInt32ElementIndex = !1),
            (this.managedGeometries = {});
        }
        contextChange() {
          this.disposeAll(!0);
          let e = (this.gl = this.renderer.gl),
            t = this.renderer.context;
          if (
            ((this.CONTEXT_UID = this.renderer.CONTEXT_UID),
            t.webGLVersion !== 2)
          ) {
            let t = this.renderer.context.extensions.vertexArrayObject;
            D.PREFER_ENV === a.WEBGL_LEGACY && (t = null),
              t
                ? ((e.createVertexArray = () => t.createVertexArrayOES()),
                  (e.bindVertexArray = (e) => t.bindVertexArrayOES(e)),
                  (e.deleteVertexArray = (e) => t.deleteVertexArrayOES(e)))
                : ((this.hasVao = !1),
                  (e.createVertexArray = () => null),
                  (e.bindVertexArray = () => null),
                  (e.deleteVertexArray = () => null));
          }
          if (t.webGLVersion !== 2) {
            let t = e.getExtension(`ANGLE_instanced_arrays`);
            t
              ? ((e.vertexAttribDivisor = (e, n) =>
                  t.vertexAttribDivisorANGLE(e, n)),
                (e.drawElementsInstanced = (e, n, r, i, a) =>
                  t.drawElementsInstancedANGLE(e, n, r, i, a)),
                (e.drawArraysInstanced = (e, n, r, i) =>
                  t.drawArraysInstancedANGLE(e, n, r, i)))
              : (this.hasInstance = !1);
          }
          this.canUseUInt32ElementIndex =
            t.webGLVersion === 2 || !!t.extensions.uint32ElementIndex;
        }
        bind(e, t) {
          t ||= this.renderer.shader.shader;
          let { gl: n } = this,
            r = e.glVertexArrayObjects[this.CONTEXT_UID],
            i = !1;
          r ||
            ((this.managedGeometries[e.id] = e),
            e.disposeRunner.add(this),
            (e.glVertexArrayObjects[this.CONTEXT_UID] = r = {}),
            (i = !0));
          let a = r[t.program.id] || this.initGeometryVao(e, t, i);
          (this._activeGeometry = e),
            this._activeVao !== a &&
              ((this._activeVao = a),
              this.hasVao
                ? n.bindVertexArray(a)
                : this.activateVao(e, t.program)),
            this.updateBuffers();
        }
        reset() {
          this.unbind();
        }
        updateBuffers() {
          let e = this._activeGeometry,
            t = this.renderer.buffer;
          for (let n = 0; n < e.buffers.length; n++) {
            let r = e.buffers[n];
            t.update(r);
          }
        }
        checkCompatibility(e, t) {
          let n = e.attributes,
            r = t.attributeData;
          for (let e in r)
            if (!n[e])
              throw Error(
                `shader and geometry incompatible, geometry missing the "${e}" attribute`
              );
        }
        getSignature(e, t) {
          let n = e.attributes,
            r = t.attributeData,
            i = [`g`, e.id];
          for (let e in n) r[e] && i.push(e, r[e].location);
          return i.join(`-`);
        }
        initGeometryVao(e, t, n = !0) {
          let r = this.gl,
            i = this.CONTEXT_UID,
            a = this.renderer.buffer,
            o = t.program;
          o.glPrograms[i] || this.renderer.shader.generateProgram(t),
            this.checkCompatibility(e, o);
          let s = this.getSignature(e, o),
            c = e.glVertexArrayObjects[this.CONTEXT_UID],
            l = c[s];
          if (l) return (c[o.id] = l), l;
          let u = e.buffers,
            d = e.attributes,
            f = {},
            p = {};
          for (let e in u) (f[e] = 0), (p[e] = 0);
          for (let e in d)
            !d[e].size && o.attributeData[e]
              ? (d[e].size = o.attributeData[e].size)
              : d[e].size ||
                console.warn(
                  `PIXI Geometry attribute '${e}' size cannot be determined (likely the bound shader does not have the attribute)`
                ),
              (f[d[e].buffer] += d[e].size * Ja[d[e].type]);
          for (let e in d) {
            let t = d[e],
              n = t.size;
            t.stride === void 0 &&
              (t.stride = f[t.buffer] === n * Ja[t.type] ? 0 : f[t.buffer]),
              t.start === void 0 &&
                ((t.start = p[t.buffer]), (p[t.buffer] += n * Ja[t.type]));
          }
          (l = r.createVertexArray()), r.bindVertexArray(l);
          for (let e = 0; e < u.length; e++) {
            let t = u[e];
            a.bind(t), n && t._glBuffers[i].refCount++;
          }
          return (
            this.activateVao(e, o),
            (c[o.id] = l),
            (c[s] = l),
            r.bindVertexArray(null),
            a.unbind(C.ARRAY_BUFFER),
            l
          );
        }
        disposeGeometry(e, t) {
          if (!this.managedGeometries[e.id]) return;
          delete this.managedGeometries[e.id];
          let n = e.glVertexArrayObjects[this.CONTEXT_UID],
            r = this.gl,
            i = e.buffers,
            a = this.renderer?.buffer;
          if ((e.disposeRunner.remove(this), n)) {
            if (a)
              for (let e = 0; e < i.length; e++) {
                let n = i[e]._glBuffers[this.CONTEXT_UID];
                n &&
                  (n.refCount--, n.refCount === 0 && !t && a.dispose(i[e], t));
              }
            if (!t) {
              for (let e in n)
                if (e[0] === `g`) {
                  let t = n[e];
                  this._activeVao === t && this.unbind(),
                    r.deleteVertexArray(t);
                }
            }
            delete e.glVertexArrayObjects[this.CONTEXT_UID];
          }
        }
        disposeAll(e) {
          let t = Object.keys(this.managedGeometries);
          for (let n = 0; n < t.length; n++)
            this.disposeGeometry(this.managedGeometries[t[n]], e);
        }
        activateVao(e, t) {
          let n = this.gl,
            r = this.CONTEXT_UID,
            i = this.renderer.buffer,
            a = e.buffers,
            o = e.attributes;
          e.indexBuffer && i.bind(e.indexBuffer);
          let s = null;
          for (let e in o) {
            let c = o[e],
              l = a[c.buffer],
              u = l._glBuffers[r];
            if (t.attributeData[e]) {
              s !== u && (i.bind(l), (s = u));
              let r = t.attributeData[e].location;
              if (
                (n.enableVertexAttribArray(r),
                n.vertexAttribPointer(
                  r,
                  c.size,
                  c.type || n.FLOAT,
                  c.normalized,
                  c.stride,
                  c.start
                ),
                c.instance)
              )
                if (this.hasInstance) n.vertexAttribDivisor(r, c.divisor);
                else
                  throw Error(
                    `geometry error, GPU Instancing is not supported on this device`
                  );
            }
          }
        }
        draw(e, t, n, r) {
          let { gl: i } = this,
            a = this._activeGeometry;
          if (a.indexBuffer) {
            let o = a.indexBuffer.data.BYTES_PER_ELEMENT,
              s = o === 2 ? i.UNSIGNED_SHORT : i.UNSIGNED_INT;
            o === 2 || (o === 4 && this.canUseUInt32ElementIndex)
              ? a.instanced
                ? i.drawElementsInstanced(
                    e,
                    t || a.indexBuffer.data.length,
                    s,
                    (n || 0) * o,
                    r || 1
                  )
                : i.drawElements(
                    e,
                    t || a.indexBuffer.data.length,
                    s,
                    (n || 0) * o
                  )
              : console.warn(`unsupported index buffer type: uint32`);
          } else
            a.instanced
              ? i.drawArraysInstanced(e, n, t || a.getSize(), r || 1)
              : i.drawArrays(e, n, t || a.getSize());
          return this;
        }
        unbind() {
          this.gl.bindVertexArray(null),
            (this._activeVao = null),
            (this._activeGeometry = null);
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (Ya.extension = { type: z.RendererSystem, name: `geometry` }),
      B.add(Ya);
  }))();
}
var Za, Qa;
function $a() {
  return ($a = t(() => {
    Y(),
      (Za = new q()),
      (Qa = class {
        constructor(e, t) {
          (this._texture = e),
            (this.mapCoord = new q()),
            (this.uClampFrame = new Float32Array(4)),
            (this.uClampOffset = new Float32Array(2)),
            (this._textureID = -1),
            (this._updateID = 0),
            (this.clampOffset = 0),
            (this.clampMargin = t === void 0 ? 0.5 : t),
            (this.isSimple = !1);
        }
        get texture() {
          return this._texture;
        }
        set texture(e) {
          (this._texture = e), (this._textureID = -1);
        }
        multiplyUvs(e, t) {
          t === void 0 && (t = e);
          let n = this.mapCoord;
          for (let r = 0; r < e.length; r += 2) {
            let i = e[r],
              a = e[r + 1];
            (t[r] = i * n.a + a * n.c + n.tx),
              (t[r + 1] = i * n.b + a * n.d + n.ty);
          }
          return t;
        }
        update(e) {
          let t = this._texture;
          if (!t || !t.valid || (!e && this._textureID === t._updateID))
            return !1;
          (this._textureID = t._updateID), this._updateID++;
          let n = t._uvs;
          this.mapCoord.set(
            n.x1 - n.x0,
            n.y1 - n.y0,
            n.x3 - n.x0,
            n.y3 - n.y0,
            n.x0,
            n.y0
          );
          let r = t.orig,
            i = t.trim;
          i &&
            (Za.set(
              r.width / i.width,
              0,
              0,
              r.height / i.height,
              -i.x / i.width,
              -i.y / i.height
            ),
            this.mapCoord.append(Za));
          let a = t.baseTexture,
            o = this.uClampFrame,
            s = this.clampMargin / a.resolution,
            c = this.clampOffset;
          return (
            (o[0] = (t._frame.x + s + c) / a.width),
            (o[1] = (t._frame.y + s + c) / a.height),
            (o[2] = (t._frame.x + t._frame.width - s + c) / a.width),
            (o[3] = (t._frame.y + t._frame.height - s + c) / a.height),
            (this.uClampOffset[0] = c / a.realWidth),
            (this.uClampOffset[1] = c / a.realHeight),
            (this.isSimple =
              t._frame.width === a.width &&
              t._frame.height === a.height &&
              t.rotate === 0),
            !0
          );
        }
      });
  }))();
}
function eo() {
  return (eo = t(() => {}))();
}
function to() {
  return (to = t(() => {}))();
}
var no;
function ro() {
  return (ro = t(() => {
    Y(),
      $a(),
      oa(),
      eo(),
      to(),
      (no = class extends aa {
        constructor(e, t, n) {
          let r = null;
          typeof e != `string` &&
            t === void 0 &&
            n === void 0 &&
            ((r = e), (e = void 0), (t = void 0), (n = void 0)),
            super(
              e ||
                `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;
uniform mat3 otherMatrix;

varying vec2 vMaskCoord;
varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = aTextureCoord;
    vMaskCoord = ( otherMatrix * vec3( aTextureCoord, 1.0)  ).xy;
}
`,
              t ||
                `varying vec2 vMaskCoord;
varying vec2 vTextureCoord;

uniform sampler2D uSampler;
uniform sampler2D mask;
uniform float alpha;
uniform float npmAlpha;
uniform vec4 maskClamp;

void main(void)
{
    float clip = step(3.5,
        step(maskClamp.x, vMaskCoord.x) +
        step(maskClamp.y, vMaskCoord.y) +
        step(vMaskCoord.x, maskClamp.z) +
        step(vMaskCoord.y, maskClamp.w));

    vec4 original = texture2D(uSampler, vTextureCoord);
    vec4 masky = texture2D(mask, vMaskCoord);
    float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);

    original *= (alphaMul * masky.r * alpha * clip);

    gl_FragColor = original;
}
`,
              n
            ),
            (this.maskSprite = r),
            (this.maskMatrix = new q());
        }
        get maskSprite() {
          return this._maskSprite;
        }
        set maskSprite(e) {
          (this._maskSprite = e),
            this._maskSprite && (this._maskSprite.renderable = !1);
        }
        apply(e, t, n, r) {
          let i = this._maskSprite,
            a = i._texture;
          a.valid &&
            ((a.uvMatrix ||= new Qa(a, 0)),
            a.uvMatrix.update(),
            (this.uniforms.npmAlpha = +!a.baseTexture.alphaMode),
            (this.uniforms.mask = a),
            (this.uniforms.otherMatrix = e
              .calculateSpriteMatrix(this.maskMatrix, i)
              .prepend(a.uvMatrix.mapCoord)),
            (this.uniforms.alpha = i.worldAlpha),
            (this.uniforms.maskClamp = a.uvMatrix.uClampFrame),
            e.applyFilter(this, t, n, r));
        }
      });
  }))();
}
var io;
function ao() {
  return (ao = t(() => {
    w(),
      oa(),
      (io = class {
        constructor(e = null) {
          (this.type = x.NONE),
            (this.autoDetect = !0),
            (this.maskObject = e || null),
            (this.pooled = !1),
            (this.isMaskData = !0),
            (this.resolution = null),
            (this.multisample = aa.defaultMultisample),
            (this.enabled = !0),
            (this.colorMask = 15),
            (this._filters = null),
            (this._stencilCounter = 0),
            (this._scissorCounter = 0),
            (this._scissorRect = null),
            (this._scissorRectLocal = null),
            (this._colorMask = 15),
            (this._target = null);
        }
        get filter() {
          return this._filters ? this._filters[0] : null;
        }
        set filter(e) {
          e
            ? this._filters
              ? (this._filters[0] = e)
              : (this._filters = [e])
            : (this._filters = null);
        }
        reset() {
          this.pooled &&
            ((this.maskObject = null),
            (this.type = x.NONE),
            (this.autoDetect = !0)),
            (this._target = null),
            (this._scissorRectLocal = null);
        }
        copyCountersOrReset(e) {
          e
            ? ((this._stencilCounter = e._stencilCounter),
              (this._scissorCounter = e._scissorCounter),
              (this._scissorRect = e._scissorRect))
            : ((this._stencilCounter = 0),
              (this._scissorCounter = 0),
              (this._scissorRect = null));
        }
      });
  }))();
}
var oo;
function so() {
  return (so = t(() => {
    w(),
      V(),
      ro(),
      ao(),
      (oo = class {
        constructor(e) {
          (this.renderer = e),
            (this.enableScissor = !0),
            (this.alphaMaskPool = []),
            (this.maskDataPool = []),
            (this.maskStack = []),
            (this.alphaMaskIndex = 0);
        }
        setMaskStack(e) {
          (this.maskStack = e),
            this.renderer.scissor.setMaskStack(e),
            this.renderer.stencil.setMaskStack(e);
        }
        push(e, t) {
          let n = t;
          if (!n.isMaskData) {
            let e = this.maskDataPool.pop() || new io();
            (e.pooled = !0), (e.maskObject = t), (n = e);
          }
          let r =
            this.maskStack.length === 0
              ? null
              : this.maskStack[this.maskStack.length - 1];
          if (
            (n.copyCountersOrReset(r),
            (n._colorMask = r ? r._colorMask : 15),
            n.autoDetect && this.detect(n),
            (n._target = e),
            n.type !== x.SPRITE && this.maskStack.push(n),
            n.enabled)
          )
            switch (n.type) {
              case x.SCISSOR:
                this.renderer.scissor.push(n);
                break;
              case x.STENCIL:
                this.renderer.stencil.push(n);
                break;
              case x.SPRITE:
                n.copyCountersOrReset(null), this.pushSpriteMask(n);
                break;
              case x.COLOR:
                this.pushColorMask(n);
            }
          n.type === x.SPRITE && this.maskStack.push(n);
        }
        pop(e) {
          let t = this.maskStack.pop();
          if (!(!t || t._target !== e)) {
            if (t.enabled)
              switch (t.type) {
                case x.SCISSOR:
                  this.renderer.scissor.pop(t);
                  break;
                case x.STENCIL:
                  this.renderer.stencil.pop(t.maskObject);
                  break;
                case x.SPRITE:
                  this.popSpriteMask(t);
                  break;
                case x.COLOR:
                  this.popColorMask(t);
              }
            if (
              (t.reset(),
              t.pooled && this.maskDataPool.push(t),
              this.maskStack.length !== 0)
            ) {
              let e = this.maskStack[this.maskStack.length - 1];
              e.type === x.SPRITE &&
                e._filters &&
                (e._filters[0].maskSprite = e.maskObject);
            }
          }
        }
        detect(e) {
          let t = e.maskObject;
          e.type = t
            ? t.isSprite
              ? x.SPRITE
              : this.enableScissor && this.renderer.scissor.testScissor(e)
              ? x.SCISSOR
              : x.STENCIL
            : x.COLOR;
        }
        pushSpriteMask(e) {
          let { maskObject: t } = e,
            n = e._target,
            r = e._filters;
          r ||
            ((r = this.alphaMaskPool[this.alphaMaskIndex]),
            (r ||= this.alphaMaskPool[this.alphaMaskIndex] = [new no()]));
          let i = this.renderer,
            a = i.renderTexture,
            o,
            s;
          if (a.current) {
            let t = a.current;
            (o = e.resolution || t.resolution),
              (s = e.multisample ?? t.multisample);
          } else
            (o = e.resolution || i.resolution),
              (s = e.multisample ?? i.multisample);
          (r[0].resolution = o), (r[0].multisample = s), (r[0].maskSprite = t);
          let c = n.filterArea;
          (n.filterArea = t.getBounds(!0)),
            i.filter.push(n, r),
            (n.filterArea = c),
            e._filters || this.alphaMaskIndex++;
        }
        popSpriteMask(e) {
          this.renderer.filter.pop(),
            e._filters
              ? (e._filters[0].maskSprite = null)
              : (this.alphaMaskIndex--,
                (this.alphaMaskPool[this.alphaMaskIndex][0].maskSprite = null));
        }
        pushColorMask(e) {
          let t = e._colorMask,
            n = (e._colorMask = t & e.colorMask);
          n !== t &&
            this.renderer.gl.colorMask(
              !!(n & 1),
              !!(n & 2),
              !!(n & 4),
              !!(n & 8)
            );
        }
        popColorMask(e) {
          let t = e._colorMask,
            n =
              this.maskStack.length > 0
                ? this.maskStack[this.maskStack.length - 1]._colorMask
                : 15;
          n !== t &&
            this.renderer.gl.colorMask(
              !!(n & 1),
              !!(n & 2),
              !!(n & 4),
              !!(n & 8)
            );
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (oo.extension = { type: z.RendererSystem, name: `mask` }),
      B.add(oo);
  }))();
}
var co;
function lo() {
  return (lo = t(() => {
    co = class {
      constructor(e) {
        (this.renderer = e), (this.maskStack = []), (this.glConst = 0);
      }
      getStackLength() {
        return this.maskStack.length;
      }
      setMaskStack(e) {
        let { gl: t } = this.renderer,
          n = this.getStackLength();
        this.maskStack = e;
        let r = this.getStackLength();
        r !== n &&
          (r === 0
            ? t.disable(this.glConst)
            : (t.enable(this.glConst), this._useCurrent()));
      }
      _useCurrent() {}
      destroy() {
        (this.renderer = null), (this.maskStack = null);
      }
    };
  }))();
}
var uo, fo, po, mo;
function ho() {
  return (ho = t(() => {
    V(),
      Y(),
      N(),
      lo(),
      (uo = new q()),
      (fo = []),
      (po = class extends co {
        constructor(e) {
          super(e),
            (this.glConst = D.ADAPTER.getWebGLRenderingContext().SCISSOR_TEST);
        }
        getStackLength() {
          let e = this.maskStack[this.maskStack.length - 1];
          return e ? e._scissorCounter : 0;
        }
        calcScissorRect(e) {
          if (e._scissorRectLocal) return;
          let t = e._scissorRect,
            { maskObject: n } = e,
            { renderer: r } = this,
            i = r.renderTexture,
            a = n.getBounds(!0, fo.pop() ?? new K());
          this.roundFrameToPixels(
            a,
            i.current ? i.current.resolution : r.resolution,
            i.sourceFrame,
            i.destinationFrame,
            r.projection.transform
          ),
            t && a.fit(t),
            (e._scissorRectLocal = a);
        }
        static isMatrixRotated(e) {
          if (!e) return !1;
          let { a: t, b: n, c: r, d: i } = e;
          return (
            (Math.abs(n) > 1e-4 || Math.abs(r) > 1e-4) &&
            (Math.abs(t) > 1e-4 || Math.abs(i) > 1e-4)
          );
        }
        testScissor(e) {
          let { maskObject: t } = e;
          if (
            !t.isFastRect ||
            !t.isFastRect() ||
            po.isMatrixRotated(t.worldTransform) ||
            po.isMatrixRotated(this.renderer.projection.transform)
          )
            return !1;
          this.calcScissorRect(e);
          let n = e._scissorRectLocal;
          return n.width > 0 && n.height > 0;
        }
        roundFrameToPixels(e, t, n, r, i) {
          po.isMatrixRotated(i) ||
            ((i = i ? uo.copyFrom(i) : uo.identity()),
            i
              .translate(-n.x, -n.y)
              .scale(r.width / n.width, r.height / n.height)
              .translate(r.x, r.y),
            this.renderer.filter.transformAABB(i, e),
            e.fit(r),
            (e.x = Math.round(e.x * t)),
            (e.y = Math.round(e.y * t)),
            (e.width = Math.round(e.width * t)),
            (e.height = Math.round(e.height * t)));
        }
        push(e) {
          e._scissorRectLocal || this.calcScissorRect(e);
          let { gl: t } = this.renderer;
          e._scissorRect || t.enable(t.SCISSOR_TEST),
            e._scissorCounter++,
            (e._scissorRect = e._scissorRectLocal),
            this._useCurrent();
        }
        pop(e) {
          let { gl: t } = this.renderer;
          e && fo.push(e._scissorRectLocal),
            this.getStackLength() > 0
              ? this._useCurrent()
              : t.disable(t.SCISSOR_TEST);
        }
        _useCurrent() {
          let e = this.maskStack[this.maskStack.length - 1]._scissorRect,
            t;
          (t = this.renderer.renderTexture.current
            ? e.y
            : this.renderer.height - e.height - e.y),
            this.renderer.gl.scissor(e.x, t, e.width, e.height);
        }
      }),
      (mo = po),
      (mo.extension = { type: z.RendererSystem, name: `scissor` }),
      B.add(mo);
  }))();
}
var go;
function _o() {
  return (_o = t(() => {
    V(),
      N(),
      lo(),
      (go = class extends co {
        constructor(e) {
          super(e),
            (this.glConst = D.ADAPTER.getWebGLRenderingContext().STENCIL_TEST);
        }
        getStackLength() {
          let e = this.maskStack[this.maskStack.length - 1];
          return e ? e._stencilCounter : 0;
        }
        push(e) {
          let t = e.maskObject,
            { gl: n } = this.renderer,
            r = e._stencilCounter;
          r === 0 &&
            (this.renderer.framebuffer.forceStencil(),
            n.clearStencil(0),
            n.clear(n.STENCIL_BUFFER_BIT),
            n.enable(n.STENCIL_TEST)),
            e._stencilCounter++;
          let i = e._colorMask;
          i !== 0 && ((e._colorMask = 0), n.colorMask(!1, !1, !1, !1)),
            n.stencilFunc(n.EQUAL, r, 4294967295),
            n.stencilOp(n.KEEP, n.KEEP, n.INCR),
            (t.renderable = !0),
            t.render(this.renderer),
            this.renderer.batch.flush(),
            (t.renderable = !1),
            i !== 0 &&
              ((e._colorMask = i),
              n.colorMask(!!(i & 1), !!(i & 2), !!(i & 4), !!(i & 8))),
            this._useCurrent();
        }
        pop(e) {
          let t = this.renderer.gl;
          if (this.getStackLength() === 0) t.disable(t.STENCIL_TEST);
          else {
            let n =
                this.maskStack.length === 0
                  ? null
                  : this.maskStack[this.maskStack.length - 1],
              r = n ? n._colorMask : 15;
            r !== 0 && ((n._colorMask = 0), t.colorMask(!1, !1, !1, !1)),
              t.stencilOp(t.KEEP, t.KEEP, t.DECR),
              (e.renderable = !0),
              e.render(this.renderer),
              this.renderer.batch.flush(),
              (e.renderable = !1),
              r !== 0 &&
                ((n._colorMask = r),
                t.colorMask(!!(r & 1), !!(r & 2), !!(r & 4), !!(r & 8))),
              this._useCurrent();
          }
        }
        _useCurrent() {
          let e = this.renderer.gl;
          e.stencilFunc(e.EQUAL, this.getStackLength(), 4294967295),
            e.stencilOp(e.KEEP, e.KEEP, e.KEEP);
        }
      }),
      (go.extension = { type: z.RendererSystem, name: `stencil` }),
      B.add(go);
  }))();
}
var vo;
function yo() {
  return (yo = t(() => {
    V(),
      R(),
      (vo = class {
        constructor(e) {
          (this.renderer = e),
            (this.plugins = {}),
            Object.defineProperties(this.plugins, {
              extract: {
                enumerable: !1,
                get() {
                  return (
                    P(
                      `7.0.0`,
                      `renderer.plugins.extract has moved to renderer.extract`
                    ),
                    e.extract
                  );
                },
              },
              prepare: {
                enumerable: !1,
                get() {
                  return (
                    P(
                      `7.0.0`,
                      `renderer.plugins.prepare has moved to renderer.prepare`
                    ),
                    e.prepare
                  );
                },
              },
              interaction: {
                enumerable: !1,
                get() {
                  return (
                    P(
                      `7.0.0`,
                      `renderer.plugins.interaction has been deprecated, use renderer.events`
                    ),
                    e.events
                  );
                },
              },
            });
        }
        init() {
          let e = this.rendererPlugins;
          for (let t in e) this.plugins[t] = new e[t](this.renderer);
        }
        destroy() {
          for (let e in this.plugins)
            this.plugins[e].destroy(), (this.plugins[e] = null);
        }
      }),
      (vo.extension = {
        type: [z.RendererSystem, z.CanvasRendererSystem],
        name: `_plugin`,
      }),
      B.add(vo);
  }))();
}
var bo;
function xo() {
  return (xo = t(() => {
    V(),
      Y(),
      (bo = class {
        constructor(e) {
          (this.renderer = e),
            (this.destinationFrame = null),
            (this.sourceFrame = null),
            (this.defaultFrame = null),
            (this.projectionMatrix = new q()),
            (this.transform = null);
        }
        update(e, t, n, r) {
          (this.destinationFrame =
            e || this.destinationFrame || this.defaultFrame),
            (this.sourceFrame = t || this.sourceFrame || e),
            this.calculateProjection(
              this.destinationFrame,
              this.sourceFrame,
              n,
              r
            ),
            this.transform && this.projectionMatrix.append(this.transform);
          let i = this.renderer;
          (i.globalUniforms.uniforms.projectionMatrix = this.projectionMatrix),
            i.globalUniforms.update(),
            i.shader.shader &&
              i.shader.syncUniformGroup(i.shader.shader.uniforms.globals);
        }
        calculateProjection(e, t, n, r) {
          let i = this.projectionMatrix,
            a = r ? -1 : 1;
          i.identity(),
            (i.a = (1 / t.width) * 2),
            (i.d = a * ((1 / t.height) * 2)),
            (i.tx = -1 - t.x * i.a),
            (i.ty = -a - t.y * i.d);
        }
        setTransform(e) {}
        destroy() {
          this.renderer = null;
        }
      }),
      (bo.extension = { type: z.RendererSystem, name: `projection` }),
      B.add(bo);
  }))();
}
var So, Co;
function wo() {
  return (wo = t(() => {
    V(),
      Y(),
      Aa(),
      (So = new Wr()),
      (Co = class {
        constructor(e) {
          (this.renderer = e), (this._tempMatrix = new q());
        }
        generateTexture(e, t) {
          let { region: n, ...r } = t || {},
            i = n || e.getLocalBounds(null, !0);
          i.width === 0 && (i.width = 1), i.height === 0 && (i.height = 1);
          let a = ka.create({ width: i.width, height: i.height, ...r });
          (this._tempMatrix.tx = -i.x), (this._tempMatrix.ty = -i.y);
          let o = e.transform;
          return (
            (e.transform = So),
            this.renderer.render(e, {
              renderTexture: a,
              transform: this._tempMatrix,
              skipUpdateTransform: !!e.parent,
              blit: !0,
            }),
            (e.transform = o),
            a
          );
        }
        destroy() {}
      }),
      (Co.extension = {
        type: [z.RendererSystem, z.CanvasRendererSystem],
        name: `textureGenerator`,
      }),
      B.add(Co);
  }))();
}
var To, Eo, Do;
function Oo() {
  return (Oo = t(() => {
    Ot(),
      V(),
      Y(),
      (To = new K()),
      (Eo = new K()),
      (Do = class {
        constructor(e) {
          (this.renderer = e),
            (this.defaultMaskStack = []),
            (this.current = null),
            (this.sourceFrame = new K()),
            (this.destinationFrame = new K()),
            (this.viewportFrame = new K());
        }
        bind(e = null, t, n) {
          let r = this.renderer;
          this.current = e;
          let i, a, o;
          e
            ? ((i = e.baseTexture),
              (o = i.resolution),
              (t ||=
                ((To.width = e.frame.width), (To.height = e.frame.height), To)),
              (n ||=
                ((Eo.x = e.frame.x),
                (Eo.y = e.frame.y),
                (Eo.width = t.width),
                (Eo.height = t.height),
                Eo)),
              (a = i.framebuffer))
            : ((o = r.resolution),
              (t ||=
                ((To.width = r._view.screen.width),
                (To.height = r._view.screen.height),
                To)),
              n || ((n = To), (n.width = t.width), (n.height = t.height)));
          let s = this.viewportFrame;
          (s.x = n.x * o),
            (s.y = n.y * o),
            (s.width = n.width * o),
            (s.height = n.height * o),
            e || (s.y = r.view.height - (s.y + s.height)),
            s.ceil(),
            this.renderer.framebuffer.bind(a, s),
            this.renderer.projection.update(n, t, o, !a),
            e
              ? this.renderer.mask.setMaskStack(i.maskStack)
              : this.renderer.mask.setMaskStack(this.defaultMaskStack),
            this.sourceFrame.copyFrom(t),
            this.destinationFrame.copyFrom(n);
        }
        clear(e, t) {
          let n = this.current
              ? this.current.baseTexture.clear
              : this.renderer.background.backgroundColor,
            r = e ? I.shared.setValue(e) : n,
            i = this.destinationFrame,
            a = this.current
              ? this.current.baseTexture
              : this.renderer._view.screen,
            o = i.width !== a.width || i.height !== a.height;
          if (o) {
            let { x: e, y: t, width: n, height: r } = this.viewportFrame;
            (e = Math.round(e)),
              (t = Math.round(t)),
              (n = Math.round(n)),
              (r = Math.round(r)),
              this.renderer.gl.enable(this.renderer.gl.SCISSOR_TEST),
              this.renderer.gl.scissor(e, t, n, r);
          }
          this.renderer.framebuffer.clear(r.red, r.green, r.blue, r.alpha, t),
            o && this.renderer.scissor.pop();
        }
        resize() {
          this.bind(null);
        }
        reset() {
          this.bind(null);
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (Do.extension = { type: z.RendererSystem, name: `renderTexture` }),
      B.add(Do);
  }))();
}
var ko;
function Ao() {
  return (Ao = t(() => {
    ko = class {
      constructor(e, t) {
        (this.program = e),
          (this.uniformData = t),
          (this.uniformGroups = {}),
          (this.uniformDirtyGroups = {}),
          (this.uniformBufferBindings = {});
      }
      destroy() {
        (this.uniformData = null),
          (this.uniformGroups = null),
          (this.uniformDirtyGroups = null),
          (this.uniformBufferBindings = null),
          (this.program = null);
      }
    };
  }))();
}
function jo(e, t) {
  let n = {},
    r = t.getProgramParameter(e, t.ACTIVE_ATTRIBUTES);
  for (let i = 0; i < r; i++) {
    let r = t.getActiveAttrib(e, i);
    if (r.name.startsWith(`gl_`)) continue;
    let a = _i(t, r.type),
      o = {
        type: a,
        name: r.name,
        size: mi(a),
        location: t.getAttribLocation(e, r.name),
      };
    n[r.name] = o;
  }
  return n;
}
function Mo() {
  return (Mo = t(() => {
    gi(), bi();
  }))();
}
function No(e, t) {
  let n = {},
    r = t.getProgramParameter(e, t.ACTIVE_UNIFORMS);
  for (let i = 0; i < r; i++) {
    let r = t.getActiveUniform(e, i),
      a = r.name.replace(/\[.*?\]$/, ``),
      o = !!r.name.match(/\[.*?\]$/),
      s = _i(t, r.type);
    n[a] = {
      name: a,
      index: i,
      type: s,
      size: r.size,
      isArray: o,
      value: Qr(s, r.size),
    };
  }
  return n;
}
function Po() {
  return (Po = t(() => {
    bi();
  }))();
}
function Fo(e, t) {
  let n = Xr(e, e.VERTEX_SHADER, t.vertexSrc),
    r = Xr(e, e.FRAGMENT_SHADER, t.fragmentSrc),
    i = e.createProgram();
  e.attachShader(i, n), e.attachShader(i, r);
  let a = t.extra?.transformFeedbackVaryings;
  if (
    (a &&
      (typeof e.transformFeedbackVaryings == `function`
        ? e.transformFeedbackVaryings(
            i,
            a.names,
            a.bufferMode === `separate`
              ? e.SEPARATE_ATTRIBS
              : e.INTERLEAVED_ATTRIBS
          )
        : console.warn(
            `TransformFeedback is not supported but TransformFeedbackVaryings are given.`
          )),
    e.linkProgram(i),
    e.getProgramParameter(i, e.LINK_STATUS) || pi(e, i, n, r),
    (t.attributeData = jo(i, e)),
    (t.uniformData = No(i, e)),
    !/^[ \t]*#[ \t]*version[ \t]+300[ \t]+es[ \t]*$/m.test(t.vertexSrc))
  ) {
    let n = Object.keys(t.attributeData);
    n.sort((e, t) => (e > t ? 1 : -1));
    for (let r = 0; r < n.length; r++)
      (t.attributeData[n[r]].location = r), e.bindAttribLocation(i, r, n[r]);
    e.linkProgram(i);
  }
  e.deleteShader(n), e.deleteShader(r);
  let o = {};
  for (let n in t.uniformData) {
    let r = t.uniformData[n];
    o[n] = { location: e.getUniformLocation(i, n), value: Qr(r.type, r.size) };
  }
  return new ko(i, o);
}
function Io() {
  return (Io = t(() => {
    Ao(), Mo(), Po();
  }))();
}
function Lo(e, t, n, r, i) {
  n.buffer.update(i);
}
function Ro(e) {
  let t = e.map((e) => ({ data: e, offset: 0, dataLen: 0, dirty: 0 })),
    n = 0,
    r = 0,
    i = 0;
  for (let e = 0; e < t.length; e++) {
    let a = t[e];
    if (
      ((n = Ho[a.data.type]),
      a.data.size > 1 && (n = Math.max(n, 16) * a.data.size),
      (a.dataLen = n),
      r % n !== 0 && r < 16)
    ) {
      let e = (r % n) % 16;
      (r += e), (i += e);
    }
    r + n > 16
      ? ((i = Math.ceil(i / 16) * 16), (a.offset = i), (i += n), (r = n))
      : ((a.offset = i), (r += n), (i += n));
  }
  return (i = Math.ceil(i / 16) * 16), { uboElements: t, size: i };
}
function zo(e, t) {
  let n = [];
  for (let r in e) t[r] && n.push(t[r]);
  return n.sort((e, t) => e.index - t.index), n;
}
function Bo(e, t) {
  if (!e.autoManage) return { size: 0, syncFunc: Lo };
  let { uboElements: n, size: r } = Ro(zo(e.uniforms, t)),
    i = [
      `
    var v = null;
    var v2 = null;
    var cv = null;
    var t = 0;
    var gl = renderer.gl
    var index = 0;
    var data = buffer.data;
    `,
    ];
  for (let t = 0; t < n.length; t++) {
    let r = n[t],
      a = e.uniforms[r.data.name],
      o = r.data.name,
      s = !1;
    for (let e = 0; e < $r.length; e++) {
      let t = $r[e];
      if (t.codeUbo && t.test(r.data, a)) {
        i.push(`offset = ${r.offset / 4};`, $r[e].codeUbo(r.data.name, a)),
          (s = !0);
        break;
      }
    }
    if (!s)
      if (r.data.size > 1) {
        let e = mi(r.data.type),
          t = Math.max(Ho[r.data.type] / 16, 1),
          n = e / t,
          a = (4 - (n % 4)) % 4;
        i.push(`
                cv = ud.${o}.value;
                v = uv.${o};
                offset = ${r.offset / 4};

                t = 0;

                for(var i=0; i < ${r.data.size * t}; i++)
                {
                    for(var j = 0; j < ${n}; j++)
                    {
                        data[offset++] = v[t++];
                    }
                    offset += ${a};
                }

                `);
      } else {
        let e = Vo[r.data.type];
        i.push(`
                cv = ud.${o}.value;
                v = uv.${o};
                offset = ${r.offset / 4};
                ${e};
                `);
      }
  }
  return (
    i.push(`
       renderer.buffer.update(buffer);
    `),
    {
      size: r,
      syncFunc: Function(
        `ud`,
        `uv`,
        `renderer`,
        `syncData`,
        `buffer`,
        i.join(`
`)
      ),
    }
  );
}
var Vo, Ho;
function Uo() {
  return (Uo = t(() => {
    Ei(),
      ei(),
      gi(),
      (Vo = {
        float: `
        data[offset] = v;
    `,
        vec2: `
        data[offset] = v[0];
        data[offset+1] = v[1];
    `,
        vec3: `
        data[offset] = v[0];
        data[offset+1] = v[1];
        data[offset+2] = v[2];

    `,
        vec4: `
        data[offset] = v[0];
        data[offset+1] = v[1];
        data[offset+2] = v[2];
        data[offset+3] = v[3];
    `,
        mat2: `
        data[offset] = v[0];
        data[offset+1] = v[1];

        data[offset+4] = v[2];
        data[offset+5] = v[3];
    `,
        mat3: `
        data[offset] = v[0];
        data[offset+1] = v[1];
        data[offset+2] = v[2];

        data[offset + 4] = v[3];
        data[offset + 5] = v[4];
        data[offset + 6] = v[5];

        data[offset + 8] = v[6];
        data[offset + 9] = v[7];
        data[offset + 10] = v[8];
    `,
        mat4: `
        for(var i = 0; i < 16; i++)
        {
            data[offset + i] = v[i];
        }
    `,
      }),
      (Ho = {
        float: 4,
        vec2: 8,
        vec3: 12,
        vec4: 16,
        int: 4,
        ivec2: 8,
        ivec3: 12,
        ivec4: 16,
        uint: 4,
        uvec2: 8,
        uvec3: 12,
        uvec4: 16,
        bool: 4,
        bvec2: 8,
        bvec3: 12,
        bvec4: 16,
        mat2: 32,
        mat3: 48,
        mat4: 64,
      });
  }))();
}
var Wo, Go, Ko;
function qo() {
  return (qo = t(() => {
    V(),
      Ei(),
      Io(),
      Uo(),
      Ti(),
      ii(),
      (Wo = 0),
      (Go = { textureCount: 0, uboCount: 0 }),
      (Ko = class {
        constructor(e) {
          (this.destroyed = !1),
            (this.renderer = e),
            this.systemCheck(),
            (this.gl = null),
            (this.shader = null),
            (this.program = null),
            (this.cache = {}),
            (this._uboCache = {}),
            (this.id = Wo++);
        }
        systemCheck() {
          if (!Ci())
            throw Error(
              `Current environment does not allow unsafe-eval, please use @pixi/unsafe-eval module to enable support.`
            );
        }
        contextChange(e) {
          (this.gl = e), this.reset();
        }
        bind(e, t) {
          e.disposeRunner.add(this),
            (e.uniforms.globals = this.renderer.globalUniforms);
          let n = e.program,
            r =
              n.glPrograms[this.renderer.CONTEXT_UID] ||
              this.generateProgram(e);
          return (
            (this.shader = e),
            this.program !== n &&
              ((this.program = n), this.gl.useProgram(r.program)),
            t ||
              ((Go.textureCount = 0),
              (Go.uboCount = 0),
              this.syncUniformGroup(e.uniformGroup, Go)),
            r
          );
        }
        setUniforms(e) {
          let t = this.shader.program,
            n = t.glPrograms[this.renderer.CONTEXT_UID];
          t.syncUniforms(n.uniformData, e, this.renderer);
        }
        syncUniformGroup(e, t) {
          let n = this.getGlProgram();
          (!e.static || e.dirtyId !== n.uniformDirtyGroups[e.id]) &&
            ((n.uniformDirtyGroups[e.id] = e.dirtyId),
            this.syncUniforms(e, n, t));
        }
        syncUniforms(e, t, n) {
          (e.syncUniforms[this.shader.program.id] || this.createSyncGroups(e))(
            t.uniformData,
            e.uniforms,
            this.renderer,
            n
          );
        }
        createSyncGroups(e) {
          let t = this.getSignature(e, this.shader.program.uniformData, `u`);
          return (
            this.cache[t] ||
              (this.cache[t] = ti(e, this.shader.program.uniformData)),
            (e.syncUniforms[this.shader.program.id] = this.cache[t]),
            e.syncUniforms[this.shader.program.id]
          );
        }
        syncUniformBufferGroup(e, t) {
          let n = this.getGlProgram();
          if (!e.static || e.dirtyId !== 0 || !n.uniformGroups[e.id]) {
            e.dirtyId = 0;
            let r =
              n.uniformGroups[e.id] || this.createSyncBufferGroup(e, n, t);
            e.buffer.update(),
              r(n.uniformData, e.uniforms, this.renderer, Go, e.buffer);
          }
          this.renderer.buffer.bindBufferBase(
            e.buffer,
            n.uniformBufferBindings[t]
          );
        }
        createSyncBufferGroup(e, t, n) {
          let { gl: r } = this.renderer;
          this.renderer.buffer.bind(e.buffer);
          let i = this.gl.getUniformBlockIndex(t.program, n);
          (t.uniformBufferBindings[n] = this.shader.uniformBindCount),
            r.uniformBlockBinding(t.program, i, this.shader.uniformBindCount),
            this.shader.uniformBindCount++;
          let a = this.getSignature(e, this.shader.program.uniformData, `ubo`),
            o = this._uboCache[a];
          if (
            ((o ||= this._uboCache[a] = Bo(e, this.shader.program.uniformData)),
            e.autoManage)
          ) {
            let t = new Float32Array(o.size / 4);
            e.buffer.update(t);
          }
          return (t.uniformGroups[e.id] = o.syncFunc), t.uniformGroups[e.id];
        }
        getSignature(e, t, n) {
          let r = e.uniforms,
            i = [`${n}-`];
          for (let e in r) i.push(e), t[e] && i.push(t[e].type);
          return i.join(`-`);
        }
        getGlProgram() {
          return this.shader
            ? this.shader.program.glPrograms[this.renderer.CONTEXT_UID]
            : null;
        }
        generateProgram(e) {
          let t = this.gl,
            n = e.program,
            r = Fo(t, n);
          return (n.glPrograms[this.renderer.CONTEXT_UID] = r), r;
        }
        reset() {
          (this.program = null), (this.shader = null);
        }
        disposeShader(e) {
          this.shader === e && (this.shader = null);
        }
        destroy() {
          (this.renderer = null), (this.destroyed = !0);
        }
      }),
      (Ko.extension = { type: z.RendererSystem, name: `shader` }),
      B.add(Ko);
  }))();
}
var Jo;
function Yo() {
  return (Yo = t(() => {
    V(),
      (Jo = class {
        constructor(e) {
          this.renderer = e;
        }
        run(e) {
          let { renderer: t } = this;
          t.runners.init.emit(t.options),
            e.hello &&
              console.log(
                `PixiJS 7.2.3 - ${t.rendererLogId} - https://pixijs.com`
              ),
            t.resize(t.screen.width, t.screen.height);
        }
        destroy() {}
      }),
      (Jo.defaultOptions = { hello: !1 }),
      (Jo.extension = {
        type: [z.RendererSystem, z.CanvasRendererSystem],
        name: `startup`,
      }),
      B.add(Jo);
  }))();
}
function Xo(e, t = []) {
  return (
    (t[c.NORMAL] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.ADD] = [e.ONE, e.ONE]),
    (t[c.MULTIPLY] = [
      e.DST_COLOR,
      e.ONE_MINUS_SRC_ALPHA,
      e.ONE,
      e.ONE_MINUS_SRC_ALPHA,
    ]),
    (t[c.SCREEN] = [
      e.ONE,
      e.ONE_MINUS_SRC_COLOR,
      e.ONE,
      e.ONE_MINUS_SRC_ALPHA,
    ]),
    (t[c.OVERLAY] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.DARKEN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.LIGHTEN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.COLOR_DODGE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.COLOR_BURN] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.HARD_LIGHT] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.SOFT_LIGHT] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.DIFFERENCE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.EXCLUSION] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.HUE] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.SATURATION] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.COLOR] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.LUMINOSITY] = [e.ONE, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.NONE] = [0, 0]),
    (t[c.NORMAL_NPM] = [
      e.SRC_ALPHA,
      e.ONE_MINUS_SRC_ALPHA,
      e.ONE,
      e.ONE_MINUS_SRC_ALPHA,
    ]),
    (t[c.ADD_NPM] = [e.SRC_ALPHA, e.ONE, e.ONE, e.ONE]),
    (t[c.SCREEN_NPM] = [
      e.SRC_ALPHA,
      e.ONE_MINUS_SRC_COLOR,
      e.ONE,
      e.ONE_MINUS_SRC_ALPHA,
    ]),
    (t[c.SRC_IN] = [e.DST_ALPHA, e.ZERO]),
    (t[c.SRC_OUT] = [e.ONE_MINUS_DST_ALPHA, e.ZERO]),
    (t[c.SRC_ATOP] = [e.DST_ALPHA, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.DST_OVER] = [e.ONE_MINUS_DST_ALPHA, e.ONE]),
    (t[c.DST_IN] = [e.ZERO, e.SRC_ALPHA]),
    (t[c.DST_OUT] = [e.ZERO, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.DST_ATOP] = [e.ONE_MINUS_DST_ALPHA, e.SRC_ALPHA]),
    (t[c.XOR] = [e.ONE_MINUS_DST_ALPHA, e.ONE_MINUS_SRC_ALPHA]),
    (t[c.SUBTRACT] = [
      e.ONE,
      e.ONE,
      e.ONE,
      e.ONE,
      e.FUNC_REVERSE_SUBTRACT,
      e.FUNC_ADD,
    ]),
    t
  );
}
function Zo() {
  return (Zo = t(() => {
    w();
  }))();
}
var Qo, $o, es, ts, ns, rs, is, as;
function os() {
  return (os = t(() => {
    w(),
      V(),
      Bn(),
      Zo(),
      (Qo = 0),
      ($o = 1),
      (es = 2),
      (ts = 3),
      (ns = 4),
      (rs = 5),
      (is = class {
        constructor() {
          (this.gl = null),
            (this.stateId = 0),
            (this.polygonOffset = 0),
            (this.blendMode = c.NONE),
            (this._blendEq = !1),
            (this.map = []),
            (this.map[Qo] = this.setBlend),
            (this.map[$o] = this.setOffset),
            (this.map[es] = this.setCullFace),
            (this.map[ts] = this.setDepthTest),
            (this.map[ns] = this.setFrontFace),
            (this.map[rs] = this.setDepthMask),
            (this.checks = []),
            (this.defaultState = new zn()),
            (this.defaultState.blend = !0);
        }
        contextChange(e) {
          (this.gl = e),
            (this.blendModes = Xo(e)),
            this.set(this.defaultState),
            this.reset();
        }
        set(e) {
          if (((e ||= this.defaultState), this.stateId !== e.data)) {
            let t = this.stateId ^ e.data,
              n = 0;
            for (; t; )
              t & 1 && this.map[n].call(this, !!(e.data & (1 << n))),
                (t >>= 1),
                n++;
            this.stateId = e.data;
          }
          for (let t = 0; t < this.checks.length; t++) this.checks[t](this, e);
        }
        forceState(e) {
          e ||= this.defaultState;
          for (let t = 0; t < this.map.length; t++)
            this.map[t].call(this, !!(e.data & (1 << t)));
          for (let t = 0; t < this.checks.length; t++) this.checks[t](this, e);
          this.stateId = e.data;
        }
        setBlend(e) {
          this.updateCheck(is.checkBlendMode, e),
            this.gl[e ? `enable` : `disable`](this.gl.BLEND);
        }
        setOffset(e) {
          this.updateCheck(is.checkPolygonOffset, e),
            this.gl[e ? `enable` : `disable`](this.gl.POLYGON_OFFSET_FILL);
        }
        setDepthTest(e) {
          this.gl[e ? `enable` : `disable`](this.gl.DEPTH_TEST);
        }
        setDepthMask(e) {
          this.gl.depthMask(e);
        }
        setCullFace(e) {
          this.gl[e ? `enable` : `disable`](this.gl.CULL_FACE);
        }
        setFrontFace(e) {
          this.gl.frontFace(this.gl[e ? `CW` : `CCW`]);
        }
        setBlendMode(e) {
          if (e === this.blendMode) return;
          this.blendMode = e;
          let t = this.blendModes[e],
            n = this.gl;
          t.length === 2
            ? n.blendFunc(t[0], t[1])
            : n.blendFuncSeparate(t[0], t[1], t[2], t[3]),
            t.length === 6
              ? ((this._blendEq = !0), n.blendEquationSeparate(t[4], t[5]))
              : this._blendEq &&
                ((this._blendEq = !1),
                n.blendEquationSeparate(n.FUNC_ADD, n.FUNC_ADD));
        }
        setPolygonOffset(e, t) {
          this.gl.polygonOffset(e, t);
        }
        reset() {
          this.gl.pixelStorei(this.gl.UNPACK_FLIP_Y_WEBGL, !1),
            this.forceState(this.defaultState),
            (this._blendEq = !0),
            (this.blendMode = -1),
            this.setBlendMode(0);
        }
        updateCheck(e, t) {
          let n = this.checks.indexOf(e);
          t && n === -1
            ? this.checks.push(e)
            : !t && n !== -1 && this.checks.splice(n, 1);
        }
        static checkBlendMode(e, t) {
          e.setBlendMode(t.blendMode);
        }
        static checkPolygonOffset(e, t) {
          e.setPolygonOffset(1, t.polygonOffset);
        }
        destroy() {
          this.gl = null;
        }
      }),
      (as = is),
      (as.extension = { type: z.RendererSystem, name: `state` }),
      B.add(as);
  }))();
}
var ss;
function cs() {
  return (cs = t(() => {
    Kn(),
      R(),
      (ss = class extends kn.default {
        constructor() {
          super(...arguments), (this.runners = {}), (this._systemsHash = {});
        }
        setup(e) {
          this.addRunners(...e.runners);
          let t = (e.priority ?? []).filter((t) => e.systems[t]),
            n = [...t, ...Object.keys(e.systems).filter((e) => !t.includes(e))];
          for (let t of n) this.addSystem(e.systems[t], t);
        }
        addRunners(...e) {
          e.forEach((e) => {
            this.runners[e] = new Wn(e);
          });
        }
        addSystem(e, t) {
          let n = new e(this);
          if (this[t]) throw Error(`Whoops! The name "${t}" is already in use`);
          (this[t] = n), (this._systemsHash[t] = n);
          for (let e in this.runners) this.runners[e].add(n);
          return this;
        }
        emitWithCustomOptions(e, t) {
          let n = Object.keys(this._systemsHash);
          e.items.forEach((r) => {
            let i = n.find((e) => this._systemsHash[e] === r);
            r[e.name](t[i]);
          });
        }
        destroy() {
          Object.values(this.runners).forEach((e) => {
            e.destroy();
          }),
            (this._systemsHash = {});
        }
      });
  }))();
}
var ls, us;
function ds() {
  return (ds = t(() => {
    w(),
      V(),
      (ls = class {
        constructor(e) {
          (this.renderer = e),
            (this.count = 0),
            (this.checkCount = 0),
            (this.maxIdle = ls.defaultMaxIdle),
            (this.checkCountMax = ls.defaultCheckCountMax),
            (this.mode = ls.defaultMode);
        }
        postrender() {
          this.renderer.objectRenderer.renderingToScreen &&
            (this.count++,
            this.mode !== y.MANUAL &&
              (this.checkCount++,
              this.checkCount > this.checkCountMax &&
                ((this.checkCount = 0), this.run())));
        }
        run() {
          let e = this.renderer.texture,
            t = e.managedTextures,
            n = !1;
          for (let r = 0; r < t.length; r++) {
            let i = t[r];
            !i.framebuffer &&
              this.count - i.touched > this.maxIdle &&
              (e.destroyTexture(i, !0), (t[r] = null), (n = !0));
          }
          if (n) {
            let e = 0;
            for (let n = 0; n < t.length; n++) t[n] !== null && (t[e++] = t[n]);
            t.length = e;
          }
        }
        unload(e) {
          let t = this.renderer.texture,
            n = e._texture;
          n && !n.framebuffer && t.destroyTexture(n);
          for (let t = e.children.length - 1; t >= 0; t--)
            this.unload(e.children[t]);
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (us = ls),
      (us.defaultMode = y.AUTO),
      (us.defaultMaxIdle = 3600),
      (us.defaultCheckCountMax = 600),
      (us.extension = { type: z.RendererSystem, name: `textureGC` }),
      B.add(us);
  }))();
}
var fs;
function ps() {
  return (ps = t(() => {
    w(),
      (fs = class {
        constructor(e) {
          (this.texture = e),
            (this.width = -1),
            (this.height = -1),
            (this.dirtyId = -1),
            (this.dirtyStyleId = -1),
            (this.mipmap = !1),
            (this.wrapMode = 33071),
            (this.type = f.UNSIGNED_BYTE),
            (this.internalFormat = u.RGBA),
            (this.samplerType = 0);
        }
      });
  }))();
}
function ms(e) {
  let t;
  return (
    (t =
      `WebGL2RenderingContext` in globalThis &&
      e instanceof globalThis.WebGL2RenderingContext
        ? {
            [f.UNSIGNED_BYTE]: {
              [u.RGBA]: e.RGBA8,
              [u.RGB]: e.RGB8,
              [u.RG]: e.RG8,
              [u.RED]: e.R8,
              [u.RGBA_INTEGER]: e.RGBA8UI,
              [u.RGB_INTEGER]: e.RGB8UI,
              [u.RG_INTEGER]: e.RG8UI,
              [u.RED_INTEGER]: e.R8UI,
              [u.ALPHA]: e.ALPHA,
              [u.LUMINANCE]: e.LUMINANCE,
              [u.LUMINANCE_ALPHA]: e.LUMINANCE_ALPHA,
            },
            [f.BYTE]: {
              [u.RGBA]: e.RGBA8_SNORM,
              [u.RGB]: e.RGB8_SNORM,
              [u.RG]: e.RG8_SNORM,
              [u.RED]: e.R8_SNORM,
              [u.RGBA_INTEGER]: e.RGBA8I,
              [u.RGB_INTEGER]: e.RGB8I,
              [u.RG_INTEGER]: e.RG8I,
              [u.RED_INTEGER]: e.R8I,
            },
            [f.UNSIGNED_SHORT]: {
              [u.RGBA_INTEGER]: e.RGBA16UI,
              [u.RGB_INTEGER]: e.RGB16UI,
              [u.RG_INTEGER]: e.RG16UI,
              [u.RED_INTEGER]: e.R16UI,
              [u.DEPTH_COMPONENT]: e.DEPTH_COMPONENT16,
            },
            [f.SHORT]: {
              [u.RGBA_INTEGER]: e.RGBA16I,
              [u.RGB_INTEGER]: e.RGB16I,
              [u.RG_INTEGER]: e.RG16I,
              [u.RED_INTEGER]: e.R16I,
            },
            [f.UNSIGNED_INT]: {
              [u.RGBA_INTEGER]: e.RGBA32UI,
              [u.RGB_INTEGER]: e.RGB32UI,
              [u.RG_INTEGER]: e.RG32UI,
              [u.RED_INTEGER]: e.R32UI,
              [u.DEPTH_COMPONENT]: e.DEPTH_COMPONENT24,
            },
            [f.INT]: {
              [u.RGBA_INTEGER]: e.RGBA32I,
              [u.RGB_INTEGER]: e.RGB32I,
              [u.RG_INTEGER]: e.RG32I,
              [u.RED_INTEGER]: e.R32I,
            },
            [f.FLOAT]: {
              [u.RGBA]: e.RGBA32F,
              [u.RGB]: e.RGB32F,
              [u.RG]: e.RG32F,
              [u.RED]: e.R32F,
              [u.DEPTH_COMPONENT]: e.DEPTH_COMPONENT32F,
            },
            [f.HALF_FLOAT]: {
              [u.RGBA]: e.RGBA16F,
              [u.RGB]: e.RGB16F,
              [u.RG]: e.RG16F,
              [u.RED]: e.R16F,
            },
            [f.UNSIGNED_SHORT_5_6_5]: { [u.RGB]: e.RGB565 },
            [f.UNSIGNED_SHORT_4_4_4_4]: { [u.RGBA]: e.RGBA4 },
            [f.UNSIGNED_SHORT_5_5_5_1]: { [u.RGBA]: e.RGB5_A1 },
            [f.UNSIGNED_INT_2_10_10_10_REV]: {
              [u.RGBA]: e.RGB10_A2,
              [u.RGBA_INTEGER]: e.RGB10_A2UI,
            },
            [f.UNSIGNED_INT_10F_11F_11F_REV]: { [u.RGB]: e.R11F_G11F_B10F },
            [f.UNSIGNED_INT_5_9_9_9_REV]: { [u.RGB]: e.RGB9_E5 },
            [f.UNSIGNED_INT_24_8]: { [u.DEPTH_STENCIL]: e.DEPTH24_STENCIL8 },
            [f.FLOAT_32_UNSIGNED_INT_24_8_REV]: {
              [u.DEPTH_STENCIL]: e.DEPTH32F_STENCIL8,
            },
          }
        : {
            [f.UNSIGNED_BYTE]: {
              [u.RGBA]: e.RGBA,
              [u.RGB]: e.RGB,
              [u.ALPHA]: e.ALPHA,
              [u.LUMINANCE]: e.LUMINANCE,
              [u.LUMINANCE_ALPHA]: e.LUMINANCE_ALPHA,
            },
            [f.UNSIGNED_SHORT_5_6_5]: { [u.RGB]: e.RGB },
            [f.UNSIGNED_SHORT_4_4_4_4]: { [u.RGBA]: e.RGBA },
            [f.UNSIGNED_SHORT_5_5_5_1]: { [u.RGBA]: e.RGBA },
          }),
    t
  );
}
function hs() {
  return (hs = t(() => {
    w();
  }))();
}
var gs;
function _s() {
  return (_s = t(() => {
    w(),
      V(),
      R(),
      $n(),
      ps(),
      hs(),
      (gs = class {
        constructor(e) {
          (this.renderer = e),
            (this.boundTextures = []),
            (this.currentLocation = -1),
            (this.managedTextures = []),
            (this._unknownBoundTextures = !1),
            (this.unknownTexture = new H()),
            (this.hasIntegerTextures = !1);
        }
        contextChange() {
          let e = (this.gl = this.renderer.gl);
          (this.CONTEXT_UID = this.renderer.CONTEXT_UID),
            (this.webGLVersion = this.renderer.context.webGLVersion),
            (this.internalFormats = ms(e));
          let t = e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS);
          this.boundTextures.length = t;
          for (let e = 0; e < t; e++) this.boundTextures[e] = null;
          this.emptyTextures = {};
          let n = new fs(e.createTexture());
          e.bindTexture(e.TEXTURE_2D, n.texture),
            e.texImage2D(
              e.TEXTURE_2D,
              0,
              e.RGBA,
              1,
              1,
              0,
              e.RGBA,
              e.UNSIGNED_BYTE,
              new Uint8Array(4)
            ),
            (this.emptyTextures[e.TEXTURE_2D] = n),
            (this.emptyTextures[e.TEXTURE_CUBE_MAP] = new fs(
              e.createTexture()
            )),
            e.bindTexture(
              e.TEXTURE_CUBE_MAP,
              this.emptyTextures[e.TEXTURE_CUBE_MAP].texture
            );
          for (let t = 0; t < 6; t++)
            e.texImage2D(
              e.TEXTURE_CUBE_MAP_POSITIVE_X + t,
              0,
              e.RGBA,
              1,
              1,
              0,
              e.RGBA,
              e.UNSIGNED_BYTE,
              null
            );
          e.texParameteri(e.TEXTURE_CUBE_MAP, e.TEXTURE_MAG_FILTER, e.LINEAR),
            e.texParameteri(e.TEXTURE_CUBE_MAP, e.TEXTURE_MIN_FILTER, e.LINEAR);
          for (let e = 0; e < this.boundTextures.length; e++)
            this.bind(null, e);
        }
        bind(e, t = 0) {
          let { gl: n } = this;
          if (
            ((e = e?.castToBaseTexture()), e?.valid && !e.parentTextureArray)
          ) {
            e.touched = this.renderer.textureGC.count;
            let r = e._glTextures[this.CONTEXT_UID] || this.initTexture(e);
            this.boundTextures[t] !== e &&
              (this.currentLocation !== t &&
                ((this.currentLocation = t), n.activeTexture(n.TEXTURE0 + t)),
              n.bindTexture(e.target, r.texture)),
              r.dirtyId === e.dirtyId
                ? r.dirtyStyleId !== e.dirtyStyleId &&
                  this.updateTextureStyle(e)
                : (this.currentLocation !== t &&
                    ((this.currentLocation = t),
                    n.activeTexture(n.TEXTURE0 + t)),
                  this.updateTexture(e)),
              (this.boundTextures[t] = e);
          } else
            this.currentLocation !== t &&
              ((this.currentLocation = t), n.activeTexture(n.TEXTURE0 + t)),
              n.bindTexture(
                n.TEXTURE_2D,
                this.emptyTextures[n.TEXTURE_2D].texture
              ),
              (this.boundTextures[t] = null);
        }
        reset() {
          (this._unknownBoundTextures = !0),
            (this.hasIntegerTextures = !1),
            (this.currentLocation = -1);
          for (let e = 0; e < this.boundTextures.length; e++)
            this.boundTextures[e] = this.unknownTexture;
        }
        unbind(e) {
          let { gl: t, boundTextures: n } = this;
          if (this._unknownBoundTextures) {
            this._unknownBoundTextures = !1;
            for (let e = 0; e < n.length; e++)
              n[e] === this.unknownTexture && this.bind(null, e);
          }
          for (let r = 0; r < n.length; r++)
            n[r] === e &&
              (this.currentLocation !== r &&
                (t.activeTexture(t.TEXTURE0 + r), (this.currentLocation = r)),
              t.bindTexture(e.target, this.emptyTextures[e.target].texture),
              (n[r] = null));
        }
        ensureSamplerType(e) {
          let {
            boundTextures: t,
            hasIntegerTextures: n,
            CONTEXT_UID: r,
          } = this;
          if (n)
            for (let n = e - 1; n >= 0; --n) {
              let e = t[n];
              e &&
                e._glTextures[r].samplerType !== p.FLOAT &&
                this.renderer.texture.unbind(e);
            }
        }
        initTexture(e) {
          let t = new fs(this.gl.createTexture());
          return (
            (t.dirtyId = -1),
            (e._glTextures[this.CONTEXT_UID] = t),
            this.managedTextures.push(e),
            e.on(`dispose`, this.destroyTexture, this),
            t
          );
        }
        initTextureType(e, t) {
          (t.internalFormat =
            this.internalFormats[e.type]?.[e.format] ?? e.format),
            (t.type =
              this.webGLVersion === 2 && e.type === f.HALF_FLOAT
                ? this.gl.HALF_FLOAT
                : e.type);
        }
        updateTexture(e) {
          let t = e._glTextures[this.CONTEXT_UID];
          if (!t) return;
          let n = this.renderer;
          if ((this.initTextureType(e, t), e.resource?.upload(n, e, t)))
            t.samplerType !== p.FLOAT && (this.hasIntegerTextures = !0);
          else {
            let r = e.realWidth,
              i = e.realHeight,
              a = n.gl;
            (t.width !== r || t.height !== i || t.dirtyId < 0) &&
              ((t.width = r),
              (t.height = i),
              a.texImage2D(
                e.target,
                0,
                t.internalFormat,
                r,
                i,
                0,
                e.format,
                t.type,
                null
              ));
          }
          e.dirtyStyleId !== t.dirtyStyleId && this.updateTextureStyle(e),
            (t.dirtyId = e.dirtyId);
        }
        destroyTexture(e, t) {
          let { gl: n } = this;
          if (
            ((e = e.castToBaseTexture()),
            e._glTextures[this.CONTEXT_UID] &&
              (this.unbind(e),
              n.deleteTexture(e._glTextures[this.CONTEXT_UID].texture),
              e.off(`dispose`, this.destroyTexture, this),
              delete e._glTextures[this.CONTEXT_UID],
              !t))
          ) {
            let t = this.managedTextures.indexOf(e);
            t !== -1 && Zt(this.managedTextures, t, 1);
          }
        }
        updateTextureStyle(e) {
          let t = e._glTextures[this.CONTEXT_UID];
          t &&
            ((t.mipmap =
              (e.mipmap === g.POW2 || this.webGLVersion !== 2) &&
              !e.isPowerOfTwo
                ? !1
                : e.mipmap >= 1),
            (t.wrapMode =
              this.webGLVersion !== 2 && !e.isPowerOfTwo
                ? h.CLAMP
                : e.wrapMode),
            e.resource?.style(this.renderer, e, t) || this.setStyle(e, t),
            (t.dirtyStyleId = e.dirtyStyleId));
        }
        setStyle(e, t) {
          let n = this.gl;
          if (
            (t.mipmap && e.mipmap !== g.ON_MANUAL && n.generateMipmap(e.target),
            n.texParameteri(e.target, n.TEXTURE_WRAP_S, t.wrapMode),
            n.texParameteri(e.target, n.TEXTURE_WRAP_T, t.wrapMode),
            t.mipmap)
          ) {
            n.texParameteri(
              e.target,
              n.TEXTURE_MIN_FILTER,
              e.scaleMode === m.LINEAR
                ? n.LINEAR_MIPMAP_LINEAR
                : n.NEAREST_MIPMAP_NEAREST
            );
            let t = this.renderer.context.extensions.anisotropicFiltering;
            if (t && e.anisotropicLevel > 0 && e.scaleMode === m.LINEAR) {
              let r = Math.min(
                e.anisotropicLevel,
                n.getParameter(t.MAX_TEXTURE_MAX_ANISOTROPY_EXT)
              );
              n.texParameterf(e.target, t.TEXTURE_MAX_ANISOTROPY_EXT, r);
            }
          } else
            n.texParameteri(
              e.target,
              n.TEXTURE_MIN_FILTER,
              e.scaleMode === m.LINEAR ? n.LINEAR : n.NEAREST
            );
          n.texParameteri(
            e.target,
            n.TEXTURE_MAG_FILTER,
            e.scaleMode === m.LINEAR ? n.LINEAR : n.NEAREST
          );
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (gs.extension = { type: z.RendererSystem, name: `texture` }),
      B.add(gs);
  }))();
}
var vs;
function ys() {
  return (ys = t(() => {
    V(),
      (vs = class {
        constructor(e) {
          this.renderer = e;
        }
        contextChange() {
          (this.gl = this.renderer.gl),
            (this.CONTEXT_UID = this.renderer.CONTEXT_UID);
        }
        bind(e) {
          let { gl: t, CONTEXT_UID: n } = this,
            r = e._glTransformFeedbacks[n] || this.createGLTransformFeedback(e);
          t.bindTransformFeedback(t.TRANSFORM_FEEDBACK, r);
        }
        unbind() {
          let { gl: e } = this;
          e.bindTransformFeedback(e.TRANSFORM_FEEDBACK, null);
        }
        beginTransformFeedback(e, t) {
          let { gl: n, renderer: r } = this;
          t && r.shader.bind(t), n.beginTransformFeedback(e);
        }
        endTransformFeedback() {
          let { gl: e } = this;
          e.endTransformFeedback();
        }
        createGLTransformFeedback(e) {
          let { gl: t, renderer: n, CONTEXT_UID: r } = this,
            i = t.createTransformFeedback();
          (e._glTransformFeedbacks[r] = i),
            t.bindTransformFeedback(t.TRANSFORM_FEEDBACK, i);
          for (let i = 0; i < e.buffers.length; i++) {
            let a = e.buffers[i];
            a &&
              (n.buffer.update(a),
              a._glBuffers[r].refCount++,
              t.bindBufferBase(
                t.TRANSFORM_FEEDBACK_BUFFER,
                i,
                a._glBuffers[r].buffer || null
              ));
          }
          return (
            t.bindTransformFeedback(t.TRANSFORM_FEEDBACK, null),
            e.disposeRunner.add(this),
            i
          );
        }
        disposeTransformFeedback(e, t) {
          let n = e._glTransformFeedbacks[this.CONTEXT_UID],
            r = this.gl;
          e.disposeRunner.remove(this);
          let i = this.renderer.buffer;
          if (i)
            for (let n = 0; n < e.buffers.length; n++) {
              let r = e.buffers[n];
              if (!r) continue;
              let a = r._glBuffers[this.CONTEXT_UID];
              a && (a.refCount--, a.refCount === 0 && !t && i.dispose(r, t));
            }
          n &&
            (t || r.deleteTransformFeedback(n),
            delete e._glTransformFeedbacks[this.CONTEXT_UID]);
        }
        destroy() {
          this.renderer = null;
        }
      }),
      (vs.extension = { type: z.RendererSystem, name: `transformFeedback` }),
      B.add(vs);
  }))();
}
var bs;
function xs() {
  return (xs = t(() => {
    V(),
      Y(),
      N(),
      (bs = class {
        constructor(e) {
          this.renderer = e;
        }
        init(e) {
          (this.screen = new K(0, 0, e.width, e.height)),
            (this.element = e.view || D.ADAPTER.createCanvas()),
            (this.resolution = e.resolution || D.RESOLUTION),
            (this.autoDensity = !!e.autoDensity);
        }
        resizeView(e, t) {
          (this.element.width = Math.round(e * this.resolution)),
            (this.element.height = Math.round(t * this.resolution));
          let n = this.element.width / this.resolution,
            r = this.element.height / this.resolution;
          (this.screen.width = n),
            (this.screen.height = r),
            this.autoDensity &&
              ((this.element.style.width = `${n}px`),
              (this.element.style.height = `${r}px`)),
            this.renderer.emit(`resize`, n, r),
            this.renderer.runners.resize.emit(
              this.screen.width,
              this.screen.height
            );
        }
        destroy(e) {
          e && this.element.parentNode?.removeChild(this.element),
            (this.renderer = null),
            (this.element = null),
            (this.screen = null);
        }
      }),
      (bs.defaultOptions = {
        width: 800,
        height: 600,
        resolution: D.RESOLUTION,
        autoDensity: !1,
      }),
      (bs.extension = {
        type: [z.RendererSystem, z.CanvasRendererSystem],
        name: `_view`,
      }),
      B.add(bs);
  }))();
}
function Ss() {
  return (Ss = t(() => {
    ca(),
      ua(),
      pa(),
      Ha(),
      qa(),
      Xa(),
      so(),
      ho(),
      _o(),
      yo(),
      xo(),
      wo(),
      Oo(),
      qo(),
      Yo(),
      os(),
      cs(),
      ds(),
      _s(),
      ys(),
      xs();
  }))();
}
function Cs() {
  return (Cs = t(() => {
    w(),
      N(),
      R(),
      $i(),
      oa(),
      ji(),
      Ss(),
      $n(),
      pa(),
      ca(),
      xs(),
      Yo(),
      ds(),
      (D.PREFER_ENV = a.WEBGL2),
      (D.STRICT_TEXTURE_CACHE = !1),
      (D.RENDER_OPTIONS = {
        ...fa.defaultOptions,
        ...sa.defaultOptions,
        ...bs.defaultOptions,
        ...Jo.defaultOptions,
      }),
      Object.defineProperties(D, {
        WRAP_MODE: {
          get() {
            return H.defaultOptions.wrapMode;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.WRAP_MODE is deprecated, use BaseTexture.defaultOptions.wrapMode`
            ),
              (H.defaultOptions.wrapMode = e);
          },
        },
        SCALE_MODE: {
          get() {
            return H.defaultOptions.scaleMode;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.SCALE_MODE is deprecated, use BaseTexture.defaultOptions.scaleMode`
            ),
              (H.defaultOptions.scaleMode = e);
          },
        },
        MIPMAP_TEXTURES: {
          get() {
            return H.defaultOptions.mipmap;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.MIPMAP_TEXTURES is deprecated, use BaseTexture.defaultOptions.mipmap`
            ),
              (H.defaultOptions.mipmap = e);
          },
        },
        ANISOTROPIC_LEVEL: {
          get() {
            return H.defaultOptions.anisotropicLevel;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.ANISOTROPIC_LEVEL is deprecated, use BaseTexture.defaultOptions.anisotropicLevel`
            ),
              (H.defaultOptions.anisotropicLevel = e);
          },
        },
        FILTER_RESOLUTION: {
          get() {
            return (
              P(
                `7.1.0`,
                `settings.FILTER_RESOLUTION is deprecated, use Filter.defaultResolution`
              ),
              aa.defaultResolution
            );
          },
          set(e) {
            aa.defaultResolution = e;
          },
        },
        FILTER_MULTISAMPLE: {
          get() {
            return (
              P(
                `7.1.0`,
                `settings.FILTER_MULTISAMPLE is deprecated, use Filter.defaultMultisample`
              ),
              aa.defaultMultisample
            );
          },
          set(e) {
            aa.defaultMultisample = e;
          },
        },
        SPRITE_MAX_TEXTURES: {
          get() {
            return Qi.defaultMaxTextures;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.SPRITE_MAX_TEXTURES is deprecated, use BatchRenderer.defaultMaxTextures`
            ),
              (Qi.defaultMaxTextures = e);
          },
        },
        SPRITE_BATCH_SIZE: {
          get() {
            return Qi.defaultBatchSize;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.SPRITE_BATCH_SIZE is deprecated, use BatchRenderer.defaultBatchSize`
            ),
              (Qi.defaultBatchSize = e);
          },
        },
        CAN_UPLOAD_SAME_BUFFER: {
          get() {
            return Qi.canUploadSameBuffer;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.CAN_UPLOAD_SAME_BUFFER is deprecated, use BatchRenderer.canUploadSameBuffer`
            ),
              (Qi.canUploadSameBuffer = e);
          },
        },
        GC_MODE: {
          get() {
            return us.defaultMode;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.GC_MODE is deprecated, use TextureGCSystem.defaultMode`
            ),
              (us.defaultMode = e);
          },
        },
        GC_MAX_IDLE: {
          get() {
            return us.defaultMaxIdle;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.GC_MAX_IDLE is deprecated, use TextureGCSystem.defaultMaxIdle`
            ),
              (us.defaultMaxIdle = e);
          },
        },
        GC_MAX_CHECK_COUNT: {
          get() {
            return us.defaultCheckCountMax;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.GC_MAX_CHECK_COUNT is deprecated, use TextureGCSystem.defaultCheckCountMax`
            ),
              (us.defaultCheckCountMax = e);
          },
        },
        PRECISION_VERTEX: {
          get() {
            return Ai.defaultVertexPrecision;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.PRECISION_VERTEX is deprecated, use Program.defaultVertexPrecision`
            ),
              (Ai.defaultVertexPrecision = e);
          },
        },
        PRECISION_FRAGMENT: {
          get() {
            return Ai.defaultFragmentPrecision;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.PRECISION_FRAGMENT is deprecated, use Program.defaultFragmentPrecision`
            ),
              (Ai.defaultFragmentPrecision = e);
          },
        },
      });
  }))();
}
var ws;
function Ts() {
  return (Ts = t(() => {
    ws = ((e) => (
      (e[(e.INTERACTION = 50)] = `INTERACTION`),
      (e[(e.HIGH = 25)] = `HIGH`),
      (e[(e.NORMAL = 0)] = `NORMAL`),
      (e[(e.LOW = -25)] = `LOW`),
      (e[(e.UTILITY = -50)] = `UTILITY`),
      e
    ))(ws || {});
  }))();
}
var Es;
function Ds() {
  return (Ds = t(() => {
    Es = class {
      constructor(e, t = null, n = 0, r = !1) {
        (this.next = null),
          (this.previous = null),
          (this._destroyed = !1),
          (this.fn = e),
          (this.context = t),
          (this.priority = n),
          (this.once = r);
      }
      match(e, t = null) {
        return this.fn === e && this.context === t;
      }
      emit(e) {
        this.fn && (this.context ? this.fn.call(this.context, e) : this.fn(e));
        let t = this.next;
        return (
          this.once && this.destroy(!0),
          this._destroyed && (this.next = null),
          t
        );
      }
      connect(e) {
        (this.previous = e),
          e.next && (e.next.previous = this),
          (this.next = e.next),
          (e.next = this);
      }
      destroy(e = !1) {
        (this._destroyed = !0),
          (this.fn = null),
          (this.context = null),
          this.previous && (this.previous.next = this.next),
          this.next && (this.next.previous = this.previous);
        let t = this.next;
        return (this.next = e ? null : t), (this.previous = null), t;
      }
    };
  }))();
}
var Os, ks;
function As() {
  return (As = t(() => {
    Ts(),
      Ds(),
      (Os = class {
        constructor() {
          (this.autoStart = !1),
            (this.deltaTime = 1),
            (this.lastTime = -1),
            (this.speed = 1),
            (this.started = !1),
            (this._requestId = null),
            (this._maxElapsedMS = 100),
            (this._minElapsedMS = 0),
            (this._protected = !1),
            (this._lastFrame = -1),
            (this._head = new Es(null, null, 1 / 0)),
            (this.deltaMS = 1 / Os.targetFPMS),
            (this.elapsedMS = 1 / Os.targetFPMS),
            (this._tick = (e) => {
              (this._requestId = null),
                this.started &&
                  (this.update(e),
                  this.started &&
                    this._requestId === null &&
                    this._head.next &&
                    (this._requestId = requestAnimationFrame(this._tick)));
            });
        }
        _requestIfNeeded() {
          this._requestId === null &&
            this._head.next &&
            ((this.lastTime = performance.now()),
            (this._lastFrame = this.lastTime),
            (this._requestId = requestAnimationFrame(this._tick)));
        }
        _cancelIfNeeded() {
          this._requestId !== null &&
            (cancelAnimationFrame(this._requestId), (this._requestId = null));
        }
        _startIfPossible() {
          this.started
            ? this._requestIfNeeded()
            : this.autoStart && this.start();
        }
        add(e, t, n = ws.NORMAL) {
          return this._addListener(new Es(e, t, n));
        }
        addOnce(e, t, n = ws.NORMAL) {
          return this._addListener(new Es(e, t, n, !0));
        }
        _addListener(e) {
          let t = this._head.next,
            n = this._head;
          if (!t) e.connect(n);
          else {
            for (; t; ) {
              if (e.priority > t.priority) {
                e.connect(n);
                break;
              }
              (n = t), (t = t.next);
            }
            e.previous || e.connect(n);
          }
          return this._startIfPossible(), this;
        }
        remove(e, t) {
          let n = this._head.next;
          for (; n; ) n = n.match(e, t) ? n.destroy() : n.next;
          return this._head.next || this._cancelIfNeeded(), this;
        }
        get count() {
          if (!this._head) return 0;
          let e = 0,
            t = this._head;
          for (; (t = t.next); ) e++;
          return e;
        }
        start() {
          this.started || ((this.started = !0), this._requestIfNeeded());
        }
        stop() {
          this.started && ((this.started = !1), this._cancelIfNeeded());
        }
        destroy() {
          if (!this._protected) {
            this.stop();
            let e = this._head.next;
            for (; e; ) e = e.destroy(!0);
            this._head.destroy(), (this._head = null);
          }
        }
        update(e = performance.now()) {
          let t;
          if (e > this.lastTime) {
            if (
              ((t = this.elapsedMS = e - this.lastTime),
              t > this._maxElapsedMS && (t = this._maxElapsedMS),
              (t *= this.speed),
              this._minElapsedMS)
            ) {
              let t = (e - this._lastFrame) | 0;
              if (t < this._minElapsedMS) return;
              this._lastFrame = e - (t % this._minElapsedMS);
            }
            (this.deltaMS = t), (this.deltaTime = this.deltaMS * Os.targetFPMS);
            let n = this._head,
              r = n.next;
            for (; r; ) r = r.emit(this.deltaTime);
            n.next || this._cancelIfNeeded();
          } else this.deltaTime = this.deltaMS = this.elapsedMS = 0;
          this.lastTime = e;
        }
        get FPS() {
          return 1e3 / this.elapsedMS;
        }
        get minFPS() {
          return 1e3 / this._maxElapsedMS;
        }
        set minFPS(e) {
          let t = Math.min(this.maxFPS, e),
            n = Math.min(Math.max(0, t) / 1e3, Os.targetFPMS);
          this._maxElapsedMS = 1 / n;
        }
        get maxFPS() {
          return this._minElapsedMS ? Math.round(1e3 / this._minElapsedMS) : 0;
        }
        set maxFPS(e) {
          if (e === 0) this._minElapsedMS = 0;
          else {
            let t = Math.max(this.minFPS, e);
            this._minElapsedMS = 1 / (t / 1e3);
          }
        }
        static get shared() {
          if (!Os._shared) {
            let e = (Os._shared = new Os());
            (e.autoStart = !0), (e._protected = !0);
          }
          return Os._shared;
        }
        static get system() {
          if (!Os._system) {
            let e = (Os._system = new Os());
            (e.autoStart = !0), (e._protected = !0);
          }
          return Os._system;
        }
      }),
      (ks = Os),
      (ks.targetFPMS = 0.06);
  }))();
}
function js() {
  return (js = t(() => {
    N(),
      R(),
      As(),
      Object.defineProperties(D, {
        TARGET_FPMS: {
          get() {
            return ks.targetFPMS;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.TARGET_FPMS is deprecated, use Ticker.targetFPMS`
            ),
              (ks.targetFPMS = e);
          },
        },
      });
  }))();
}
var Ms;
function Ns() {
  return (Ns = t(() => {
    V(),
      Ts(),
      As(),
      (Ms = class {
        static init(e) {
          (e = Object.assign({ autoStart: !0, sharedTicker: !1 }, e)),
            Object.defineProperty(this, "ticker", {
              set(e) {
                this._ticker && this._ticker.remove(this.render, this),
                  (this._ticker = e),
                  e && e.add(this.render, this, ws.LOW);
              },
              get() {
                return this._ticker;
              },
            }),
            (this.stop = () => {
              this._ticker.stop();
            }),
            (this.start = () => {
              this._ticker.start();
            }),
            (this._ticker = null),
            (this.ticker = e.sharedTicker ? ks.shared : new ks()),
            e.autoStart && this.start();
        }
        static destroy() {
          if (this._ticker) {
            let e = this._ticker;
            (this.ticker = null), e.destroy();
          }
        }
      }),
      (Ms.extension = z.Application),
      B.add(Ms);
  }))();
}
function Ps() {
  return (Ps = t(() => {
    js(), Ts(), As(), Ns();
  }))();
}
function Fs(e) {
  for (let t of Is) if (t.test(e)) return new t(e);
  throw Error(`Unable to auto-detect a suitable renderer.`);
}
var Is;
function Ls() {
  return (Ls = t(() => {
    V(), (Is = []), B.handleByList(z.Renderer, Is);
  }))();
}
var Rs;
function zs() {
  return (zs = t(() => {
    w(),
      V(),
      (Rs = class {
        constructor(e) {
          this.renderer = e;
        }
        contextChange(e) {
          let t;
          if (this.renderer.context.webGLVersion === 1) {
            let n = e.getParameter(e.FRAMEBUFFER_BINDING);
            e.bindFramebuffer(e.FRAMEBUFFER, null),
              (t = e.getParameter(e.SAMPLES)),
              e.bindFramebuffer(e.FRAMEBUFFER, n);
          } else {
            let n = e.getParameter(e.DRAW_FRAMEBUFFER_BINDING);
            e.bindFramebuffer(e.DRAW_FRAMEBUFFER, null),
              (t = e.getParameter(e.SAMPLES)),
              e.bindFramebuffer(e.DRAW_FRAMEBUFFER, n);
          }
          this.multisample =
            t >= S.HIGH
              ? S.HIGH
              : t >= S.MEDIUM
              ? S.MEDIUM
              : t >= S.LOW
              ? S.LOW
              : S.NONE;
        }
        destroy() {}
      }),
      (Rs.extension = { type: z.RendererSystem, name: `_multisample` }),
      B.add(Rs);
  }))();
}
var Bs;
function Vs() {
  return (Vs = t(() => {
    Bs = class {
      constructor(e) {
        (this.buffer = e || null),
          (this.updateID = -1),
          (this.byteLength = -1),
          (this.refCount = 0);
      }
    };
  }))();
}
var Hs;
function Us() {
  return (Us = t(() => {
    V(),
      Vs(),
      (Hs = class {
        constructor(e) {
          (this.renderer = e),
            (this.managedBuffers = {}),
            (this.boundBufferBases = {});
        }
        destroy() {
          this.renderer = null;
        }
        contextChange() {
          this.disposeAll(!0),
            (this.gl = this.renderer.gl),
            (this.CONTEXT_UID = this.renderer.CONTEXT_UID);
        }
        bind(e) {
          let { gl: t, CONTEXT_UID: n } = this,
            r = e._glBuffers[n] || this.createGLBuffer(e);
          t.bindBuffer(e.type, r.buffer);
        }
        unbind(e) {
          let { gl: t } = this;
          t.bindBuffer(e, null);
        }
        bindBufferBase(e, t) {
          let { gl: n, CONTEXT_UID: r } = this;
          if (this.boundBufferBases[t] !== e) {
            let i = e._glBuffers[r] || this.createGLBuffer(e);
            (this.boundBufferBases[t] = e),
              n.bindBufferBase(n.UNIFORM_BUFFER, t, i.buffer);
          }
        }
        bindBufferRange(e, t, n) {
          let { gl: r, CONTEXT_UID: i } = this;
          n ||= 0;
          let a = e._glBuffers[i] || this.createGLBuffer(e);
          r.bindBufferRange(r.UNIFORM_BUFFER, t || 0, a.buffer, n * 256, 256);
        }
        update(e) {
          let { gl: t, CONTEXT_UID: n } = this,
            r = e._glBuffers[n] || this.createGLBuffer(e);
          if (e._updateID !== r.updateID)
            if (
              ((r.updateID = e._updateID),
              t.bindBuffer(e.type, r.buffer),
              r.byteLength >= e.data.byteLength)
            )
              t.bufferSubData(e.type, 0, e.data);
            else {
              let n = e.static ? t.STATIC_DRAW : t.DYNAMIC_DRAW;
              (r.byteLength = e.data.byteLength),
                t.bufferData(e.type, e.data, n);
            }
        }
        dispose(e, t) {
          if (!this.managedBuffers[e.id]) return;
          delete this.managedBuffers[e.id];
          let n = e._glBuffers[this.CONTEXT_UID],
            r = this.gl;
          e.disposeRunner.remove(this),
            n &&
              (t || r.deleteBuffer(n.buffer),
              delete e._glBuffers[this.CONTEXT_UID]);
        }
        disposeAll(e) {
          let t = Object.keys(this.managedBuffers);
          for (let n = 0; n < t.length; n++)
            this.dispose(this.managedBuffers[t[n]], e);
        }
        createGLBuffer(e) {
          let { CONTEXT_UID: t, gl: n } = this;
          return (
            (e._glBuffers[t] = new Bs(n.createBuffer())),
            (this.managedBuffers[e.id] = e),
            e.disposeRunner.add(this),
            e._glBuffers[t]
          );
        }
      }),
      (Hs.extension = { type: z.RendererSystem, name: `buffer` }),
      B.add(Hs);
  }))();
}
var Ws;
function Gs() {
  return (Gs = t(() => {
    V(),
      (Ws = class {
        constructor(e) {
          this.renderer = e;
        }
        render(e, t) {
          let n = this.renderer,
            r,
            i,
            a,
            o;
          if (
            (t &&
              ((r = t.renderTexture),
              (i = t.clear),
              (a = t.transform),
              (o = t.skipUpdateTransform)),
            (this.renderingToScreen = !r),
            n.runners.prerender.emit(),
            n.emit(`prerender`),
            (n.projection.transform = a),
            !n.context.isLost)
          ) {
            if ((r || (this.lastObjectRendered = e), !o)) {
              let t = e.enableTempParent();
              e.updateTransform(), e.disableTempParent(t);
            }
            n.renderTexture.bind(r),
              n.batch.currentRenderer.start(),
              (i ?? n.background.clearBeforeRender) && n.renderTexture.clear(),
              e.render(n),
              n.batch.currentRenderer.flush(),
              r && (t.blit && n.framebuffer.blit(), r.baseTexture.update()),
              n.runners.postrender.emit(),
              (n.projection.transform = null),
              n.emit(`postrender`);
          }
        }
        destroy() {
          (this.renderer = null), (this.lastObjectRendered = null);
        }
      }),
      (Ws.extension = { type: z.RendererSystem, name: `objectRenderer` }),
      B.add(Ws);
  }))();
}
var Ks, qs;
function Js() {
  return (Js = t(() => {
    w(),
      V(),
      Y(),
      N(),
      R(),
      Pi(),
      cs(),
      (Ks = class extends ss {
        constructor(e) {
          super(),
            (this.type = o.WEBGL),
            (e = Object.assign({}, D.RENDER_OPTIONS, e)),
            (this.gl = null),
            (this.CONTEXT_UID = 0),
            (this.globalUniforms = new Ni({ projectionMatrix: new q() }, !0));
          let t = {
            runners: [
              `init`,
              `destroy`,
              `contextChange`,
              `resolutionChange`,
              `reset`,
              `update`,
              `postrender`,
              `prerender`,
              `resize`,
            ],
            systems: Ks.__systems,
            priority: [
              `_view`,
              `textureGenerator`,
              `background`,
              `_plugin`,
              `startup`,
              `context`,
              `state`,
              `texture`,
              `buffer`,
              `geometry`,
              `framebuffer`,
              `transformFeedback`,
              `mask`,
              `scissor`,
              `stencil`,
              `projection`,
              `textureGC`,
              `filter`,
              `renderTexture`,
              `batch`,
              `objectRenderer`,
              `_multisample`,
            ],
          };
          this.setup(t),
            `useContextAlpha` in e &&
              (P(
                `7.0.0`,
                `options.useContextAlpha is deprecated, use options.premultipliedAlpha and options.backgroundAlpha instead`
              ),
              (e.premultipliedAlpha =
                e.useContextAlpha && e.useContextAlpha !== `notMultiplied`),
              (e.backgroundAlpha =
                e.useContextAlpha === !1 ? 1 : e.backgroundAlpha)),
            (this._plugin.rendererPlugins = Ks.__plugins),
            (this.options = e),
            this.startup.run(this.options);
        }
        static test(e) {
          return !e?.forceCanvas && Ve();
        }
        render(e, t) {
          this.objectRenderer.render(e, t);
        }
        resize(e, t) {
          this._view.resizeView(e, t);
        }
        reset() {
          return this.runners.reset.emit(), this;
        }
        clear() {
          this.renderTexture.bind(), this.renderTexture.clear();
        }
        destroy(e = !1) {
          this.runners.destroy.items.reverse(),
            this.emitWithCustomOptions(this.runners.destroy, { _view: e }),
            super.destroy();
        }
        get plugins() {
          return this._plugin.plugins;
        }
        get multisample() {
          return this._multisample.multisample;
        }
        get width() {
          return this._view.element.width;
        }
        get height() {
          return this._view.element.height;
        }
        get resolution() {
          return this._view.resolution;
        }
        set resolution(e) {
          (this._view.resolution = e), this.runners.resolutionChange.emit(e);
        }
        get autoDensity() {
          return this._view.autoDensity;
        }
        get view() {
          return this._view.element;
        }
        get screen() {
          return this._view.screen;
        }
        get lastObjectRendered() {
          return this.objectRenderer.lastObjectRendered;
        }
        get renderingToScreen() {
          return this.objectRenderer.renderingToScreen;
        }
        get rendererLogId() {
          return `WebGL ${this.context.webGLVersion}`;
        }
        get clearBeforeRender() {
          return (
            P(
              `7.0.0`,
              `renderer.clearBeforeRender has been deprecated, please use renderer.background.clearBeforeRender instead.`
            ),
            this.background.clearBeforeRender
          );
        }
        get useContextAlpha() {
          return (
            P(
              `7.0.0`,
              `renderer.useContextAlpha has been deprecated, please use renderer.context.premultipliedAlpha instead.`
            ),
            this.context.useContextAlpha
          );
        }
        get preserveDrawingBuffer() {
          return (
            P(
              `7.0.0`,
              `renderer.preserveDrawingBuffer has been deprecated, we cannot truly know this unless pixi created the context`
            ),
            this.context.preserveDrawingBuffer
          );
        }
        get backgroundColor() {
          return (
            P(
              `7.0.0`,
              `renderer.backgroundColor has been deprecated, use renderer.background.color instead.`
            ),
            this.background.color
          );
        }
        set backgroundColor(e) {
          P(
            `7.0.0`,
            `renderer.backgroundColor has been deprecated, use renderer.background.color instead.`
          ),
            (this.background.color = e);
        }
        get backgroundAlpha() {
          return (
            P(
              `7.0.0`,
              `renderer.backgroundAlpha has been deprecated, use renderer.background.alpha instead.`
            ),
            this.background.alpha
          );
        }
        set backgroundAlpha(e) {
          P(
            `7.0.0`,
            `renderer.backgroundAlpha has been deprecated, use renderer.background.alpha instead.`
          ),
            (this.background.alpha = e);
        }
        get powerPreference() {
          return (
            P(
              `7.0.0`,
              `renderer.powerPreference has been deprecated, we can only know this if pixi creates the context`
            ),
            this.context.powerPreference
          );
        }
        generateTexture(e, t) {
          return this.textureGenerator.generateTexture(e, t);
        }
      }),
      (qs = Ks),
      (qs.extension = { type: z.Renderer, priority: 1 }),
      (qs.__plugins = {}),
      (qs.__systems = {}),
      B.handleByMap(z.RendererPlugin, qs.__plugins),
      B.handleByMap(z.RendererSystem, qs.__systems),
      B.add(qs);
  }))();
}
var Ys;
function Xs() {
  return (Xs = t(() => {
    $n(),
      Un(),
      Jn(),
      (Ys = class extends qn {
        constructor(e, t) {
          let { width: n, height: r } = t || {};
          super(n, r), (this.items = []), (this.itemDirtyIds = []);
          for (let t = 0; t < e; t++) {
            let e = new H();
            this.items.push(e), this.itemDirtyIds.push(-2);
          }
          (this.length = e), (this._load = null), (this.baseTexture = null);
        }
        initFromArray(e, t) {
          for (let n = 0; n < this.length; n++)
            e[n] &&
              (e[n].castToBaseTexture
                ? this.addBaseTextureAt(e[n].castToBaseTexture(), n)
                : e[n] instanceof qn
                ? this.addResourceAt(e[n], n)
                : this.addResourceAt(Vn(e[n], t), n));
        }
        dispose() {
          for (let e = 0, t = this.length; e < t; e++) this.items[e].destroy();
          (this.items = null), (this.itemDirtyIds = null), (this._load = null);
        }
        addResourceAt(e, t) {
          if (!this.items[t]) throw Error(`Index ${t} is out of bounds`);
          return (
            e.valid && !this.valid && this.resize(e.width, e.height),
            this.items[t].setResource(e),
            this
          );
        }
        bind(e) {
          if (this.baseTexture !== null)
            throw Error(`Only one base texture per TextureArray is allowed`);
          super.bind(e);
          for (let t = 0; t < this.length; t++)
            (this.items[t].parentTextureArray = e),
              this.items[t].on(`update`, e.update, e);
        }
        unbind(e) {
          super.unbind(e);
          for (let t = 0; t < this.length; t++)
            (this.items[t].parentTextureArray = null),
              this.items[t].off(`update`, e.update, e);
        }
        load() {
          if (this._load) return this._load;
          let e = this.items
            .map((e) => e.resource)
            .filter((e) => e)
            .map((e) => e.load());
          return (
            (this._load = Promise.all(e).then(() => {
              let { realWidth: e, realHeight: t } = this.items[0];
              return this.resize(e, t), Promise.resolve(this);
            })),
            this._load
          );
        }
      });
  }))();
}
var Zs;
function Qs() {
  return (Qs = t(() => {
    w(),
      Xs(),
      (Zs = class extends Ys {
        constructor(e, t) {
          let { width: n, height: r } = t || {},
            i,
            a;
          Array.isArray(e) ? ((i = e), (a = e.length)) : (a = e),
            super(a, { width: n, height: r }),
            i && this.initFromArray(i, t);
        }
        addBaseTextureAt(e, t) {
          if (e.resource) this.addResourceAt(e.resource, t);
          else throw Error(`ArrayResource does not support RenderTexture`);
          return this;
        }
        bind(e) {
          super.bind(e), (e.target = d.TEXTURE_2D_ARRAY);
        }
        upload(e, t, n) {
          let { length: r, itemDirtyIds: i, items: a } = this,
            { gl: o } = e;
          n.dirtyId < 0 &&
            o.texImage3D(
              o.TEXTURE_2D_ARRAY,
              0,
              n.internalFormat,
              this._width,
              this._height,
              r,
              0,
              t.format,
              n.type,
              null
            );
          for (let e = 0; e < r; e++) {
            let r = a[e];
            i[e] < r.dirtyId &&
              ((i[e] = r.dirtyId),
              r.valid &&
                o.texSubImage3D(
                  o.TEXTURE_2D_ARRAY,
                  0,
                  0,
                  0,
                  e,
                  r.resource.width,
                  r.resource.height,
                  1,
                  t.format,
                  n.type,
                  r.resource.source
                ));
          }
          return !0;
        }
      });
  }))();
}
var $s;
function ec() {
  return (ec = t(() => {
    xa(),
      ($s = class extends ba {
        constructor(e) {
          super(e);
        }
        static test(e) {
          let { OffscreenCanvas: t } = globalThis;
          return t && e instanceof t
            ? !0
            : globalThis.HTMLCanvasElement && e instanceof HTMLCanvasElement;
        }
      });
  }))();
}
var tc, nc;
function rc() {
  return (rc = t(() => {
    w(),
      Xs(),
      (tc = class extends Ys {
        constructor(e, t) {
          let {
            width: n,
            height: r,
            autoLoad: i,
            linkBaseTexture: a,
          } = t || {};
          if (e && e.length !== tc.SIDES)
            throw Error(`Invalid length. Got ${e.length}, expected 6`);
          super(6, { width: n, height: r });
          for (let e = 0; e < tc.SIDES; e++)
            this.items[e].target = d.TEXTURE_CUBE_MAP_POSITIVE_X + e;
          (this.linkBaseTexture = a !== !1),
            e && this.initFromArray(e, t),
            i !== !1 && this.load();
        }
        bind(e) {
          super.bind(e), (e.target = d.TEXTURE_CUBE_MAP);
        }
        addBaseTextureAt(e, t, n) {
          if ((n === void 0 && (n = this.linkBaseTexture), !this.items[t]))
            throw Error(`Index ${t} is out of bounds`);
          if (
            !this.linkBaseTexture ||
            e.parentTextureArray ||
            Object.keys(e._glTextures).length > 0
          )
            if (e.resource) this.addResourceAt(e.resource, t);
            else
              throw Error(
                `CubeResource does not support copying of renderTexture.`
              );
          else
            (e.target = d.TEXTURE_CUBE_MAP_POSITIVE_X + t),
              (e.parentTextureArray = this.baseTexture),
              (this.items[t] = e);
          return (
            e.valid && !this.valid && this.resize(e.realWidth, e.realHeight),
            (this.items[t] = e),
            this
          );
        }
        upload(e, t, n) {
          let r = this.itemDirtyIds;
          for (let i = 0; i < tc.SIDES; i++) {
            let a = this.items[i];
            (r[i] < a.dirtyId || n.dirtyId < t.dirtyId) &&
              (a.valid && a.resource
                ? (a.resource.upload(e, a, n), (r[i] = a.dirtyId))
                : r[i] < -1 &&
                  (e.gl.texImage2D(
                    a.target,
                    0,
                    n.internalFormat,
                    t.realWidth,
                    t.realHeight,
                    0,
                    t.format,
                    n.type,
                    null
                  ),
                  (r[i] = -1)));
          }
          return !0;
        }
        static test(e) {
          return Array.isArray(e) && e.length === tc.SIDES;
        }
      }),
      (nc = tc),
      (nc.SIDES = 6);
  }))();
}
var ic;
function ac() {
  return (ac = t(() => {
    w(),
      N(),
      xa(),
      (ic = class e extends ba {
        constructor(t, n) {
          n ||= {};
          let r, i;
          typeof t == `string`
            ? ((r = e.EMPTY), (i = t))
            : ((r = t), (i = null)),
            super(r),
            (this.url = i),
            (this.crossOrigin = n.crossOrigin ?? !0),
            (this.alphaMode =
              typeof n.alphaMode == `number` ? n.alphaMode : null),
            (this._load = null),
            n.autoLoad !== !1 && this.load();
        }
        load() {
          return (
            (this._load ||= new Promise(async (e, t) => {
              if (this.url === null) {
                e(this);
                return;
              }
              try {
                let t = await D.ADAPTER.fetch(this.url, {
                  mode: this.crossOrigin ? `cors` : `no-cors`,
                });
                if (this.destroyed) return;
                let n = await t.blob();
                if (this.destroyed) return;
                let r = await createImageBitmap(n, {
                  premultiplyAlpha:
                    this.alphaMode === null || this.alphaMode === _.UNPACK
                      ? `premultiply`
                      : `none`,
                });
                if (this.destroyed) return;
                (this.source = r), this.update(), e(this);
              } catch (e) {
                if (this.destroyed) return;
                t(e), this.onError.emit(e);
              }
            })),
            this._load
          );
        }
        upload(e, t, n) {
          return this.source instanceof ImageBitmap
            ? (typeof this.alphaMode == `number` &&
                (t.alphaMode = this.alphaMode),
              super.upload(e, t, n))
            : (this.load(), !1);
        }
        dispose() {
          this.source instanceof ImageBitmap && this.source.close(),
            super.dispose(),
            (this._load = null);
        }
        static test(e) {
          return (
            !!globalThis.createImageBitmap &&
            typeof ImageBitmap < `u` &&
            (typeof e == `string` || e instanceof ImageBitmap)
          );
        }
        static get EMPTY() {
          return (
            (e._EMPTY = e._EMPTY ?? D.ADAPTER.createCanvas(0, 0)), e._EMPTY
          );
        }
      });
  }))();
}
var oc, sc;
function cc() {
  return (cc = t(() => {
    N(),
      R(),
      xa(),
      (oc = class extends ba {
        constructor(e, t) {
          (t ||= {}),
            super(D.ADAPTER.createCanvas()),
            (this._width = 0),
            (this._height = 0),
            (this.svg = e),
            (this.scale = t.scale || 1),
            (this._overrideWidth = t.width),
            (this._overrideHeight = t.height),
            (this._resolve = null),
            (this._crossorigin = t.crossorigin),
            (this._load = null),
            t.autoLoad !== !1 && this.load();
        }
        load() {
          return (
            (this._load ||= new Promise((e) => {
              if (
                ((this._resolve = () => {
                  this.resize(this.source.width, this.source.height), e(this);
                }),
                oc.SVG_XML.test(this.svg.trim()))
              ) {
                if (!btoa)
                  throw Error(
                    `Your browser doesn't support base64 conversions.`
                  );
                this.svg = `data:image/svg+xml;base64,${btoa(
                  unescape(encodeURIComponent(this.svg))
                )}`;
              }
              this._loadSvg();
            })),
            this._load
          );
        }
        _loadSvg() {
          let e = new Image();
          ba.crossOrigin(e, this.svg, this._crossorigin),
            (e.src = this.svg),
            (e.onerror = (t) => {
              this._resolve && ((e.onerror = null), this.onError.emit(t));
            }),
            (e.onload = () => {
              if (!this._resolve) return;
              let t = e.width,
                n = e.height;
              if (!t || !n)
                throw Error(
                  `The SVG image must have width and height defined (in pixels), canvas API needs them.`
                );
              let r = t * this.scale,
                i = n * this.scale;
              (this._overrideWidth || this._overrideHeight) &&
                ((r = this._overrideWidth || (this._overrideHeight / n) * t),
                (i = this._overrideHeight || (this._overrideWidth / t) * n)),
                (r = Math.round(r)),
                (i = Math.round(i));
              let a = this.source;
              (a.width = r),
                (a.height = i),
                (a._pixiId = `canvas_${tn()}`),
                a.getContext(`2d`).drawImage(e, 0, 0, t, n, 0, 0, r, i),
                this._resolve(),
                (this._resolve = null);
            });
        }
        static getSize(e) {
          let t = oc.SVG_SIZE.exec(e),
            n = {};
          return (
            t &&
              ((n[t[1]] = Math.round(parseFloat(t[3]))),
              (n[t[5]] = Math.round(parseFloat(t[7])))),
            n
          );
        }
        dispose() {
          super.dispose(), (this._resolve = null), (this._crossorigin = null);
        }
        static test(e, t) {
          return (
            t === `svg` ||
            (typeof e == `string` && e.startsWith(`data:image/svg+xml`)) ||
            (typeof e == `string` && oc.SVG_XML.test(e))
          );
        }
      }),
      (sc = oc),
      (sc.SVG_XML = /^(<\?xml[^?]+\?>)?\s*(<!--[^(-->)]*-->)?\s*\<svg/m),
      (sc.SVG_SIZE =
        /<svg[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*(?:\s(width|height)=('|")(\d*(?:\.\d+)?)(?:px)?('|"))[^>]*>/i);
  }))();
}
var lc, uc;
function dc() {
  return (dc = t(() => {
    Ps(),
      xa(),
      (lc = class extends ba {
        constructor(e, t) {
          if (((t ||= {}), !(e instanceof HTMLVideoElement))) {
            let n = document.createElement(`video`);
            n.setAttribute(`preload`, `auto`),
              n.setAttribute(`webkit-playsinline`, ``),
              n.setAttribute(`playsinline`, ``),
              typeof e == `string` && (e = [e]);
            let r = e[0].src || e[0];
            ba.crossOrigin(n, r, t.crossorigin);
            for (let t = 0; t < e.length; ++t) {
              let r = document.createElement(`source`),
                { src: i, mime: a } = e[t];
              i ||= e[t];
              let o = i.split(`?`).shift().toLowerCase(),
                s = o.slice(o.lastIndexOf(`.`) + 1);
              (a = a || lc.MIME_TYPES[s] || `video/${s}`),
                (r.src = i),
                (r.type = a),
                n.appendChild(r);
            }
            e = n;
          }
          super(e),
            (this.noSubImage = !0),
            (this._autoUpdate = !0),
            (this._isConnectedToTicker = !1),
            (this._updateFPS = t.updateFPS || 0),
            (this._msToNextUpdate = 0),
            (this.autoPlay = t.autoPlay !== !1),
            (this._load = null),
            (this._resolve = null),
            (this._onCanPlay = this._onCanPlay.bind(this)),
            (this._onError = this._onError.bind(this)),
            t.autoLoad !== !1 && this.load();
        }
        update(e = 0) {
          if (!this.destroyed) {
            let e = ks.shared.elapsedMS * this.source.playbackRate;
            (this._msToNextUpdate = Math.floor(this._msToNextUpdate - e)),
              (!this._updateFPS || this._msToNextUpdate <= 0) &&
                (super.update(),
                (this._msToNextUpdate = this._updateFPS
                  ? Math.floor(1e3 / this._updateFPS)
                  : 0));
          }
        }
        load() {
          if (this._load) return this._load;
          let e = this.source;
          return (
            (e.readyState === e.HAVE_ENOUGH_DATA ||
              e.readyState === e.HAVE_FUTURE_DATA) &&
              e.width &&
              e.height &&
              (e.complete = !0),
            e.addEventListener(`play`, this._onPlayStart.bind(this)),
            e.addEventListener(`pause`, this._onPlayStop.bind(this)),
            this._isSourceReady()
              ? this._onCanPlay()
              : (e.addEventListener(`canplay`, this._onCanPlay),
                e.addEventListener(`canplaythrough`, this._onCanPlay),
                e.addEventListener(`error`, this._onError, !0)),
            (this._load = new Promise((t) => {
              this.valid ? t(this) : ((this._resolve = t), e.load());
            })),
            this._load
          );
        }
        _onError(e) {
          this.source.removeEventListener(`error`, this._onError, !0),
            this.onError.emit(e);
        }
        _isSourcePlaying() {
          let e = this.source;
          return !e.paused && !e.ended && this._isSourceReady();
        }
        _isSourceReady() {
          return this.source.readyState > 2;
        }
        _onPlayStart() {
          this.valid || this._onCanPlay(),
            this.autoUpdate &&
              !this._isConnectedToTicker &&
              (ks.shared.add(this.update, this),
              (this._isConnectedToTicker = !0));
        }
        _onPlayStop() {
          this._isConnectedToTicker &&=
            (ks.shared.remove(this.update, this), !1);
        }
        _onCanPlay() {
          let e = this.source;
          e.removeEventListener(`canplay`, this._onCanPlay),
            e.removeEventListener(`canplaythrough`, this._onCanPlay);
          let t = this.valid;
          this.resize(e.videoWidth, e.videoHeight),
            !t &&
              this._resolve &&
              (this._resolve(this), (this._resolve = null)),
            this._isSourcePlaying()
              ? this._onPlayStart()
              : this.autoPlay && e.play();
        }
        dispose() {
          this._isConnectedToTicker &&=
            (ks.shared.remove(this.update, this), !1);
          let e = this.source;
          e &&
            (e.removeEventListener(`error`, this._onError, !0),
            e.pause(),
            (e.src = ``),
            e.load()),
            super.dispose();
        }
        get autoUpdate() {
          return this._autoUpdate;
        }
        set autoUpdate(e) {
          e !== this._autoUpdate &&
            ((this._autoUpdate = e),
            !this._autoUpdate && this._isConnectedToTicker
              ? (ks.shared.remove(this.update, this),
                (this._isConnectedToTicker = !1))
              : this._autoUpdate &&
                !this._isConnectedToTicker &&
                this._isSourcePlaying() &&
                (ks.shared.add(this.update, this),
                (this._isConnectedToTicker = !0)));
        }
        get updateFPS() {
          return this._updateFPS;
        }
        set updateFPS(e) {
          e !== this._updateFPS && (this._updateFPS = e);
        }
        static test(e, t) {
          return (
            (globalThis.HTMLVideoElement && e instanceof HTMLVideoElement) ||
            lc.TYPES.includes(t)
          );
        }
      }),
      (uc = lc),
      (uc.TYPES = [`mp4`, `m4v`, `webm`, `ogg`, `ogv`, `h264`, `avi`, `mov`]),
      (uc.MIME_TYPES = {
        ogv: `video/ogg`,
        mov: `video/quicktime`,
        m4v: `video/mp4`,
      });
  }))();
}
function fc() {
  return (fc = t(() => {
    Qs(),
      Un(),
      Xn(),
      ec(),
      rc(),
      ac(),
      Ca(),
      cc(),
      dc(),
      xa(),
      Jn(),
      Xs(),
      Hn.push(ic, Sa, $s, uc, sc, Yn, nc, Zs);
  }))();
}
function pc() {
  return (pc = t(() => {
    Kn();
  }))();
}
function Z() {
  return (Z = t(() => {
    Cs(),
      Ot(),
      w(),
      V(),
      Y(),
      Kn(),
      N(),
      Ps(),
      R(),
      Ls(),
      ca(),
      tr(),
      hr(),
      $i(),
      Ri(),
      ua(),
      Bi(),
      Ki(),
      pa(),
      oa(),
      Ra(),
      Ha(),
      ro(),
      i(),
      _a(),
      qa(),
      zs(),
      rr(),
      Us(),
      pr(),
      Xa(),
      Pn(),
      ao(),
      so(),
      ho(),
      _o(),
      yo(),
      xo(),
      Gs(),
      Js(),
      ya(),
      wo(),
      Aa(),
      Ma(),
      Oo(),
      ji(),
      Ii(),
      qo(),
      Pi(),
      Rn(),
      Uo(),
      ci(),
      Yo(),
      Bn(),
      os(),
      Ss(),
      $n(),
      fc(),
      Oa(),
      ds(),
      $a(),
      _s(),
      Ta(),
      pc(),
      ys(),
      Pa(),
      Ia(),
      xs(),
      cs(),
      xa(),
      Jn(),
      Xs(),
      Qs(),
      Xn(),
      ec(),
      rc(),
      ac(),
      Ca(),
      cc(),
      dc();
  }))();
}
var mc;
function hc() {
  return (hc = t(() => {
    Z(),
      (mc = class {
        constructor() {
          (this.minX = 1 / 0),
            (this.minY = 1 / 0),
            (this.maxX = -1 / 0),
            (this.maxY = -1 / 0),
            (this.rect = null),
            (this.updateID = -1);
        }
        isEmpty() {
          return this.minX > this.maxX || this.minY > this.maxY;
        }
        clear() {
          (this.minX = 1 / 0),
            (this.minY = 1 / 0),
            (this.maxX = -1 / 0),
            (this.maxY = -1 / 0);
        }
        getRectangle(e) {
          return this.minX > this.maxX || this.minY > this.maxY
            ? K.EMPTY
            : ((e ||= new K(0, 0, 1, 1)),
              (e.x = this.minX),
              (e.y = this.minY),
              (e.width = this.maxX - this.minX),
              (e.height = this.maxY - this.minY),
              e);
        }
        addPoint(e) {
          (this.minX = Math.min(this.minX, e.x)),
            (this.maxX = Math.max(this.maxX, e.x)),
            (this.minY = Math.min(this.minY, e.y)),
            (this.maxY = Math.max(this.maxY, e.y));
        }
        addPointMatrix(e, t) {
          let { a: n, b: r, c: i, d: a, tx: o, ty: s } = e,
            c = n * t.x + i * t.y + o,
            l = r * t.x + a * t.y + s;
          (this.minX = Math.min(this.minX, c)),
            (this.maxX = Math.max(this.maxX, c)),
            (this.minY = Math.min(this.minY, l)),
            (this.maxY = Math.max(this.maxY, l));
        }
        addQuad(e) {
          let t = this.minX,
            n = this.minY,
            r = this.maxX,
            i = this.maxY,
            a = e[0],
            o = e[1];
          (t = a < t ? a : t),
            (n = o < n ? o : n),
            (r = a > r ? a : r),
            (i = o > i ? o : i),
            (a = e[2]),
            (o = e[3]),
            (t = a < t ? a : t),
            (n = o < n ? o : n),
            (r = a > r ? a : r),
            (i = o > i ? o : i),
            (a = e[4]),
            (o = e[5]),
            (t = a < t ? a : t),
            (n = o < n ? o : n),
            (r = a > r ? a : r),
            (i = o > i ? o : i),
            (a = e[6]),
            (o = e[7]),
            (t = a < t ? a : t),
            (n = o < n ? o : n),
            (r = a > r ? a : r),
            (i = o > i ? o : i),
            (this.minX = t),
            (this.minY = n),
            (this.maxX = r),
            (this.maxY = i);
        }
        addFrame(e, t, n, r, i) {
          this.addFrameMatrix(e.worldTransform, t, n, r, i);
        }
        addFrameMatrix(e, t, n, r, i) {
          let a = e.a,
            o = e.b,
            s = e.c,
            c = e.d,
            l = e.tx,
            u = e.ty,
            d = this.minX,
            f = this.minY,
            p = this.maxX,
            m = this.maxY,
            h = a * t + s * n + l,
            g = o * t + c * n + u;
          (d = h < d ? h : d),
            (f = g < f ? g : f),
            (p = h > p ? h : p),
            (m = g > m ? g : m),
            (h = a * r + s * n + l),
            (g = o * r + c * n + u),
            (d = h < d ? h : d),
            (f = g < f ? g : f),
            (p = h > p ? h : p),
            (m = g > m ? g : m),
            (h = a * t + s * i + l),
            (g = o * t + c * i + u),
            (d = h < d ? h : d),
            (f = g < f ? g : f),
            (p = h > p ? h : p),
            (m = g > m ? g : m),
            (h = a * r + s * i + l),
            (g = o * r + c * i + u),
            (d = h < d ? h : d),
            (f = g < f ? g : f),
            (p = h > p ? h : p),
            (m = g > m ? g : m),
            (this.minX = d),
            (this.minY = f),
            (this.maxX = p),
            (this.maxY = m);
        }
        addVertexData(e, t, n) {
          let r = this.minX,
            i = this.minY,
            a = this.maxX,
            o = this.maxY;
          for (let s = t; s < n; s += 2) {
            let t = e[s],
              n = e[s + 1];
            (r = t < r ? t : r),
              (i = n < i ? n : i),
              (a = t > a ? t : a),
              (o = n > o ? n : o);
          }
          (this.minX = r), (this.minY = i), (this.maxX = a), (this.maxY = o);
        }
        addVertices(e, t, n, r) {
          this.addVerticesMatrix(e.worldTransform, t, n, r);
        }
        addVerticesMatrix(e, t, n, r, i = 0, a = i) {
          let o = e.a,
            s = e.b,
            c = e.c,
            l = e.d,
            u = e.tx,
            d = e.ty,
            f = this.minX,
            p = this.minY,
            m = this.maxX,
            h = this.maxY;
          for (let e = n; e < r; e += 2) {
            let n = t[e],
              r = t[e + 1],
              g = o * n + c * r + u,
              _ = l * r + s * n + d;
            (f = Math.min(f, g - i)),
              (m = Math.max(m, g + i)),
              (p = Math.min(p, _ - a)),
              (h = Math.max(h, _ + a));
          }
          (this.minX = f), (this.minY = p), (this.maxX = m), (this.maxY = h);
        }
        addBounds(e) {
          let t = this.minX,
            n = this.minY,
            r = this.maxX,
            i = this.maxY;
          (this.minX = e.minX < t ? e.minX : t),
            (this.minY = e.minY < n ? e.minY : n),
            (this.maxX = e.maxX > r ? e.maxX : r),
            (this.maxY = e.maxY > i ? e.maxY : i);
        }
        addBoundsMask(e, t) {
          let n = e.minX > t.minX ? e.minX : t.minX,
            r = e.minY > t.minY ? e.minY : t.minY,
            i = e.maxX < t.maxX ? e.maxX : t.maxX,
            a = e.maxY < t.maxY ? e.maxY : t.maxY;
          if (n <= i && r <= a) {
            let e = this.minX,
              t = this.minY,
              o = this.maxX,
              s = this.maxY;
            (this.minX = n < e ? n : e),
              (this.minY = r < t ? r : t),
              (this.maxX = i > o ? i : o),
              (this.maxY = a > s ? a : s);
          }
        }
        addBoundsMatrix(e, t) {
          this.addFrameMatrix(t, e.minX, e.minY, e.maxX, e.maxY);
        }
        addBoundsArea(e, t) {
          let n = e.minX > t.x ? e.minX : t.x,
            r = e.minY > t.y ? e.minY : t.y,
            i = e.maxX < t.x + t.width ? e.maxX : t.x + t.width,
            a = e.maxY < t.y + t.height ? e.maxY : t.y + t.height;
          if (n <= i && r <= a) {
            let e = this.minX,
              t = this.minY,
              o = this.maxX,
              s = this.maxY;
            (this.minX = n < e ? n : e),
              (this.minY = r < t ? r : t),
              (this.maxX = i > o ? i : o),
              (this.maxY = a > s ? a : s);
          }
        }
        pad(e = 0, t = e) {
          this.isEmpty() ||
            ((this.minX -= e),
            (this.maxX += e),
            (this.minY -= t),
            (this.maxY += t));
        }
        addFramePad(e, t, n, r, i, a) {
          (e -= i),
            (t -= a),
            (n += i),
            (r += a),
            (this.minX = this.minX < e ? this.minX : e),
            (this.maxX = this.maxX > n ? this.maxX : n),
            (this.minY = this.minY < t ? this.minY : t),
            (this.maxY = this.maxY > r ? this.maxY : r);
        }
      });
  }))();
}
var gc, _c;
function vc() {
  return (vc = t(() => {
    Z(),
      hc(),
      (gc = class e extends kn.default {
        constructor() {
          super(),
            (this.tempDisplayObjectParent = null),
            (this.transform = new Wr()),
            (this.alpha = 1),
            (this.visible = !0),
            (this.renderable = !0),
            (this.cullable = !1),
            (this.cullArea = null),
            (this.parent = null),
            (this.worldAlpha = 1),
            (this._lastSortedIndex = 0),
            (this._zIndex = 0),
            (this.filterArea = null),
            (this.filters = null),
            (this._enabledFilters = null),
            (this._bounds = new mc()),
            (this._localBounds = null),
            (this._boundsID = 0),
            (this._boundsRect = null),
            (this._localBoundsRect = null),
            (this._mask = null),
            (this._maskRefCount = 0),
            (this._destroyed = !1),
            (this.isSprite = !1),
            (this.isMask = !1);
        }
        static mixin(t) {
          let n = Object.keys(t);
          for (let r = 0; r < n.length; ++r) {
            let i = n[r];
            Object.defineProperty(
              e.prototype,
              i,
              Object.getOwnPropertyDescriptor(t, i)
            );
          }
        }
        get destroyed() {
          return this._destroyed;
        }
        _recursivePostUpdateTransform() {
          this.parent
            ? (this.parent._recursivePostUpdateTransform(),
              this.transform.updateTransform(this.parent.transform))
            : this.transform.updateTransform(
                this._tempDisplayObjectParent.transform
              );
        }
        updateTransform() {
          this._boundsID++,
            this.transform.updateTransform(this.parent.transform),
            (this.worldAlpha = this.alpha * this.parent.worldAlpha);
        }
        getBounds(e, t) {
          return (
            e ||
              (this.parent
                ? (this._recursivePostUpdateTransform(), this.updateTransform())
                : ((this.parent = this._tempDisplayObjectParent),
                  this.updateTransform(),
                  (this.parent = null))),
            this._bounds.updateID !== this._boundsID &&
              (this.calculateBounds(),
              (this._bounds.updateID = this._boundsID)),
            (t ||= ((this._boundsRect ||= new K()), this._boundsRect)),
            this._bounds.getRectangle(t)
          );
        }
        getLocalBounds(e) {
          (e ||= ((this._localBoundsRect ||= new K()), this._localBoundsRect)),
            (this._localBounds ||= new mc());
          let t = this.transform,
            n = this.parent;
          (this.parent = null),
            (this.transform = this._tempDisplayObjectParent.transform);
          let r = this._bounds,
            i = this._boundsID;
          this._bounds = this._localBounds;
          let a = this.getBounds(!1, e);
          return (
            (this.parent = n),
            (this.transform = t),
            (this._bounds = r),
            (this._bounds.updateID += this._boundsID - i),
            a
          );
        }
        toGlobal(e, t, n = !1) {
          return (
            n ||
              (this._recursivePostUpdateTransform(),
              this.parent
                ? this.displayObjectUpdateTransform()
                : ((this.parent = this._tempDisplayObjectParent),
                  this.displayObjectUpdateTransform(),
                  (this.parent = null))),
            this.worldTransform.apply(e, t)
          );
        }
        toLocal(e, t, n, r) {
          return (
            t && (e = t.toGlobal(e, n, r)),
            r ||
              (this._recursivePostUpdateTransform(),
              this.parent
                ? this.displayObjectUpdateTransform()
                : ((this.parent = this._tempDisplayObjectParent),
                  this.displayObjectUpdateTransform(),
                  (this.parent = null))),
            this.worldTransform.applyInverse(e, n)
          );
        }
        setParent(e) {
          if (!e || !e.addChild)
            throw Error(`setParent: Argument must be a Container`);
          return e.addChild(this), e;
        }
        removeFromParent() {
          this.parent?.removeChild(this);
        }
        setTransform(
          e = 0,
          t = 0,
          n = 1,
          r = 1,
          i = 0,
          a = 0,
          o = 0,
          s = 0,
          c = 0
        ) {
          return (
            (this.position.x = e),
            (this.position.y = t),
            (this.scale.x = n || 1),
            (this.scale.y = r || 1),
            (this.rotation = i),
            (this.skew.x = a),
            (this.skew.y = o),
            (this.pivot.x = s),
            (this.pivot.y = c),
            this
          );
        }
        destroy(e) {
          this.removeFromParent(),
            (this._destroyed = !0),
            (this.transform = null),
            (this.parent = null),
            (this._bounds = null),
            (this.mask = null),
            (this.cullArea = null),
            (this.filters = null),
            (this.filterArea = null),
            (this.hitArea = null),
            (this.eventMode = `auto`),
            (this.interactiveChildren = !1),
            this.emit(`destroyed`),
            this.removeAllListeners();
        }
        get _tempDisplayObjectParent() {
          return (
            this.tempDisplayObjectParent === null &&
              (this.tempDisplayObjectParent = new _c()),
            this.tempDisplayObjectParent
          );
        }
        enableTempParent() {
          let e = this.parent;
          return (this.parent = this._tempDisplayObjectParent), e;
        }
        disableTempParent(e) {
          this.parent = e;
        }
        get x() {
          return this.position.x;
        }
        set x(e) {
          this.transform.position.x = e;
        }
        get y() {
          return this.position.y;
        }
        set y(e) {
          this.transform.position.y = e;
        }
        get worldTransform() {
          return this.transform.worldTransform;
        }
        get localTransform() {
          return this.transform.localTransform;
        }
        get position() {
          return this.transform.position;
        }
        set position(e) {
          this.transform.position.copyFrom(e);
        }
        get scale() {
          return this.transform.scale;
        }
        set scale(e) {
          this.transform.scale.copyFrom(e);
        }
        get pivot() {
          return this.transform.pivot;
        }
        set pivot(e) {
          this.transform.pivot.copyFrom(e);
        }
        get skew() {
          return this.transform.skew;
        }
        set skew(e) {
          this.transform.skew.copyFrom(e);
        }
        get rotation() {
          return this.transform.rotation;
        }
        set rotation(e) {
          this.transform.rotation = e;
        }
        get angle() {
          return this.transform.rotation * _r;
        }
        set angle(e) {
          this.transform.rotation = e * vr;
        }
        get zIndex() {
          return this._zIndex;
        }
        set zIndex(e) {
          (this._zIndex = e), this.parent && (this.parent.sortDirty = !0);
        }
        get worldVisible() {
          let e = this;
          do {
            if (!e.visible) return !1;
            e = e.parent;
          } while (e);
          return !0;
        }
        get mask() {
          return this._mask;
        }
        set mask(e) {
          if (this._mask !== e) {
            if (this._mask) {
              let e = this._mask.isMaskData
                ? this._mask.maskObject
                : this._mask;
              e &&
                (e._maskRefCount--,
                e._maskRefCount === 0 &&
                  ((e.renderable = !0), (e.isMask = !1)));
            }
            if (((this._mask = e), this._mask)) {
              let e = this._mask.isMaskData
                ? this._mask.maskObject
                : this._mask;
              e &&
                (e._maskRefCount === 0 &&
                  ((e.renderable = !1), (e.isMask = !0)),
                e._maskRefCount++);
            }
          }
        }
      }),
      (_c = class extends gc {
        constructor() {
          super(...arguments), (this.sortDirty = null);
        }
      }),
      (gc.prototype.displayObjectUpdateTransform =
        gc.prototype.updateTransform);
  }))();
}
function yc(e, t) {
  return e.zIndex === t.zIndex
    ? e._lastSortedIndex - t._lastSortedIndex
    : e.zIndex - t.zIndex;
}
var bc, xc, Sc;
function Cc() {
  return (Cc = t(() => {
    Z(),
      vc(),
      (bc = new q()),
      (xc = class extends gc {
        constructor() {
          super(),
            (this.children = []),
            (this.sortableChildren = xc.defaultSortableChildren),
            (this.sortDirty = !1);
        }
        onChildrenChange(e) {}
        addChild(...e) {
          if (e.length > 1)
            for (let t = 0; t < e.length; t++) this.addChild(e[t]);
          else {
            let t = e[0];
            t.parent && t.parent.removeChild(t),
              (t.parent = this),
              (this.sortDirty = !0),
              (t.transform._parentID = -1),
              this.children.push(t),
              this._boundsID++,
              this.onChildrenChange(this.children.length - 1),
              this.emit(`childAdded`, t, this, this.children.length - 1),
              t.emit(`added`, this);
          }
          return e[0];
        }
        addChildAt(e, t) {
          if (t < 0 || t > this.children.length)
            throw Error(
              `${e}addChildAt: The index ${t} supplied is out of bounds ${this.children.length}`
            );
          return (
            e.parent && e.parent.removeChild(e),
            (e.parent = this),
            (this.sortDirty = !0),
            (e.transform._parentID = -1),
            this.children.splice(t, 0, e),
            this._boundsID++,
            this.onChildrenChange(t),
            e.emit(`added`, this),
            this.emit(`childAdded`, e, this, t),
            e
          );
        }
        swapChildren(e, t) {
          if (e === t) return;
          let n = this.getChildIndex(e),
            r = this.getChildIndex(t);
          (this.children[n] = t),
            (this.children[r] = e),
            this.onChildrenChange(n < r ? n : r);
        }
        getChildIndex(e) {
          let t = this.children.indexOf(e);
          if (t === -1)
            throw Error(
              `The supplied DisplayObject must be a child of the caller`
            );
          return t;
        }
        setChildIndex(e, t) {
          if (t < 0 || t >= this.children.length)
            throw Error(
              `The index ${t} supplied is out of bounds ${this.children.length}`
            );
          let n = this.getChildIndex(e);
          Zt(this.children, n, 1),
            this.children.splice(t, 0, e),
            this.onChildrenChange(t);
        }
        getChildAt(e) {
          if (e < 0 || e >= this.children.length)
            throw Error(`getChildAt: Index (${e}) does not exist.`);
          return this.children[e];
        }
        removeChild(...e) {
          if (e.length > 1)
            for (let t = 0; t < e.length; t++) this.removeChild(e[t]);
          else {
            let t = e[0],
              n = this.children.indexOf(t);
            if (n === -1) return null;
            (t.parent = null),
              (t.transform._parentID = -1),
              Zt(this.children, n, 1),
              this._boundsID++,
              this.onChildrenChange(n),
              t.emit(`removed`, this),
              this.emit(`childRemoved`, t, this, n);
          }
          return e[0];
        }
        removeChildAt(e) {
          let t = this.getChildAt(e);
          return (
            (t.parent = null),
            (t.transform._parentID = -1),
            Zt(this.children, e, 1),
            this._boundsID++,
            this.onChildrenChange(e),
            t.emit(`removed`, this),
            this.emit(`childRemoved`, t, this, e),
            t
          );
        }
        removeChildren(e = 0, t = this.children.length) {
          let n = e,
            r = t,
            i = r - n,
            a;
          if (i > 0 && i <= r) {
            a = this.children.splice(n, i);
            for (let e = 0; e < a.length; ++e)
              (a[e].parent = null),
                a[e].transform && (a[e].transform._parentID = -1);
            this._boundsID++, this.onChildrenChange(e);
            for (let e = 0; e < a.length; ++e)
              a[e].emit(`removed`, this),
                this.emit(`childRemoved`, a[e], this, e);
            return a;
          }
          if (i === 0 && this.children.length === 0) return [];
          throw RangeError(
            `removeChildren: numeric values are outside the acceptable range.`
          );
        }
        sortChildren() {
          let e = !1;
          for (let t = 0, n = this.children.length; t < n; ++t) {
            let n = this.children[t];
            (n._lastSortedIndex = t), !e && n.zIndex !== 0 && (e = !0);
          }
          e && this.children.length > 1 && this.children.sort(yc),
            (this.sortDirty = !1);
        }
        updateTransform() {
          this.sortableChildren && this.sortDirty && this.sortChildren(),
            this._boundsID++,
            this.transform.updateTransform(this.parent.transform),
            (this.worldAlpha = this.alpha * this.parent.worldAlpha);
          for (let e = 0, t = this.children.length; e < t; ++e) {
            let t = this.children[e];
            t.visible && t.updateTransform();
          }
        }
        calculateBounds() {
          this._bounds.clear(), this._calculateBounds();
          for (let e = 0; e < this.children.length; e++) {
            let t = this.children[e];
            if (!(!t.visible || !t.renderable))
              if ((t.calculateBounds(), t._mask)) {
                let e = t._mask.isMaskData ? t._mask.maskObject : t._mask;
                e
                  ? (e.calculateBounds(),
                    this._bounds.addBoundsMask(t._bounds, e._bounds))
                  : this._bounds.addBounds(t._bounds);
              } else
                t.filterArea
                  ? this._bounds.addBoundsArea(t._bounds, t.filterArea)
                  : this._bounds.addBounds(t._bounds);
          }
          this._bounds.updateID = this._boundsID;
        }
        getLocalBounds(e, t = !1) {
          let n = super.getLocalBounds(e);
          if (!t)
            for (let e = 0, t = this.children.length; e < t; ++e) {
              let t = this.children[e];
              t.visible && t.updateTransform();
            }
          return n;
        }
        _calculateBounds() {}
        _renderWithCulling(e) {
          let t = e.renderTexture.sourceFrame;
          if (!(t.width > 0 && t.height > 0)) return;
          let n, r;
          this.cullArea
            ? ((n = this.cullArea), (r = this.worldTransform))
            : this._render !== xc.prototype._render && (n = this.getBounds(!0));
          let i = e.projection.transform;
          if (
            (i && (r ? ((r = bc.copyFrom(r)), r.prepend(i)) : (r = i)),
            n && t.intersects(n, r))
          )
            this._render(e);
          else if (this.cullArea) return;
          for (let t = 0, n = this.children.length; t < n; ++t) {
            let n = this.children[t],
              r = n.cullable;
            (n.cullable = r || !this.cullArea), n.render(e), (n.cullable = r);
          }
        }
        render(e) {
          if (!(!this.visible || this.worldAlpha <= 0 || !this.renderable))
            if (this._mask || this.filters?.length) this.renderAdvanced(e);
            else if (this.cullable) this._renderWithCulling(e);
            else {
              this._render(e);
              for (let t = 0, n = this.children.length; t < n; ++t)
                this.children[t].render(e);
            }
        }
        renderAdvanced(e) {
          let t = this.filters,
            n = this._mask;
          if (t) {
            (this._enabledFilters ||= []), (this._enabledFilters.length = 0);
            for (let e = 0; e < t.length; e++)
              t[e].enabled && this._enabledFilters.push(t[e]);
          }
          let r =
            (t && this._enabledFilters?.length) ||
            (n &&
              (!n.isMaskData ||
                (n.enabled && (n.autoDetect || n.type !== x.NONE))));
          if (
            (r && e.batch.flush(),
            t &&
              this._enabledFilters?.length &&
              e.filter.push(this, this._enabledFilters),
            n && e.mask.push(this, this._mask),
            this.cullable)
          )
            this._renderWithCulling(e);
          else {
            this._render(e);
            for (let t = 0, n = this.children.length; t < n; ++t)
              this.children[t].render(e);
          }
          r && e.batch.flush(),
            n && e.mask.pop(this),
            t && this._enabledFilters?.length && e.filter.pop();
        }
        _render(e) {}
        destroy(e) {
          super.destroy(), (this.sortDirty = !1);
          let t = typeof e == `boolean` ? e : e?.children,
            n = this.removeChildren(0, this.children.length);
          if (t) for (let t = 0; t < n.length; ++t) n[t].destroy(e);
        }
        get width() {
          return this.scale.x * this.getLocalBounds().width;
        }
        set width(e) {
          let t = this.getLocalBounds().width;
          t === 0 ? (this.scale.x = 1) : (this.scale.x = e / t),
            (this._width = e);
        }
        get height() {
          return this.scale.y * this.getLocalBounds().height;
        }
        set height(e) {
          let t = this.getLocalBounds().height;
          t === 0 ? (this.scale.y = 1) : (this.scale.y = e / t),
            (this._height = e);
        }
      }),
      (Sc = xc),
      (Sc.defaultSortableChildren = !1),
      (Sc.prototype.containerUpdateTransform = Sc.prototype.updateTransform);
  }))();
}
function wc() {
  return (wc = t(() => {
    Z(),
      Cc(),
      Object.defineProperties(D, {
        SORTABLE_CHILDREN: {
          get() {
            return Sc.defaultSortableChildren;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.SORTABLE_CHILDREN is deprecated, use Container.defaultSortableChildren`
            ),
              (Sc.defaultSortableChildren = e);
          },
        },
      });
  }))();
}
function Tc() {
  return (Tc = t(() => {
    wc(), hc(), Cc(), vc();
  }))();
}
var Ec, Dc, Oc;
function kc() {
  return (kc = t(() => {
    Z(),
      Tc(),
      (Ec = new G()),
      (Dc = new Uint16Array([0, 1, 2, 0, 2, 3])),
      (Oc = class e extends Sc {
        constructor(e) {
          super(),
            (this._anchor = new Vr(
              this._onAnchorUpdate,
              this,
              e ? e.defaultAnchor.x : 0,
              e ? e.defaultAnchor.y : 0
            )),
            (this._texture = null),
            (this._width = 0),
            (this._height = 0),
            (this._tintColor = new I(16777215)),
            (this._tintRGB = null),
            (this.tint = 16777215),
            (this.blendMode = c.NORMAL),
            (this._cachedTint = 16777215),
            (this.uvs = null),
            (this.texture = e || X.EMPTY),
            (this.vertexData = new Float32Array(8)),
            (this.vertexTrimmedData = null),
            (this._transformID = -1),
            (this._textureID = -1),
            (this._transformTrimmedID = -1),
            (this._textureTrimmedID = -1),
            (this.indices = Dc),
            (this.pluginName = `batch`),
            (this.isSprite = !0),
            (this._roundPixels = D.ROUND_PIXELS);
        }
        _onTextureUpdate() {
          (this._textureID = -1),
            (this._textureTrimmedID = -1),
            (this._cachedTint = 16777215),
            this._width &&
              (this.scale.x =
                ($t(this.scale.x) * this._width) / this._texture.orig.width),
            this._height &&
              (this.scale.y =
                ($t(this.scale.y) * this._height) / this._texture.orig.height);
        }
        _onAnchorUpdate() {
          (this._transformID = -1), (this._transformTrimmedID = -1);
        }
        calculateVertices() {
          let e = this._texture;
          if (
            this._transformID === this.transform._worldID &&
            this._textureID === e._updateID
          )
            return;
          this._textureID !== e._updateID &&
            (this.uvs = this._texture._uvs.uvsFloat32),
            (this._transformID = this.transform._worldID),
            (this._textureID = e._updateID);
          let t = this.transform.worldTransform,
            n = t.a,
            r = t.b,
            i = t.c,
            a = t.d,
            o = t.tx,
            s = t.ty,
            c = this.vertexData,
            l = e.trim,
            u = e.orig,
            d = this._anchor,
            f = 0,
            p = 0,
            m = 0,
            h = 0;
          if (
            (l
              ? ((p = l.x - d._x * u.width),
                (f = p + l.width),
                (h = l.y - d._y * u.height),
                (m = h + l.height))
              : ((p = -d._x * u.width),
                (f = p + u.width),
                (h = -d._y * u.height),
                (m = h + u.height)),
            (c[0] = n * p + i * h + o),
            (c[1] = a * h + r * p + s),
            (c[2] = n * f + i * h + o),
            (c[3] = a * h + r * f + s),
            (c[4] = n * f + i * m + o),
            (c[5] = a * m + r * f + s),
            (c[6] = n * p + i * m + o),
            (c[7] = a * m + r * p + s),
            this._roundPixels)
          ) {
            let e = D.RESOLUTION;
            for (let t = 0; t < c.length; ++t) c[t] = Math.round(c[t] * e) / e;
          }
        }
        calculateTrimmedVertices() {
          if (!this.vertexTrimmedData)
            this.vertexTrimmedData = new Float32Array(8);
          else if (
            this._transformTrimmedID === this.transform._worldID &&
            this._textureTrimmedID === this._texture._updateID
          )
            return;
          (this._transformTrimmedID = this.transform._worldID),
            (this._textureTrimmedID = this._texture._updateID);
          let e = this._texture,
            t = this.vertexTrimmedData,
            n = e.orig,
            r = this._anchor,
            i = this.transform.worldTransform,
            a = i.a,
            o = i.b,
            s = i.c,
            c = i.d,
            l = i.tx,
            u = i.ty,
            d = -r._x * n.width,
            f = d + n.width,
            p = -r._y * n.height,
            m = p + n.height;
          (t[0] = a * d + s * p + l),
            (t[1] = c * p + o * d + u),
            (t[2] = a * f + s * p + l),
            (t[3] = c * p + o * f + u),
            (t[4] = a * f + s * m + l),
            (t[5] = c * m + o * f + u),
            (t[6] = a * d + s * m + l),
            (t[7] = c * m + o * d + u);
        }
        _render(e) {
          this.calculateVertices(),
            e.batch.setObjectRenderer(e.plugins[this.pluginName]),
            e.plugins[this.pluginName].render(this);
        }
        _calculateBounds() {
          let e = this._texture.trim,
            t = this._texture.orig;
          !e || (e.width === t.width && e.height === t.height)
            ? (this.calculateVertices(), this._bounds.addQuad(this.vertexData))
            : (this.calculateTrimmedVertices(),
              this._bounds.addQuad(this.vertexTrimmedData));
        }
        getLocalBounds(e) {
          return this.children.length === 0
            ? ((this._localBounds ||= new mc()),
              (this._localBounds.minX =
                this._texture.orig.width * -this._anchor._x),
              (this._localBounds.minY =
                this._texture.orig.height * -this._anchor._y),
              (this._localBounds.maxX =
                this._texture.orig.width * (1 - this._anchor._x)),
              (this._localBounds.maxY =
                this._texture.orig.height * (1 - this._anchor._y)),
              (e ||=
                ((this._localBoundsRect ||= new K()), this._localBoundsRect)),
              this._localBounds.getRectangle(e))
            : super.getLocalBounds.call(this, e);
        }
        containsPoint(e) {
          this.worldTransform.applyInverse(e, Ec);
          let t = this._texture.orig.width,
            n = this._texture.orig.height,
            r = -t * this.anchor.x,
            i = 0;
          return (
            Ec.x >= r &&
            Ec.x < r + t &&
            ((i = -n * this.anchor.y), Ec.y >= i && Ec.y < i + n)
          );
        }
        destroy(e) {
          if (
            (super.destroy(e),
            this._texture.off(`update`, this._onTextureUpdate, this),
            (this._anchor = null),
            typeof e == `boolean` ? e : e?.texture)
          ) {
            let t = typeof e == `boolean` ? e : e?.baseTexture;
            this._texture.destroy(!!t);
          }
          this._texture = null;
        }
        static from(t, n) {
          let r = t instanceof X ? t : X.from(t, n);
          return new e(r);
        }
        set roundPixels(e) {
          this._roundPixels !== e && (this._transformID = -1),
            (this._roundPixels = e);
        }
        get roundPixels() {
          return this._roundPixels;
        }
        get width() {
          return Math.abs(this.scale.x) * this._texture.orig.width;
        }
        set width(e) {
          let t = $t(this.scale.x) || 1;
          (this.scale.x = (t * e) / this._texture.orig.width),
            (this._width = e);
        }
        get height() {
          return Math.abs(this.scale.y) * this._texture.orig.height;
        }
        set height(e) {
          let t = $t(this.scale.y) || 1;
          (this.scale.y = (t * e) / this._texture.orig.height),
            (this._height = e);
        }
        get anchor() {
          return this._anchor;
        }
        set anchor(e) {
          this._anchor.copyFrom(e);
        }
        get tint() {
          return this._tintColor.value;
        }
        set tint(e) {
          this._tintColor.setValue(e),
            (this._tintRGB = this._tintColor.toLittleEndianNumber());
        }
        get tintValue() {
          return this._tintColor.toNumber();
        }
        get texture() {
          return this._texture;
        }
        set texture(e) {
          this._texture !== e &&
            (this._texture &&
              this._texture.off(`update`, this._onTextureUpdate, this),
            (this._texture = e || X.EMPTY),
            (this._cachedTint = 16777215),
            (this._textureID = -1),
            (this._textureTrimmedID = -1),
            e &&
              (e.baseTexture.valid
                ? this._onTextureUpdate()
                : e.once(`update`, this._onTextureUpdate, this)));
        }
      });
  }))();
}
function Ac() {
  return (Ac = t(() => {
    kc();
  }))();
}
var jc;
function Mc() {
  return (Mc = t(() => {
    Z(),
      (jc = {
        build(e) {
          let t = e.points,
            n,
            r,
            i,
            a,
            o,
            s;
          if (e.type === W.CIRC) {
            let t = e.shape;
            (n = t.x), (r = t.y), (o = s = t.radius), (i = a = 0);
          } else if (e.type === W.ELIP) {
            let t = e.shape;
            (n = t.x), (r = t.y), (o = t.width), (s = t.height), (i = a = 0);
          } else {
            let t = e.shape,
              c = t.width / 2,
              l = t.height / 2;
            (n = t.x + c),
              (r = t.y + l),
              (o = s = Math.max(0, Math.min(t.radius, Math.min(c, l)))),
              (i = c - o),
              (a = l - s);
          }
          if (!(o >= 0 && s >= 0 && i >= 0 && a >= 0)) {
            t.length = 0;
            return;
          }
          let c = Math.ceil(2.3 * Math.sqrt(o + s)),
            l = c * 8 + (i ? 4 : 0) + (a ? 4 : 0);
          if (((t.length = l), l === 0)) return;
          if (c === 0) {
            (t.length = 8),
              (t[0] = t[6] = n + i),
              (t[1] = t[3] = r + a),
              (t[2] = t[4] = n - i),
              (t[5] = t[7] = r - a);
            return;
          }
          let u = 0,
            d = c * 4 + (i ? 2 : 0) + 2,
            f = d,
            p = l;
          {
            let e = i + o,
              s = a,
              c = n + e,
              l = n - e,
              m = r + s;
            if (((t[u++] = c), (t[u++] = m), (t[--d] = m), (t[--d] = l), a)) {
              let e = r - s;
              (t[f++] = l), (t[f++] = e), (t[--p] = e), (t[--p] = c);
            }
          }
          for (let e = 1; e < c; e++) {
            let l = (Math.PI / 2) * (e / c),
              m = i + Math.cos(l) * o,
              h = a + Math.sin(l) * s,
              g = n + m,
              _ = n - m,
              v = r + h,
              y = r - h;
            (t[u++] = g),
              (t[u++] = v),
              (t[--d] = v),
              (t[--d] = _),
              (t[f++] = _),
              (t[f++] = y),
              (t[--p] = y),
              (t[--p] = g);
          }
          {
            let e = i,
              o = a + s,
              c = n + e,
              l = n - e,
              d = r + o,
              f = r - o;
            (t[u++] = c),
              (t[u++] = d),
              (t[--p] = f),
              (t[--p] = c),
              i && ((t[u++] = l), (t[u++] = d), (t[--p] = f), (t[--p] = l));
          }
        },
        triangulate(e, t) {
          let n = e.points,
            r = t.points,
            i = t.indices;
          if (n.length === 0) return;
          let a = r.length / 2,
            o = a,
            s,
            c;
          if (e.type !== W.RREC) {
            let t = e.shape;
            (s = t.x), (c = t.y);
          } else {
            let t = e.shape;
            (s = t.x + t.width / 2), (c = t.y + t.height / 2);
          }
          let l = e.matrix;
          r.push(
            e.matrix ? l.a * s + l.c * c + l.tx : s,
            e.matrix ? l.b * s + l.d * c + l.ty : c
          ),
            a++,
            r.push(n[0], n[1]);
          for (let e = 2; e < n.length; e += 2)
            r.push(n[e], n[e + 1]), i.push(a++, o, a);
          i.push(o + 1, o, a);
        },
      });
  }))();
}
function Nc(e, t = !1) {
  let n = e.length;
  if (n < 6) return;
  let r = 0;
  for (let t = 0, i = e[n - 2], a = e[n - 1]; t < n; t += 2) {
    let n = e[t],
      o = e[t + 1];
    (r += (n - i) * (o + a)), (i = n), (a = o);
  }
  if ((!t && r > 0) || (t && r <= 0)) {
    let t = n / 2;
    for (let r = t + (t % 2); r < n; r += 2) {
      let t = n - r - 2,
        i = n - r - 1,
        a = r,
        o = r + 1;
      ([e[t], e[a]] = [e[a], e[t]]), ([e[i], e[o]] = [e[o], e[i]]);
    }
  }
}
var Pc;
function Fc() {
  return (Fc = t(() => {
    Z(),
      (Pc = {
        build(e) {
          e.points = e.shape.points.slice();
        },
        triangulate(e, t) {
          let n = e.points,
            r = e.holes,
            i = t.points,
            a = t.indices;
          if (n.length >= 6) {
            Nc(n, !1);
            let e = [];
            for (let t = 0; t < r.length; t++) {
              let i = r[t];
              Nc(i.points, !0), e.push(n.length / 2), (n = n.concat(i.points));
            }
            let t = An.default(n, e, 2);
            if (!t) return;
            let o = i.length / 2;
            for (let e = 0; e < t.length; e += 3)
              a.push(t[e] + o), a.push(t[e + 1] + o), a.push(t[e + 2] + o);
            for (let e = 0; e < n.length; e++) i.push(n[e]);
          }
        },
      });
  }))();
}
var Ic;
function Lc() {
  return (Lc = t(() => {
    Ic = {
      build(e) {
        let t = e.shape,
          n = t.x,
          r = t.y,
          i = t.width,
          a = t.height,
          o = e.points;
        (o.length = 0),
          i >= 0 && a >= 0 && o.push(n, r, n + i, r, n + i, r + a, n, r + a);
      },
      triangulate(e, t) {
        let n = e.points,
          r = t.points;
        if (n.length === 0) return;
        let i = r.length / 2;
        r.push(n[0], n[1], n[2], n[3], n[6], n[7], n[4], n[5]),
          t.indices.push(i, i + 1, i + 2, i + 1, i + 2, i + 3);
      },
    };
  }))();
}
var Rc;
function zc() {
  return (zc = t(() => {
    Mc(),
      (Rc = {
        build(e) {
          jc.build(e);
        },
        triangulate(e, t) {
          jc.triangulate(e, t);
        },
      });
  }))();
}
var Bc, Vc, Hc;
function Uc() {
  return (Uc = t(() => {
    (Bc = ((e) => (
      (e.MITER = `miter`), (e.BEVEL = `bevel`), (e.ROUND = `round`), e
    ))(Bc || {})),
      (Vc = ((e) => (
        (e.BUTT = `butt`), (e.ROUND = `round`), (e.SQUARE = `square`), e
      ))(Vc || {})),
      (Hc = {
        adaptive: !0,
        maxLength: 10,
        minSegments: 8,
        maxSegments: 2048,
        epsilon: 1e-4,
        _segmentsCount(e, t = 20) {
          if (!this.adaptive || !e || isNaN(e)) return t;
          let n = Math.ceil(e / this.maxLength);
          return (
            n < this.minSegments
              ? (n = this.minSegments)
              : n > this.maxSegments && (n = this.maxSegments),
            n
          );
        },
      });
  }))();
}
var Wc;
function Gc() {
  return (Gc = t(() => {
    Z(),
      Uc(),
      (Wc = class {
        static curveTo(e, t, n, r, i, a) {
          let o = a[a.length - 2],
            s = a[a.length - 1] - t,
            c = o - e,
            l = r - t,
            u = n - e,
            d = Math.abs(s * u - c * l);
          if (d < 1e-8 || i === 0)
            return (
              (a[a.length - 2] !== e || a[a.length - 1] !== t) && a.push(e, t),
              null
            );
          let f = s * s + c * c,
            p = l * l + u * u,
            m = s * l + c * u,
            h = (i * Math.sqrt(f)) / d,
            g = (i * Math.sqrt(p)) / d,
            _ = (h * m) / f,
            v = (g * m) / p,
            y = h * u + g * c,
            b = h * l + g * s,
            x = c * (g + _),
            S = s * (g + _),
            C = u * (h + v),
            w = l * (h + v),
            T = Math.atan2(S - b, x - y),
            E = Math.atan2(w - b, C - y);
          return {
            cx: y + e,
            cy: b + t,
            radius: i,
            startAngle: T,
            endAngle: E,
            anticlockwise: c * l > u * s,
          };
        }
        static arc(e, t, n, r, i, a, o, s, c) {
          let l = o - a,
            u = Hc._segmentsCount(
              Math.abs(l) * i,
              Math.ceil(Math.abs(l) / gr) * 40
            ),
            d = l / (u * 2),
            f = d * 2,
            p = Math.cos(d),
            m = Math.sin(d),
            h = u - 1,
            g = (h % 1) / h;
          for (let e = 0; e <= h; ++e) {
            let t = e + g * e,
              o = d + a + f * t,
              s = Math.cos(o),
              l = -Math.sin(o);
            c.push((p * s + m * l) * i + n, (p * -l + m * s) * i + r);
          }
        }
      });
  }))();
}
var Kc;
function qc() {
  return (qc = t(() => {
    Kc = class {
      constructor() {
        this.reset();
      }
      begin(e, t, n) {
        this.reset(),
          (this.style = e),
          (this.start = t),
          (this.attribStart = n);
      }
      end(e, t) {
        (this.attribSize = t - this.attribStart), (this.size = e - this.start);
      }
      reset() {
        (this.style = null),
          (this.size = 0),
          (this.start = 0),
          (this.attribStart = 0),
          (this.attribSize = 0);
      }
    };
  }))();
}
var Jc;
function Yc() {
  return (Yc = t(() => {
    Uc(),
      (Jc = class e {
        static curveLength(e, t, n, r, i, a, o, s) {
          let c = 0,
            l = 0,
            u = 0,
            d = 0,
            f = 0,
            p = 0,
            m = 0,
            h = 0,
            g = 0,
            _ = 0,
            v = 0,
            y = e,
            b = t;
          for (let x = 1; x <= 10; ++x)
            (l = x / 10),
              (u = l * l),
              (d = u * l),
              (f = 1 - l),
              (p = f * f),
              (m = p * f),
              (h = m * e + 3 * p * l * n + 3 * f * u * i + d * o),
              (g = m * t + 3 * p * l * r + 3 * f * u * a + d * s),
              (_ = y - h),
              (v = b - g),
              (y = h),
              (b = g),
              (c += Math.sqrt(_ * _ + v * v));
          return c;
        }
        static curveTo(t, n, r, i, a, o, s) {
          let c = s[s.length - 2],
            l = s[s.length - 1];
          s.length -= 2;
          let u = Hc._segmentsCount(e.curveLength(c, l, t, n, r, i, a, o)),
            d = 0,
            f = 0,
            p = 0,
            m = 0,
            h = 0;
          s.push(c, l);
          for (let e = 1, g = 0; e <= u; ++e)
            (g = e / u),
              (d = 1 - g),
              (f = d * d),
              (p = f * d),
              (m = g * g),
              (h = m * g),
              s.push(
                p * c + 3 * f * g * t + 3 * d * m * r + h * a,
                p * l + 3 * f * g * n + 3 * d * m * i + h * o
              );
        }
      });
  }))();
}
function Xc(e, t, n, r, i, a, o, s) {
  let c = e - n * i,
    l = t - r * i,
    u = e + n * a,
    d = t + r * a,
    f,
    p;
  o ? ((f = r), (p = -n)) : ((f = -r), (p = n));
  let m = c + f,
    h = l + p,
    g = u + f,
    _ = d + p;
  return s.push(m, h, g, _), 2;
}
function Zc(e, t, n, r, i, a, o, s) {
  let c = n - e,
    l = r - t,
    u = Math.atan2(c, l),
    d = Math.atan2(i - e, a - t);
  s && u < d ? (u += Math.PI * 2) : !s && u > d && (d += Math.PI * 2);
  let f = u,
    p = d - u,
    m = Math.abs(p),
    h = Math.sqrt(c * c + l * l),
    g = (((15 * m * Math.sqrt(h)) / Math.PI) >> 0) + 1,
    _ = p / g;
  if (((f += _), s)) {
    o.push(e, t, n, r);
    for (let n = 1, r = f; n < g; n++, r += _)
      o.push(e, t, e + Math.sin(r) * h, t + Math.cos(r) * h);
    o.push(e, t, i, a);
  } else {
    o.push(n, r, e, t);
    for (let n = 1, r = f; n < g; n++, r += _)
      o.push(e + Math.sin(r) * h, t + Math.cos(r) * h, e, t);
    o.push(i, a, e, t);
  }
  return g * 2;
}
function Qc(e, t) {
  let n = e.shape,
    r = e.points || n.points.slice(),
    i = t.closePointEps;
  if (r.length === 0) return;
  let a = e.lineStyle,
    o = new G(r[0], r[1]),
    s = new G(r[r.length - 2], r[r.length - 1]),
    c = n.type !== W.POLY || n.closeStroke,
    l = Math.abs(o.x - s.x) < i && Math.abs(o.y - s.y) < i;
  if (c) {
    (r = r.slice()),
      l && (r.pop(), r.pop(), s.set(r[r.length - 2], r[r.length - 1]));
    let e = (o.x + s.x) * 0.5,
      t = (s.y + o.y) * 0.5;
    r.unshift(e, t), r.push(e, t);
  }
  let u = t.points,
    d = r.length / 2,
    f = r.length,
    p = u.length / 2,
    m = a.width / 2,
    h = m * m,
    g = a.miterLimit * a.miterLimit,
    _ = r[0],
    v = r[1],
    y = r[2],
    b = r[3],
    x = 0,
    S = 0,
    C = -(v - b),
    w = _ - y,
    T = 0,
    E = 0,
    D = Math.sqrt(C * C + w * w);
  (C /= D), (w /= D), (C *= m), (w *= m);
  let O = a.alignment,
    k = (1 - O) * 2,
    A = O * 2;
  c ||
    (a.cap === Vc.ROUND
      ? (f +=
          Zc(
            _ - C * (k - A) * 0.5,
            v - w * (k - A) * 0.5,
            _ - C * k,
            v - w * k,
            _ + C * A,
            v + w * A,
            u,
            !0
          ) + 2)
      : a.cap === Vc.SQUARE && (f += Xc(_, v, C, w, k, A, !0, u))),
    u.push(_ - C * k, v - w * k, _ + C * A, v + w * A);
  for (let e = 1; e < d - 1; ++e) {
    (_ = r[(e - 1) * 2]),
      (v = r[(e - 1) * 2 + 1]),
      (y = r[e * 2]),
      (b = r[e * 2 + 1]),
      (x = r[(e + 1) * 2]),
      (S = r[(e + 1) * 2 + 1]),
      (C = -(v - b)),
      (w = _ - y),
      (D = Math.sqrt(C * C + w * w)),
      (C /= D),
      (w /= D),
      (C *= m),
      (w *= m),
      (T = -(b - S)),
      (E = y - x),
      (D = Math.sqrt(T * T + E * E)),
      (T /= D),
      (E /= D),
      (T *= m),
      (E *= m);
    let t = y - _,
      n = v - b,
      i = y - x,
      o = S - b,
      s = t * i + n * o,
      c = n * i - o * t,
      l = c < 0;
    if (Math.abs(c) < 0.001 * Math.abs(s)) {
      u.push(y - C * k, b - w * k, y + C * A, b + w * A),
        s >= 0 &&
          (a.join === Bc.ROUND
            ? (f +=
                Zc(y, b, y - C * k, b - w * k, y - T * k, b - E * k, u, !1) + 4)
            : (f += 2),
          u.push(y - T * A, b - E * A, y + T * k, b + E * k));
      continue;
    }
    let d = (-C + _) * (-w + b) - (-C + y) * (-w + v),
      p = (-T + x) * (-E + b) - (-T + y) * (-E + S),
      O = (t * p - i * d) / c,
      j = (o * d - n * p) / c,
      ee = (O - y) * (O - y) + (j - b) * (j - b),
      M = y + (O - y) * k,
      te = b + (j - b) * k,
      ne = y - (O - y) * A,
      re = b - (j - b) * A,
      ie = Math.min(t * t + n * n, i * i + o * o),
      ae = l ? k : A,
      oe = ee <= ie + ae * ae * h,
      se = a.join;
    if ((se === Bc.MITER && ee / h > g && (se = Bc.BEVEL), oe))
      switch (se) {
        case Bc.MITER:
          u.push(M, te, ne, re);
          break;
        case Bc.BEVEL:
          l
            ? u.push(M, te, y + C * A, b + w * A, M, te, y + T * A, b + E * A)
            : u.push(
                y - C * k,
                b - w * k,
                ne,
                re,
                y - T * k,
                b - E * k,
                ne,
                re
              ),
            (f += 2);
          break;
        case Bc.ROUND:
          l
            ? (u.push(M, te, y + C * A, b + w * A),
              (f +=
                Zc(y, b, y + C * A, b + w * A, y + T * A, b + E * A, u, !0) +
                4),
              u.push(M, te, y + T * A, b + E * A))
            : (u.push(y - C * k, b - w * k, ne, re),
              (f +=
                Zc(y, b, y - C * k, b - w * k, y - T * k, b - E * k, u, !1) +
                4),
              u.push(y - T * k, b - E * k, ne, re));
      }
    else {
      switch ((u.push(y - C * k, b - w * k, y + C * A, b + w * A), se)) {
        case Bc.MITER:
          l ? u.push(ne, re, ne, re) : u.push(M, te, M, te), (f += 2);
          break;
        case Bc.ROUND:
          f += l
            ? Zc(y, b, y + C * A, b + w * A, y + T * A, b + E * A, u, !0) + 2
            : Zc(y, b, y - C * k, b - w * k, y - T * k, b - E * k, u, !1) + 2;
      }
      u.push(y - T * k, b - E * k, y + T * A, b + E * A), (f += 2);
    }
  }
  (_ = r[(d - 2) * 2]),
    (v = r[(d - 2) * 2 + 1]),
    (y = r[(d - 1) * 2]),
    (b = r[(d - 1) * 2 + 1]),
    (C = -(v - b)),
    (w = _ - y),
    (D = Math.sqrt(C * C + w * w)),
    (C /= D),
    (w /= D),
    (C *= m),
    (w *= m),
    u.push(y - C * k, b - w * k, y + C * A, b + w * A),
    c ||
      (a.cap === Vc.ROUND
        ? (f +=
            Zc(
              y - C * (k - A) * 0.5,
              b - w * (k - A) * 0.5,
              y - C * k,
              b - w * k,
              y + C * A,
              b + w * A,
              u,
              !1
            ) + 2)
        : a.cap === Vc.SQUARE && (f += Xc(y, b, C, w, k, A, !1, u)));
  let j = t.indices,
    ee = Hc.epsilon * Hc.epsilon;
  for (let e = p; e < f + p - 2; ++e)
    (_ = u[e * 2]),
      (v = u[e * 2 + 1]),
      (y = u[(e + 1) * 2]),
      (b = u[(e + 1) * 2 + 1]),
      (x = u[(e + 2) * 2]),
      (S = u[(e + 2) * 2 + 1]),
      !(Math.abs(_ * (b - S) + y * (S - v) + x * (v - b)) < ee) &&
        j.push(e, e + 1, e + 2);
}
function $c(e, t) {
  let n = 0,
    r = e.shape,
    i = e.points || r.points,
    a = r.type !== W.POLY || r.closeStroke;
  if (i.length === 0) return;
  let o = t.points,
    s = t.indices,
    c = i.length / 2,
    l = o.length / 2,
    u = l;
  for (o.push(i[0], i[1]), n = 1; n < c; n++)
    o.push(i[n * 2], i[n * 2 + 1]), s.push(u, u + 1), u++;
  a && s.push(u, l);
}
function el(e, t) {
  e.lineStyle.native ? $c(e, t) : Qc(e, t);
}
function tl() {
  return (tl = t(() => {
    Z(), Uc();
  }))();
}
var nl;
function rl() {
  return (rl = t(() => {
    Uc(),
      (nl = class e {
        static curveLength(e, t, n, r, i, a) {
          let o = e - 2 * n + i,
            s = t - 2 * r + a,
            c = 2 * n - 2 * e,
            l = 2 * r - 2 * t,
            u = 4 * (o * o + s * s),
            d = 4 * (o * c + s * l),
            f = c * c + l * l,
            p = 2 * Math.sqrt(u + d + f),
            m = Math.sqrt(u),
            h = 2 * u * m,
            g = 2 * Math.sqrt(f),
            _ = d / m;
          return (
            (h * p +
              m * d * (p - g) +
              (4 * f * u - d * d) * Math.log((2 * m + _ + p) / (_ + g))) /
            (4 * h)
          );
        }
        static curveTo(t, n, r, i, a) {
          let o = a[a.length - 2],
            s = a[a.length - 1],
            c = Hc._segmentsCount(e.curveLength(o, s, t, n, r, i)),
            l = 0,
            u = 0;
          for (let e = 1; e <= c; ++e) {
            let d = e / c;
            (l = o + (t - o) * d),
              (u = s + (n - s) * d),
              a.push(
                l + (t + (r - t) * d - l) * d,
                u + (n + (i - n) * d - u) * d
              );
          }
        }
      });
  }))();
}
var il, al, ol;
function sl() {
  return (sl = t(() => {
    Z(),
      Mc(),
      Fc(),
      Lc(),
      zc(),
      Gc(),
      tl(),
      (il = {
        [W.POLY]: Pc,
        [W.CIRC]: jc,
        [W.ELIP]: jc,
        [W.RECT]: Ic,
        [W.RREC]: Rc,
      }),
      (al = []),
      (ol = []);
  }))();
}
var cl;
function ll() {
  return (ll = t(() => {
    cl = class e {
      constructor(e, t = null, n = null, r = null) {
        (this.points = []),
          (this.holes = []),
          (this.shape = e),
          (this.lineStyle = n),
          (this.fillStyle = t),
          (this.matrix = r),
          (this.type = e.type);
      }
      clone() {
        return new e(this.shape, this.fillStyle, this.lineStyle, this.matrix);
      }
      destroy() {
        (this.shape = null),
          (this.holes.length = 0),
          (this.holes = null),
          (this.points.length = 0),
          (this.points = null),
          (this.lineStyle = null),
          (this.fillStyle = null);
      }
    };
  }))();
}
var ul, dl, fl;
function pl() {
  return (pl = t(() => {
    Z(),
      Tc(),
      ll(),
      sl(),
      qc(),
      Fc(),
      tl(),
      (ul = new G()),
      (dl = class extends mr {
        constructor() {
          super(),
            (this.closePointEps = 1e-4),
            (this.boundsPadding = 0),
            (this.uvsFloat32 = null),
            (this.indicesUint16 = null),
            (this.batchable = !1),
            (this.points = []),
            (this.colors = []),
            (this.uvs = []),
            (this.indices = []),
            (this.textureIds = []),
            (this.graphicsData = []),
            (this.drawCalls = []),
            (this.batchDirty = -1),
            (this.batches = []),
            (this.dirty = 0),
            (this.cacheDirty = -1),
            (this.clearDirty = 0),
            (this.shapeIndex = 0),
            (this._bounds = new mc()),
            (this.boundsDirty = -1);
        }
        get bounds() {
          return (
            this.updateBatches(),
            this.boundsDirty !== this.dirty &&
              ((this.boundsDirty = this.dirty), this.calculateBounds()),
            this._bounds
          );
        }
        invalidate() {
          (this.boundsDirty = -1),
            this.dirty++,
            this.batchDirty++,
            (this.shapeIndex = 0),
            (this.points.length = 0),
            (this.colors.length = 0),
            (this.uvs.length = 0),
            (this.indices.length = 0),
            (this.textureIds.length = 0);
          for (let e = 0; e < this.drawCalls.length; e++)
            this.drawCalls[e].texArray.clear(), ol.push(this.drawCalls[e]);
          this.drawCalls.length = 0;
          for (let e = 0; e < this.batches.length; e++) {
            let t = this.batches[e];
            t.reset(), al.push(t);
          }
          this.batches.length = 0;
        }
        clear() {
          return (
            this.graphicsData.length > 0 &&
              (this.invalidate(),
              this.clearDirty++,
              (this.graphicsData.length = 0)),
            this
          );
        }
        drawShape(e, t = null, n = null, r = null) {
          let i = new cl(e, t, n, r);
          return this.graphicsData.push(i), this.dirty++, this;
        }
        drawHole(e, t = null) {
          if (!this.graphicsData.length) return null;
          let n = new cl(e, null, null, t),
            r = this.graphicsData[this.graphicsData.length - 1];
          return (
            (n.lineStyle = r.lineStyle), r.holes.push(n), this.dirty++, this
          );
        }
        destroy() {
          super.destroy();
          for (let e = 0; e < this.graphicsData.length; ++e)
            this.graphicsData[e].destroy();
          (this.points.length = 0),
            (this.points = null),
            (this.colors.length = 0),
            (this.colors = null),
            (this.uvs.length = 0),
            (this.uvs = null),
            (this.indices.length = 0),
            (this.indices = null),
            this.indexBuffer.destroy(),
            (this.indexBuffer = null),
            (this.graphicsData.length = 0),
            (this.graphicsData = null),
            (this.drawCalls.length = 0),
            (this.drawCalls = null),
            (this.batches.length = 0),
            (this.batches = null),
            (this._bounds = null);
        }
        containsPoint(e) {
          let t = this.graphicsData;
          for (let n = 0; n < t.length; ++n) {
            let r = t[n];
            if (
              r.fillStyle.visible &&
              r.shape &&
              (r.matrix ? r.matrix.applyInverse(e, ul) : ul.copyFrom(e),
              r.shape.contains(ul.x, ul.y))
            ) {
              let e = !1;
              if (r.holes) {
                for (let t = 0; t < r.holes.length; t++)
                  if (r.holes[t].shape.contains(ul.x, ul.y)) {
                    e = !0;
                    break;
                  }
              }
              if (!e) return !0;
            }
          }
          return !1;
        }
        updateBatches() {
          if (!this.graphicsData.length) {
            this.batchable = !0;
            return;
          }
          if (!this.validateBatching()) return;
          this.cacheDirty = this.dirty;
          let e = this.uvs,
            t = this.graphicsData,
            n = null,
            r = null;
          this.batches.length > 0 &&
            ((n = this.batches[this.batches.length - 1]), (r = n.style));
          for (let i = this.shapeIndex; i < t.length; i++) {
            this.shapeIndex++;
            let a = t[i],
              o = a.fillStyle,
              s = a.lineStyle;
            il[a.type].build(a),
              a.matrix && this.transformPoints(a.points, a.matrix),
              (o.visible || s.visible) && this.processHoles(a.holes);
            for (let t = 0; t < 2; t++) {
              let i = t === 0 ? o : s;
              if (!i.visible) continue;
              let c = i.texture.baseTexture,
                l = this.indices.length,
                u = this.points.length / 2;
              (c.wrapMode = h.REPEAT),
                t === 0 ? this.processFill(a) : this.processLine(a);
              let d = this.points.length / 2 - u;
              d !== 0 &&
                (n && !this._compareStyles(r, i) && (n.end(l, u), (n = null)),
                n ||
                  ((n = al.pop() || new Kc()),
                  n.begin(i, l, u),
                  this.batches.push(n),
                  (r = i)),
                this.addUvs(this.points, e, i.texture, u, d, i.matrix));
            }
          }
          let i = this.indices.length,
            a = this.points.length / 2;
          if ((n && n.end(i, a), this.batches.length === 0)) {
            this.batchable = !0;
            return;
          }
          let o = a > 65535;
          this.indicesUint16 &&
          this.indices.length === this.indicesUint16.length &&
          o === this.indicesUint16.BYTES_PER_ELEMENT > 2
            ? this.indicesUint16.set(this.indices)
            : (this.indicesUint16 = o
                ? new Uint32Array(this.indices)
                : new Uint16Array(this.indices)),
            (this.batchable = this.isBatchable()),
            this.batchable ? this.packBatches() : this.buildDrawCalls();
        }
        _compareStyles(e, t) {
          return !(
            !e ||
            !t ||
            e.texture.baseTexture !== t.texture.baseTexture ||
            e.color + e.alpha !== t.color + t.alpha ||
            !!e.native != !!t.native
          );
        }
        validateBatching() {
          if (this.dirty === this.cacheDirty || !this.graphicsData.length)
            return !1;
          for (let e = 0, t = this.graphicsData.length; e < t; e++) {
            let t = this.graphicsData[e],
              n = t.fillStyle,
              r = t.lineStyle;
            if (
              (n && !n.texture.baseTexture.valid) ||
              (r && !r.texture.baseTexture.valid)
            )
              return !1;
          }
          return !0;
        }
        packBatches() {
          this.batchDirty++, (this.uvsFloat32 = new Float32Array(this.uvs));
          let e = this.batches;
          for (let t = 0, n = e.length; t < n; t++) {
            let n = e[t];
            for (let e = 0; e < n.size; e++) {
              let t = n.start + e;
              this.indicesUint16[t] = this.indicesUint16[t] - n.attribStart;
            }
          }
        }
        isBatchable() {
          if (this.points.length > 131070) return !1;
          let e = this.batches;
          for (let t = 0; t < e.length; t++) if (e[t].style.native) return !1;
          return this.points.length < dl.BATCHABLE_SIZE * 2;
        }
        buildDrawCalls() {
          let e = ++H._globalBatch;
          for (let e = 0; e < this.drawCalls.length; e++)
            this.drawCalls[e].texArray.clear(), ol.push(this.drawCalls[e]);
          this.drawCalls.length = 0;
          let t = this.colors,
            n = this.textureIds,
            r = ol.pop();
          r || ((r = new er()), (r.texArray = new zi())),
            (r.texArray.count = 0),
            (r.start = 0),
            (r.size = 0),
            (r.type = l.TRIANGLES);
          let i = 0,
            a = null,
            o = 0,
            s = !1,
            c = l.TRIANGLES,
            u = 0;
          this.drawCalls.push(r);
          for (let d = 0; d < this.batches.length; d++) {
            let f = this.batches[d],
              p = f.style,
              m = p.texture.baseTexture;
            s !== !!p.native &&
              ((s = !!p.native),
              (c = s ? l.LINES : l.TRIANGLES),
              (a = null),
              (i = 8),
              e++),
              a !== m &&
                ((a = m),
                m._batchEnabled !== e &&
                  (i === 8 &&
                    (e++,
                    (i = 0),
                    r.size > 0 &&
                      ((r = ol.pop()),
                      r || ((r = new er()), (r.texArray = new zi())),
                      this.drawCalls.push(r)),
                    (r.start = u),
                    (r.size = 0),
                    (r.texArray.count = 0),
                    (r.type = c)),
                  (m.touched = 1),
                  (m._batchEnabled = e),
                  (m._batchLocation = i),
                  (m.wrapMode = h.REPEAT),
                  (r.texArray.elements[r.texArray.count++] = m),
                  i++)),
              (r.size += f.size),
              (u += f.size),
              (o = m._batchLocation),
              this.addColors(t, p.color, p.alpha, f.attribSize, f.attribStart),
              this.addTextureIds(n, o, f.attribSize, f.attribStart);
          }
          (H._globalBatch = e), this.packAttributes();
        }
        packAttributes() {
          let e = this.points,
            t = this.uvs,
            n = this.colors,
            r = this.textureIds,
            i = new ArrayBuffer(e.length * 3 * 4),
            a = new Float32Array(i),
            o = new Uint32Array(i),
            s = 0;
          for (let i = 0; i < e.length / 2; i++)
            (a[s++] = e[i * 2]),
              (a[s++] = e[i * 2 + 1]),
              (a[s++] = t[i * 2]),
              (a[s++] = t[i * 2 + 1]),
              (o[s++] = n[i]),
              (a[s++] = r[i]);
          this._buffer.update(i), this._indexBuffer.update(this.indicesUint16);
        }
        processFill(e) {
          e.holes.length
            ? Pc.triangulate(e, this)
            : il[e.type].triangulate(e, this);
        }
        processLine(e) {
          el(e, this);
          for (let t = 0; t < e.holes.length; t++) el(e.holes[t], this);
        }
        processHoles(e) {
          for (let t = 0; t < e.length; t++) {
            let n = e[t];
            il[n.type].build(n),
              n.matrix && this.transformPoints(n.points, n.matrix);
          }
        }
        calculateBounds() {
          let e = this._bounds;
          e.clear(),
            e.addVertexData(this.points, 0, this.points.length),
            e.pad(this.boundsPadding, this.boundsPadding);
        }
        transformPoints(e, t) {
          for (let n = 0; n < e.length / 2; n++) {
            let r = e[n * 2],
              i = e[n * 2 + 1];
            (e[n * 2] = t.a * r + t.c * i + t.tx),
              (e[n * 2 + 1] = t.b * r + t.d * i + t.ty);
          }
        }
        addColors(e, t, n, r, i = 0) {
          let a = I.shared.setValue(t).toLittleEndianNumber(),
            o = I.shared.setValue(a).toPremultiplied(n);
          e.length = Math.max(e.length, i + r);
          for (let t = 0; t < r; t++) e[i + t] = o;
        }
        addTextureIds(e, t, n, r = 0) {
          e.length = Math.max(e.length, r + n);
          for (let i = 0; i < n; i++) e[r + i] = t;
        }
        addUvs(e, t, n, r, i, a = null) {
          let o = 0,
            s = t.length,
            c = n.frame;
          for (; o < i; ) {
            let n = e[(r + o) * 2],
              i = e[(r + o) * 2 + 1];
            if (a) {
              let e = a.a * n + a.c * i + a.tx;
              (i = a.b * n + a.d * i + a.ty), (n = e);
            }
            o++, t.push(n / c.width, i / c.height);
          }
          let l = n.baseTexture;
          (c.width < l.width || c.height < l.height) &&
            this.adjustUvs(t, n, s, i);
        }
        adjustUvs(e, t, n, r) {
          let i = t.baseTexture,
            a = 1e-6,
            o = n + r * 2,
            s = t.frame,
            c = s.width / i.width,
            l = s.height / i.height,
            u = s.x / s.width,
            d = s.y / s.height,
            f = Math.floor(e[n] + a),
            p = Math.floor(e[n + 1] + a);
          for (let t = n + 2; t < o; t += 2)
            (f = Math.min(f, Math.floor(e[t] + a))),
              (p = Math.min(p, Math.floor(e[t + 1] + a)));
          (u -= f), (d -= p);
          for (let t = n; t < o; t += 2)
            (e[t] = (e[t] + u) * c), (e[t + 1] = (e[t + 1] + d) * l);
        }
      }),
      (fl = dl),
      (fl.BATCHABLE_SIZE = 100);
  }))();
}
var ml;
function hl() {
  return (hl = t(() => {
    Z(),
      (ml = class e {
        constructor() {
          (this.color = 16777215),
            (this.alpha = 1),
            (this.texture = X.WHITE),
            (this.matrix = null),
            (this.visible = !1),
            this.reset();
        }
        clone() {
          let t = new e();
          return (
            (t.color = this.color),
            (t.alpha = this.alpha),
            (t.texture = this.texture),
            (t.matrix = this.matrix),
            (t.visible = this.visible),
            t
          );
        }
        reset() {
          (this.color = 16777215),
            (this.alpha = 1),
            (this.texture = X.WHITE),
            (this.matrix = null),
            (this.visible = !1);
        }
        destroy() {
          (this.texture = null), (this.matrix = null);
        }
      });
  }))();
}
var gl;
function _l() {
  return (_l = t(() => {
    Uc(),
      hl(),
      (gl = class e extends ml {
        constructor() {
          super(...arguments),
            (this.width = 0),
            (this.alignment = 0.5),
            (this.native = !1),
            (this.cap = Vc.BUTT),
            (this.join = Bc.MITER),
            (this.miterLimit = 10);
        }
        clone() {
          let t = new e();
          return (
            (t.color = this.color),
            (t.alpha = this.alpha),
            (t.texture = this.texture),
            (t.matrix = this.matrix),
            (t.visible = this.visible),
            (t.width = this.width),
            (t.alignment = this.alignment),
            (t.native = this.native),
            (t.cap = this.cap),
            (t.join = this.join),
            (t.miterLimit = this.miterLimit),
            t
          );
        }
        reset() {
          super.reset(),
            (this.color = 0),
            (this.alignment = 0.5),
            (this.width = 0),
            (this.native = !1);
        }
      });
  }))();
}
var vl, yl, bl;
function xl() {
  return (xl = t(() => {
    Z(),
      Tc(),
      Uc(),
      pl(),
      hl(),
      _l(),
      sl(),
      rl(),
      Yc(),
      Gc(),
      (vl = {}),
      (yl = class extends Sc {
        constructor(e = null) {
          super(),
            (this.shader = null),
            (this.pluginName = `batch`),
            (this.currentPath = null),
            (this.batches = []),
            (this.batchTint = -1),
            (this.batchDirty = -1),
            (this.vertexData = null),
            (this._fillStyle = new ml()),
            (this._lineStyle = new gl()),
            (this._matrix = null),
            (this._holeMode = !1),
            (this.state = zn.for2d()),
            (this._geometry = e || new fl()),
            this._geometry.refCount++,
            (this._transformID = -1),
            (this._tintColor = new I(16777215)),
            (this.blendMode = c.NORMAL);
        }
        get geometry() {
          return this._geometry;
        }
        clone() {
          return this.finishPoly(), new yl(this._geometry);
        }
        set blendMode(e) {
          this.state.blendMode = e;
        }
        get blendMode() {
          return this.state.blendMode;
        }
        get tint() {
          return this._tintColor.value;
        }
        set tint(e) {
          this._tintColor.setValue(e);
        }
        get fill() {
          return this._fillStyle;
        }
        get line() {
          return this._lineStyle;
        }
        lineStyle(e = null, t = 0, n, r = 0.5, i = !1) {
          return (
            typeof e == `number` &&
              (e = { width: e, color: t, alpha: n, alignment: r, native: i }),
            this.lineTextureStyle(e)
          );
        }
        lineTextureStyle(e) {
          let t = {
            width: 0,
            texture: X.WHITE,
            color: e?.texture ? 16777215 : 0,
            matrix: null,
            alignment: 0.5,
            native: !1,
            cap: Vc.BUTT,
            join: Bc.MITER,
            miterLimit: 10,
          };
          (e = Object.assign(t, e)),
            this.normalizeColor(e),
            this.currentPath && this.startPoly();
          let n = e.width > 0 && e.alpha > 0;
          return (
            n
              ? (e.matrix && ((e.matrix = e.matrix.clone()), e.matrix.invert()),
                Object.assign(this._lineStyle, { visible: n }, e))
              : this._lineStyle.reset(),
            this
          );
        }
        startPoly() {
          if (this.currentPath) {
            let e = this.currentPath.points,
              t = this.currentPath.points.length;
            t > 2 &&
              (this.drawShape(this.currentPath),
              (this.currentPath = new Dr()),
              (this.currentPath.closeStroke = !1),
              this.currentPath.points.push(e[t - 2], e[t - 1]));
          } else
            (this.currentPath = new Dr()), (this.currentPath.closeStroke = !1);
        }
        finishPoly() {
          this.currentPath &&
            (this.currentPath.points.length > 2
              ? (this.drawShape(this.currentPath), (this.currentPath = null))
              : (this.currentPath.points.length = 0));
        }
        moveTo(e, t) {
          return (
            this.startPoly(),
            (this.currentPath.points[0] = e),
            (this.currentPath.points[1] = t),
            this
          );
        }
        lineTo(e, t) {
          this.currentPath || this.moveTo(0, 0);
          let n = this.currentPath.points,
            r = n[n.length - 2],
            i = n[n.length - 1];
          return (r !== e || i !== t) && n.push(e, t), this;
        }
        _initCurve(e = 0, t = 0) {
          this.currentPath
            ? this.currentPath.points.length === 0 &&
              (this.currentPath.points = [e, t])
            : this.moveTo(e, t);
        }
        quadraticCurveTo(e, t, n, r) {
          this._initCurve();
          let i = this.currentPath.points;
          return (
            i.length === 0 && this.moveTo(0, 0), nl.curveTo(e, t, n, r, i), this
          );
        }
        bezierCurveTo(e, t, n, r, i, a) {
          return (
            this._initCurve(),
            Jc.curveTo(e, t, n, r, i, a, this.currentPath.points),
            this
          );
        }
        arcTo(e, t, n, r, i) {
          this._initCurve(e, t);
          let a = this.currentPath.points,
            o = Wc.curveTo(e, t, n, r, i, a);
          if (o) {
            let {
              cx: e,
              cy: t,
              radius: n,
              startAngle: r,
              endAngle: i,
              anticlockwise: a,
            } = o;
            this.arc(e, t, n, r, i, a);
          }
          return this;
        }
        arc(e, t, n, r, i, a = !1) {
          if (
            r === i ||
            (!a && i <= r ? (i += gr) : a && r <= i && (r += gr), i - r === 0)
          )
            return this;
          let o = e + Math.cos(r) * n,
            s = t + Math.sin(r) * n,
            c = this._geometry.closePointEps,
            l = this.currentPath ? this.currentPath.points : null;
          if (l) {
            let e = Math.abs(l[l.length - 2] - o),
              t = Math.abs(l[l.length - 1] - s);
            (e < c && t < c) || l.push(o, s);
          } else this.moveTo(o, s), (l = this.currentPath.points);
          return Wc.arc(o, s, e, t, n, r, i, a, l), this;
        }
        beginFill(e = 0, t) {
          return this.beginTextureFill({
            texture: X.WHITE,
            color: e,
            alpha: t,
          });
        }
        normalizeColor(e) {
          let t = I.shared.setValue(e.color ?? 0);
          (e.color = t.toNumber()), (e.alpha ??= t.alpha);
        }
        beginTextureFill(e) {
          let t = { texture: X.WHITE, color: 16777215, matrix: null };
          (e = Object.assign(t, e)),
            this.normalizeColor(e),
            this.currentPath && this.startPoly();
          let n = e.alpha > 0;
          return (
            n
              ? (e.matrix && ((e.matrix = e.matrix.clone()), e.matrix.invert()),
                Object.assign(this._fillStyle, { visible: n }, e))
              : this._fillStyle.reset(),
            this
          );
        }
        endFill() {
          return this.finishPoly(), this._fillStyle.reset(), this;
        }
        drawRect(e, t, n, r) {
          return this.drawShape(new K(e, t, n, r));
        }
        drawRoundedRect(e, t, n, r, i) {
          return this.drawShape(new kr(e, t, n, r, i));
        }
        drawCircle(e, t, n) {
          return this.drawShape(new Cr(e, t, n));
        }
        drawEllipse(e, t, n, r) {
          return this.drawShape(new Tr(e, t, n, r));
        }
        drawPolygon(...e) {
          let t,
            n = !0,
            r = e[0];
          r.points
            ? ((n = r.closeStroke), (t = r.points))
            : (t = Array.isArray(e[0]) ? e[0] : e);
          let i = new Dr(t);
          return (i.closeStroke = n), this.drawShape(i), this;
        }
        drawShape(e) {
          return (
            this._holeMode
              ? this._geometry.drawHole(e, this._matrix)
              : this._geometry.drawShape(
                  e,
                  this._fillStyle.clone(),
                  this._lineStyle.clone(),
                  this._matrix
                ),
            this
          );
        }
        clear() {
          return (
            this._geometry.clear(),
            this._lineStyle.reset(),
            this._fillStyle.reset(),
            this._boundsID++,
            (this._matrix = null),
            (this._holeMode = !1),
            (this.currentPath = null),
            this
          );
        }
        isFastRect() {
          let e = this._geometry.graphicsData;
          return (
            e.length === 1 &&
            e[0].shape.type === W.RECT &&
            !e[0].matrix &&
            !e[0].holes.length &&
            !(e[0].lineStyle.visible && e[0].lineStyle.width)
          );
        }
        _render(e) {
          this.finishPoly();
          let t = this._geometry;
          t.updateBatches(),
            t.batchable
              ? (this.batchDirty !== t.batchDirty && this._populateBatches(),
                this._renderBatched(e))
              : (e.batch.flush(), this._renderDirect(e));
        }
        _populateBatches() {
          let e = this._geometry,
            t = this.blendMode,
            n = e.batches.length;
          (this.batchTint = -1),
            (this._transformID = -1),
            (this.batchDirty = e.batchDirty),
            (this.batches.length = n),
            (this.vertexData = new Float32Array(e.points));
          for (let r = 0; r < n; r++) {
            let n = e.batches[r],
              i = n.style.color,
              a = new Float32Array(
                this.vertexData.buffer,
                n.attribStart * 4 * 2,
                n.attribSize * 2
              ),
              o = new Float32Array(
                e.uvsFloat32.buffer,
                n.attribStart * 4 * 2,
                n.attribSize * 2
              ),
              s = {
                vertexData: a,
                blendMode: t,
                indices: new Uint16Array(
                  e.indicesUint16.buffer,
                  n.start * 2,
                  n.size
                ),
                uvs: o,
                _batchRGB: I.shared.setValue(i).toRgbArray(),
                _tintRGB: i,
                _texture: n.style.texture,
                alpha: n.style.alpha,
                worldAlpha: 1,
              };
            this.batches[r] = s;
          }
        }
        _renderBatched(e) {
          if (this.batches.length) {
            e.batch.setObjectRenderer(e.plugins[this.pluginName]),
              this.calculateVertices(),
              this.calculateTints();
            for (let t = 0, n = this.batches.length; t < n; t++) {
              let n = this.batches[t];
              (n.worldAlpha = this.worldAlpha * n.alpha),
                e.plugins[this.pluginName].render(n);
            }
          }
        }
        _renderDirect(e) {
          let t = this._resolveDirectShader(e),
            n = this._geometry,
            r = this.worldAlpha,
            i = t.uniforms,
            a = n.drawCalls;
          (i.translationMatrix = this.transform.worldTransform),
            I.shared.setValue(this._tintColor).premultiply(r).toArray(i.tint),
            e.shader.bind(t),
            e.geometry.bind(n, t),
            e.state.set(this.state);
          for (let t = 0, r = a.length; t < r; t++)
            this._renderDrawCallDirect(e, n.drawCalls[t]);
        }
        _renderDrawCallDirect(e, t) {
          let { texArray: n, type: r, size: i, start: a } = t,
            o = n.count;
          for (let t = 0; t < o; t++) e.texture.bind(n.elements[t], t);
          e.geometry.draw(r, i, a);
        }
        _resolveDirectShader(e) {
          let t = this.shader,
            n = this.pluginName;
          if (!t) {
            if (!vl[n]) {
              let { maxTextures: t } = e.plugins[n],
                r = new Int32Array(t);
              for (let e = 0; e < t; e++) r[e] = e;
              let i = {
                  tint: new Float32Array([1, 1, 1, 1]),
                  translationMatrix: new q(),
                  default: Ni.from({ uSamplers: r }, !0),
                },
                a = e.plugins[n]._shader.program;
              vl[n] = new Fi(a, i);
            }
            t = vl[n];
          }
          return t;
        }
        _calculateBounds() {
          this.finishPoly();
          let e = this._geometry;
          if (!e.graphicsData.length) return;
          let { minX: t, minY: n, maxX: r, maxY: i } = e.bounds;
          this._bounds.addFrame(this.transform, t, n, r, i);
        }
        containsPoint(e) {
          return (
            this.worldTransform.applyInverse(e, yl._TEMP_POINT),
            this._geometry.containsPoint(yl._TEMP_POINT)
          );
        }
        calculateTints() {
          if (this.batchTint !== this.tint) {
            this.batchTint = this._tintColor.toNumber();
            for (let e = 0; e < this.batches.length; e++) {
              let t = this.batches[e];
              t._tintRGB = I.shared
                .setValue(this._tintColor)
                .multiply(t._batchRGB)
                .toLittleEndianNumber();
            }
          }
        }
        calculateVertices() {
          let e = this.transform._worldID;
          if (this._transformID === e) return;
          this._transformID = e;
          let t = this.transform.worldTransform,
            n = t.a,
            r = t.b,
            i = t.c,
            a = t.d,
            o = t.tx,
            s = t.ty,
            c = this._geometry.points,
            l = this.vertexData,
            u = 0;
          for (let e = 0; e < c.length; e += 2) {
            let t = c[e],
              d = c[e + 1];
            (l[u++] = n * t + i * d + o), (l[u++] = a * d + r * t + s);
          }
        }
        closePath() {
          let e = this.currentPath;
          return e && ((e.closeStroke = !0), this.finishPoly()), this;
        }
        setMatrix(e) {
          return (this._matrix = e), this;
        }
        beginHole() {
          return this.finishPoly(), (this._holeMode = !0), this;
        }
        endHole() {
          return this.finishPoly(), (this._holeMode = !1), this;
        }
        destroy(e) {
          this._geometry.refCount--,
            this._geometry.refCount === 0 && this._geometry.dispose(),
            (this._matrix = null),
            (this.currentPath = null),
            this._lineStyle.destroy(),
            (this._lineStyle = null),
            this._fillStyle.destroy(),
            (this._fillStyle = null),
            (this._geometry = null),
            (this.shader = null),
            (this.vertexData = null),
            (this.batches.length = 0),
            (this.batches = null),
            super.destroy(e);
        }
      }),
      (bl = yl),
      (bl.curves = Hc),
      (bl._TEMP_POINT = new G());
  }))();
}
function Sl() {
  return (Sl = t(() => {
    sl(), Uc(), xl(), pl(), hl(), _l(), Fc(), Mc(), zc(), tl(), Gc();
  }))();
}
var Cl;
function wl() {
  return (wl = t(() => {
    Cl = class {
      constructor(e, t) {
        (this.uvBuffer = e),
          (this.uvMatrix = t),
          (this.data = null),
          (this._bufferUpdateId = -1),
          (this._textureUpdateId = -1),
          (this._updateID = 0);
      }
      update(e) {
        if (
          !e &&
          this._bufferUpdateId === this.uvBuffer._updateID &&
          this._textureUpdateId === this.uvMatrix._updateID
        )
          return;
        (this._bufferUpdateId = this.uvBuffer._updateID),
          (this._textureUpdateId = this.uvMatrix._updateID);
        let t = this.uvBuffer.data;
        (!this.data || this.data.length !== t.length) &&
          (this.data = new Float32Array(t.length)),
          this.uvMatrix.multiplyUvs(t, this.data),
          this._updateID++;
      }
    };
  }))();
}
var Tl, El, Dl, Ol;
function kl() {
  return (kl = t(() => {
    Z(),
      Tc(),
      wl(),
      (Tl = new G()),
      (El = new Dr()),
      (Dl = class extends Sc {
        constructor(e, t, n, r = l.TRIANGLES) {
          super(),
            (this.geometry = e),
            (this.shader = t),
            (this.state = n || zn.for2d()),
            (this.drawMode = r),
            (this.start = 0),
            (this.size = 0),
            (this.uvs = null),
            (this.indices = null),
            (this.vertexData = new Float32Array(1)),
            (this.vertexDirty = -1),
            (this._transformID = -1),
            (this._roundPixels = D.ROUND_PIXELS),
            (this.batchUvs = null);
        }
        get geometry() {
          return this._geometry;
        }
        set geometry(e) {
          this._geometry !== e &&
            (this._geometry &&
              (this._geometry.refCount--,
              this._geometry.refCount === 0 && this._geometry.dispose()),
            (this._geometry = e),
            this._geometry && this._geometry.refCount++,
            (this.vertexDirty = -1));
        }
        get uvBuffer() {
          return this.geometry.buffers[1];
        }
        get verticesBuffer() {
          return this.geometry.buffers[0];
        }
        set material(e) {
          this.shader = e;
        }
        get material() {
          return this.shader;
        }
        set blendMode(e) {
          this.state.blendMode = e;
        }
        get blendMode() {
          return this.state.blendMode;
        }
        set roundPixels(e) {
          this._roundPixels !== e && (this._transformID = -1),
            (this._roundPixels = e);
        }
        get roundPixels() {
          return this._roundPixels;
        }
        get tint() {
          return `tint` in this.shader ? this.shader.tint : null;
        }
        set tint(e) {
          this.shader.tint = e;
        }
        get tintValue() {
          return this.shader.tintValue;
        }
        get texture() {
          return `texture` in this.shader ? this.shader.texture : null;
        }
        set texture(e) {
          this.shader.texture = e;
        }
        _render(e) {
          let t = this.geometry.buffers[0].data;
          this.shader.batchable &&
          this.drawMode === l.TRIANGLES &&
          t.length < Dl.BATCHABLE_SIZE * 2
            ? this._renderToBatch(e)
            : this._renderDefault(e);
        }
        _renderDefault(e) {
          let t = this.shader;
          (t.alpha = this.worldAlpha),
            t.update && t.update(),
            e.batch.flush(),
            (t.uniforms.translationMatrix =
              this.transform.worldTransform.toArray(!0)),
            e.shader.bind(t),
            e.state.set(this.state),
            e.geometry.bind(this.geometry, t),
            e.geometry.draw(
              this.drawMode,
              this.size,
              this.start,
              this.geometry.instanceCount
            );
        }
        _renderToBatch(e) {
          let t = this.geometry,
            n = this.shader;
          n.uvMatrix && (n.uvMatrix.update(), this.calculateUvs()),
            this.calculateVertices(),
            (this.indices = t.indexBuffer.data),
            (this._tintRGB = n._tintRGB),
            (this._texture = n.texture);
          let r = this.material.pluginName;
          e.batch.setObjectRenderer(e.plugins[r]), e.plugins[r].render(this);
        }
        calculateVertices() {
          let e = this.geometry.buffers[0],
            t = e.data,
            n = e._updateID;
          if (
            n === this.vertexDirty &&
            this._transformID === this.transform._worldID
          )
            return;
          (this._transformID = this.transform._worldID),
            this.vertexData.length !== t.length &&
              (this.vertexData = new Float32Array(t.length));
          let r = this.transform.worldTransform,
            i = r.a,
            a = r.b,
            o = r.c,
            s = r.d,
            c = r.tx,
            l = r.ty,
            u = this.vertexData;
          for (let e = 0; e < u.length / 2; e++) {
            let n = t[e * 2],
              r = t[e * 2 + 1];
            (u[e * 2] = i * n + o * r + c), (u[e * 2 + 1] = a * n + s * r + l);
          }
          if (this._roundPixels) {
            let e = D.RESOLUTION;
            for (let t = 0; t < u.length; ++t) u[t] = Math.round(u[t] * e) / e;
          }
          this.vertexDirty = n;
        }
        calculateUvs() {
          let e = this.geometry.buffers[1],
            t = this.shader;
          t.uvMatrix.isSimple
            ? (this.uvs = e.data)
            : ((this.batchUvs ||= new Cl(e, t.uvMatrix)),
              this.batchUvs.update(),
              (this.uvs = this.batchUvs.data));
        }
        _calculateBounds() {
          this.calculateVertices(),
            this._bounds.addVertexData(
              this.vertexData,
              0,
              this.vertexData.length
            );
        }
        containsPoint(e) {
          if (!this.getBounds().contains(e.x, e.y)) return !1;
          this.worldTransform.applyInverse(e, Tl);
          let t = this.geometry.getBuffer(`aVertexPosition`).data,
            n = El.points,
            r = this.geometry.getIndex().data,
            i = r.length,
            a = this.drawMode === 4 ? 3 : 1;
          for (let e = 0; e + 2 < i; e += a) {
            let i = r[e] * 2,
              a = r[e + 1] * 2,
              o = r[e + 2] * 2;
            if (
              ((n[0] = t[i]),
              (n[1] = t[i + 1]),
              (n[2] = t[a]),
              (n[3] = t[a + 1]),
              (n[4] = t[o]),
              (n[5] = t[o + 1]),
              El.contains(Tl.x, Tl.y))
            )
              return !0;
          }
          return !1;
        }
        destroy(e) {
          super.destroy(e),
            (this._cachedTexture &&= (this._cachedTexture.destroy(), null)),
            (this.geometry = null),
            (this.shader = null),
            (this.state = null),
            (this.uvs = null),
            (this.indices = null),
            (this.vertexData = null);
        }
      }),
      (Ol = Dl),
      (Ol.BATCHABLE_SIZE = 100);
  }))();
}
var Al;
function jl() {
  return (jl = t(() => {
    Z(),
      (Al = class extends fr {
        constructor(e, t, n) {
          super();
          let r = new U(e),
            i = new U(t, !0),
            a = new U(n, !0, !0);
          this.addAttribute(`aVertexPosition`, r, 2, !1, f.FLOAT)
            .addAttribute(`aTextureCoord`, i, 2, !1, f.FLOAT)
            .addIndex(a),
            (this._updateId = -1);
        }
        get vertexDirtyId() {
          return this.buffers[0]._updateID;
        }
      });
  }))();
}
function Ml() {
  return (Ml = t(() => {}))();
}
function Nl() {
  return (Nl = t(() => {}))();
}
var Pl;
function Fl() {
  return (Fl = t(() => {
    Z(),
      Ml(),
      Nl(),
      (Pl = class extends Fi {
        constructor(e, t) {
          let n = {
            uSampler: e,
            alpha: 1,
            uTextureMatrix: q.IDENTITY,
            uColor: new Float32Array([1, 1, 1, 1]),
          };
          (t = Object.assign(
            { tint: 16777215, alpha: 1, pluginName: `batch` },
            t
          )),
            t.uniforms && Object.assign(n, t.uniforms),
            super(
              t.program ||
                Ai.from(
                  `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;
uniform mat3 translationMatrix;
uniform mat3 uTextureMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = (uTextureMatrix * vec3(aTextureCoord, 1.0)).xy;
}
`,
                  `varying vec2 vTextureCoord;
uniform vec4 uColor;

uniform sampler2D uSampler;

void main(void)
{
    gl_FragColor = texture2D(uSampler, vTextureCoord) * uColor;
}
`
                ),
              n
            ),
            (this._colorDirty = !1),
            (this.uvMatrix = new Qa(e)),
            (this.batchable = t.program === void 0),
            (this.pluginName = t.pluginName),
            (this._tintColor = new I(t.tint)),
            (this._tintRGB = this._tintColor.toLittleEndianNumber()),
            (this._colorDirty = !0),
            (this.alpha = t.alpha);
        }
        get texture() {
          return this.uniforms.uSampler;
        }
        set texture(e) {
          this.uniforms.uSampler !== e &&
            (!this.uniforms.uSampler.baseTexture.alphaMode !=
              !e.baseTexture.alphaMode && (this._colorDirty = !0),
            (this.uniforms.uSampler = e),
            (this.uvMatrix.texture = e));
        }
        set alpha(e) {
          e !== this._alpha && ((this._alpha = e), (this._colorDirty = !0));
        }
        get alpha() {
          return this._alpha;
        }
        set tint(e) {
          e !== this.tint &&
            (this._tintColor.setValue(e),
            (this._tintRGB = this._tintColor.toLittleEndianNumber()),
            (this._colorDirty = !0));
        }
        get tint() {
          return this._tintColor.value;
        }
        get tintValue() {
          return this._tintColor.toNumber();
        }
        update() {
          if (this._colorDirty) {
            this._colorDirty = !1;
            let e = this.texture.baseTexture.alphaMode;
            I.shared
              .setValue(this._tintColor)
              .premultiply(this._alpha, e)
              .toArray(this.uniforms.uColor);
          }
          this.uvMatrix.update() &&
            (this.uniforms.uTextureMatrix = this.uvMatrix.mapCoord);
        }
      });
  }))();
}
function Il() {
  return (Il = t(() => {
    kl(), jl(), Fl();
  }))();
}
var Ll;
function Rl() {
  return (Rl = t(() => {
    Il(),
      (Ll = class extends Al {
        constructor(e = 100, t = 100, n = 10, r = 10) {
          super(),
            (this.segWidth = n),
            (this.segHeight = r),
            (this.width = e),
            (this.height = t),
            this.build();
        }
        build() {
          let e = this.segWidth * this.segHeight,
            t = [],
            n = [],
            r = [],
            i = this.segWidth - 1,
            a = this.segHeight - 1,
            o = this.width / i,
            s = this.height / a;
          for (let r = 0; r < e; r++) {
            let e = r % this.segWidth,
              c = (r / this.segWidth) | 0;
            t.push(e * o, c * s), n.push(e / i, c / a);
          }
          let c = i * a;
          for (let e = 0; e < c; e++) {
            let t = e % i,
              n = (e / i) | 0,
              a = n * this.segWidth + t,
              o = n * this.segWidth + t + 1,
              s = (n + 1) * this.segWidth + t,
              c = (n + 1) * this.segWidth + t + 1;
            r.push(a, o, s, o, c, s);
          }
          (this.buffers[0].data = new Float32Array(t)),
            (this.buffers[1].data = new Float32Array(n)),
            (this.indexBuffer.data = new Uint16Array(r)),
            this.buffers[0].update(),
            this.buffers[1].update(),
            this.indexBuffer.update();
        }
      });
  }))();
}
var zl;
function Bl() {
  return (Bl = t(() => {
    Il(),
      (zl = class extends Al {
        constructor(e = 200, t, n = 0) {
          super(
            new Float32Array(t.length * 4),
            new Float32Array(t.length * 4),
            new Uint16Array((t.length - 1) * 6)
          ),
            (this.points = t),
            (this._width = e),
            (this.textureScale = n),
            this.build();
        }
        get width() {
          return this._width;
        }
        build() {
          let e = this.points;
          if (!e) return;
          let t = this.getBuffer(`aVertexPosition`),
            n = this.getBuffer(`aTextureCoord`),
            r = this.getIndex();
          if (e.length < 1) return;
          t.data.length / 4 !== e.length &&
            ((t.data = new Float32Array(e.length * 4)),
            (n.data = new Float32Array(e.length * 4)),
            (r.data = new Uint16Array((e.length - 1) * 6)));
          let i = n.data,
            a = r.data;
          (i[0] = 0), (i[1] = 0), (i[2] = 0), (i[3] = 1);
          let o = 0,
            s = e[0],
            c = this._width * this.textureScale,
            l = e.length;
          for (let t = 0; t < l; t++) {
            let n = t * 4;
            if (this.textureScale > 0) {
              let n = s.x - e[t].x,
                r = s.y - e[t].y,
                i = Math.sqrt(n * n + r * r);
              (s = e[t]), (o += i / c);
            } else o = t / (l - 1);
            (i[n] = o), (i[n + 1] = 0), (i[n + 2] = o), (i[n + 3] = 1);
          }
          let u = 0;
          for (let e = 0; e < l - 1; e++) {
            let t = e * 2;
            (a[u++] = t),
              (a[u++] = t + 1),
              (a[u++] = t + 2),
              (a[u++] = t + 2),
              (a[u++] = t + 1),
              (a[u++] = t + 3);
          }
          n.update(), r.update(), this.updateVertices();
        }
        updateVertices() {
          let e = this.points;
          if (e.length < 1) return;
          let t = e[0],
            n,
            r = 0,
            i = 0,
            a = this.buffers[0].data,
            o = e.length,
            s =
              this.textureScale > 0
                ? (this.textureScale * this._width) / 2
                : this._width / 2;
          for (let c = 0; c < o; c++) {
            let l = e[c],
              u = c * 4;
            (n = c < e.length - 1 ? e[c + 1] : l),
              (i = -(n.x - t.x)),
              (r = n.y - t.y);
            let d = (1 - c / (o - 1)) * 10;
            d > 1 && (d = 1);
            let f = Math.sqrt(r * r + i * i);
            f < 1e-6
              ? ((r = 0), (i = 0))
              : ((r /= f), (i /= f), (r *= s), (i *= s)),
              (a[u] = l.x + r),
              (a[u + 1] = l.y + i),
              (a[u + 2] = l.x - r),
              (a[u + 3] = l.y - i),
              (t = l);
          }
          this.buffers[0].update();
        }
        update() {
          this.textureScale > 0 ? this.build() : this.updateVertices();
        }
      });
  }))();
}
var Vl;
function Hl() {
  return (Hl = t(() => {
    Z(),
      Il(),
      Rl(),
      (Vl = class extends Ol {
        constructor(e, t, n) {
          let r = new Ll(e.width, e.height, t, n),
            i = new Pl(X.WHITE);
          super(r, i), (this.texture = e), (this.autoResize = !0);
        }
        textureUpdated() {
          this._textureID = this.shader.texture._updateID;
          let e = this.geometry,
            { width: t, height: n } = this.shader.texture;
          this.autoResize &&
            (e.width !== t || e.height !== n) &&
            ((e.width = this.shader.texture.width),
            (e.height = this.shader.texture.height),
            e.build());
        }
        set texture(e) {
          this.shader.texture !== e &&
            ((this.shader.texture = e),
            (this._textureID = -1),
            e.baseTexture.valid
              ? this.textureUpdated()
              : e.once(`update`, this.textureUpdated, this));
        }
        get texture() {
          return this.shader.texture;
        }
        _render(e) {
          this._textureID !== this.shader.texture._updateID &&
            this.textureUpdated(),
            super._render(e);
        }
        destroy(e) {
          this.shader.texture.off(`update`, this.textureUpdated, this),
            super.destroy(e);
        }
      });
  }))();
}
var Ul, Wl;
function Gl() {
  return (Gl = t(() => {
    Z(),
      Hl(),
      (Ul = 10),
      (Wl = class extends Vl {
        constructor(e, t, n, r, i) {
          super(X.WHITE, 4, 4),
            (this._origWidth = e.orig.width),
            (this._origHeight = e.orig.height),
            (this._width = this._origWidth),
            (this._height = this._origHeight),
            (this._leftWidth = t ?? e.defaultBorders?.left ?? Ul),
            (this._rightWidth = r ?? e.defaultBorders?.right ?? Ul),
            (this._topHeight = n ?? e.defaultBorders?.top ?? Ul),
            (this._bottomHeight = i ?? e.defaultBorders?.bottom ?? Ul),
            (this.texture = e);
        }
        textureUpdated() {
          (this._textureID = this.shader.texture._updateID), this._refresh();
        }
        get vertices() {
          return this.geometry.getBuffer(`aVertexPosition`).data;
        }
        set vertices(e) {
          this.geometry.getBuffer(`aVertexPosition`).data = e;
        }
        updateHorizontalVertices() {
          let e = this.vertices,
            t = this._getMinScale();
          (e[9] = e[11] = e[13] = e[15] = this._topHeight * t),
            (e[17] =
              e[19] =
              e[21] =
              e[23] =
                this._height - this._bottomHeight * t),
            (e[25] = e[27] = e[29] = e[31] = this._height);
        }
        updateVerticalVertices() {
          let e = this.vertices,
            t = this._getMinScale();
          (e[2] = e[10] = e[18] = e[26] = this._leftWidth * t),
            (e[4] = e[12] = e[20] = e[28] = this._width - this._rightWidth * t),
            (e[6] = e[14] = e[22] = e[30] = this._width);
        }
        _getMinScale() {
          let e = this._leftWidth + this._rightWidth,
            t = this._width > e ? 1 : this._width / e,
            n = this._topHeight + this._bottomHeight,
            r = this._height > n ? 1 : this._height / n;
          return Math.min(t, r);
        }
        get width() {
          return this._width;
        }
        set width(e) {
          (this._width = e), this._refresh();
        }
        get height() {
          return this._height;
        }
        set height(e) {
          (this._height = e), this._refresh();
        }
        get leftWidth() {
          return this._leftWidth;
        }
        set leftWidth(e) {
          (this._leftWidth = e), this._refresh();
        }
        get rightWidth() {
          return this._rightWidth;
        }
        set rightWidth(e) {
          (this._rightWidth = e), this._refresh();
        }
        get topHeight() {
          return this._topHeight;
        }
        set topHeight(e) {
          (this._topHeight = e), this._refresh();
        }
        get bottomHeight() {
          return this._bottomHeight;
        }
        set bottomHeight(e) {
          (this._bottomHeight = e), this._refresh();
        }
        _refresh() {
          let e = this.texture,
            t = this.geometry.buffers[1].data;
          (this._origWidth = e.orig.width), (this._origHeight = e.orig.height);
          let n = 1 / this._origWidth,
            r = 1 / this._origHeight;
          (t[0] = t[8] = t[16] = t[24] = 0),
            (t[1] = t[3] = t[5] = t[7] = 0),
            (t[6] = t[14] = t[22] = t[30] = 1),
            (t[25] = t[27] = t[29] = t[31] = 1),
            (t[2] = t[10] = t[18] = t[26] = n * this._leftWidth),
            (t[4] = t[12] = t[20] = t[28] = 1 - n * this._rightWidth),
            (t[9] = t[11] = t[13] = t[15] = r * this._topHeight),
            (t[17] = t[19] = t[21] = t[23] = 1 - r * this._bottomHeight),
            this.updateHorizontalVertices(),
            this.updateVerticalVertices(),
            this.geometry.buffers[0].update(),
            this.geometry.buffers[1].update();
        }
      });
  }))();
}
var Kl;
function ql() {
  return (ql = t(() => {
    Z(),
      Il(),
      (Kl = class extends Ol {
        constructor(e = X.EMPTY, t, n, r, i) {
          let a = new Al(t, n, r);
          a.getBuffer(`aVertexPosition`).static = !1;
          let o = new Pl(e);
          super(a, o, null, i), (this.autoUpdate = !0);
        }
        get vertices() {
          return this.geometry.getBuffer(`aVertexPosition`).data;
        }
        set vertices(e) {
          this.geometry.getBuffer(`aVertexPosition`).data = e;
        }
        _render(e) {
          this.autoUpdate &&
            this.geometry.getBuffer(`aVertexPosition`).update(),
            super._render(e);
        }
      });
  }))();
}
var Jl;
function Yl() {
  return (Yl = t(() => {
    Z(),
      Il(),
      Bl(),
      (Jl = class extends Ol {
        constructor(e, t, n = 0) {
          let r = new zl(e.height, t, n),
            i = new Pl(e);
          n > 0 && (e.baseTexture.wrapMode = h.REPEAT),
            super(r, i),
            (this.autoUpdate = !0);
        }
        _render(e) {
          let t = this.geometry;
          (this.autoUpdate || t._width !== this.shader.texture.height) &&
            ((t._width = this.shader.texture.height), t.update()),
            super._render(e);
        }
      });
  }))();
}
function Xl() {
  return (Xl = t(() => {
    Rl(), Bl(), Gl(), ql(), Hl(), Yl();
  }))();
}
var Zl;
function Ql() {
  return (Ql = t(() => {
    Z(),
      Tc(),
      (Zl = class extends Sc {
        constructor(e = 1500, t, n = 16384, r = !1) {
          super();
          let i = 16384;
          n > i && (n = i),
            (this._properties = [!1, !0, !1, !1, !1]),
            (this._maxSize = e),
            (this._batchSize = n),
            (this._buffers = null),
            (this._bufferUpdateIDs = []),
            (this._updateID = 0),
            (this.interactiveChildren = !1),
            (this.blendMode = c.NORMAL),
            (this.autoResize = r),
            (this.roundPixels = !0),
            (this.baseTexture = null),
            this.setProperties(t),
            (this._tintColor = new I(0)),
            (this.tintRgb = new Float32Array(3)),
            (this.tint = 16777215);
        }
        setProperties(e) {
          e &&
            ((this._properties[0] =
              `vertices` in e || `scale` in e
                ? !!e.vertices || !!e.scale
                : this._properties[0]),
            (this._properties[1] =
              `position` in e ? !!e.position : this._properties[1]),
            (this._properties[2] =
              `rotation` in e ? !!e.rotation : this._properties[2]),
            (this._properties[3] = `uvs` in e ? !!e.uvs : this._properties[3]),
            (this._properties[4] =
              `tint` in e || `alpha` in e
                ? !!e.tint || !!e.alpha
                : this._properties[4]));
        }
        updateTransform() {
          this.displayObjectUpdateTransform();
        }
        get tint() {
          return this._tintColor.value;
        }
        set tint(e) {
          this._tintColor.setValue(e), this._tintColor.toRgbArray(this.tintRgb);
        }
        render(e) {
          !this.visible ||
            this.worldAlpha <= 0 ||
            !this.children.length ||
            !this.renderable ||
            (this.baseTexture ||
              ((this.baseTexture = this.children[0]._texture.baseTexture),
              this.baseTexture.valid ||
                this.baseTexture.once(`update`, () =>
                  this.onChildrenChange(0)
                )),
            e.batch.setObjectRenderer(e.plugins.particle),
            e.plugins.particle.render(this));
        }
        onChildrenChange(e) {
          let t = Math.floor(e / this._batchSize);
          for (; this._bufferUpdateIDs.length < t; )
            this._bufferUpdateIDs.push(0);
          this._bufferUpdateIDs[t] = ++this._updateID;
        }
        dispose() {
          if (this._buffers) {
            for (let e = 0; e < this._buffers.length; ++e)
              this._buffers[e].destroy();
            this._buffers = null;
          }
        }
        destroy(e) {
          super.destroy(e),
            this.dispose(),
            (this._properties = null),
            (this._buffers = null),
            (this._bufferUpdateIDs = null);
        }
      });
  }))();
}
var $l;
function eu() {
  return (eu = t(() => {
    Z(),
      ($l = class {
        constructor(e, t, n) {
          (this.geometry = new fr()),
            (this.indexBuffer = null),
            (this.size = n),
            (this.dynamicProperties = []),
            (this.staticProperties = []);
          for (let n = 0; n < e.length; ++n) {
            let r = e[n];
            (r = {
              attributeName: r.attributeName,
              size: r.size,
              uploadFunction: r.uploadFunction,
              type: r.type || f.FLOAT,
              offset: r.offset,
            }),
              t[n]
                ? this.dynamicProperties.push(r)
                : this.staticProperties.push(r);
          }
          (this.staticStride = 0),
            (this.staticBuffer = null),
            (this.staticData = null),
            (this.staticDataUint32 = null),
            (this.dynamicStride = 0),
            (this.dynamicBuffer = null),
            (this.dynamicData = null),
            (this.dynamicDataUint32 = null),
            (this._updateID = 0),
            this.initBuffers();
        }
        initBuffers() {
          let e = this.geometry,
            t = 0;
          (this.indexBuffer = new U(Ut(this.size), !0, !0)),
            e.addIndex(this.indexBuffer),
            (this.dynamicStride = 0);
          for (let e = 0; e < this.dynamicProperties.length; ++e) {
            let n = this.dynamicProperties[e];
            (n.offset = t), (t += n.size), (this.dynamicStride += n.size);
          }
          let n = new ArrayBuffer(this.size * this.dynamicStride * 4 * 4);
          (this.dynamicData = new Float32Array(n)),
            (this.dynamicDataUint32 = new Uint32Array(n)),
            (this.dynamicBuffer = new U(this.dynamicData, !1, !1));
          let r = 0;
          this.staticStride = 0;
          for (let e = 0; e < this.staticProperties.length; ++e) {
            let t = this.staticProperties[e];
            (t.offset = r), (r += t.size), (this.staticStride += t.size);
          }
          let i = new ArrayBuffer(this.size * this.staticStride * 4 * 4);
          (this.staticData = new Float32Array(i)),
            (this.staticDataUint32 = new Uint32Array(i)),
            (this.staticBuffer = new U(this.staticData, !0, !1));
          for (let t = 0; t < this.dynamicProperties.length; ++t) {
            let n = this.dynamicProperties[t];
            e.addAttribute(
              n.attributeName,
              this.dynamicBuffer,
              0,
              n.type === f.UNSIGNED_BYTE,
              n.type,
              this.dynamicStride * 4,
              n.offset * 4
            );
          }
          for (let t = 0; t < this.staticProperties.length; ++t) {
            let n = this.staticProperties[t];
            e.addAttribute(
              n.attributeName,
              this.staticBuffer,
              0,
              n.type === f.UNSIGNED_BYTE,
              n.type,
              this.staticStride * 4,
              n.offset * 4
            );
          }
        }
        uploadDynamic(e, t, n) {
          for (let r = 0; r < this.dynamicProperties.length; r++) {
            let i = this.dynamicProperties[r];
            i.uploadFunction(
              e,
              t,
              n,
              i.type === f.UNSIGNED_BYTE
                ? this.dynamicDataUint32
                : this.dynamicData,
              this.dynamicStride,
              i.offset
            );
          }
          this.dynamicBuffer._updateID++;
        }
        uploadStatic(e, t, n) {
          for (let r = 0; r < this.staticProperties.length; r++) {
            let i = this.staticProperties[r];
            i.uploadFunction(
              e,
              t,
              n,
              i.type === f.UNSIGNED_BYTE
                ? this.staticDataUint32
                : this.staticData,
              this.staticStride,
              i.offset
            );
          }
          this.staticBuffer._updateID++;
        }
        destroy() {
          (this.indexBuffer = null),
            (this.dynamicProperties = null),
            (this.dynamicBuffer = null),
            (this.dynamicData = null),
            (this.dynamicDataUint32 = null),
            (this.staticProperties = null),
            (this.staticBuffer = null),
            (this.staticData = null),
            (this.staticDataUint32 = null),
            this.geometry.destroy();
        }
      });
  }))();
}
var tu;
function nu() {
  return (nu = t(() => {
    tu = `varying vec2 vTextureCoord;
varying vec4 vColor;

uniform sampler2D uSampler;

void main(void){
    vec4 color = texture2D(uSampler, vTextureCoord) * vColor;
    gl_FragColor = color;
}`;
  }))();
}
var ru;
function iu() {
  return (iu = t(() => {
    ru = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;
attribute vec4 aColor;

attribute vec2 aPositionCoord;
attribute float aRotation;

uniform mat3 translationMatrix;
uniform vec4 uColor;

varying vec2 vTextureCoord;
varying vec4 vColor;

void main(void){
    float x = (aVertexPosition.x) * cos(aRotation) - (aVertexPosition.y) * sin(aRotation);
    float y = (aVertexPosition.x) * sin(aRotation) + (aVertexPosition.y) * cos(aRotation);

    vec2 v = vec2(x, y);
    v = v + aPositionCoord;

    gl_Position = vec4((translationMatrix * vec3(v, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = aTextureCoord;
    vColor = aColor * uColor;
}
`;
  }))();
}
var au;
function ou() {
  return (ou = t(() => {
    Z(),
      eu(),
      nu(),
      iu(),
      (au = class extends Gi {
        constructor(e) {
          super(e),
            (this.shader = null),
            (this.properties = null),
            (this.tempMatrix = new q()),
            (this.properties = [
              {
                attributeName: `aVertexPosition`,
                size: 2,
                uploadFunction: this.uploadVertices,
                offset: 0,
              },
              {
                attributeName: `aPositionCoord`,
                size: 2,
                uploadFunction: this.uploadPosition,
                offset: 0,
              },
              {
                attributeName: `aRotation`,
                size: 1,
                uploadFunction: this.uploadRotation,
                offset: 0,
              },
              {
                attributeName: `aTextureCoord`,
                size: 2,
                uploadFunction: this.uploadUvs,
                offset: 0,
              },
              {
                attributeName: `aColor`,
                size: 1,
                type: f.UNSIGNED_BYTE,
                uploadFunction: this.uploadTint,
                offset: 0,
              },
            ]),
            (this.shader = Fi.from(ru, tu, {})),
            (this.state = zn.for2d());
        }
        render(e) {
          let t = e.children,
            n = e._maxSize,
            r = e._batchSize,
            i = this.renderer,
            a = t.length;
          if (a === 0) return;
          a > n && !e.autoResize && (a = n);
          let o = e._buffers;
          o ||= e._buffers = this.generateBuffers(e);
          let s = t[0]._texture.baseTexture,
            c = s.alphaMode > 0;
          (this.state.blendMode = Ft(e.blendMode, c)), i.state.set(this.state);
          let l = i.gl,
            u = e.worldTransform.copyTo(this.tempMatrix);
          u.prepend(i.globalUniforms.uniforms.projectionMatrix),
            (this.shader.uniforms.translationMatrix = u.toArray(!0)),
            (this.shader.uniforms.uColor = I.shared
              .setValue(e.tintRgb)
              .premultiply(e.worldAlpha, c)
              .toArray(this.shader.uniforms.uColor)),
            (this.shader.uniforms.uSampler = s),
            this.renderer.shader.bind(this.shader);
          let d = !1;
          for (let n = 0, s = 0; n < a; n += r, s += 1) {
            let c = a - n;
            c > r && (c = r),
              s >= o.length && o.push(this._generateOneMoreBuffer(e));
            let u = o[s];
            u.uploadDynamic(t, n, c);
            let f = e._bufferUpdateIDs[s] || 0;
            (d ||= u._updateID < f),
              d && ((u._updateID = e._updateID), u.uploadStatic(t, n, c)),
              i.geometry.bind(u.geometry),
              l.drawElements(l.TRIANGLES, c * 6, l.UNSIGNED_SHORT, 0);
          }
        }
        generateBuffers(e) {
          let t = [],
            n = e._maxSize,
            r = e._batchSize,
            i = e._properties;
          for (let e = 0; e < n; e += r) t.push(new $l(this.properties, i, r));
          return t;
        }
        _generateOneMoreBuffer(e) {
          let t = e._batchSize,
            n = e._properties;
          return new $l(this.properties, n, t);
        }
        uploadVertices(e, t, n, r, i, a) {
          let o = 0,
            s = 0,
            c = 0,
            l = 0;
          for (let u = 0; u < n; ++u) {
            let n = e[t + u],
              d = n._texture,
              f = n.scale.x,
              p = n.scale.y,
              m = d.trim,
              h = d.orig;
            m
              ? ((s = m.x - n.anchor.x * h.width),
                (o = s + m.width),
                (l = m.y - n.anchor.y * h.height),
                (c = l + m.height))
              : ((o = h.width * (1 - n.anchor.x)),
                (s = h.width * -n.anchor.x),
                (c = h.height * (1 - n.anchor.y)),
                (l = h.height * -n.anchor.y)),
              (r[a] = s * f),
              (r[a + 1] = l * p),
              (r[a + i] = o * f),
              (r[a + i + 1] = l * p),
              (r[a + i * 2] = o * f),
              (r[a + i * 2 + 1] = c * p),
              (r[a + i * 3] = s * f),
              (r[a + i * 3 + 1] = c * p),
              (a += i * 4);
          }
        }
        uploadPosition(e, t, n, r, i, a) {
          for (let o = 0; o < n; o++) {
            let n = e[t + o].position;
            (r[a] = n.x),
              (r[a + 1] = n.y),
              (r[a + i] = n.x),
              (r[a + i + 1] = n.y),
              (r[a + i * 2] = n.x),
              (r[a + i * 2 + 1] = n.y),
              (r[a + i * 3] = n.x),
              (r[a + i * 3 + 1] = n.y),
              (a += i * 4);
          }
        }
        uploadRotation(e, t, n, r, i, a) {
          for (let o = 0; o < n; o++) {
            let n = e[t + o].rotation;
            (r[a] = n),
              (r[a + i] = n),
              (r[a + i * 2] = n),
              (r[a + i * 3] = n),
              (a += i * 4);
          }
        }
        uploadUvs(e, t, n, r, i, a) {
          for (let o = 0; o < n; ++o) {
            let n = e[t + o]._texture._uvs;
            n
              ? ((r[a] = n.x0),
                (r[a + 1] = n.y0),
                (r[a + i] = n.x1),
                (r[a + i + 1] = n.y1),
                (r[a + i * 2] = n.x2),
                (r[a + i * 2 + 1] = n.y2),
                (r[a + i * 3] = n.x3),
                (r[a + i * 3 + 1] = n.y3),
                (a += i * 4))
              : ((r[a] = 0),
                (r[a + 1] = 0),
                (r[a + i] = 0),
                (r[a + i + 1] = 0),
                (r[a + i * 2] = 0),
                (r[a + i * 2 + 1] = 0),
                (r[a + i * 3] = 0),
                (r[a + i * 3 + 1] = 0),
                (a += i * 4));
          }
        }
        uploadTint(e, t, n, r, i, a) {
          for (let o = 0; o < n; ++o) {
            let n = e[t + o],
              s = I.shared.setValue(n._tintRGB).toPremultiplied(n.alpha);
            (r[a] = s),
              (r[a + i] = s),
              (r[a + i * 2] = s),
              (r[a + i * 3] = s),
              (a += i * 4);
          }
        }
        destroy() {
          super.destroy(),
            (this.shader &&= (this.shader.destroy(), null)),
            (this.tempMatrix = null);
        }
      }),
      (au.extension = { name: `particle`, type: z.RendererPlugin }),
      B.add(au);
  }))();
}
function su() {
  return (su = t(() => {
    Ql(), ou();
  }))();
}
var cu;
function lu() {
  return (lu = t(() => {
    cu = ((e) => (
      (e[(e.LINEAR_VERTICAL = 0)] = `LINEAR_VERTICAL`),
      (e[(e.LINEAR_HORIZONTAL = 1)] = `LINEAR_HORIZONTAL`),
      e
    ))(cu || {});
  }))();
}
var uu, Q, $;
function du() {
  return (du = t(() => {
    Z(),
      (uu = { willReadFrequently: !0 }),
      (Q = class {
        static get experimentalLetterSpacingSupported() {
          let e = Q._experimentalLetterSpacingSupported;
          if (e !== void 0) {
            let t = D.ADAPTER.getCanvasRenderingContext2D().prototype;
            e = Q._experimentalLetterSpacingSupported =
              `letterSpacing` in t || `textLetterSpacing` in t;
          }
          return e;
        }
        constructor(e, t, n, r, i, a, o, s, c) {
          (this.text = e),
            (this.style = t),
            (this.width = n),
            (this.height = r),
            (this.lines = i),
            (this.lineWidths = a),
            (this.lineHeight = o),
            (this.maxLineWidth = s),
            (this.fontProperties = c);
        }
        static measureText(e, t, n, r = Q._canvas) {
          n ??= t.wordWrap;
          let i = t.toFontString(),
            a = Q.measureFont(i);
          a.fontSize === 0 &&
            ((a.fontSize = t.fontSize), (a.ascent = t.fontSize));
          let o = r.getContext(`2d`, uu);
          o.font = i;
          let s = (n ? Q.wordWrap(e, t, r) : e).split(/(?:\r\n|\r|\n)/),
            c = Array(s.length),
            l = 0;
          for (let e = 0; e < s.length; e++) {
            let n = Q._measureText(s[e], t.letterSpacing, o);
            (c[e] = n), (l = Math.max(l, n));
          }
          let u = l + t.strokeThickness;
          t.dropShadow && (u += t.dropShadowDistance);
          let d = t.lineHeight || a.fontSize + t.strokeThickness,
            f =
              Math.max(d, a.fontSize + t.strokeThickness * 2) +
              (s.length - 1) * (d + t.leading);
          return (
            t.dropShadow && (f += t.dropShadowDistance),
            new Q(e, t, u, f, s, c, d + t.leading, l, a)
          );
        }
        static _measureText(e, t, n) {
          let r = !1;
          Q.experimentalLetterSpacingSupported &&
            (Q.experimentalLetterSpacing
              ? ((n.letterSpacing = `${t}px`),
                (n.textLetterSpacing = `${t}px`),
                (r = !0))
              : ((n.letterSpacing = `0px`), (n.textLetterSpacing = `0px`)));
          let i = n.measureText(e).width;
          return (
            i > 0 &&
              (r ? (i -= t) : (i += (Q.graphemeSegmenter(e).length - 1) * t)),
            i
          );
        }
        static wordWrap(e, t, n = Q._canvas) {
          let r = n.getContext(`2d`, uu),
            i = 0,
            a = ``,
            o = ``,
            s = Object.create(null),
            { letterSpacing: c, whiteSpace: l } = t,
            u = Q.collapseSpaces(l),
            d = Q.collapseNewlines(l),
            f = !u,
            p = t.wordWrapWidth + c,
            m = Q.tokenize(e);
          for (let e = 0; e < m.length; e++) {
            let n = m[e];
            if (Q.isNewline(n)) {
              if (!d) {
                (o += Q.addLine(a)), (f = !u), (a = ``), (i = 0);
                continue;
              }
              n = ` `;
            }
            if (u) {
              let e = Q.isBreakingSpace(n),
                t = Q.isBreakingSpace(a[a.length - 1]);
              if (e && t) continue;
            }
            let l = Q.getFromCache(n, c, s, r);
            if (l > p)
              if (
                (a !== `` && ((o += Q.addLine(a)), (a = ``), (i = 0)),
                Q.canBreakWords(n, t.breakWords))
              ) {
                let e = Q.wordWrapSplit(n);
                for (let l = 0; l < e.length; l++) {
                  let u = e[l],
                    d = u,
                    m = 1;
                  for (; e[l + m]; ) {
                    let r = e[l + m];
                    if (!Q.canBreakChars(d, r, n, l, t.breakWords)) u += r;
                    else break;
                    (d = r), m++;
                  }
                  l += m - 1;
                  let h = Q.getFromCache(u, c, s, r);
                  h + i > p &&
                    ((o += Q.addLine(a)), (f = !1), (a = ``), (i = 0)),
                    (a += u),
                    (i += h);
                }
              } else {
                a.length > 0 && ((o += Q.addLine(a)), (a = ``), (i = 0));
                let t = e === m.length - 1;
                (o += Q.addLine(n, !t)), (f = !1), (a = ``), (i = 0);
              }
            else
              l + i > p && ((f = !1), (o += Q.addLine(a)), (a = ``), (i = 0)),
                (a.length > 0 || !Q.isBreakingSpace(n) || f) &&
                  ((a += n), (i += l));
          }
          return (o += Q.addLine(a, !1)), o;
        }
        static addLine(e, t = !0) {
          return (
            (e = Q.trimRight(e)),
            (e = t
              ? `${e}
`
              : e),
            e
          );
        }
        static getFromCache(e, t, n, r) {
          let i = n[e];
          return (
            typeof i != `number` &&
              ((i = Q._measureText(e, t, r) + t), (n[e] = i)),
            i
          );
        }
        static collapseSpaces(e) {
          return e === `normal` || e === `pre-line`;
        }
        static collapseNewlines(e) {
          return e === `normal`;
        }
        static trimRight(e) {
          if (typeof e != `string`) return ``;
          for (let t = e.length - 1; t >= 0; t--) {
            let n = e[t];
            if (!Q.isBreakingSpace(n)) break;
            e = e.slice(0, -1);
          }
          return e;
        }
        static isNewline(e) {
          return typeof e == `string` && Q._newlines.includes(e.charCodeAt(0));
        }
        static isBreakingSpace(e, t) {
          return (
            typeof e == `string` && Q._breakingSpaces.includes(e.charCodeAt(0))
          );
        }
        static tokenize(e) {
          let t = [],
            n = ``;
          if (typeof e != `string`) return t;
          for (let r = 0; r < e.length; r++) {
            let i = e[r],
              a = e[r + 1];
            if (Q.isBreakingSpace(i, a) || Q.isNewline(i)) {
              n !== `` && (t.push(n), (n = ``)), t.push(i);
              continue;
            }
            n += i;
          }
          return n !== `` && t.push(n), t;
        }
        static canBreakWords(e, t) {
          return t;
        }
        static canBreakChars(e, t, n, r, i) {
          return !0;
        }
        static wordWrapSplit(e) {
          return Q.graphemeSegmenter(e);
        }
        static measureFont(e) {
          if (Q._fonts[e]) return Q._fonts[e];
          let t = { ascent: 0, descent: 0, fontSize: 0 },
            n = Q._canvas,
            r = Q._context;
          r.font = e;
          let i = Q.METRICS_STRING + Q.BASELINE_SYMBOL,
            a = Math.ceil(r.measureText(i).width),
            o = Math.ceil(r.measureText(Q.BASELINE_SYMBOL).width),
            s = Math.ceil(Q.HEIGHT_MULTIPLIER * o);
          if (((o = (o * Q.BASELINE_MULTIPLIER) | 0), a === 0 || s === 0))
            return (Q._fonts[e] = t), t;
          (n.width = a),
            (n.height = s),
            (r.fillStyle = `#f00`),
            r.fillRect(0, 0, a, s),
            (r.font = e),
            (r.textBaseline = `alphabetic`),
            (r.fillStyle = `#000`),
            r.fillText(i, 0, o);
          let c = r.getImageData(0, 0, a, s).data,
            l = c.length,
            u = a * 4,
            d = 0,
            f = 0,
            p = !1;
          for (d = 0; d < o; ++d) {
            for (let e = 0; e < u; e += 4)
              if (c[f + e] !== 255) {
                p = !0;
                break;
              }
            if (!p) f += u;
            else break;
          }
          for (t.ascent = o - d, f = l - u, p = !1, d = s; d > o; --d) {
            for (let e = 0; e < u; e += 4)
              if (c[f + e] !== 255) {
                p = !0;
                break;
              }
            if (!p) f -= u;
            else break;
          }
          return (
            (t.descent = d - o),
            (t.fontSize = t.ascent + t.descent),
            (Q._fonts[e] = t),
            t
          );
        }
        static clearMetrics(e = ``) {
          e ? delete Q._fonts[e] : (Q._fonts = {});
        }
        static get _canvas() {
          if (!Q.__canvas) {
            let e;
            try {
              let t = new OffscreenCanvas(0, 0);
              if (t.getContext(`2d`, uu)?.measureText)
                return (Q.__canvas = t), t;
              e = D.ADAPTER.createCanvas();
            } catch {
              e = D.ADAPTER.createCanvas();
            }
            (e.width = e.height = 10), (Q.__canvas = e);
          }
          return Q.__canvas;
        }
        static get _context() {
          return (
            Q.__context || (Q.__context = Q._canvas.getContext(`2d`, uu)),
            Q.__context
          );
        }
      }),
      ($ = Q),
      ($.METRICS_STRING = `|ÉqÅ`),
      ($.BASELINE_SYMBOL = `M`),
      ($.BASELINE_MULTIPLIER = 1.4),
      ($.HEIGHT_MULTIPLIER = 2),
      ($.graphemeSegmenter = (() => {
        if (typeof Intl?.Segmenter == `function`) {
          let e = new Intl.Segmenter();
          return (t) => [...e.segment(t)].map((e) => e.segment);
        }
        return (e) => [...e];
      })()),
      ($.experimentalLetterSpacing = !1),
      ($._fonts = {}),
      ($._newlines = [10, 13]),
      ($._breakingSpaces = [
        9, 32, 8192, 8193, 8194, 8195, 8196, 8197, 8198, 8200, 8201, 8202, 8287,
        12288,
      ]);
  }))();
}
function fu(e) {
  let t = I.shared;
  return Array.isArray(e)
    ? e.map((e) => t.setValue(e).toHex())
    : t.setValue(e).toHex();
}
function pu(e, t) {
  if (!Array.isArray(e) || !Array.isArray(t) || e.length !== t.length)
    return !1;
  for (let n = 0; n < e.length; ++n) if (e[n] !== t[n]) return !1;
  return !0;
}
function mu(e, t, n) {
  for (let r in n) e[r] = Array.isArray(t[r]) ? t[r].slice() : t[r];
}
var hu, gu, _u;
function vu() {
  return (vu = t(() => {
    lu(),
      Z(),
      (hu = [
        `serif`,
        `sans-serif`,
        `monospace`,
        `cursive`,
        `fantasy`,
        `system-ui`,
      ]),
      (gu = class {
        constructor(e) {
          (this.styleID = 0), this.reset(), mu(this, e, e);
        }
        clone() {
          let e = {};
          return mu(e, this, gu.defaultStyle), new gu(e);
        }
        reset() {
          mu(this, gu.defaultStyle, gu.defaultStyle);
        }
        get align() {
          return this._align;
        }
        set align(e) {
          this._align !== e && ((this._align = e), this.styleID++);
        }
        get breakWords() {
          return this._breakWords;
        }
        set breakWords(e) {
          this._breakWords !== e && ((this._breakWords = e), this.styleID++);
        }
        get dropShadow() {
          return this._dropShadow;
        }
        set dropShadow(e) {
          this._dropShadow !== e && ((this._dropShadow = e), this.styleID++);
        }
        get dropShadowAlpha() {
          return this._dropShadowAlpha;
        }
        set dropShadowAlpha(e) {
          this._dropShadowAlpha !== e &&
            ((this._dropShadowAlpha = e), this.styleID++);
        }
        get dropShadowAngle() {
          return this._dropShadowAngle;
        }
        set dropShadowAngle(e) {
          this._dropShadowAngle !== e &&
            ((this._dropShadowAngle = e), this.styleID++);
        }
        get dropShadowBlur() {
          return this._dropShadowBlur;
        }
        set dropShadowBlur(e) {
          this._dropShadowBlur !== e &&
            ((this._dropShadowBlur = e), this.styleID++);
        }
        get dropShadowColor() {
          return this._dropShadowColor;
        }
        set dropShadowColor(e) {
          let t = fu(e);
          this._dropShadowColor !== t &&
            ((this._dropShadowColor = t), this.styleID++);
        }
        get dropShadowDistance() {
          return this._dropShadowDistance;
        }
        set dropShadowDistance(e) {
          this._dropShadowDistance !== e &&
            ((this._dropShadowDistance = e), this.styleID++);
        }
        get fill() {
          return this._fill;
        }
        set fill(e) {
          let t = fu(e);
          this._fill !== t && ((this._fill = t), this.styleID++);
        }
        get fillGradientType() {
          return this._fillGradientType;
        }
        set fillGradientType(e) {
          this._fillGradientType !== e &&
            ((this._fillGradientType = e), this.styleID++);
        }
        get fillGradientStops() {
          return this._fillGradientStops;
        }
        set fillGradientStops(e) {
          pu(this._fillGradientStops, e) ||
            ((this._fillGradientStops = e), this.styleID++);
        }
        get fontFamily() {
          return this._fontFamily;
        }
        set fontFamily(e) {
          this.fontFamily !== e && ((this._fontFamily = e), this.styleID++);
        }
        get fontSize() {
          return this._fontSize;
        }
        set fontSize(e) {
          this._fontSize !== e && ((this._fontSize = e), this.styleID++);
        }
        get fontStyle() {
          return this._fontStyle;
        }
        set fontStyle(e) {
          this._fontStyle !== e && ((this._fontStyle = e), this.styleID++);
        }
        get fontVariant() {
          return this._fontVariant;
        }
        set fontVariant(e) {
          this._fontVariant !== e && ((this._fontVariant = e), this.styleID++);
        }
        get fontWeight() {
          return this._fontWeight;
        }
        set fontWeight(e) {
          this._fontWeight !== e && ((this._fontWeight = e), this.styleID++);
        }
        get letterSpacing() {
          return this._letterSpacing;
        }
        set letterSpacing(e) {
          this._letterSpacing !== e &&
            ((this._letterSpacing = e), this.styleID++);
        }
        get lineHeight() {
          return this._lineHeight;
        }
        set lineHeight(e) {
          this._lineHeight !== e && ((this._lineHeight = e), this.styleID++);
        }
        get leading() {
          return this._leading;
        }
        set leading(e) {
          this._leading !== e && ((this._leading = e), this.styleID++);
        }
        get lineJoin() {
          return this._lineJoin;
        }
        set lineJoin(e) {
          this._lineJoin !== e && ((this._lineJoin = e), this.styleID++);
        }
        get miterLimit() {
          return this._miterLimit;
        }
        set miterLimit(e) {
          this._miterLimit !== e && ((this._miterLimit = e), this.styleID++);
        }
        get padding() {
          return this._padding;
        }
        set padding(e) {
          this._padding !== e && ((this._padding = e), this.styleID++);
        }
        get stroke() {
          return this._stroke;
        }
        set stroke(e) {
          let t = fu(e);
          this._stroke !== t && ((this._stroke = t), this.styleID++);
        }
        get strokeThickness() {
          return this._strokeThickness;
        }
        set strokeThickness(e) {
          this._strokeThickness !== e &&
            ((this._strokeThickness = e), this.styleID++);
        }
        get textBaseline() {
          return this._textBaseline;
        }
        set textBaseline(e) {
          this._textBaseline !== e &&
            ((this._textBaseline = e), this.styleID++);
        }
        get trim() {
          return this._trim;
        }
        set trim(e) {
          this._trim !== e && ((this._trim = e), this.styleID++);
        }
        get whiteSpace() {
          return this._whiteSpace;
        }
        set whiteSpace(e) {
          this._whiteSpace !== e && ((this._whiteSpace = e), this.styleID++);
        }
        get wordWrap() {
          return this._wordWrap;
        }
        set wordWrap(e) {
          this._wordWrap !== e && ((this._wordWrap = e), this.styleID++);
        }
        get wordWrapWidth() {
          return this._wordWrapWidth;
        }
        set wordWrapWidth(e) {
          this._wordWrapWidth !== e &&
            ((this._wordWrapWidth = e), this.styleID++);
        }
        toFontString() {
          let e =
              typeof this.fontSize == `number`
                ? `${this.fontSize}px`
                : this.fontSize,
            t = this.fontFamily;
          Array.isArray(this.fontFamily) || (t = this.fontFamily.split(`,`));
          for (let e = t.length - 1; e >= 0; e--) {
            let n = t[e].trim();
            !/([\"\'])[^\'\"]+\1/.test(n) && !hu.includes(n) && (n = `"${n}"`),
              (t[e] = n);
          }
          return `${this.fontStyle} ${this.fontVariant} ${
            this.fontWeight
          } ${e} ${t.join(`,`)}`;
        }
      }),
      (_u = gu),
      (_u.defaultStyle = {
        align: `left`,
        breakWords: !1,
        dropShadow: !1,
        dropShadowAlpha: 1,
        dropShadowAngle: Math.PI / 6,
        dropShadowBlur: 0,
        dropShadowColor: `black`,
        dropShadowDistance: 5,
        fill: `black`,
        fillGradientType: cu.LINEAR_VERTICAL,
        fillGradientStops: [],
        fontFamily: `Arial`,
        fontSize: 26,
        fontStyle: `normal`,
        fontVariant: `normal`,
        fontWeight: `normal`,
        leading: 0,
        letterSpacing: 0,
        lineHeight: 0,
        lineJoin: `miter`,
        miterLimit: 10,
        padding: 0,
        stroke: `black`,
        strokeThickness: 0,
        textBaseline: `alphabetic`,
        trim: !1,
        whiteSpace: `pre`,
        wordWrap: !1,
        wordWrapWidth: 100,
      });
  }))();
}
var yu, bu, xu;
function Su() {
  return (Su = t(() => {
    Z(),
      Ac(),
      lu(),
      du(),
      vu(),
      (yu = { texture: !0, children: !1, baseTexture: !0 }),
      (bu = class extends Oc {
        constructor(e, t, n) {
          let r = !1;
          n || ((n = D.ADAPTER.createCanvas()), (r = !0)),
            (n.width = 3),
            (n.height = 3);
          let i = X.from(n);
          (i.orig = new K()),
            (i.trim = new K()),
            super(i),
            (this._ownCanvas = r),
            (this.canvas = n),
            (this.context = n.getContext(`2d`, { willReadFrequently: !0 })),
            (this._resolution = bu.defaultResolution ?? D.RESOLUTION),
            (this._autoResolution = bu.defaultAutoResolution),
            (this._text = null),
            (this._style = null),
            (this._styleListener = null),
            (this._font = ``),
            (this.text = e),
            (this.style = t),
            (this.localStyleID = -1);
        }
        static get experimentalLetterSpacing() {
          return $.experimentalLetterSpacing;
        }
        static set experimentalLetterSpacing(e) {
          P(
            `7.1.0`,
            `Text.experimentalLetterSpacing is deprecated, use TextMetrics.experimentalLetterSpacing`
          ),
            ($.experimentalLetterSpacing = e);
        }
        updateText(e) {
          let t = this._style;
          if (
            (this.localStyleID !== t.styleID &&
              ((this.dirty = !0), (this.localStyleID = t.styleID)),
            !this.dirty && e)
          )
            return;
          this._font = this._style.toFontString();
          let n = this.context,
            r = $.measureText(
              this._text || ` `,
              this._style,
              this._style.wordWrap,
              this.canvas
            ),
            i = r.width,
            a = r.height,
            o = r.lines,
            s = r.lineHeight,
            c = r.lineWidths,
            l = r.maxLineWidth,
            u = r.fontProperties;
          (this.canvas.width = Math.ceil(
            Math.ceil(Math.max(1, i) + t.padding * 2) * this._resolution
          )),
            (this.canvas.height = Math.ceil(
              Math.ceil(Math.max(1, a) + t.padding * 2) * this._resolution
            )),
            n.scale(this._resolution, this._resolution),
            n.clearRect(0, 0, this.canvas.width, this.canvas.height),
            (n.font = this._font),
            (n.lineWidth = t.strokeThickness),
            (n.textBaseline = t.textBaseline),
            (n.lineJoin = t.lineJoin),
            (n.miterLimit = t.miterLimit);
          let d,
            f,
            p = t.dropShadow ? 2 : 1;
          for (let e = 0; e < p; ++e) {
            let i = t.dropShadow && e === 0,
              p = i ? Math.ceil(Math.max(1, a) + t.padding * 2) : 0,
              m = p * this._resolution;
            if (i) {
              (n.fillStyle = `black`), (n.strokeStyle = `black`);
              let e = t.dropShadowColor,
                r = t.dropShadowBlur * this._resolution,
                i = t.dropShadowDistance * this._resolution;
              (n.shadowColor = I.shared
                .setValue(e)
                .setAlpha(t.dropShadowAlpha)
                .toRgbaString()),
                (n.shadowBlur = r),
                (n.shadowOffsetX = Math.cos(t.dropShadowAngle) * i),
                (n.shadowOffsetY = Math.sin(t.dropShadowAngle) * i + m);
            } else
              (n.fillStyle = this._generateFillStyle(t, o, r)),
                (n.strokeStyle = t.stroke),
                (n.shadowColor = `black`),
                (n.shadowBlur = 0),
                (n.shadowOffsetX = 0),
                (n.shadowOffsetY = 0);
            let h = (s - u.fontSize) / 2;
            s - u.fontSize < 0 && (h = 0);
            for (let e = 0; e < o.length; e++)
              (d = t.strokeThickness / 2),
                (f = t.strokeThickness / 2 + e * s + u.ascent + h),
                t.align === `right`
                  ? (d += l - c[e])
                  : t.align === `center` && (d += (l - c[e]) / 2),
                t.stroke &&
                  t.strokeThickness &&
                  this.drawLetterSpacing(
                    o[e],
                    d + t.padding,
                    f + t.padding - p,
                    !0
                  ),
                t.fill &&
                  this.drawLetterSpacing(
                    o[e],
                    d + t.padding,
                    f + t.padding - p
                  );
          }
          this.updateTexture();
        }
        drawLetterSpacing(e, t, n, r = !1) {
          let i = this._style.letterSpacing,
            a = !1;
          if (
            ($.experimentalLetterSpacingSupported &&
              ($.experimentalLetterSpacing
                ? ((this.context.letterSpacing = `${i}px`),
                  (this.context.textLetterSpacing = `${i}px`),
                  (a = !0))
                : ((this.context.letterSpacing = `0px`),
                  (this.context.textLetterSpacing = `0px`))),
            i === 0 || a)
          ) {
            r
              ? this.context.strokeText(e, t, n)
              : this.context.fillText(e, t, n);
            return;
          }
          let o = t,
            s = $.graphemeSegmenter(e),
            c = this.context.measureText(e).width,
            l = 0;
          for (let e = 0; e < s.length; ++e) {
            let t = s[e];
            r
              ? this.context.strokeText(t, o, n)
              : this.context.fillText(t, o, n);
            let a = ``;
            for (let t = e + 1; t < s.length; ++t) a += s[t];
            (l = this.context.measureText(a).width), (o += c - l + i), (c = l);
          }
        }
        updateTexture() {
          let e = this.canvas;
          if (this._style.trim) {
            let t = yn(e);
            t.data &&
              ((e.width = t.width),
              (e.height = t.height),
              this.context.putImageData(t.data, 0, 0));
          }
          let t = this._texture,
            n = this._style,
            r = n.trim ? 0 : n.padding,
            i = t.baseTexture;
          (t.trim.width = t._frame.width = e.width / this._resolution),
            (t.trim.height = t._frame.height = e.height / this._resolution),
            (t.trim.x = -r),
            (t.trim.y = -r),
            (t.orig.width = t._frame.width - r * 2),
            (t.orig.height = t._frame.height - r * 2),
            this._onTextureUpdate(),
            i.setRealSize(e.width, e.height, this._resolution),
            t.updateUvs(),
            (this.dirty = !1);
        }
        _render(e) {
          this._autoResolution &&
            this._resolution !== e.resolution &&
            ((this._resolution = e.resolution), (this.dirty = !0)),
            this.updateText(!0),
            super._render(e);
        }
        updateTransform() {
          this.updateText(!0), super.updateTransform();
        }
        getBounds(e, t) {
          return (
            this.updateText(!0),
            this._textureID === -1 && (e = !1),
            super.getBounds(e, t)
          );
        }
        getLocalBounds(e) {
          return this.updateText(!0), super.getLocalBounds.call(this, e);
        }
        _calculateBounds() {
          this.calculateVertices(), this._bounds.addQuad(this.vertexData);
        }
        _generateFillStyle(e, t, n) {
          let r = e.fill;
          if (!Array.isArray(r)) return r;
          if (r.length === 1) return r[0];
          let i,
            a = e.dropShadow ? e.dropShadowDistance : 0,
            o = e.padding || 0,
            s = this.canvas.width / this._resolution - a - o * 2,
            c = this.canvas.height / this._resolution - a - o * 2,
            l = r.slice(),
            u = e.fillGradientStops.slice();
          if (!u.length) {
            let e = l.length + 1;
            for (let t = 1; t < e; ++t) u.push(t / e);
          }
          if (
            (l.unshift(r[0]),
            u.unshift(0),
            l.push(r[r.length - 1]),
            u.push(1),
            e.fillGradientType === cu.LINEAR_VERTICAL)
          ) {
            i = this.context.createLinearGradient(s / 2, o, s / 2, c + o);
            let r = n.fontProperties.fontSize + e.strokeThickness;
            for (let e = 0; e < t.length; e++) {
              let a = n.lineHeight * (e - 1) + r,
                o = n.lineHeight * e,
                s = o;
              e > 0 && a > o && (s = (o + a) / 2);
              let d = o + r,
                f = n.lineHeight * (e + 1),
                p = d;
              e + 1 < t.length && f < d && (p = (d + f) / 2);
              let m = (p - s) / c;
              for (let e = 0; e < l.length; e++) {
                let t = 0;
                t = typeof u[e] == `number` ? u[e] : e / l.length;
                let n = Math.min(1, Math.max(0, s / c + t * m));
                (n = Number(n.toFixed(5))), i.addColorStop(n, l[e]);
              }
            }
          } else {
            i = this.context.createLinearGradient(o, c / 2, s + o, c / 2);
            let e = l.length + 1,
              t = 1;
            for (let n = 0; n < l.length; n++) {
              let r;
              (r = typeof u[n] == `number` ? u[n] : t / e),
                i.addColorStop(r, l[n]),
                t++;
            }
          }
          return i;
        }
        destroy(e) {
          typeof e == `boolean` && (e = { children: e }),
            (e = Object.assign({}, yu, e)),
            super.destroy(e),
            this._ownCanvas && (this.canvas.height = this.canvas.width = 0),
            (this.context = null),
            (this.canvas = null),
            (this._style = null);
        }
        get width() {
          return (
            this.updateText(!0),
            Math.abs(this.scale.x) * this._texture.orig.width
          );
        }
        set width(e) {
          this.updateText(!0);
          let t = $t(this.scale.x) || 1;
          (this.scale.x = (t * e) / this._texture.orig.width),
            (this._width = e);
        }
        get height() {
          return (
            this.updateText(!0),
            Math.abs(this.scale.y) * this._texture.orig.height
          );
        }
        set height(e) {
          this.updateText(!0);
          let t = $t(this.scale.y) || 1;
          (this.scale.y = (t * e) / this._texture.orig.height),
            (this._height = e);
        }
        get style() {
          return this._style;
        }
        set style(e) {
          (e ||= {}),
            (this._style = e instanceof _u ? e : new _u(e)),
            (this.localStyleID = -1),
            (this.dirty = !0);
        }
        get text() {
          return this._text;
        }
        set text(e) {
          (e = String(e ?? ``)),
            this._text !== e && ((this._text = e), (this.dirty = !0));
        }
        get resolution() {
          return this._resolution;
        }
        set resolution(e) {
          (this._autoResolution = !1),
            this._resolution !== e &&
              ((this._resolution = e), (this.dirty = !0));
        }
      }),
      (xu = bu),
      (xu.defaultAutoResolution = !0);
  }))();
}
function Cu() {
  return (Cu = t(() => {
    lu(), Su(), du(), vu();
  }))();
}
var wu;
function Tu() {
  return (Tu = t(() => {
    wu = class {
      constructor(e) {
        (this.maxItemsPerFrame = e), (this.itemsLeft = 0);
      }
      beginFrame() {
        this.itemsLeft = this.maxItemsPerFrame;
      }
      allowedToUpload() {
        return this.itemsLeft-- > 0;
      }
    };
  }))();
}
function Eu(e, t) {
  let n = !1;
  if (e?._textures?.length) {
    for (let r = 0; r < e._textures.length; r++)
      if (e._textures[r] instanceof X) {
        let i = e._textures[r].baseTexture;
        t.includes(i) || (t.push(i), (n = !0));
      }
  }
  return n;
}
function Du(e, t) {
  if (e.baseTexture instanceof H) {
    let n = e.baseTexture;
    return t.includes(n) || t.push(n), !0;
  }
  return !1;
}
function Ou(e, t) {
  if (e._texture && e._texture instanceof X) {
    let n = e._texture.baseTexture;
    return t.includes(n) || t.push(n), !0;
  }
  return !1;
}
function ku(e, t) {
  return t instanceof xu && (t.updateText(!0), !0);
}
function Au(e, t) {
  if (t instanceof _u) {
    let e = t.toFontString();
    return $.measureFont(e), !0;
  }
  return !1;
}
function ju(e, t) {
  if (e instanceof xu) {
    t.includes(e.style) || t.push(e.style), t.includes(e) || t.push(e);
    let n = e._texture.baseTexture;
    return t.includes(n) || t.push(n), !0;
  }
  return !1;
}
function Mu(e, t) {
  return e instanceof _u && (t.includes(e) || t.push(e), !0);
}
var Nu, Pu;
function Fu() {
  return (Fu = t(() => {
    Z(),
      Tc(),
      Cu(),
      Tu(),
      (Nu = class {
        constructor(e) {
          (this.limiter = new wu(Nu.uploadsPerFrame)),
            (this.renderer = e),
            (this.uploadHookHelper = null),
            (this.queue = []),
            (this.addHooks = []),
            (this.uploadHooks = []),
            (this.completes = []),
            (this.ticking = !1),
            (this.delayedTick = () => {
              this.queue && this.prepareItems();
            }),
            this.registerFindHook(ju),
            this.registerFindHook(Mu),
            this.registerFindHook(Eu),
            this.registerFindHook(Du),
            this.registerFindHook(Ou),
            this.registerUploadHook(ku),
            this.registerUploadHook(Au);
        }
        upload(e) {
          return new Promise((t) => {
            e && this.add(e),
              this.queue.length
                ? (this.completes.push(t),
                  this.ticking ||
                    ((this.ticking = !0),
                    ks.system.addOnce(this.tick, this, ws.UTILITY)))
                : t();
          });
        }
        tick() {
          setTimeout(this.delayedTick, 0);
        }
        prepareItems() {
          for (
            this.limiter.beginFrame();
            this.queue.length && this.limiter.allowedToUpload();

          ) {
            let e = this.queue[0],
              t = !1;
            if (e && !e._destroyed) {
              for (let n = 0, r = this.uploadHooks.length; n < r; n++)
                if (this.uploadHooks[n](this.uploadHookHelper, e)) {
                  this.queue.shift(), (t = !0);
                  break;
                }
            }
            t || this.queue.shift();
          }
          if (this.queue.length) ks.system.addOnce(this.tick, this, ws.UTILITY);
          else {
            this.ticking = !1;
            let e = this.completes.slice(0);
            this.completes.length = 0;
            for (let t = 0, n = e.length; t < n; t++) e[t]();
          }
        }
        registerFindHook(e) {
          return e && this.addHooks.push(e), this;
        }
        registerUploadHook(e) {
          return e && this.uploadHooks.push(e), this;
        }
        add(e) {
          for (
            let t = 0, n = this.addHooks.length;
            t < n && !this.addHooks[t](e, this.queue);
            t++
          );
          if (e instanceof Sc)
            for (let t = e.children.length - 1; t >= 0; t--)
              this.add(e.children[t]);
          return this;
        }
        destroy() {
          this.ticking && ks.system.remove(this.tick, this),
            (this.ticking = !1),
            (this.addHooks = null),
            (this.uploadHooks = null),
            (this.renderer = null),
            (this.completes = null),
            (this.queue = null),
            (this.limiter = null),
            (this.uploadHookHelper = null);
        }
      }),
      (Pu = Nu),
      (Pu.uploadsPerFrame = 4);
  }))();
}
function Iu() {
  return (Iu = t(() => {
    Z(),
      Fu(),
      Object.defineProperties(D, {
        UPLOADS_PER_FRAME: {
          get() {
            return Pu.uploadsPerFrame;
          },
          set(e) {
            P(
              `7.1.0`,
              `settings.UPLOADS_PER_FRAME is deprecated, use prepare.BasePrepare.uploadsPerFrame`
            ),
              (Pu.uploadsPerFrame = e);
          },
        },
      });
  }))();
}
function Lu(e, t) {
  return (
    t instanceof H && (t._glTextures[e.CONTEXT_UID] || e.texture.bind(t), !0)
  );
}
function Ru(e, t) {
  if (!(t instanceof bl)) return !1;
  let { geometry: n } = t;
  t.finishPoly(), n.updateBatches();
  let { batches: r } = n;
  for (let t = 0; t < r.length; t++) {
    let { texture: n } = r[t].style;
    n && Lu(e, n.baseTexture);
  }
  return n.batchable || e.geometry.bind(n, t._resolveDirectShader(e)), !0;
}
function zu(e, t) {
  return e instanceof bl && (t.push(e), !0);
}
var Bu;
function Vu() {
  return (Vu = t(() => {
    Z(),
      Sl(),
      Fu(),
      (Bu = class extends Pu {
        constructor(e) {
          super(e),
            (this.uploadHookHelper = this.renderer),
            this.registerFindHook(zu),
            this.registerUploadHook(Lu),
            this.registerUploadHook(Ru);
        }
      }),
      (Bu.extension = { name: `prepare`, type: z.RendererSystem }),
      B.add(Bu);
  }))();
}
function Hu() {
  return (Hu = t(() => {
    Iu(), Fu(), Vu();
  }))();
}
var Uu, Wu;
function Gu() {
  return (Gu = t(() => {
    Z(),
      Ac(),
      (Uu = new G()),
      (Wu = class e extends Oc {
        constructor(e, t = 100, n = 100) {
          super(e),
            (this.tileTransform = new Wr()),
            (this._width = t),
            (this._height = n),
            (this.uvMatrix = this.texture.uvMatrix || new Qa(e)),
            (this.pluginName = `tilingSprite`),
            (this.uvRespectAnchor = !1);
        }
        get clampMargin() {
          return this.uvMatrix.clampMargin;
        }
        set clampMargin(e) {
          (this.uvMatrix.clampMargin = e), this.uvMatrix.update(!0);
        }
        get tileScale() {
          return this.tileTransform.scale;
        }
        set tileScale(e) {
          this.tileTransform.scale.copyFrom(e);
        }
        get tilePosition() {
          return this.tileTransform.position;
        }
        set tilePosition(e) {
          this.tileTransform.position.copyFrom(e);
        }
        _onTextureUpdate() {
          this.uvMatrix && (this.uvMatrix.texture = this._texture),
            (this._cachedTint = 16777215);
        }
        _render(e) {
          let t = this._texture;
          !t ||
            !t.valid ||
            (this.tileTransform.updateLocalTransform(),
            this.uvMatrix.update(),
            e.batch.setObjectRenderer(e.plugins[this.pluginName]),
            e.plugins[this.pluginName].render(this));
        }
        _calculateBounds() {
          let e = this._width * -this._anchor._x,
            t = this._height * -this._anchor._y,
            n = this._width * (1 - this._anchor._x),
            r = this._height * (1 - this._anchor._y);
          this._bounds.addFrame(this.transform, e, t, n, r);
        }
        getLocalBounds(e) {
          return this.children.length === 0
            ? ((this._bounds.minX = this._width * -this._anchor._x),
              (this._bounds.minY = this._height * -this._anchor._y),
              (this._bounds.maxX = this._width * (1 - this._anchor._x)),
              (this._bounds.maxY = this._height * (1 - this._anchor._y)),
              (e ||=
                ((this._localBoundsRect ||= new K()), this._localBoundsRect)),
              this._bounds.getRectangle(e))
            : super.getLocalBounds.call(this, e);
        }
        containsPoint(e) {
          this.worldTransform.applyInverse(e, Uu);
          let t = this._width,
            n = this._height,
            r = -t * this.anchor._x;
          if (Uu.x >= r && Uu.x < r + t) {
            let e = -n * this.anchor._y;
            if (Uu.y >= e && Uu.y < e + n) return !0;
          }
          return !1;
        }
        destroy(e) {
          super.destroy(e), (this.tileTransform = null), (this.uvMatrix = null);
        }
        static from(t, n) {
          let r = t instanceof X ? t : X.from(t, n);
          return new e(r, n.width, n.height);
        }
        get width() {
          return this._width;
        }
        set width(e) {
          this._width = e;
        }
        get height() {
          return this._height;
        }
        set height(e) {
          this._height = e;
        }
      });
  }))();
}
var Ku;
function qu() {
  return (qu = t(() => {
    Ku = `#version 300 es
#define SHADER_NAME Tiling-Sprite-100

precision lowp float;

in vec2 vTextureCoord;

out vec4 fragmentColor;

uniform sampler2D uSampler;
uniform vec4 uColor;
uniform mat3 uMapCoord;
uniform vec4 uClampFrame;
uniform vec2 uClampOffset;

void main(void)
{
    vec2 coord = vTextureCoord + ceil(uClampOffset - vTextureCoord);
    coord = (uMapCoord * vec3(coord, 1.0)).xy;
    vec2 unclamped = coord;
    coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);

    vec4 texSample = texture(uSampler, coord, unclamped == coord ? 0.0f : -32.0f);// lod-bias very negative to force lod 0

    fragmentColor = texSample * uColor;
}
`;
  }))();
}
var Ju;
function Yu() {
  return (Yu = t(() => {
    Ju = `#version 300 es
#define SHADER_NAME Tiling-Sprite-300

precision lowp float;

in vec2 aVertexPosition;
in vec2 aTextureCoord;

uniform mat3 projectionMatrix;
uniform mat3 translationMatrix;
uniform mat3 uTransform;

out vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = (uTransform * vec3(aTextureCoord, 1.0)).xy;
}
`;
  }))();
}
var Xu;
function Zu() {
  return (Zu = t(() => {
    Xu = `#version 100
#ifdef GL_EXT_shader_texture_lod
    #extension GL_EXT_shader_texture_lod : enable
#endif
#define SHADER_NAME Tiling-Sprite-100

precision lowp float;

varying vec2 vTextureCoord;

uniform sampler2D uSampler;
uniform vec4 uColor;
uniform mat3 uMapCoord;
uniform vec4 uClampFrame;
uniform vec2 uClampOffset;

void main(void)
{
    vec2 coord = vTextureCoord + ceil(uClampOffset - vTextureCoord);
    coord = (uMapCoord * vec3(coord, 1.0)).xy;
    vec2 unclamped = coord;
    coord = clamp(coord, uClampFrame.xy, uClampFrame.zw);

    #ifdef GL_EXT_shader_texture_lod
        vec4 texSample = unclamped == coord
            ? texture2D(uSampler, coord) 
            : texture2DLodEXT(uSampler, coord, 0);
    #else
        vec4 texSample = texture2D(uSampler, coord);
    #endif

    gl_FragColor = texSample * uColor;
}
`;
  }))();
}
var Qu;
function $u() {
  return ($u = t(() => {
    Qu = `#version 100
#define SHADER_NAME Tiling-Sprite-100

precision lowp float;

attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;
uniform mat3 translationMatrix;
uniform mat3 uTransform;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);

    vTextureCoord = (uTransform * vec3(aTextureCoord, 1.0)).xy;
}
`;
  }))();
}
var ed;
function td() {
  return (td = t(() => {
    ed = `#version 100
#define SHADER_NAME Tiling-Sprite-Simple-100

precision lowp float;

varying vec2 vTextureCoord;

uniform sampler2D uSampler;
uniform vec4 uColor;

void main(void)
{
    vec4 texSample = texture2D(uSampler, vTextureCoord);
    gl_FragColor = texSample * uColor;
}
`;
  }))();
}
var nd, rd;
function id() {
  return (id = t(() => {
    Z(),
      qu(),
      Yu(),
      Zu(),
      $u(),
      td(),
      (nd = new q()),
      (rd = class extends Gi {
        constructor(e) {
          super(e),
            e.runners.contextChange.add(this),
            (this.quad = new Fa()),
            (this.state = zn.for2d());
        }
        contextChange() {
          let e = this.renderer,
            t = { globals: e.globalUniforms };
          (this.simpleShader = Fi.from(Qu, ed, t)),
            (this.shader =
              e.context.webGLVersion > 1
                ? Fi.from(Ju, Ku, t)
                : Fi.from(Qu, Xu, t));
        }
        render(e) {
          let t = this.renderer,
            n = this.quad,
            r = n.vertices;
          (r[0] = r[6] = e._width * -e.anchor.x),
            (r[1] = r[3] = e._height * -e.anchor.y),
            (r[2] = r[4] = e._width * (1 - e.anchor.x)),
            (r[5] = r[7] = e._height * (1 - e.anchor.y));
          let i = e.uvRespectAnchor ? e.anchor.x : 0,
            a = e.uvRespectAnchor ? e.anchor.y : 0;
          (r = n.uvs),
            (r[0] = r[6] = -i),
            (r[1] = r[3] = -a),
            (r[2] = r[4] = 1 - i),
            (r[5] = r[7] = 1 - a),
            n.invalidate();
          let o = e._texture,
            s = o.baseTexture,
            c = s.alphaMode > 0,
            l = e.tileTransform.localTransform,
            u = e.uvMatrix,
            d =
              s.isPowerOfTwo &&
              o.frame.width === s.width &&
              o.frame.height === s.height;
          d &&
            (s._glTextures[t.CONTEXT_UID]
              ? (d = s.wrapMode !== h.CLAMP)
              : s.wrapMode === h.CLAMP && (s.wrapMode = h.REPEAT));
          let f = d ? this.simpleShader : this.shader,
            p = o.width,
            m = o.height,
            g = e._width,
            _ = e._height;
          nd.set(
            (l.a * p) / g,
            (l.b * p) / _,
            (l.c * m) / g,
            (l.d * m) / _,
            l.tx / g,
            l.ty / _
          ),
            nd.invert(),
            d
              ? nd.prepend(u.mapCoord)
              : ((f.uniforms.uMapCoord = u.mapCoord.toArray(!0)),
                (f.uniforms.uClampFrame = u.uClampFrame),
                (f.uniforms.uClampOffset = u.uClampOffset)),
            (f.uniforms.uTransform = nd.toArray(!0)),
            (f.uniforms.uColor = I.shared
              .setValue(e.tint)
              .premultiply(e.worldAlpha, c)
              .toArray(f.uniforms.uColor)),
            (f.uniforms.translationMatrix = e.transform.worldTransform.toArray(
              !0
            )),
            (f.uniforms.uSampler = o),
            t.shader.bind(f),
            t.geometry.bind(n),
            (this.state.blendMode = Ft(e.blendMode, c)),
            t.state.set(this.state),
            t.geometry.draw(this.renderer.gl.TRIANGLES, 6, 0);
        }
      }),
      (rd.extension = { name: `tilingSprite`, type: z.RendererPlugin }),
      B.add(rd);
  }))();
}
function ad() {
  return (ad = t(() => {
    Gu(), id();
  }))();
}
export {
  ec as $,
  V as $t,
  jl as A,
  l as An,
  Vr as At,
  Oc as B,
  G as Bt,
  ql as C,
  ge as Cn,
  aa as Ct,
  Pl as D,
  _ as Dn,
  Y as Dt,
  Il as E,
  D as En,
  ji as Et,
  xl as F,
  m as Fn,
  jr as Ft,
  gc as G,
  H as Gt,
  Tc as H,
  vr as Ht,
  Vc as I,
  f as In,
  Dr as It,
  hc as J,
  Xn as Jt,
  vc as K,
  $n as Kt,
  Bc as L,
  w as Ln,
  Or as Lt,
  kl as M,
  g as Mn,
  J as Mt,
  Sl as N,
  S as Nn,
  Br as Nt,
  Fl as O,
  c as On,
  Wr as Ot,
  bl as P,
  o as Pn,
  q as Pt,
  $s as Q,
  B as Qt,
  Uc as R,
  K as Rt,
  Kl as S,
  Pe as Sn,
  ca as St,
  Gl as T,
  O as Tn,
  Ai as Tt,
  Sc as U,
  W as Ut,
  kc as V,
  br as Vt,
  Cc as W,
  yr as Wt,
  sc as X,
  Pn as Xt,
  Z as Y,
  Nn as Yt,
  cc as Z,
  z as Zt,
  Zl as _,
  I as _n,
  va as _t,
  Pu as a,
  pn as an,
  ks as at,
  Jl as b,
  Le as bn,
  pa as bt,
  xu as c,
  tn as cn,
  Ts as ct,
  vu as d,
  Qt as dn,
  ss as dt,
  kn as en,
  qs as et,
  $ as f,
  Zt as fn,
  cs as ft,
  su as g,
  Mt as gn,
  Oa as gt,
  lu as h,
  Nt as hn,
  X as ht,
  Hu as i,
  Dn as in,
  Ps as it,
  Ol as j,
  u as jn,
  Hr as jt,
  Al as k,
  v as kn,
  Gr as kt,
  Su as l,
  en as ln,
  bs as lt,
  cu as m,
  At as mn,
  Aa as mt,
  Wu as n,
  On as nn,
  Fs as nt,
  Fu as o,
  mn as on,
  As as ot,
  du as p,
  kt as pn,
  ka as pt,
  mc as q,
  Yn as qt,
  Gu as r,
  En as rn,
  Ls as rt,
  Cu as s,
  rn as sn,
  ws as st,
  ad as t,
  R as tn,
  Js as tt,
  _u as u,
  $t as un,
  xs as ut,
  Ql as v,
  Dt as vn,
  ya as vt,
  Wl as w,
  he as wn,
  oa as wt,
  Yl as x,
  Fe as xn,
  sa as xt,
  Xl as y,
  P as yn,
  fa as yt,
  Ac as z,
  Sr as zt,
};
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/lib-BTerfQ6O.js.map
