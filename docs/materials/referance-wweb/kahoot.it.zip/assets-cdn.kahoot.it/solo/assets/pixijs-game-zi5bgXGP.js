import { a as e, n as t, t as n } from "./rolldown-runtime-B0Z9INg1.js";
import {
  $t as r,
  Fn as i,
  Go as a,
  Xt as o,
  ft as s,
  l as c,
  yl as l,
} from "./app-Bv1T6OmB.js";
import {
  $r as u,
  Eo as d,
  Qr as f,
  To as p,
  Xr as m,
  Yr as h,
  Zr as g,
  ci as _,
  ii as v,
  li as y,
  si as b,
  ui as x,
} from "./solo-z64LhsmC.js";
import {
  An as S,
  At as C,
  B as w,
  Bt as T,
  Ct as E,
  D,
  Dn as O,
  E as k,
  En as A,
  Fn as j,
  G as M,
  Gt as ee,
  H as N,
  In as P,
  It as te,
  Mn as ne,
  N as re,
  Nn as ie,
  On as F,
  Ot as ae,
  P as oe,
  Pt as se,
  Qt as I,
  Rt as ce,
  S as le,
  Sn as L,
  Tt as ue,
  U as de,
  X as fe,
  Y as R,
  Yt as pe,
  Zt as z,
  _n as me,
  an as he,
  at as ge,
  cn as _e,
  en as ve,
  et as ye,
  f as be,
  fn as xe,
  g as Se,
  gn as Ce,
  ht as B,
  i as we,
  j as Te,
  jn as Ee,
  k as De,
  kn as Oe,
  lt as ke,
  m as Ae,
  mn as je,
  n as Me,
  nt as Ne,
  pn as Pe,
  pt as Fe,
  qt as Ie,
  rn as Le,
  s as Re,
  st as ze,
  t as Be,
  tn as Ve,
  u as He,
  un as Ue,
  wn as We,
  xt as Ge,
  y as Ke,
  yn as qe,
  yt as Je,
  z as Ye,
} from "./lib-BTerfQ6O.js";
var Xe;
function Ze() {
  return (Ze = t(() => {
    Xe = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
}`;
  }))();
}
var Qe;
function $e() {
  return ($e = t(() => {
    Qe = `attribute vec2 aVertexPosition;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

uniform vec4 inputSize;
uniform vec4 outputFrame;

vec4 filterVertexPosition( void )
{
    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;

    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
}

vec2 filterTextureCoord( void )
{
    return aVertexPosition * (outputFrame.zw * inputSize.zw);
}

void main(void)
{
    gl_Position = filterVertexPosition();
    vTextureCoord = filterTextureCoord();
}
`;
  }))();
}
var et, tt;
function nt() {
  return (nt = t(() => {
    Ze(), $e(), (et = Xe), (tt = Qe);
  }))();
}
var rt, it;
function at() {
  return (at = t(() => {
    R(),
      N(),
      Ye(),
      (rt = new se()),
      (M.prototype._cacheAsBitmap = !1),
      (M.prototype._cacheData = null),
      (M.prototype._cacheAsBitmapResolution = null),
      (M.prototype._cacheAsBitmapMultisample = null),
      (it = class {
        constructor() {
          (this.textureCacheId = null),
            (this.originalRender = null),
            (this.originalRenderCanvas = null),
            (this.originalCalculateBounds = null),
            (this.originalGetLocalBounds = null),
            (this.originalUpdateTransform = null),
            (this.originalDestroy = null),
            (this.originalMask = null),
            (this.originalFilterArea = null),
            (this.originalContainsPoint = null),
            (this.sprite = null);
        }
      }),
      Object.defineProperties(M.prototype, {
        cacheAsBitmapResolution: {
          get() {
            return this._cacheAsBitmapResolution;
          },
          set(e) {
            e !== this._cacheAsBitmapResolution &&
              ((this._cacheAsBitmapResolution = e),
              (this.cacheAsBitmap &&= ((this.cacheAsBitmap = !1), !0)));
          },
        },
        cacheAsBitmapMultisample: {
          get() {
            return this._cacheAsBitmapMultisample;
          },
          set(e) {
            e !== this._cacheAsBitmapMultisample &&
              ((this._cacheAsBitmapMultisample = e),
              (this.cacheAsBitmap &&= ((this.cacheAsBitmap = !1), !0)));
          },
        },
        cacheAsBitmap: {
          get() {
            return this._cacheAsBitmap;
          },
          set(e) {
            if (this._cacheAsBitmap === e) return;
            this._cacheAsBitmap = e;
            let t;
            e
              ? ((this._cacheData ||= new it()),
                (t = this._cacheData),
                (t.originalRender = this.render),
                (t.originalRenderCanvas = this.renderCanvas),
                (t.originalUpdateTransform = this.updateTransform),
                (t.originalCalculateBounds = this.calculateBounds),
                (t.originalGetLocalBounds = this.getLocalBounds),
                (t.originalDestroy = this.destroy),
                (t.originalContainsPoint = this.containsPoint),
                (t.originalMask = this._mask),
                (t.originalFilterArea = this.filterArea),
                (this.render = this._renderCached),
                (this.renderCanvas = this._renderCachedCanvas),
                (this.destroy = this._cacheAsBitmapDestroy))
              : ((t = this._cacheData),
                t.sprite && this._destroyCachedDisplayObject(),
                (this.render = t.originalRender),
                (this.renderCanvas = t.originalRenderCanvas),
                (this.calculateBounds = t.originalCalculateBounds),
                (this.getLocalBounds = t.originalGetLocalBounds),
                (this.destroy = t.originalDestroy),
                (this.updateTransform = t.originalUpdateTransform),
                (this.containsPoint = t.originalContainsPoint),
                (this._mask = t.originalMask),
                (this.filterArea = t.originalFilterArea));
          },
        },
      }),
      (M.prototype._renderCached = function (e) {
        !this.visible ||
          this.worldAlpha <= 0 ||
          !this.renderable ||
          (this._initCachedDisplayObject(e),
          (this._cacheData.sprite.transform._worldID = this.transform._worldID),
          (this._cacheData.sprite.worldAlpha = this.worldAlpha),
          this._cacheData.sprite._render(e));
      }),
      (M.prototype._initCachedDisplayObject = function (e) {
        if (this._cacheData?.sprite) return;
        let t = this.alpha;
        (this.alpha = 1), e.batch.flush();
        let n = this.getLocalBounds(null, !0).clone();
        if (this.filters?.length) {
          let e = this.filters[0].padding;
          n.pad(e);
        }
        n.ceil(A.RESOLUTION);
        let r = e.renderTexture.current,
          i = e.renderTexture.sourceFrame.clone(),
          a = e.renderTexture.destinationFrame.clone(),
          o = e.projection.transform,
          s = Fe.create({
            width: n.width,
            height: n.height,
            resolution: this.cacheAsBitmapResolution || e.resolution,
            multisample: this.cacheAsBitmapMultisample ?? e.multisample,
          }),
          c = `cacheAsBitmap_${_e()}`;
        (this._cacheData.textureCacheId = c),
          ee.addToCache(s.baseTexture, c),
          B.addToCache(s, c);
        let l = this.transform.localTransform
          .copyTo(rt)
          .invert()
          .translate(-n.x, -n.y);
        (this.render = this._cacheData.originalRender),
          e.render(this, {
            renderTexture: s,
            clear: !0,
            transform: l,
            skipUpdateTransform: !1,
          }),
          e.framebuffer.blit(),
          (e.projection.transform = o),
          e.renderTexture.bind(r, i, a),
          (this.render = this._renderCached),
          (this.updateTransform = this.displayObjectUpdateTransform),
          (this.calculateBounds = this._calculateCachedBounds),
          (this.getLocalBounds = this._getCachedLocalBounds),
          (this._mask = null),
          (this.filterArea = null),
          (this.alpha = t);
        let u = new w(s);
        (u.transform.worldTransform = this.transform.worldTransform),
          (u.anchor.x = -(n.x / n.width)),
          (u.anchor.y = -(n.y / n.height)),
          (u.alpha = t),
          (u._bounds = this._bounds),
          (this._cacheData.sprite = u),
          (this.transform._parentID = -1),
          this.parent
            ? this.updateTransform()
            : (this.enableTempParent(),
              this.updateTransform(),
              this.disableTempParent(null)),
          (this.containsPoint = u.containsPoint.bind(u));
      }),
      (M.prototype._renderCachedCanvas = function (e) {
        !this.visible ||
          this.worldAlpha <= 0 ||
          !this.renderable ||
          (this._initCachedDisplayObjectCanvas(e),
          (this._cacheData.sprite.worldAlpha = this.worldAlpha),
          this._cacheData.sprite._renderCanvas(e));
      }),
      (M.prototype._initCachedDisplayObjectCanvas = function (e) {
        if (this._cacheData?.sprite) return;
        let t = this.getLocalBounds(null, !0),
          n = this.alpha;
        this.alpha = 1;
        let r = e.canvasContext.activeContext,
          i = e._projTransform;
        t.ceil(A.RESOLUTION);
        let a = Fe.create({ width: t.width, height: t.height }),
          o = `cacheAsBitmap_${_e()}`;
        (this._cacheData.textureCacheId = o),
          ee.addToCache(a.baseTexture, o),
          B.addToCache(a, o);
        let s = rt;
        this.transform.localTransform.copyTo(s),
          s.invert(),
          (s.tx -= t.x),
          (s.ty -= t.y),
          (this.renderCanvas = this._cacheData.originalRenderCanvas),
          e.render(this, {
            renderTexture: a,
            clear: !0,
            transform: s,
            skipUpdateTransform: !1,
          }),
          (e.canvasContext.activeContext = r),
          (e._projTransform = i),
          (this.renderCanvas = this._renderCachedCanvas),
          (this.updateTransform = this.displayObjectUpdateTransform),
          (this.calculateBounds = this._calculateCachedBounds),
          (this.getLocalBounds = this._getCachedLocalBounds),
          (this._mask = null),
          (this.filterArea = null),
          (this.alpha = n);
        let c = new w(a);
        (c.transform.worldTransform = this.transform.worldTransform),
          (c.anchor.x = -(t.x / t.width)),
          (c.anchor.y = -(t.y / t.height)),
          (c.alpha = n),
          (c._bounds = this._bounds),
          (this._cacheData.sprite = c),
          (this.transform._parentID = -1),
          this.parent
            ? this.updateTransform()
            : ((this.parent = e._tempDisplayObjectParent),
              this.updateTransform(),
              (this.parent = null)),
          (this.containsPoint = c.containsPoint.bind(c));
      }),
      (M.prototype._calculateCachedBounds = function () {
        this._bounds.clear(),
          (this._cacheData.sprite.transform._worldID = this.transform._worldID),
          this._cacheData.sprite._calculateBounds(),
          (this._bounds.updateID = this._boundsID);
      }),
      (M.prototype._getCachedLocalBounds = function () {
        return this._cacheData.sprite.getLocalBounds(null);
      }),
      (M.prototype._destroyCachedDisplayObject = function () {
        this._cacheData.sprite._texture.destroy(!0),
          (this._cacheData.sprite = null),
          ee.removeFromCache(this._cacheData.textureCacheId),
          B.removeFromCache(this._cacheData.textureCacheId),
          (this._cacheData.textureCacheId = null);
      }),
      (M.prototype._cacheAsBitmapDestroy = function (e) {
        (this.cacheAsBitmap = !1), this.destroy(e);
      });
  }))();
}
function ot() {
  return (ot = t(() => {
    N(),
      (M.prototype.name = null),
      (de.prototype.getChildByName = function (e, t) {
        for (let t = 0, n = this.children.length; t < n; t++)
          if (this.children[t].name === e) return this.children[t];
        if (t)
          for (let t = 0, n = this.children.length; t < n; t++) {
            let n = this.children[t];
            if (!n.getChildByName) continue;
            let r = n.getChildByName(e, !0);
            if (r) return r;
          }
        return null;
      });
  }))();
}
function st() {
  return (st = t(() => {
    R(),
      N(),
      (M.prototype.getGlobalPosition = function (e = new T(), t = !1) {
        return (
          this.parent
            ? this.parent.toGlobal(this.position, e, t)
            : ((e.x = this.position.x), (e.y = this.position.y)),
          e
        );
      });
  }))();
}
var ct;
function lt() {
  return (lt = t(() => {
    ct = `varying vec2 vTextureCoord;

uniform sampler2D uSampler;
uniform float uAlpha;

void main(void)
{
   gl_FragColor = texture2D(uSampler, vTextureCoord) * uAlpha;
}
`;
  }))();
}
var ut;
function dt() {
  return (dt = t(() => {
    R(),
      lt(),
      (ut = class extends E {
        constructor(e = 1) {
          super(et, ct, { uAlpha: 1 }), (this.alpha = e);
        }
        get alpha() {
          return this.uniforms.uAlpha;
        }
        set alpha(e) {
          this.uniforms.uAlpha = e;
        }
      });
  }))();
}
function ft() {
  return (ft = t(() => {
    dt();
  }))();
}
function pt(e) {
  let t = mt[e],
    n = t.length,
    r = ht,
    i = ``,
    a;
  for (let r = 0; r < e; r++) {
    let o =
      `gl_FragColor += texture2D(uSampler, vBlurTexCoords[%index%]) * %value%;`.replace(
        `%index%`,
        r.toString()
      );
    (a = r),
      r >= n && (a = e - r - 1),
      (o = o.replace(`%value%`, t[a].toString())),
      (i += o),
      (i += `
`);
  }
  return (
    (r = r.replace(`%blur%`, i)), (r = r.replace(`%size%`, e.toString())), r
  );
}
var mt, ht;
function gt() {
  return (gt = t(() => {
    (mt = {
      5: [0.153388, 0.221461, 0.250301],
      7: [0.071303, 0.131514, 0.189879, 0.214607],
      9: [0.028532, 0.067234, 0.124009, 0.179044, 0.20236],
      11: [0.0093, 0.028002, 0.065984, 0.121703, 0.175713, 0.198596],
      13: [
        0.002406, 0.009255, 0.027867, 0.065666, 0.121117, 0.174868, 0.197641,
      ],
      15: [
        489e-6, 0.002403, 0.009246, 0.02784, 0.065602, 0.120999, 0.174697,
        0.197448,
      ],
    }),
      (ht = [
        `varying vec2 vBlurTexCoords[%size%];`,
        `uniform sampler2D uSampler;`,
        `void main(void)`,
        `{`,
        `    gl_FragColor = vec4(0.0);`,
        `    %blur%`,
        `}`,
      ].join(`
`));
  }))();
}
function _t(e, t) {
  let n = Math.ceil(e / 2),
    r = vt,
    i = ``,
    a;
  a = t
    ? `vBlurTexCoords[%index%] =  textureCoord + vec2(%sampleIndex% * strength, 0.0);`
    : `vBlurTexCoords[%index%] =  textureCoord + vec2(0.0, %sampleIndex% * strength);`;
  for (let t = 0; t < e; t++) {
    let e = a.replace(`%index%`, t.toString());
    (e = e.replace(`%sampleIndex%`, `${t - (n - 1)}.0`)),
      (i += e),
      (i += `
`);
  }
  return (
    (r = r.replace(`%blur%`, i)), (r = r.replace(`%size%`, e.toString())), r
  );
}
var vt;
function yt() {
  return (yt = t(() => {
    vt = `
    attribute vec2 aVertexPosition;

    uniform mat3 projectionMatrix;

    uniform float strength;

    varying vec2 vBlurTexCoords[%size%];

    uniform vec4 inputSize;
    uniform vec4 outputFrame;

    vec4 filterVertexPosition( void )
    {
        vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;

        return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
    }

    vec2 filterTextureCoord( void )
    {
        return aVertexPosition * (outputFrame.zw * inputSize.zw);
    }

    void main(void)
    {
        gl_Position = filterVertexPosition();

        vec2 textureCoord = filterTextureCoord();
        %blur%
    }`;
  }))();
}
var bt;
function xt() {
  return (xt = t(() => {
    R(),
      gt(),
      yt(),
      (bt = class extends E {
        constructor(e, t = 8, n = 4, r = E.defaultResolution, i = 5) {
          let a = _t(i, e),
            o = pt(i);
          super(a, o),
            (this.horizontal = e),
            (this.resolution = r),
            (this._quality = 0),
            (this.quality = n),
            (this.blur = t);
        }
        apply(e, t, n, r) {
          if (
            (n
              ? this.horizontal
                ? (this.uniforms.strength = (1 / n.width) * (n.width / t.width))
                : (this.uniforms.strength =
                    (1 / n.height) * (n.height / t.height))
              : this.horizontal
              ? (this.uniforms.strength =
                  (1 / e.renderer.width) * (e.renderer.width / t.width))
              : (this.uniforms.strength =
                  (1 / e.renderer.height) * (e.renderer.height / t.height)),
            (this.uniforms.strength *= this.strength),
            (this.uniforms.strength /= this.passes),
            this.passes === 1)
          )
            e.applyFilter(this, t, n, r);
          else {
            let i = e.getFilterTexture(),
              a = e.renderer,
              o = t,
              s = i;
            (this.state.blend = !1), e.applyFilter(this, o, s, Oe.CLEAR);
            for (let t = 1; t < this.passes - 1; t++) {
              e.bindAndClear(o, Oe.BLIT), (this.uniforms.uSampler = s);
              let t = s;
              (s = o), (o = t), a.shader.bind(this), a.geometry.draw(5);
            }
            (this.state.blend = !0),
              e.applyFilter(this, s, n, r),
              e.returnFilterTexture(i);
          }
        }
        get blur() {
          return this.strength;
        }
        set blur(e) {
          (this.padding = 1 + Math.abs(e) * 2), (this.strength = e);
        }
        get quality() {
          return this._quality;
        }
        set quality(e) {
          (this._quality = e), (this.passes = e);
        }
      });
  }))();
}
var St;
function Ct() {
  return (Ct = t(() => {
    R(),
      xt(),
      (St = class extends E {
        constructor(e = 8, t = 4, n = E.defaultResolution, r = 5) {
          super(),
            (this._repeatEdgePixels = !1),
            (this.blurXFilter = new bt(!0, e, t, n, r)),
            (this.blurYFilter = new bt(!1, e, t, n, r)),
            (this.resolution = n),
            (this.quality = t),
            (this.blur = e),
            (this.repeatEdgePixels = !1);
        }
        apply(e, t, n, r) {
          let i = Math.abs(this.blurXFilter.strength),
            a = Math.abs(this.blurYFilter.strength);
          if (i && a) {
            let i = e.getFilterTexture();
            this.blurXFilter.apply(e, t, i, Oe.CLEAR),
              this.blurYFilter.apply(e, i, n, r),
              e.returnFilterTexture(i);
          } else
            a
              ? this.blurYFilter.apply(e, t, n, r)
              : this.blurXFilter.apply(e, t, n, r);
        }
        updatePadding() {
          this.padding = this._repeatEdgePixels
            ? 0
            : Math.max(
                Math.abs(this.blurXFilter.strength),
                Math.abs(this.blurYFilter.strength)
              ) * 2;
        }
        get blur() {
          return this.blurXFilter.blur;
        }
        set blur(e) {
          (this.blurXFilter.blur = this.blurYFilter.blur = e),
            this.updatePadding();
        }
        get quality() {
          return this.blurXFilter.quality;
        }
        set quality(e) {
          this.blurXFilter.quality = this.blurYFilter.quality = e;
        }
        get blurX() {
          return this.blurXFilter.blur;
        }
        set blurX(e) {
          (this.blurXFilter.blur = e), this.updatePadding();
        }
        get blurY() {
          return this.blurYFilter.blur;
        }
        set blurY(e) {
          (this.blurYFilter.blur = e), this.updatePadding();
        }
        get blendMode() {
          return this.blurYFilter.blendMode;
        }
        set blendMode(e) {
          this.blurYFilter.blendMode = e;
        }
        get repeatEdgePixels() {
          return this._repeatEdgePixels;
        }
        set repeatEdgePixels(e) {
          (this._repeatEdgePixels = e), this.updatePadding();
        }
      });
  }))();
}
function wt() {
  return (wt = t(() => {
    Ct(), xt();
  }))();
}
var Tt;
function Et() {
  return (Et = t(() => {
    Tt = `varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform float m[20];
uniform float uAlpha;

void main(void)
{
    vec4 c = texture2D(uSampler, vTextureCoord);

    if (uAlpha == 0.0) {
        gl_FragColor = c;
        return;
    }

    // Un-premultiply alpha before applying the color matrix. See issue #3539.
    if (c.a > 0.0) {
      c.rgb /= c.a;
    }

    vec4 result;

    result.r = (m[0] * c.r);
        result.r += (m[1] * c.g);
        result.r += (m[2] * c.b);
        result.r += (m[3] * c.a);
        result.r += m[4];

    result.g = (m[5] * c.r);
        result.g += (m[6] * c.g);
        result.g += (m[7] * c.b);
        result.g += (m[8] * c.a);
        result.g += m[9];

    result.b = (m[10] * c.r);
       result.b += (m[11] * c.g);
       result.b += (m[12] * c.b);
       result.b += (m[13] * c.a);
       result.b += m[14];

    result.a = (m[15] * c.r);
       result.a += (m[16] * c.g);
       result.a += (m[17] * c.b);
       result.a += (m[18] * c.a);
       result.a += m[19];

    vec3 rgb = mix(c.rgb, result.rgb, uAlpha);

    // Premultiply alpha again.
    rgb *= result.a;

    gl_FragColor = vec4(rgb, result.a);
}
`;
  }))();
}
var Dt;
function Ot() {
  return (Ot = t(() => {
    R(),
      Et(),
      (Dt = class extends E {
        constructor() {
          let e = {
            m: new Float32Array([
              1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0,
            ]),
            uAlpha: 1,
          };
          super(tt, Tt, e), (this.alpha = 1);
        }
        _loadMatrix(e, t = !1) {
          let n = e;
          t &&
            (this._multiply(n, this.uniforms.m, e), (n = this._colorMatrix(n))),
            (this.uniforms.m = n);
        }
        _multiply(e, t, n) {
          return (
            (e[0] = t[0] * n[0] + t[1] * n[5] + t[2] * n[10] + t[3] * n[15]),
            (e[1] = t[0] * n[1] + t[1] * n[6] + t[2] * n[11] + t[3] * n[16]),
            (e[2] = t[0] * n[2] + t[1] * n[7] + t[2] * n[12] + t[3] * n[17]),
            (e[3] = t[0] * n[3] + t[1] * n[8] + t[2] * n[13] + t[3] * n[18]),
            (e[4] =
              t[0] * n[4] + t[1] * n[9] + t[2] * n[14] + t[3] * n[19] + t[4]),
            (e[5] = t[5] * n[0] + t[6] * n[5] + t[7] * n[10] + t[8] * n[15]),
            (e[6] = t[5] * n[1] + t[6] * n[6] + t[7] * n[11] + t[8] * n[16]),
            (e[7] = t[5] * n[2] + t[6] * n[7] + t[7] * n[12] + t[8] * n[17]),
            (e[8] = t[5] * n[3] + t[6] * n[8] + t[7] * n[13] + t[8] * n[18]),
            (e[9] =
              t[5] * n[4] + t[6] * n[9] + t[7] * n[14] + t[8] * n[19] + t[9]),
            (e[10] =
              t[10] * n[0] + t[11] * n[5] + t[12] * n[10] + t[13] * n[15]),
            (e[11] =
              t[10] * n[1] + t[11] * n[6] + t[12] * n[11] + t[13] * n[16]),
            (e[12] =
              t[10] * n[2] + t[11] * n[7] + t[12] * n[12] + t[13] * n[17]),
            (e[13] =
              t[10] * n[3] + t[11] * n[8] + t[12] * n[13] + t[13] * n[18]),
            (e[14] =
              t[10] * n[4] +
              t[11] * n[9] +
              t[12] * n[14] +
              t[13] * n[19] +
              t[14]),
            (e[15] =
              t[15] * n[0] + t[16] * n[5] + t[17] * n[10] + t[18] * n[15]),
            (e[16] =
              t[15] * n[1] + t[16] * n[6] + t[17] * n[11] + t[18] * n[16]),
            (e[17] =
              t[15] * n[2] + t[16] * n[7] + t[17] * n[12] + t[18] * n[17]),
            (e[18] =
              t[15] * n[3] + t[16] * n[8] + t[17] * n[13] + t[18] * n[18]),
            (e[19] =
              t[15] * n[4] +
              t[16] * n[9] +
              t[17] * n[14] +
              t[18] * n[19] +
              t[19]),
            e
          );
        }
        _colorMatrix(e) {
          let t = new Float32Array(e);
          return (
            (t[4] /= 255), (t[9] /= 255), (t[14] /= 255), (t[19] /= 255), t
          );
        }
        brightness(e, t) {
          let n = [e, 0, 0, 0, 0, 0, e, 0, 0, 0, 0, 0, e, 0, 0, 0, 0, 0, 1, 0];
          this._loadMatrix(n, t);
        }
        tint(e, t) {
          let [n, r, i] = me.shared.setValue(e).toArray(),
            a = [n, 0, 0, 0, 0, 0, r, 0, 0, 0, 0, 0, i, 0, 0, 0, 0, 0, 1, 0];
          this._loadMatrix(a, t);
        }
        greyscale(e, t) {
          let n = [e, e, e, 0, 0, e, e, e, 0, 0, e, e, e, 0, 0, 0, 0, 0, 1, 0];
          this._loadMatrix(n, t);
        }
        blackAndWhite(e) {
          this._loadMatrix(
            [
              0.3, 0.6, 0.1, 0, 0, 0.3, 0.6, 0.1, 0, 0, 0.3, 0.6, 0.1, 0, 0, 0,
              0, 0, 1, 0,
            ],
            e
          );
        }
        hue(e, t) {
          e = ((e || 0) / 180) * Math.PI;
          let n = Math.cos(e),
            r = Math.sin(e),
            i = Math.sqrt,
            a = 1 / 3,
            o = i(a),
            s = [
              n + (1 - n) * a,
              a * (1 - n) - o * r,
              a * (1 - n) + o * r,
              0,
              0,
              a * (1 - n) + o * r,
              n + a * (1 - n),
              a * (1 - n) - o * r,
              0,
              0,
              a * (1 - n) - o * r,
              a * (1 - n) + o * r,
              n + a * (1 - n),
              0,
              0,
              0,
              0,
              0,
              1,
              0,
            ];
          this._loadMatrix(s, t);
        }
        contrast(e, t) {
          let n = (e || 0) + 1,
            r = -0.5 * (n - 1),
            i = [n, 0, 0, 0, r, 0, n, 0, 0, r, 0, 0, n, 0, r, 0, 0, 0, 1, 0];
          this._loadMatrix(i, t);
        }
        saturate(e = 0, t) {
          let n = (e * 2) / 3 + 1,
            r = (n - 1) * -0.5,
            i = [n, r, r, 0, 0, r, n, r, 0, 0, r, r, n, 0, 0, 0, 0, 0, 1, 0];
          this._loadMatrix(i, t);
        }
        desaturate() {
          this.saturate(-1);
        }
        negative(e) {
          this._loadMatrix(
            [-1, 0, 0, 1, 0, 0, -1, 0, 1, 0, 0, 0, -1, 1, 0, 0, 0, 0, 1, 0],
            e
          );
        }
        sepia(e) {
          this._loadMatrix(
            [
              0.393, 0.7689999, 0.18899999, 0, 0, 0.349, 0.6859999, 0.16799999,
              0, 0, 0.272, 0.5339999, 0.13099999, 0, 0, 0, 0, 0, 1, 0,
            ],
            e
          );
        }
        technicolor(e) {
          this._loadMatrix(
            [
              1.9125277891456083, -0.8545344976951645, -0.09155508482755585, 0,
              11.793603434377337, -0.3087833385928097, 1.7658908555458428,
              -0.10601743074722245, 0, -70.35205161461398, -0.231103377548616,
              -0.7501899197440212, 1.847597816108189, 0, 30.950940869491138, 0,
              0, 0, 1, 0,
            ],
            e
          );
        }
        polaroid(e) {
          this._loadMatrix(
            [
              1.438, -0.062, -0.062, 0, 0, -0.122, 1.378, -0.122, 0, 0, -0.016,
              -0.016, 1.483, 0, 0, 0, 0, 0, 1, 0,
            ],
            e
          );
        }
        toBGR(e) {
          this._loadMatrix(
            [0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0],
            e
          );
        }
        kodachrome(e) {
          this._loadMatrix(
            [
              1.1285582396593525, -0.3967382283601348, -0.03992559172921793, 0,
              63.72958762196502, -0.16404339962244616, 1.0835251566291304,
              -0.05498805115633132, 0, 24.732407896706203, -0.16786010706155763,
              -0.5603416277695248, 1.6014850761964943, 0, 35.62982807460946, 0,
              0, 0, 1, 0,
            ],
            e
          );
        }
        browni(e) {
          this._loadMatrix(
            [
              0.5997023498159715, 0.34553243048391263, -0.2708298674538042, 0,
              47.43192855600873, -0.037703249837783157, 0.8609577587992641,
              0.15059552388459913, 0, -36.96841498319127, 0.24113635128153335,
              -0.07441037908422492, 0.44972182064877153, 0, -7.562075277591283,
              0, 0, 0, 1, 0,
            ],
            e
          );
        }
        vintage(e) {
          this._loadMatrix(
            [
              0.6279345635605994, 0.3202183420819367, -0.03965408211312453, 0,
              9.651285835294123, 0.02578397704808868, 0.6441188644374771,
              0.03259127616149294, 0, 7.462829176470591, 0.0466055556782719,
              -0.0851232987247891, 0.5241648018700465, 0, 5.159190588235296, 0,
              0, 0, 1, 0,
            ],
            e
          );
        }
        colorTone(e, t, n, r, i) {
          (e ||= 0.2), (t ||= 0.15), (n ||= 16770432), (r ||= 3375104);
          let a = me.shared,
            [o, s, c] = a.setValue(n).toArray(),
            [l, u, d] = a.setValue(r).toArray(),
            f = [
              0.3,
              0.59,
              0.11,
              0,
              0,
              o,
              s,
              c,
              e,
              0,
              l,
              u,
              d,
              t,
              0,
              o - l,
              s - u,
              c - d,
              0,
              0,
            ];
          this._loadMatrix(f, i);
        }
        night(e, t) {
          e ||= 0.1;
          let n = [
            e * -2,
            -e,
            0,
            0,
            0,
            -e,
            0,
            e,
            0,
            0,
            0,
            e,
            e * 2,
            0,
            0,
            0,
            0,
            0,
            1,
            0,
          ];
          this._loadMatrix(n, t);
        }
        predator(e, t) {
          let n = [
            11.224130630493164 * e,
            -4.794486999511719 * e,
            -2.8746118545532227 * e,
            0 * e,
            0.40342438220977783 * e,
            -3.6330697536468506 * e,
            9.193157196044922 * e,
            -2.951810836791992 * e,
            0 * e,
            -1.316135048866272 * e,
            -3.2184197902679443 * e,
            -4.2375030517578125 * e,
            7.476448059082031 * e,
            0 * e,
            0.8044459223747253 * e,
            0,
            0,
            0,
            1,
            0,
          ];
          this._loadMatrix(n, t);
        }
        lsd(e) {
          this._loadMatrix(
            [
              2, -0.4, 0.5, 0, 0, -0.5, 2, -0.4, 0, 0, -0.4, -0.5, 3, 0, 0, 0,
              0, 0, 1, 0,
            ],
            e
          );
        }
        reset() {
          this._loadMatrix(
            [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0],
            !1
          );
        }
        get matrix() {
          return this.uniforms.m;
        }
        set matrix(e) {
          this.uniforms.m = e;
        }
        get alpha() {
          return this.uniforms.uAlpha;
        }
        set alpha(e) {
          this.uniforms.uAlpha = e;
        }
      }),
      (Dt.prototype.grayscale = Dt.prototype.greyscale);
  }))();
}
function kt() {
  return (kt = t(() => {
    Ot();
  }))();
}
var At;
function jt() {
  return (jt = t(() => {
    At = `varying vec2 vFilterCoord;
varying vec2 vTextureCoord;

uniform vec2 scale;
uniform mat2 rotation;
uniform sampler2D uSampler;
uniform sampler2D mapSampler;

uniform highp vec4 inputSize;
uniform vec4 inputClamp;

void main(void)
{
  vec4 map =  texture2D(mapSampler, vFilterCoord);

  map -= 0.5;
  map.xy = scale * inputSize.zw * (rotation * map.xy);

  gl_FragColor = texture2D(uSampler, clamp(vec2(vTextureCoord.x + map.x, vTextureCoord.y + map.y), inputClamp.xy, inputClamp.zw));
}
`;
  }))();
}
var Mt;
function Nt() {
  return (Nt = t(() => {
    Mt = `attribute vec2 aVertexPosition;

uniform mat3 projectionMatrix;
uniform mat3 filterMatrix;

varying vec2 vTextureCoord;
varying vec2 vFilterCoord;

uniform vec4 inputSize;
uniform vec4 outputFrame;

vec4 filterVertexPosition( void )
{
    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;

    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
}

vec2 filterTextureCoord( void )
{
    return aVertexPosition * (outputFrame.zw * inputSize.zw);
}

void main(void)
{
	gl_Position = filterVertexPosition();
	vTextureCoord = filterTextureCoord();
	vFilterCoord = ( filterMatrix * vec3( vTextureCoord, 1.0)  ).xy;
}
`;
  }))();
}
var Pt;
function Ft() {
  return (Ft = t(() => {
    R(),
      jt(),
      Nt(),
      (Pt = class extends E {
        constructor(e, t) {
          let n = new se();
          (e.renderable = !1),
            super(Mt, At, {
              mapSampler: e._texture,
              filterMatrix: n,
              scale: { x: 1, y: 1 },
              rotation: new Float32Array([1, 0, 0, 1]),
            }),
            (this.maskSprite = e),
            (this.maskMatrix = n),
            (t ??= 20),
            (this.scale = new T(t, t));
        }
        apply(e, t, n, r) {
          (this.uniforms.filterMatrix = e.calculateSpriteMatrix(
            this.maskMatrix,
            this.maskSprite
          )),
            (this.uniforms.scale.x = this.scale.x),
            (this.uniforms.scale.y = this.scale.y);
          let i = this.maskSprite.worldTransform,
            a = Math.sqrt(i.a * i.a + i.b * i.b),
            o = Math.sqrt(i.c * i.c + i.d * i.d);
          a !== 0 &&
            o !== 0 &&
            ((this.uniforms.rotation[0] = i.a / a),
            (this.uniforms.rotation[1] = i.b / a),
            (this.uniforms.rotation[2] = i.c / o),
            (this.uniforms.rotation[3] = i.d / o)),
            e.applyFilter(this, t, n, r);
        }
        get map() {
          return this.uniforms.mapSampler;
        }
        set map(e) {
          this.uniforms.mapSampler = e;
        }
      });
  }))();
}
function It() {
  return (It = t(() => {
    Ft();
  }))();
}
var Lt;
function Rt() {
  return (Rt = t(() => {
    Lt = `varying vec2 v_rgbNW;
varying vec2 v_rgbNE;
varying vec2 v_rgbSW;
varying vec2 v_rgbSE;
varying vec2 v_rgbM;

varying vec2 vFragCoord;
uniform sampler2D uSampler;
uniform highp vec4 inputSize;


/**
 Basic FXAA implementation based on the code on geeks3d.com with the
 modification that the texture2DLod stuff was removed since it's
 unsupported by WebGL.

 --

 From:
 https://github.com/mitsuhiko/webgl-meincraft

 Copyright (c) 2011 by Armin Ronacher.

 Some rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are
 met:

 * Redistributions of source code must retain the above copyright
 notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above
 copyright notice, this list of conditions and the following
 disclaimer in the documentation and/or other materials provided
 with the distribution.

 * The names of the contributors may not be used to endorse or
 promote products derived from this software without specific
 prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef FXAA_REDUCE_MIN
#define FXAA_REDUCE_MIN   (1.0/ 128.0)
#endif
#ifndef FXAA_REDUCE_MUL
#define FXAA_REDUCE_MUL   (1.0 / 8.0)
#endif
#ifndef FXAA_SPAN_MAX
#define FXAA_SPAN_MAX     8.0
#endif

//optimized version for mobile, where dependent
//texture reads can be a bottleneck
vec4 fxaa(sampler2D tex, vec2 fragCoord, vec2 inverseVP,
          vec2 v_rgbNW, vec2 v_rgbNE,
          vec2 v_rgbSW, vec2 v_rgbSE,
          vec2 v_rgbM) {
    vec4 color;
    vec3 rgbNW = texture2D(tex, v_rgbNW).xyz;
    vec3 rgbNE = texture2D(tex, v_rgbNE).xyz;
    vec3 rgbSW = texture2D(tex, v_rgbSW).xyz;
    vec3 rgbSE = texture2D(tex, v_rgbSE).xyz;
    vec4 texColor = texture2D(tex, v_rgbM);
    vec3 rgbM  = texColor.xyz;
    vec3 luma = vec3(0.299, 0.587, 0.114);
    float lumaNW = dot(rgbNW, luma);
    float lumaNE = dot(rgbNE, luma);
    float lumaSW = dot(rgbSW, luma);
    float lumaSE = dot(rgbSE, luma);
    float lumaM  = dot(rgbM,  luma);
    float lumaMin = min(lumaM, min(min(lumaNW, lumaNE), min(lumaSW, lumaSE)));
    float lumaMax = max(lumaM, max(max(lumaNW, lumaNE), max(lumaSW, lumaSE)));

    mediump vec2 dir;
    dir.x = -((lumaNW + lumaNE) - (lumaSW + lumaSE));
    dir.y =  ((lumaNW + lumaSW) - (lumaNE + lumaSE));

    float dirReduce = max((lumaNW + lumaNE + lumaSW + lumaSE) *
                          (0.25 * FXAA_REDUCE_MUL), FXAA_REDUCE_MIN);

    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = min(vec2(FXAA_SPAN_MAX, FXAA_SPAN_MAX),
              max(vec2(-FXAA_SPAN_MAX, -FXAA_SPAN_MAX),
                  dir * rcpDirMin)) * inverseVP;

    vec3 rgbA = 0.5 * (
                       texture2D(tex, fragCoord * inverseVP + dir * (1.0 / 3.0 - 0.5)).xyz +
                       texture2D(tex, fragCoord * inverseVP + dir * (2.0 / 3.0 - 0.5)).xyz);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (
                                     texture2D(tex, fragCoord * inverseVP + dir * -0.5).xyz +
                                     texture2D(tex, fragCoord * inverseVP + dir * 0.5).xyz);

    float lumaB = dot(rgbB, luma);
    if ((lumaB < lumaMin) || (lumaB > lumaMax))
        color = vec4(rgbA, texColor.a);
    else
        color = vec4(rgbB, texColor.a);
    return color;
}

void main() {

      vec4 color;

      color = fxaa(uSampler, vFragCoord, inputSize.zw, v_rgbNW, v_rgbNE, v_rgbSW, v_rgbSE, v_rgbM);

      gl_FragColor = color;
}
`;
  }))();
}
var zt;
function Bt() {
  return (Bt = t(() => {
    zt = `
attribute vec2 aVertexPosition;

uniform mat3 projectionMatrix;

varying vec2 v_rgbNW;
varying vec2 v_rgbNE;
varying vec2 v_rgbSW;
varying vec2 v_rgbSE;
varying vec2 v_rgbM;

varying vec2 vFragCoord;

uniform vec4 inputSize;
uniform vec4 outputFrame;

vec4 filterVertexPosition( void )
{
    vec2 position = aVertexPosition * max(outputFrame.zw, vec2(0.)) + outputFrame.xy;

    return vec4((projectionMatrix * vec3(position, 1.0)).xy, 0.0, 1.0);
}

void texcoords(vec2 fragCoord, vec2 inverseVP,
               out vec2 v_rgbNW, out vec2 v_rgbNE,
               out vec2 v_rgbSW, out vec2 v_rgbSE,
               out vec2 v_rgbM) {
    v_rgbNW = (fragCoord + vec2(-1.0, -1.0)) * inverseVP;
    v_rgbNE = (fragCoord + vec2(1.0, -1.0)) * inverseVP;
    v_rgbSW = (fragCoord + vec2(-1.0, 1.0)) * inverseVP;
    v_rgbSE = (fragCoord + vec2(1.0, 1.0)) * inverseVP;
    v_rgbM = vec2(fragCoord * inverseVP);
}

void main(void) {

   gl_Position = filterVertexPosition();

   vFragCoord = aVertexPosition * outputFrame.zw;

   texcoords(vFragCoord, inputSize.zw, v_rgbNW, v_rgbNE, v_rgbSW, v_rgbSE, v_rgbM);
}
`;
  }))();
}
var Vt;
function Ht() {
  return (Ht = t(() => {
    R(),
      Rt(),
      Bt(),
      (Vt = class extends E {
        constructor() {
          super(zt, Lt);
        }
      });
  }))();
}
function Ut() {
  return (Ut = t(() => {
    Ht();
  }))();
}
var Wt;
function Gt() {
  return (Gt = t(() => {
    Wt = `precision highp float;

varying vec2 vTextureCoord;
varying vec4 vColor;

uniform float uNoise;
uniform float uSeed;
uniform sampler2D uSampler;

float rand(vec2 co)
{
    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main()
{
    vec4 color = texture2D(uSampler, vTextureCoord);
    float randomValue = rand(gl_FragCoord.xy * uSeed);
    float diff = (randomValue - 0.5) * uNoise;

    // Un-premultiply alpha before applying the color matrix. See issue #3539.
    if (color.a > 0.0) {
        color.rgb /= color.a;
    }

    color.r += diff;
    color.g += diff;
    color.b += diff;

    // Premultiply alpha again.
    color.rgb *= color.a;

    gl_FragColor = color;
}
`;
  }))();
}
var Kt;
function qt() {
  return (qt = t(() => {
    R(),
      Gt(),
      (Kt = class extends E {
        constructor(e = 0.5, t = Math.random()) {
          super(tt, Wt, { uNoise: 0, uSeed: 0 }),
            (this.noise = e),
            (this.seed = t);
        }
        get noise() {
          return this.uniforms.uNoise;
        }
        set noise(e) {
          this.uniforms.uNoise = e;
        }
        get seed() {
          return this.uniforms.uSeed;
        }
        set seed(e) {
          this.uniforms.uSeed = e;
        }
      });
  }))();
}
function Jt() {
  return (Jt = t(() => {
    qt();
  }))();
}
var Yt;
function Xt() {
  return (Xt = t(() => {
    R(),
      ft(),
      wt(),
      kt(),
      It(),
      Ut(),
      Jt(),
      (Yt = {
        AlphaFilter: ut,
        BlurFilter: St,
        BlurFilterPass: bt,
        ColorMatrixFilter: Dt,
        DisplacementFilter: Pt,
        FXAAFilter: Vt,
        NoiseFilter: Kt,
      }),
      Object.entries(Yt).forEach(([e, t]) => {
        Object.defineProperty(Yt, e, {
          get() {
            return qe(`7.1.0`, `filters.${e} has moved to ${e}`), t;
          },
        });
      });
  }))();
}
var Zt, Qt;
function $t() {
  return ($t = t(() => {
    R(),
      (Zt = class {
        constructor() {
          (this.interactionFrequency = 10),
            (this._deltaTime = 0),
            (this._didMove = !1),
            (this.tickerAdded = !1),
            (this._pauseUpdate = !0);
        }
        init(e) {
          this.removeTickerListener(),
            (this.events = e),
            (this.interactionFrequency = 10),
            (this._deltaTime = 0),
            (this._didMove = !1),
            (this.tickerAdded = !1),
            (this._pauseUpdate = !0);
        }
        get pauseUpdate() {
          return this._pauseUpdate;
        }
        set pauseUpdate(e) {
          this._pauseUpdate = e;
        }
        addTickerListener() {
          this.tickerAdded ||
            !this.domElement ||
            (ge.system.add(this.tickerUpdate, this, ze.INTERACTION),
            (this.tickerAdded = !0));
        }
        removeTickerListener() {
          this.tickerAdded &&= (ge.system.remove(this.tickerUpdate, this), !1);
        }
        pointerMoved() {
          this._didMove = !0;
        }
        update() {
          if (!this.domElement || this._pauseUpdate) return;
          if (this._didMove) {
            this._didMove = !1;
            return;
          }
          let e = this.events.rootPointerEvent;
          (this.events.supportsTouchEvents && e.pointerType === `touch`) ||
            globalThis.document.dispatchEvent(
              new PointerEvent(`pointermove`, {
                clientX: e.clientX,
                clientY: e.clientY,
              })
            );
        }
        tickerUpdate(e) {
          (this._deltaTime += e),
            !(this._deltaTime < this.interactionFrequency) &&
              ((this._deltaTime = 0), this.update());
        }
      }),
      (Qt = new Zt());
  }))();
}
var en;
function tn() {
  return (tn = t(() => {
    R(),
      (en = class e {
        constructor(t) {
          (this.bubbles = !0),
            (this.cancelBubble = !0),
            (this.cancelable = !1),
            (this.composed = !1),
            (this.defaultPrevented = !1),
            (this.eventPhase = e.prototype.NONE),
            (this.propagationStopped = !1),
            (this.propagationImmediatelyStopped = !1),
            (this.layer = new T()),
            (this.page = new T()),
            (this.NONE = 0),
            (this.CAPTURING_PHASE = 1),
            (this.AT_TARGET = 2),
            (this.BUBBLING_PHASE = 3),
            (this.manager = t);
        }
        get layerX() {
          return this.layer.x;
        }
        get layerY() {
          return this.layer.y;
        }
        get pageX() {
          return this.page.x;
        }
        get pageY() {
          return this.page.y;
        }
        get data() {
          return this;
        }
        composedPath() {
          return (
            this.manager &&
              (!this.path || this.path[this.path.length - 1] !== this.target) &&
              (this.path = this.target
                ? this.manager.propagationPath(this.target)
                : []),
            this.path
          );
        }
        initEvent(e, t, n) {
          throw Error(
            `initEvent() is a legacy DOM API. It is not implemented in the Federated Events API.`
          );
        }
        initUIEvent(e, t, n, r, i) {
          throw Error(
            `initUIEvent() is a legacy DOM API. It is not implemented in the Federated Events API.`
          );
        }
        preventDefault() {
          this.nativeEvent instanceof Event &&
            this.nativeEvent.cancelable &&
            this.nativeEvent.preventDefault(),
            (this.defaultPrevented = !0);
        }
        stopImmediatePropagation() {
          this.propagationImmediatelyStopped = !0;
        }
        stopPropagation() {
          this.propagationStopped = !0;
        }
      });
  }))();
}
var nn;
function rn() {
  return (rn = t(() => {
    R(),
      tn(),
      (nn = class extends en {
        constructor() {
          super(...arguments),
            (this.client = new T()),
            (this.movement = new T()),
            (this.offset = new T()),
            (this.global = new T()),
            (this.screen = new T());
        }
        get clientX() {
          return this.client.x;
        }
        get clientY() {
          return this.client.y;
        }
        get x() {
          return this.clientX;
        }
        get y() {
          return this.clientY;
        }
        get movementX() {
          return this.movement.x;
        }
        get movementY() {
          return this.movement.y;
        }
        get offsetX() {
          return this.offset.x;
        }
        get offsetY() {
          return this.offset.y;
        }
        get globalX() {
          return this.global.x;
        }
        get globalY() {
          return this.global.y;
        }
        get screenX() {
          return this.screen.x;
        }
        get screenY() {
          return this.screen.y;
        }
        getLocalPosition(e, t, n) {
          return e.worldTransform.applyInverse(n || this.global, t);
        }
        getModifierState(e) {
          return (
            `getModifierState` in this.nativeEvent &&
            this.nativeEvent.getModifierState(e)
          );
        }
        initMouseEvent(e, t, n, r, i, a, o, s, c, l, u, d, f, p, m) {
          throw Error(`Method not implemented.`);
        }
      });
  }))();
}
var an;
function on() {
  return (on = t(() => {
    rn(),
      (an = class extends nn {
        constructor() {
          super(...arguments),
            (this.width = 0),
            (this.height = 0),
            (this.isPrimary = !1);
        }
        getCoalescedEvents() {
          return this.type === `pointermove` ||
            this.type === `mousemove` ||
            this.type === `touchmove`
            ? [this]
            : [];
        }
        getPredictedEvents() {
          throw Error(`getPredictedEvents is not supported!`);
        }
      });
  }))();
}
var sn;
function cn() {
  return (cn = t(() => {
    rn(),
      (sn = class extends nn {
        constructor() {
          super(...arguments),
            (this.DOM_DELTA_PIXEL = 0),
            (this.DOM_DELTA_LINE = 1),
            (this.DOM_DELTA_PAGE = 2);
        }
      }),
      (sn.DOM_DELTA_PIXEL = 0),
      (sn.DOM_DELTA_LINE = 1),
      (sn.DOM_DELTA_PAGE = 2);
  }))();
}
var ln, un, dn, fn;
function pn() {
  return (pn = t(() => {
    R(),
      $t(),
      rn(),
      on(),
      cn(),
      (ln = 2048),
      (un = new T()),
      (dn = new T()),
      (fn = class {
        constructor(e) {
          (this.dispatch = new ve.default()),
            (this.moveOnAll = !1),
            (this.enableGlobalMoveEvents = !0),
            (this.mappingState = { trackingData: {} }),
            (this.eventPool = new Map()),
            (this._allInteractiveElements = []),
            (this._hitElements = []),
            (this._isPointerMoveEvent = !1),
            (this.rootTarget = e),
            (this.hitPruneFn = this.hitPruneFn.bind(this)),
            (this.hitTestFn = this.hitTestFn.bind(this)),
            (this.mapPointerDown = this.mapPointerDown.bind(this)),
            (this.mapPointerMove = this.mapPointerMove.bind(this)),
            (this.mapPointerOut = this.mapPointerOut.bind(this)),
            (this.mapPointerOver = this.mapPointerOver.bind(this)),
            (this.mapPointerUp = this.mapPointerUp.bind(this)),
            (this.mapPointerUpOutside = this.mapPointerUpOutside.bind(this)),
            (this.mapWheel = this.mapWheel.bind(this)),
            (this.mappingTable = {}),
            this.addEventMapping(`pointerdown`, this.mapPointerDown),
            this.addEventMapping(`pointermove`, this.mapPointerMove),
            this.addEventMapping(`pointerout`, this.mapPointerOut),
            this.addEventMapping(`pointerleave`, this.mapPointerOut),
            this.addEventMapping(`pointerover`, this.mapPointerOver),
            this.addEventMapping(`pointerup`, this.mapPointerUp),
            this.addEventMapping(`pointerupoutside`, this.mapPointerUpOutside),
            this.addEventMapping(`wheel`, this.mapWheel);
        }
        addEventMapping(e, t) {
          this.mappingTable[e] || (this.mappingTable[e] = []),
            this.mappingTable[e].push({ fn: t, priority: 0 }),
            this.mappingTable[e].sort((e, t) => e.priority - t.priority);
        }
        dispatchEvent(e, t) {
          (e.propagationStopped = !1),
            (e.propagationImmediatelyStopped = !1),
            this.propagate(e, t),
            this.dispatch.emit(t || e.type, e);
        }
        mapEvent(e) {
          if (!this.rootTarget) return;
          let t = this.mappingTable[e.type];
          if (t) for (let n = 0, r = t.length; n < r; n++) t[n].fn(e);
          else
            console.warn(
              `[EventBoundary]: Event mapping not defined for ${e.type}`
            );
        }
        hitTest(e, t) {
          Qt.pauseUpdate = !0;
          let n =
              this._isPointerMoveEvent && this.enableGlobalMoveEvents
                ? `hitTestMoveRecursive`
                : `hitTestRecursive`,
            r = this[n](
              this.rootTarget,
              this.rootTarget.eventMode,
              un.set(e, t),
              this.hitTestFn,
              this.hitPruneFn
            );
          return r && r[0];
        }
        propagate(e, t) {
          if (!e.target) return;
          let n = e.composedPath();
          e.eventPhase = e.CAPTURING_PHASE;
          for (let r = 0, i = n.length - 1; r < i; r++)
            if (
              ((e.currentTarget = n[r]),
              this.notifyTarget(e, t),
              e.propagationStopped || e.propagationImmediatelyStopped)
            )
              return;
          if (
            ((e.eventPhase = e.AT_TARGET),
            (e.currentTarget = e.target),
            this.notifyTarget(e, t),
            !(e.propagationStopped || e.propagationImmediatelyStopped))
          ) {
            e.eventPhase = e.BUBBLING_PHASE;
            for (let r = n.length - 2; r >= 0; r--)
              if (
                ((e.currentTarget = n[r]),
                this.notifyTarget(e, t),
                e.propagationStopped || e.propagationImmediatelyStopped)
              )
                return;
          }
        }
        all(e, t, n = this._allInteractiveElements) {
          if (n.length === 0) return;
          e.eventPhase = e.BUBBLING_PHASE;
          let r = Array.isArray(t) ? t : [t];
          for (let t = n.length - 1; t >= 0; t--)
            r.forEach((r) => {
              (e.currentTarget = n[t]), this.notifyTarget(e, r);
            });
        }
        propagationPath(e) {
          let t = [e];
          for (let n = 0; n < ln && e !== this.rootTarget; n++) {
            if (!e.parent)
              throw Error(
                `Cannot find propagation path to disconnected target`
              );
            t.push(e.parent), (e = e.parent);
          }
          return t.reverse(), t;
        }
        hitTestMoveRecursive(e, t, n, r, i, a = !1) {
          if (this._interactivePrune(e)) return null;
          if (
            ((e.eventMode === `dynamic` || t === `dynamic`) &&
              (Qt.pauseUpdate = !1),
            e.interactiveChildren && e.children)
          ) {
            let a = e.children;
            for (let o = a.length - 1; o >= 0; o--) {
              let s = a[o],
                c = this.hitTestMoveRecursive(
                  s,
                  this._isInteractive(t) ? t : s.eventMode,
                  n,
                  r,
                  i,
                  i(e, n)
                );
              if (c) {
                if (c.length > 0 && !c[c.length - 1].parent) continue;
                let t = e.isInteractive();
                (c.length > 0 || t) &&
                  (t && this._allInteractiveElements.push(e), c.push(e)),
                  this._hitElements.length === 0 && (this._hitElements = c);
              }
            }
          }
          let o = this._isInteractive(t),
            s = e.isInteractive();
          return (
            s && s && this._allInteractiveElements.push(e),
            a || this._hitElements.length > 0
              ? null
              : o && !i(e, n) && r(e, n)
              ? s
                ? [e]
                : []
              : null
          );
        }
        hitTestRecursive(e, t, n, r, i) {
          if (this._interactivePrune(e) || i(e, n)) return null;
          if (
            ((e.eventMode === `dynamic` || t === `dynamic`) &&
              (Qt.pauseUpdate = !1),
            e.interactiveChildren && e.children)
          ) {
            let a = e.children;
            for (let o = a.length - 1; o >= 0; o--) {
              let s = a[o],
                c = this.hitTestRecursive(
                  s,
                  this._isInteractive(t) ? t : s.eventMode,
                  n,
                  r,
                  i
                );
              if (c) {
                if (c.length > 0 && !c[c.length - 1].parent) continue;
                let t = e.isInteractive();
                return (c.length > 0 || t) && c.push(e), c;
              }
            }
          }
          let a = this._isInteractive(t),
            o = e.isInteractive();
          return a && r(e, n) ? (o ? [e] : []) : null;
        }
        _isInteractive(e) {
          return e === `static` || e === `dynamic`;
        }
        _interactivePrune(e) {
          return !!(
            !e ||
            e.isMask ||
            !e.visible ||
            !e.renderable ||
            e.eventMode === `none` ||
            (e.eventMode === `passive` && !e.interactiveChildren) ||
            e.isMask
          );
        }
        hitPruneFn(e, t) {
          if (
            e.hitArea &&
            (e.worldTransform.applyInverse(t, dn),
            !e.hitArea.contains(dn.x, dn.y))
          )
            return !0;
          if (e._mask) {
            let n = e._mask.isMaskData ? e._mask.maskObject : e._mask;
            if (n && !n.containsPoint?.(t)) return !0;
          }
          return !1;
        }
        hitTestFn(e, t) {
          return e.eventMode === `passive`
            ? !1
            : e.hitArea
            ? !0
            : e.containsPoint
            ? e.containsPoint(t)
            : !1;
        }
        notifyTarget(e, t) {
          t ??= e.type;
          let n = `on${t}`;
          e.currentTarget[n]?.(e);
          let r =
            e.eventPhase === e.CAPTURING_PHASE || e.eventPhase === e.AT_TARGET
              ? `${t}capture`
              : t;
          this.notifyListeners(e, r),
            e.eventPhase === e.AT_TARGET && this.notifyListeners(e, t);
        }
        mapPointerDown(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          let t = this.createPointerEvent(e);
          if ((this.dispatchEvent(t, `pointerdown`), t.pointerType === `touch`))
            this.dispatchEvent(t, `touchstart`);
          else if (t.pointerType === `mouse` || t.pointerType === `pen`) {
            let e = t.button === 2;
            this.dispatchEvent(t, e ? `rightdown` : `mousedown`);
          }
          let n = this.trackingData(e.pointerId);
          (n.pressTargetsByButton[e.button] = t.composedPath()),
            this.freeEvent(t);
        }
        mapPointerMove(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          (this._allInteractiveElements.length = 0),
            (this._hitElements.length = 0),
            (this._isPointerMoveEvent = !0);
          let t = this.createPointerEvent(e);
          this._isPointerMoveEvent = !1;
          let n = t.pointerType === `mouse` || t.pointerType === `pen`,
            r = this.trackingData(e.pointerId),
            i = this.findMountedTarget(r.overTargets);
          if (r.overTargets?.length > 0 && i !== t.target) {
            let r = e.type === `mousemove` ? `mouseout` : `pointerout`,
              a = this.createPointerEvent(e, r, i);
            if (
              (this.dispatchEvent(a, `pointerout`),
              n && this.dispatchEvent(a, `mouseout`),
              !t.composedPath().includes(i))
            ) {
              let r = this.createPointerEvent(e, `pointerleave`, i);
              for (
                r.eventPhase = r.AT_TARGET;
                r.target && !t.composedPath().includes(r.target);

              )
                (r.currentTarget = r.target),
                  this.notifyTarget(r),
                  n && this.notifyTarget(r, `mouseleave`),
                  (r.target = r.target.parent);
              this.freeEvent(r);
            }
            this.freeEvent(a);
          }
          if (i !== t.target) {
            let r = e.type === `mousemove` ? `mouseover` : `pointerover`,
              a = this.clonePointerEvent(t, r);
            this.dispatchEvent(a, `pointerover`),
              n && this.dispatchEvent(a, `mouseover`);
            let o = i?.parent;
            for (; o && o !== this.rootTarget.parent && o !== t.target; )
              o = o.parent;
            if (!o || o === this.rootTarget.parent) {
              let e = this.clonePointerEvent(t, `pointerenter`);
              for (
                e.eventPhase = e.AT_TARGET;
                e.target &&
                e.target !== i &&
                e.target !== this.rootTarget.parent;

              )
                (e.currentTarget = e.target),
                  this.notifyTarget(e),
                  n && this.notifyTarget(e, `mouseenter`),
                  (e.target = e.target.parent);
              this.freeEvent(e);
            }
            this.freeEvent(a);
          }
          let a = [],
            o = this.enableGlobalMoveEvents ?? !0;
          this.moveOnAll
            ? a.push(`pointermove`)
            : this.dispatchEvent(t, `pointermove`),
            o && a.push(`globalpointermove`),
            t.pointerType === `touch` &&
              (this.moveOnAll
                ? a.splice(1, 0, `touchmove`)
                : this.dispatchEvent(t, `touchmove`),
              o && a.push(`globaltouchmove`)),
            n &&
              (this.moveOnAll
                ? a.splice(1, 0, `mousemove`)
                : this.dispatchEvent(t, `mousemove`),
              o && a.push(`globalmousemove`),
              (this.cursor = t.target?.cursor)),
            a.length > 0 && this.all(t, a),
            (this._allInteractiveElements.length = 0),
            (this._hitElements.length = 0),
            (r.overTargets = t.composedPath()),
            this.freeEvent(t);
        }
        mapPointerOver(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          let t = this.trackingData(e.pointerId),
            n = this.createPointerEvent(e),
            r = n.pointerType === `mouse` || n.pointerType === `pen`;
          this.dispatchEvent(n, `pointerover`),
            r && this.dispatchEvent(n, `mouseover`),
            n.pointerType === `mouse` && (this.cursor = n.target?.cursor);
          let i = this.clonePointerEvent(n, `pointerenter`);
          for (
            i.eventPhase = i.AT_TARGET;
            i.target && i.target !== this.rootTarget.parent;

          )
            (i.currentTarget = i.target),
              this.notifyTarget(i),
              r && this.notifyTarget(i, `mouseenter`),
              (i.target = i.target.parent);
          (t.overTargets = n.composedPath()),
            this.freeEvent(n),
            this.freeEvent(i);
        }
        mapPointerOut(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          let t = this.trackingData(e.pointerId);
          if (t.overTargets) {
            let n = e.pointerType === `mouse` || e.pointerType === `pen`,
              r = this.findMountedTarget(t.overTargets),
              i = this.createPointerEvent(e, `pointerout`, r);
            this.dispatchEvent(i), n && this.dispatchEvent(i, `mouseout`);
            let a = this.createPointerEvent(e, `pointerleave`, r);
            for (
              a.eventPhase = a.AT_TARGET;
              a.target && a.target !== this.rootTarget.parent;

            )
              (a.currentTarget = a.target),
                this.notifyTarget(a),
                n && this.notifyTarget(a, `mouseleave`),
                (a.target = a.target.parent);
            (t.overTargets = null), this.freeEvent(i), this.freeEvent(a);
          }
          this.cursor = null;
        }
        mapPointerUp(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          let t = performance.now(),
            n = this.createPointerEvent(e);
          if ((this.dispatchEvent(n, `pointerup`), n.pointerType === `touch`))
            this.dispatchEvent(n, `touchend`);
          else if (n.pointerType === `mouse` || n.pointerType === `pen`) {
            let e = n.button === 2;
            this.dispatchEvent(n, e ? `rightup` : `mouseup`);
          }
          let r = this.trackingData(e.pointerId),
            i = this.findMountedTarget(r.pressTargetsByButton[e.button]),
            a = i;
          if (i && !n.composedPath().includes(i)) {
            let t = i;
            for (; t && !n.composedPath().includes(t); ) {
              if (
                ((n.currentTarget = t),
                this.notifyTarget(n, `pointerupoutside`),
                n.pointerType === `touch`)
              )
                this.notifyTarget(n, `touchendoutside`);
              else if (n.pointerType === `mouse` || n.pointerType === `pen`) {
                let e = n.button === 2;
                this.notifyTarget(n, e ? `rightupoutside` : `mouseupoutside`);
              }
              t = t.parent;
            }
            delete r.pressTargetsByButton[e.button], (a = t);
          }
          if (a) {
            let i = this.clonePointerEvent(n, `click`);
            (i.target = a),
              (i.path = null),
              r.clicksByButton[e.button] ||
                (r.clicksByButton[e.button] = {
                  clickCount: 0,
                  target: i.target,
                  timeStamp: t,
                });
            let o = r.clicksByButton[e.button];
            if (
              (o.target === i.target && t - o.timeStamp < 200
                ? ++o.clickCount
                : (o.clickCount = 1),
              (o.target = i.target),
              (o.timeStamp = t),
              (i.detail = o.clickCount),
              i.pointerType === `mouse`)
            ) {
              let e = i.button === 2;
              this.dispatchEvent(i, e ? `rightclick` : `click`);
            } else i.pointerType === `touch` && this.dispatchEvent(i, `tap`);
            this.dispatchEvent(i, `pointertap`), this.freeEvent(i);
          }
          this.freeEvent(n);
        }
        mapPointerUpOutside(e) {
          if (!(e instanceof an)) {
            console.warn(
              `EventBoundary cannot map a non-pointer event as a pointer event`
            );
            return;
          }
          let t = this.trackingData(e.pointerId),
            n = this.findMountedTarget(t.pressTargetsByButton[e.button]),
            r = this.createPointerEvent(e);
          if (n) {
            let i = n;
            for (; i; )
              (r.currentTarget = i),
                this.notifyTarget(r, `pointerupoutside`),
                r.pointerType === `touch`
                  ? this.notifyTarget(r, `touchendoutside`)
                  : (r.pointerType === `mouse` || r.pointerType === `pen`) &&
                    this.notifyTarget(
                      r,
                      r.button === 2 ? `rightupoutside` : `mouseupoutside`
                    ),
                (i = i.parent);
            delete t.pressTargetsByButton[e.button];
          }
          this.freeEvent(r);
        }
        mapWheel(e) {
          if (!(e instanceof sn)) {
            console.warn(
              `EventBoundary cannot map a non-wheel event as a wheel event`
            );
            return;
          }
          let t = this.createWheelEvent(e);
          this.dispatchEvent(t), this.freeEvent(t);
        }
        findMountedTarget(e) {
          if (!e) return null;
          let t = e[0];
          for (let n = 1; n < e.length && e[n].parent === t; n++) t = e[n];
          return t;
        }
        createPointerEvent(e, t, n) {
          let r = this.allocateEvent(an);
          return (
            this.copyPointerData(e, r),
            this.copyMouseData(e, r),
            this.copyData(e, r),
            (r.nativeEvent = e.nativeEvent),
            (r.originalEvent = e),
            (r.target =
              n ??
              this.hitTest(r.global.x, r.global.y) ??
              this._hitElements[0]),
            typeof t == `string` && (r.type = t),
            r
          );
        }
        createWheelEvent(e) {
          let t = this.allocateEvent(sn);
          return (
            this.copyWheelData(e, t),
            this.copyMouseData(e, t),
            this.copyData(e, t),
            (t.nativeEvent = e.nativeEvent),
            (t.originalEvent = e),
            (t.target = this.hitTest(t.global.x, t.global.y)),
            t
          );
        }
        clonePointerEvent(e, t) {
          let n = this.allocateEvent(an);
          return (
            (n.nativeEvent = e.nativeEvent),
            (n.originalEvent = e.originalEvent),
            this.copyPointerData(e, n),
            this.copyMouseData(e, n),
            this.copyData(e, n),
            (n.target = e.target),
            (n.path = e.composedPath().slice()),
            (n.type = t ?? n.type),
            n
          );
        }
        copyWheelData(e, t) {
          (t.deltaMode = e.deltaMode),
            (t.deltaX = e.deltaX),
            (t.deltaY = e.deltaY),
            (t.deltaZ = e.deltaZ);
        }
        copyPointerData(e, t) {
          e instanceof an &&
            t instanceof an &&
            ((t.pointerId = e.pointerId),
            (t.width = e.width),
            (t.height = e.height),
            (t.isPrimary = e.isPrimary),
            (t.pointerType = e.pointerType),
            (t.pressure = e.pressure),
            (t.tangentialPressure = e.tangentialPressure),
            (t.tiltX = e.tiltX),
            (t.tiltY = e.tiltY),
            (t.twist = e.twist));
        }
        copyMouseData(e, t) {
          e instanceof nn &&
            t instanceof nn &&
            ((t.altKey = e.altKey),
            (t.button = e.button),
            (t.buttons = e.buttons),
            t.client.copyFrom(e.client),
            (t.ctrlKey = e.ctrlKey),
            (t.metaKey = e.metaKey),
            t.movement.copyFrom(e.movement),
            t.screen.copyFrom(e.screen),
            (t.shiftKey = e.shiftKey),
            t.global.copyFrom(e.global));
        }
        copyData(e, t) {
          (t.isTrusted = e.isTrusted),
            (t.srcElement = e.srcElement),
            (t.timeStamp = performance.now()),
            (t.type = e.type),
            (t.detail = e.detail),
            (t.view = e.view),
            (t.which = e.which),
            t.layer.copyFrom(e.layer),
            t.page.copyFrom(e.page);
        }
        trackingData(e) {
          return (
            this.mappingState.trackingData[e] ||
              (this.mappingState.trackingData[e] = {
                pressTargetsByButton: {},
                clicksByButton: {},
                overTarget: null,
              }),
            this.mappingState.trackingData[e]
          );
        }
        allocateEvent(e) {
          this.eventPool.has(e) || this.eventPool.set(e, []);
          let t = this.eventPool.get(e).pop() || new e(this);
          return (
            (t.eventPhase = t.NONE),
            (t.currentTarget = null),
            (t.path = null),
            (t.target = null),
            t
          );
        }
        freeEvent(e) {
          if (e.manager !== this)
            throw Error(
              `It is illegal to free an event not managed by this EventBoundary!`
            );
          let t = e.constructor;
          this.eventPool.has(t) || this.eventPool.set(t, []),
            this.eventPool.get(t).push(e);
        }
        notifyListeners(e, t) {
          let n = e.currentTarget._events[t];
          if (n && e.currentTarget.isInteractive())
            if (`fn` in n)
              n.once && e.currentTarget.removeListener(t, n.fn, void 0, !0),
                n.fn.call(n.context, e);
            else
              for (
                let r = 0, i = n.length;
                r < i && !e.propagationImmediatelyStopped;
                r++
              )
                n[r].once &&
                  e.currentTarget.removeListener(t, n[r].fn, void 0, !0),
                  n[r].fn.call(n[r].context, e);
        }
      });
  }))();
}
var mn, hn, gn, _n;
function vn() {
  return (vn = t(() => {
    R(),
      pn(),
      $t(),
      on(),
      cn(),
      (mn = 1),
      (hn = {
        touchstart: `pointerdown`,
        touchend: `pointerup`,
        touchendoutside: `pointerupoutside`,
        touchmove: `pointermove`,
        touchcancel: `pointercancel`,
      }),
      (gn = class {
        constructor(e) {
          (this.supportsTouchEvents = `ontouchstart` in globalThis),
            (this.supportsPointerEvents = !!globalThis.PointerEvent),
            (this.domElement = null),
            (this.resolution = 1),
            (this.renderer = e),
            (this.rootBoundary = new fn(null)),
            Qt.init(this),
            (this.autoPreventDefault = !0),
            (this.eventsAdded = !1),
            (this.rootPointerEvent = new an(null)),
            (this.rootWheelEvent = new sn(null)),
            (this.cursorStyles = { default: `inherit`, pointer: `pointer` }),
            (this.features = new Proxy(
              { ...gn.defaultEventFeatures },
              {
                set: (e, t, n) => (
                  t === `globalMove` &&
                    (this.rootBoundary.enableGlobalMoveEvents = n),
                  (e[t] = n),
                  !0
                ),
              }
            )),
            (this.onPointerDown = this.onPointerDown.bind(this)),
            (this.onPointerMove = this.onPointerMove.bind(this)),
            (this.onPointerUp = this.onPointerUp.bind(this)),
            (this.onPointerOverOut = this.onPointerOverOut.bind(this)),
            (this.onWheel = this.onWheel.bind(this));
        }
        static get defaultEventMode() {
          return this._defaultEventMode;
        }
        init(e) {
          let { view: t, resolution: n } = this.renderer;
          this.setTargetElement(t),
            (this.resolution = n),
            (gn._defaultEventMode = e.eventMode ?? `auto`),
            Object.assign(this.features, e.eventFeatures ?? {}),
            (this.rootBoundary.enableGlobalMoveEvents =
              this.features.globalMove);
        }
        resolutionChange(e) {
          this.resolution = e;
        }
        destroy() {
          this.setTargetElement(null), (this.renderer = null);
        }
        setCursor(e) {
          e ||= `default`;
          let t = !0;
          if (
            (globalThis.OffscreenCanvas &&
              this.domElement instanceof OffscreenCanvas &&
              (t = !1),
            this.currentCursor === e)
          )
            return;
          this.currentCursor = e;
          let n = this.cursorStyles[e];
          if (n)
            switch (typeof n) {
              case `string`:
                t && (this.domElement.style.cursor = n);
                break;
              case `function`:
                n(e);
                break;
              case `object`:
                t && Object.assign(this.domElement.style, n);
            }
          else
            t &&
              typeof e == `string` &&
              !Object.prototype.hasOwnProperty.call(this.cursorStyles, e) &&
              (this.domElement.style.cursor = e);
        }
        get pointer() {
          return this.rootPointerEvent;
        }
        onPointerDown(e) {
          if (
            !this.features.click ||
            ((this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
            this.supportsTouchEvents && e.pointerType === `touch`)
          )
            return;
          let t = this.normalizeToPointerData(e);
          this.autoPreventDefault &&
            t[0].isNormalized &&
            (e.cancelable || !(`cancelable` in e)) &&
            e.preventDefault();
          for (let e = 0, n = t.length; e < n; e++) {
            let n = t[e],
              r = this.bootstrapEvent(this.rootPointerEvent, n);
            this.rootBoundary.mapEvent(r);
          }
          this.setCursor(this.rootBoundary.cursor);
        }
        onPointerMove(e) {
          if (
            !this.features.move ||
            ((this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
            this.supportsTouchEvents && e.pointerType === `touch`)
          )
            return;
          Qt.pointerMoved();
          let t = this.normalizeToPointerData(e);
          for (let e = 0, n = t.length; e < n; e++) {
            let n = this.bootstrapEvent(this.rootPointerEvent, t[e]);
            this.rootBoundary.mapEvent(n);
          }
          this.setCursor(this.rootBoundary.cursor);
        }
        onPointerUp(e) {
          if (
            !this.features.click ||
            ((this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
            this.supportsTouchEvents && e.pointerType === `touch`)
          )
            return;
          let t = e.target;
          e.composedPath &&
            e.composedPath().length > 0 &&
            (t = e.composedPath()[0]);
          let n = t === this.domElement ? `` : `outside`,
            r = this.normalizeToPointerData(e);
          for (let e = 0, t = r.length; e < t; e++) {
            let t = this.bootstrapEvent(this.rootPointerEvent, r[e]);
            (t.type += n), this.rootBoundary.mapEvent(t);
          }
          this.setCursor(this.rootBoundary.cursor);
        }
        onPointerOverOut(e) {
          if (
            !this.features.click ||
            ((this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
            this.supportsTouchEvents && e.pointerType === `touch`)
          )
            return;
          let t = this.normalizeToPointerData(e);
          for (let e = 0, n = t.length; e < n; e++) {
            let n = this.bootstrapEvent(this.rootPointerEvent, t[e]);
            this.rootBoundary.mapEvent(n);
          }
          this.setCursor(this.rootBoundary.cursor);
        }
        onWheel(e) {
          if (!this.features.wheel) return;
          let t = this.normalizeWheelEvent(e);
          (this.rootBoundary.rootTarget = this.renderer.lastObjectRendered),
            this.rootBoundary.mapEvent(t);
        }
        setTargetElement(e) {
          this.removeEvents(),
            (this.domElement = e),
            (Qt.domElement = e),
            this.addEvents();
        }
        addEvents() {
          if (this.eventsAdded || !this.domElement) return;
          Qt.addTickerListener();
          let e = this.domElement.style;
          e &&
            (globalThis.navigator.msPointerEnabled
              ? ((e.msContentZooming = `none`), (e.msTouchAction = `none`))
              : this.supportsPointerEvents && (e.touchAction = `none`)),
            this.supportsPointerEvents
              ? (globalThis.document.addEventListener(
                  `pointermove`,
                  this.onPointerMove,
                  !0
                ),
                this.domElement.addEventListener(
                  `pointerdown`,
                  this.onPointerDown,
                  !0
                ),
                this.domElement.addEventListener(
                  `pointerleave`,
                  this.onPointerOverOut,
                  !0
                ),
                this.domElement.addEventListener(
                  `pointerover`,
                  this.onPointerOverOut,
                  !0
                ),
                globalThis.addEventListener(`pointerup`, this.onPointerUp, !0))
              : (globalThis.document.addEventListener(
                  `mousemove`,
                  this.onPointerMove,
                  !0
                ),
                this.domElement.addEventListener(
                  `mousedown`,
                  this.onPointerDown,
                  !0
                ),
                this.domElement.addEventListener(
                  `mouseout`,
                  this.onPointerOverOut,
                  !0
                ),
                this.domElement.addEventListener(
                  `mouseover`,
                  this.onPointerOverOut,
                  !0
                ),
                globalThis.addEventListener(`mouseup`, this.onPointerUp, !0)),
            this.supportsTouchEvents &&
              (this.domElement.addEventListener(
                `touchstart`,
                this.onPointerDown,
                !0
              ),
              this.domElement.addEventListener(
                `touchend`,
                this.onPointerUp,
                !0
              ),
              this.domElement.addEventListener(
                `touchmove`,
                this.onPointerMove,
                !0
              )),
            this.domElement.addEventListener(`wheel`, this.onWheel, {
              passive: !0,
              capture: !0,
            }),
            (this.eventsAdded = !0);
        }
        removeEvents() {
          if (!this.eventsAdded || !this.domElement) return;
          Qt.removeTickerListener();
          let e = this.domElement.style;
          globalThis.navigator.msPointerEnabled
            ? ((e.msContentZooming = ``), (e.msTouchAction = ``))
            : this.supportsPointerEvents && (e.touchAction = ``),
            this.supportsPointerEvents
              ? (globalThis.document.removeEventListener(
                  `pointermove`,
                  this.onPointerMove,
                  !0
                ),
                this.domElement.removeEventListener(
                  `pointerdown`,
                  this.onPointerDown,
                  !0
                ),
                this.domElement.removeEventListener(
                  `pointerleave`,
                  this.onPointerOverOut,
                  !0
                ),
                this.domElement.removeEventListener(
                  `pointerover`,
                  this.onPointerOverOut,
                  !0
                ),
                globalThis.removeEventListener(
                  `pointerup`,
                  this.onPointerUp,
                  !0
                ))
              : (globalThis.document.removeEventListener(
                  `mousemove`,
                  this.onPointerMove,
                  !0
                ),
                this.domElement.removeEventListener(
                  `mousedown`,
                  this.onPointerDown,
                  !0
                ),
                this.domElement.removeEventListener(
                  `mouseout`,
                  this.onPointerOverOut,
                  !0
                ),
                this.domElement.removeEventListener(
                  `mouseover`,
                  this.onPointerOverOut,
                  !0
                ),
                globalThis.removeEventListener(
                  `mouseup`,
                  this.onPointerUp,
                  !0
                )),
            this.supportsTouchEvents &&
              (this.domElement.removeEventListener(
                `touchstart`,
                this.onPointerDown,
                !0
              ),
              this.domElement.removeEventListener(
                `touchend`,
                this.onPointerUp,
                !0
              ),
              this.domElement.removeEventListener(
                `touchmove`,
                this.onPointerMove,
                !0
              )),
            this.domElement.removeEventListener(`wheel`, this.onWheel, !0),
            (this.domElement = null),
            (this.eventsAdded = !1);
        }
        mapPositionToPoint(e, t, n) {
          let r;
          r = this.domElement.parentElement
            ? this.domElement.getBoundingClientRect()
            : {
                x: 0,
                y: 0,
                width: this.domElement.width,
                height: this.domElement.height,
                left: 0,
                top: 0,
              };
          let i = 1 / this.resolution;
          (e.x = (t - r.left) * (this.domElement.width / r.width) * i),
            (e.y = (n - r.top) * (this.domElement.height / r.height) * i);
        }
        normalizeToPointerData(e) {
          let t = [];
          if (this.supportsTouchEvents && e instanceof TouchEvent)
            for (let n = 0, r = e.changedTouches.length; n < r; n++) {
              let r = e.changedTouches[n];
              r.button === void 0 && (r.button = 0),
                r.buttons === void 0 && (r.buttons = 1),
                r.isPrimary === void 0 &&
                  (r.isPrimary =
                    e.touches.length === 1 && e.type === `touchstart`),
                r.width === void 0 && (r.width = r.radiusX || 1),
                r.height === void 0 && (r.height = r.radiusY || 1),
                r.tiltX === void 0 && (r.tiltX = 0),
                r.tiltY === void 0 && (r.tiltY = 0),
                r.pointerType === void 0 && (r.pointerType = `touch`),
                r.pointerId === void 0 && (r.pointerId = r.identifier || 0),
                r.pressure === void 0 && (r.pressure = r.force || 0.5),
                r.twist === void 0 && (r.twist = 0),
                r.tangentialPressure === void 0 && (r.tangentialPressure = 0),
                r.layerX === void 0 && (r.layerX = r.offsetX = r.clientX),
                r.layerY === void 0 && (r.layerY = r.offsetY = r.clientY),
                (r.isNormalized = !0),
                (r.type = e.type),
                t.push(r);
            }
          else if (
            !globalThis.MouseEvent ||
            (e instanceof MouseEvent &&
              (!this.supportsPointerEvents ||
                !(e instanceof globalThis.PointerEvent)))
          ) {
            let n = e;
            n.isPrimary === void 0 && (n.isPrimary = !0),
              n.width === void 0 && (n.width = 1),
              n.height === void 0 && (n.height = 1),
              n.tiltX === void 0 && (n.tiltX = 0),
              n.tiltY === void 0 && (n.tiltY = 0),
              n.pointerType === void 0 && (n.pointerType = `mouse`),
              n.pointerId === void 0 && (n.pointerId = mn),
              n.pressure === void 0 && (n.pressure = 0.5),
              n.twist === void 0 && (n.twist = 0),
              n.tangentialPressure === void 0 && (n.tangentialPressure = 0),
              (n.isNormalized = !0),
              t.push(n);
          } else t.push(e);
          return t;
        }
        normalizeWheelEvent(e) {
          let t = this.rootWheelEvent;
          return (
            this.transferMouseData(t, e),
            (t.deltaX = e.deltaX),
            (t.deltaY = e.deltaY),
            (t.deltaZ = e.deltaZ),
            (t.deltaMode = e.deltaMode),
            this.mapPositionToPoint(t.screen, e.clientX, e.clientY),
            t.global.copyFrom(t.screen),
            t.offset.copyFrom(t.screen),
            (t.nativeEvent = e),
            (t.type = e.type),
            t
          );
        }
        bootstrapEvent(e, t) {
          return (
            (e.originalEvent = null),
            (e.nativeEvent = t),
            (e.pointerId = t.pointerId),
            (e.width = t.width),
            (e.height = t.height),
            (e.isPrimary = t.isPrimary),
            (e.pointerType = t.pointerType),
            (e.pressure = t.pressure),
            (e.tangentialPressure = t.tangentialPressure),
            (e.tiltX = t.tiltX),
            (e.tiltY = t.tiltY),
            (e.twist = t.twist),
            this.transferMouseData(e, t),
            this.mapPositionToPoint(e.screen, t.clientX, t.clientY),
            e.global.copyFrom(e.screen),
            e.offset.copyFrom(e.screen),
            (e.isTrusted = t.isTrusted),
            e.type === `pointerleave` && (e.type = `pointerout`),
            e.type.startsWith(`mouse`) &&
              (e.type = e.type.replace(`mouse`, `pointer`)),
            e.type.startsWith(`touch`) && (e.type = hn[e.type] || e.type),
            e
          );
        }
        transferMouseData(e, t) {
          (e.isTrusted = t.isTrusted),
            (e.srcElement = t.srcElement),
            (e.timeStamp = performance.now()),
            (e.type = t.type),
            (e.altKey = t.altKey),
            (e.button = t.button),
            (e.buttons = t.buttons),
            (e.client.x = t.clientX),
            (e.client.y = t.clientY),
            (e.ctrlKey = t.ctrlKey),
            (e.metaKey = t.metaKey),
            (e.movement.x = t.movementX),
            (e.movement.y = t.movementY),
            (e.page.x = t.pageX),
            (e.page.y = t.pageY),
            (e.relatedTarget = null),
            (e.shiftKey = t.shiftKey);
        }
      }),
      (_n = gn),
      (_n.extension = {
        name: `events`,
        type: [z.RendererSystem, z.CanvasRendererSystem],
      }),
      (_n.defaultEventFeatures = {
        move: !0,
        globalMove: !0,
        click: !0,
        wheel: !0,
      }),
      I.add(_n);
  }))();
}
function yn(e) {
  return e === `dynamic` || e === `static`;
}
var bn;
function xn() {
  return (xn = t(() => {
    N(),
      Ve(),
      vn(),
      tn(),
      (bn = {
        onclick: null,
        onmousedown: null,
        onmouseenter: null,
        onmouseleave: null,
        onmousemove: null,
        onglobalmousemove: null,
        onmouseout: null,
        onmouseover: null,
        onmouseup: null,
        onmouseupoutside: null,
        onpointercancel: null,
        onpointerdown: null,
        onpointerenter: null,
        onpointerleave: null,
        onpointermove: null,
        onglobalpointermove: null,
        onpointerout: null,
        onpointerover: null,
        onpointertap: null,
        onpointerup: null,
        onpointerupoutside: null,
        onrightclick: null,
        onrightdown: null,
        onrightup: null,
        onrightupoutside: null,
        ontap: null,
        ontouchcancel: null,
        ontouchend: null,
        ontouchendoutside: null,
        ontouchmove: null,
        onglobaltouchmove: null,
        ontouchstart: null,
        onwheel: null,
        _internalInteractive: void 0,
        get interactive() {
          return this._internalInteractive ?? yn(_n.defaultEventMode);
        },
        set interactive(e) {
          qe(
            `7.2.0`,
            `Setting interactive is deprecated, use eventMode = 'none'/'passive'/'auto'/'static'/'dynamic' instead.`
          ),
            (this._internalInteractive = e),
            (this.eventMode = e ? `static` : `auto`);
        },
        _internalEventMode: void 0,
        get eventMode() {
          return this._internalEventMode ?? _n.defaultEventMode;
        },
        set eventMode(e) {
          (this._internalInteractive = yn(e)), (this._internalEventMode = e);
        },
        isInteractive() {
          return this.eventMode === `static` || this.eventMode === `dynamic`;
        },
        interactiveChildren: !0,
        hitArea: null,
        addEventListener(e, t, n) {
          let r =
              (typeof n == `boolean` && n) ||
              (typeof n == `object` && n.capture),
            i = typeof t == `function` ? void 0 : t;
          (e = r ? `${e}capture` : e),
            (t = typeof t == `function` ? t : t.handleEvent),
            this.on(e, t, i);
        },
        removeEventListener(e, t, n) {
          let r =
              (typeof n == `boolean` && n) ||
              (typeof n == `object` && n.capture),
            i = typeof t == `function` ? void 0 : t;
          (e = r ? `${e}capture` : e),
            (t = typeof t == `function` ? t : t.handleEvent),
            this.off(e, t, i);
        },
        dispatchEvent(e) {
          if (!(e instanceof en))
            throw Error(
              `DisplayObject cannot propagate events outside of the Federated Events API`
            );
          return (
            (e.defaultPrevented = !1),
            (e.path = null),
            (e.target = this),
            e.manager.dispatchEvent(e),
            !e.defaultPrevented
          );
        },
      }),
      M.mixin(bn);
  }))();
}
function Sn() {
  return (Sn = t(() => {
    pn(), vn(), tn(), xn(), rn(), on(), cn();
  }))();
}
var Cn;
function wn() {
  return (wn = t(() => {
    Cn = {
      accessible: !1,
      accessibleTitle: null,
      accessibleHint: null,
      tabIndex: 0,
      _accessibleActive: !1,
      _accessibleDiv: null,
      accessibleType: `button`,
      accessiblePointerEvents: `auto`,
      accessibleChildren: !0,
      renderId: -1,
    };
  }))();
}
var Tn, En, Dn, On, kn, An, jn, Mn, Nn, Pn;
function Fn() {
  return (Fn = t(() => {
    R(),
      N(),
      Sn(),
      wn(),
      M.mixin(Cn),
      (Tn = 9),
      (En = 100),
      (Dn = 0),
      (On = 0),
      (kn = 2),
      (An = 1),
      (jn = -1e3),
      (Mn = -1e3),
      (Nn = 2),
      (Pn = class {
        constructor(e) {
          (this.debug = !1),
            (this._isActive = !1),
            (this._isMobileAccessibility = !1),
            (this.pool = []),
            (this.renderId = 0),
            (this.children = []),
            (this.androidUpdateCount = 0),
            (this.androidUpdateFrequency = 500),
            (this._hookDiv = null),
            (We.tablet || We.phone) && this.createTouchHook();
          let t = document.createElement(`div`);
          (t.style.width = `${En}px`),
            (t.style.height = `${En}px`),
            (t.style.position = `absolute`),
            (t.style.top = `${Dn}px`),
            (t.style.left = `${On}px`),
            (t.style.zIndex = kn.toString()),
            (this.div = t),
            (this.renderer = e),
            (this._onKeyDown = this._onKeyDown.bind(this)),
            (this._onMouseMove = this._onMouseMove.bind(this)),
            globalThis.addEventListener(`keydown`, this._onKeyDown, !1);
        }
        get isActive() {
          return this._isActive;
        }
        get isMobileAccessibility() {
          return this._isMobileAccessibility;
        }
        createTouchHook() {
          let e = document.createElement(`button`);
          (e.style.width = `${An}px`),
            (e.style.height = `${An}px`),
            (e.style.position = `absolute`),
            (e.style.top = `${jn}px`),
            (e.style.left = `${Mn}px`),
            (e.style.zIndex = Nn.toString()),
            (e.style.backgroundColor = `#FF0000`),
            (e.title = `select to enable accessibility for this content`),
            e.addEventListener(`focus`, () => {
              (this._isMobileAccessibility = !0),
                this.activate(),
                this.destroyTouchHook();
            }),
            document.body.appendChild(e),
            (this._hookDiv = e);
        }
        destroyTouchHook() {
          this._hookDiv &&= (document.body.removeChild(this._hookDiv), null);
        }
        activate() {
          this._isActive ||
            ((this._isActive = !0),
            globalThis.document.addEventListener(
              `mousemove`,
              this._onMouseMove,
              !0
            ),
            globalThis.removeEventListener(`keydown`, this._onKeyDown, !1),
            this.renderer.on(`postrender`, this.update, this),
            this.renderer.view.parentNode?.appendChild(this.div));
        }
        deactivate() {
          !this._isActive ||
            this._isMobileAccessibility ||
            ((this._isActive = !1),
            globalThis.document.removeEventListener(
              `mousemove`,
              this._onMouseMove,
              !0
            ),
            globalThis.addEventListener(`keydown`, this._onKeyDown, !1),
            this.renderer.off(`postrender`, this.update),
            this.div.parentNode?.removeChild(this.div));
        }
        updateAccessibleObjects(e) {
          if (!e.visible || !e.accessibleChildren) return;
          e.accessible &&
            e.isInteractive() &&
            (e._accessibleActive || this.addChild(e),
            (e.renderId = this.renderId));
          let t = e.children;
          if (t)
            for (let e = 0; e < t.length; e++)
              this.updateAccessibleObjects(t[e]);
        }
        update() {
          let e = performance.now();
          if (
            (We.android.device && e < this.androidUpdateCount) ||
            ((this.androidUpdateCount = e + this.androidUpdateFrequency),
            !this.renderer.renderingToScreen)
          )
            return;
          this.renderer.lastObjectRendered &&
            this.updateAccessibleObjects(this.renderer.lastObjectRendered);
          let {
              x: t,
              y: n,
              width: r,
              height: i,
            } = this.renderer.view.getBoundingClientRect(),
            { width: a, height: o, resolution: s } = this.renderer,
            c = (r / a) * s,
            l = (i / o) * s,
            u = this.div;
          (u.style.left = `${t}px`),
            (u.style.top = `${n}px`),
            (u.style.width = `${a}px`),
            (u.style.height = `${o}px`);
          for (let e = 0; e < this.children.length; e++) {
            let t = this.children[e];
            if (t.renderId !== this.renderId)
              (t._accessibleActive = !1),
                xe(this.children, e, 1),
                this.div.removeChild(t._accessibleDiv),
                this.pool.push(t._accessibleDiv),
                (t._accessibleDiv = null),
                e--;
            else {
              u = t._accessibleDiv;
              let e = t.hitArea,
                n = t.worldTransform;
              t.hitArea
                ? ((u.style.left = `${(n.tx + e.x * n.a) * c}px`),
                  (u.style.top = `${(n.ty + e.y * n.d) * l}px`),
                  (u.style.width = `${e.width * n.a * c}px`),
                  (u.style.height = `${e.height * n.d * l}px`))
                : ((e = t.getBounds()),
                  this.capHitArea(e),
                  (u.style.left = `${e.x * c}px`),
                  (u.style.top = `${e.y * l}px`),
                  (u.style.width = `${e.width * c}px`),
                  (u.style.height = `${e.height * l}px`),
                  u.title !== t.accessibleTitle &&
                    t.accessibleTitle !== null &&
                    (u.title = t.accessibleTitle),
                  u.getAttribute(`aria-label`) !== t.accessibleHint &&
                    t.accessibleHint !== null &&
                    u.setAttribute(`aria-label`, t.accessibleHint)),
                (t.accessibleTitle !== u.title || t.tabIndex !== u.tabIndex) &&
                  ((u.title = t.accessibleTitle),
                  (u.tabIndex = t.tabIndex),
                  this.debug && this.updateDebugHTML(u));
            }
          }
          this.renderId++;
        }
        updateDebugHTML(e) {
          e.innerHTML = `type: ${e.type}</br> title : ${e.title}</br> tabIndex: ${e.tabIndex}`;
        }
        capHitArea(e) {
          e.x < 0 && ((e.width += e.x), (e.x = 0)),
            e.y < 0 && ((e.height += e.y), (e.y = 0));
          let { width: t, height: n } = this.renderer;
          e.x + e.width > t && (e.width = t - e.x),
            e.y + e.height > n && (e.height = n - e.y);
        }
        addChild(e) {
          let t = this.pool.pop();
          t ||
            ((t = document.createElement(`button`)),
            (t.style.width = `${En}px`),
            (t.style.height = `${En}px`),
            (t.style.backgroundColor = this.debug
              ? `rgba(255,255,255,0.5)`
              : `transparent`),
            (t.style.position = `absolute`),
            (t.style.zIndex = kn.toString()),
            (t.style.borderStyle = `none`),
            navigator.userAgent.toLowerCase().includes(`chrome`)
              ? t.setAttribute(`aria-live`, `off`)
              : t.setAttribute(`aria-live`, `polite`),
            navigator.userAgent.match(/rv:.*Gecko\//)
              ? t.setAttribute(`aria-relevant`, `additions`)
              : t.setAttribute(`aria-relevant`, `text`),
            t.addEventListener(`click`, this._onClick.bind(this)),
            t.addEventListener(`focus`, this._onFocus.bind(this)),
            t.addEventListener(`focusout`, this._onFocusOut.bind(this))),
            (t.style.pointerEvents = e.accessiblePointerEvents),
            (t.type = e.accessibleType),
            e.accessibleTitle && e.accessibleTitle !== null
              ? (t.title = e.accessibleTitle)
              : (!e.accessibleHint || e.accessibleHint === null) &&
                (t.title = `displayObject ${e.tabIndex}`),
            e.accessibleHint &&
              e.accessibleHint !== null &&
              t.setAttribute(`aria-label`, e.accessibleHint),
            this.debug && this.updateDebugHTML(t),
            (e._accessibleActive = !0),
            (e._accessibleDiv = t),
            (t.displayObject = e),
            this.children.push(e),
            this.div.appendChild(e._accessibleDiv),
            (e._accessibleDiv.tabIndex = e.tabIndex);
        }
        _dispatchEvent(e, t) {
          let { displayObject: n } = e.target,
            r = this.renderer.events.rootBoundary,
            i = Object.assign(new en(r), { target: n });
          (r.rootTarget = this.renderer.lastObjectRendered),
            t.forEach((e) => r.dispatchEvent(i, e));
        }
        _onClick(e) {
          this._dispatchEvent(e, [`click`, `pointertap`, `tap`]);
        }
        _onFocus(e) {
          e.target.getAttribute(`aria-live`) ||
            e.target.setAttribute(`aria-live`, `assertive`),
            this._dispatchEvent(e, [`mouseover`]);
        }
        _onFocusOut(e) {
          e.target.getAttribute(`aria-live`) ||
            e.target.setAttribute(`aria-live`, `polite`),
            this._dispatchEvent(e, [`mouseout`]);
        }
        _onKeyDown(e) {
          e.keyCode === Tn && this.activate();
        }
        _onMouseMove(e) {
          (e.movementX !== 0 || e.movementY !== 0) && this.deactivate();
        }
        destroy() {
          this.destroyTouchHook(),
            (this.div = null),
            globalThis.document.removeEventListener(
              `mousemove`,
              this._onMouseMove,
              !0
            ),
            globalThis.removeEventListener(`keydown`, this._onKeyDown),
            (this.pool = null),
            (this.children = null),
            (this.renderer = null);
        }
      }),
      (Pn.extension = {
        name: `accessibility`,
        type: [z.RendererPlugin, z.CanvasRendererPlugin],
      }),
      I.add(Pn);
  }))();
}
function In() {
  return (In = t(() => {
    Fn();
  }))();
}
var Ln, Rn;
function zn() {
  return (zn = t(() => {
    R(),
      N(),
      (Ln = class {
        constructor(e) {
          (this.stage = new de()),
            (e = Object.assign({ forceCanvas: !1 }, e)),
            (this.renderer = Ne(e)),
            Ln._plugins.forEach((t) => {
              t.init.call(this, e);
            });
        }
        render() {
          this.renderer.render(this.stage);
        }
        get view() {
          return this.renderer.view;
        }
        get screen() {
          return this.renderer.screen;
        }
        destroy(e, t) {
          let n = Ln._plugins.slice(0);
          n.reverse(),
            n.forEach((e) => {
              e.destroy.call(this);
            }),
            this.stage.destroy(t),
            (this.stage = null),
            this.renderer.destroy(e),
            (this.renderer = null);
        }
      }),
      (Rn = Ln),
      (Rn._plugins = []);
  }))();
}
var Bn;
function Vn() {
  return (Vn = t(() => {
    R(),
      (Bn = class {
        static init(e) {
          Object.defineProperty(this, "resizeTo", {
            set(e) {
              globalThis.removeEventListener(`resize`, this.queueResize),
                (this._resizeTo = e),
                e &&
                  (globalThis.addEventListener(`resize`, this.queueResize),
                  this.resize());
            },
            get() {
              return this._resizeTo;
            },
          }),
            (this.queueResize = () => {
              this._resizeTo &&
                (this.cancelResize(),
                (this._resizeId = requestAnimationFrame(() => this.resize())));
            }),
            (this.cancelResize = () => {
              this._resizeId &&= (cancelAnimationFrame(this._resizeId), null);
            }),
            (this.resize = () => {
              if (!this._resizeTo) return;
              this.cancelResize();
              let e, t;
              if (this._resizeTo === globalThis.window)
                (e = globalThis.innerWidth), (t = globalThis.innerHeight);
              else {
                let { clientWidth: n, clientHeight: r } = this._resizeTo;
                (e = n), (t = r);
              }
              this.renderer.resize(e, t), this.render();
            }),
            (this._resizeId = null),
            (this._resizeTo = null),
            (this.resizeTo = e.resizeTo || null);
        }
        static destroy() {
          globalThis.removeEventListener(`resize`, this.queueResize),
            this.cancelResize(),
            (this.cancelResize = null),
            (this.queueResize = null),
            (this.resizeTo = null),
            (this.resize = null);
        }
      }),
      (Bn.extension = z.Application),
      I.add(Bn);
  }))();
}
function Hn() {
  return (Hn = t(() => {
    zn(), Vn();
  }))();
}
var Un;
function Wn() {
  return (Wn = t(() => {
    R(),
      (Un = {
        loader: z.LoadParser,
        resolver: z.ResolveParser,
        cache: z.CacheParser,
        detection: z.DetectionParser,
      }),
      I.handle(
        z.Asset,
        (e) => {
          let t = e.ref;
          Object.entries(Un)
            .filter(([e]) => !!t[e])
            .forEach(([e, n]) =>
              I.add(Object.assign(t[e], { extension: t[e].extension ?? n }))
            );
        },
        (e) => {
          let t = e.ref;
          Object.keys(Un)
            .filter((e) => !!t[e])
            .forEach((e) => I.remove(t[e]));
        }
      );
  }))();
}
var Gn;
function Kn() {
  return (Kn = t(() => {
    Gn = class {
      constructor(e, t = !1) {
        (this._loader = e),
          (this._assetList = []),
          (this._isLoading = !1),
          (this._maxConcurrent = 1),
          (this.verbose = t);
      }
      add(e) {
        e.forEach((e) => {
          this._assetList.push(e);
        }),
          this.verbose &&
            console.log(`[BackgroundLoader] assets: `, this._assetList),
          this._isActive && !this._isLoading && this._next();
      }
      async _next() {
        if (this._assetList.length && this._isActive) {
          this._isLoading = !0;
          let e = [],
            t = Math.min(this._assetList.length, this._maxConcurrent);
          for (let n = 0; n < t; n++) e.push(this._assetList.pop());
          await this._loader.load(e), (this._isLoading = !1), this._next();
        }
      }
      get active() {
        return this._isActive;
      }
      set active(e) {
        this._isActive !== e &&
          ((this._isActive = e), e && !this._isLoading && this._next());
      }
    };
  }))();
}
function qn(e, t) {
  if (Array.isArray(t)) {
    for (let n of t) if (e.startsWith(`data:${n}`)) return !0;
    return !1;
  }
  return e.startsWith(`data:${t}`);
}
function Jn(e, t) {
  let n = e.split(`?`)[0],
    r = L.extname(n).toLowerCase();
  return Array.isArray(t) ? t.includes(r) : r === t;
}
function Yn() {
  return (Yn = t(() => {
    R();
  }))();
}
var Xn;
function Zn() {
  return (Zn = t(() => {
    Xn = (e, t) => (
      Array.isArray(e) || (e = [e]),
      t ? e.map((e) => (typeof e == `string` ? t(e) : e)) : e
    );
  }))();
}
var Qn;
function $n() {
  return ($n = t(() => {
    Qn = (e, t) => {
      let n = t.split(`?`)[1];
      return n && (e += `?${n}`), e;
    };
  }))();
}
function er(e, t, n, r, i) {
  let a = t[n];
  for (let o = 0; o < a.length; o++) {
    let s = a[o];
    n < t.length - 1
      ? er(e.replace(r[n], s), t, n + 1, r, i)
      : i.push(e.replace(r[n], s));
  }
}
function tr(e) {
  let t = e.match(/\{(.*?)\}/g),
    n = [];
  if (t) {
    let r = [];
    t.forEach((e) => {
      let t = e.substring(1, e.length - 1).split(`,`);
      r.push(t);
    }),
      er(e, r, 0, t, n);
  } else n.push(e);
  return n;
}
var nr;
function rr() {
  return (rr = t(() => {
    nr = (e) => !Array.isArray(e);
  }))();
}
function ir() {
  return (ir = t(() => {
    Yn();
  }))();
}
var ar, or;
function sr() {
  return (sr = t(() => {
    R(),
      ir(),
      Zn(),
      (ar = class {
        constructor() {
          (this._parsers = []),
            (this._cache = new Map()),
            (this._cacheMap = new Map());
        }
        reset() {
          this._cacheMap.clear(), this._cache.clear();
        }
        has(e) {
          return this._cache.has(e);
        }
        get(e) {
          let t = this._cache.get(e);
          return (
            t ||
              console.warn(`[Assets] Asset id ${e} was not found in the Cache`),
            t
          );
        }
        set(e, t) {
          let n = Xn(e),
            r;
          for (let e = 0; e < this.parsers.length; e++) {
            let i = this.parsers[e];
            if (i.test(t)) {
              r = i.getCacheableAssets(n, t);
              break;
            }
          }
          r ||
            ((r = {}),
            n.forEach((e) => {
              r[e] = t;
            }));
          let i = Object.keys(r),
            a = { cacheKeys: i, keys: n };
          if (
            (n.forEach((e) => {
              this._cacheMap.set(e, a);
            }),
            i.forEach((e) => {
              this._cache.has(e) &&
                this._cache.get(e) !== t &&
                console.warn(`[Cache] already has key:`, e),
                this._cache.set(e, r[e]);
            }),
            t instanceof B)
          ) {
            let e = t;
            n.forEach((t) => {
              e.baseTexture !== B.EMPTY.baseTexture &&
                ee.addToCache(e.baseTexture, t),
                B.addToCache(e, t);
            });
          }
        }
        remove(e) {
          if ((this._cacheMap.get(e), !this._cacheMap.has(e))) {
            console.warn(`[Assets] Asset id ${e} was not found in the Cache`);
            return;
          }
          let t = this._cacheMap.get(e);
          t.cacheKeys.forEach((e) => {
            this._cache.delete(e);
          }),
            t.keys.forEach((e) => {
              this._cacheMap.delete(e);
            });
        }
        get parsers() {
          return this._parsers;
        }
      }),
      (or = new ar());
  }))();
}
var cr;
function lr() {
  return (lr = t(() => {
    R(),
      ir(),
      rr(),
      Zn(),
      (cr = class {
        constructor() {
          (this._parsers = []),
            (this._parsersValidated = !1),
            (this.parsers = new Proxy(this._parsers, {
              set: (e, t, n) => ((this._parsersValidated = !1), (e[t] = n), !0),
            })),
            (this.promiseCache = {});
        }
        reset() {
          (this._parsersValidated = !1), (this.promiseCache = {});
        }
        _getLoadPromiseAndParser(e, t) {
          let n = { promise: null, parser: null };
          return (
            (n.promise = (async () => {
              let r = null,
                i = null;
              if (
                (t.loadParser &&
                  ((i = this._parserHash[t.loadParser]),
                  i ||
                    console.warn(
                      `[Assets] specified load parser "${t.loadParser}" not found while loading ${e}`
                    )),
                !i)
              ) {
                for (let n = 0; n < this.parsers.length; n++) {
                  let r = this.parsers[n];
                  if (r.load && r.test?.(e, t, this)) {
                    i = r;
                    break;
                  }
                }
                if (!i)
                  return (
                    console.warn(
                      `[Assets] ${e} could not be loaded as we don't know how to parse it, ensure the correct parser has been added`
                    ),
                    null
                  );
              }
              (r = await i.load(e, t, this)), (n.parser = i);
              for (let e = 0; e < this.parsers.length; e++) {
                let i = this.parsers[e];
                i.parse &&
                  i.parse &&
                  (await i.testParse?.(r, t, this)) &&
                  ((r = (await i.parse(r, t, this)) || r), (n.parser = i));
              }
              return r;
            })()),
            n
          );
        }
        async load(e, t) {
          this._parsersValidated || this._validateParsers();
          let n = 0,
            r = {},
            i = nr(e),
            a = Xn(e, (e) => ({ src: e })),
            o = a.length,
            s = a.map(async (e) => {
              let i = L.toAbsolute(e.src);
              if (!r[e.src])
                try {
                  this.promiseCache[i] ||
                    (this.promiseCache[i] = this._getLoadPromiseAndParser(
                      i,
                      e
                    )),
                    (r[e.src] = await this.promiseCache[i].promise),
                    t && t(++n / o);
                } catch (t) {
                  throw (
                    (delete this.promiseCache[i],
                    delete r[e.src],
                    Error(`[Loader.load] Failed to load ${i}.
${t}`))
                  );
                }
            });
          return await Promise.all(s), i ? r[a[0].src] : r;
        }
        async unload(e) {
          let t = Xn(e, (e) => ({ src: e })).map(async (e) => {
            let t = L.toAbsolute(e.src),
              n = this.promiseCache[t];
            if (n) {
              let r = await n.promise;
              n.parser?.unload?.(r, e, this), delete this.promiseCache[t];
            }
          });
          await Promise.all(t);
        }
        _validateParsers() {
          (this._parsersValidated = !0),
            (this._parserHash = this._parsers
              .filter((e) => e.name)
              .reduce(
                (e, t) => (
                  e[t.name] &&
                    console.warn(
                      `[Assets] loadParser name conflict "${t.name}"`
                    ),
                  { ...e, [t.name]: t }
                ),
                {}
              ));
        }
      });
  }))();
}
var ur;
function dr() {
  return (dr = t(() => {
    ur = ((e) => (
      (e[(e.Low = 0)] = `Low`),
      (e[(e.Normal = 1)] = `Normal`),
      (e[(e.High = 2)] = `High`),
      e
    ))(ur || {});
  }))();
}
var fr, pr, mr;
function hr() {
  return (hr = t(() => {
    R(),
      Yn(),
      dr(),
      (fr = `.json`),
      (pr = `application/json`),
      (mr = {
        extension: { type: z.LoadParser, priority: ur.Low },
        name: `loadJson`,
        test(e) {
          return qn(e, pr) || Jn(e, fr);
        },
        async load(e) {
          return await (await A.ADAPTER.fetch(e)).json();
        },
      }),
      I.add(mr);
  }))();
}
var gr, _r, vr;
function yr() {
  return (yr = t(() => {
    R(),
      Yn(),
      dr(),
      (gr = `.txt`),
      (_r = `text/plain`),
      (vr = {
        name: `loadTxt`,
        extension: { type: z.LoadParser, priority: ur.Low },
        test(e) {
          return qn(e, _r) || Jn(e, gr);
        },
        async load(e) {
          return await (await A.ADAPTER.fetch(e)).text();
        },
      }),
      I.add(vr);
  }))();
}
function br(e) {
  let t = L.extname(e);
  return L.basename(e, t)
    .replace(/(-|_)/g, ` `)
    .toLowerCase()
    .split(` `)
    .map((e) => e.charAt(0).toUpperCase() + e.slice(1))
    .join(` `);
}
var xr, Sr, Cr, wr;
function Tr() {
  return (Tr = t(() => {
    R(),
      Yn(),
      dr(),
      (xr = [
        `normal`,
        `bold`,
        `100`,
        `200`,
        `300`,
        `400`,
        `500`,
        `600`,
        `700`,
        `800`,
        `900`,
      ]),
      (Sr = [`.ttf`, `.otf`, `.woff`, `.woff2`]),
      (Cr = [`font/ttf`, `font/otf`, `font/woff`, `font/woff2`]),
      (wr = {
        extension: { type: z.LoadParser, priority: ur.Low },
        name: `loadWebFont`,
        test(e) {
          return qn(e, Cr) || Jn(e, Sr);
        },
        async load(e, t) {
          let n = A.ADAPTER.getFontFaceSet();
          if (n) {
            let r = [],
              i = t.data?.family ?? br(e),
              a = t.data?.weights?.filter((e) => xr.includes(e)) ?? [`normal`],
              o = t.data ?? {};
            for (let t = 0; t < a.length; t++) {
              let s = a[t],
                c = new FontFace(i, `url(${encodeURI(e)})`, {
                  ...o,
                  weight: s,
                });
              await c.load(), n.add(c), r.push(c);
            }
            return r.length === 1 ? r[0] : r;
          }
          return (
            console.warn(
              `[loadWebFont] FontFace API is not supported. Skipping loading font`
            ),
            null
          );
        },
        unload(e) {
          (Array.isArray(e) ? e : [e]).forEach((e) =>
            A.ADAPTER.getFontFaceSet().delete(e)
          );
        },
      }),
      I.add(wr);
  }))();
}
var Er, Dr, Or, kr, Ar, jr, Mr;
function Nr() {
  return (Nr = t(() => {
    (Er = 0),
      (Or = {
        id: `checkImageBitmap`,
        code: `
    async function checkImageBitmap()
    {
        try
        {
            if (typeof createImageBitmap !== 'function') return false;

            const response = await fetch('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+ip1sAAAAASUVORK5CYII=');
            const imageBlob =  await response.blob();
            const imageBitmap = await createImageBitmap(imageBlob);

            return imageBitmap.width === 1 && imageBitmap.height === 1;
        }
        catch (e)
        {
            return false;
        }
    }
    checkImageBitmap().then((result) => { self.postMessage(result); });
    `,
      }),
      (kr = {
        id: `loadImageBitmap`,
        code: `
    async function loadImageBitmap(url)
    {
        const response = await fetch(url);

        if (!response.ok)
        {
            throw new Error(\`[WorkerManager.loadImageBitmap] Failed to fetch \${url}: \`
                + \`\${response.status} \${response.statusText}\`);
        }

        const imageBlob =  await response.blob();
        const imageBitmap = await createImageBitmap(imageBlob);

        return imageBitmap;
    }
    self.onmessage = async (event) =>
    {
        try
        {
            const imageBitmap = await loadImageBitmap(event.data.data[0]);

            self.postMessage({
                data: imageBitmap,
                uuid: event.data.uuid,
                id: event.data.id,
            }, [imageBitmap]);
        }
        catch(e)
        {
            self.postMessage({
                error: e,
                uuid: event.data.uuid,
                id: event.data.id,
            });
        }
    };`,
      }),
      (jr = class {
        constructor() {
          (this._initialized = !1),
            (this._createdWorkers = 0),
            (this.workerPool = []),
            (this.queue = []),
            (this.resolveHash = {});
        }
        isImageBitmapSupported() {
          return (
            this._isImageBitmapSupported === void 0 &&
              (this._isImageBitmapSupported = new Promise((e) => {
                let t = URL.createObjectURL(
                    new Blob([Or.code], { type: `application/javascript` })
                  ),
                  n = new Worker(t);
                n.addEventListener(`message`, (r) => {
                  n.terminate(), URL.revokeObjectURL(t), e(r.data);
                });
              })),
            this._isImageBitmapSupported
          );
        }
        loadImageBitmap(e) {
          return this._run(`loadImageBitmap`, [e]);
        }
        async _initWorkers() {
          this._initialized ||= !0;
        }
        getWorker() {
          Dr === void 0 && (Dr = navigator.hardwareConcurrency || 4);
          let e = this.workerPool.pop();
          return (
            !e &&
              this._createdWorkers < Dr &&
              ((Ar ||= URL.createObjectURL(
                new Blob([kr.code], { type: `application/javascript` })
              )),
              this._createdWorkers++,
              (e = new Worker(Ar)),
              e.addEventListener(`message`, (e) => {
                this.complete(e.data), this.returnWorker(e.target), this.next();
              })),
            e
          );
        }
        returnWorker(e) {
          this.workerPool.push(e);
        }
        complete(e) {
          e.error === void 0
            ? this.resolveHash[e.uuid].resolve(e.data)
            : this.resolveHash[e.uuid].reject(e.error),
            (this.resolveHash[e.uuid] = null);
        }
        async _run(e, t) {
          await this._initWorkers();
          let n = new Promise((n, r) => {
            this.queue.push({ id: e, arguments: t, resolve: n, reject: r });
          });
          return this.next(), n;
        }
        next() {
          if (!this.queue.length) return;
          let e = this.getWorker();
          if (!e) return;
          let t = this.queue.pop(),
            n = t.id;
          (this.resolveHash[Er] = { resolve: t.resolve, reject: t.reject }),
            e.postMessage({ data: t.arguments, uuid: Er++, id: n });
        }
      }),
      (Mr = new jr());
  }))();
}
function Pr(e, t, n) {
  let r = new B(e);
  return (
    r.baseTexture.on(`dispose`, () => {
      delete t.promiseCache[n];
    }),
    r
  );
}
function Fr() {
  return (Fr = t(() => {
    R();
  }))();
}
async function Ir(e) {
  let t = await A.ADAPTER.fetch(e);
  if (!t.ok)
    throw Error(
      `[loadImageBitmap] Failed to fetch ${e}: ${t.status} ${t.statusText}`
    );
  let n = await t.blob();
  return await createImageBitmap(n);
}
var Lr, Rr, zr;
function Br() {
  return (Br = t(() => {
    R(),
      Yn(),
      dr(),
      Nr(),
      Fr(),
      (Lr = [`.jpeg`, `.jpg`, `.png`, `.webp`, `.avif`]),
      (Rr = [`image/jpeg`, `image/png`, `image/webp`, `image/avif`]),
      (zr = {
        name: `loadTextures`,
        extension: { type: z.LoadParser, priority: ur.High },
        config: {
          preferWorkers: !0,
          preferCreateImageBitmap: !0,
          crossOrigin: `anonymous`,
        },
        test(e) {
          return qn(e, Rr) || Jn(e, Lr);
        },
        async load(e, t, n) {
          let r = null;
          r =
            globalThis.createImageBitmap && this.config.preferCreateImageBitmap
              ? this.config.preferWorkers && (await Mr.isImageBitmapSupported())
                ? await Mr.loadImageBitmap(e)
                : await Ir(e)
              : await new Promise((t) => {
                  (r = new Image()),
                    (r.crossOrigin = this.config.crossOrigin),
                    (r.src = e),
                    r.complete
                      ? t(r)
                      : (r.onload = () => {
                          t(r);
                        });
                });
          let i = new ee(r, { resolution: Le(e), ...t.data });
          return (i.resource.src = e), Pr(i, n, e);
        },
        unload(e) {
          e.destroy(!0);
        },
      }),
      I.add(zr);
  }))();
}
var Vr, Hr, Ur;
function Wr() {
  return (Wr = t(() => {
    R(),
      Yn(),
      dr(),
      Br(),
      Fr(),
      (Vr = `.svg`),
      (Hr = `image/svg+xml`),
      (Ur = {
        extension: { type: z.LoadParser, priority: ur.High },
        name: `loadSVG`,
        test(e) {
          return qn(e, Hr) || Jn(e, Vr);
        },
        async testParse(e) {
          return fe.test(e);
        },
        async parse(e, t, n) {
          let r = new fe(e, t?.data?.resourceOptions),
            i = new ee(r, { resolution: Le(e), ...t?.data });
          i.resource.src = e;
          let a = Pr(i, n, e);
          return t?.data?.resourceOptions?.autoLoad || (await r.load()), a;
        },
        async load(e, t) {
          return (await A.ADAPTER.fetch(e)).text();
        },
        unload: zr.unload,
      }),
      I.add(Ur);
  }))();
}
function Gr() {
  return (Gr = t(() => {
    Fr();
  }))();
}
function Kr() {
  return (Kr = t(() => {
    Wr(), Br(), Gr();
  }))();
}
function qr() {
  return (qr = t(() => {
    hr(), yr(), Tr(), Kr();
  }))();
}
var Jr;
function Yr() {
  return (Yr = t(() => {
    R(),
      Zn(),
      rr(),
      (Jr = class {
        constructor() {
          (this._defaultBundleIdentifierOptions = {
            connector: `-`,
            createBundleAssetId: (e, t) => `${e}${this._bundleIdConnector}${t}`,
            extractAssetIdFromBundle: (e, t) =>
              t.replace(`${e}${this._bundleIdConnector}`, ``),
          }),
            (this._bundleIdConnector =
              this._defaultBundleIdentifierOptions.connector),
            (this._createBundleAssetId =
              this._defaultBundleIdentifierOptions.createBundleAssetId),
            (this._extractAssetIdFromBundle =
              this._defaultBundleIdentifierOptions.extractAssetIdFromBundle),
            (this._assetMap = {}),
            (this._preferredOrder = []),
            (this._parsers = []),
            (this._resolverHash = {}),
            (this._bundles = {});
        }
        setBundleIdentifier(e) {
          if (
            ((this._bundleIdConnector = e.connector ?? this._bundleIdConnector),
            (this._createBundleAssetId =
              e.createBundleAssetId ?? this._createBundleAssetId),
            (this._extractAssetIdFromBundle =
              e.extractAssetIdFromBundle ?? this._extractAssetIdFromBundle),
            this._extractAssetIdFromBundle(
              `foo`,
              this._createBundleAssetId(`foo`, `bar`)
            ) !== `bar`)
          )
            throw Error(
              `[Resolver] GenerateBundleAssetId are not working correctly`
            );
        }
        prefer(...e) {
          e.forEach((e) => {
            this._preferredOrder.push(e),
              (e.priority ||= Object.keys(e.params));
          }),
            (this._resolverHash = {});
        }
        set basePath(e) {
          this._basePath = e;
        }
        get basePath() {
          return this._basePath;
        }
        set rootPath(e) {
          this._rootPath = e;
        }
        get rootPath() {
          return this._rootPath;
        }
        get parsers() {
          return this._parsers;
        }
        reset() {
          this.setBundleIdentifier(this._defaultBundleIdentifierOptions),
            (this._assetMap = {}),
            (this._preferredOrder = []),
            (this._resolverHash = {}),
            (this._rootPath = null),
            (this._basePath = null),
            (this._manifest = null),
            (this._bundles = {}),
            (this._defaultSearchParams = null);
        }
        setDefaultSearchParams(e) {
          if (typeof e == `string`) this._defaultSearchParams = e;
          else {
            let t = e;
            this._defaultSearchParams = Object.keys(t)
              .map(
                (e) => `${encodeURIComponent(e)}=${encodeURIComponent(t[e])}`
              )
              .join(`&`);
          }
        }
        addManifest(e) {
          this._manifest &&
            console.warn(
              `[Resolver] Manifest already exists, this will be overwritten`
            ),
            (this._manifest = e),
            e.bundles.forEach((e) => {
              this.addBundle(e.name, e.assets);
            });
        }
        addBundle(e, t) {
          let n = [];
          Array.isArray(t)
            ? t.forEach((t) => {
                if (typeof t.name == `string`) {
                  let r = this._createBundleAssetId(e, t.name);
                  n.push(r), this.add([t.name, r], t.srcs, t.data);
                } else {
                  let r = t.name.map((t) => this._createBundleAssetId(e, t));
                  r.forEach((e) => {
                    n.push(e);
                  }),
                    this.add([...t.name, ...r], t.srcs);
                }
              })
            : Object.keys(t).forEach((r) => {
                n.push(this._createBundleAssetId(e, r)),
                  this.add([r, this._createBundleAssetId(e, r)], t[r]);
              }),
            (this._bundles[e] = n);
        }
        add(e, t, n) {
          let r = Xn(e);
          r.forEach((e) => {
            this.hasKey(e) &&
              console.warn(`[Resolver] already has key: ${e} overwriting`);
          }),
            Array.isArray(t) || (t = typeof t == `string` ? tr(t) : [t]);
          let i = t.map((e) => {
            let t = e;
            if (typeof e == `string`) {
              let n = !1;
              for (let r = 0; r < this._parsers.length; r++) {
                let i = this._parsers[r];
                if (i.test(e)) {
                  (t = i.parse(e)), (n = !0);
                  break;
                }
              }
              n || (t = { src: e });
            }
            return (
              t.format || (t.format = t.src.split(`.`).pop()),
              t.alias || (t.alias = r),
              (this._basePath || this._rootPath) &&
                (t.src = L.toAbsolute(t.src, this._basePath, this._rootPath)),
              (t.src = this._appendDefaultSearchParams(t.src)),
              (t.data = t.data ?? n),
              t
            );
          });
          r.forEach((e) => {
            this._assetMap[e] = i;
          });
        }
        resolveBundle(e) {
          let t = nr(e);
          e = Xn(e);
          let n = {};
          return (
            e.forEach((e) => {
              let t = this._bundles[e];
              if (t) {
                let r = this.resolve(t),
                  i = {};
                for (let t in r) {
                  let n = r[t];
                  i[this._extractAssetIdFromBundle(e, t)] = n;
                }
                n[e] = i;
              }
            }),
            t ? n[e[0]] : n
          );
        }
        resolveUrl(e) {
          let t = this.resolve(e);
          if (typeof e != `string`) {
            let e = {};
            for (let n in t) e[n] = t[n].src;
            return e;
          }
          return t.src;
        }
        resolve(e) {
          let t = nr(e);
          e = Xn(e);
          let n = {};
          return (
            e.forEach((e) => {
              if (!this._resolverHash[e])
                if (this._assetMap[e]) {
                  let t = this._assetMap[e],
                    n = this._getPreferredOrder(t),
                    r = t[0];
                  n?.priority.forEach((e) => {
                    n.params[e].forEach((n) => {
                      let r = t.filter((t) => (t[e] ? t[e] === n : !1));
                      r.length && (t = r);
                    });
                  }),
                    (this._resolverHash[e] = t[0] ?? r);
                } else {
                  let t = e;
                  (this._basePath || this._rootPath) &&
                    (t = L.toAbsolute(t, this._basePath, this._rootPath)),
                    (t = this._appendDefaultSearchParams(t)),
                    (this._resolverHash[e] = { src: t });
                }
              n[e] = this._resolverHash[e];
            }),
            t ? n[e[0]] : n
          );
        }
        hasKey(e) {
          return !!this._assetMap[e];
        }
        hasBundle(e) {
          return !!this._bundles[e];
        }
        _getPreferredOrder(e) {
          for (let t = 0; t < e.length; t++) {
            let t = e[0],
              n = this._preferredOrder.find((e) =>
                e.params.format.includes(t.format)
              );
            if (n) return n;
          }
          return this._preferredOrder[0];
        }
        _appendDefaultSearchParams(e) {
          return this._defaultSearchParams
            ? `${e}${/\?/.test(e) ? `&` : `?`}${this._defaultSearchParams}`
            : e;
        }
      });
  }))();
}
var Xr, Zr;
function Qr() {
  return (Qr = t(() => {
    R(),
      Ve(),
      Kn(),
      sr(),
      lr(),
      qr(),
      Yr(),
      Zn(),
      rr(),
      Br(),
      (Xr = class {
        constructor() {
          (this._detections = []),
            (this._initialized = !1),
            (this.resolver = new Jr()),
            (this.loader = new cr()),
            (this.cache = or),
            (this._backgroundLoader = new Gn(this.loader)),
            (this._backgroundLoader.active = !0),
            this.reset();
        }
        async init(e = {}) {
          if (this._initialized) {
            console.warn(
              `[Assets]AssetManager already initialized, did you load before calling this Asset.init()?`
            );
            return;
          }
          if (
            ((this._initialized = !0),
            e.defaultSearchParams &&
              this.resolver.setDefaultSearchParams(e.defaultSearchParams),
            e.basePath && (this.resolver.basePath = e.basePath),
            e.bundleIdentifier &&
              this.resolver.setBundleIdentifier(e.bundleIdentifier),
            e.manifest)
          ) {
            let t = e.manifest;
            typeof t == `string` && (t = await this.load(t)),
              this.resolver.addManifest(t);
          }
          let t = e.texturePreference?.resolution ?? 1,
            n = typeof t == `number` ? [t] : t,
            r = [];
          if (e.texturePreference?.format) {
            let t = e.texturePreference?.format;
            r = typeof t == `string` ? [t] : t;
            for (let e of this._detections)
              (await e.test()) || (r = await e.remove(r));
          } else
            for (let e of this._detections)
              (await e.test()) && (r = await e.add(r));
          this.resolver.prefer({ params: { format: r, resolution: n } }),
            e.preferences && this.setPreferences(e.preferences);
        }
        add(e, t, n) {
          this.resolver.add(e, t, n);
        }
        async load(e, t) {
          this._initialized || (await this.init());
          let n = nr(e),
            r = Xn(e).map((e) =>
              typeof e == `string`
                ? (this.resolver.hasKey(e) || this.resolver.add(e, e), e)
                : (this.resolver.add(e.src, e), e.src)
            ),
            i = this.resolver.resolve(r),
            a = await this._mapLoadToResolve(i, t);
          return n ? a[r[0]] : a;
        }
        addBundle(e, t) {
          this.resolver.addBundle(e, t);
        }
        async loadBundle(e, t) {
          this._initialized || (await this.init());
          let n = !1;
          typeof e == `string` && ((n = !0), (e = [e]));
          let r = this.resolver.resolveBundle(e),
            i = {},
            a = Object.keys(r),
            o = 0,
            s = 0,
            c = () => {
              t?.(++o / s);
            },
            l = a.map((e) => {
              let t = r[e];
              return (
                (s += Object.keys(t).length),
                this._mapLoadToResolve(t, c).then((t) => {
                  i[e] = t;
                })
              );
            });
          return await Promise.all(l), n ? i[e[0]] : i;
        }
        async backgroundLoad(e) {
          this._initialized || (await this.init()),
            typeof e == `string` && (e = [e]);
          let t = this.resolver.resolve(e);
          this._backgroundLoader.add(Object.values(t));
        }
        async backgroundLoadBundle(e) {
          this._initialized || (await this.init()),
            typeof e == `string` && (e = [e]);
          let t = this.resolver.resolveBundle(e);
          Object.values(t).forEach((e) => {
            this._backgroundLoader.add(Object.values(e));
          });
        }
        reset() {
          this.resolver.reset(),
            this.loader.reset(),
            this.cache.reset(),
            (this._initialized = !1);
        }
        get(e) {
          if (typeof e == `string`) return or.get(e);
          let t = {};
          for (let n = 0; n < e.length; n++) t[n] = or.get(e[n]);
          return t;
        }
        async _mapLoadToResolve(e, t) {
          let n = Object.values(e),
            r = Object.keys(e);
          this._backgroundLoader.active = !1;
          let i = await this.loader.load(n, t);
          this._backgroundLoader.active = !0;
          let a = {};
          return (
            n.forEach((e, t) => {
              let n = i[e.src],
                o = [e.src];
              e.alias && o.push(...e.alias), (a[r[t]] = n), or.set(o, n);
            }),
            a
          );
        }
        async unload(e) {
          this._initialized || (await this.init());
          let t = Xn(e).map((e) => (typeof e == `string` ? e : e.src)),
            n = this.resolver.resolve(t);
          await this._unloadFromResolved(n);
        }
        async unloadBundle(e) {
          this._initialized || (await this.init()), (e = Xn(e));
          let t = this.resolver.resolveBundle(e),
            n = Object.keys(t).map((e) => this._unloadFromResolved(t[e]));
          await Promise.all(n);
        }
        async _unloadFromResolved(e) {
          let t = Object.values(e);
          t.forEach((e) => {
            or.remove(e.src);
          }),
            await this.loader.unload(t);
        }
        get detections() {
          return this._detections;
        }
        get preferWorkers() {
          return zr.config.preferWorkers;
        }
        set preferWorkers(e) {
          qe(
            `7.2.0`,
            `Assets.prefersWorkers is deprecated, use Assets.setPreferences({ preferWorkers: true }) instead.`
          ),
            this.setPreferences({ preferWorkers: e });
        }
        setPreferences(e) {
          this.loader.parsers.forEach((t) => {
            t.config &&
              Object.keys(t.config)
                .filter((t) => t in e)
                .forEach((n) => {
                  t.config[n] = e[n];
                });
          });
        }
      }),
      (Zr = new Xr()),
      I.handleByList(z.LoadParser, Zr.loader.parsers)
        .handleByList(z.ResolveParser, Zr.resolver.parsers)
        .handleByList(z.CacheParser, Zr.cache.parsers)
        .handleByList(z.DetectionParser, Zr.detections);
  }))();
}
var $r;
function ei() {
  return (ei = t(() => {
    R(),
      ($r = {
        extension: z.CacheParser,
        test: (e) => Array.isArray(e) && e.every((e) => e instanceof B),
        getCacheableAssets: (e, t) => {
          let n = {};
          return (
            e.forEach((e) => {
              t.forEach((t, r) => {
                n[e + (r === 0 ? `` : r + 1)] = t;
              });
            }),
            n
          );
        },
      }),
      I.add($r);
  }))();
}
function ti() {
  return (ti = t(() => {
    ei();
  }))();
}
function ni() {
  return (ni = t(() => {
    sr(), ti();
  }))();
}
var ri;
function ii() {
  return (ii = t(() => {
    R(),
      (ri = {
        extension: { type: z.DetectionParser, priority: 1 },
        test: async () => {
          if (!globalThis.createImageBitmap) return !1;
          let e = await A.ADAPTER.fetch(
            `data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAAB0AAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAIAAAACAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQ0MAAAAABNjb2xybmNseAACAAIAAYAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAACVtZGF0EgAKCBgANogQEAwgMg8f8D///8WfhwB8+ErK42A=`
          ).then((e) => e.blob());
          return createImageBitmap(e).then(
            () => !0,
            () => !1
          );
        },
        add: async (e) => [...e, `avif`],
        remove: async (e) => e.filter((e) => e !== `avif`),
      }),
      I.add(ri);
  }))();
}
var ai;
function oi() {
  return (oi = t(() => {
    R(),
      (ai = {
        extension: { type: z.DetectionParser, priority: 0 },
        test: async () => {
          if (!globalThis.createImageBitmap) return !1;
          let e = await A.ADAPTER.fetch(
            `data:image/webp;base64,UklGRh4AAABXRUJQVlA4TBEAAAAvAAAAAAfQ//73v/+BiOh/AAA=`
          ).then((e) => e.blob());
          return createImageBitmap(e).then(
            () => !0,
            () => !1
          );
        },
        add: async (e) => [...e, `webp`],
        remove: async (e) => e.filter((e) => e !== `webp`),
      }),
      I.add(ai);
  }))();
}
var si, ci;
function li() {
  return (li = t(() => {
    R(),
      (si = [`png`, `jpg`, `jpeg`]),
      (ci = {
        extension: { type: z.DetectionParser, priority: -1 },
        test: () => Promise.resolve(!0),
        add: async (e) => [...e, ...si],
        remove: async (e) => e.filter((e) => !si.includes(e)),
      }),
      I.add(ci);
  }))();
}
function ui() {
  return (ui = t(() => {
    ii(), oi(), li();
  }))();
}
function di() {
  return (di = t(() => {
    ui();
  }))();
}
function fi() {
  return (fi = t(() => {
    qr();
  }))();
}
var pi;
function mi() {
  return (mi = t(() => {
    R(),
      fi(),
      Br(),
      (pi = {
        extension: z.ResolveParser,
        test: zr.test,
        parse: (e) => ({
          resolution: parseFloat(A.RETINA_PREFIX.exec(e)?.[1] ?? `1`),
          format: e.split(`.`).pop(),
          src: e,
        }),
      }),
      I.add(pi);
  }))();
}
function hi() {
  return (hi = t(() => {
    mi();
  }))();
}
function gi() {
  return (gi = t(() => {
    hi();
  }))();
}
function _i() {
  return (_i = t(() => {
    Wn(),
      Qr(),
      ni(),
      di(),
      fi(),
      gi(),
      ir(),
      sr(),
      ei(),
      ii(),
      oi(),
      li(),
      dr(),
      hr(),
      yr(),
      Tr(),
      Wr(),
      Br(),
      Fr(),
      mi(),
      Yn(),
      $n();
  }))();
}
var vi, yi;
function bi() {
  return (bi = t(() => {
    (vi = ((e) => (
      (e[
        (e.COMPRESSED_RGB_S3TC_DXT1_EXT = 33776)
      ] = `COMPRESSED_RGB_S3TC_DXT1_EXT`),
      (e[
        (e.COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777)
      ] = `COMPRESSED_RGBA_S3TC_DXT1_EXT`),
      (e[
        (e.COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778)
      ] = `COMPRESSED_RGBA_S3TC_DXT3_EXT`),
      (e[
        (e.COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779)
      ] = `COMPRESSED_RGBA_S3TC_DXT5_EXT`),
      (e[
        (e.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = 35917)
      ] = `COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT`),
      (e[
        (e.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = 35918)
      ] = `COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT`),
      (e[
        (e.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = 35919)
      ] = `COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT`),
      (e[
        (e.COMPRESSED_SRGB_S3TC_DXT1_EXT = 35916)
      ] = `COMPRESSED_SRGB_S3TC_DXT1_EXT`),
      (e[(e.COMPRESSED_R11_EAC = 37488)] = `COMPRESSED_R11_EAC`),
      (e[(e.COMPRESSED_SIGNED_R11_EAC = 37489)] = `COMPRESSED_SIGNED_R11_EAC`),
      (e[(e.COMPRESSED_RG11_EAC = 37490)] = `COMPRESSED_RG11_EAC`),
      (e[
        (e.COMPRESSED_SIGNED_RG11_EAC = 37491)
      ] = `COMPRESSED_SIGNED_RG11_EAC`),
      (e[(e.COMPRESSED_RGB8_ETC2 = 37492)] = `COMPRESSED_RGB8_ETC2`),
      (e[(e.COMPRESSED_RGBA8_ETC2_EAC = 37496)] = `COMPRESSED_RGBA8_ETC2_EAC`),
      (e[(e.COMPRESSED_SRGB8_ETC2 = 37493)] = `COMPRESSED_SRGB8_ETC2`),
      (e[
        (e.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = 37497)
      ] = `COMPRESSED_SRGB8_ALPHA8_ETC2_EAC`),
      (e[
        (e.COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37494)
      ] = `COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2`),
      (e[
        (e.COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 = 37495)
      ] = `COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2`),
      (e[
        (e.COMPRESSED_RGB_PVRTC_4BPPV1_IMG = 35840)
      ] = `COMPRESSED_RGB_PVRTC_4BPPV1_IMG`),
      (e[
        (e.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG = 35842)
      ] = `COMPRESSED_RGBA_PVRTC_4BPPV1_IMG`),
      (e[
        (e.COMPRESSED_RGB_PVRTC_2BPPV1_IMG = 35841)
      ] = `COMPRESSED_RGB_PVRTC_2BPPV1_IMG`),
      (e[
        (e.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG = 35843)
      ] = `COMPRESSED_RGBA_PVRTC_2BPPV1_IMG`),
      (e[(e.COMPRESSED_RGB_ETC1_WEBGL = 36196)] = `COMPRESSED_RGB_ETC1_WEBGL`),
      (e[(e.COMPRESSED_RGB_ATC_WEBGL = 35986)] = `COMPRESSED_RGB_ATC_WEBGL`),
      (e[
        (e.COMPRESSED_RGBA_ATC_EXPLICIT_ALPHA_WEBGL = 35986)
      ] = `COMPRESSED_RGBA_ATC_EXPLICIT_ALPHA_WEBGL`),
      (e[
        (e.COMPRESSED_RGBA_ATC_INTERPOLATED_ALPHA_WEBGL = 34798)
      ] = `COMPRESSED_RGBA_ATC_INTERPOLATED_ALPHA_WEBGL`),
      (e[
        (e.COMPRESSED_RGBA_ASTC_4x4_KHR = 37808)
      ] = `COMPRESSED_RGBA_ASTC_4x4_KHR`),
      e
    ))(vi || {})),
      (yi = {
        33776: 0.5,
        33777: 0.5,
        33778: 1,
        33779: 1,
        35916: 0.5,
        35917: 0.5,
        35918: 1,
        35919: 1,
        37488: 0.5,
        37489: 0.5,
        37490: 1,
        37491: 1,
        37492: 0.5,
        37496: 1,
        37493: 0.5,
        37497: 1,
        37494: 0.5,
        37495: 0.5,
        35840: 0.5,
        35842: 0.5,
        35841: 0.25,
        35843: 0.25,
        36196: 0.5,
        35986: 0.5,
        35986: 1,
        34798: 1,
        37808: 1,
      });
  }))();
}
function xi() {
  Ci = {
    s3tc: Si.getExtension(`WEBGL_compressed_texture_s3tc`),
    s3tc_sRGB: Si.getExtension(`WEBGL_compressed_texture_s3tc_srgb`),
    etc: Si.getExtension(`WEBGL_compressed_texture_etc`),
    etc1: Si.getExtension(`WEBGL_compressed_texture_etc1`),
    pvrtc:
      Si.getExtension(`WEBGL_compressed_texture_pvrtc`) ||
      Si.getExtension(`WEBKIT_WEBGL_compressed_texture_pvrtc`),
    atc: Si.getExtension(`WEBGL_compressed_texture_atc`),
    astc: Si.getExtension(`WEBGL_compressed_texture_astc`),
  };
}
var Si, Ci, wi;
function Ti() {
  return (Ti = t(() => {
    R(),
      (wi = {
        extension: { type: z.DetectionParser, priority: 2 },
        test: async () => {
          let e = A.ADAPTER.createCanvas().getContext(`webgl`);
          return e
            ? ((Si = e), !0)
            : (console.warn(`WebGL not available for compressed textures.`),
              !1);
        },
        add: async (e) => {
          Ci || xi();
          let t = [];
          for (let e in Ci) Ci[e] && t.push(e);
          return [...t, ...e];
        },
        remove: async (e) => (Ci || xi(), e.filter((e) => !(e in Ci))),
      }),
      I.add(wi);
  }))();
}
var Ei;
function Di() {
  return (Di = t(() => {
    R(),
      (Ei = class extends Ie {
        constructor(e, t = { width: 1, height: 1, autoLoad: !0 }) {
          let n, r;
          typeof e == `string`
            ? ((n = e), (r = new Uint8Array()))
            : ((n = null), (r = e)),
            super(r, t),
            (this.origin = n),
            (this.buffer = r ? new pe(r) : null),
            this.origin && t.autoLoad !== !1 && this.load(),
            r?.length &&
              ((this.loaded = !0),
              this.onBlobLoaded(this.buffer.rawBinaryData));
        }
        onBlobLoaded(e) {}
        async load() {
          let e = await (await (await fetch(this.origin)).blob()).arrayBuffer();
          return (
            (this.data = new Uint32Array(e)),
            (this.buffer = new pe(e)),
            (this.loaded = !0),
            this.onBlobLoaded(e),
            this.update(),
            this
          );
        }
      });
  }))();
}
var Oi;
function ki() {
  return (ki = t(() => {
    bi(),
      Di(),
      (Oi = class e extends Ei {
        constructor(t, n) {
          super(t, n),
            (this.format = n.format),
            (this.levels = n.levels || 1),
            (this._width = n.width),
            (this._height = n.height),
            (this._extension = e._formatToExtension(this.format)),
            (n.levelBuffers || this.buffer) &&
              (this._levelBuffers =
                n.levelBuffers ||
                e._createLevelBuffers(
                  t instanceof Uint8Array ? t : this.buffer.uint8View,
                  this.format,
                  this.levels,
                  4,
                  4,
                  this.width,
                  this.height
                ));
        }
        upload(e, t, n) {
          let r = e.gl;
          if (!e.context.extensions[this._extension])
            throw Error(
              `${this._extension} textures are not supported on the current machine`
            );
          if (!this._levelBuffers) return !1;
          for (let e = 0, t = this.levels; e < t; e++) {
            let {
              levelID: t,
              levelWidth: n,
              levelHeight: i,
              levelBuffer: a,
            } = this._levelBuffers[e];
            r.compressedTexImage2D(r.TEXTURE_2D, t, this.format, n, i, 0, a);
          }
          return !0;
        }
        onBlobLoaded() {
          this._levelBuffers = e._createLevelBuffers(
            this.buffer.uint8View,
            this.format,
            this.levels,
            4,
            4,
            this.width,
            this.height
          );
        }
        static _formatToExtension(e) {
          if (e >= 33776 && e <= 33779) return `s3tc`;
          if (e >= 37488 && e <= 37497) return `etc`;
          if (e >= 35840 && e <= 35843) return `pvrtc`;
          if (e >= 36196) return `etc1`;
          if (e >= 35986 && e <= 34798) return `atc`;
          throw Error(`Invalid (compressed) texture format given!`);
        }
        static _createLevelBuffers(e, t, n, r, i, a, o) {
          let s = Array(n),
            c = e.byteOffset,
            l = a,
            u = o,
            d = (l + r - 1) & ~(r - 1),
            f = (u + i - 1) & ~(i - 1),
            p = d * f * yi[t];
          for (let a = 0; a < n; a++)
            (s[a] = {
              levelID: a,
              levelWidth: n > 1 ? l : d,
              levelHeight: n > 1 ? u : f,
              levelBuffer: new Uint8Array(e.buffer, c, p),
            }),
              (c += p),
              (l = l >> 1 || 1),
              (u = u >> 1 || 1),
              (d = (l + r - 1) & ~(r - 1)),
              (f = (u + i - 1) & ~(i - 1)),
              (p = d * f * yi[t]);
          return s;
        }
      });
  }))();
}
function Ai() {
  return (Ai = t(() => {
    Di(), ki();
  }))();
}
function ji(e) {
  let t = new Uint32Array(e);
  if (t[0] !== Fi) throw Error(`Invalid DDS file magic word`);
  let n = new Uint32Array(e, 0, Mi / Uint32Array.BYTES_PER_ELEMENT),
    r = n[Ii.HEIGHT],
    i = n[Ii.WIDTH],
    a = n[Ii.MIPMAP_COUNT],
    o = new Uint32Array(
      e,
      Ii.PIXEL_FORMAT * Uint32Array.BYTES_PER_ELEMENT,
      Ni / Uint32Array.BYTES_PER_ELEMENT
    ),
    s = o[zi];
  if (s & Vi) {
    let n = o[Li.FOURCC];
    if (n !== Ji) {
      let t = Xi[n],
        o = new Uint8Array(e, 128);
      return [new Oi(o, { format: t, width: i, height: r, levels: a })];
    }
    let s = new Uint32Array(t.buffer, 128, Pi / Uint32Array.BYTES_PER_ELEMENT),
      c = s[Ri.DXGI_FORMAT],
      l = s[Ri.RESOURCE_DIMENSION],
      u = s[Ri.MISC_FLAG],
      d = s[Ri.ARRAY_SIZE],
      f = Zi[c];
    if (f === void 0)
      throw Error(`DDSParser cannot parse texture data with DXGI format ${c}`);
    if (u === Yi) throw Error(`DDSParser does not support cubemap textures`);
    if (l === 6) throw Error(`DDSParser does not supported 3D texture data`);
    let p = [];
    if (d === 1) p.push(new Uint8Array(e, 148));
    else {
      let t = yi[f],
        n = 0,
        o = i,
        s = r;
      for (let e = 0; e < a; e++) {
        let e = Math.max(1, (o + 3) & -4) * Math.max(1, (s + 3) & -4) * t;
        (n += e), (o >>>= 1), (s >>>= 1);
      }
      let c = 148;
      for (let t = 0; t < d; t++) p.push(new Uint8Array(e, c, n)), (c += n);
    }
    return p.map(
      (e) => new Oi(e, { format: f, width: i, height: r, levels: a })
    );
  }
  throw s & Hi
    ? Error(`DDSParser does not support uncompressed texture data.`)
    : s & Ui
    ? Error(`DDSParser does not supported YUV uncompressed texture data.`)
    : s & Wi
    ? Error(
        `DDSParser does not support single-channel (lumninance) texture data!`
      )
    : s & Bi
    ? Error(`DDSParser does not support single-channel (alpha) texture data!`)
    : Error(
        `DDSParser failed to load a texture file due to an unknown reason!`
      );
}
var Mi,
  Ni,
  Pi,
  Fi,
  Ii,
  Li,
  Ri,
  zi,
  Bi,
  Vi,
  Hi,
  Ui,
  Wi,
  Gi,
  Ki,
  qi,
  Ji,
  Yi,
  Xi,
  Zi;
function Qi() {
  return (Qi = t(() => {
    bi(),
      Ai(),
      ki(),
      (Mi = 124),
      (Ni = 32),
      (Pi = 20),
      (Fi = 542327876),
      (Ii = {
        SIZE: 1,
        FLAGS: 2,
        HEIGHT: 3,
        WIDTH: 4,
        MIPMAP_COUNT: 7,
        PIXEL_FORMAT: 19,
      }),
      (Li = {
        SIZE: 0,
        FLAGS: 1,
        FOURCC: 2,
        RGB_BITCOUNT: 3,
        R_BIT_MASK: 4,
        G_BIT_MASK: 5,
        B_BIT_MASK: 6,
        A_BIT_MASK: 7,
      }),
      (Ri = {
        DXGI_FORMAT: 0,
        RESOURCE_DIMENSION: 1,
        MISC_FLAG: 2,
        ARRAY_SIZE: 3,
        MISC_FLAGS2: 4,
      }),
      (zi = 1),
      (Bi = 2),
      (Vi = 4),
      (Hi = 64),
      (Ui = 512),
      (Wi = 131072),
      (Gi = 827611204),
      (Ki = 861165636),
      (qi = 894720068),
      (Ji = 808540228),
      (Yi = 4),
      (Xi = {
        [Gi]: vi.COMPRESSED_RGBA_S3TC_DXT1_EXT,
        [Ki]: vi.COMPRESSED_RGBA_S3TC_DXT3_EXT,
        [qi]: vi.COMPRESSED_RGBA_S3TC_DXT5_EXT,
      }),
      (Zi = {
        70: vi.COMPRESSED_RGBA_S3TC_DXT1_EXT,
        71: vi.COMPRESSED_RGBA_S3TC_DXT1_EXT,
        73: vi.COMPRESSED_RGBA_S3TC_DXT3_EXT,
        74: vi.COMPRESSED_RGBA_S3TC_DXT3_EXT,
        76: vi.COMPRESSED_RGBA_S3TC_DXT5_EXT,
        77: vi.COMPRESSED_RGBA_S3TC_DXT5_EXT,
        72: vi.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT,
        75: vi.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT,
        78: vi.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT,
      });
  }))();
}
function $i(e, t, n = !1) {
  let r = new DataView(t);
  if (!ea(e, r)) return null;
  let i = r.getUint32(aa.ENDIANNESS, !0) === ia,
    a = r.getUint32(aa.GL_TYPE, i),
    o = r.getUint32(aa.GL_FORMAT, i),
    s = r.getUint32(aa.GL_INTERNAL_FORMAT, i),
    c = r.getUint32(aa.PIXEL_WIDTH, i),
    l = r.getUint32(aa.PIXEL_HEIGHT, i) || 1,
    u = r.getUint32(aa.PIXEL_DEPTH, i) || 1,
    d = r.getUint32(aa.NUMBER_OF_ARRAY_ELEMENTS, i) || 1,
    f = r.getUint32(aa.NUMBER_OF_FACES, i),
    p = r.getUint32(aa.NUMBER_OF_MIPMAP_LEVELS, i),
    m = r.getUint32(aa.BYTES_OF_KEY_VALUE_DATA, i);
  if (l === 0 || u !== 1) throw Error(`Only 2D textures are supported`);
  if (f !== 1) throw Error(`CubeTextures are not supported by KTXLoader yet!`);
  if (d !== 1) throw Error(`WebGL does not support array textures`);
  let h = (c + 3) & -4,
    g = (l + 3) & -4,
    _ = Array(d),
    v = c * l;
  a === 0 && (v = h * g);
  let y;
  if (((y = a === 0 ? yi[s] : sa[a] ? sa[a] * ca[o] : la[a]), y === void 0))
    throw Error(`Unable to resolve the pixel format stored in the *.ktx file!`);
  let b = n ? na(r, m, i) : null,
    x = v * y,
    S = c,
    C = l,
    w = h,
    T = g,
    E = oa + m;
  for (let e = 0; e < p; e++) {
    let n = r.getUint32(E, i),
      o = E + 4;
    for (let n = 0; n < d; n++) {
      let r = _[n];
      (r ||= _[n] = Array(p)),
        (r[e] = {
          levelID: e,
          levelWidth: p > 1 || a !== 0 ? S : w,
          levelHeight: p > 1 || a !== 0 ? C : T,
          levelBuffer: new Uint8Array(t, o, x),
        }),
        (o += x);
    }
    (E += n + 4),
      (E = E % 4 == 0 ? E : E + 4 - (E % 4)),
      (S = S >> 1 || 1),
      (C = C >> 1 || 1),
      (w = (S + 4 - 1) & -4),
      (T = (C + 4 - 1) & -4),
      (x = w * T * y);
  }
  return a === 0
    ? {
        compressed: _.map(
          (e) =>
            new Oi(null, {
              format: s,
              width: c,
              height: l,
              levels: p,
              levelBuffers: e,
            })
        ),
        kvData: b,
      }
    : {
        uncompressed: _.map((e) => {
          let t = e[0].levelBuffer,
            n = !1;
          return (
            a === P.FLOAT
              ? (t = new Float32Array(
                  e[0].levelBuffer.buffer,
                  e[0].levelBuffer.byteOffset,
                  e[0].levelBuffer.byteLength / 4
                ))
              : a === P.UNSIGNED_INT
              ? ((n = !0),
                (t = new Uint32Array(
                  e[0].levelBuffer.buffer,
                  e[0].levelBuffer.byteOffset,
                  e[0].levelBuffer.byteLength / 4
                )))
              : a === P.INT &&
                ((n = !0),
                (t = new Int32Array(
                  e[0].levelBuffer.buffer,
                  e[0].levelBuffer.byteOffset,
                  e[0].levelBuffer.byteLength / 4
                ))),
            {
              resource: new Ie(t, {
                width: e[0].levelWidth,
                height: e[0].levelHeight,
              }),
              type: a,
              format: n ? ta(o) : o,
            }
          );
        }),
        kvData: b,
      };
}
function ea(e, t) {
  for (let n = 0; n < ra.length; n++)
    if (t.getUint8(n) !== ra[n])
      return console.error(`${e} is not a valid *.ktx file!`), !1;
  return !0;
}
function ta(e) {
  switch (e) {
    case Ee.RGBA:
      return Ee.RGBA_INTEGER;
    case Ee.RGB:
      return Ee.RGB_INTEGER;
    case Ee.RG:
      return Ee.RG_INTEGER;
    case Ee.RED:
      return Ee.RED_INTEGER;
    default:
      return e;
  }
}
function na(e, t, n) {
  let r = new Map(),
    i = 0;
  for (; i < t; ) {
    let a = e.getUint32(oa + i, n),
      o = oa + i + 4,
      s = 3 - ((a + 3) % 4);
    if (a === 0 || a > t - i) {
      console.error(`KTXLoader: keyAndValueByteSize out of bounds`);
      break;
    }
    let c = 0;
    for (; c < a && e.getUint8(o + c) !== 0; c++);
    if (c === -1) {
      console.error(
        `KTXLoader: Failed to find null byte terminating kvData key`
      );
      break;
    }
    let l = new TextDecoder().decode(new Uint8Array(e.buffer, o, c)),
      u = new DataView(e.buffer, o + c + 1, a - c - 1);
    r.set(l, u), (i += 4 + a + s);
  }
  return r;
}
var ra, ia, aa, oa, sa, ca, la;
function ua() {
  return (ua = t(() => {
    R(),
      bi(),
      Ai(),
      ki(),
      (ra = [171, 75, 84, 88, 32, 49, 49, 187, 13, 10, 26, 10]),
      (ia = 67305985),
      (aa = {
        FILE_IDENTIFIER: 0,
        ENDIANNESS: 12,
        GL_TYPE: 16,
        GL_TYPE_SIZE: 20,
        GL_FORMAT: 24,
        GL_INTERNAL_FORMAT: 28,
        GL_BASE_INTERNAL_FORMAT: 32,
        PIXEL_WIDTH: 36,
        PIXEL_HEIGHT: 40,
        PIXEL_DEPTH: 44,
        NUMBER_OF_ARRAY_ELEMENTS: 48,
        NUMBER_OF_FACES: 52,
        NUMBER_OF_MIPMAP_LEVELS: 56,
        BYTES_OF_KEY_VALUE_DATA: 60,
      }),
      (oa = 64),
      (sa = {
        [P.UNSIGNED_BYTE]: 1,
        [P.UNSIGNED_SHORT]: 2,
        [P.INT]: 4,
        [P.UNSIGNED_INT]: 4,
        [P.FLOAT]: 4,
        [P.HALF_FLOAT]: 8,
      }),
      (ca = {
        [Ee.RGBA]: 4,
        [Ee.RGB]: 3,
        [Ee.RG]: 2,
        [Ee.RED]: 1,
        [Ee.LUMINANCE]: 1,
        [Ee.LUMINANCE_ALPHA]: 2,
        [Ee.ALPHA]: 1,
      }),
      (la = {
        [P.UNSIGNED_SHORT_4_4_4_4]: 2,
        [P.UNSIGNED_SHORT_5_5_5_1]: 2,
        [P.UNSIGNED_SHORT_5_6_5]: 2,
      });
  }))();
}
function da() {
  return (da = t(() => {
    Qi(), ua();
  }))();
}
var fa;
function pa() {
  return (pa = t(() => {
    _i(),
      R(),
      da(),
      Qi(),
      (fa = {
        extension: { type: z.LoadParser, priority: ur.High },
        name: `loadDDS`,
        test(e) {
          return Jn(e, `.dds`);
        },
        async load(e, t, n) {
          let r = ji(await (await A.ADAPTER.fetch(e)).arrayBuffer()).map((r) =>
            Pr(
              new ee(r, {
                mipmap: ne.OFF,
                alphaMode: O.NO_PREMULTIPLIED_ALPHA,
                resolution: Le(e),
                ...t.data,
              }),
              n,
              e
            )
          );
          return r.length === 1 ? r[0] : r;
        },
        unload(e) {
          Array.isArray(e) ? e.forEach((e) => e.destroy(!0)) : e.destroy(!0);
        },
      }),
      I.add(fa);
  }))();
}
var ma;
function ha() {
  return (ha = t(() => {
    _i(),
      R(),
      da(),
      ua(),
      (ma = {
        extension: { type: z.LoadParser, priority: ur.High },
        name: `loadKTX`,
        test(e) {
          return Jn(e, `.ktx`);
        },
        async load(e, t, n) {
          let {
              compressed: r,
              uncompressed: i,
              kvData: a,
            } = $i(e, await (await A.ADAPTER.fetch(e)).arrayBuffer()),
            o = r ?? i,
            s = {
              mipmap: ne.OFF,
              alphaMode: O.NO_PREMULTIPLIED_ALPHA,
              resolution: Le(e),
              ...t.data,
            },
            c = o.map((t) => {
              o === i && Object.assign(s, { type: t.type, format: t.format });
              let r = new ee(t, s);
              return (r.ktxKeyValueData = a), Pr(r, n, e);
            });
          return c.length === 1 ? c[0] : c;
        },
        unload(e) {
          Array.isArray(e) ? e.forEach((e) => e.destroy(!0)) : e.destroy(!0);
        },
      }),
      I.add(ma);
  }))();
}
var ga;
function _a() {
  return (_a = t(() => {
    R(),
      (ga = {
        extension: z.ResolveParser,
        test: (e) => {
          let t = e.split(`?`)[0].split(`.`).pop();
          return [`basis`, `ktx`, `dds`].includes(t);
        },
        parse: (e) => {
          if (e.split(`?`)[0].split(`.`).pop() === `ktx`) {
            let t = [
              `.s3tc.ktx`,
              `.s3tc_sRGB.ktx`,
              `.etc.ktx`,
              `.etc1.ktx`,
              `.pvrt.ktx`,
              `.atc.ktx`,
              `.astc.ktx`,
            ];
            if (t.some((t) => e.endsWith(t)))
              return {
                resolution: parseFloat(A.RETINA_PREFIX.exec(e)?.[1] ?? `1`),
                format: t.find((t) => e.endsWith(t)),
                src: e,
              };
          }
          return {
            resolution: parseFloat(A.RETINA_PREFIX.exec(e)?.[1] ?? `1`),
            format: e.split(`.`).pop(),
            src: e,
          };
        },
      }),
      I.add(ga);
  }))();
}
function va() {
  return (va = t(() => {
    Ti(), pa(), ha(), _a();
  }))();
}
function ya() {
  return (ya = t(() => {
    va(), da(), Ai(), Ti(), pa(), ha(), _a(), Qi(), ua(), Di(), ki();
  }))();
}
var ba, xa, Sa, Ca;
function wa() {
  return (wa = t(() => {
    R(),
      (ba = new ce()),
      (xa = 4),
      (Sa = class {
        constructor(e) {
          this.renderer = e;
        }
        async image(e, t, n) {
          let r = new Image();
          return (r.src = await this.base64(e, t, n)), r;
        }
        async base64(e, t, n) {
          let r = this.canvas(e);
          if (r.toDataURL !== void 0) return r.toDataURL(t, n);
          if (r.convertToBlob !== void 0) {
            let e = await r.convertToBlob({ type: t, quality: n });
            return await new Promise((t) => {
              let n = new FileReader();
              (n.onload = () => t(n.result)), n.readAsDataURL(e);
            });
          }
          throw Error(
            `Extract.base64() requires ICanvas.toDataURL or ICanvas.convertToBlob to be implemented`
          );
        }
        canvas(e, t) {
          let {
              pixels: n,
              width: r,
              height: i,
              flipY: a,
            } = this._rawPixels(e, t),
            o = new he(r, i, 1),
            s = o.context.getImageData(0, 0, r, i);
          if (
            (Sa.arrayPostDivide(n, s.data), o.context.putImageData(s, 0, 0), a)
          ) {
            let e = new he(o.width, o.height, 1);
            e.context.scale(1, -1),
              e.context.drawImage(o.canvas, 0, -i),
              o.destroy(),
              (o = e);
          }
          return o.canvas;
        }
        pixels(e, t) {
          let { pixels: n } = this._rawPixels(e, t);
          return Sa.arrayPostDivide(n, n), n;
        }
        _rawPixels(e, t) {
          let n = this.renderer;
          if (!n) throw Error(`The Extract has already been destroyed`);
          let r,
            i = !1,
            a,
            o = !1;
          if (e)
            if (e instanceof Fe) a = e;
            else {
              let t = n.context.webGLVersion >= 2 ? n.multisample : ie.NONE;
              if (
                ((a = n.generateTexture(e, { multisample: t })), t !== ie.NONE)
              ) {
                let e = Fe.create({ width: a.width, height: a.height });
                n.framebuffer.bind(a.framebuffer),
                  n.framebuffer.blit(e.framebuffer),
                  n.framebuffer.bind(),
                  a.destroy(!0),
                  (a = e);
              }
              o = !0;
            }
          a
            ? ((r = a.baseTexture.resolution),
              (t ??= a.frame),
              (i = !1),
              n.renderTexture.bind(a))
            : ((r = n.resolution),
              t || ((t = ba), (t.width = n.width), (t.height = n.height)),
              (i = !0),
              n.renderTexture.bind());
          let s = Math.round(t.width * r),
            c = Math.round(t.height * r),
            l = new Uint8Array(xa * s * c),
            u = n.gl;
          return (
            u.readPixels(
              Math.round(t.x * r),
              Math.round(t.y * r),
              s,
              c,
              u.RGBA,
              u.UNSIGNED_BYTE,
              l
            ),
            o && a?.destroy(!0),
            { pixels: l, width: s, height: c, flipY: i }
          );
        }
        destroy() {
          this.renderer = null;
        }
        static arrayPostDivide(e, t) {
          for (let n = 0; n < e.length; n += 4) {
            let r = (t[n + 3] = e[n + 3]);
            r === 0
              ? ((t[n] = e[n]), (t[n + 1] = e[n + 1]), (t[n + 2] = e[n + 2]))
              : ((t[n] = Math.round(Math.min((e[n] * 255) / r, 255))),
                (t[n + 1] = Math.round(Math.min((e[n + 1] * 255) / r, 255))),
                (t[n + 2] = Math.round(Math.min((e[n + 2] * 255) / r, 255))));
          }
        }
      }),
      (Ca = Sa),
      (Ca.extension = { name: `extract`, type: z.RendererSystem }),
      I.add(Ca);
  }))();
}
function Ta() {
  return (Ta = t(() => {
    wa();
  }))();
}
var Ea;
function Da() {
  return (Da = t(() => {
    R(),
      Ye(),
      (Ea = class e extends w {
        constructor(e, t = !0) {
          super(e[0] instanceof B ? e[0] : e[0].texture),
            (this._textures = null),
            (this._durations = null),
            (this._autoUpdate = t),
            (this._isConnectedToTicker = !1),
            (this.animationSpeed = 1),
            (this.loop = !0),
            (this.updateAnchor = !1),
            (this.onComplete = null),
            (this.onFrameChange = null),
            (this.onLoop = null),
            (this._currentTime = 0),
            (this._playing = !1),
            (this._previousFrame = null),
            (this.textures = e);
        }
        stop() {
          this._playing &&
            ((this._playing = !1),
            this._autoUpdate &&
              this._isConnectedToTicker &&
              (ge.shared.remove(this.update, this),
              (this._isConnectedToTicker = !1)));
        }
        play() {
          this._playing ||
            ((this._playing = !0),
            this._autoUpdate &&
              !this._isConnectedToTicker &&
              (ge.shared.add(this.update, this, ze.HIGH),
              (this._isConnectedToTicker = !0)));
        }
        gotoAndStop(e) {
          this.stop(), (this.currentFrame = e);
        }
        gotoAndPlay(e) {
          (this.currentFrame = e), this.play();
        }
        update(e) {
          if (!this._playing) return;
          let t = this.animationSpeed * e,
            n = this.currentFrame;
          if (this._durations !== null) {
            let n =
              (this._currentTime % 1) * this._durations[this.currentFrame];
            for (n += (t / 60) * 1e3; n < 0; )
              this._currentTime--, (n += this._durations[this.currentFrame]);
            let r = Math.sign(this.animationSpeed * e);
            for (
              this._currentTime = Math.floor(this._currentTime);
              n >= this._durations[this.currentFrame];

            )
              (n -= this._durations[this.currentFrame] * r),
                (this._currentTime += r);
            this._currentTime += n / this._durations[this.currentFrame];
          } else this._currentTime += t;
          this._currentTime < 0 && !this.loop
            ? (this.gotoAndStop(0), this.onComplete && this.onComplete())
            : this._currentTime >= this._textures.length && !this.loop
            ? (this.gotoAndStop(this._textures.length - 1),
              this.onComplete && this.onComplete())
            : n !== this.currentFrame &&
              (this.loop &&
                this.onLoop &&
                ((this.animationSpeed > 0 && this.currentFrame < n) ||
                  (this.animationSpeed < 0 && this.currentFrame > n)) &&
                this.onLoop(),
              this.updateTexture());
        }
        updateTexture() {
          let e = this.currentFrame;
          this._previousFrame !== e &&
            ((this._previousFrame = e),
            (this._texture = this._textures[e]),
            (this._textureID = -1),
            (this._textureTrimmedID = -1),
            (this._cachedTint = 16777215),
            (this.uvs = this._texture._uvs.uvsFloat32),
            this.updateAnchor &&
              this._anchor.copyFrom(this._texture.defaultAnchor),
            this.onFrameChange && this.onFrameChange(this.currentFrame));
        }
        destroy(e) {
          this.stop(),
            super.destroy(e),
            (this.onComplete = null),
            (this.onFrameChange = null),
            (this.onLoop = null);
        }
        static fromFrames(t) {
          let n = [];
          for (let e = 0; e < t.length; ++e) n.push(B.from(t[e]));
          return new e(n);
        }
        static fromImages(t) {
          let n = [];
          for (let e = 0; e < t.length; ++e) n.push(B.from(t[e]));
          return new e(n);
        }
        get totalFrames() {
          return this._textures.length;
        }
        get textures() {
          return this._textures;
        }
        set textures(e) {
          if (e[0] instanceof B) (this._textures = e), (this._durations = null);
          else {
            (this._textures = []), (this._durations = []);
            for (let t = 0; t < e.length; t++)
              this._textures.push(e[t].texture),
                this._durations.push(e[t].time);
          }
          (this._previousFrame = null),
            this.gotoAndStop(0),
            this.updateTexture();
        }
        get currentFrame() {
          let e = Math.floor(this._currentTime) % this._textures.length;
          return e < 0 && (e += this._textures.length), e;
        }
        set currentFrame(e) {
          if (e < 0 || e > this.totalFrames - 1)
            throw Error(
              `[AnimatedSprite]: Invalid frame index value ${e}, expected to be between 0 and totalFrames ${this.totalFrames}.`
            );
          let t = this.currentFrame;
          (this._currentTime = e),
            t !== this.currentFrame && this.updateTexture();
        }
        get playing() {
          return this._playing;
        }
        get autoUpdate() {
          return this._autoUpdate;
        }
        set autoUpdate(e) {
          e !== this._autoUpdate &&
            ((this._autoUpdate = e),
            !this._autoUpdate && this._isConnectedToTicker
              ? (ge.shared.remove(this.update, this),
                (this._isConnectedToTicker = !1))
              : this._autoUpdate &&
                !this._isConnectedToTicker &&
                this._playing &&
                (ge.shared.add(this.update, this),
                (this._isConnectedToTicker = !0)));
        }
      });
  }))();
}
function Oa() {
  return (Oa = t(() => {
    Da();
  }))();
}
var ka, Aa;
function ja() {
  return (ja = t(() => {
    R(),
      (ka = class {
        constructor(e, t, n = null) {
          (this.linkedSheets = []),
            (this._texture = e instanceof B ? e : null),
            (this.baseTexture =
              e instanceof ee ? e : this._texture.baseTexture),
            (this.textures = {}),
            (this.animations = {}),
            (this.data = t);
          let r = this.baseTexture.resource;
          (this.resolution = this._updateResolution(n || (r ? r.url : null))),
            (this._frames = this.data.frames),
            (this._frameKeys = Object.keys(this._frames)),
            (this._batchIndex = 0),
            (this._callback = null);
        }
        _updateResolution(e = null) {
          let { scale: t } = this.data.meta,
            n = Le(e, null);
          return (
            n === null && (n = parseFloat(t ?? `1`)),
            n !== 1 && this.baseTexture.setResolution(n),
            n
          );
        }
        parse() {
          return new Promise((e) => {
            (this._callback = e),
              (this._batchIndex = 0),
              this._frameKeys.length <= ka.BATCH_SIZE
                ? (this._processFrames(0),
                  this._processAnimations(),
                  this._parseComplete())
                : this._nextBatch();
          });
        }
        _processFrames(e) {
          let t = e,
            n = ka.BATCH_SIZE;
          for (; t - e < n && t < this._frameKeys.length; ) {
            let e = this._frameKeys[t],
              n = this._frames[e],
              r = n.frame;
            if (r) {
              let t = null,
                i = null,
                a = n.trimmed !== !1 && n.sourceSize ? n.sourceSize : n.frame,
                o = new ce(
                  0,
                  0,
                  Math.floor(a.w) / this.resolution,
                  Math.floor(a.h) / this.resolution
                );
              (t = n.rotated
                ? new ce(
                    Math.floor(r.x) / this.resolution,
                    Math.floor(r.y) / this.resolution,
                    Math.floor(r.h) / this.resolution,
                    Math.floor(r.w) / this.resolution
                  )
                : new ce(
                    Math.floor(r.x) / this.resolution,
                    Math.floor(r.y) / this.resolution,
                    Math.floor(r.w) / this.resolution,
                    Math.floor(r.h) / this.resolution
                  )),
                n.trimmed !== !1 &&
                  n.spriteSourceSize &&
                  (i = new ce(
                    Math.floor(n.spriteSourceSize.x) / this.resolution,
                    Math.floor(n.spriteSourceSize.y) / this.resolution,
                    Math.floor(r.w) / this.resolution,
                    Math.floor(r.h) / this.resolution
                  )),
                (this.textures[e] = new B(
                  this.baseTexture,
                  t,
                  o,
                  i,
                  n.rotated ? 2 : 0,
                  n.anchor,
                  n.borders
                )),
                B.addToCache(this.textures[e], e);
            }
            t++;
          }
        }
        _processAnimations() {
          let e = this.data.animations || {};
          for (let t in e) {
            this.animations[t] = [];
            for (let n = 0; n < e[t].length; n++) {
              let r = e[t][n];
              this.animations[t].push(this.textures[r]);
            }
          }
        }
        _parseComplete() {
          let e = this._callback;
          (this._callback = null),
            (this._batchIndex = 0),
            e.call(this, this.textures);
        }
        _nextBatch() {
          this._processFrames(this._batchIndex * ka.BATCH_SIZE),
            this._batchIndex++,
            setTimeout(() => {
              this._batchIndex * ka.BATCH_SIZE < this._frameKeys.length
                ? this._nextBatch()
                : (this._processAnimations(), this._parseComplete());
            }, 0);
        }
        destroy(e = !1) {
          for (let e in this.textures) this.textures[e].destroy();
          (this._frames = null),
            (this._frameKeys = null),
            (this.data = null),
            (this.textures = null),
            e && (this._texture?.destroy(), this.baseTexture.destroy()),
            (this._texture = null),
            (this.baseTexture = null),
            (this.linkedSheets = []);
        }
      }),
      (Aa = ka),
      (Aa.BATCH_SIZE = 1e3);
  }))();
}
function Ma(e, t, n) {
  let r = {};
  if (
    (e.forEach((e) => {
      r[e] = t;
    }),
    Object.keys(t.textures).forEach((e) => {
      r[e] = t.textures[e];
    }),
    !n)
  ) {
    let n = L.dirname(e[0]);
    t.linkedSheets.forEach((e, i) => {
      let a = Ma([`${n}/${t.data.meta.related_multi_packs[i]}`], e, !0);
      Object.assign(r, a);
    });
  }
  return r;
}
var Na, Pa;
function Fa() {
  return (Fa = t(() => {
    _i(),
      R(),
      ja(),
      (Na = [`jpg`, `png`, `jpeg`, `avif`, `webp`]),
      (Pa = {
        extension: z.Asset,
        cache: {
          test: (e) => e instanceof Aa,
          getCacheableAssets: (e, t) => Ma(e, t, !1),
        },
        resolver: {
          test: (e) => {
            let t = e.split(`?`)[0].split(`.`),
              n = t.pop(),
              r = t.pop();
            return n === `json` && Na.includes(r);
          },
          parse: (e) => {
            let t = e.split(`.`);
            return {
              resolution: parseFloat(A.RETINA_PREFIX.exec(e)?.[1] ?? `1`),
              format: t[t.length - 2],
              src: e,
            };
          },
        },
        loader: {
          name: `spritesheetLoader`,
          extension: { type: z.LoadParser, priority: ur.Normal },
          async testParse(e, t) {
            return L.extname(t.src).toLowerCase() === `.json` && !!e.frames;
          },
          async parse(e, t, n) {
            let r = L.dirname(t.src);
            r && r.lastIndexOf(`/`) !== r.length - 1 && (r += `/`);
            let i = r + e.meta.image;
            i = Qn(i, t.src);
            let a = (await n.load([i]))[i],
              o = new Aa(a.baseTexture, e, t.src);
            await o.parse();
            let s = e?.meta?.related_multi_packs;
            if (Array.isArray(s)) {
              let e = [];
              for (let i of s) {
                if (typeof i != `string`) continue;
                let a = r + i;
                t.data?.ignoreMultiPack ||
                  ((a = Qn(a, t.src)),
                  e.push(n.load({ src: a, data: { ignoreMultiPack: !0 } })));
              }
              let i = await Promise.all(e);
              (o.linkedSheets = i),
                i.forEach((e) => {
                  e.linkedSheets = [o].concat(
                    o.linkedSheets.filter((t) => t !== e)
                  );
                });
            }
            return o;
          },
          unload(e) {
            e.destroy(!0);
          },
        },
      }),
      I.add(Pa);
  }))();
}
function Ia() {
  return (Ia = t(() => {
    ja(), Fa();
  }))();
}
var La;
function Ra() {
  return (Ra = t(() => {
    La = class {
      constructor() {
        (this.info = []),
          (this.common = []),
          (this.page = []),
          (this.char = []),
          (this.kerning = []),
          (this.distanceField = []);
      }
    };
  }))();
}
var za;
function Ba() {
  return (Ba = t(() => {
    Ra(),
      (za = class {
        static test(e) {
          return typeof e == `string` && e.startsWith(`info face=`);
        }
        static parse(e) {
          let t = e.match(/^[a-z]+\s+.+$/gm),
            n = {
              info: [],
              common: [],
              page: [],
              char: [],
              chars: [],
              kerning: [],
              kernings: [],
              distanceField: [],
            };
          for (let e in t) {
            let r = t[e].match(/^[a-z]+/gm)[0],
              i = t[e].match(/[a-zA-Z]+=([^\s"']+|"([^"]*)")/gm),
              a = {};
            for (let e in i) {
              let t = i[e].split(`=`),
                n = t[0],
                r = t[1].replace(/"/gm, ``),
                o = parseFloat(r);
              a[n] = isNaN(o) ? r : o;
            }
            n[r].push(a);
          }
          let r = new La();
          return (
            n.info.forEach((e) =>
              r.info.push({ face: e.face, size: parseInt(e.size, 10) })
            ),
            n.common.forEach((e) =>
              r.common.push({ lineHeight: parseInt(e.lineHeight, 10) })
            ),
            n.page.forEach((e) =>
              r.page.push({ id: parseInt(e.id, 10), file: e.file })
            ),
            n.char.forEach((e) =>
              r.char.push({
                id: parseInt(e.id, 10),
                page: parseInt(e.page, 10),
                x: parseInt(e.x, 10),
                y: parseInt(e.y, 10),
                width: parseInt(e.width, 10),
                height: parseInt(e.height, 10),
                xoffset: parseInt(e.xoffset, 10),
                yoffset: parseInt(e.yoffset, 10),
                xadvance: parseInt(e.xadvance, 10),
              })
            ),
            n.kerning.forEach((e) =>
              r.kerning.push({
                first: parseInt(e.first, 10),
                second: parseInt(e.second, 10),
                amount: parseInt(e.amount, 10),
              })
            ),
            n.distanceField.forEach((e) =>
              r.distanceField.push({
                distanceRange: parseInt(e.distanceRange, 10),
                fieldType: e.fieldType,
              })
            ),
            r
          );
        }
      });
  }))();
}
var Va;
function Ha() {
  return (Ha = t(() => {
    Ra(),
      (Va = class {
        static test(e) {
          let t = e;
          return (
            `getElementsByTagName` in t &&
            t.getElementsByTagName(`page`).length &&
            t.getElementsByTagName(`info`)[0].getAttribute(`face`) !== null
          );
        }
        static parse(e) {
          let t = new La(),
            n = e.getElementsByTagName(`info`),
            r = e.getElementsByTagName(`common`),
            i = e.getElementsByTagName(`page`),
            a = e.getElementsByTagName(`char`),
            o = e.getElementsByTagName(`kerning`),
            s = e.getElementsByTagName(`distanceField`);
          for (let e = 0; e < n.length; e++)
            t.info.push({
              face: n[e].getAttribute(`face`),
              size: parseInt(n[e].getAttribute(`size`), 10),
            });
          for (let e = 0; e < r.length; e++)
            t.common.push({
              lineHeight: parseInt(r[e].getAttribute(`lineHeight`), 10),
            });
          for (let e = 0; e < i.length; e++)
            t.page.push({
              id: parseInt(i[e].getAttribute(`id`), 10) || 0,
              file: i[e].getAttribute(`file`),
            });
          for (let e = 0; e < a.length; e++) {
            let n = a[e];
            t.char.push({
              id: parseInt(n.getAttribute(`id`), 10),
              page: parseInt(n.getAttribute(`page`), 10) || 0,
              x: parseInt(n.getAttribute(`x`), 10),
              y: parseInt(n.getAttribute(`y`), 10),
              width: parseInt(n.getAttribute(`width`), 10),
              height: parseInt(n.getAttribute(`height`), 10),
              xoffset: parseInt(n.getAttribute(`xoffset`), 10),
              yoffset: parseInt(n.getAttribute(`yoffset`), 10),
              xadvance: parseInt(n.getAttribute(`xadvance`), 10),
            });
          }
          for (let e = 0; e < o.length; e++)
            t.kerning.push({
              first: parseInt(o[e].getAttribute(`first`), 10),
              second: parseInt(o[e].getAttribute(`second`), 10),
              amount: parseInt(o[e].getAttribute(`amount`), 10),
            });
          for (let e = 0; e < s.length; e++)
            t.distanceField.push({
              fieldType: s[e].getAttribute(`fieldType`),
              distanceRange: parseInt(s[e].getAttribute(`distanceRange`), 10),
            });
          return t;
        }
      });
  }))();
}
var Ua;
function Wa() {
  return (Wa = t(() => {
    R(),
      Ha(),
      (Ua = class {
        static test(e) {
          return typeof e == `string` && e.includes(`<font>`)
            ? Va.test(A.ADAPTER.parseXML(e))
            : !1;
        }
        static parse(e) {
          return Va.parse(A.ADAPTER.parseXML(e));
        }
      });
  }))();
}
function Ga(e) {
  for (let t = 0; t < Ka.length; t++) if (Ka[t].test(e)) return Ka[t];
  return null;
}
var Ka;
function qa() {
  return (qa = t(() => {
    Ba(), Ha(), Wa(), (Ka = [za, Va, Ua]);
  }))();
}
function Ja(e, t, n, r, i, a) {
  let o = n.fill;
  if (!Array.isArray(o)) return o;
  if (o.length === 1) return o[0];
  let s,
    c = n.dropShadow ? n.dropShadowDistance : 0,
    l = n.padding || 0,
    u = e.width / r - c - l * 2,
    d = e.height / r - c - l * 2,
    f = o.slice(),
    p = n.fillGradientStops.slice();
  if (!p.length) {
    let e = f.length + 1;
    for (let t = 1; t < e; ++t) p.push(t / e);
  }
  if (
    (f.unshift(o[0]),
    p.unshift(0),
    f.push(o[o.length - 1]),
    p.push(1),
    n.fillGradientType === Ae.LINEAR_VERTICAL)
  ) {
    s = t.createLinearGradient(u / 2, l, u / 2, d + l);
    let e = 0,
      r = (a.fontProperties.fontSize + n.strokeThickness) / d;
    for (let t = 0; t < i.length; t++) {
      let n = a.lineHeight * t;
      for (let t = 0; t < f.length; t++) {
        let i = 0;
        i = typeof p[t] == `number` ? p[t] : t / f.length;
        let a = n / d + i * r,
          o = Math.max(e, a);
        (o = Math.min(o, 1)), s.addColorStop(o, f[t]), (e = o);
      }
    }
  } else {
    s = t.createLinearGradient(l, d / 2, u + l, d / 2);
    let e = f.length + 1,
      n = 1;
    for (let t = 0; t < f.length; t++) {
      let r;
      (r = typeof p[t] == `number` ? p[t] : n / e),
        s.addColorStop(r, f[t]),
        n++;
    }
  }
  return s;
}
function Ya() {
  return (Ya = t(() => {
    Re();
  }))();
}
function Xa(e, t, n, r, i, a, o) {
  let s = n.text,
    c = n.fontProperties;
  t.translate(r, i), t.scale(a, a);
  let l = o.strokeThickness / 2,
    u = -(o.strokeThickness / 2);
  if (
    ((t.font = o.toFontString()),
    (t.lineWidth = o.strokeThickness),
    (t.textBaseline = o.textBaseline),
    (t.lineJoin = o.lineJoin),
    (t.miterLimit = o.miterLimit),
    (t.fillStyle = Ja(e, t, o, a, [s], n)),
    (t.strokeStyle = o.stroke),
    o.dropShadow)
  ) {
    let e = o.dropShadowColor,
      n = o.dropShadowBlur * a,
      r = o.dropShadowDistance * a;
    (t.shadowColor = me.shared
      .setValue(e)
      .setAlpha(o.dropShadowAlpha)
      .toRgbaString()),
      (t.shadowBlur = n),
      (t.shadowOffsetX = Math.cos(o.dropShadowAngle) * r),
      (t.shadowOffsetY = Math.sin(o.dropShadowAngle) * r);
  } else
    (t.shadowColor = `black`),
      (t.shadowBlur = 0),
      (t.shadowOffsetX = 0),
      (t.shadowOffsetY = 0);
  o.stroke &&
    o.strokeThickness &&
    t.strokeText(s, l, u + n.lineHeight - c.descent),
    o.fill && t.fillText(s, l, u + n.lineHeight - c.descent),
    t.setTransform(1, 0, 0, 1, 0, 0),
    (t.fillStyle = `rgba(0, 0, 0, 0)`);
}
function Za() {
  return (Za = t(() => {
    R(), Ya();
  }))();
}
function Qa(e) {
  return e.codePointAt ? e.codePointAt(0) : e.charCodeAt(0);
}
function $a(e) {
  return Array.from ? Array.from(e) : e.split(``);
}
function eo(e) {
  typeof e == `string` && (e = [e]);
  let t = [];
  for (let n = 0, r = e.length; n < r; n++) {
    let r = e[n];
    if (Array.isArray(r)) {
      if (r.length !== 2)
        throw Error(
          `[BitmapFont]: Invalid character range length, expecting 2 got ${r.length}.`
        );
      let e = r[0].charCodeAt(0),
        n = r[1].charCodeAt(0);
      if (n < e) throw Error(`[BitmapFont]: Invalid character range.`);
      for (let r = e, i = n; r <= i; r++) t.push(String.fromCharCode(r));
    } else t.push(...$a(r));
  }
  if (t.length === 0)
    throw Error(`[BitmapFont]: Empty set when resolving characters.`);
  return t;
}
function to() {
  return (to = t(() => {}))();
}
function no() {
  return (no = t(() => {
    Za(), Ya();
  }))();
}
var ro, io;
function ao() {
  return (ao = t(() => {
    R(),
      Re(),
      Ra(),
      qa(),
      no(),
      to(),
      Za(),
      (ro = class {
        constructor(e, t, n) {
          let [r] = e.info,
            [i] = e.common,
            [a] = e.page,
            [o] = e.distanceField,
            s = Le(a.file),
            c = {};
          (this._ownsTextures = n),
            (this.font = r.face),
            (this.size = r.size),
            (this.lineHeight = i.lineHeight / s),
            (this.chars = {}),
            (this.pageTextures = c);
          for (let n = 0; n < e.page.length; n++) {
            let { id: r, file: i } = e.page[n];
            (c[r] = t instanceof Array ? t[n] : t[i]),
              o?.fieldType &&
                o.fieldType !== `none` &&
                ((c[r].baseTexture.alphaMode = O.NO_PREMULTIPLIED_ALPHA),
                (c[r].baseTexture.mipmap = ne.OFF));
          }
          for (let t = 0; t < e.char.length; t++) {
            let { id: n, page: r } = e.char[t],
              {
                x: i,
                y: a,
                width: o,
                height: l,
                xoffset: u,
                yoffset: d,
                xadvance: f,
              } = e.char[t];
            (i /= s),
              (a /= s),
              (o /= s),
              (l /= s),
              (u /= s),
              (d /= s),
              (f /= s);
            let p = new ce(i + c[r].frame.x / s, a + c[r].frame.y / s, o, l);
            this.chars[n] = {
              xOffset: u,
              yOffset: d,
              xAdvance: f,
              kerning: {},
              texture: new B(c[r].baseTexture, p),
              page: r,
            };
          }
          for (let t = 0; t < e.kerning.length; t++) {
            let { first: n, second: r, amount: i } = e.kerning[t];
            (n /= s),
              (r /= s),
              (i /= s),
              this.chars[r] && (this.chars[r].kerning[n] = i);
          }
          (this.distanceFieldRange = o?.distanceRange),
            (this.distanceFieldType = o?.fieldType?.toLowerCase() ?? `none`);
        }
        destroy() {
          for (let e in this.chars)
            this.chars[e].texture.destroy(), (this.chars[e].texture = null);
          for (let e in this.pageTextures)
            this._ownsTextures && this.pageTextures[e].destroy(!0),
              (this.pageTextures[e] = null);
          (this.chars = null), (this.pageTextures = null);
        }
        static install(e, t, n) {
          let r;
          if (e instanceof La) r = e;
          else {
            let t = Ga(e);
            if (!t) throw Error(`Unrecognized data format for font.`);
            r = t.parse(e);
          }
          t instanceof B && (t = [t]);
          let i = new ro(r, t, n);
          return (ro.available[i.font] = i), i;
        }
        static uninstall(e) {
          let t = ro.available[e];
          if (!t) throw Error(`No font found named '${e}'`);
          t.destroy(), delete ro.available[e];
        }
        static from(e, t, n) {
          if (!e) throw Error("[BitmapFont] Property `name` is required.");
          let {
              chars: r,
              padding: i,
              resolution: a,
              textureWidth: o,
              textureHeight: s,
              ...c
            } = Object.assign({}, ro.defaultOptions, n),
            l = eo(r),
            u = t instanceof He ? t : new He(t),
            d = o,
            f = new La();
          (f.info[0] = { face: u.fontFamily, size: u.fontSize }),
            (f.common[0] = { lineHeight: u.fontSize });
          let p = 0,
            m = 0,
            h,
            g,
            _,
            v = 0,
            y = [],
            b = [];
          for (let e = 0; e < l.length; e++) {
            h ||
              ((h = A.ADAPTER.createCanvas()),
              (h.width = o),
              (h.height = s),
              (g = h.getContext(`2d`)),
              (_ = new ee(h, { resolution: a, ...c })),
              y.push(_),
              b.push(new B(_)),
              f.page.push({ id: b.length - 1, file: `` }));
            let t = l[e],
              n = be.measureText(t, u, !1, h),
              r = n.width,
              x = Math.ceil(n.height),
              S = Math.ceil((u.fontStyle === `italic` ? 2 : 1) * r);
            if (m >= s - x * a) {
              if (m === 0)
                throw Error(
                  `[BitmapFont] textureHeight ${s}px is too small (fontFamily: '${u.fontFamily}', fontSize: ${u.fontSize}px, char: '${t}')`
                );
              --e,
                (h = null),
                (g = null),
                (_ = null),
                (m = 0),
                (p = 0),
                (v = 0);
              continue;
            }
            if (
              ((v = Math.max(x + n.fontProperties.descent, v)), S * a + p >= d)
            ) {
              if (p === 0)
                throw Error(
                  `[BitmapFont] textureWidth ${o}px is too small (fontFamily: '${u.fontFamily}', fontSize: ${u.fontSize}px, char: '${t}')`
                );
              --e, (m += v * a), (m = Math.ceil(m)), (p = 0), (v = 0);
              continue;
            }
            Xa(h, g, n, p, m, a, u);
            let C = Qa(n.text);
            f.char.push({
              id: C,
              page: b.length - 1,
              x: p / a,
              y: m / a,
              width: S,
              height: x,
              xoffset: 0,
              yoffset: 0,
              xadvance:
                r -
                (u.dropShadow ? u.dropShadowDistance : 0) -
                (u.stroke ? u.strokeThickness : 0),
            }),
              (p += (S + 2 * i) * a),
              (p = Math.ceil(p));
          }
          for (let e = 0, t = l.length; e < t; e++) {
            let n = l[e];
            for (let e = 0; e < t; e++) {
              let t = l[e],
                r = g.measureText(n).width,
                i = g.measureText(t).width,
                a = g.measureText(n + t).width - (r + i);
              a && f.kerning.push({ first: Qa(n), second: Qa(t), amount: a });
            }
          }
          let x = new ro(f, b, !0);
          return (
            ro.available[e] !== void 0 && ro.uninstall(e),
            (ro.available[e] = x),
            x
          );
        }
      }),
      (io = ro),
      (io.ALPHA = [[`a`, `z`], [`A`, `Z`], ` `]),
      (io.NUMERIC = [[`0`, `9`]]),
      (io.ALPHANUMERIC = [[`a`, `z`], [`A`, `Z`], [`0`, `9`], ` `]),
      (io.ASCII = [[` `, `~`]]),
      (io.defaultOptions = {
        resolution: 1,
        textureWidth: 512,
        textureHeight: 512,
        padding: 4,
        chars: ro.ALPHANUMERIC,
      }),
      (io.available = {});
  }))();
}
var oo;
function so() {
  return (so = t(() => {
    oo = `// Pixi texture info\r
varying vec2 vTextureCoord;\r
uniform sampler2D uSampler;\r
\r
// Tint\r
uniform vec4 uColor;\r
\r
// on 2D applications fwidth is screenScale / glyphAtlasScale * distanceFieldRange\r
uniform float uFWidth;\r
\r
void main(void) {\r
\r
  // To stack MSDF and SDF we need a non-pre-multiplied-alpha texture.\r
  vec4 texColor = texture2D(uSampler, vTextureCoord);\r
\r
  // MSDF\r
  float median = texColor.r + texColor.g + texColor.b -\r
                  min(texColor.r, min(texColor.g, texColor.b)) -\r
                  max(texColor.r, max(texColor.g, texColor.b));\r
  // SDF\r
  median = min(median, texColor.a);\r
\r
  float screenPxDistance = uFWidth * (median - 0.5);\r
  float alpha = clamp(screenPxDistance + 0.5, 0.0, 1.0);\r
  if (median < 0.01) {\r
    alpha = 0.0;\r
  } else if (median > 0.99) {\r
    alpha = 1.0;\r
  }\r
\r
  // Gamma correction for coverage-like alpha\r
  float luma = dot(uColor.rgb, vec3(0.299, 0.587, 0.114));\r
  float gamma = mix(1.0, 1.0 / 2.2, luma);\r
  float coverage = pow(uColor.a * alpha, gamma);  \r
\r
  // NPM Textures, NPM outputs\r
  gl_FragColor = vec4(uColor.rgb, coverage);\r
}\r
`;
  }))();
}
var co;
function lo() {
  return (lo = t(() => {
    co = `// Mesh material default fragment\r
attribute vec2 aVertexPosition;\r
attribute vec2 aTextureCoord;\r
\r
uniform mat3 projectionMatrix;\r
uniform mat3 translationMatrix;\r
uniform mat3 uTextureMatrix;\r
\r
varying vec2 vTextureCoord;\r
\r
void main(void)\r
{\r
    gl_Position = vec4((projectionMatrix * translationMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);\r
\r
    vTextureCoord = (uTextureMatrix * vec3(aTextureCoord, 1.0)).xy;\r
}\r
`;
  }))();
}
var uo, fo, po, mo, ho;
function go() {
  return (go = t(() => {
    R(),
      N(),
      k(),
      ao(),
      so(),
      lo(),
      no(),
      (uo = []),
      (fo = []),
      (po = []),
      (mo = class extends de {
        constructor(e, t = {}) {
          super();
          let {
            align: n,
            tint: r,
            maxWidth: i,
            letterSpacing: a,
            fontName: o,
            fontSize: s,
          } = Object.assign({}, mo.styleDefaults, t);
          if (!io.available[o]) throw Error(`Missing BitmapFont "${o}"`);
          (this._activePagesMeshData = []),
            (this._textWidth = 0),
            (this._textHeight = 0),
            (this._align = n),
            (this._tintColor = new me(r)),
            (this._font = void 0),
            (this._fontName = o),
            (this._fontSize = s),
            (this.text = e),
            (this._maxWidth = i),
            (this._maxLineHeight = 0),
            (this._letterSpacing = a),
            (this._anchor = new C(
              () => {
                this.dirty = !0;
              },
              this,
              0,
              0
            )),
            (this._roundPixels = A.ROUND_PIXELS),
            (this.dirty = !0),
            (this._resolution = A.RESOLUTION),
            (this._autoResolution = !0),
            (this._textureCache = {});
        }
        updateText() {
          let e = io.available[this._fontName],
            t = this.fontSize,
            n = t / e.size,
            r = new T(),
            i = [],
            a = [],
            o = [],
            s = $a(
              this._text.replace(
                /(?:\r\n|\r)/g,
                `
`
              ) || ` `
            ),
            c = (this._maxWidth * e.size) / t,
            l = e.distanceFieldType === `none` ? uo : fo,
            u = null,
            d = 0,
            f = 0,
            p = 0,
            m = -1,
            h = 0,
            g = 0,
            _ = 0,
            v = 0;
          for (let t = 0; t < s.length; t++) {
            let n = s[t],
              l = Qa(n);
            if (
              (/(?:\s)/.test(n) && ((m = t), (h = d), v++),
              n === `\r` ||
                n ===
                  `
`)
            ) {
              a.push(d),
                o.push(-1),
                (f = Math.max(f, d)),
                ++p,
                ++g,
                (r.x = 0),
                (r.y += e.lineHeight),
                (u = null),
                (v = 0);
              continue;
            }
            let y = e.chars[l];
            if (!y) continue;
            u && y.kerning[u] && (r.x += y.kerning[u]);
            let b = po.pop() || {
              texture: B.EMPTY,
              line: 0,
              charCode: 0,
              prevSpaces: 0,
              position: new T(),
            };
            (b.texture = y.texture),
              (b.line = p),
              (b.charCode = l),
              (b.position.x = Math.round(
                r.x + y.xOffset + this._letterSpacing / 2
              )),
              (b.position.y = Math.round(r.y + y.yOffset)),
              (b.prevSpaces = v),
              i.push(b),
              (d =
                b.position.x +
                Math.max(y.xAdvance - y.xOffset, y.texture.orig.width)),
              (r.x += y.xAdvance + this._letterSpacing),
              (_ = Math.max(_, y.yOffset + y.texture.height)),
              (u = l),
              m !== -1 &&
                c > 0 &&
                r.x > c &&
                (++g,
                xe(i, 1 + m - g, 1 + t - m),
                (t = m),
                (m = -1),
                a.push(h),
                o.push(i.length > 0 ? i[i.length - 1].prevSpaces : 0),
                (f = Math.max(f, h)),
                p++,
                (r.x = 0),
                (r.y += e.lineHeight),
                (u = null),
                (v = 0));
          }
          let y = s[s.length - 1];
          y !== `\r` &&
            y !==
              `
` &&
            (/(?:\s)/.test(y) && (d = h),
            a.push(d),
            (f = Math.max(f, d)),
            o.push(-1));
          let b = [];
          for (let e = 0; e <= p; e++) {
            let t = 0;
            this._align === `right`
              ? (t = f - a[e])
              : this._align === `center`
              ? (t = (f - a[e]) / 2)
              : this._align === `justify` &&
                (t = o[e] < 0 ? 0 : (f - a[e]) / o[e]),
              b.push(t);
          }
          let x = i.length,
            S = {},
            C = [],
            w = this._activePagesMeshData;
          l.push(...w);
          for (let t = 0; t < x; t++) {
            let n = i[t].texture,
              r = n.baseTexture.uid;
            if (!S[r]) {
              let t = l.pop();
              if (!t) {
                let n = new De(),
                  r,
                  i;
                e.distanceFieldType === `none`
                  ? ((r = new D(B.EMPTY)), (i = F.NORMAL))
                  : ((r = new D(B.EMPTY, {
                      program: ue.from(co, oo),
                      uniforms: { uFWidth: 0 },
                    })),
                    (i = F.NORMAL_NPM));
                let a = new Te(n, r);
                (a.blendMode = i),
                  (t = {
                    index: 0,
                    indexCount: 0,
                    vertexCount: 0,
                    uvsCount: 0,
                    total: 0,
                    mesh: a,
                    vertices: null,
                    uvs: null,
                    indices: null,
                  });
              }
              (t.index = 0),
                (t.indexCount = 0),
                (t.vertexCount = 0),
                (t.uvsCount = 0),
                (t.total = 0);
              let { _textureCache: i } = this;
              (i[r] = i[r] || new B(n.baseTexture)),
                (t.mesh.texture = i[r]),
                (t.mesh.tint = this._tintColor.value),
                C.push(t),
                (S[r] = t);
            }
            S[r].total++;
          }
          for (let e = 0; e < w.length; e++)
            C.includes(w[e]) || this.removeChild(w[e].mesh);
          for (let e = 0; e < C.length; e++)
            C[e].mesh.parent !== this && this.addChild(C[e].mesh);
          this._activePagesMeshData = C;
          for (let e in S) {
            let t = S[e],
              n = t.total;
            if (
              !(t.indices?.length > 6 * n) ||
              t.vertices.length < Te.BATCHABLE_SIZE * 2
            )
              (t.vertices = new Float32Array(8 * n)),
                (t.uvs = new Float32Array(8 * n)),
                (t.indices = new Uint16Array(6 * n));
            else {
              let e = t.total,
                n = t.vertices;
              for (let t = e * 4 * 2; t < n.length; t++) n[t] = 0;
            }
            t.mesh.size = 6 * n;
          }
          for (let e = 0; e < x; e++) {
            let t = i[e],
              r =
                t.position.x +
                b[t.line] * (this._align === `justify` ? t.prevSpaces : 1);
            this._roundPixels && (r = Math.round(r));
            let a = r * n,
              o = t.position.y * n,
              s = t.texture,
              c = S[s.baseTexture.uid],
              l = s.frame,
              u = s._uvs,
              d = c.index++;
            (c.indices[d * 6 + 0] = 0 + d * 4),
              (c.indices[d * 6 + 1] = 1 + d * 4),
              (c.indices[d * 6 + 2] = 2 + d * 4),
              (c.indices[d * 6 + 3] = 0 + d * 4),
              (c.indices[d * 6 + 4] = 2 + d * 4),
              (c.indices[d * 6 + 5] = 3 + d * 4),
              (c.vertices[d * 8 + 0] = a),
              (c.vertices[d * 8 + 1] = o),
              (c.vertices[d * 8 + 2] = a + l.width * n),
              (c.vertices[d * 8 + 3] = o),
              (c.vertices[d * 8 + 4] = a + l.width * n),
              (c.vertices[d * 8 + 5] = o + l.height * n),
              (c.vertices[d * 8 + 6] = a),
              (c.vertices[d * 8 + 7] = o + l.height * n),
              (c.uvs[d * 8 + 0] = u.x0),
              (c.uvs[d * 8 + 1] = u.y0),
              (c.uvs[d * 8 + 2] = u.x1),
              (c.uvs[d * 8 + 3] = u.y1),
              (c.uvs[d * 8 + 4] = u.x2),
              (c.uvs[d * 8 + 5] = u.y2),
              (c.uvs[d * 8 + 6] = u.x3),
              (c.uvs[d * 8 + 7] = u.y3);
          }
          (this._textWidth = f * n),
            (this._textHeight = (r.y + e.lineHeight) * n);
          for (let e in S) {
            let t = S[e];
            if (this.anchor.x !== 0 || this.anchor.y !== 0) {
              let e = 0,
                n = this._textWidth * this.anchor.x,
                r = this._textHeight * this.anchor.y;
              for (let i = 0; i < t.total; i++)
                (t.vertices[e++] -= n),
                  (t.vertices[e++] -= r),
                  (t.vertices[e++] -= n),
                  (t.vertices[e++] -= r),
                  (t.vertices[e++] -= n),
                  (t.vertices[e++] -= r),
                  (t.vertices[e++] -= n),
                  (t.vertices[e++] -= r);
            }
            this._maxLineHeight = _ * n;
            let r = t.mesh.geometry.getBuffer(`aVertexPosition`),
              i = t.mesh.geometry.getBuffer(`aTextureCoord`),
              a = t.mesh.geometry.getIndex();
            (r.data = t.vertices),
              (i.data = t.uvs),
              (a.data = t.indices),
              r.update(),
              i.update(),
              a.update();
          }
          for (let e = 0; e < i.length; e++) po.push(i[e]);
          (this._font = e), (this.dirty = !1);
        }
        updateTransform() {
          this.validate(), this.containerUpdateTransform();
        }
        _render(e) {
          this._autoResolution &&
            this._resolution !== e.resolution &&
            ((this._resolution = e.resolution), (this.dirty = !0));
          let {
            distanceFieldRange: t,
            distanceFieldType: n,
            size: r,
          } = io.available[this._fontName];
          if (n !== `none`) {
            let { a: n, b: i, c: a, d: o } = this.worldTransform,
              s = Math.sqrt(n * n + i * i),
              c = Math.sqrt(a * a + o * o),
              l = (Math.abs(s) + Math.abs(c)) / 2,
              u = this.fontSize / r,
              d = e._view.resolution;
            for (let e of this._activePagesMeshData)
              e.mesh.shader.uniforms.uFWidth = l * t * u * d;
          }
          super._render(e);
        }
        getLocalBounds() {
          return this.validate(), super.getLocalBounds();
        }
        validate() {
          let e = io.available[this._fontName];
          if (!e) throw Error(`Missing BitmapFont "${this._fontName}"`);
          this._font !== e && (this.dirty = !0),
            this.dirty && this.updateText();
        }
        get tint() {
          return this._tintColor.value;
        }
        set tint(e) {
          if (this.tint !== e) {
            this._tintColor.setValue(e);
            for (let t = 0; t < this._activePagesMeshData.length; t++)
              this._activePagesMeshData[t].mesh.tint = e;
          }
        }
        get align() {
          return this._align;
        }
        set align(e) {
          this._align !== e && ((this._align = e), (this.dirty = !0));
        }
        get fontName() {
          return this._fontName;
        }
        set fontName(e) {
          if (!io.available[e]) throw Error(`Missing BitmapFont "${e}"`);
          this._fontName !== e && ((this._fontName = e), (this.dirty = !0));
        }
        get fontSize() {
          return this._fontSize ?? io.available[this._fontName].size;
        }
        set fontSize(e) {
          this._fontSize !== e && ((this._fontSize = e), (this.dirty = !0));
        }
        get anchor() {
          return this._anchor;
        }
        set anchor(e) {
          typeof e == `number` ? this._anchor.set(e) : this._anchor.copyFrom(e);
        }
        get text() {
          return this._text;
        }
        set text(e) {
          (e = String(e ?? ``)),
            this._text !== e && ((this._text = e), (this.dirty = !0));
        }
        get maxWidth() {
          return this._maxWidth;
        }
        set maxWidth(e) {
          this._maxWidth !== e && ((this._maxWidth = e), (this.dirty = !0));
        }
        get maxLineHeight() {
          return this.validate(), this._maxLineHeight;
        }
        get textWidth() {
          return this.validate(), this._textWidth;
        }
        get letterSpacing() {
          return this._letterSpacing;
        }
        set letterSpacing(e) {
          this._letterSpacing !== e &&
            ((this._letterSpacing = e), (this.dirty = !0));
        }
        get roundPixels() {
          return this._roundPixels;
        }
        set roundPixels(e) {
          e !== this._roundPixels &&
            ((this._roundPixels = e), (this.dirty = !0));
        }
        get textHeight() {
          return this.validate(), this._textHeight;
        }
        get resolution() {
          return this._resolution;
        }
        set resolution(e) {
          (this._autoResolution = !1),
            this._resolution !== e &&
              ((this._resolution = e), (this.dirty = !0));
        }
        destroy(e) {
          let { _textureCache: t } = this,
            n =
              io.available[this._fontName].distanceFieldType === `none`
                ? uo
                : fo;
          n.push(...this._activePagesMeshData);
          for (let e of this._activePagesMeshData) this.removeChild(e.mesh);
          (this._activePagesMeshData = []),
            n
              .filter((e) => t[e.mesh.texture.baseTexture.uid])
              .forEach((e) => {
                e.mesh.texture = B.EMPTY;
              });
          for (let e in t) t[e].destroy(), delete t[e];
          (this._font = null),
            (this._tintColor = null),
            (this._textureCache = null),
            super.destroy(e);
        }
      }),
      (ho = mo),
      (ho.styleDefaults = {
        align: `left`,
        tint: 16777215,
        maxWidth: 0,
        letterSpacing: 0,
      });
  }))();
}
var _o, vo;
function yo() {
  return (yo = t(() => {
    _i(),
      R(),
      ao(),
      qa(),
      Ba(),
      Wa(),
      (_o = [`.xml`, `.fnt`]),
      (vo = {
        extension: { type: z.LoadParser, priority: ur.Normal },
        name: `loadBitmapFont`,
        test(e) {
          return _o.includes(L.extname(e).toLowerCase());
        },
        async testParse(e) {
          return za.test(e) || Ua.test(e);
        },
        async parse(e, t, n) {
          let r = za.test(e) ? za.parse(e) : Ua.parse(e),
            { src: i } = t,
            { page: a } = r,
            o = [];
          for (let e = 0; e < a.length; ++e) {
            let t = a[e].file,
              n = L.join(L.dirname(i), t);
            (n = Qn(n, i)), o.push(n);
          }
          let s = await n.load(o),
            c = o.map((e) => s[e]);
          return io.install(r, c, !0);
        },
        async load(e, t) {
          return (await A.ADAPTER.fetch(e)).text();
        },
        unload(e) {
          e.destroy();
        },
      }),
      I.add(vo);
  }))();
}
function bo() {
  return (bo = t(() => {
    ao(), go(), qa(), yo(), Wa();
  }))();
}
var xo, So;
function Co() {
  return (Co = t(() => {
    R(),
      Re(),
      (xo = class extends He {
        constructor() {
          super(...arguments),
            (this._fonts = []),
            (this._overrides = []),
            (this._stylesheet = ``),
            (this.fontsDirty = !1);
        }
        static from(e) {
          return new xo(
            Object.keys(xo.defaultOptions).reduce(
              (t, n) => ({ ...t, [n]: e[n] }),
              {}
            )
          );
        }
        cleanFonts() {
          this._fonts.length > 0 &&
            (this._fonts.forEach((e) => {
              URL.revokeObjectURL(e.src),
                e.refs--,
                e.refs === 0 &&
                  (e.fontFace && document.fonts.delete(e.fontFace),
                  delete xo.availableFonts[e.originalUrl]);
            }),
            (this.fontFamily = `Arial`),
            (this._fonts.length = 0),
            this.styleID++,
            (this.fontsDirty = !0));
        }
        loadFont(e, t = {}) {
          let { availableFonts: n } = xo;
          if (n[e]) {
            let t = n[e];
            return (
              this._fonts.push(t),
              t.refs++,
              this.styleID++,
              (this.fontsDirty = !0),
              Promise.resolve()
            );
          }
          return A.ADAPTER.fetch(e)
            .then((e) => e.blob())
            .then(
              async (e) =>
                new Promise((t, n) => {
                  let r = URL.createObjectURL(e),
                    i = new FileReader();
                  (i.onload = () => t([r, i.result])),
                    (i.onerror = n),
                    i.readAsDataURL(e);
                })
            )
            .then(async ([r, i]) => {
              let a = Object.assign(
                {
                  family: L.basename(e, L.extname(e)),
                  weight: `normal`,
                  style: `normal`,
                  src: r,
                  dataSrc: i,
                  refs: 1,
                  originalUrl: e,
                  fontFace: null,
                },
                t
              );
              (n[e] = a), this._fonts.push(a), this.styleID++;
              let o = new FontFace(a.family, `url(${a.src})`, {
                weight: a.weight,
                style: a.style,
              });
              (a.fontFace = o),
                await o.load(),
                document.fonts.add(o),
                await document.fonts.ready,
                this.styleID++,
                (this.fontsDirty = !0);
            });
        }
        addOverride(...e) {
          let t = e.filter((e) => !this._overrides.includes(e));
          t.length > 0 && (this._overrides.push(...t), this.styleID++);
        }
        removeOverride(...e) {
          let t = e.filter((e) => this._overrides.includes(e));
          t.length > 0 &&
            ((this._overrides = this._overrides.filter((e) => !t.includes(e))),
            this.styleID++);
        }
        toCSS(e) {
          return [
            `transform: scale(${e})`,
            `transform-origin: top left`,
            `display: inline-block`,
            `color: ${this.normalizeColor(this.fill)}`,
            `font-size: ${this.fontSize}px`,
            `font-family: ${this.fontFamily}`,
            `font-weight: ${this.fontWeight}`,
            `font-style: ${this.fontStyle}`,
            `font-variant: ${this.fontVariant}`,
            `letter-spacing: ${this.letterSpacing}px`,
            `text-align: ${this.align}`,
            `padding: ${this.padding}px`,
            `white-space: ${this.whiteSpace}`,
            ...(this.lineHeight ? [`line-height: ${this.lineHeight}px`] : []),
            ...(this.wordWrap
              ? [
                  `word-wrap: ${this.breakWords ? `break-all` : `break-word`}`,
                  `max-width: ${this.wordWrapWidth}px`,
                ]
              : []),
            ...(this.strokeThickness
              ? [
                  `-webkit-text-stroke-width: ${this.strokeThickness}px`,
                  `-webkit-text-stroke-color: ${this.normalizeColor(
                    this.stroke
                  )}`,
                  `text-stroke-width: ${this.strokeThickness}px`,
                  `text-stroke-color: ${this.normalizeColor(this.stroke)}`,
                  `paint-order: stroke`,
                ]
              : []),
            ...(this.dropShadow ? [this.dropShadowToCSS()] : []),
            ...this._overrides,
          ].join(`;`);
        }
        toGlobalCSS() {
          return this._fonts.reduce(
            (e, t) => `${e}
            @font-face {
                font-family: "${t.family}";
                src: url('${t.dataSrc}');
                font-weight: ${t.weight};
                font-style: ${t.style}; 
            }`,
            this._stylesheet
          );
        }
        get stylesheet() {
          return this._stylesheet;
        }
        set stylesheet(e) {
          this._stylesheet !== e && ((this._stylesheet = e), this.styleID++);
        }
        normalizeColor(e) {
          return (
            Array.isArray(e) && (e = Ce(e)), typeof e == `number` ? je(e) : e
          );
        }
        dropShadowToCSS() {
          let e = this.normalizeColor(this.dropShadowColor),
            t = this.dropShadowAlpha,
            n = Math.round(
              Math.cos(this.dropShadowAngle) * this.dropShadowDistance
            ),
            r = Math.round(
              Math.sin(this.dropShadowAngle) * this.dropShadowDistance
            );
          e.startsWith(`#`) &&
            t < 1 &&
            (e += ((t * 255) | 0).toString(16).padStart(2, `0`));
          let i = `${n}px ${r}px`;
          return this.dropShadowBlur > 0
            ? `text-shadow: ${i} ${this.dropShadowBlur}px ${e}`
            : `text-shadow: ${i} ${e}`;
        }
        reset() {
          Object.assign(this, xo.defaultOptions);
        }
        onBeforeDraw() {
          let { fontsDirty: e } = this;
          return (
            (this.fontsDirty = !1),
            this.isSafari && this._fonts.length > 0 && e
              ? new Promise((e) => setTimeout(e, 100))
              : Promise.resolve()
          );
        }
        get isSafari() {
          let { userAgent: e } = A.ADAPTER.getNavigator();
          return /^((?!chrome|android).)*safari/i.test(e);
        }
        set fillGradientStops(e) {
          console.warn(
            `[HTMLTextStyle] fillGradientStops is not supported by HTMLText`
          );
        }
        get fillGradientStops() {
          return super.fillGradientStops;
        }
        set fillGradientType(e) {
          console.warn(
            `[HTMLTextStyle] fillGradientType is not supported by HTMLText`
          );
        }
        get fillGradientType() {
          return super.fillGradientType;
        }
        set miterLimit(e) {
          console.warn(
            `[HTMLTextStyle] miterLimit is not supported by HTMLText`
          );
        }
        get miterLimit() {
          return super.miterLimit;
        }
        set trim(e) {
          console.warn(`[HTMLTextStyle] trim is not supported by HTMLText`);
        }
        get trim() {
          return super.trim;
        }
        set textBaseline(e) {
          console.warn(
            `[HTMLTextStyle] textBaseline is not supported by HTMLText`
          );
        }
        get textBaseline() {
          return super.textBaseline;
        }
        set leading(e) {
          console.warn(`[HTMLTextStyle] leading is not supported by HTMLText`);
        }
        get leading() {
          return super.leading;
        }
        set lineJoin(e) {
          console.warn(`[HTMLTextStyle] lineJoin is not supported by HTMLText`);
        }
        get lineJoin() {
          return super.lineJoin;
        }
      }),
      (So = xo),
      (So.availableFonts = {}),
      (So.defaultOptions = {
        align: `left`,
        breakWords: !1,
        dropShadow: !1,
        dropShadowAlpha: 1,
        dropShadowAngle: Math.PI / 6,
        dropShadowBlur: 0,
        dropShadowColor: `black`,
        dropShadowDistance: 5,
        fill: `black`,
        fontFamily: `Arial`,
        fontSize: 26,
        fontStyle: `normal`,
        fontVariant: `normal`,
        fontWeight: `normal`,
        letterSpacing: 0,
        lineHeight: 0,
        padding: 0,
        stroke: `black`,
        strokeThickness: 0,
        whiteSpace: `normal`,
        wordWrap: !1,
        wordWrapWidth: 100,
      });
  }))();
}
var wo, To;
function Eo() {
  return (Eo = t(() => {
    R(),
      Ye(),
      Re(),
      Co(),
      (wo = class extends w {
        constructor(e = ``, t = {}) {
          super(B.EMPTY),
            (this._text = null),
            (this._style = null),
            (this._autoResolution = !0),
            (this._loading = !1),
            (this.localStyleID = -1),
            (this.dirty = !1),
            (this.ownsStyle = !1);
          let n = new Image(),
            r = B.from(n, {
              scaleMode: A.SCALE_MODE,
              resourceOptions: { autoLoad: !1 },
            });
          (r.orig = new ce()), (r.trim = new ce()), (this.texture = r);
          let i = `http://www.w3.org/2000/svg`,
            a = `http://www.w3.org/1999/xhtml`,
            o = document.createElementNS(i, `svg`),
            s = document.createElementNS(i, `foreignObject`),
            c = document.createElementNS(a, `div`),
            l = document.createElementNS(a, `style`);
          s.setAttribute(`width`, `10000`),
            s.setAttribute(`height`, `10000`),
            (s.style.overflow = `hidden`),
            o.appendChild(s),
            (this.maxWidth = wo.defaultMaxWidth),
            (this.maxHeight = wo.defaultMaxHeight),
            (this._domElement = c),
            (this._styleElement = l),
            (this._svgRoot = o),
            (this._foreignObject = s),
            this._foreignObject.appendChild(l),
            this._foreignObject.appendChild(c),
            (this._image = n),
            (this._loadImage = new Image()),
            (this._autoResolution = wo.defaultAutoResolution),
            (this._resolution = wo.defaultResolution ?? A.RESOLUTION),
            (this.text = e),
            (this.style = t);
        }
        measureText(e) {
          let {
            text: t,
            style: n,
            resolution: r,
          } = Object.assign(
            {
              text: this._text,
              style: this._style,
              resolution: this._resolution,
            },
            e
          );
          Object.assign(this._domElement, { innerHTML: t, style: n.toCSS(r) }),
            (this._styleElement.textContent = n.toGlobalCSS()),
            document.body.appendChild(this._svgRoot);
          let i = this._domElement.getBoundingClientRect();
          this._svgRoot.remove();
          let a = Math.min(this.maxWidth, Math.ceil(i.width)),
            o = Math.min(this.maxHeight, Math.ceil(i.height));
          return (
            this._svgRoot.setAttribute(`width`, a.toString()),
            this._svgRoot.setAttribute(`height`, o.toString()),
            t !== this._text && (this._domElement.innerHTML = this._text),
            n !== this._style &&
              (Object.assign(this._domElement, {
                style: this._style?.toCSS(r),
              }),
              (this._styleElement.textContent = this._style?.toGlobalCSS())),
            { width: a + n.padding * 2, height: o + n.padding * 2 }
          );
        }
        async updateText(e = !0) {
          let { style: t, _image: n, _loadImage: r } = this;
          if (
            (this.localStyleID !== t.styleID &&
              ((this.dirty = !0), (this.localStyleID = t.styleID)),
            !this.dirty && e)
          )
            return;
          let { width: i, height: a } = this.measureText();
          (n.width = r.width = Math.ceil(Math.max(1, i))),
            (n.height = r.height = Math.ceil(Math.max(1, a))),
            this._loading ||
              ((this._loading = !0),
              await new Promise((e) => {
                r.onload = async () => {
                  await t.onBeforeDraw(),
                    (this._loading = !1),
                    (n.src = r.src),
                    (r.onload = null),
                    (r.src = ``),
                    this.updateTexture(),
                    e();
                };
                let i = new XMLSerializer().serializeToString(this._svgRoot);
                r.src = `data:image/svg+xml;charset=utf8,${encodeURIComponent(
                  i
                )}`;
              }));
        }
        get source() {
          return this._image;
        }
        updateTexture() {
          let { style: e, texture: t, _image: n, resolution: r } = this,
            { padding: i } = e,
            { baseTexture: a } = t;
          (t.trim.width = t._frame.width = n.width / r),
            (t.trim.height = t._frame.height = n.height / r),
            (t.trim.x = -i),
            (t.trim.y = -i),
            (t.orig.width = t._frame.width - i * 2),
            (t.orig.height = t._frame.height - i * 2),
            this._onTextureUpdate(),
            a.setRealSize(n.width, n.height, r),
            (this.dirty = !1);
        }
        _render(e) {
          this._autoResolution &&
            this._resolution !== e.resolution &&
            ((this._resolution = e.resolution), (this.dirty = !0)),
            this.updateText(!0),
            super._render(e);
        }
        _renderCanvas(e) {
          this._autoResolution &&
            this._resolution !== e.resolution &&
            ((this._resolution = e.resolution), (this.dirty = !0)),
            this.updateText(!0),
            super._renderCanvas(e);
        }
        getLocalBounds(e) {
          return this.updateText(!0), super.getLocalBounds(e);
        }
        _calculateBounds() {
          this.updateText(!0),
            this.calculateVertices(),
            this._bounds.addQuad(this.vertexData);
        }
        _onStyleChange() {
          this.dirty = !0;
        }
        destroy(e) {
          typeof e == `boolean` && (e = { children: e }),
            (e = Object.assign({}, wo.defaultDestroyOptions, e)),
            super.destroy(e),
            this.ownsStyle && this._style?.cleanFonts(),
            (this._style = null),
            this._svgRoot?.remove(),
            (this._svgRoot = null),
            this._domElement?.remove(),
            (this._domElement = null),
            this._foreignObject?.remove(),
            (this._foreignObject = null),
            this._styleElement?.remove(),
            (this._styleElement = null),
            (this._loadImage.src = ``),
            (this._loadImage.onload = null),
            (this._loadImage = null),
            (this._image.src = ``),
            (this._image = null);
        }
        get width() {
          return (
            this.updateText(!0),
            (Math.abs(this.scale.x) * this._image.width) / this.resolution
          );
        }
        set width(e) {
          this.updateText(!0);
          let t = Ue(this.scale.x) || 1;
          (this.scale.x = (t * e) / this._image.width / this.resolution),
            (this._width = e);
        }
        get height() {
          return (
            this.updateText(!0),
            (Math.abs(this.scale.y) * this._image.height) / this.resolution
          );
        }
        set height(e) {
          this.updateText(!0);
          let t = Ue(this.scale.y) || 1;
          (this.scale.y = (t * e) / this._image.height / this.resolution),
            (this._height = e);
        }
        get style() {
          return this._style;
        }
        set style(e) {
          this._style !== e &&
            ((e ||= {}),
            e instanceof So
              ? ((this.ownsStyle = !1), (this._style = e))
              : e instanceof He
              ? (console.warn(
                  `[HTMLText] Cloning TextStyle, if this is not what you want, use HTMLTextStyle`
                ),
                (this.ownsStyle = !0),
                (this._style = So.from(e)))
              : ((this.ownsStyle = !0), (this._style = new So(e))),
            (this.localStyleID = -1),
            (this.dirty = !0));
        }
        get text() {
          return this._text;
        }
        set text(e) {
          (e = String(e === `` || e == null ? ` ` : e)),
            (e = this.sanitiseText(e)),
            this._text !== e && ((this._text = e), (this.dirty = !0));
        }
        get resolution() {
          return this._resolution;
        }
        set resolution(e) {
          (this._autoResolution = !1),
            this._resolution !== e &&
              ((this._resolution = e), (this.dirty = !0));
        }
        sanitiseText(e) {
          return e
            .replace(/<br>/gi, `<br/>`)
            .replace(/<hr>/gi, `<hr/>`)
            .replace(/&nbsp;/gi, `&#160;`);
        }
      }),
      (To = wo),
      (To.defaultDestroyOptions = {
        texture: !0,
        children: !1,
        baseTexture: !0,
      }),
      (To.defaultMaxWidth = 2024),
      (To.defaultMaxHeight = 2024),
      (To.defaultAutoResolution = !0);
  }))();
}
function Do() {
  return (Do = t(() => {
    Eo(), Co();
  }))();
}
function Oo() {
  return (Oo = t(() => {
    at(),
      ot(),
      st(),
      Xt(),
      In(),
      Hn(),
      _i(),
      ya(),
      R(),
      N(),
      Sn(),
      Ta(),
      ft(),
      wt(),
      kt(),
      It(),
      Ut(),
      Jt(),
      re(),
      k(),
      Ke(),
      Se(),
      we(),
      Ye(),
      Oa(),
      Be(),
      Ia(),
      Re(),
      bo(),
      Do();
  }))();
}
var ko = n((e, t) => {
    var n = typeof Reflect == `object` ? Reflect : null,
      r =
        n && typeof n.apply == `function`
          ? n.apply
          : function (e, t, n) {
              return Function.prototype.apply.call(e, t, n);
            },
      i =
        n && typeof n.ownKeys == `function`
          ? n.ownKeys
          : Object.getOwnPropertySymbols
          ? function (e) {
              return Object.getOwnPropertyNames(e).concat(
                Object.getOwnPropertySymbols(e)
              );
            }
          : function (e) {
              return Object.getOwnPropertyNames(e);
            };
    function a(e) {
      console && console.warn && console.warn(e);
    }
    var o =
      Number.isNaN ||
      function (e) {
        return e !== e;
      };
    function s() {
      s.init.call(this);
    }
    (t.exports = s),
      (t.exports.once = y),
      (s.EventEmitter = s),
      (s.prototype._events = void 0),
      (s.prototype._eventsCount = 0),
      (s.prototype._maxListeners = void 0);
    var c = 10;
    function l(e) {
      if (typeof e != `function`)
        throw TypeError(
          `The "listener" argument must be of type Function. Received type ` +
            typeof e
        );
    }
    Object.defineProperty(s, "defaultMaxListeners", {
      enumerable: !0,
      get: function () {
        return c;
      },
      set: function (e) {
        if (typeof e != `number` || e < 0 || o(e))
          throw RangeError(
            `The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ` +
              e +
              `.`
          );
        c = e;
      },
    }),
      (s.init = function () {
        (this._events === void 0 ||
          this._events === Object.getPrototypeOf(this)._events) &&
          ((this._events = Object.create(null)), (this._eventsCount = 0)),
          (this._maxListeners = this._maxListeners || void 0);
      }),
      (s.prototype.setMaxListeners = function (e) {
        if (typeof e != `number` || e < 0 || o(e))
          throw RangeError(
            `The value of "n" is out of range. It must be a non-negative number. Received ` +
              e +
              `.`
          );
        return (this._maxListeners = e), this;
      });
    function u(e) {
      return e._maxListeners === void 0
        ? s.defaultMaxListeners
        : e._maxListeners;
    }
    (s.prototype.getMaxListeners = function () {
      return u(this);
    }),
      (s.prototype.emit = function (e) {
        for (var t = [], n = 1; n < arguments.length; n++) t.push(arguments[n]);
        var i = e === `error`,
          a = this._events;
        if (a !== void 0) i &&= a.error === void 0;
        else if (!i) return !1;
        if (i) {
          var o;
          if ((t.length > 0 && (o = t[0]), o instanceof Error)) throw o;
          var s = Error(`Unhandled error.` + (o ? ` (` + o.message + `)` : ``));
          throw ((s.context = o), s);
        }
        var c = a[e];
        if (c === void 0) return !1;
        if (typeof c == `function`) r(c, this, t);
        else
          for (var l = c.length, u = g(c, l), n = 0; n < l; ++n)
            r(u[n], this, t);
        return !0;
      });
    function d(e, t, n, r) {
      var i, o, s;
      if (
        (l(n),
        (o = e._events),
        o === void 0
          ? ((o = e._events = Object.create(null)), (e._eventsCount = 0))
          : (o.newListener !== void 0 &&
              (e.emit(`newListener`, t, n.listener ? n.listener : n),
              (o = e._events)),
            (s = o[t])),
        s === void 0)
      )
        (s = o[t] = n), ++e._eventsCount;
      else if (
        (typeof s == `function`
          ? (s = o[t] = r ? [n, s] : [s, n])
          : r
          ? s.unshift(n)
          : s.push(n),
        (i = u(e)),
        i > 0 && s.length > i && !s.warned)
      ) {
        s.warned = !0;
        var c = Error(
          `Possible EventEmitter memory leak detected. ` +
            s.length +
            ` ` +
            String(t) +
            ` listeners added. Use emitter.setMaxListeners() to increase limit`
        );
        (c.name = `MaxListenersExceededWarning`),
          (c.emitter = e),
          (c.type = t),
          (c.count = s.length),
          a(c);
      }
      return e;
    }
    (s.prototype.addListener = function (e, t) {
      return d(this, e, t, !1);
    }),
      (s.prototype.on = s.prototype.addListener),
      (s.prototype.prependListener = function (e, t) {
        return d(this, e, t, !0);
      });
    function f() {
      if (!this.fired)
        return (
          this.target.removeListener(this.type, this.wrapFn),
          (this.fired = !0),
          arguments.length === 0
            ? this.listener.call(this.target)
            : this.listener.apply(this.target, arguments)
        );
    }
    function p(e, t, n) {
      var r = { fired: !1, wrapFn: void 0, target: e, type: t, listener: n },
        i = f.bind(r);
      return (i.listener = n), (r.wrapFn = i), i;
    }
    (s.prototype.once = function (e, t) {
      return l(t), this.on(e, p(this, e, t)), this;
    }),
      (s.prototype.prependOnceListener = function (e, t) {
        return l(t), this.prependListener(e, p(this, e, t)), this;
      }),
      (s.prototype.removeListener = function (e, t) {
        var n, r, i, a, o;
        if (
          (l(t), (r = this._events), r === void 0 || ((n = r[e]), n === void 0))
        )
          return this;
        if (n === t || n.listener === t)
          --this._eventsCount === 0
            ? (this._events = Object.create(null))
            : (delete r[e],
              r.removeListener &&
                this.emit(`removeListener`, e, n.listener || t));
        else if (typeof n != `function`) {
          for (i = -1, a = n.length - 1; a >= 0; a--)
            if (n[a] === t || n[a].listener === t) {
              (o = n[a].listener), (i = a);
              break;
            }
          if (i < 0) return this;
          i === 0 ? n.shift() : _(n, i),
            n.length === 1 && (r[e] = n[0]),
            r.removeListener !== void 0 &&
              this.emit(`removeListener`, e, o || t);
        }
        return this;
      }),
      (s.prototype.off = s.prototype.removeListener),
      (s.prototype.removeAllListeners = function (e) {
        var t,
          n = this._events,
          r;
        if (n === void 0) return this;
        if (n.removeListener === void 0)
          return (
            arguments.length === 0
              ? ((this._events = Object.create(null)), (this._eventsCount = 0))
              : n[e] !== void 0 &&
                (--this._eventsCount === 0
                  ? (this._events = Object.create(null))
                  : delete n[e]),
            this
          );
        if (arguments.length === 0) {
          var i = Object.keys(n),
            a;
          for (r = 0; r < i.length; ++r)
            (a = i[r]), a !== `removeListener` && this.removeAllListeners(a);
          return (
            this.removeAllListeners(`removeListener`),
            (this._events = Object.create(null)),
            (this._eventsCount = 0),
            this
          );
        }
        if (((t = n[e]), typeof t == `function`)) this.removeListener(e, t);
        else if (t !== void 0)
          for (r = t.length - 1; r >= 0; r--) this.removeListener(e, t[r]);
        return this;
      });
    function m(e, t, n) {
      var r = e._events;
      if (r === void 0) return [];
      var i = r[t];
      return i === void 0
        ? []
        : typeof i == `function`
        ? n
          ? [i.listener || i]
          : [i]
        : n
        ? v(i)
        : g(i, i.length);
    }
    (s.prototype.listeners = function (e) {
      return m(this, e, !0);
    }),
      (s.prototype.rawListeners = function (e) {
        return m(this, e, !1);
      }),
      (s.listenerCount = function (e, t) {
        return typeof e.listenerCount == `function`
          ? e.listenerCount(t)
          : h.call(e, t);
      }),
      (s.prototype.listenerCount = h);
    function h(e) {
      var t = this._events;
      if (t !== void 0) {
        var n = t[e];
        if (typeof n == `function`) return 1;
        if (n !== void 0) return n.length;
      }
      return 0;
    }
    s.prototype.eventNames = function () {
      return this._eventsCount > 0 ? i(this._events) : [];
    };
    function g(e, t) {
      for (var n = Array(t), r = 0; r < t; ++r) n[r] = e[r];
      return n;
    }
    function _(e, t) {
      for (; t + 1 < e.length; t++) e[t] = e[t + 1];
      e.pop();
    }
    function v(e) {
      for (var t = Array(e.length), n = 0; n < t.length; ++n)
        t[n] = e[n].listener || e[n];
      return t;
    }
    function y(e, t) {
      return new Promise(function (n, r) {
        function i(n) {
          e.removeListener(t, a), r(n);
        }
        function a() {
          typeof e.removeListener == `function` && e.removeListener(`error`, i),
            n([].slice.call(arguments));
        }
        x(e, t, a, { once: !0 }), t !== `error` && b(e, i, { once: !0 });
      });
    }
    function b(e, t, n) {
      typeof e.on == `function` && x(e, `error`, t, n);
    }
    function x(e, t, n, r) {
      if (typeof e.on == `function`) r.once ? e.once(t, n) : e.on(t, n);
      else if (typeof e.addEventListener == `function`)
        e.addEventListener(t, function i(a) {
          r.once && e.removeEventListener(t, i), n(a);
        });
      else
        throw TypeError(
          `The "emitter" argument must be of type EventEmitter. Received type ` +
            typeof e
        );
    }
  }),
  Ao,
  jo,
  Mo;
function No() {
  return (No = t(() => {
    (Ao = ko()),
      (jo = e(c())),
      (Mo = class extends Ao.EventEmitter {
        constructor() {
          super(),
            (this._debugId = ``),
            (this.logType = `game`),
            (this._debugId = (0, jo.default)(`${this.constructor.name}_`));
        }
        addListener(e, t) {
          return t ? super.addListener(e, t) : this;
        }
        removeListener(e, t) {
          return t ? super.removeListener(e, t) : this.removeAllListeners(e);
        }
        removeAllListeners(e) {
          return super.removeAllListeners(e);
        }
        dispatchEvent(e, t) {
          this.emit(e, t);
        }
        logMessage(e) {
          return this.logType === `game`
            ? `[PixiGame ${this._debugId}]: ${e}`
            : `- ${this._debugId}: ${e}`;
        }
        log(e, ...t) {
          ({}.K_DEBUG_PIXI && console.log(this.logMessage(e), ...t));
        }
        warn(e, ...t) {
          ({}.K_DEBUG_PIXI && console.warn(this.logMessage(e), ...t));
        }
      });
  }))();
}
var Po, Fo, Io, Lo, Ro;
function zo() {
  return (zo = t(() => {
    p(),
      Oo(),
      In(),
      R(),
      N(),
      (Po = Pn.prototype),
      (Fo = Po.createTouchHook),
      (Po.createTouchHook = function () {
        Fo.call(this),
          this._hookDiv &&
            ((this._hookDiv.style.position = `fixed`),
            (this._hookDiv.style.top = `0`),
            (this._hookDiv.style.left = `0`),
            (this._hookDiv.style.opacity = `0`));
      }),
      (Io = Po.update),
      (Po.update = function () {
        if ((Io.call(this), !this.isActive)) return;
        let { view: e } = this.renderer;
        e.offsetParent &&
          ((this.div.style.left = `${e.offsetLeft}px`),
          (this.div.style.top = `${e.offsetTop}px`));
      }),
      (Lo = class {
        static {
          this.storedRenderers = [];
        }
        static stats() {
          return {
            pooled: this.storedRenderers.length,
            lost: this.storedRenderers.filter((e) => e.context.isLost).length,
          };
        }
        static hasStoredRenderers() {
          return this.storedRenderers.some((e) => !e.context.isLost);
        }
        static clear() {
          this.storedRenderers.forEach((e) => this.destroyRenderer(e)),
            (this.storedRenderers = []);
        }
        static acquire(e) {
          let t = this.popUsableRenderer();
          if (t) {
            let n = e.width ?? ke.defaultOptions.width,
              r = e.height ?? ke.defaultOptions.height;
            return (
              (t.resolution = e.resolution ?? ke.defaultOptions.resolution),
              t.resize(n, r),
              t.background.init({
                backgroundColor:
                  e.backgroundColor ?? Ge.defaultOptions.backgroundColor,
                backgroundAlpha:
                  e.backgroundAlpha ?? Ge.defaultOptions.backgroundAlpha,
                clearBeforeRender:
                  e.clearBeforeRender ?? Ge.defaultOptions.clearBeforeRender,
              }),
              (t.options.premultipliedAlpha =
                e.premultipliedAlpha ?? Je.defaultOptions.premultipliedAlpha),
              (t.events.renderer = t),
              t.events.init(e),
              t
            );
          }
          {
            let t = e.backgroundAlpha ?? Ge.defaultOptions.backgroundAlpha,
              n = t >= 1 ? 0.99 : t;
            return Ne({ ...e, backgroundAlpha: n });
          }
        }
        static store(e) {
          if (e.context.isLost) {
            this.discardLostRenderer(e, `store`);
            return;
          }
          e.events.setTargetElement(null),
            (e.events.rootBoundary = new fn(null)),
            e.reset();
          try {
            e.view.parentNode?.removeChild(e.view);
          } catch {}
          this.storedRenderers.push(e);
        }
        static destroyRenderer(e) {
          try {
            e.destroy(!0);
          } catch (e) {
            d(
              Error(
                `PixiJS WebGL context lost: pooled renderer destroy failed`
              ),
              { originalError: e },
              `warning`
            );
          }
        }
        static discardLostRenderer(e, t) {
          d(
            Error(`PixiJS WebGL context lost: pooled renderer discarded`),
            { detectedAt: t },
            `error`
          ),
            this.destroyRenderer(e);
        }
        static popUsableRenderer() {
          let e = this.storedRenderers.pop();
          if (e)
            return e.context.isLost
              ? (this.discardLostRenderer(e, `acquire`),
                this.popUsableRenderer())
              : e;
        }
      }),
      (Ro = class e {
        get isReusingContext() {
          return this._isReusingContext;
        }
        static clearCache() {
          Lo.clear();
        }
        static rendererPoolStats() {
          return Lo.stats();
        }
        static {
          this._plugins = [];
        }
        constructor(t) {
          (this.preserveContext = !1),
            (this._isReusingContext = !1),
            (this.stage = new de());
          let n = { forceCanvas: !1, ...t };
          if (
            ((this.preserveContext = n?.preserveContext ?? !1),
            this.preserveContext)
          ) {
            this._isReusingContext = Lo.hasStoredRenderers();
            let e = Lo.acquire(n);
            this.renderer = e;
          } else this.renderer = Ne(n);
          e._plugins.forEach((e) => {
            e.init.call(this, n);
          });
        }
        render() {
          this.renderer.render(this.stage);
        }
        get view() {
          return this.renderer.view;
        }
        get screen() {
          return this.renderer.screen;
        }
        destroy(t, n) {
          let r = e._plugins.slice(0);
          r.reverse(),
            r.forEach((e) => {
              e.destroy.call(this);
            }),
            this.stage.destroy(n),
            (this.stage = null),
            this.preserveContext && this.renderer instanceof ye
              ? Lo.store(this.renderer)
              : this.renderer.destroy(t),
            (this.renderer = null);
        }
      }),
      I.handleByList(z.Application, Ro._plugins);
  }))();
}
var Bo;
function Vo() {
  return (Vo = t(() => {
    Bo = (e) => {};
  }))();
}
function Ho(e, t, n, r) {
  let i = (0, Wo.default)((...r) => (0, Uo.default)(e, t, n), r);
  return (...e) => i(...e)(...e);
}
var Uo, Wo;
function Go() {
  return (Go = t(() => {
    (Uo = e(r())), (Wo = e(l())), o();
  }))();
}
var Ko;
function qo() {
  return (qo = t(() => {
    Ko = class {
      constructor(e, t) {
        (this.howl = e), (this.objectUrl = t);
      }
      get playing() {
        return this.howl.playing();
      }
      get volume() {
        return this.howl.volume();
      }
      set volume(e) {
        this.howl.volume(e);
      }
      get rate() {
        return this.howl.rate();
      }
      set rate(e) {
        this.howl.rate(e);
      }
      play() {
        this.playing || this.howl.play();
      }
      stop() {
        this.howl.stop();
      }
      fade(e, t, n) {
        this.howl.fade(e, t, n);
      }
      destroy() {
        this.howl.unload(),
          (this.objectUrl &&= (URL.revokeObjectURL(this.objectUrl), void 0));
      }
    };
  }))();
}
function Jo() {
  I.add($o);
}
function Yo() {
  I.remove($o);
}
var Xo, Zo, Qo, $o;
function es() {
  return (es = t(() => {
    (Xo = i()),
      Oo(),
      qo(),
      (Zo = async (e) => {
        try {
          return await fetch(e);
        } catch (e) {
          throw Error(`Sound fetch failed: ${String(e)}`);
        }
      }),
      (Qo = async (e) => {
        let t = await Zo(e);
        if (!t.ok) throw Error(`Sound fetch failed with status ${t.status}`);
        return URL.createObjectURL(await t.blob());
      }),
      ($o = {
        extension: z.Asset,
        loader: {
          name: `loadSound`,
          extension: { type: [z.LoadParser], priority: ur.High },
          test(e) {
            if (e.startsWith(`data:audio/mpeg;base64`)) return !0;
            let t = L.extname(e).slice(1);
            return Xo.Howler.codecs(t);
          },
          async load(e, t) {
            if (t.data?.html5 === !0 && t.data?.autoplay === !0)
              return new Ko(new Xo.Howl({ src: e, ...t.data }));
            let n = e.startsWith(`data:`) ? void 0 : await Qo(e),
              r = L.extname(e).slice(1);
            try {
              let i = await new Promise((i, a) => {
                let o = new Xo.Howl({
                  src: n ?? e,
                  ...(n ? { format: [r] } : {}),
                  ...t.data,
                  onload: () => {
                    i(o);
                  },
                  onloaderror: (e, t) =>
                    a(Error(`Sound decode failed: ${String(t)}`)),
                });
              });
              return new Ko(i, n);
            } catch (e) {
              throw (n && URL.revokeObjectURL(n), e);
            }
          },
          unload(e) {
            e.destroy();
          },
        },
      });
  }))();
}
function ts() {
  return (ts = t(() => {
    es(), qo();
  }))();
}
var V;
function ns() {
  return (ns = t(() => {
    V = ((e) => (
      (e[(e.Region = 0)] = `Region`),
      (e[(e.BoundingBox = 1)] = `BoundingBox`),
      (e[(e.Mesh = 2)] = `Mesh`),
      (e[(e.LinkedMesh = 3)] = `LinkedMesh`),
      (e[(e.Path = 4)] = `Path`),
      (e[(e.Point = 5)] = `Point`),
      (e[(e.Clipping = 6)] = `Clipping`),
      e
    ))(V || {});
  }))();
}
var rs;
function is() {
  return (is = t(() => {
    rs = class {
      constructor(e, t = [], n = 0, r = new DataView(e.buffer)) {
        (this.strings = t), (this.index = n), (this.buffer = r);
      }
      readByte() {
        return this.buffer.getInt8(this.index++);
      }
      readUnsignedByte() {
        return this.buffer.getUint8(this.index++);
      }
      readShort() {
        let e = this.buffer.getInt16(this.index);
        return (this.index += 2), e;
      }
      readInt32() {
        let e = this.buffer.getInt32(this.index);
        return (this.index += 4), e;
      }
      readInt(e) {
        let t = this.readByte(),
          n = t & 127;
        return (
          t & 128 &&
            ((t = this.readByte()),
            (n |= (t & 127) << 7),
            t & 128 &&
              ((t = this.readByte()),
              (n |= (t & 127) << 14),
              t & 128 &&
                ((t = this.readByte()),
                (n |= (t & 127) << 21),
                t & 128 && ((t = this.readByte()), (n |= (t & 127) << 28))))),
          e ? n : (n >>> 1) ^ -(n & 1)
        );
      }
      readStringRef() {
        let e = this.readInt(!0);
        return e == 0 ? null : this.strings[e - 1];
      }
      readString() {
        let e = this.readInt(!0);
        switch (e) {
          case 0:
            return null;
          case 1:
            return ``;
        }
        e--;
        let t = ``;
        for (let n = 0; n < e; ) {
          let e = this.readUnsignedByte();
          switch (e >> 4) {
            case 12:
            case 13:
              (t += String.fromCharCode(
                ((e & 31) << 6) | (this.readByte() & 63)
              )),
                (n += 2);
              break;
            case 14:
              (t += String.fromCharCode(
                ((e & 15) << 12) |
                  ((this.readByte() & 63) << 6) |
                  (this.readByte() & 63)
              )),
                (n += 3);
              break;
            default:
              (t += String.fromCharCode(e)), n++;
          }
        }
        return t;
      }
      readFloat() {
        let e = this.buffer.getFloat32(this.index);
        return (this.index += 4), e;
      }
      readBoolean() {
        return this.readByte() != 0;
      }
    };
  }))();
}
var H, as;
function os() {
  return (os = t(() => {
    (H = ((e) => (
      (e[(e.setup = 0)] = `setup`),
      (e[(e.first = 1)] = `first`),
      (e[(e.replace = 2)] = `replace`),
      (e[(e.add = 3)] = `add`),
      e
    ))(H || {})),
      (as = ((e) => (
        (e[(e.mixIn = 0)] = `mixIn`), (e[(e.mixOut = 1)] = `mixOut`), e
      ))(as || {}));
  }))();
}
var ss, cs;
function ls() {
  return (ls = t(() => {
    (ss = ((e) => (
      (e[(e.Fixed = 0)] = `Fixed`), (e[(e.Percent = 1)] = `Percent`), e
    ))(ss || {})),
      (cs = ((e) => (
        (e[(e.Tangent = 0)] = `Tangent`),
        (e[(e.Chain = 1)] = `Chain`),
        (e[(e.ChainScale = 2)] = `ChainScale`),
        e
      ))(cs || {}));
  }))();
}
var us;
function ds() {
  return (ds = t(() => {
    us = ((e) => (
      (e[(e.Normal = 0)] = `Normal`),
      (e[(e.OnlyTranslation = 1)] = `OnlyTranslation`),
      (e[(e.NoRotationOrReflection = 2)] = `NoRotationOrReflection`),
      (e[(e.NoScale = 3)] = `NoScale`),
      (e[(e.NoScaleOrReflection = 4)] = `NoScaleOrReflection`),
      e
    ))(us || {});
  }))();
}
function fs(e) {
  switch (e.toLowerCase()) {
    case `nearest`:
      return ps.Nearest;
    case `linear`:
      return ps.Linear;
    case `mipmap`:
      return ps.MipMap;
    case `mipmapnearestnearest`:
      return ps.MipMapNearestNearest;
    case `mipmaplinearnearest`:
      return ps.MipMapLinearNearest;
    case `mipmapnearestlinear`:
      return ps.MipMapNearestLinear;
    case `mipmaplinearlinear`:
      return ps.MipMapLinearLinear;
    default:
      throw Error(`Unknown texture filter ${e}`);
  }
}
var ps, ms, hs;
function gs() {
  return (gs = t(() => {
    (ps = ((e) => (
      (e[(e.Nearest = 9728)] = `Nearest`),
      (e[(e.Linear = 9729)] = `Linear`),
      (e[(e.MipMap = 9987)] = `MipMap`),
      (e[(e.MipMapNearestNearest = 9984)] = `MipMapNearestNearest`),
      (e[(e.MipMapLinearNearest = 9985)] = `MipMapLinearNearest`),
      (e[(e.MipMapNearestLinear = 9986)] = `MipMapNearestLinear`),
      (e[(e.MipMapLinearLinear = 9987)] = `MipMapLinearLinear`),
      e
    ))(ps || {})),
      (ms = ((e) => (
        (e[(e.MirroredRepeat = 33648)] = `MirroredRepeat`),
        (e[(e.ClampToEdge = 33071)] = `ClampToEdge`),
        (e[(e.Repeat = 10497)] = `Repeat`),
        e
      ))(ms || {})),
      (hs = class {
        constructor() {
          (this.size = null),
            (this.names = null),
            (this.values = null),
            (this.renderObject = null);
        }
        get width() {
          let e = this.texture;
          return e.trim ? e.trim.width : e.orig.width;
        }
        get height() {
          let e = this.texture;
          return e.trim ? e.trim.height : e.orig.height;
        }
        get u() {
          return this.texture._uvs.x0;
        }
        get v() {
          return this.texture._uvs.y0;
        }
        get u2() {
          return this.texture._uvs.x2;
        }
        get v2() {
          return this.texture._uvs.y2;
        }
        get offsetX() {
          let e = this.texture;
          return e.trim ? e.trim.x : 0;
        }
        get offsetY() {
          return this.spineOffsetY;
        }
        get pixiOffsetY() {
          let e = this.texture;
          return e.trim ? e.trim.y : 0;
        }
        get spineOffsetY() {
          let e = this.texture;
          return this.originalHeight - this.height - (e.trim ? e.trim.y : 0);
        }
        get originalWidth() {
          return this.texture.orig.width;
        }
        get originalHeight() {
          return this.texture.orig.height;
        }
        get x() {
          return this.texture.frame.x;
        }
        get y() {
          return this.texture.frame.y;
        }
        get rotate() {
          return this.texture.rotate !== 0;
        }
        get degrees() {
          return (360 - this.texture.rotate * 45) % 360;
        }
      });
  }))();
}
var _s, vs, ys, bs, xs;
function Ss() {
  return (Ss = t(() => {
    R(),
      gs(),
      (_s = class {
        constructor() {
          (this.x = 0),
            (this.y = 0),
            (this.width = 0),
            (this.height = 0),
            (this.offsetX = 0),
            (this.offsetY = 0),
            (this.originalWidth = 0),
            (this.originalHeight = 0),
            (this.rotate = 0),
            (this.index = 0);
        }
      }),
      (vs = class {
        constructor(e, t, n) {
          (this.pages = []),
            (this.regions = []),
            e && this.addSpineAtlas(e, t, n);
        }
        addTexture(e, t) {
          let n = this.pages,
            r = null;
          for (let e = 0; e < n.length; e++)
            if (n[e].baseTexture === t.baseTexture) {
              r = n[e];
              break;
            }
          if (r === null) {
            (r = new bs()), (r.name = `texturePage`);
            let e = t.baseTexture;
            (r.width = e.realWidth),
              (r.height = e.realHeight),
              (r.baseTexture = e),
              (r.minFilter = r.magFilter = ps.Nearest),
              (r.uWrap = ms.ClampToEdge),
              (r.vWrap = ms.ClampToEdge),
              n.push(r);
          }
          let i = new xs();
          return (
            (i.name = e),
            (i.page = r),
            (i.texture = t),
            (i.index = -1),
            this.regions.push(i),
            i
          );
        }
        addTextureHash(e, t) {
          for (let n in e)
            e.hasOwnProperty(n) &&
              this.addTexture(
                t && n.indexOf(`.`) !== -1
                  ? n.substr(0, n.lastIndexOf(`.`))
                  : n,
                e[n]
              );
        }
        addSpineAtlas(e, t, n) {
          return this.load(e, t, n);
        }
        load(e, t, n) {
          if (t == null) throw Error(`textureLoader cannot be null.`);
          let r = new ys(e),
            i = [, , , ,],
            a = null,
            o = {},
            s = null;
          (o.size = () => {
            (a.width = parseInt(i[1])), (a.height = parseInt(i[2]));
          }),
            (o.format = () => {}),
            (o.filter = () => {
              (a.minFilter = fs(i[1])), (a.magFilter = fs(i[2]));
            }),
            (o.repeat = () => {
              i[1].indexOf(`x`) != -1 && (a.uWrap = ms.Repeat),
                i[1].indexOf(`y`) != -1 && (a.vWrap = ms.Repeat);
            }),
            (o.pma = () => {
              a.pma = i[1] == `true`;
            });
          let c = {};
          (c.xy = () => {
            (s.x = parseInt(i[1])), (s.y = parseInt(i[2]));
          }),
            (c.size = () => {
              (s.width = parseInt(i[1])), (s.height = parseInt(i[2]));
            }),
            (c.bounds = () => {
              (s.x = parseInt(i[1])),
                (s.y = parseInt(i[2])),
                (s.width = parseInt(i[3])),
                (s.height = parseInt(i[4]));
            }),
            (c.offset = () => {
              (s.offsetX = parseInt(i[1])), (s.offsetY = parseInt(i[2]));
            }),
            (c.orig = () => {
              (s.originalWidth = parseInt(i[1])),
                (s.originalHeight = parseInt(i[2]));
            }),
            (c.offsets = () => {
              (s.offsetX = parseInt(i[1])),
                (s.offsetY = parseInt(i[2])),
                (s.originalWidth = parseInt(i[3])),
                (s.originalHeight = parseInt(i[4]));
            }),
            (c.rotate = () => {
              let e = i[1],
                t = 0;
              (t =
                e.toLocaleLowerCase() == `true`
                  ? 6
                  : e.toLocaleLowerCase() == `false`
                  ? 0
                  : ((720 - parseFloat(e)) % 360) / 45),
                (s.rotate = t);
            }),
            (c.index = () => {
              s.index = parseInt(i[1]);
            });
          let l = r.readLine();
          for (; l != null && l.trim().length == 0; ) l = r.readLine();
          for (; l != null && l.trim().length != 0 && r.readEntry(i, l) != 0; )
            l = r.readLine();
          let u = () => {
            for (;;) {
              if (l == null) return n && n(this);
              if (l.trim().length == 0) (a = null), (l = r.readLine());
              else if (a === null) {
                for (
                  a = new bs(), a.name = l.trim();
                  r.readEntry(i, (l = r.readLine())) != 0;

                ) {
                  let e = o[i[0]];
                  e && e();
                }
                this.pages.push(a),
                  t(a.name, (e) => {
                    if (e === null)
                      return (
                        this.pages.splice(this.pages.indexOf(a), 1),
                        n && n(null)
                      );
                    (a.baseTexture = e),
                      a.pma && (e.alphaMode = O.PMA),
                      e.valid || e.setSize(a.width, a.height),
                      a.setFilters(),
                      (!a.width || !a.height) &&
                        ((a.width = e.realWidth),
                        (a.height = e.realHeight),
                        (!a.width || !a.height) &&
                          console.log(
                            `ERROR spine atlas page ${a.name}: meshes wont work if you dont specify size in atlas (http://www.html5gamedevs.com/topic/18888-pixi-spines-and-meshes/?p=107121)`
                          )),
                      u();
                  });
                break;
              } else {
                s = new _s();
                let e = new xs();
                (e.name = l), (e.page = a);
                let t = null,
                  n = null;
                for (;;) {
                  let e = r.readEntry(i, (l = r.readLine()));
                  if (e == 0) break;
                  let a = c[i[0]];
                  if (a) a();
                  else {
                    t ?? ((t = []), (n = [])), t.push(i[0]);
                    let r = [];
                    for (let t = 0; t < e; t++) r.push(parseInt(i[t + 1]));
                    n.push(r);
                  }
                }
                s.originalWidth == 0 &&
                  s.originalHeight == 0 &&
                  ((s.originalWidth = s.width), (s.originalHeight = s.height));
                let o = a.baseTexture.resolution;
                (s.x /= o),
                  (s.y /= o),
                  (s.width /= o),
                  (s.height /= o),
                  (s.originalWidth /= o),
                  (s.originalHeight /= o),
                  (s.offsetX /= o),
                  (s.offsetY /= o);
                let u = s.rotate % 4 != 0,
                  d = new ce(
                    s.x,
                    s.y,
                    u ? s.height : s.width,
                    u ? s.width : s.height
                  ),
                  f = new ce(0, 0, s.originalWidth, s.originalHeight),
                  p = new ce(
                    s.offsetX,
                    s.originalHeight - s.height - s.offsetY,
                    s.width,
                    s.height
                  );
                (e.texture = new B(e.page.baseTexture, d, f, p, s.rotate)),
                  (e.index = s.index),
                  e.texture.updateUvs(),
                  this.regions.push(e);
              }
            }
          };
          u();
        }
        findRegion(e) {
          for (let t = 0; t < this.regions.length; t++)
            if (this.regions[t].name == e) return this.regions[t];
          return null;
        }
        dispose() {
          for (let e = 0; e < this.pages.length; e++)
            this.pages[e].baseTexture.dispose();
        }
      }),
      (ys = class {
        constructor(e) {
          (this.index = 0), (this.lines = e.split(/\r\n|\r|\n/));
        }
        readLine() {
          return this.index >= this.lines.length
            ? null
            : this.lines[this.index++];
        }
        readEntry(e, t) {
          if (t == null || ((t = t.trim()), t.length == 0)) return 0;
          let n = t.indexOf(`:`);
          if (n == -1) return 0;
          e[0] = t.substr(0, n).trim();
          for (let r = 1, i = n + 1; ; r++) {
            let n = t.indexOf(`,`, i);
            if (n == -1) return (e[r] = t.substr(i).trim()), r;
            if (((e[r] = t.substr(i, n - i).trim()), (i = n + 1), r == 4))
              return 4;
          }
        }
      }),
      (bs = class {
        constructor() {
          (this.minFilter = ps.Nearest),
            (this.magFilter = ps.Nearest),
            (this.uWrap = ms.ClampToEdge),
            (this.vWrap = ms.ClampToEdge);
        }
        setFilters() {
          let e = this.baseTexture,
            t = this.minFilter;
          t == ps.Linear
            ? (e.scaleMode = j.LINEAR)
            : this.minFilter == ps.Nearest
            ? (e.scaleMode = j.NEAREST)
            : ((e.mipmap = ne.POW2),
              (e.scaleMode =
                t == ps.MipMapNearestNearest ? j.NEAREST : j.LINEAR));
        }
      }),
      (xs = class extends hs {});
  }))();
}
var Cs, ws, U, Ts, W, Es, G, Ds, Os;
function ks() {
  return (ks = t(() => {
    (Cs = class {
      constructor() {
        (this.entries = {}), (this.size = 0);
      }
      add(e) {
        let t = this.entries[e];
        return (this.entries[e] = !0), !t && (this.size++, !0);
      }
      addAll(e) {
        let t = this.size;
        for (let t = 0, n = e.length; t < n; t++) this.add(e[t]);
        return t != this.size;
      }
      contains(e) {
        return this.entries[e];
      }
      clear() {
        (this.entries = {}), (this.size = 0);
      }
    }),
      (ws = class {
        constructor(e = 0, t = 0, n = 0, r = 0) {
          (this.r = e), (this.g = t), (this.b = n), (this.a = r);
        }
        set(e, t, n, r) {
          return (
            (this.r = e), (this.g = t), (this.b = n), (this.a = r), this.clamp()
          );
        }
        setFromColor(e) {
          return (
            (this.r = e.r), (this.g = e.g), (this.b = e.b), (this.a = e.a), this
          );
        }
        setFromString(e) {
          return (
            (e = e.charAt(0) == `#` ? e.substr(1) : e),
            (this.r = parseInt(e.substr(0, 2), 16) / 255),
            (this.g = parseInt(e.substr(2, 2), 16) / 255),
            (this.b = parseInt(e.substr(4, 2), 16) / 255),
            (this.a = e.length == 8 ? parseInt(e.substr(6, 2), 16) / 255 : 1),
            this
          );
        }
        add(e, t, n, r) {
          return (
            (this.r += e),
            (this.g += t),
            (this.b += n),
            (this.a += r),
            this.clamp()
          );
        }
        clamp() {
          return (
            this.r < 0 ? (this.r = 0) : this.r > 1 && (this.r = 1),
            this.g < 0 ? (this.g = 0) : this.g > 1 && (this.g = 1),
            this.b < 0 ? (this.b = 0) : this.b > 1 && (this.b = 1),
            this.a < 0 ? (this.a = 0) : this.a > 1 && (this.a = 1),
            this
          );
        }
        static rgba8888ToColor(e, t) {
          (e.r = ((t & 4278190080) >>> 24) / 255),
            (e.g = ((t & 16711680) >>> 16) / 255),
            (e.b = ((t & 65280) >>> 8) / 255),
            (e.a = (t & 255) / 255);
        }
        static rgb888ToColor(e, t) {
          (e.r = ((t & 16711680) >>> 16) / 255),
            (e.g = ((t & 65280) >>> 8) / 255),
            (e.b = (t & 255) / 255);
        }
        static fromString(e) {
          return new ws().setFromString(e);
        }
      }),
      (U = ws),
      (U.WHITE = new ws(1, 1, 1, 1)),
      (U.RED = new ws(1, 0, 0, 1)),
      (U.GREEN = new ws(0, 1, 0, 1)),
      (U.BLUE = new ws(0, 0, 1, 1)),
      (U.MAGENTA = new ws(1, 0, 1, 1)),
      (Ts = class {
        static clamp(e, t, n) {
          return e < t ? t : e > n ? n : e;
        }
        static cosDeg(e) {
          return Math.cos(e * Ts.degRad);
        }
        static sinDeg(e) {
          return Math.sin(e * Ts.degRad);
        }
        static signum(e) {
          return Math.sign(e);
        }
        static toInt(e) {
          return e > 0 ? Math.floor(e) : Math.ceil(e);
        }
        static cbrt(e) {
          let t = Math.abs(e) ** (1 / 3);
          return e < 0 ? -t : t;
        }
        static randomTriangular(e, t) {
          return Ts.randomTriangularWith(e, t, (e + t) * 0.5);
        }
        static randomTriangularWith(e, t, n) {
          let r = Math.random(),
            i = t - e;
          return r <= (n - e) / i
            ? e + Math.sqrt(r * i * (n - e))
            : t - Math.sqrt((1 - r) * i * (t - n));
        }
        static isPowerOfTwo(e) {
          return e && !(e & (e - 1));
        }
      }),
      (W = Ts),
      (W.PI = 3.1415927),
      (W.PI2 = Ts.PI * 2),
      (W.radiansToDegrees = 180 / Ts.PI),
      (W.radDeg = Ts.radiansToDegrees),
      (W.degreesToRadians = Ts.PI / 180),
      (W.degRad = Ts.degreesToRadians),
      (Es = class {
        static arrayCopy(e, t, n, r, i) {
          for (let a = t, o = r; a < t + i; a++, o++) n[o] = e[a];
        }
        static arrayFill(e, t, n, r) {
          for (let i = t; i < n; i++) e[i] = r;
        }
        static setArraySize(e, t, n = 0) {
          let r = e.length;
          if (r == t) return e;
          if (((e.length = t), r < t)) for (let i = r; i < t; i++) e[i] = n;
          return e;
        }
        static ensureArrayCapacity(e, t, n = 0) {
          return e.length >= t ? e : Es.setArraySize(e, t, n);
        }
        static newArray(e, t) {
          let n = Array(e);
          for (let r = 0; r < e; r++) n[r] = t;
          return n;
        }
        static newFloatArray(e) {
          if (Es.SUPPORTS_TYPED_ARRAYS) return new Float32Array(e);
          let t = Array(e);
          for (let e = 0; e < t.length; e++) t[e] = 0;
          return t;
        }
        static newShortArray(e) {
          if (Es.SUPPORTS_TYPED_ARRAYS) return new Int16Array(e);
          let t = Array(e);
          for (let e = 0; e < t.length; e++) t[e] = 0;
          return t;
        }
        static toFloatArray(e) {
          return Es.SUPPORTS_TYPED_ARRAYS ? new Float32Array(e) : e;
        }
        static toSinglePrecision(e) {
          return Es.SUPPORTS_TYPED_ARRAYS ? Math.fround(e) : e;
        }
        static webkit602BugfixHelper(e, t) {}
        static contains(e, t, n = !0) {
          for (let n = 0; n < e.length; n++) if (e[n] == t) return !0;
          return !1;
        }
        static enumValue(e, t) {
          return e[t[0].toUpperCase() + t.slice(1)];
        }
      }),
      (G = Es),
      (G.SUPPORTS_TYPED_ARRAYS = typeof Float32Array < `u`),
      (Ds = class {
        constructor(e) {
          (this.items = []), (this.instantiator = e);
        }
        obtain() {
          return this.items.length > 0 ? this.items.pop() : this.instantiator();
        }
        free(e) {
          e.reset && e.reset(), this.items.push(e);
        }
        freeAll(e) {
          for (let t = 0; t < e.length; t++) this.free(e[t]);
        }
        clear() {
          this.items.length = 0;
        }
      }),
      (Os = class {
        constructor(e = 0, t = 0) {
          (this.x = e), (this.y = t);
        }
        set(e, t) {
          return (this.x = e), (this.y = t), this;
        }
        length() {
          let e = this.x,
            t = this.y;
          return Math.sqrt(e * e + t * t);
        }
        normalize() {
          let e = this.length();
          return e != 0 && ((this.x /= e), (this.y /= e)), this;
        }
      });
  }))();
}
function As() {
  return (As = t(() => {
    ks();
  }))();
}
var js;
function Ms() {
  return (Ms = t(() => {
    js = {
      yDown: !0,
      FAIL_ON_NON_EXISTING_SKIN: !1,
      GLOBAL_AUTO_UPDATE: !0,
      GLOBAL_DELAY_LIMIT: 0,
    };
  }))();
}
var Ns, Ps, Fs, Is, Ls;
function Rs() {
  return (Rs = t(() => {
    ns(),
      gs(),
      ks(),
      R(),
      N(),
      Ye(),
      Ke(),
      re(),
      Ms(),
      (Ns = [0, 0, 0]),
      (Ps = class extends w {
        constructor() {
          super(...arguments), (this.region = null), (this.attachment = null);
        }
      }),
      (Fs = class extends le {
        constructor(e, t, n, r, i) {
          super(e, t, n, r, i), (this.region = null), (this.attachment = null);
        }
      }),
      (Is = class extends de {
        constructor(e) {
          if ((super(), !e)) throw Error(`The spineData param is required.`);
          if (typeof e == `string`)
            throw Error(
              `spineData param cant be string. Please use spine.Spine.fromAtlas("YOUR_RESOURCE_NAME") from now on.`
            );
          (this.spineData = e),
            this.createSkeleton(e),
            (this.slotContainers = []),
            (this.tempClipContainers = []);
          for (let e = 0, t = this.skeleton.slots.length; e < t; e++) {
            let t = this.skeleton.slots[e],
              n = t.getAttachment(),
              r = this.newContainer();
            if (
              (this.slotContainers.push(r),
              this.addChild(r),
              this.tempClipContainers.push(null),
              n)
            )
              if (n.type === V.Region) {
                let e = n.name,
                  i = this.createSprite(t, n, e);
                (t.currentSprite = i), (t.currentSpriteName = e), r.addChild(i);
              } else if (n.type === V.Mesh) {
                let e = this.createMesh(t, n);
                (t.currentMesh = e),
                  (t.currentMeshId = n.id),
                  (t.currentMeshName = n.name),
                  r.addChild(e);
              } else
                n.type === V.Clipping &&
                  (this.createGraphics(t, n),
                  r.addChild(t.clippingContainer),
                  r.addChild(t.currentGraphics));
          }
          (this.tintRgb = new Float32Array([1, 1, 1])),
            (this.autoUpdate = !0),
            (this.visible = !0);
        }
        get debug() {
          return this._debug;
        }
        set debug(e) {
          e != this._debug &&
            (this._debug?.unregisterSpine(this),
            e?.registerSpine(this),
            (this._debug = e));
        }
        get autoUpdate() {
          return this._autoUpdate;
        }
        set autoUpdate(e) {
          e !== this._autoUpdate &&
            ((this._autoUpdate = e),
            (this.updateTransform = e
              ? Is.prototype.autoUpdateTransform
              : de.prototype.updateTransform));
        }
        get tint() {
          return Ce(this.tintRgb);
        }
        set tint(e) {
          this.tintRgb = Pe(e, this.tintRgb);
        }
        get delayLimit() {
          return (
            (this.localDelayLimit === void 0
              ? js.GLOBAL_DELAY_LIMIT
              : this.localDelayLimit) || Number.MAX_VALUE
          );
        }
        update(e) {
          let t = this.delayLimit;
          if (
            (e > t && (e = t),
            this.state.update(e),
            this.state.apply(this.skeleton),
            !this.skeleton)
          )
            return;
          this.skeleton.updateWorldTransform();
          let n = this.skeleton.slots,
            r = this.color,
            i = null,
            a = null;
          r ? ((i = r.light), (a = r.dark)) : (i = this.tintRgb);
          for (let e = 0, t = n.length; e < t; e++) {
            let t = n[e],
              r = t.getAttachment(),
              o = this.slotContainers[e];
            if (!r) {
              o.visible = !1;
              continue;
            }
            let s = null;
            r.sequence && r.sequence.apply(t, r);
            let c = r.region,
              l = r.color;
            switch (r != null && r.type) {
              case V.Region:
                if (
                  (o.transform.setFromMatrix(t.bone.matrix),
                  (c = r.region),
                  t.currentMesh &&
                    ((t.currentMesh.visible = !1),
                    (t.currentMesh = null),
                    (t.currentMeshId = void 0),
                    (t.currentMeshName = void 0)),
                  !c)
                ) {
                  t.currentSprite && (t.currentSprite.renderable = !1);
                  break;
                }
                if (!t.currentSpriteName || t.currentSpriteName !== r.name) {
                  let e = r.name;
                  if (
                    (t.currentSprite && (t.currentSprite.visible = !1),
                    (t.sprites = t.sprites || {}),
                    t.sprites[e] !== void 0)
                  )
                    t.sprites[e].visible = !0;
                  else {
                    let n = this.createSprite(t, r, e);
                    o.addChild(n);
                  }
                  (t.currentSprite = t.sprites[e]), (t.currentSpriteName = e);
                }
                (t.currentSprite.renderable = !0),
                  t.hackRegion || this.setSpriteRegion(r, t.currentSprite, c),
                  t.currentSprite.color
                    ? (s = t.currentSprite.color)
                    : ((Ns[0] = i[0] * t.color.r * l.r),
                      (Ns[1] = i[1] * t.color.g * l.g),
                      (Ns[2] = i[2] * t.color.b * l.b),
                      (t.currentSprite.tint = Ce(Ns))),
                  (t.currentSprite.blendMode = t.blendMode);
                break;
              case V.Mesh:
                if (t.currentSprite) {
                  (t.currentSprite.visible = !1),
                    (t.currentSprite = null),
                    (t.currentSpriteName = void 0);
                  let e = new ae();
                  (e._parentID = -1),
                    (e._worldID = o.transform._worldID),
                    (o.transform = e);
                }
                if (!c) {
                  t.currentMesh && (t.currentMesh.renderable = !1);
                  break;
                }
                let e = r.id;
                if (t.currentMeshId === void 0 || t.currentMeshId !== e) {
                  let n = e;
                  if (
                    (t.currentMesh && (t.currentMesh.visible = !1),
                    (t.meshes = t.meshes || {}),
                    t.meshes[n] !== void 0)
                  )
                    t.meshes[n].visible = !0;
                  else {
                    let e = this.createMesh(t, r);
                    o.addChild(e);
                  }
                  (t.currentMesh = t.meshes[n]),
                    (t.currentMeshName = r.name),
                    (t.currentMeshId = n);
                }
                (t.currentMesh.renderable = !0),
                  r.computeWorldVerticesOld(t, t.currentMesh.vertices),
                  t.currentMesh.color
                    ? (s = t.currentMesh.color)
                    : ((Ns[0] = i[0] * t.color.r * l.r),
                      (Ns[1] = i[1] * t.color.g * l.g),
                      (Ns[2] = i[2] * t.color.b * l.b),
                      (t.currentMesh.tint = Ce(Ns))),
                  (t.currentMesh.blendMode = t.blendMode),
                  t.hackRegion || this.setMeshRegion(r, t.currentMesh, c);
                break;
              case V.Clipping:
                t.currentGraphics ||
                  (this.createGraphics(t, r),
                  o.addChild(t.clippingContainer),
                  o.addChild(t.currentGraphics)),
                  this.updateGraphics(t, r),
                  (o.alpha = 1),
                  (o.visible = !0);
                continue;
              default:
                o.visible = !1;
                continue;
            }
            if (((o.visible = !0), s)) {
              let e = t.color.r * l.r,
                n = t.color.g * l.g,
                r = t.color.b * l.b;
              s.setLight(
                i[0] * e + a[0] * (1 - e),
                i[1] * n + a[1] * (1 - n),
                i[2] * r + a[2] * (1 - r)
              ),
                t.darkColor
                  ? ((e = t.darkColor.r),
                    (n = t.darkColor.g),
                    (r = t.darkColor.b))
                  : ((e = 0), (n = 0), (r = 0)),
                s.setDark(
                  i[0] * e + a[0] * (1 - e),
                  i[1] * n + a[1] * (1 - n),
                  i[2] * r + a[2] * (1 - r)
                );
            }
            o.alpha = t.color.a;
          }
          let o = this.skeleton.drawOrder,
            s = null,
            c = null;
          for (let e = 0, t = o.length; e < t; e++) {
            let t = n[o[e].data.index],
              r = this.slotContainers[o[e].data.index];
            if (
              (c ||
                (r.parent !== null &&
                  r.parent !== this &&
                  (r.parent.removeChild(r), (r.parent = this))),
              t.currentGraphics && t.getAttachment())
            )
              (c = t.clippingContainer),
                (s = t.getAttachment()),
                (c.children.length = 0),
                (this.children[e] = r),
                s.endSlot === t.data && (s.endSlot = null);
            else if (c) {
              let n = this.tempClipContainers[e];
              n ||
                ((n = this.tempClipContainers[e] = this.newContainer()),
                (n.visible = !1)),
                (this.children[e] = n),
                (r.parent = null),
                c.addChild(r),
                s.endSlot == t.data &&
                  ((c.renderable = !0), (c = null), (s = null));
            } else this.children[e] = r;
          }
          this._debug?.renderDebug(this);
        }
        setSpriteRegion(e, t, n) {
          (t.attachment !== e || t.region !== n) &&
            ((t.region = n),
            (t.attachment = e),
            (t.texture = n.texture),
            (t.rotation = e.rotation * W.degRad),
            (t.position.x = e.x),
            (t.position.y = e.y),
            (t.alpha = e.color.a),
            n.size
              ? ((t.scale.x = n.size.width / n.originalWidth),
                (t.scale.y = -n.size.height / n.originalHeight))
              : ((t.scale.x = (e.scaleX * e.width) / n.originalWidth),
                (t.scale.y = (-e.scaleY * e.height) / n.originalHeight)));
        }
        setMeshRegion(e, t, n) {
          (t.attachment !== e || t.region !== n) &&
            ((t.region = n),
            (t.attachment = e),
            (t.texture = n.texture),
            n.texture.updateUvs(),
            t.uvBuffer.update(e.regionUVs));
        }
        autoUpdateTransform() {
          if (js.GLOBAL_AUTO_UPDATE) {
            this.lastTime = this.lastTime || Date.now();
            let e = (Date.now() - this.lastTime) * 0.001;
            (this.lastTime = Date.now()), this.update(e);
          } else this.lastTime = 0;
          de.prototype.updateTransform.call(this);
        }
        createSprite(e, t, n) {
          let r = t.region;
          e.hackAttachment === t && (r = e.hackRegion);
          let i = r ? r.texture : null,
            a = this.newSprite(i);
          return (
            a.anchor.set(0.5),
            r && this.setSpriteRegion(t, a, t.region),
            (e.sprites = e.sprites || {}),
            (e.sprites[n] = a),
            a
          );
        }
        createMesh(e, t) {
          let n = t.region;
          e.hackAttachment === t &&
            ((n = e.hackRegion),
            (e.hackAttachment = null),
            (e.hackRegion = null));
          let r = this.newMesh(
            n ? n.texture : null,
            new Float32Array(t.regionUVs.length),
            t.regionUVs,
            new Uint16Array(t.triangles),
            S.TRIANGLES
          );
          return (
            r._canvasPadding !== void 0 && (r._canvasPadding = 1.5),
            (r.alpha = t.color.a),
            (r.region = t.region),
            n && this.setMeshRegion(t, r, n),
            (e.meshes = e.meshes || {}),
            (e.meshes[t.id] = r),
            r
          );
        }
        createGraphics(e, t) {
          let n = this.newGraphics(),
            r = new te([]);
          return (
            n.clear(),
            n.beginFill(16777215, 1),
            n.drawPolygon(r),
            (n.renderable = !1),
            (e.currentGraphics = n),
            (e.clippingContainer = this.newContainer()),
            (e.clippingContainer.mask = e.currentGraphics),
            n
          );
        }
        updateGraphics(e, t) {
          let n = e.currentGraphics.geometry,
            r = n.graphicsData[0].shape.points,
            i = t.worldVerticesLength;
          (r.length = i),
            t.computeWorldVertices(e, 0, i, r, 0, 2),
            n.invalidate();
        }
        hackTextureBySlotIndex(e, t = null, n = null) {
          let r = this.skeleton.slots[e];
          if (!r) return !1;
          let i = r.getAttachment(),
            a = i.region;
          return (
            t
              ? ((a = new hs()),
                (a.texture = t),
                (a.size = n),
                (r.hackRegion = a),
                (r.hackAttachment = i))
              : ((r.hackRegion = null), (r.hackAttachment = null)),
            r.currentSprite
              ? this.setSpriteRegion(i, r.currentSprite, a)
              : r.currentMesh && this.setMeshRegion(i, r.currentMesh, a),
            !0
          );
        }
        hackTextureBySlotName(e, t = null, n = null) {
          let r = this.skeleton.findSlotIndex(e);
          return r != -1 && this.hackTextureBySlotIndex(r, t, n);
        }
        hackTextureAttachment(e, t, n, r = null) {
          let i = this.skeleton.findSlotIndex(e),
            a = this.skeleton.getAttachmentByName(e, t);
          a.region.texture = n;
          let o = this.skeleton.slots[i];
          if (!o) return !1;
          let s = o.getAttachment();
          if (t === s.name) {
            let e = a.region;
            return (
              n
                ? ((e = new hs()),
                  (e.texture = n),
                  (e.size = r),
                  (o.hackRegion = e),
                  (o.hackAttachment = s))
                : ((o.hackRegion = null), (o.hackAttachment = null)),
              o.currentSprite && o.currentSprite.region != e
                ? (this.setSpriteRegion(s, o.currentSprite, e),
                  (o.currentSprite.region = e))
                : o.currentMesh &&
                  o.currentMesh.region != e &&
                  this.setMeshRegion(s, o.currentMesh, e),
              !0
            );
          }
          return !1;
        }
        newContainer() {
          return new de();
        }
        newSprite(e) {
          return new Ps(e);
        }
        newGraphics() {
          return new oe();
        }
        newMesh(e, t, n, r, i) {
          return new Fs(e, t, n, r, i);
        }
        transformHack() {
          return 1;
        }
        hackAttachmentGroups(e, t, n) {
          if (!e) return;
          let r = [],
            i = [];
          for (let a = 0, o = this.skeleton.slots.length; a < o; a++) {
            let o = this.skeleton.slots[a],
              s = o.currentSpriteName || o.currentMeshName || ``,
              c = o.currentSprite || o.currentMesh;
            s.endsWith(e)
              ? ((c.parentGroup = t), i.push(c))
              : n && c && ((c.parentGroup = n), r.push(c));
          }
          return [r, i];
        }
        destroy(e) {
          this.debug = null;
          for (let t = 0, n = this.skeleton.slots.length; t < n; t++) {
            let n = this.skeleton.slots[t];
            for (let t in n.meshes) n.meshes[t].destroy(e);
            n.meshes = null;
            for (let t in n.sprites) n.sprites[t].destroy(e);
            n.sprites = null;
          }
          for (let t = 0, n = this.slotContainers.length; t < n; t++)
            this.slotContainers[t].destroy(e);
          (this.spineData = null),
            (this.skeleton = null),
            (this.slotContainers = null),
            (this.stateData = null),
            (this.state = null),
            (this.tempClipContainers = null),
            super.destroy(e);
        }
      }),
      (Ls = Is),
      (Ls.clippingPolygon = []),
      Object.defineProperty(Ls.prototype, "visible", {
        get() {
          return this._visible;
        },
        set(e) {
          e !== this._visible &&
            ((this._visible = e), e && (this.lastTime = 0));
        },
      });
  }))();
}
function zs() {
  return (zs = t(() => {
    N(), re(), As();
  }))();
}
function K() {
  return (K = t(() => {
    ns(), is(), os(), ls(), ds(), Ss(), ks(), As(), Ms(), Rs(), zs();
  }))();
}
var Bs, Vs, Hs;
function Us() {
  return (Us = t(() => {
    K(),
      (Bs = class {
        constructor(e) {
          if (!e) throw Error(`name cannot be null.`);
          this.name = e;
        }
      }),
      (Vs = class extends Bs {
        constructor(e) {
          super(e),
            (this.id = Vs.nextID++),
            (this.bones = null),
            (this.vertices = []),
            (this.worldVerticesLength = 0),
            (this.timelineAttachment = this);
        }
        computeWorldVerticesOld(e, t) {
          this.computeWorldVertices(e, 0, this.worldVerticesLength, t, 0, 2);
        }
        computeWorldVertices(e, t, n, r, i, a) {
          n = i + (n >> 1) * a;
          let o = e.bone.skeleton,
            s = e.deform,
            c = this.vertices,
            l = this.bones;
          if (!l) {
            s.length > 0 && (c = s);
            let o = e.bone.matrix,
              l = o.tx,
              u = o.ty,
              d = o.a,
              f = o.c,
              p = o.b,
              m = o.d;
            for (let e = t, o = i; o < n; e += 2, o += a) {
              let t = c[e],
                n = c[e + 1];
              (r[o] = t * d + n * f + l), (r[o + 1] = t * p + n * m + u);
            }
            return;
          }
          let u = 0,
            d = 0;
          for (let e = 0; e < t; e += 2) {
            let e = l[u];
            (u += e + 1), (d += e);
          }
          let f = o.bones;
          if (s.length == 0)
            for (let e = i, t = d * 3; e < n; e += a) {
              let n = 0,
                i = 0,
                a = l[u++];
              for (a += u; u < a; u++, t += 3) {
                let e = f[l[u]].matrix,
                  r = c[t],
                  a = c[t + 1],
                  o = c[t + 2];
                (n += (r * e.a + a * e.c + e.tx) * o),
                  (i += (r * e.b + a * e.d + e.ty) * o);
              }
              (r[e] = n), (r[e + 1] = i);
            }
          else {
            let e = s;
            for (let t = i, o = d * 3, s = d << 1; t < n; t += a) {
              let n = 0,
                i = 0,
                a = l[u++];
              for (a += u; u < a; u++, o += 3, s += 2) {
                let t = f[l[u]].matrix,
                  r = c[o] + e[s],
                  a = c[o + 1] + e[s + 1],
                  d = c[o + 2];
                (n += (r * t.a + a * t.c + t.tx) * d),
                  (i += (r * t.b + a * t.d + t.ty) * d);
              }
              (r[t] = n), (r[t + 1] = i);
            }
          }
        }
        copyTo(e) {
          this.bones
            ? ((e.bones = Array(this.bones.length)),
              G.arrayCopy(this.bones, 0, e.bones, 0, this.bones.length))
            : (e.bones = null),
            this.vertices &&
              ((e.vertices = G.newFloatArray(this.vertices.length)),
              G.arrayCopy(
                this.vertices,
                0,
                e.vertices,
                0,
                this.vertices.length
              )),
            (e.worldVerticesLength = this.worldVerticesLength),
            (e.timelineAttachment = this.timelineAttachment);
        }
      }),
      (Hs = Vs),
      (Hs.nextID = 0);
  }))();
}
var Ws;
function Gs() {
  return (Gs = t(() => {
    Us(),
      K(),
      (Ws = class e extends Hs {
        constructor(e) {
          super(e),
            (this.type = V.BoundingBox),
            (this.color = new U(1, 1, 1, 1));
        }
        copy() {
          let t = new e(this.name);
          return this.copyTo(t), t.color.setFromColor(this.color), t;
        }
      });
  }))();
}
var Ks;
function qs() {
  return (qs = t(() => {
    Us(),
      K(),
      (Ks = class e extends Hs {
        constructor(e) {
          super(e),
            (this.type = V.Clipping),
            (this.endSlot = null),
            (this.color = new U(0.2275, 0.2275, 0.8078, 1));
        }
        copy() {
          let t = new e(this.name);
          return (
            this.copyTo(t),
            (t.endSlot = this.endSlot),
            t.color.setFromColor(this.color),
            t
          );
        }
      });
  }))();
}
var Js;
function Ys() {
  return (Ys = t(() => {
    Us(),
      K(),
      (Js = class e extends Hs {
        constructor(e, t) {
          super(e),
            (this.type = V.Mesh),
            (this.region = null),
            (this.triangles = []),
            (this.color = new U(1, 1, 1, 1)),
            (this.width = 0),
            (this.height = 0),
            (this.hullLength = 0),
            (this.edges = []),
            (this.parentMesh = null),
            (this.sequence = null),
            (this.tempColor = new U(0, 0, 0, 0)),
            (this.path = t);
        }
        getParentMesh() {
          return this.parentMesh;
        }
        setParentMesh(e) {
          (this.parentMesh = e),
            e &&
              ((this.bones = e.bones),
              (this.vertices = e.vertices),
              (this.worldVerticesLength = e.worldVerticesLength),
              (this.regionUVs = e.regionUVs),
              (this.triangles = e.triangles),
              (this.hullLength = e.hullLength),
              (this.worldVerticesLength = e.worldVerticesLength));
        }
        copy() {
          if (this.parentMesh) return this.newLinkedMesh();
          let t = new e(this.name, this.path);
          return (
            (t.region = this.region),
            t.color.setFromColor(this.color),
            this.copyTo(t),
            (t.regionUVs = new Float32Array(this.regionUVs.length)),
            G.arrayCopy(
              this.regionUVs,
              0,
              t.regionUVs,
              0,
              this.regionUVs.length
            ),
            (t.triangles = Array(this.triangles.length)),
            G.arrayCopy(
              this.triangles,
              0,
              t.triangles,
              0,
              this.triangles.length
            ),
            (t.hullLength = this.hullLength),
            (t.sequence = this.sequence == null ? null : this.sequence.copy()),
            this.edges &&
              ((t.edges = Array(this.edges.length)),
              G.arrayCopy(this.edges, 0, t.edges, 0, this.edges.length)),
            (t.width = this.width),
            (t.height = this.height),
            t
          );
        }
        computeWorldVertices(e, t, n, r, i, a) {
          this.sequence != null && this.sequence.apply(e, this),
            super.computeWorldVertices(e, t, n, r, i, a);
        }
        newLinkedMesh() {
          let t = new e(this.name, this.path);
          return (
            (t.region = this.region),
            t.color.setFromColor(this.color),
            (t.timelineAttachment = this.timelineAttachment),
            t.setParentMesh(this.parentMesh ? this.parentMesh : this),
            t
          );
        }
      });
  }))();
}
var Xs;
function Zs() {
  return (Zs = t(() => {
    Us(),
      K(),
      (Xs = class e extends Hs {
        constructor(e) {
          super(e),
            (this.type = V.Path),
            (this.lengths = []),
            (this.closed = !1),
            (this.constantSpeed = !1),
            (this.color = new U(1, 1, 1, 1));
        }
        copy() {
          let t = new e(this.name);
          return (
            this.copyTo(t),
            (t.lengths = Array(this.lengths.length)),
            G.arrayCopy(this.lengths, 0, t.lengths, 0, this.lengths.length),
            (t.closed = closed),
            (t.constantSpeed = this.constantSpeed),
            t.color.setFromColor(this.color),
            t
          );
        }
      });
  }))();
}
var Qs;
function $s() {
  return ($s = t(() => {
    Us(),
      K(),
      (Qs = class e extends Hs {
        constructor(e) {
          super(e),
            (this.type = V.Point),
            (this.x = 0),
            (this.y = 0),
            (this.rotation = 0),
            (this.color = new U(0.38, 0.94, 0, 1));
        }
        computeWorldPosition(e, t) {
          let n = e.matrix;
          return (
            (t.x = this.x * n.a + this.y * n.c + e.worldX),
            (t.y = this.x * n.b + this.y * n.d + e.worldY),
            t
          );
        }
        computeWorldRotation(e) {
          let t = e.matrix,
            n = W.cosDeg(this.rotation),
            r = W.sinDeg(this.rotation),
            i = n * t.a + r * t.c,
            a = n * t.b + r * t.d;
          return Math.atan2(a, i) * W.radDeg;
        }
        copy() {
          let t = new e(this.name);
          return (
            (t.x = this.x),
            (t.y = this.y),
            (t.rotation = this.rotation),
            t.color.setFromColor(this.color),
            t
          );
        }
      });
  }))();
}
var ec, q;
function tc() {
  return (tc = t(() => {
    Us(),
      K(),
      (ec = class extends Bs {
        constructor(e, t) {
          super(e),
            (this.type = V.Region),
            (this.x = 0),
            (this.y = 0),
            (this.scaleX = 1),
            (this.scaleY = 1),
            (this.rotation = 0),
            (this.width = 0),
            (this.height = 0),
            (this.color = new U(1, 1, 1, 1)),
            (this.rendererObject = null),
            (this.region = null),
            (this.sequence = null),
            (this.offset = G.newFloatArray(8)),
            (this.uvs = G.newFloatArray(8)),
            (this.tempColor = new U(1, 1, 1, 1)),
            (this.path = t);
        }
        updateRegion() {
          if (!this.region) throw Error(`Region not set.`);
          let e = this.region,
            t = (this.width / this.region.originalWidth) * this.scaleX,
            n = (this.height / this.region.originalHeight) * this.scaleY,
            r = (-this.width / 2) * this.scaleX + this.region.offsetX * t,
            i = (-this.height / 2) * this.scaleY + this.region.offsetY * n,
            a = r + this.region.width * t,
            o = i + this.region.height * n,
            s = (this.rotation * Math.PI) / 180,
            c = Math.cos(s),
            l = Math.sin(s),
            u = this.x,
            d = this.y,
            f = r * c + u,
            p = r * l,
            m = i * c + d,
            h = i * l,
            g = a * c + u,
            _ = a * l,
            v = o * c + d,
            y = o * l,
            b = this.offset;
          (b[0] = f - h),
            (b[1] = m + p),
            (b[2] = f - y),
            (b[3] = v + p),
            (b[4] = g - y),
            (b[5] = v + _),
            (b[6] = g - h),
            (b[7] = m + _);
          let x = this.uvs;
          e.degrees == 90
            ? ((x[2] = e.u),
              (x[3] = e.v2),
              (x[4] = e.u),
              (x[5] = e.v),
              (x[6] = e.u2),
              (x[7] = e.v),
              (x[0] = e.u2),
              (x[1] = e.v2))
            : ((x[0] = e.u),
              (x[1] = e.v2),
              (x[2] = e.u),
              (x[3] = e.v),
              (x[4] = e.u2),
              (x[5] = e.v),
              (x[6] = e.u2),
              (x[7] = e.v2));
        }
        computeWorldVertices(e, t, n, r) {
          this.sequence != null && this.sequence.apply(e, this);
          let i = e.bone,
            a = this.offset,
            o = i.matrix,
            s = o.tx,
            c = o.ty,
            l = o.a,
            u = o.c,
            d = o.b,
            f = o.d,
            p = 0,
            m = 0;
          (p = a[0]),
            (m = a[1]),
            (t[n] = p * l + m * u + s),
            (t[n + 1] = p * d + m * f + c),
            (n += r),
            (p = a[2]),
            (m = a[3]),
            (t[n] = p * l + m * u + s),
            (t[n + 1] = p * d + m * f + c),
            (n += r),
            (p = a[4]),
            (m = a[5]),
            (t[n] = p * l + m * u + s),
            (t[n + 1] = p * d + m * f + c),
            (n += r),
            (p = a[6]),
            (m = a[7]),
            (t[n] = p * l + m * u + s),
            (t[n + 1] = p * d + m * f + c);
        }
        copy() {
          let e = new ec(this.name, this.path);
          return (
            (e.region = this.region),
            (e.rendererObject = this.rendererObject),
            (e.x = this.x),
            (e.y = this.y),
            (e.scaleX = this.scaleX),
            (e.scaleY = this.scaleY),
            (e.rotation = this.rotation),
            (e.width = this.width),
            (e.height = this.height),
            G.arrayCopy(this.uvs, 0, e.uvs, 0, 8),
            G.arrayCopy(this.offset, 0, e.offset, 0, 8),
            e.color.setFromColor(this.color),
            (e.sequence = this.sequence == null ? null : this.sequence.copy()),
            e
          );
        }
      }),
      (q = ec),
      (q.X1 = 0),
      (q.Y1 = 1),
      (q.C1R = 2),
      (q.C1G = 3),
      (q.C1B = 4),
      (q.C1A = 5),
      (q.U1 = 6),
      (q.V1 = 7),
      (q.X2 = 8),
      (q.Y2 = 9),
      (q.C2R = 10),
      (q.C2G = 11),
      (q.C2B = 12),
      (q.C2A = 13),
      (q.U2 = 14),
      (q.V2 = 15),
      (q.X3 = 16),
      (q.Y3 = 17),
      (q.C3R = 18),
      (q.C3G = 19),
      (q.C3B = 20),
      (q.C3A = 21),
      (q.U3 = 22),
      (q.V3 = 23),
      (q.X4 = 24),
      (q.Y4 = 25),
      (q.C4R = 26),
      (q.C4G = 27),
      (q.C4B = 28),
      (q.C4A = 29),
      (q.U4 = 30),
      (q.V4 = 31);
  }))();
}
var nc, rc, ic, ac;
function oc() {
  return (oc = t(() => {
    K(),
      (nc = class {
        constructor(e) {
          (this.id = nc.nextID()),
            (this.start = 0),
            (this.digits = 0),
            (this.setupIndex = 0),
            (this.regions = Array(e));
        }
        copy() {
          let e = new nc(this.regions.length);
          return (
            G.arrayCopy(this.regions, 0, e.regions, 0, this.regions.length),
            (e.start = this.start),
            (e.digits = this.digits),
            (e.setupIndex = this.setupIndex),
            e
          );
        }
        apply(e, t) {
          let n = e.sequenceIndex;
          n == -1 && (n = this.setupIndex),
            n >= this.regions.length && (n = this.regions.length - 1);
          let r = this.regions[n];
          t.region != r && (t.region = r);
        }
        getPath(e, t) {
          let n = e,
            r = (this.start + t).toString();
          for (let e = this.digits - r.length; e > 0; e--) n += `0`;
          return (n += r), n;
        }
        static nextID() {
          return nc._nextID++;
        }
      }),
      (rc = nc),
      (rc._nextID = 0),
      (ic = ((e) => (
        (e[(e.hold = 0)] = `hold`),
        (e[(e.once = 1)] = `once`),
        (e[(e.loop = 2)] = `loop`),
        (e[(e.pingpong = 3)] = `pingpong`),
        (e[(e.onceReverse = 4)] = `onceReverse`),
        (e[(e.loopReverse = 5)] = `loopReverse`),
        (e[(e.pingpongReverse = 6)] = `pingpongReverse`),
        e
      ))(ic || {})),
      (ac = [0, 1, 2, 3, 4, 5, 6]);
  }))();
}
var sc,
  J,
  Y,
  cc,
  lc,
  uc,
  dc,
  fc,
  pc,
  mc,
  hc,
  gc,
  _c,
  vc,
  yc,
  bc,
  xc,
  Sc,
  Cc,
  wc,
  Tc,
  Ec,
  Dc,
  Oc,
  kc,
  Ac,
  jc,
  Mc,
  Nc,
  Pc,
  Fc,
  Ic,
  Lc,
  Rc;
function zc() {
  return (zc = t(() => {
    Us(),
      K(),
      tc(),
      oc(),
      (sc = class {
        constructor(e, t, n) {
          if (((this.timelines = []), (this.timelineIds = new Cs()), !e))
            throw Error(`name cannot be null.`);
          (this.name = e), this.setTimelines(t), (this.duration = n);
        }
        setTimelines(e) {
          if (!e) throw Error(`timelines cannot be null.`);
          (this.timelines = e), this.timelineIds.clear();
          for (let t = 0; t < e.length; t++)
            this.timelineIds.addAll(e[t].getPropertyIds());
        }
        hasTimeline(e) {
          for (let t = 0; t < e.length; t++)
            if (this.timelineIds.contains(e[t])) return !0;
          return !1;
        }
        apply(e, t, n, r, i, a, o, s) {
          if (!e) throw Error(`skeleton cannot be null.`);
          r &&
            this.duration != 0 &&
            ((n %= this.duration), t > 0 && (t %= this.duration));
          let c = this.timelines;
          for (let r = 0, l = c.length; r < l; r++)
            c[r].apply(e, t, n, i, a, o, s);
        }
      }),
      (J = {
        rotate: 0,
        x: 1,
        y: 2,
        scaleX: 3,
        scaleY: 4,
        shearX: 5,
        shearY: 6,
        rgb: 7,
        alpha: 8,
        rgb2: 9,
        attachment: 10,
        deform: 11,
        event: 12,
        drawOrder: 13,
        ikConstraint: 14,
        transformConstraint: 15,
        pathConstraintPosition: 16,
        pathConstraintSpacing: 17,
        pathConstraintMix: 18,
        sequence: 19,
      }),
      (Y = class {
        constructor(e, t) {
          (this.propertyIds = t),
            (this.frames = G.newFloatArray(e * this.getFrameEntries()));
        }
        getPropertyIds() {
          return this.propertyIds;
        }
        getFrameEntries() {
          return 1;
        }
        getFrameCount() {
          return this.frames.length / this.getFrameEntries();
        }
        getDuration() {
          return this.frames[this.frames.length - this.getFrameEntries()];
        }
        static search1(e, t) {
          let n = e.length;
          for (let r = 1; r < n; r++) if (e[r] > t) return r - 1;
          return n - 1;
        }
        static search(e, t, n) {
          let r = e.length;
          for (let i = n; i < r; i += n) if (e[i] > t) return i - n;
          return r - n;
        }
      }),
      (cc = class extends Y {
        constructor(e, t, n) {
          super(e, n),
            (this.curves = G.newFloatArray(e + t * 18)),
            (this.curves[e - 1] = 1);
        }
        setLinear(e) {
          this.curves[e] = 0;
        }
        setStepped(e) {
          this.curves[e] = 1;
        }
        shrink(e) {
          let t = this.getFrameCount() + e * 18;
          if (this.curves.length > t) {
            let e = G.newFloatArray(t);
            G.arrayCopy(this.curves, 0, e, 0, t), (this.curves = e);
          }
        }
        setBezier(e, t, n, r, i, a, o, s, c, l, u) {
          let d = this.curves,
            f = this.getFrameCount() + e * 18;
          n == 0 && (d[t] = 2 + f);
          let p = (r - a * 2 + s) * 0.03,
            m = (i - o * 2 + c) * 0.03,
            h = ((a - s) * 3 - r + l) * 0.006,
            g = ((o - c) * 3 - i + u) * 0.006,
            _ = p * 2 + h,
            v = m * 2 + g,
            y = (a - r) * 0.3 + p + h * 0.16666667,
            b = (o - i) * 0.3 + m + g * 0.16666667,
            x = r + y,
            S = i + b;
          for (let e = f + 18; f < e; f += 2)
            (d[f] = x),
              (d[f + 1] = S),
              (y += _),
              (b += v),
              (_ += h),
              (v += g),
              (x += y),
              (S += b);
        }
        getBezierValue(e, t, n, r) {
          let i = this.curves;
          if (i[r] > e) {
            let a = this.frames[t],
              o = this.frames[t + n];
            return o + ((e - a) / (i[r] - a)) * (i[r + 1] - o);
          }
          let a = r + 18;
          for (r += 2; r < a; r += 2)
            if (i[r] >= e) {
              let t = i[r - 2],
                n = i[r - 1];
              return n + ((e - t) / (i[r] - t)) * (i[r + 1] - n);
            }
          t += this.getFrameEntries();
          let o = i[a - 2],
            s = i[a - 1];
          return (
            s + ((e - o) / (this.frames[t] - o)) * (this.frames[t + n] - s)
          );
        }
      }),
      (lc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [n]);
        }
        getFrameEntries() {
          return 2;
        }
        setFrame(e, t, n) {
          (e <<= 1), (this.frames[e] = t), (this.frames[e + 1] = n);
        }
        getCurveValue(e) {
          let t = this.frames,
            n = t.length - 2;
          for (let r = 2; r <= n; r += 2)
            if (t[r] > e) {
              n = r - 2;
              break;
            }
          let r = this.curves[n >> 1];
          switch (r) {
            case 0:
              let r = t[n],
                i = t[n + 1];
              return i + ((e - r) / (t[n + 2] - r)) * (t[n + 2 + 1] - i);
            case 1:
              return t[n + 1];
          }
          return this.getBezierValue(e, n, 1, r - 2);
        }
      }),
      (uc = class extends cc {
        constructor(e, t, n, r) {
          super(e, t, [n, r]);
        }
        getFrameEntries() {
          return 3;
        }
        setFrame(e, t, n, r) {
          (e *= 3),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r);
        }
      }),
      (dc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.rotate}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.rotation = s.data.rotation;
                return;
              case H.first:
                s.rotation += (s.data.rotation - s.rotation) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          switch (a) {
            case H.setup:
              s.rotation = s.data.rotation + c * i;
              break;
            case H.first:
            case H.replace:
              c += s.data.rotation - s.rotation;
            case H.add:
              s.rotation += c * i;
          }
        }
      }),
      (fc = class extends uc {
        constructor(e, t, n) {
          super(e, t, `${J.x}|${n}`, `${J.y}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            switch (a) {
              case H.setup:
                (s.x = s.data.x), (s.y = s.data.y);
                return;
              case H.first:
                (s.x += (s.data.x - s.x) * i), (s.y += (s.data.y - s.y) * i);
            }
            return;
          }
          let l = 0,
            u = 0,
            d = Y.search(c, n, 3),
            f = this.curves[d / 3];
          switch (f) {
            case 0:
              let e = c[d];
              (l = c[d + 1]), (u = c[d + 2]);
              let t = (n - e) / (c[d + 3] - e);
              (l += (c[d + 3 + 1] - l) * t), (u += (c[d + 3 + 2] - u) * t);
              break;
            case 1:
              (l = c[d + 1]), (u = c[d + 2]);
              break;
            default:
              (l = this.getBezierValue(n, d, 1, f - 2)),
                (u = this.getBezierValue(n, d, 2, f + 18 - 2));
          }
          switch (a) {
            case H.setup:
              (s.x = s.data.x + l * i), (s.y = s.data.y + u * i);
              break;
            case H.first:
            case H.replace:
              (s.x += (s.data.x + l - s.x) * i),
                (s.y += (s.data.y + u - s.y) * i);
              break;
            case H.add:
              (s.x += l * i), (s.y += u * i);
          }
        }
      }),
      (pc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.x}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.x = s.data.x;
                return;
              case H.first:
                s.x += (s.data.x - s.x) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          switch (a) {
            case H.setup:
              s.x = s.data.x + c * i;
              break;
            case H.first:
            case H.replace:
              s.x += (s.data.x + c - s.x) * i;
              break;
            case H.add:
              s.x += c * i;
          }
        }
      }),
      (mc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.y}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.y = s.data.y;
                return;
              case H.first:
                s.y += (s.data.y - s.y) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          switch (a) {
            case H.setup:
              s.y = s.data.y + c * i;
              break;
            case H.first:
            case H.replace:
              s.y += (s.data.y + c - s.y) * i;
              break;
            case H.add:
              s.y += c * i;
          }
        }
      }),
      (hc = class extends uc {
        constructor(e, t, n) {
          super(e, t, `${J.scaleX}|${n}`, `${J.scaleY}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            switch (a) {
              case H.setup:
                (s.scaleX = s.data.scaleX), (s.scaleY = s.data.scaleY);
                return;
              case H.first:
                (s.scaleX += (s.data.scaleX - s.scaleX) * i),
                  (s.scaleY += (s.data.scaleY - s.scaleY) * i);
            }
            return;
          }
          let l,
            u,
            d = Y.search(c, n, 3),
            f = this.curves[d / 3];
          switch (f) {
            case 0:
              let e = c[d];
              (l = c[d + 1]), (u = c[d + 2]);
              let t = (n - e) / (c[d + 3] - e);
              (l += (c[d + 3 + 1] - l) * t), (u += (c[d + 3 + 2] - u) * t);
              break;
            case 1:
              (l = c[d + 1]), (u = c[d + 2]);
              break;
            default:
              (l = this.getBezierValue(n, d, 1, f - 2)),
                (u = this.getBezierValue(n, d, 2, f + 18 - 2));
          }
          if (((l *= s.data.scaleX), (u *= s.data.scaleY), i == 1))
            a == H.add
              ? ((s.scaleX += l - s.data.scaleX),
                (s.scaleY += u - s.data.scaleY))
              : ((s.scaleX = l), (s.scaleY = u));
          else {
            let e = 0,
              t = 0;
            if (o == as.mixOut)
              switch (a) {
                case H.setup:
                  (e = s.data.scaleX),
                    (t = s.data.scaleY),
                    (s.scaleX = e + (Math.abs(l) * W.signum(e) - e) * i),
                    (s.scaleY = t + (Math.abs(u) * W.signum(t) - t) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = s.scaleX),
                    (t = s.scaleY),
                    (s.scaleX = e + (Math.abs(l) * W.signum(e) - e) * i),
                    (s.scaleY = t + (Math.abs(u) * W.signum(t) - t) * i);
                  break;
                case H.add:
                  (s.scaleX += (l - s.data.scaleX) * i),
                    (s.scaleY += (u - s.data.scaleY) * i);
              }
            else
              switch (a) {
                case H.setup:
                  (e = Math.abs(s.data.scaleX) * W.signum(l)),
                    (t = Math.abs(s.data.scaleY) * W.signum(u)),
                    (s.scaleX = e + (l - e) * i),
                    (s.scaleY = t + (u - t) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = Math.abs(s.scaleX) * W.signum(l)),
                    (t = Math.abs(s.scaleY) * W.signum(u)),
                    (s.scaleX = e + (l - e) * i),
                    (s.scaleY = t + (u - t) * i);
                  break;
                case H.add:
                  (s.scaleX += (l - s.data.scaleX) * i),
                    (s.scaleY += (u - s.data.scaleY) * i);
              }
          }
        }
      }),
      (gc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.scaleX}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.scaleX = s.data.scaleX;
                return;
              case H.first:
                s.scaleX += (s.data.scaleX - s.scaleX) * i;
            }
            return;
          }
          let c = this.getCurveValue(n) * s.data.scaleX;
          if (i == 1)
            a == H.add ? (s.scaleX += c - s.data.scaleX) : (s.scaleX = c);
          else {
            let e = 0;
            if (o == as.mixOut)
              switch (a) {
                case H.setup:
                  (e = s.data.scaleX),
                    (s.scaleX = e + (Math.abs(c) * W.signum(e) - e) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = s.scaleX),
                    (s.scaleX = e + (Math.abs(c) * W.signum(e) - e) * i);
                  break;
                case H.add:
                  s.scaleX += (c - s.data.scaleX) * i;
              }
            else
              switch (a) {
                case H.setup:
                  (e = Math.abs(s.data.scaleX) * W.signum(c)),
                    (s.scaleX = e + (c - e) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = Math.abs(s.scaleX) * W.signum(c)),
                    (s.scaleX = e + (c - e) * i);
                  break;
                case H.add:
                  s.scaleX += (c - s.data.scaleX) * i;
              }
          }
        }
      }),
      (_c = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.scaleY}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.scaleY = s.data.scaleY;
                return;
              case H.first:
                s.scaleY += (s.data.scaleY - s.scaleY) * i;
            }
            return;
          }
          let c = this.getCurveValue(n) * s.data.scaleY;
          if (i == 1)
            a == H.add ? (s.scaleY += c - s.data.scaleY) : (s.scaleY = c);
          else {
            let e = 0;
            if (o == as.mixOut)
              switch (a) {
                case H.setup:
                  (e = s.data.scaleY),
                    (s.scaleY = e + (Math.abs(c) * W.signum(e) - e) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = s.scaleY),
                    (s.scaleY = e + (Math.abs(c) * W.signum(e) - e) * i);
                  break;
                case H.add:
                  s.scaleY += (c - s.data.scaleY) * i;
              }
            else
              switch (a) {
                case H.setup:
                  (e = Math.abs(s.data.scaleY) * W.signum(c)),
                    (s.scaleY = e + (c - e) * i);
                  break;
                case H.first:
                case H.replace:
                  (e = Math.abs(s.scaleY) * W.signum(c)),
                    (s.scaleY = e + (c - e) * i);
                  break;
                case H.add:
                  s.scaleY += (c - s.data.scaleY) * i;
              }
          }
        }
      }),
      (vc = class extends uc {
        constructor(e, t, n) {
          super(e, t, `${J.shearX}|${n}`, `${J.shearY}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            switch (a) {
              case H.setup:
                (s.shearX = s.data.shearX), (s.shearY = s.data.shearY);
                return;
              case H.first:
                (s.shearX += (s.data.shearX - s.shearX) * i),
                  (s.shearY += (s.data.shearY - s.shearY) * i);
            }
            return;
          }
          let l = 0,
            u = 0,
            d = Y.search(c, n, 3),
            f = this.curves[d / 3];
          switch (f) {
            case 0:
              let e = c[d];
              (l = c[d + 1]), (u = c[d + 2]);
              let t = (n - e) / (c[d + 3] - e);
              (l += (c[d + 3 + 1] - l) * t), (u += (c[d + 3 + 2] - u) * t);
              break;
            case 1:
              (l = c[d + 1]), (u = c[d + 2]);
              break;
            default:
              (l = this.getBezierValue(n, d, 1, f - 2)),
                (u = this.getBezierValue(n, d, 2, f + 18 - 2));
          }
          switch (a) {
            case H.setup:
              (s.shearX = s.data.shearX + l * i),
                (s.shearY = s.data.shearY + u * i);
              break;
            case H.first:
            case H.replace:
              (s.shearX += (s.data.shearX + l - s.shearX) * i),
                (s.shearY += (s.data.shearY + u - s.shearY) * i);
              break;
            case H.add:
              (s.shearX += l * i), (s.shearY += u * i);
          }
        }
      }),
      (yc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.shearX}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.shearX = s.data.shearX;
                return;
              case H.first:
                s.shearX += (s.data.shearX - s.shearX) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          switch (a) {
            case H.setup:
              s.shearX = s.data.shearX + c * i;
              break;
            case H.first:
            case H.replace:
              s.shearX += (s.data.shearX + c - s.shearX) * i;
              break;
            case H.add:
              s.shearX += c * i;
          }
        }
      }),
      (bc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.shearY}|${n}`),
            (this.boneIndex = 0),
            (this.boneIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.bones[this.boneIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.shearY = s.data.shearY;
                return;
              case H.first:
                s.shearY += (s.data.shearY - s.shearY) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          switch (a) {
            case H.setup:
              s.shearY = s.data.shearY + c * i;
              break;
            case H.first:
            case H.replace:
              s.shearY += (s.data.shearY + c - s.shearY) * i;
              break;
            case H.add:
              s.shearY += c * i;
          }
        }
      }),
      (xc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.rgb}|${n}`, `${J.alpha}|${n}`]),
            (this.slotIndex = 0),
            (this.slotIndex = n);
        }
        getFrameEntries() {
          return 5;
        }
        setFrame(e, t, n, r, i, a) {
          (e *= 5),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r),
            (this.frames[e + 3] = i),
            (this.frames[e + 4] = a);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = this.frames,
            l = s.color;
          if (n < c[0]) {
            let e = s.data.color;
            switch (a) {
              case H.setup:
                l.setFromColor(e);
                return;
              case H.first:
                l.add(
                  (e.r - l.r) * i,
                  (e.g - l.g) * i,
                  (e.b - l.b) * i,
                  (e.a - l.a) * i
                );
            }
            return;
          }
          let u = 0,
            d = 0,
            f = 0,
            p = 0,
            m = Y.search(c, n, 5),
            h = this.curves[m / 5];
          switch (h) {
            case 0:
              let e = c[m];
              (u = c[m + 1]), (d = c[m + 2]), (f = c[m + 3]), (p = c[m + 4]);
              let t = (n - e) / (c[m + 5] - e);
              (u += (c[m + 5 + 1] - u) * t),
                (d += (c[m + 5 + 2] - d) * t),
                (f += (c[m + 5 + 3] - f) * t),
                (p += (c[m + 5 + 4] - p) * t);
              break;
            case 1:
              (u = c[m + 1]), (d = c[m + 2]), (f = c[m + 3]), (p = c[m + 4]);
              break;
            default:
              (u = this.getBezierValue(n, m, 1, h - 2)),
                (d = this.getBezierValue(n, m, 2, h + 18 - 2)),
                (f = this.getBezierValue(n, m, 3, h + 36 - 2)),
                (p = this.getBezierValue(n, m, 4, h + 54 - 2));
          }
          i == 1
            ? l.set(u, d, f, p)
            : (a == H.setup && l.setFromColor(s.data.color),
              l.add(
                (u - l.r) * i,
                (d - l.g) * i,
                (f - l.b) * i,
                (p - l.a) * i
              ));
        }
      }),
      (Sc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.rgb}|${n}`]),
            (this.slotIndex = 0),
            (this.slotIndex = n);
        }
        getFrameEntries() {
          return 4;
        }
        setFrame(e, t, n, r, i) {
          (e <<= 2),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r),
            (this.frames[e + 3] = i);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = this.frames,
            l = s.color;
          if (n < c[0]) {
            let e = s.data.color;
            switch (a) {
              case H.setup:
                (l.r = e.r), (l.g = e.g), (l.b = e.b);
                return;
              case H.first:
                (l.r += (e.r - l.r) * i),
                  (l.g += (e.g - l.g) * i),
                  (l.b += (e.b - l.b) * i);
            }
            return;
          }
          let u = 0,
            d = 0,
            f = 0,
            p = Y.search(c, n, 4),
            m = this.curves[p >> 2];
          switch (m) {
            case 0:
              let e = c[p];
              (u = c[p + 1]), (d = c[p + 2]), (f = c[p + 3]);
              let t = (n - e) / (c[p + 4] - e);
              (u += (c[p + 4 + 1] - u) * t),
                (d += (c[p + 4 + 2] - d) * t),
                (f += (c[p + 4 + 3] - f) * t);
              break;
            case 1:
              (u = c[p + 1]), (d = c[p + 2]), (f = c[p + 3]);
              break;
            default:
              (u = this.getBezierValue(n, p, 1, m - 2)),
                (d = this.getBezierValue(n, p, 2, m + 18 - 2)),
                (f = this.getBezierValue(n, p, 3, m + 36 - 2));
          }
          if (i == 1) (l.r = u), (l.g = d), (l.b = f);
          else {
            if (a == H.setup) {
              let e = s.data.color;
              (l.r = e.r), (l.g = e.g), (l.b = e.b);
            }
            (l.r += (u - l.r) * i),
              (l.g += (d - l.g) * i),
              (l.b += (f - l.b) * i);
          }
        }
      }),
      (Cc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.alpha}|${n}`),
            (this.slotIndex = 0),
            (this.slotIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = s.color;
          if (n < this.frames[0]) {
            let e = s.data.color;
            switch (a) {
              case H.setup:
                c.a = e.a;
                return;
              case H.first:
                c.a += (e.a - c.a) * i;
            }
            return;
          }
          let l = this.getCurveValue(n);
          i == 1
            ? (c.a = l)
            : (a == H.setup && (c.a = s.data.color.a), (c.a += (l - c.a) * i));
        }
      }),
      (wc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.rgb}|${n}`, `${J.alpha}|${n}`, `${J.rgb2}|${n}`]),
            (this.slotIndex = 0),
            (this.slotIndex = n);
        }
        getFrameEntries() {
          return 8;
        }
        setFrame(e, t, n, r, i, a, o, s, c) {
          (e <<= 3),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r),
            (this.frames[e + 3] = i),
            (this.frames[e + 4] = a),
            (this.frames[e + 5] = o),
            (this.frames[e + 6] = s),
            (this.frames[e + 7] = c);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = this.frames,
            l = s.color,
            u = s.darkColor;
          if (n < c[0]) {
            let e = s.data.color,
              t = s.data.darkColor;
            switch (a) {
              case H.setup:
                l.setFromColor(e), (u.r = t.r), (u.g = t.g), (u.b = t.b);
                return;
              case H.first:
                l.add(
                  (e.r - l.r) * i,
                  (e.g - l.g) * i,
                  (e.b - l.b) * i,
                  (e.a - l.a) * i
                ),
                  (u.r += (t.r - u.r) * i),
                  (u.g += (t.g - u.g) * i),
                  (u.b += (t.b - u.b) * i);
            }
            return;
          }
          let d = 0,
            f = 0,
            p = 0,
            m = 0,
            h = 0,
            g = 0,
            _ = 0,
            v = Y.search(c, n, 8),
            y = this.curves[v >> 3];
          switch (y) {
            case 0:
              let e = c[v];
              (d = c[v + 1]),
                (f = c[v + 2]),
                (p = c[v + 3]),
                (m = c[v + 4]),
                (h = c[v + 5]),
                (g = c[v + 6]),
                (_ = c[v + 7]);
              let t = (n - e) / (c[v + 8] - e);
              (d += (c[v + 8 + 1] - d) * t),
                (f += (c[v + 8 + 2] - f) * t),
                (p += (c[v + 8 + 3] - p) * t),
                (m += (c[v + 8 + 4] - m) * t),
                (h += (c[v + 8 + 5] - h) * t),
                (g += (c[v + 8 + 6] - g) * t),
                (_ += (c[v + 8 + 7] - _) * t);
              break;
            case 1:
              (d = c[v + 1]),
                (f = c[v + 2]),
                (p = c[v + 3]),
                (m = c[v + 4]),
                (h = c[v + 5]),
                (g = c[v + 6]),
                (_ = c[v + 7]);
              break;
            default:
              (d = this.getBezierValue(n, v, 1, y - 2)),
                (f = this.getBezierValue(n, v, 2, y + 18 - 2)),
                (p = this.getBezierValue(n, v, 3, y + 36 - 2)),
                (m = this.getBezierValue(n, v, 4, y + 54 - 2)),
                (h = this.getBezierValue(n, v, 5, y + 72 - 2)),
                (g = this.getBezierValue(n, v, 6, y + 90 - 2)),
                (_ = this.getBezierValue(n, v, 7, y + 108 - 2));
          }
          if (i == 1) l.set(d, f, p, m), (u.r = h), (u.g = g), (u.b = _);
          else {
            if (a == H.setup) {
              l.setFromColor(s.data.color);
              let e = s.data.darkColor;
              (u.r = e.r), (u.g = e.g), (u.b = e.b);
            }
            l.add((d - l.r) * i, (f - l.g) * i, (p - l.b) * i, (m - l.a) * i),
              (u.r += (h - u.r) * i),
              (u.g += (g - u.g) * i),
              (u.b += (_ - u.b) * i);
          }
        }
      }),
      (Tc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.rgb}|${n}`, `${J.rgb2}|${n}`]),
            (this.slotIndex = 0),
            (this.slotIndex = n);
        }
        getFrameEntries() {
          return 7;
        }
        setFrame(e, t, n, r, i, a, o, s) {
          (e *= 7),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r),
            (this.frames[e + 3] = i),
            (this.frames[e + 4] = a),
            (this.frames[e + 5] = o),
            (this.frames[e + 6] = s);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = this.frames,
            l = s.color,
            u = s.darkColor;
          if (n < c[0]) {
            let e = s.data.color,
              t = s.data.darkColor;
            switch (a) {
              case H.setup:
                (l.r = e.r),
                  (l.g = e.g),
                  (l.b = e.b),
                  (u.r = t.r),
                  (u.g = t.g),
                  (u.b = t.b);
                return;
              case H.first:
                (l.r += (e.r - l.r) * i),
                  (l.g += (e.g - l.g) * i),
                  (l.b += (e.b - l.b) * i),
                  (u.r += (t.r - u.r) * i),
                  (u.g += (t.g - u.g) * i),
                  (u.b += (t.b - u.b) * i);
            }
            return;
          }
          let d = 0,
            f = 0,
            p = 0,
            m = 0,
            h = 0,
            g = 0,
            _ = Y.search(c, n, 7),
            v = this.curves[_ / 7];
          switch (v) {
            case 0:
              let e = c[_];
              (d = c[_ + 1]),
                (f = c[_ + 2]),
                (p = c[_ + 3]),
                (m = c[_ + 4]),
                (h = c[_ + 5]),
                (g = c[_ + 6]);
              let t = (n - e) / (c[_ + 7] - e);
              (d += (c[_ + 7 + 1] - d) * t),
                (f += (c[_ + 7 + 2] - f) * t),
                (p += (c[_ + 7 + 3] - p) * t),
                (m += (c[_ + 7 + 4] - m) * t),
                (h += (c[_ + 7 + 5] - h) * t),
                (g += (c[_ + 7 + 6] - g) * t);
              break;
            case 1:
              (d = c[_ + 1]),
                (f = c[_ + 2]),
                (p = c[_ + 3]),
                (m = c[_ + 4]),
                (h = c[_ + 5]),
                (g = c[_ + 6]);
              break;
            default:
              (d = this.getBezierValue(n, _, 1, v - 2)),
                (f = this.getBezierValue(n, _, 2, v + 18 - 2)),
                (p = this.getBezierValue(n, _, 3, v + 36 - 2)),
                (m = this.getBezierValue(n, _, 4, v + 54 - 2)),
                (h = this.getBezierValue(n, _, 5, v + 72 - 2)),
                (g = this.getBezierValue(n, _, 6, v + 90 - 2));
          }
          if (i == 1)
            (l.r = d), (l.g = f), (l.b = p), (u.r = m), (u.g = h), (u.b = g);
          else {
            if (a == H.setup) {
              let e = s.data.color,
                t = s.data.darkColor;
              (l.r = e.r),
                (l.g = e.g),
                (l.b = e.b),
                (u.r = t.r),
                (u.g = t.g),
                (u.b = t.b);
            }
            (l.r += (d - l.r) * i),
              (l.g += (f - l.g) * i),
              (l.b += (p - l.b) * i),
              (u.r += (m - u.r) * i),
              (u.g += (h - u.g) * i),
              (u.b += (g - u.b) * i);
          }
        }
      }),
      (Ec = class extends Y {
        constructor(e, t) {
          super(e, [`${J.attachment}|${t}`]),
            (this.slotIndex = 0),
            (this.slotIndex = t),
            (this.attachmentNames = Array(e));
        }
        getFrameCount() {
          return this.frames.length;
        }
        setFrame(e, t, n) {
          (this.frames[e] = t), (this.attachmentNames[e] = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (s.bone.active) {
            if (o == as.mixOut) {
              a == H.setup && this.setAttachment(e, s, s.data.attachmentName);
              return;
            }
            if (n < this.frames[0]) {
              (a == H.setup || a == H.first) &&
                this.setAttachment(e, s, s.data.attachmentName);
              return;
            }
            this.setAttachment(
              e,
              s,
              this.attachmentNames[Y.search1(this.frames, n)]
            );
          }
        }
        setAttachment(e, t, n) {
          t.setAttachment(n ? e.getAttachment(this.slotIndex, n) : null);
        }
      }),
      (Dc = class extends cc {
        constructor(e, t, n, r) {
          super(e, t, [`${J.deform}|${n}|${r.id}`]),
            (this.slotIndex = 0),
            (this.slotIndex = n),
            (this.attachment = r),
            (this.vertices = Array(e));
        }
        getFrameCount() {
          return this.frames.length;
        }
        setFrame(e, t, n) {
          (this.frames[e] = t), (this.vertices[e] = n);
        }
        setBezier(e, t, n, r, i, a, o, s, c, l, u) {
          let d = this.curves,
            f = this.getFrameCount() + e * 18;
          n == 0 && (d[t] = 2 + f);
          let p = (r - a * 2 + s) * 0.03,
            m = c * 0.03 - o * 0.06,
            h = ((a - s) * 3 - r + l) * 0.006,
            g = (o - c + 0.33333333) * 0.018,
            _ = p * 2 + h,
            v = m * 2 + g,
            y = (a - r) * 0.3 + p + h * 0.16666667,
            b = o * 0.3 + m + g * 0.16666667,
            x = r + y,
            S = b;
          for (let e = f + 18; f < e; f += 2)
            (d[f] = x),
              (d[f + 1] = S),
              (y += _),
              (b += v),
              (_ += h),
              (v += g),
              (x += y),
              (S += b);
        }
        getCurvePercent(e, t) {
          let n = this.curves,
            r = n[t];
          switch (r) {
            case 0:
              let n = this.frames[t];
              return (e - n) / (this.frames[t + this.getFrameEntries()] - n);
            case 1:
              return 0;
          }
          if (((r -= 2), n[r] > e)) {
            let i = this.frames[t];
            return (n[r + 1] * (e - i)) / (n[r] - i);
          }
          let i = r + 18;
          for (r += 2; r < i; r += 2)
            if (n[r] >= e) {
              let t = n[r - 2],
                i = n[r - 1];
              return i + ((e - t) / (n[r] - t)) * (n[r + 1] - i);
            }
          let a = n[i - 2],
            o = n[i - 1];
          return (
            o +
            ((1 - o) * (e - a)) / (this.frames[t + this.getFrameEntries()] - a)
          );
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = s.getAttachment();
          if (
            !c ||
            !(c instanceof Hs) ||
            c.timelineAttachment != this.attachment
          )
            return;
          let l = s.deform;
          l.length == 0 && (a = H.setup);
          let u = this.vertices,
            d = u[0].length,
            f = this.frames;
          if (n < f[0]) {
            switch (a) {
              case H.setup:
                l.length = 0;
                return;
              case H.first:
                if (i == 1) {
                  l.length = 0;
                  return;
                }
                l.length = d;
                let e = c;
                if (e.bones) {
                  i = 1 - i;
                  for (let e = 0; e < d; e++) l[e] *= i;
                } else {
                  let t = e.vertices;
                  for (let e = 0; e < d; e++) l[e] += (t[e] - l[e]) * i;
                }
            }
            return;
          }
          if (((l.length = d), n >= f[f.length - 1])) {
            let e = u[f.length - 1];
            if (i == 1)
              if (a == H.add) {
                let t = c;
                if (t.bones) for (let t = 0; t < d; t++) l[t] += e[t];
                else {
                  let n = t.vertices;
                  for (let t = 0; t < d; t++) l[t] += e[t] - n[t];
                }
              } else G.arrayCopy(e, 0, l, 0, d);
            else
              switch (a) {
                case H.setup: {
                  let t = c;
                  if (t.bones) for (let t = 0; t < d; t++) l[t] = e[t] * i;
                  else {
                    let n = t.vertices;
                    for (let t = 0; t < d; t++) {
                      let r = n[t];
                      l[t] = r + (e[t] - r) * i;
                    }
                  }
                  break;
                }
                case H.first:
                case H.replace:
                  for (let t = 0; t < d; t++) l[t] += (e[t] - l[t]) * i;
                  break;
                case H.add:
                  let t = c;
                  if (t.bones) for (let t = 0; t < d; t++) l[t] += e[t] * i;
                  else {
                    let n = t.vertices;
                    for (let t = 0; t < d; t++) l[t] += (e[t] - n[t]) * i;
                  }
              }
            return;
          }
          let p = Y.search1(f, n),
            m = this.getCurvePercent(n, p),
            h = u[p],
            g = u[p + 1];
          if (i == 1)
            if (a == H.add) {
              let e = c;
              if (e.bones)
                for (let e = 0; e < d; e++) {
                  let t = h[e];
                  l[e] += t + (g[e] - t) * m;
                }
              else {
                let t = e.vertices;
                for (let e = 0; e < d; e++) {
                  let n = h[e];
                  l[e] += n + (g[e] - n) * m - t[e];
                }
              }
            } else
              for (let e = 0; e < d; e++) {
                let t = h[e];
                l[e] = t + (g[e] - t) * m;
              }
          else
            switch (a) {
              case H.setup: {
                let e = c;
                if (e.bones)
                  for (let e = 0; e < d; e++) {
                    let t = h[e];
                    l[e] = (t + (g[e] - t) * m) * i;
                  }
                else {
                  let t = e.vertices;
                  for (let e = 0; e < d; e++) {
                    let n = h[e],
                      r = t[e];
                    l[e] = r + (n + (g[e] - n) * m - r) * i;
                  }
                }
                break;
              }
              case H.first:
              case H.replace:
                for (let e = 0; e < d; e++) {
                  let t = h[e];
                  l[e] += (t + (g[e] - t) * m - l[e]) * i;
                }
                break;
              case H.add:
                let e = c;
                if (e.bones)
                  for (let e = 0; e < d; e++) {
                    let t = h[e];
                    l[e] += (t + (g[e] - t) * m) * i;
                  }
                else {
                  let t = e.vertices;
                  for (let e = 0; e < d; e++) {
                    let n = h[e];
                    l[e] += (n + (g[e] - n) * m - t[e]) * i;
                  }
                }
            }
        }
      }),
      (Oc = class extends Y {
        constructor(e) {
          super(e, Oc.propertyIds), (this.events = Array(e));
        }
        getFrameCount() {
          return this.frames.length;
        }
        setFrame(e, t) {
          (this.frames[e] = t.time), (this.events[e] = t);
        }
        apply(e, t, n, r, i, a, o) {
          if (!r) return;
          let s = this.frames,
            c = this.frames.length;
          if (t > n) this.apply(e, t, Number.MAX_VALUE, r, i, a, o), (t = -1);
          else if (t >= s[c - 1]) return;
          if (n < s[0]) return;
          let l = 0;
          if (t < s[0]) l = 0;
          else {
            l = Y.search1(s, t) + 1;
            let e = s[l];
            for (; l > 0 && s[l - 1] == e; ) l--;
          }
          for (; l < c && n >= s[l]; l++) r.push(this.events[l]);
        }
      }),
      (kc = Oc),
      (kc.propertyIds = [`${J.event}`]),
      (Ac = class extends Y {
        constructor(e) {
          super(e, Ac.propertyIds), (this.drawOrders = Array(e));
        }
        getFrameCount() {
          return this.frames.length;
        }
        setFrame(e, t, n) {
          (this.frames[e] = t), (this.drawOrders[e] = n);
        }
        apply(e, t, n, r, i, a, o) {
          if (o == as.mixOut) {
            a == H.setup &&
              G.arrayCopy(e.slots, 0, e.drawOrder, 0, e.slots.length);
            return;
          }
          if (n < this.frames[0]) {
            (a == H.setup || a == H.first) &&
              G.arrayCopy(e.slots, 0, e.drawOrder, 0, e.slots.length);
            return;
          }
          let s = Y.search1(this.frames, n),
            c = this.drawOrders[s];
          if (!c) G.arrayCopy(e.slots, 0, e.drawOrder, 0, e.slots.length);
          else {
            let t = e.drawOrder,
              n = e.slots;
            for (let e = 0, r = c.length; e < r; e++) t[e] = n[c[e]];
          }
        }
      }),
      (jc = Ac),
      (jc.propertyIds = [`${J.drawOrder}`]),
      (Mc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.ikConstraint}|${n}`]),
            (this.ikConstraintIndex = 0),
            (this.ikConstraintIndex = n);
        }
        getFrameEntries() {
          return 6;
        }
        setFrame(e, t, n, r, i, a, o) {
          (e *= 6),
            (this.frames[e] = t),
            (this.frames[e + 1] = n),
            (this.frames[e + 2] = r),
            (this.frames[e + 3] = i),
            (this.frames[e + 4] = +!!a),
            (this.frames[e + 5] = +!!o);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.ikConstraints[this.ikConstraintIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            switch (a) {
              case H.setup:
                (s.mix = s.data.mix),
                  (s.softness = s.data.softness),
                  (s.bendDirection = s.data.bendDirection),
                  (s.compress = s.data.compress),
                  (s.stretch = s.data.stretch);
                return;
              case H.first:
                (s.mix += (s.data.mix - s.mix) * i),
                  (s.softness += (s.data.softness - s.softness) * i),
                  (s.bendDirection = s.data.bendDirection),
                  (s.compress = s.data.compress),
                  (s.stretch = s.data.stretch);
            }
            return;
          }
          let l = 0,
            u = 0,
            d = Y.search(c, n, 6),
            f = this.curves[d / 6];
          switch (f) {
            case 0:
              let e = c[d];
              (l = c[d + 1]), (u = c[d + 2]);
              let t = (n - e) / (c[d + 6] - e);
              (l += (c[d + 6 + 1] - l) * t), (u += (c[d + 6 + 2] - u) * t);
              break;
            case 1:
              (l = c[d + 1]), (u = c[d + 2]);
              break;
            default:
              (l = this.getBezierValue(n, d, 1, f - 2)),
                (u = this.getBezierValue(n, d, 2, f + 18 - 2));
          }
          a == H.setup
            ? ((s.mix = s.data.mix + (l - s.data.mix) * i),
              (s.softness = s.data.softness + (u - s.data.softness) * i),
              o == as.mixOut
                ? ((s.bendDirection = s.data.bendDirection),
                  (s.compress = s.data.compress),
                  (s.stretch = s.data.stretch))
                : ((s.bendDirection = c[d + 3]),
                  (s.compress = c[d + 4] != 0),
                  (s.stretch = c[d + 5] != 0)))
            : ((s.mix += (l - s.mix) * i),
              (s.softness += (u - s.softness) * i),
              o == as.mixIn &&
                ((s.bendDirection = c[d + 3]),
                (s.compress = c[d + 4] != 0),
                (s.stretch = c[d + 5] != 0)));
        }
      }),
      (Nc = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.transformConstraint}|${n}`]),
            (this.transformConstraintIndex = 0),
            (this.transformConstraintIndex = n);
        }
        getFrameEntries() {
          return 7;
        }
        setFrame(e, t, n, r, i, a, o, s) {
          let c = this.frames;
          (e *= 7),
            (c[e] = t),
            (c[e + 1] = n),
            (c[e + 2] = r),
            (c[e + 3] = i),
            (c[e + 4] = a),
            (c[e + 5] = o),
            (c[e + 6] = s);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.transformConstraints[this.transformConstraintIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            let e = s.data;
            switch (a) {
              case H.setup:
                (s.mixRotate = e.mixRotate),
                  (s.mixX = e.mixX),
                  (s.mixY = e.mixY),
                  (s.mixScaleX = e.mixScaleX),
                  (s.mixScaleY = e.mixScaleY),
                  (s.mixShearY = e.mixShearY);
                return;
              case H.first:
                (s.mixRotate += (e.mixRotate - s.mixRotate) * i),
                  (s.mixX += (e.mixX - s.mixX) * i),
                  (s.mixY += (e.mixY - s.mixY) * i),
                  (s.mixScaleX += (e.mixScaleX - s.mixScaleX) * i),
                  (s.mixScaleY += (e.mixScaleY - s.mixScaleY) * i),
                  (s.mixShearY += (e.mixShearY - s.mixShearY) * i);
            }
            return;
          }
          let l,
            u,
            d,
            f,
            p,
            m,
            h = Y.search(c, n, 7),
            g = this.curves[h / 7];
          switch (g) {
            case 0:
              let e = c[h];
              (l = c[h + 1]),
                (u = c[h + 2]),
                (d = c[h + 3]),
                (f = c[h + 4]),
                (p = c[h + 5]),
                (m = c[h + 6]);
              let t = (n - e) / (c[h + 7] - e);
              (l += (c[h + 7 + 1] - l) * t),
                (u += (c[h + 7 + 2] - u) * t),
                (d += (c[h + 7 + 3] - d) * t),
                (f += (c[h + 7 + 4] - f) * t),
                (p += (c[h + 7 + 5] - p) * t),
                (m += (c[h + 7 + 6] - m) * t);
              break;
            case 1:
              (l = c[h + 1]),
                (u = c[h + 2]),
                (d = c[h + 3]),
                (f = c[h + 4]),
                (p = c[h + 5]),
                (m = c[h + 6]);
              break;
            default:
              (l = this.getBezierValue(n, h, 1, g - 2)),
                (u = this.getBezierValue(n, h, 2, g + 18 - 2)),
                (d = this.getBezierValue(n, h, 3, g + 36 - 2)),
                (f = this.getBezierValue(n, h, 4, g + 54 - 2)),
                (p = this.getBezierValue(n, h, 5, g + 72 - 2)),
                (m = this.getBezierValue(n, h, 6, g + 90 - 2));
          }
          if (a == H.setup) {
            let e = s.data;
            (s.mixRotate = e.mixRotate + (l - e.mixRotate) * i),
              (s.mixX = e.mixX + (u - e.mixX) * i),
              (s.mixY = e.mixY + (d - e.mixY) * i),
              (s.mixScaleX = e.mixScaleX + (f - e.mixScaleX) * i),
              (s.mixScaleY = e.mixScaleY + (p - e.mixScaleY) * i),
              (s.mixShearY = e.mixShearY + (m - e.mixShearY) * i);
          } else
            (s.mixRotate += (l - s.mixRotate) * i),
              (s.mixX += (u - s.mixX) * i),
              (s.mixY += (d - s.mixY) * i),
              (s.mixScaleX += (f - s.mixScaleX) * i),
              (s.mixScaleY += (p - s.mixScaleY) * i),
              (s.mixShearY += (m - s.mixShearY) * i);
        }
      }),
      (Pc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.pathConstraintPosition}|${n}`),
            (this.pathConstraintIndex = 0),
            (this.pathConstraintIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.pathConstraints[this.pathConstraintIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.position = s.data.position;
                return;
              case H.first:
                s.position += (s.data.position - s.position) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          a == H.setup
            ? (s.position = s.data.position + (c - s.data.position) * i)
            : (s.position += (c - s.position) * i);
        }
      }),
      (Fc = class extends lc {
        constructor(e, t, n) {
          super(e, t, `${J.pathConstraintSpacing}|${n}`),
            (this.pathConstraintIndex = 0),
            (this.pathConstraintIndex = n);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.pathConstraints[this.pathConstraintIndex];
          if (!s.active) return;
          if (n < this.frames[0]) {
            switch (a) {
              case H.setup:
                s.spacing = s.data.spacing;
                return;
              case H.first:
                s.spacing += (s.data.spacing - s.spacing) * i;
            }
            return;
          }
          let c = this.getCurveValue(n);
          a == H.setup
            ? (s.spacing = s.data.spacing + (c - s.data.spacing) * i)
            : (s.spacing += (c - s.spacing) * i);
        }
      }),
      (Ic = class extends cc {
        constructor(e, t, n) {
          super(e, t, [`${J.pathConstraintMix}|${n}`]),
            (this.pathConstraintIndex = 0),
            (this.pathConstraintIndex = n);
        }
        getFrameEntries() {
          return 4;
        }
        setFrame(e, t, n, r, i) {
          let a = this.frames;
          (e <<= 2), (a[e] = t), (a[e + 1] = n), (a[e + 2] = r), (a[e + 3] = i);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.pathConstraints[this.pathConstraintIndex];
          if (!s.active) return;
          let c = this.frames;
          if (n < c[0]) {
            switch (a) {
              case H.setup:
                (s.mixRotate = s.data.mixRotate),
                  (s.mixX = s.data.mixX),
                  (s.mixY = s.data.mixY);
                return;
              case H.first:
                (s.mixRotate += (s.data.mixRotate - s.mixRotate) * i),
                  (s.mixX += (s.data.mixX - s.mixX) * i),
                  (s.mixY += (s.data.mixY - s.mixY) * i);
            }
            return;
          }
          let l,
            u,
            d,
            f = Y.search(c, n, 4),
            p = this.curves[f >> 2];
          switch (p) {
            case 0:
              let e = c[f];
              (l = c[f + 1]), (u = c[f + 2]), (d = c[f + 3]);
              let t = (n - e) / (c[f + 4] - e);
              (l += (c[f + 4 + 1] - l) * t),
                (u += (c[f + 4 + 2] - u) * t),
                (d += (c[f + 4 + 3] - d) * t);
              break;
            case 1:
              (l = c[f + 1]), (u = c[f + 2]), (d = c[f + 3]);
              break;
            default:
              (l = this.getBezierValue(n, f, 1, p - 2)),
                (u = this.getBezierValue(n, f, 2, p + 18 - 2)),
                (d = this.getBezierValue(n, f, 3, p + 36 - 2));
          }
          if (a == H.setup) {
            let e = s.data;
            (s.mixRotate = e.mixRotate + (l - e.mixRotate) * i),
              (s.mixX = e.mixX + (u - e.mixX) * i),
              (s.mixY = e.mixY + (d - e.mixY) * i);
          } else
            (s.mixRotate += (l - s.mixRotate) * i),
              (s.mixX += (u - s.mixX) * i),
              (s.mixY += (d - s.mixY) * i);
        }
      }),
      (Lc = class extends Y {
        constructor(e, t, n) {
          super(e, [`${J.sequence}|${t}|${n.sequence.id}`]),
            (this.slotIndex = t),
            (this.attachment = n);
        }
        getFrameEntries() {
          return Lc.ENTRIES;
        }
        getSlotIndex() {
          return this.slotIndex;
        }
        getAttachment() {
          return this.attachment;
        }
        setFrame(e, t, n, r, i) {
          let a = this.frames;
          (e *= Lc.ENTRIES),
            (a[e] = t),
            (a[e + Lc.MODE] = n | (r << 4)),
            (a[e + Lc.DELAY] = i);
        }
        apply(e, t, n, r, i, a, o) {
          let s = e.slots[this.slotIndex];
          if (!s.bone.active) return;
          let c = s.attachment,
            l = this.attachment;
          if (c != l && (!(c instanceof Hs) || c.timelineAttachment != l))
            return;
          let u = this.frames;
          if (n < u[0]) {
            (a == H.setup || a == H.first) && (s.sequenceIndex = -1);
            return;
          }
          let d = Y.search(u, n, Lc.ENTRIES),
            f = u[d],
            p = u[d + Lc.MODE],
            m = u[d + Lc.DELAY];
          if (!this.attachment.sequence) return;
          let h = p >> 4,
            g = this.attachment.sequence.regions.length,
            _ = ac[p & 15];
          if (_ != ic.hold)
            switch (((h += ((n - f) / m + 1e-5) | 0), _)) {
              case ic.once:
                h = Math.min(g - 1, h);
                break;
              case ic.loop:
                h %= g;
                break;
              case ic.pingpong: {
                let e = (g << 1) - 2;
                (h = e == 0 ? 0 : h % e), h >= g && (h = e - h);
                break;
              }
              case ic.onceReverse:
                h = Math.max(g - 1 - h, 0);
                break;
              case ic.loopReverse:
                h = g - 1 - (h % g);
                break;
              case ic.pingpongReverse: {
                let e = (g << 1) - 2;
                (h = e == 0 ? 0 : (h + g - 1) % e), h >= g && (h = e - h);
              }
            }
          s.sequenceIndex = h;
        }
      }),
      (Rc = Lc),
      (Rc.ENTRIES = 3),
      (Rc.MODE = 1),
      (Rc.DELAY = 2);
  }))();
}
var Bc, Vc, Hc, Uc, Wc, Gc, Kc, qc, Jc, Yc, Xc, Zc, Qc;
function $c() {
  return ($c = t(() => {
    K(),
      zc(),
      (Bc = class {
        constructor(e) {
          (this.tracks = []),
            (this.timeScale = 1),
            (this.unkeyedState = 0),
            (this.events = []),
            (this.listeners = []),
            (this.queue = new Wc(this)),
            (this.propertyIDs = new Cs()),
            (this.animationsChanged = !1),
            (this.trackEntryPool = new Ds(() => new Uc())),
            (this.data = e);
        }
        static emptyAnimation() {
          return Bc._emptyAnimation;
        }
        update(e) {
          e *= this.timeScale;
          let t = this.tracks;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (!r) continue;
            (r.animationLast = r.nextAnimationLast),
              (r.trackLast = r.nextTrackLast);
            let i = e * r.timeScale;
            if (r.delay > 0) {
              if (((r.delay -= i), r.delay > 0)) continue;
              (i = -r.delay), (r.delay = 0);
            }
            let a = r.next;
            if (a) {
              let t = r.trackLast - a.delay;
              if (t >= 0) {
                for (
                  a.delay = 0,
                    a.trackTime +=
                      r.timeScale == 0
                        ? 0
                        : (t / r.timeScale + e) * a.timeScale,
                    r.trackTime += i,
                    this.setCurrent(n, a, !0);
                  a.mixingFrom;

                )
                  (a.mixTime += e), (a = a.mixingFrom);
                continue;
              }
            } else if (r.trackLast >= r.trackEnd && !r.mixingFrom) {
              (t[n] = null), this.queue.end(r), this.clearNext(r);
              continue;
            }
            if (r.mixingFrom && this.updateMixingFrom(r, e)) {
              let e = r.mixingFrom;
              for (r.mixingFrom = null, e && (e.mixingTo = null); e; )
                this.queue.end(e), (e = e.mixingFrom);
            }
            r.trackTime += i;
          }
          this.queue.drain();
        }
        updateMixingFrom(e, t) {
          let n = e.mixingFrom;
          if (!n) return !0;
          let r = this.updateMixingFrom(n, t);
          return (
            (n.animationLast = n.nextAnimationLast),
            (n.trackLast = n.nextTrackLast),
            e.mixTime > 0 && e.mixTime >= e.mixDuration
              ? ((n.totalAlpha == 0 || e.mixDuration == 0) &&
                  ((e.mixingFrom = n.mixingFrom),
                  n.mixingFrom && (n.mixingFrom.mixingTo = e),
                  (e.interruptAlpha = n.interruptAlpha),
                  this.queue.end(n)),
                r)
              : ((n.trackTime += t * n.timeScale), (e.mixTime += t), !1)
          );
        }
        apply(e) {
          if (!e) throw Error(`skeleton cannot be null.`);
          this.animationsChanged && this._animationsChanged();
          let t = this.events,
            n = this.tracks,
            r = !1;
          for (let i = 0, a = n.length; i < a; i++) {
            let a = n[i];
            if (!a || a.delay > 0) continue;
            r = !0;
            let o = i == 0 ? H.first : a.mixBlend,
              s = a.alpha;
            a.mixingFrom
              ? (s *= this.applyMixingFrom(a, e, o))
              : a.trackTime >= a.trackEnd && !a.next && (s = 0);
            let c = a.animationLast,
              l = a.getAnimationTime(),
              u = l,
              d = t;
            a.reverse && ((u = a.animation.duration - u), (d = null));
            let f = a.animation.timelines,
              p = f.length;
            if ((i == 0 && s == 1) || o == H.add)
              for (let t = 0; t < p; t++) {
                G.webkit602BugfixHelper(s, o);
                let n = f[t];
                n instanceof Ec
                  ? this.applyAttachmentTimeline(n, e, u, o, !0)
                  : n.apply(e, c, u, d, s, o, as.mixIn);
              }
            else {
              let t = a.timelineMode,
                n = a.shortestRotation,
                r = !n && a.timelinesRotation.length != p << 1;
              r && (a.timelinesRotation.length = p << 1);
              for (let i = 0; i < p; i++) {
                let l = f[i],
                  p = t[i] == Kc ? o : H.setup;
                !n && l instanceof dc
                  ? this.applyRotateTimeline(
                      l,
                      e,
                      u,
                      s,
                      p,
                      a.timelinesRotation,
                      i << 1,
                      r
                    )
                  : l instanceof Ec
                  ? this.applyAttachmentTimeline(l, e, u, o, !0)
                  : (G.webkit602BugfixHelper(s, o),
                    l.apply(e, c, u, d, s, p, as.mixIn));
              }
            }
            this.queueEvents(a, l),
              (t.length = 0),
              (a.nextAnimationLast = l),
              (a.nextTrackLast = a.trackTime);
          }
          let i = this.unkeyedState + Zc,
            a = e.slots;
          for (let t = 0, n = e.slots.length; t < n; t++) {
            let n = a[t];
            if (n.attachmentState == i) {
              let t = n.data.attachmentName;
              n.setAttachment(t ? e.getAttachment(n.data.index, t) : null);
            }
          }
          return (this.unkeyedState += 2), this.queue.drain(), r;
        }
        applyMixingFrom(e, t, n) {
          let r = e.mixingFrom;
          r.mixingFrom && this.applyMixingFrom(r, t, n);
          let i = 0;
          e.mixDuration == 0
            ? ((i = 1), n == H.first && (n = H.setup))
            : ((i = e.mixTime / e.mixDuration),
              i > 1 && (i = 1),
              n != H.first && (n = r.mixBlend));
          let a = i < r.attachmentThreshold,
            o = i < r.drawOrderThreshold,
            s = r.animation.timelines,
            c = s.length,
            l = r.alpha * e.interruptAlpha,
            u = l * (1 - i),
            d = r.animationLast,
            f = r.getAnimationTime(),
            p = f,
            m = null;
          if (
            (r.reverse
              ? (p = r.animation.duration - p)
              : i < r.eventThreshold && (m = this.events),
            n == H.add)
          )
            for (let e = 0; e < c; e++) s[e].apply(t, d, p, m, u, n, as.mixOut);
          else {
            let e = r.timelineMode,
              i = r.timelineHoldMix,
              f = r.shortestRotation,
              h = !f && r.timelinesRotation.length != c << 1;
            h && (r.timelinesRotation.length = c << 1), (r.totalAlpha = 0);
            for (let g = 0; g < c; g++) {
              let c = s[g],
                _ = as.mixOut,
                v,
                y = 0;
              switch (e[g]) {
                case Kc:
                  if (!o && c instanceof jc) continue;
                  (v = n), (y = u);
                  break;
                case qc:
                  (v = H.setup), (y = u);
                  break;
                case Jc:
                  (v = n), (y = l);
                  break;
                case Yc:
                  (v = H.setup), (y = l);
                  break;
                default:
                  v = H.setup;
                  let e = i[g];
                  y = l * Math.max(0, 1 - e.mixTime / e.mixDuration);
              }
              (r.totalAlpha += y),
                !f && c instanceof dc
                  ? this.applyRotateTimeline(
                      c,
                      t,
                      p,
                      y,
                      v,
                      r.timelinesRotation,
                      g << 1,
                      h
                    )
                  : c instanceof Ec
                  ? this.applyAttachmentTimeline(c, t, p, v, a)
                  : (G.webkit602BugfixHelper(y, n),
                    o && c instanceof jc && v == H.setup && (_ = as.mixIn),
                    c.apply(t, d, p, m, y, v, _));
            }
          }
          return (
            e.mixDuration > 0 && this.queueEvents(r, f),
            (this.events.length = 0),
            (r.nextAnimationLast = f),
            (r.nextTrackLast = r.trackTime),
            i
          );
        }
        applyAttachmentTimeline(e, t, n, r, i) {
          let a = t.slots[e.slotIndex];
          a.bone.active &&
            (n < e.frames[0]
              ? (r == H.setup || r == H.first) &&
                this.setAttachment(t, a, a.data.attachmentName, i)
              : this.setAttachment(
                  t,
                  a,
                  e.attachmentNames[Y.search1(e.frames, n)],
                  i
                ),
            a.attachmentState <= this.unkeyedState &&
              (a.attachmentState = this.unkeyedState + Zc));
        }
        setAttachment(e, t, n, r) {
          t.setAttachment(n ? e.getAttachment(t.data.index, n) : null),
            r && (t.attachmentState = this.unkeyedState + Qc);
        }
        applyRotateTimeline(e, t, n, r, i, a, o, s) {
          if ((s && (a[o] = 0), r == 1)) {
            e.apply(t, 0, n, null, 1, i, as.mixIn);
            return;
          }
          let c = t.bones[e.boneIndex];
          if (!c.active) return;
          let l = e.frames,
            u = 0,
            d = 0;
          if (n < l[0])
            switch (i) {
              case H.setup:
                c.rotation = c.data.rotation;
              default:
                return;
              case H.first:
                (u = c.rotation), (d = c.data.rotation);
            }
          else
            (u = i == H.setup ? c.data.rotation : c.rotation),
              (d = c.data.rotation + e.getCurveValue(n));
          let f = 0,
            p = d - u;
          if (
            ((p -= (16384 - ((16384.499999999996 - p / 360) | 0)) * 360),
            p == 0)
          )
            f = a[o];
          else {
            let e = 0,
              t = 0;
            s ? ((e = 0), (t = p)) : ((e = a[o]), (t = a[o + 1]));
            let n = p > 0,
              r = e >= 0;
            W.signum(t) != W.signum(p) &&
              Math.abs(t) <= 90 &&
              (Math.abs(e) > 180 && (e += 360 * W.signum(e)), (r = n)),
              (f = p + e - (e % 360)),
              r != n && (f += 360 * W.signum(e)),
              (a[o] = f);
          }
          (a[o + 1] = p), (c.rotation = u + f * r);
        }
        queueEvents(e, t) {
          let n = e.animationStart,
            r = e.animationEnd,
            i = r - n,
            a = e.trackLast % i,
            o = this.events,
            s = 0,
            c = o.length;
          for (; s < c; s++) {
            let t = o[s];
            if (t.time < a) break;
            t.time > r || this.queue.event(e, t);
          }
          let l = !1;
          for (
            l = e.loop
              ? i == 0 || a > e.trackTime % i
              : t >= r && e.animationLast < r,
              l && this.queue.complete(e);
            s < c;
            s++
          ) {
            let t = o[s];
            t.time < n || this.queue.event(e, t);
          }
        }
        clearTracks() {
          let e = this.queue.drainDisabled;
          this.queue.drainDisabled = !0;
          for (let e = 0, t = this.tracks.length; e < t; e++)
            this.clearTrack(e);
          (this.tracks.length = 0),
            (this.queue.drainDisabled = e),
            this.queue.drain();
        }
        clearTrack(e) {
          if (e >= this.tracks.length) return;
          let t = this.tracks[e];
          if (!t) return;
          this.queue.end(t), this.clearNext(t);
          let n = t;
          for (;;) {
            let e = n.mixingFrom;
            if (!e) break;
            this.queue.end(e),
              (n.mixingFrom = null),
              (n.mixingTo = null),
              (n = e);
          }
          (this.tracks[t.trackIndex] = null), this.queue.drain();
        }
        setCurrent(e, t, n) {
          let r = this.expandToIndex(e);
          (this.tracks[e] = t),
            (t.previous = null),
            r &&
              (n && this.queue.interrupt(r),
              (t.mixingFrom = r),
              (r.mixingTo = t),
              (t.mixTime = 0),
              r.mixingFrom &&
                r.mixDuration > 0 &&
                (t.interruptAlpha *= Math.min(1, r.mixTime / r.mixDuration)),
              (r.timelinesRotation.length = 0)),
            this.queue.start(t);
        }
        setAnimation(e, t, n = !1) {
          let r = this.data.skeletonData.findAnimation(t);
          if (!r) throw Error(`Animation not found: ${t}`);
          return this.setAnimationWith(e, r, n);
        }
        setAnimationWith(e, t, n = !1) {
          if (!t) throw Error(`animation cannot be null.`);
          let r = !0,
            i = this.expandToIndex(e);
          i &&
            (i.nextTrackLast == -1
              ? ((this.tracks[e] = i.mixingFrom),
                this.queue.interrupt(i),
                this.queue.end(i),
                this.clearNext(i),
                (i = i.mixingFrom),
                (r = !1))
              : this.clearNext(i));
          let a = this.trackEntry(e, t, n, i);
          return this.setCurrent(e, a, r), this.queue.drain(), a;
        }
        addAnimation(e, t, n = !1, r = 0) {
          let i = this.data.skeletonData.findAnimation(t);
          if (!i) throw Error(`Animation not found: ${t}`);
          return this.addAnimationWith(e, i, n, r);
        }
        addAnimationWith(e, t, n = !1, r = 0) {
          if (!t) throw Error(`animation cannot be null.`);
          let i = this.expandToIndex(e);
          if (i) for (; i.next; ) i = i.next;
          let a = this.trackEntry(e, t, n, i);
          return (
            i
              ? ((i.next = a),
                (a.previous = i),
                r <= 0 && (r += i.getTrackComplete() - a.mixDuration))
              : (this.setCurrent(e, a, !0), this.queue.drain()),
            (a.delay = r),
            a
          );
        }
        setEmptyAnimation(e, t = 0) {
          let n = this.setAnimationWith(e, Bc.emptyAnimation(), !1);
          return (n.mixDuration = t), (n.trackEnd = t), n;
        }
        addEmptyAnimation(e, t = 0, n = 0) {
          let r = this.addAnimationWith(e, Bc.emptyAnimation(), !1, n);
          return (
            n <= 0 && (r.delay += r.mixDuration - t),
            (r.mixDuration = t),
            (r.trackEnd = t),
            r
          );
        }
        setEmptyAnimations(e = 0) {
          let t = this.queue.drainDisabled;
          this.queue.drainDisabled = !0;
          for (let t = 0, n = this.tracks.length; t < n; t++) {
            let n = this.tracks[t];
            n && this.setEmptyAnimation(n.trackIndex, e);
          }
          (this.queue.drainDisabled = t), this.queue.drain();
        }
        expandToIndex(e) {
          return e < this.tracks.length
            ? this.tracks[e]
            : (G.ensureArrayCapacity(this.tracks, e + 1, null),
              (this.tracks.length = e + 1),
              null);
        }
        trackEntry(e, t, n, r) {
          let i = this.trackEntryPool.obtain();
          return (
            i.reset(),
            (i.trackIndex = e),
            (i.animation = t),
            (i.loop = n),
            (i.holdPrevious = !1),
            (i.reverse = !1),
            (i.shortestRotation = !1),
            (i.eventThreshold = 0),
            (i.attachmentThreshold = 0),
            (i.drawOrderThreshold = 0),
            (i.animationStart = 0),
            (i.animationEnd = t.duration),
            (i.animationLast = -1),
            (i.nextAnimationLast = -1),
            (i.delay = 0),
            (i.trackTime = 0),
            (i.trackLast = -1),
            (i.nextTrackLast = -1),
            (i.trackEnd = Number.MAX_VALUE),
            (i.timeScale = 1),
            (i.alpha = 1),
            (i.mixTime = 0),
            (i.mixDuration = r ? this.data.getMix(r.animation, t) : 0),
            (i.interruptAlpha = 1),
            (i.totalAlpha = 0),
            (i.mixBlend = H.replace),
            i
          );
        }
        clearNext(e) {
          let t = e.next;
          for (; t; ) this.queue.dispose(t), (t = t.next);
          e.next = null;
        }
        _animationsChanged() {
          (this.animationsChanged = !1), this.propertyIDs.clear();
          let e = this.tracks;
          for (let t = 0, n = e.length; t < n; t++) {
            let n = e[t];
            if (n) {
              for (; n.mixingFrom; ) n = n.mixingFrom;
              do
                (!n.mixingTo || n.mixBlend != H.add) && this.computeHold(n),
                  (n = n.mixingTo);
              while (n);
            }
          }
        }
        computeHold(e) {
          let t = e.mixingTo,
            n = e.animation.timelines,
            r = e.animation.timelines.length,
            i = e.timelineMode;
          i.length = r;
          let a = e.timelineHoldMix;
          a.length = 0;
          let o = this.propertyIDs;
          if (t && t.holdPrevious) {
            for (let e = 0; e < r; e++)
              i[e] = o.addAll(n[e].getPropertyIds()) ? Yc : Jc;
            return;
          }
          outer: for (let s = 0; s < r; s++) {
            let r = n[s],
              c = r.getPropertyIds();
            if (!o.addAll(c)) i[s] = Kc;
            else if (
              !t ||
              r instanceof Ec ||
              r instanceof jc ||
              r instanceof kc ||
              !t.animation.hasTimeline(c)
            )
              i[s] = qc;
            else {
              for (let n = t.mixingTo; n; n = n.mixingTo)
                if (!n.animation.hasTimeline(c)) {
                  if (e.mixDuration > 0) {
                    (i[s] = Xc), (a[s] = n);
                    continue outer;
                  }
                  break;
                }
              i[s] = Yc;
            }
          }
        }
        getCurrent(e) {
          return e >= this.tracks.length ? null : this.tracks[e];
        }
        addListener(e) {
          if (!e) throw Error(`listener cannot be null.`);
          this.listeners.push(e);
        }
        removeListener(e) {
          let t = this.listeners.indexOf(e);
          t >= 0 && this.listeners.splice(t, 1);
        }
        clearListeners() {
          this.listeners.length = 0;
        }
        clearListenerNotifications() {
          this.queue.clear();
        }
        setAnimationByName(e, t, n) {
          Bc.deprecatedWarning1 ||
            ((Bc.deprecatedWarning1 = !0),
            console.warn(
              `Spine Deprecation Warning: AnimationState.setAnimationByName is deprecated, please use setAnimation from now on.`
            )),
            this.setAnimation(e, t, n);
        }
        addAnimationByName(e, t, n, r) {
          Bc.deprecatedWarning2 ||
            ((Bc.deprecatedWarning2 = !0),
            console.warn(
              `Spine Deprecation Warning: AnimationState.addAnimationByName is deprecated, please use addAnimation from now on.`
            )),
            this.addAnimation(e, t, n, r);
        }
        hasAnimation(e) {
          return this.data.skeletonData.findAnimation(e) !== null;
        }
        hasAnimationByName(e) {
          return (
            Bc.deprecatedWarning3 ||
              ((Bc.deprecatedWarning3 = !0),
              console.warn(
                `Spine Deprecation Warning: AnimationState.hasAnimationByName is deprecated, please use hasAnimation from now on.`
              )),
            this.hasAnimation(e)
          );
        }
      }),
      (Vc = Bc),
      (Vc._emptyAnimation = new sc(`<empty>`, [], 0)),
      (Vc.deprecatedWarning1 = !1),
      (Vc.deprecatedWarning2 = !1),
      (Vc.deprecatedWarning3 = !1),
      (Hc = class {
        constructor() {
          (this.animation = null),
            (this.previous = null),
            (this.next = null),
            (this.mixingFrom = null),
            (this.mixingTo = null),
            (this.listener = null),
            (this.trackIndex = 0),
            (this.loop = !1),
            (this.holdPrevious = !1),
            (this.reverse = !1),
            (this.shortestRotation = !1),
            (this.eventThreshold = 0),
            (this.attachmentThreshold = 0),
            (this.drawOrderThreshold = 0),
            (this.animationStart = 0),
            (this.animationEnd = 0),
            (this.animationLast = 0),
            (this.nextAnimationLast = 0),
            (this.delay = 0),
            (this.trackTime = 0),
            (this.trackLast = 0),
            (this.nextTrackLast = 0),
            (this.trackEnd = 0),
            (this.timeScale = 0),
            (this.alpha = 0),
            (this.mixTime = 0),
            (this.mixDuration = 0),
            (this.interruptAlpha = 0),
            (this.totalAlpha = 0),
            (this.mixBlend = H.replace),
            (this.timelineMode = []),
            (this.timelineHoldMix = []),
            (this.timelinesRotation = []);
        }
        reset() {
          (this.next = null),
            (this.previous = null),
            (this.mixingFrom = null),
            (this.mixingTo = null),
            (this.animation = null),
            (this.listener = null),
            (this.timelineMode.length = 0),
            (this.timelineHoldMix.length = 0),
            (this.timelinesRotation.length = 0);
        }
        getAnimationTime() {
          if (this.loop) {
            let e = this.animationEnd - this.animationStart;
            return e == 0
              ? this.animationStart
              : (this.trackTime % e) + this.animationStart;
          }
          return Math.min(
            this.trackTime + this.animationStart,
            this.animationEnd
          );
        }
        setAnimationLast(e) {
          (this.animationLast = e), (this.nextAnimationLast = e);
        }
        isComplete() {
          return this.trackTime >= this.animationEnd - this.animationStart;
        }
        resetRotationDirections() {
          this.timelinesRotation.length = 0;
        }
        getTrackComplete() {
          let e = this.animationEnd - this.animationStart;
          if (e != 0) {
            if (this.loop) return e * (1 + ((this.trackTime / e) | 0));
            if (this.trackTime < e) return e;
          }
          return this.trackTime;
        }
        get time() {
          return (
            Hc.deprecatedWarning1 ||
              ((Hc.deprecatedWarning1 = !0),
              console.warn(
                `Spine Deprecation Warning: TrackEntry.time is deprecated, please use trackTime from now on.`
              )),
            this.trackTime
          );
        }
        set time(e) {
          Hc.deprecatedWarning1 ||
            ((Hc.deprecatedWarning1 = !0),
            console.warn(
              `Spine Deprecation Warning: TrackEntry.time is deprecated, please use trackTime from now on.`
            )),
            (this.trackTime = e);
        }
        get endTime() {
          return (
            Hc.deprecatedWarning2 ||
              ((Hc.deprecatedWarning2 = !0),
              console.warn(
                `Spine Deprecation Warning: TrackEntry.endTime is deprecated, please use trackEnd from now on.`
              )),
            this.trackTime
          );
        }
        set endTime(e) {
          Hc.deprecatedWarning2 ||
            ((Hc.deprecatedWarning2 = !0),
            console.warn(
              `Spine Deprecation Warning: TrackEntry.endTime is deprecated, please use trackEnd from now on.`
            )),
            (this.trackTime = e);
        }
        loopsCount() {
          return Math.floor(this.trackTime / this.trackEnd);
        }
      }),
      (Uc = Hc),
      (Uc.deprecatedWarning1 = !1),
      (Uc.deprecatedWarning2 = !1),
      (Wc = class {
        constructor(e) {
          (this.objects = []), (this.drainDisabled = !1), (this.animState = e);
        }
        start(e) {
          this.objects.push(Gc.start),
            this.objects.push(e),
            (this.animState.animationsChanged = !0);
        }
        interrupt(e) {
          this.objects.push(Gc.interrupt), this.objects.push(e);
        }
        end(e) {
          this.objects.push(Gc.end),
            this.objects.push(e),
            (this.animState.animationsChanged = !0);
        }
        dispose(e) {
          this.objects.push(Gc.dispose), this.objects.push(e);
        }
        complete(e) {
          this.objects.push(Gc.complete), this.objects.push(e);
        }
        event(e, t) {
          this.objects.push(Gc.event),
            this.objects.push(e),
            this.objects.push(t);
        }
        drain() {
          if (this.drainDisabled) return;
          this.drainDisabled = !0;
          let e = this.objects,
            t = this.animState.listeners;
          for (let n = 0; n < e.length; n += 2) {
            let r = e[n],
              i = e[n + 1];
            switch (r) {
              case Gc.start:
                i.listener && i.listener.start && i.listener.start(i);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.start && n.start(i);
                }
                break;
              case Gc.interrupt:
                i.listener && i.listener.interrupt && i.listener.interrupt(i);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.interrupt && n.interrupt(i);
                }
                break;
              case Gc.end:
                i.listener && i.listener.end && i.listener.end(i);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.end && n.end(i);
                }
              case Gc.dispose:
                i.listener && i.listener.dispose && i.listener.dispose(i);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.dispose && n.dispose(i);
                }
                this.animState.trackEntryPool.free(i);
                break;
              case Gc.complete:
                i.listener && i.listener.complete && i.listener.complete(i);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.complete && n.complete(i);
                }
                break;
              case Gc.event:
                let r = e[n++ + 2];
                i.listener && i.listener.event && i.listener.event(i, r);
                for (let e = 0; e < t.length; e++) {
                  let n = t[e];
                  n.event && n.event(i, r);
                }
            }
          }
          this.clear(), (this.drainDisabled = !1);
        }
        clear() {
          this.objects.length = 0;
        }
      }),
      (Gc = ((e) => (
        (e[(e.start = 0)] = `start`),
        (e[(e.interrupt = 1)] = `interrupt`),
        (e[(e.end = 2)] = `end`),
        (e[(e.dispose = 3)] = `dispose`),
        (e[(e.complete = 4)] = `complete`),
        (e[(e.event = 5)] = `event`),
        e
      ))(Gc || {})),
      (Kc = 0),
      (qc = 1),
      (Jc = 2),
      (Yc = 3),
      (Xc = 4),
      (Zc = 1),
      (Qc = 2);
  }))();
}
var el;
function tl() {
  return (tl = t(() => {
    el = class {
      constructor(e) {
        if (((this.animationToMixTime = {}), (this.defaultMix = 0), !e))
          throw Error(`skeletonData cannot be null.`);
        this.skeletonData = e;
      }
      setMix(e, t, n) {
        let r = this.skeletonData.findAnimation(e);
        if (!r) throw Error(`Animation not found: ${e}`);
        let i = this.skeletonData.findAnimation(t);
        if (!i) throw Error(`Animation not found: ${t}`);
        this.setMixWith(r, i, n);
      }
      setMixWith(e, t, n) {
        if (!e) throw Error(`from cannot be null.`);
        if (!t) throw Error(`to cannot be null.`);
        let r = `${e.name}.${t.name}`;
        this.animationToMixTime[r] = n;
      }
      getMix(e, t) {
        let n = `${e.name}.${t.name}`,
          r = this.animationToMixTime[n];
        return r === void 0 ? this.defaultMix : r;
      }
    };
  }))();
}
var nl;
function rl() {
  return (rl = t(() => {
    Us(),
      Gs(),
      qs(),
      Ys(),
      Zs(),
      $s(),
      tc(),
      oc(),
      (nl = class {
        constructor(e) {
          this.atlas = e;
        }
        loadSequence(e, t, n) {
          let r = n.regions;
          for (let i = 0, a = r.length; i < a; i++) {
            let a = n.getPath(t, i),
              o = this.atlas.findRegion(a);
            if (o == null)
              throw Error(`Region not found in atlas: ${a} (sequence: ${e})`);
            (r[i] = o), (r[i].renderObject = r[i]);
          }
        }
        newRegionAttachment(e, t, n, r) {
          let i = new q(t, n);
          if (r != null) this.loadSequence(t, n, r);
          else {
            let e = this.atlas.findRegion(n);
            if (!e)
              throw Error(
                `Region not found in atlas: ${n} (region attachment: ${t})`
              );
            (e.renderObject = e), (i.region = e);
          }
          return i;
        }
        newMeshAttachment(e, t, n, r) {
          let i = new Js(t, n);
          if (r != null) this.loadSequence(t, n, r);
          else {
            let e = this.atlas.findRegion(n);
            if (!e)
              throw Error(
                `Region not found in atlas: ${n} (mesh attachment: ${t})`
              );
            (e.renderObject = e), (i.region = e);
          }
          return i;
        }
        newBoundingBoxAttachment(e, t) {
          return new Ws(t);
        }
        newPathAttachment(e, t) {
          return new Xs(t);
        }
        newPointAttachment(e, t) {
          return new Qs(t);
        }
        newClippingAttachment(e, t) {
          return new Ks(t);
        }
      });
  }))();
}
var il;
function al() {
  return (al = t(() => {
    R(),
      K(),
      (il = class {
        constructor(e, t, n) {
          if (
            ((this.matrix = new se()),
            (this.parent = null),
            (this.children = []),
            (this.x = 0),
            (this.y = 0),
            (this.rotation = 0),
            (this.scaleX = 0),
            (this.scaleY = 0),
            (this.shearX = 0),
            (this.shearY = 0),
            (this.ax = 0),
            (this.ay = 0),
            (this.arotation = 0),
            (this.ascaleX = 0),
            (this.ascaleY = 0),
            (this.ashearX = 0),
            (this.ashearY = 0),
            (this.sorted = !1),
            (this.active = !1),
            !e)
          )
            throw Error(`data cannot be null.`);
          if (!t) throw Error(`skeleton cannot be null.`);
          (this.data = e),
            (this.skeleton = t),
            (this.parent = n),
            this.setToSetupPose();
        }
        get worldX() {
          return this.matrix.tx;
        }
        get worldY() {
          return this.matrix.ty;
        }
        isActive() {
          return this.active;
        }
        update() {
          this.updateWorldTransformWith(
            this.ax,
            this.ay,
            this.arotation,
            this.ascaleX,
            this.ascaleY,
            this.ashearX,
            this.ashearY
          );
        }
        updateWorldTransform() {
          this.updateWorldTransformWith(
            this.x,
            this.y,
            this.rotation,
            this.scaleX,
            this.scaleY,
            this.shearX,
            this.shearY
          );
        }
        updateWorldTransformWith(e, t, n, r, i, a, o) {
          (this.ax = e),
            (this.ay = t),
            (this.arotation = n),
            (this.ascaleX = r),
            (this.ascaleY = i),
            (this.ashearX = a),
            (this.ashearY = o);
          let s = this.parent,
            c = this.matrix,
            l = this.skeleton.scaleX,
            u = js.yDown ? -this.skeleton.scaleY : this.skeleton.scaleY;
          if (!s) {
            let s = this.skeleton,
              d = n + 90 + o;
            (c.a = W.cosDeg(n + a) * r * l),
              (c.c = W.cosDeg(d) * i * l),
              (c.b = W.sinDeg(n + a) * r * u),
              (c.d = W.sinDeg(d) * i * u),
              (c.tx = e * l + s.x),
              (c.ty = t * u + s.y);
            return;
          }
          let d = s.matrix.a,
            f = s.matrix.c,
            p = s.matrix.b,
            m = s.matrix.d;
          switch (
            ((c.tx = d * e + f * t + s.matrix.tx),
            (c.ty = p * e + m * t + s.matrix.ty),
            this.data.transformMode)
          ) {
            case us.Normal: {
              let e = n + 90 + o,
                t = W.cosDeg(n + a) * r,
                s = W.cosDeg(e) * i,
                l = W.sinDeg(n + a) * r,
                u = W.sinDeg(e) * i;
              (c.a = d * t + f * l),
                (c.c = d * s + f * u),
                (c.b = p * t + m * l),
                (c.d = p * s + m * u);
              return;
            }
            case us.OnlyTranslation: {
              let e = n + 90 + o;
              (c.a = W.cosDeg(n + a) * r),
                (c.c = W.cosDeg(e) * i),
                (c.b = W.sinDeg(n + a) * r),
                (c.d = W.sinDeg(e) * i);
              break;
            }
            case us.NoRotationOrReflection: {
              let e = d * d + p * p,
                t = 0;
              e > 1e-4
                ? ((e = Math.abs(d * m - f * p) / e),
                  (d /= l),
                  (p /= u),
                  (f = p * e),
                  (m = d * e),
                  (t = Math.atan2(p, d) * W.radDeg))
                : ((d = 0), (p = 0), (t = 90 - Math.atan2(m, f) * W.radDeg));
              let s = n + a - t,
                h = n + o - t + 90,
                g = W.cosDeg(s) * r,
                _ = W.cosDeg(h) * i,
                v = W.sinDeg(s) * r,
                y = W.sinDeg(h) * i;
              (c.a = d * g - f * v),
                (c.c = d * _ - f * y),
                (c.b = p * g + m * v),
                (c.d = p * _ + m * y);
              break;
            }
            case us.NoScale:
            case us.NoScaleOrReflection: {
              let e = W.cosDeg(n),
                t = W.sinDeg(n),
                s = (d * e + f * t) / l,
                h = (p * e + m * t) / u,
                g = Math.sqrt(s * s + h * h);
              g > 1e-5 && (g = 1 / g),
                (s *= g),
                (h *= g),
                (g = Math.sqrt(s * s + h * h)),
                this.data.transformMode == us.NoScale &&
                  d * m - f * p < 0 != (l < 0 != u < 0) &&
                  (g = -g);
              let _ = Math.PI / 2 + Math.atan2(h, s),
                v = Math.cos(_) * g,
                y = Math.sin(_) * g,
                b = W.cosDeg(a) * r,
                x = W.cosDeg(90 + o) * i,
                S = W.sinDeg(a) * r,
                C = W.sinDeg(90 + o) * i;
              (c.a = s * b + v * S),
                (c.c = s * x + v * C),
                (c.b = h * b + y * S),
                (c.d = h * x + y * C);
              break;
            }
          }
          (c.a *= l), (c.c *= l), (c.b *= u), (c.d *= u);
        }
        setToSetupPose() {
          let e = this.data;
          (this.x = e.x),
            (this.y = e.y),
            (this.rotation = e.rotation),
            (this.scaleX = e.scaleX),
            (this.scaleY = e.scaleY),
            (this.shearX = e.shearX),
            (this.shearY = e.shearY);
        }
        getWorldRotationX() {
          return Math.atan2(this.matrix.b, this.matrix.a) * W.radDeg;
        }
        getWorldRotationY() {
          return Math.atan2(this.matrix.d, this.matrix.c) * W.radDeg;
        }
        getWorldScaleX() {
          let e = this.matrix;
          return Math.sqrt(e.a * e.a + e.b * e.b);
        }
        getWorldScaleY() {
          let e = this.matrix;
          return Math.sqrt(e.c * e.c + e.d * e.d);
        }
        updateAppliedTransform() {
          let e = this.parent,
            t = this.matrix;
          if (!e) {
            (this.ax = t.tx - this.skeleton.x),
              (this.ay = t.ty - this.skeleton.y),
              (this.arotation = Math.atan2(t.b, t.a) * W.radDeg),
              (this.ascaleX = Math.sqrt(t.a * t.a + t.b * t.b)),
              (this.ascaleY = Math.sqrt(t.c * t.c + t.d * t.d)),
              (this.ashearX = 0),
              (this.ashearY =
                Math.atan2(t.a * t.c + t.b * t.d, t.a * t.d - t.b * t.c) *
                W.radDeg);
            return;
          }
          let n = e.matrix,
            r = 1 / (n.a * n.d - n.b * n.c),
            i = t.tx - n.tx,
            a = t.ty - n.ty;
          (this.ax = i * n.d * r - a * n.c * r),
            (this.ay = a * n.a * r - i * n.b * r);
          let o = r * n.d,
            s = r * n.a,
            c = r * n.c,
            l = r * n.b,
            u = o * t.a - c * t.b,
            d = o * t.c - c * t.d,
            f = s * t.b - l * t.a,
            p = s * t.d - l * t.c;
          if (
            ((this.ashearX = 0),
            (this.ascaleX = Math.sqrt(u * u + f * f)),
            this.ascaleX > 1e-4)
          ) {
            let e = u * p - d * f;
            (this.ascaleY = e / this.ascaleX),
              (this.ashearY = Math.atan2(u * d + f * p, e) * W.radDeg),
              (this.arotation = Math.atan2(f, u) * W.radDeg);
          } else
            (this.ascaleX = 0),
              (this.ascaleY = Math.sqrt(d * d + p * p)),
              (this.ashearY = 0),
              (this.arotation = 90 - Math.atan2(p, d) * W.radDeg);
        }
        worldToLocal(e) {
          let t = this.matrix,
            n = t.a,
            r = t.c,
            i = t.b,
            a = t.d,
            o = 1 / (n * a - r * i),
            s = e.x - t.tx,
            c = e.y - t.ty;
          return (
            (e.x = s * a * o - c * r * o), (e.y = c * n * o - s * i * o), e
          );
        }
        localToWorld(e) {
          let t = this.matrix,
            n = e.x,
            r = e.y;
          return (
            (e.x = n * t.a + r * t.c + t.tx),
            (e.y = n * t.b + r * t.d + t.ty),
            e
          );
        }
        worldToLocalRotation(e) {
          let t = W.sinDeg(e),
            n = W.cosDeg(e),
            r = this.matrix;
          return Math.atan2(r.a * t - r.b * n, r.d * n - r.c * t) * W.radDeg;
        }
        localToWorldRotation(e) {
          e -= this.rotation - this.shearX;
          let t = W.sinDeg(e),
            n = W.cosDeg(e),
            r = this.matrix;
          return Math.atan2(n * r.b + t * r.d, n * r.a + t * r.c) * W.radDeg;
        }
        rotateWorld(e) {
          let t = this.matrix,
            n = t.a,
            r = t.c,
            i = t.b,
            a = t.d,
            o = W.cosDeg(e),
            s = W.sinDeg(e);
          (t.a = o * n - s * i),
            (t.c = o * r - s * a),
            (t.b = s * n + o * i),
            (t.d = s * r + o * a);
        }
      });
  }))();
}
var ol;
function sl() {
  return (sl = t(() => {
    K(),
      (ol = class {
        constructor(e, t, n) {
          if (
            ((this.index = 0),
            (this.parent = null),
            (this.length = 0),
            (this.x = 0),
            (this.y = 0),
            (this.rotation = 0),
            (this.scaleX = 1),
            (this.scaleY = 1),
            (this.shearX = 0),
            (this.shearY = 0),
            (this.transformMode = us.Normal),
            (this.skinRequired = !1),
            (this.color = new U()),
            e < 0)
          )
            throw Error(`index must be >= 0.`);
          if (!t) throw Error(`name cannot be null.`);
          (this.index = e), (this.name = t), (this.parent = n);
        }
      });
  }))();
}
var cl;
function ll() {
  return (ll = t(() => {
    cl = class {
      constructor(e, t, n) {
        (this.name = e), (this.order = t), (this.skinRequired = n);
      }
    };
  }))();
}
var ul;
function dl() {
  return (dl = t(() => {
    ul = class {
      constructor(e, t) {
        if (
          ((this.intValue = 0),
          (this.floatValue = 0),
          (this.stringValue = null),
          (this.time = 0),
          (this.volume = 0),
          (this.balance = 0),
          !t)
        )
          throw Error(`data cannot be null.`);
        (this.time = e), (this.data = t);
      }
    };
  }))();
}
var fl;
function pl() {
  return (pl = t(() => {
    fl = class {
      constructor(e) {
        (this.intValue = 0),
          (this.floatValue = 0),
          (this.stringValue = null),
          (this.audioPath = null),
          (this.volume = 0),
          (this.balance = 0),
          (this.name = e);
      }
    };
  }))();
}
var ml;
function hl() {
  return (hl = t(() => {
    K(),
      (ml = class {
        constructor(e, t) {
          if (
            ((this.bendDirection = 0),
            (this.compress = !1),
            (this.stretch = !1),
            (this.mix = 1),
            (this.softness = 0),
            (this.active = !1),
            !e)
          )
            throw Error(`data cannot be null.`);
          if (!t) throw Error(`skeleton cannot be null.`);
          (this.data = e),
            (this.mix = e.mix),
            (this.softness = e.softness),
            (this.bendDirection = e.bendDirection),
            (this.compress = e.compress),
            (this.stretch = e.stretch),
            (this.bones = []);
          for (let n = 0; n < e.bones.length; n++) {
            let r = t.findBone(e.bones[n].name);
            if (!r) throw Error(`Couldn't find bone ${e.bones[n].name}`);
            this.bones.push(r);
          }
          let n = t.findBone(e.target.name);
          if (!n) throw Error(`Couldn't find bone ${e.target.name}`);
          this.target = n;
        }
        isActive() {
          return this.active;
        }
        update() {
          if (this.mix == 0) return;
          let e = this.target,
            t = this.bones;
          switch (t.length) {
            case 1:
              this.apply1(
                t[0],
                e.worldX,
                e.worldY,
                this.compress,
                this.stretch,
                this.data.uniform,
                this.mix
              );
              break;
            case 2:
              this.apply2(
                t[0],
                t[1],
                e.worldX,
                e.worldY,
                this.bendDirection,
                this.stretch,
                this.data.uniform,
                this.softness,
                this.mix
              );
          }
        }
        apply1(e, t, n, r, i, a, o) {
          let s = e.parent.matrix;
          if (!s) throw Error(`IK bone must have parent.`);
          let c = s.a,
            l = s.c,
            u = s.b,
            d = s.d,
            f = -e.ashearX - e.arotation,
            p = 0,
            m = 0,
            h = e.skeleton.scaleX,
            g = js.yDown ? -e.skeleton.scaleY : e.skeleton.scaleY;
          switch (e.data.transformMode) {
            case us.OnlyTranslation:
              (p = t - e.worldX), (m = n - e.worldY), js.yDown && (m = -m);
              break;
            case us.NoRotationOrReflection:
              let r = Math.abs(c * d - l * u) / (c * c + u * u),
                i = c / h,
                a = u / g;
              (l = -a * r * h),
                (d = i * r * g),
                (f += Math.atan2(a, i) * W.radDeg);
            default:
              let o = t - s.tx,
                _ = n - s.ty,
                v = c * d - l * u;
              (p = (o * d - _ * l) / v - e.ax),
                (m = (_ * c - o * u) / v - e.ay);
          }
          (f += Math.atan2(m, p) * W.radDeg),
            e.ascaleX < 0 && (f += 180),
            f > 180 ? (f -= 360) : f < -180 && (f += 360);
          let _ = e.ascaleX,
            v = e.ascaleY;
          if (r || i) {
            switch (e.data.transformMode) {
              case us.NoScale:
              case us.NoScaleOrReflection:
                (p = t - e.worldX), (m = n - e.worldY);
            }
            let s = e.data.length * _,
              c = Math.sqrt(p * p + m * m);
            if ((r && c < s) || (i && c > s && s > 1e-4)) {
              let e = (c / s - 1) * o + 1;
              (_ *= e), a && (v *= e);
            }
          }
          e.updateWorldTransformWith(
            e.ax,
            e.ay,
            e.arotation + f * o,
            _,
            v,
            e.ashearX,
            e.ashearY
          );
        }
        apply2(e, t, n, r, i, a, o, s, c) {
          let l = e.ax,
            u = e.ay,
            d = e.ascaleX,
            f = e.ascaleY,
            p = d,
            m = f,
            h = t.ascaleX,
            g = e.matrix,
            _ = 0,
            v = 0,
            y = 0;
          d < 0 ? ((d = -d), (_ = 180), (y = -1)) : ((_ = 0), (y = 1)),
            f < 0 && ((f = -f), (y = -y)),
            h < 0 ? ((h = -h), (v = 180)) : (v = 0);
          let b = t.ax,
            x = 0,
            S = 0,
            C = 0,
            w = g.a,
            T = g.c,
            E = g.b,
            D = g.d,
            O = Math.abs(d - f) <= 1e-4;
          !O || a
            ? ((x = 0), (S = w * b + g.tx), (C = E * b + g.ty))
            : ((x = t.ay),
              (S = w * b + T * x + g.tx),
              (C = E * b + D * x + g.ty));
          let k = e.parent.matrix;
          if (!k) throw Error(`IK parent must itself have a parent.`);
          (w = k.a), (T = k.c), (E = k.b), (D = k.d);
          let A = 1 / (w * D - T * E),
            j = S - k.tx,
            M = C - k.ty,
            ee = (j * D - M * T) * A - l,
            N = (M * w - j * E) * A - u,
            P = Math.sqrt(ee * ee + N * N),
            te = t.data.length * h,
            ne,
            re;
          if (P < 1e-4) {
            this.apply1(e, n, r, !1, a, !1, c),
              t.updateWorldTransformWith(
                b,
                x,
                0,
                t.ascaleX,
                t.ascaleY,
                t.ashearX,
                t.ashearY
              );
            return;
          }
          (j = n - k.tx), (M = r - k.ty);
          let ie = (j * D - M * T) * A - l,
            F = (M * w - j * E) * A - u,
            ae = ie * ie + F * F;
          if (s != 0) {
            s *= d * (h + 1) * 0.5;
            let e = Math.sqrt(ae),
              t = e - P - te * d + s;
            if (t > 0) {
              let n = Math.min(1, t / (s * 2)) - 1;
              (n = (t - s * (1 - n * n)) / e),
                (ie -= n * ie),
                (F -= n * F),
                (ae = ie * ie + F * F);
            }
          }
          outer: if (O) {
            te *= d;
            let e = (ae - P * P - te * te) / (2 * P * te);
            e < -1
              ? ((e = -1), (re = Math.PI * i))
              : e > 1
              ? ((e = 1),
                (re = 0),
                a &&
                  ((w = (Math.sqrt(ae) / (P + te) - 1) * c + 1),
                  (p *= w),
                  o && (m *= w)))
              : (re = Math.acos(e) * i),
              (w = P + te * e),
              (T = te * Math.sin(re)),
              (ne = Math.atan2(F * w - ie * T, ie * w + F * T));
          } else {
            (w = d * te), (T = f * te);
            let e = w * w,
              t = T * T,
              n = Math.atan2(F, ie);
            E = t * P * P + e * ae - e * t;
            let r = -2 * t * P,
              a = t - e;
            if (((D = r * r - 4 * a * E), D >= 0)) {
              let e = Math.sqrt(D);
              r < 0 && (e = -e), (e = -(r + e) * 0.5);
              let t = e / a,
                o = E / e,
                s = Math.abs(t) < Math.abs(o) ? t : o;
              if (s * s <= ae) {
                (M = Math.sqrt(ae - s * s) * i),
                  (ne = n - Math.atan2(M, s)),
                  (re = Math.atan2(M / f, (s - P) / d));
                break outer;
              }
            }
            let o = W.PI,
              s = P - w,
              c = s * s,
              l = 0,
              u = 0,
              p = P + w,
              m = p * p,
              h = 0;
            (E = (-w * P) / (e - t)),
              E >= -1 &&
                E <= 1 &&
                ((E = Math.acos(E)),
                (j = w * Math.cos(E) + P),
                (M = T * Math.sin(E)),
                (D = j * j + M * M),
                D < c && ((o = E), (c = D), (s = j), (l = M)),
                D > m && ((u = E), (m = D), (p = j), (h = M))),
              ae <= (c + m) * 0.5
                ? ((ne = n - Math.atan2(l * i, s)), (re = o * i))
                : ((ne = n - Math.atan2(h * i, p)), (re = u * i));
          }
          let oe = Math.atan2(x, b) * y,
            se = e.arotation;
          (ne = (ne - oe) * W.radDeg + _ - se),
            ne > 180 ? (ne -= 360) : ne < -180 && (ne += 360),
            e.updateWorldTransformWith(l, u, se + ne * c, p, m, 0, 0),
            (se = t.arotation),
            (re = ((re + oe) * W.radDeg - t.ashearX) * y + v - se),
            re > 180 ? (re -= 360) : re < -180 && (re += 360),
            t.updateWorldTransformWith(
              b,
              x,
              se + re * c,
              t.ascaleX,
              t.ascaleY,
              t.ashearX,
              t.ashearY
            );
        }
      });
  }))();
}
var gl;
function _l() {
  return (_l = t(() => {
    ll(),
      (gl = class extends cl {
        constructor(e) {
          super(e, 0, !1),
            (this.bones = []),
            (this._target = null),
            (this.bendDirection = 1),
            (this.compress = !1),
            (this.stretch = !1),
            (this.uniform = !1),
            (this.mix = 1),
            (this.softness = 0);
        }
        set target(e) {
          this._target = e;
        }
        get target() {
          if (this._target) return this._target;
          throw Error(`BoneData not set.`);
        }
      });
  }))();
}
var vl, X;
function yl() {
  return (yl = t(() => {
    ll(),
      K(),
      (vl = class extends cl {
        constructor(e) {
          super(e, 0, !1),
            (this.bones = []),
            (this._target = null),
            (this.positionMode = ss.Fixed),
            (this.spacingMode = X.Fixed),
            (this.rotateMode = cs.Chain),
            (this.offsetRotation = 0),
            (this.position = 0),
            (this.spacing = 0),
            (this.mixRotate = 0),
            (this.mixX = 0),
            (this.mixY = 0);
        }
        set target(e) {
          this._target = e;
        }
        get target() {
          if (this._target) return this._target;
          throw Error(`SlotData not set.`);
        }
      }),
      (X = ((e) => (
        (e[(e.Length = 0)] = `Length`),
        (e[(e.Fixed = 1)] = `Fixed`),
        (e[(e.Percent = 2)] = `Percent`),
        (e[(e.Proportional = 3)] = `Proportional`),
        e
      ))(X || {}));
  }))();
}
var bl, xl;
function Sl() {
  return (Sl = t(() => {
    Us(),
      K(),
      Zs(),
      tc(),
      oc(),
      yl(),
      (bl = class {
        constructor(e, t) {
          if (
            ((this.position = 0),
            (this.spacing = 0),
            (this.mixRotate = 0),
            (this.mixX = 0),
            (this.mixY = 0),
            (this.spaces = []),
            (this.positions = []),
            (this.world = []),
            (this.curves = []),
            (this.lengths = []),
            (this.segments = []),
            (this.active = !1),
            !e)
          )
            throw Error(`data cannot be null.`);
          if (!t) throw Error(`skeleton cannot be null.`);
          (this.data = e), (this.bones = []);
          for (let n = 0, r = e.bones.length; n < r; n++) {
            let r = t.findBone(e.bones[n].name);
            if (!r) throw Error(`Couldn't find bone ${e.bones[n].name}.`);
            this.bones.push(r);
          }
          let n = t.findSlot(e.target.name);
          if (!n) throw Error(`Couldn't find target bone ${e.target.name}`);
          (this.target = n),
            (this.position = e.position),
            (this.spacing = e.spacing),
            (this.mixRotate = e.mixRotate),
            (this.mixX = e.mixX),
            (this.mixY = e.mixY);
        }
        isActive() {
          return this.active;
        }
        update() {
          let e = this.target.getAttachment();
          if (!(e instanceof Xs)) return;
          let t = this.mixRotate,
            n = this.mixX,
            r = this.mixY;
          if (t == 0 && n == 0 && r == 0) return;
          let i = this.data,
            a = i.rotateMode == cs.Tangent,
            o = i.rotateMode == cs.ChainScale,
            s = this.bones,
            c = s.length,
            l = a ? c : c + 1,
            u = G.setArraySize(this.spaces, l),
            d = o ? (this.lengths = G.setArraySize(this.lengths, c)) : [],
            f = this.spacing;
          switch (i.spacingMode) {
            case X.Percent:
              if (o)
                for (let e = 0, t = l - 1; e < t; e++) {
                  let t = s[e],
                    n = t.data.length;
                  if (n < bl.epsilon) d[e] = 0;
                  else {
                    let r = n * t.matrix.a,
                      i = n * t.matrix.b;
                    d[e] = Math.sqrt(r * r + i * i);
                  }
                }
              G.arrayFill(u, 1, l, f);
              break;
            case X.Proportional:
              let e = 0;
              for (let t = 0, n = l - 1; t < n; ) {
                let n = s[t],
                  r = n.data.length;
                if (r < bl.epsilon) o && (d[t] = 0), (u[++t] = f);
                else {
                  let i = r * n.matrix.a,
                    a = r * n.matrix.b,
                    s = Math.sqrt(i * i + a * a);
                  o && (d[t] = s), (u[++t] = s), (e += s);
                }
              }
              if (e > 0) {
                e = (l / e) * f;
                for (let t = 1; t < l; t++) u[t] *= e;
              }
              break;
            default:
              let t = i.spacingMode == X.Length;
              for (let e = 0, n = l - 1; e < n; ) {
                let n = s[e],
                  r = n.data.length;
                if (r < bl.epsilon) o && (d[e] = 0), (u[++e] = f);
                else {
                  let i = r * n.matrix.a,
                    a = r * n.matrix.b,
                    s = Math.sqrt(i * i + a * a);
                  o && (d[e] = s), (u[++e] = ((t ? r + f : f) * s) / r);
                }
              }
          }
          let p = this.computeWorldPositions(e, l, a),
            m = p[0],
            h = p[1],
            g = i.offsetRotation,
            _ = !1;
          if (g == 0) _ = i.rotateMode == cs.Chain;
          else {
            _ = !1;
            let e = this.target.bone.matrix;
            g *= e.a * e.d - e.b * e.c > 0 ? W.degRad : -W.degRad;
          }
          for (let e = 0, i = 3; e < c; e++, i += 3) {
            let c = s[e],
              l = c.matrix;
            (l.tx += (m - l.tx) * n), (l.ty += (h - l.ty) * r);
            let f = p[i],
              v = p[i + 1],
              y = f - m,
              b = v - h;
            if (o) {
              let n = d[e];
              if (n != 0) {
                let e = (Math.sqrt(y * y + b * b) / n - 1) * t + 1;
                (l.a *= e), (l.b *= e);
              }
            }
            if (((m = f), (h = v), t > 0)) {
              let n = l.a,
                r = l.c,
                o = l.b,
                s = l.d,
                d = 0,
                f = 0,
                v = 0;
              if (
                ((d = a
                  ? p[i - 1]
                  : u[e + 1] == 0
                  ? p[i + 2]
                  : Math.atan2(b, y)),
                (d -= Math.atan2(o, n)),
                _)
              ) {
                (f = Math.cos(d)), (v = Math.sin(d));
                let e = c.data.length;
                (m += (e * (f * n - v * o) - y) * t),
                  (h += (e * (v * n + f * o) - b) * t);
              } else d += g;
              d > W.PI ? (d -= W.PI2) : d < -W.PI && (d += W.PI2),
                (d *= t),
                (f = Math.cos(d)),
                (v = Math.sin(d)),
                (l.a = f * n - v * o),
                (l.c = f * r - v * s),
                (l.b = v * n + f * o),
                (l.d = v * r + f * s);
            }
            c.updateAppliedTransform();
          }
        }
        computeWorldPositions(e, t, n) {
          let r = this.target,
            i = this.position,
            a = this.spaces,
            o = G.setArraySize(this.positions, t * 3 + 2),
            s = this.world,
            c = e.closed,
            l = e.worldVerticesLength,
            u = l / 6,
            d = bl.NONE;
          if (!e.constantSpeed) {
            let f = e.lengths;
            u -= c ? 1 : 2;
            let p = f[u];
            this.data.positionMode == ss.Percent && (i *= p);
            let m;
            switch (this.data.spacingMode) {
              case X.Percent:
                m = p;
                break;
              case X.Proportional:
                m = p / t;
                break;
              default:
                m = 1;
            }
            s = G.setArraySize(this.world, 8);
            for (let h = 0, g = 0, _ = 0; h < t; h++, g += 3) {
              let t = a[h] * m;
              i += t;
              let v = i;
              if (c) (v %= p), v < 0 && (v += p), (_ = 0);
              else if (v < 0) {
                d != bl.BEFORE &&
                  ((d = bl.BEFORE), e.computeWorldVertices(r, 2, 4, s, 0, 2)),
                  this.addBeforePosition(v, s, 0, o, g);
                continue;
              } else if (v > p) {
                d != bl.AFTER &&
                  ((d = bl.AFTER),
                  e.computeWorldVertices(r, l - 6, 4, s, 0, 2)),
                  this.addAfterPosition(v - p, s, 0, o, g);
                continue;
              }
              for (; ; _++) {
                let e = f[_];
                if (!(v > e)) {
                  if (_ == 0) v /= e;
                  else {
                    let t = f[_ - 1];
                    v = (v - t) / (e - t);
                  }
                  break;
                }
              }
              _ != d &&
                ((d = _),
                c && _ == u
                  ? (e.computeWorldVertices(r, l - 4, 4, s, 0, 2),
                    e.computeWorldVertices(r, 0, 4, s, 4, 2))
                  : e.computeWorldVertices(r, _ * 6 + 2, 8, s, 0, 2)),
                this.addCurvePosition(
                  v,
                  s[0],
                  s[1],
                  s[2],
                  s[3],
                  s[4],
                  s[5],
                  s[6],
                  s[7],
                  o,
                  g,
                  n || (h > 0 && t == 0)
                );
            }
            return o;
          }
          c
            ? ((l += 2),
              (s = G.setArraySize(this.world, l)),
              e.computeWorldVertices(r, 2, l - 4, s, 0, 2),
              e.computeWorldVertices(r, 0, 2, s, l - 4, 2),
              (s[l - 2] = s[0]),
              (s[l - 1] = s[1]))
            : (u--,
              (l -= 4),
              (s = G.setArraySize(this.world, l)),
              e.computeWorldVertices(r, 2, l, s, 0, 2));
          let f = G.setArraySize(this.curves, u),
            p = 0,
            m = s[0],
            h = s[1],
            g = 0,
            _ = 0,
            v = 0,
            y = 0,
            b = 0,
            x = 0,
            S = 0,
            C = 0,
            w = 0,
            T = 0,
            E = 0,
            D = 0,
            O = 0,
            k = 0;
          for (let e = 0, t = 2; e < u; e++, t += 6)
            (g = s[t]),
              (_ = s[t + 1]),
              (v = s[t + 2]),
              (y = s[t + 3]),
              (b = s[t + 4]),
              (x = s[t + 5]),
              (S = (m - g * 2 + v) * 0.1875),
              (C = (h - _ * 2 + y) * 0.1875),
              (w = ((g - v) * 3 - m + b) * 0.09375),
              (T = ((_ - y) * 3 - h + x) * 0.09375),
              (E = S * 2 + w),
              (D = C * 2 + T),
              (O = (g - m) * 0.75 + S + w * 0.16666667),
              (k = (_ - h) * 0.75 + C + T * 0.16666667),
              (p += Math.sqrt(O * O + k * k)),
              (O += E),
              (k += D),
              (E += w),
              (D += T),
              (p += Math.sqrt(O * O + k * k)),
              (O += E),
              (k += D),
              (p += Math.sqrt(O * O + k * k)),
              (O += E + w),
              (k += D + T),
              (p += Math.sqrt(O * O + k * k)),
              (f[e] = p),
              (m = b),
              (h = x);
          this.data.positionMode == ss.Percent && (i *= p);
          let A;
          switch (this.data.spacingMode) {
            case X.Percent:
              A = p;
              break;
            case X.Proportional:
              A = p / t;
              break;
            default:
              A = 1;
          }
          let j = this.segments,
            M = 0;
          for (let e = 0, r = 0, u = 0, ee = 0; e < t; e++, r += 3) {
            let t = a[e] * A;
            i += t;
            let N = i;
            if (c) (N %= p), N < 0 && (N += p), (u = 0);
            else if (N < 0) {
              this.addBeforePosition(N, s, 0, o, r);
              continue;
            } else if (N > p) {
              this.addAfterPosition(N - p, s, l - 4, o, r);
              continue;
            }
            for (; ; u++) {
              let e = f[u];
              if (!(N > e)) {
                if (u == 0) N /= e;
                else {
                  let t = f[u - 1];
                  N = (N - t) / (e - t);
                }
                break;
              }
            }
            if (u != d) {
              d = u;
              let e = u * 6;
              for (
                m = s[e],
                  h = s[e + 1],
                  g = s[e + 2],
                  _ = s[e + 3],
                  v = s[e + 4],
                  y = s[e + 5],
                  b = s[e + 6],
                  x = s[e + 7],
                  S = (m - g * 2 + v) * 0.03,
                  C = (h - _ * 2 + y) * 0.03,
                  w = ((g - v) * 3 - m + b) * 0.006,
                  T = ((_ - y) * 3 - h + x) * 0.006,
                  E = S * 2 + w,
                  D = C * 2 + T,
                  O = (g - m) * 0.3 + S + w * 0.16666667,
                  k = (_ - h) * 0.3 + C + T * 0.16666667,
                  M = Math.sqrt(O * O + k * k),
                  j[0] = M,
                  e = 1;
                e < 8;
                e++
              )
                (O += E),
                  (k += D),
                  (E += w),
                  (D += T),
                  (M += Math.sqrt(O * O + k * k)),
                  (j[e] = M);
              (O += E),
                (k += D),
                (M += Math.sqrt(O * O + k * k)),
                (j[8] = M),
                (O += E + w),
                (k += D + T),
                (M += Math.sqrt(O * O + k * k)),
                (j[9] = M),
                (ee = 0);
            }
            for (N *= M; ; ee++) {
              let e = j[ee];
              if (!(N > e)) {
                if (ee == 0) N /= e;
                else {
                  let t = j[ee - 1];
                  N = ee + (N - t) / (e - t);
                }
                break;
              }
            }
            this.addCurvePosition(
              N * 0.1,
              m,
              h,
              g,
              _,
              v,
              y,
              b,
              x,
              o,
              r,
              n || (e > 0 && t == 0)
            );
          }
          return o;
        }
        addBeforePosition(e, t, n, r, i) {
          let a = t[n],
            o = t[n + 1],
            s = t[n + 2] - a,
            c = t[n + 3] - o,
            l = Math.atan2(c, s);
          (r[i] = a + e * Math.cos(l)),
            (r[i + 1] = o + e * Math.sin(l)),
            (r[i + 2] = l);
        }
        addAfterPosition(e, t, n, r, i) {
          let a = t[n + 2],
            o = t[n + 3],
            s = a - t[n],
            c = o - t[n + 1],
            l = Math.atan2(c, s);
          (r[i] = a + e * Math.cos(l)),
            (r[i + 1] = o + e * Math.sin(l)),
            (r[i + 2] = l);
        }
        addCurvePosition(e, t, n, r, i, a, o, s, c, l, u, d) {
          if (e == 0 || isNaN(e)) {
            (l[u] = t), (l[u + 1] = n), (l[u + 2] = Math.atan2(i - n, r - t));
            return;
          }
          let f = e * e,
            p = f * e,
            m = 1 - e,
            h = m * m,
            g = h * m,
            _ = m * e,
            v = _ * 3,
            y = m * v,
            b = v * e,
            x = t * g + r * y + a * b + s * p,
            S = n * g + i * y + o * b + c * p;
          (l[u] = x),
            (l[u + 1] = S),
            d &&
              (e < 0.001
                ? (l[u + 2] = Math.atan2(i - n, r - t))
                : (l[u + 2] = Math.atan2(
                    S - (n * h + i * _ * 2 + o * f),
                    x - (t * h + r * _ * 2 + a * f)
                  )));
        }
      }),
      (xl = bl),
      (xl.NONE = -1),
      (xl.BEFORE = -2),
      (xl.AFTER = -3),
      (xl.epsilon = 1e-5);
  }))();
}
var Cl;
function wl() {
  return (wl = t(() => {
    K(),
      Us(),
      (Cl = class {
        constructor(e, t) {
          if (
            ((this.darkColor = null),
            (this.attachment = null),
            (this.attachmentState = 0),
            (this.sequenceIndex = -1),
            (this.deform = []),
            !e)
          )
            throw Error(`data cannot be null.`);
          if (!t) throw Error(`bone cannot be null.`);
          (this.data = e),
            (this.bone = t),
            (this.color = new U()),
            (this.darkColor = e.darkColor ? new U() : null),
            this.setToSetupPose(),
            (this.blendMode = this.data.blendMode);
        }
        getSkeleton() {
          return this.bone.skeleton;
        }
        getAttachment() {
          return this.attachment;
        }
        setAttachment(e) {
          this.attachment != e &&
            ((!(e instanceof Hs) ||
              !(this.attachment instanceof Hs) ||
              e.timelineAttachment != this.attachment.timelineAttachment) &&
              (this.deform.length = 0),
            (this.attachment = e),
            (this.sequenceIndex = -1));
        }
        setToSetupPose() {
          this.color.setFromColor(this.data.color),
            this.darkColor && this.darkColor.setFromColor(this.data.darkColor),
            this.data.attachmentName
              ? ((this.attachment = null),
                this.setAttachment(
                  this.bone.skeleton.getAttachment(
                    this.data.index,
                    this.data.attachmentName
                  )
                ))
              : (this.attachment = null);
        }
      });
  }))();
}
var Tl;
function El() {
  return (El = t(() => {
    K(),
      (Tl = class {
        constructor(e, t) {
          if (
            ((this.mixRotate = 0),
            (this.mixX = 0),
            (this.mixY = 0),
            (this.mixScaleX = 0),
            (this.mixScaleY = 0),
            (this.mixShearY = 0),
            (this.temp = new Os()),
            (this.active = !1),
            !e)
          )
            throw Error(`data cannot be null.`);
          if (!t) throw Error(`skeleton cannot be null.`);
          (this.data = e),
            (this.mixRotate = e.mixRotate),
            (this.mixX = e.mixX),
            (this.mixY = e.mixY),
            (this.mixScaleX = e.mixScaleX),
            (this.mixScaleY = e.mixScaleY),
            (this.mixShearY = e.mixShearY),
            (this.bones = []);
          for (let n = 0; n < e.bones.length; n++) {
            let r = t.findBone(e.bones[n].name);
            if (!r) throw Error(`Couldn't find bone ${e.bones[n].name}.`);
            this.bones.push(r);
          }
          let n = t.findBone(e.target.name);
          if (!n) throw Error(`Couldn't find target bone ${e.target.name}.`);
          this.target = n;
        }
        isActive() {
          return this.active;
        }
        update() {
          (this.mixRotate != 0 ||
            this.mixX != 0 ||
            this.mixY != 0 ||
            this.mixScaleX != 0 ||
            this.mixScaleX != 0 ||
            this.mixShearY != 0) &&
            (this.data.local
              ? this.data.relative
                ? this.applyRelativeLocal()
                : this.applyAbsoluteLocal()
              : this.data.relative
              ? this.applyRelativeWorld()
              : this.applyAbsoluteWorld());
        }
        applyAbsoluteWorld() {
          let e = this.mixRotate,
            t = this.mixX,
            n = this.mixY,
            r = this.mixScaleX,
            i = this.mixScaleY,
            a = this.mixShearY,
            o = t != 0 || n != 0,
            s = this.target,
            c = s.matrix,
            l = c.a,
            u = c.c,
            d = c.b,
            f = c.d,
            p = l * f - u * d > 0 ? W.degRad : -W.degRad,
            m = this.data.offsetRotation * p,
            h = this.data.offsetShearY * p,
            g = this.bones;
          for (let c = 0, p = g.length; c < p; c++) {
            let p = g[c],
              _ = p.matrix;
            if (e != 0) {
              let t = _.a,
                n = _.c,
                r = _.b,
                i = _.d,
                a = Math.atan2(d, l) - Math.atan2(r, t) + m;
              a > W.PI ? (a -= W.PI2) : a < -W.PI && (a += W.PI2), (a *= e);
              let o = Math.cos(a),
                s = Math.sin(a);
              (_.a = o * t - s * r),
                (_.c = o * n - s * i),
                (_.b = s * t + o * r),
                (_.d = s * n + o * i);
            }
            if (o) {
              let e = this.temp;
              s.localToWorld(e.set(this.data.offsetX, this.data.offsetY)),
                (_.tx += (e.x - _.tx) * t),
                (_.ty += (e.y - _.ty) * n);
            }
            if (r != 0) {
              let e = Math.sqrt(_.a * _.a + _.b * _.b);
              e != 0 &&
                (e =
                  (e +
                    (Math.sqrt(l * l + d * d) - e + this.data.offsetScaleX) *
                      r) /
                  e),
                (_.a *= e),
                (_.b *= e);
            }
            if (i != 0) {
              let e = Math.sqrt(_.c * _.c + _.d * _.d);
              e != 0 &&
                (e =
                  (e +
                    (Math.sqrt(u * u + f * f) - e + this.data.offsetScaleY) *
                      i) /
                  e),
                (_.c *= e),
                (_.d *= e);
            }
            if (a > 0) {
              let e = _.c,
                t = _.d,
                n = Math.atan2(t, e),
                r =
                  Math.atan2(f, u) -
                  Math.atan2(d, l) -
                  (n - Math.atan2(_.b, _.a));
              r > W.PI ? (r -= W.PI2) : r < -W.PI && (r += W.PI2),
                (r = n + (r + h) * a);
              let i = Math.sqrt(e * e + t * t);
              (_.c = Math.cos(r) * i), (_.d = Math.sin(r) * i);
            }
            p.updateAppliedTransform();
          }
        }
        applyRelativeWorld() {
          let e = this.mixRotate,
            t = this.mixX,
            n = this.mixY,
            r = this.mixScaleX,
            i = this.mixScaleY,
            a = this.mixShearY,
            o = t != 0 || n != 0,
            s = this.target,
            c = s.matrix,
            l = c.a,
            u = c.c,
            d = c.b,
            f = c.d,
            p = l * f - u * d > 0 ? W.degRad : -W.degRad,
            m = this.data.offsetRotation * p,
            h = this.data.offsetShearY * p,
            g = this.bones;
          for (let c = 0, p = g.length; c < p; c++) {
            let p = g[c],
              _ = p.matrix;
            if (e != 0) {
              let t = _.a,
                n = _.c,
                r = _.b,
                i = _.d,
                a = Math.atan2(d, l) + m;
              a > W.PI ? (a -= W.PI2) : a < -W.PI && (a += W.PI2), (a *= e);
              let o = Math.cos(a),
                s = Math.sin(a);
              (_.a = o * t - s * r),
                (_.c = o * n - s * i),
                (_.b = s * t + o * r),
                (_.d = s * n + o * i);
            }
            if (o) {
              let e = this.temp;
              s.localToWorld(e.set(this.data.offsetX, this.data.offsetY)),
                (_.tx += e.x * t),
                (_.ty += e.y * n);
            }
            if (r != 0) {
              let e =
                (Math.sqrt(l * l + d * d) - 1 + this.data.offsetScaleX) * r + 1;
              (_.a *= e), (_.b *= e);
            }
            if (i != 0) {
              let e =
                (Math.sqrt(u * u + f * f) - 1 + this.data.offsetScaleY) * i + 1;
              (_.c *= e), (_.d *= e);
            }
            if (a > 0) {
              let e = Math.atan2(f, u) - Math.atan2(d, l);
              e > W.PI ? (e -= W.PI2) : e < -W.PI && (e += W.PI2);
              let t = _.c,
                n = _.d;
              e = Math.atan2(n, t) + (e - W.PI / 2 + h) * a;
              let r = Math.sqrt(t * t + n * n);
              (_.c = Math.cos(e) * r), (_.d = Math.sin(e) * r);
            }
            p.updateAppliedTransform();
          }
        }
        applyAbsoluteLocal() {
          let e = this.mixRotate,
            t = this.mixX,
            n = this.mixY,
            r = this.mixScaleX,
            i = this.mixScaleY,
            a = this.mixShearY,
            o = this.target,
            s = this.bones;
          for (let c = 0, l = s.length; c < l; c++) {
            let l = s[c],
              u = l.arotation;
            if (e != 0) {
              let t = o.arotation - u + this.data.offsetRotation;
              (t -= (16384 - ((16384.499999999996 - t / 360) | 0)) * 360),
                (u += t * e);
            }
            let d = l.ax,
              f = l.ay;
            (d += (o.ax - d + this.data.offsetX) * t),
              (f += (o.ay - f + this.data.offsetY) * n);
            let p = l.ascaleX,
              m = l.ascaleY;
            r != 0 &&
              p != 0 &&
              (p = (p + (o.ascaleX - p + this.data.offsetScaleX) * r) / p),
              i != 0 &&
                m != 0 &&
                (m = (m + (o.ascaleY - m + this.data.offsetScaleY) * i) / m);
            let h = l.ashearY;
            if (a != 0) {
              let e = o.ashearY - h + this.data.offsetShearY;
              (e -= (16384 - ((16384.499999999996 - e / 360) | 0)) * 360),
                (h += e * a);
            }
            l.updateWorldTransformWith(d, f, u, p, m, l.ashearX, h);
          }
        }
        applyRelativeLocal() {
          let e = this.mixRotate,
            t = this.mixX,
            n = this.mixY,
            r = this.mixScaleX,
            i = this.mixScaleY,
            a = this.mixShearY,
            o = this.target,
            s = this.bones;
          for (let c = 0, l = s.length; c < l; c++) {
            let l = s[c],
              u = l.arotation + (o.arotation + this.data.offsetRotation) * e,
              d = l.ax + (o.ax + this.data.offsetX) * t,
              f = l.ay + (o.ay + this.data.offsetY) * n,
              p =
                l.ascaleX * ((o.ascaleX - 1 + this.data.offsetScaleX) * r + 1),
              m =
                l.ascaleY * ((o.ascaleY - 1 + this.data.offsetScaleY) * i + 1),
              h = l.ashearY + (o.ashearY + this.data.offsetShearY) * a;
            l.updateWorldTransformWith(d, f, u, p, m, l.ashearX, h);
          }
        }
      });
  }))();
}
var Dl, Ol;
function kl() {
  return (kl = t(() => {
    Us(),
      K(),
      Ys(),
      Zs(),
      tc(),
      oc(),
      al(),
      wl(),
      hl(),
      El(),
      Sl(),
      (Dl = class {
        constructor(e) {
          if (
            ((this._updateCache = []),
            (this.skin = null),
            (this.scaleX = 1),
            (this.scaleY = 1),
            (this.x = 0),
            (this.y = 0),
            !e)
          )
            throw Error(`data cannot be null.`);
          (this.data = e), (this.bones = []);
          for (let t = 0; t < e.bones.length; t++) {
            let n = e.bones[t],
              r;
            if (!n.parent) r = new il(n, this, null);
            else {
              let e = this.bones[n.parent.index];
              (r = new il(n, this, e)), e.children.push(r);
            }
            this.bones.push(r);
          }
          (this.slots = []), (this.drawOrder = []);
          for (let t = 0; t < e.slots.length; t++) {
            let n = e.slots[t],
              r = this.bones[n.boneData.index],
              i = new Cl(n, r);
            this.slots.push(i), this.drawOrder.push(i);
          }
          this.ikConstraints = [];
          for (let t = 0; t < e.ikConstraints.length; t++) {
            let n = e.ikConstraints[t];
            this.ikConstraints.push(new ml(n, this));
          }
          this.transformConstraints = [];
          for (let t = 0; t < e.transformConstraints.length; t++) {
            let n = e.transformConstraints[t];
            this.transformConstraints.push(new Tl(n, this));
          }
          this.pathConstraints = [];
          for (let t = 0; t < e.pathConstraints.length; t++) {
            let n = e.pathConstraints[t];
            this.pathConstraints.push(new xl(n, this));
          }
          (this.color = new U(1, 1, 1, 1)), this.updateCache();
        }
        updateCache() {
          let e = this._updateCache;
          e.length = 0;
          let t = this.bones;
          for (let e = 0, n = t.length; e < n; e++) {
            let n = t[e];
            (n.sorted = n.data.skinRequired), (n.active = !n.sorted);
          }
          if (this.skin) {
            let e = this.skin.bones;
            for (let t = 0, n = this.skin.bones.length; t < n; t++) {
              let n = this.bones[e[t].index];
              do (n.sorted = !1), (n.active = !0), (n = n.parent);
              while (n);
            }
          }
          let n = this.ikConstraints,
            r = this.transformConstraints,
            i = this.pathConstraints,
            a = n.length,
            o = r.length,
            s = i.length,
            c = a + o + s;
          outer: for (let e = 0; e < c; e++) {
            for (let t = 0; t < a; t++) {
              let r = n[t];
              if (r.data.order == e) {
                this.sortIkConstraint(r);
                continue outer;
              }
            }
            for (let t = 0; t < o; t++) {
              let n = r[t];
              if (n.data.order == e) {
                this.sortTransformConstraint(n);
                continue outer;
              }
            }
            for (let t = 0; t < s; t++) {
              let n = i[t];
              if (n.data.order == e) {
                this.sortPathConstraint(n);
                continue outer;
              }
            }
          }
          for (let e = 0, n = t.length; e < n; e++) this.sortBone(t[e]);
        }
        sortIkConstraint(e) {
          if (
            ((e.active =
              e.target.isActive() &&
              (!e.data.skinRequired ||
                (this.skin && G.contains(this.skin.constraints, e.data, !0)))),
            !e.active)
          )
            return;
          let t = e.target;
          this.sortBone(t);
          let n = e.bones,
            r = n[0];
          if ((this.sortBone(r), n.length == 1))
            this._updateCache.push(e), this.sortReset(r.children);
          else {
            let t = n[n.length - 1];
            this.sortBone(t),
              this._updateCache.push(e),
              this.sortReset(r.children),
              (t.sorted = !0);
          }
        }
        sortPathConstraint(e) {
          if (
            ((e.active =
              e.target.bone.isActive() &&
              (!e.data.skinRequired ||
                (this.skin && G.contains(this.skin.constraints, e.data, !0)))),
            !e.active)
          )
            return;
          let t = e.target,
            n = t.data.index,
            r = t.bone;
          this.skin && this.sortPathConstraintAttachment(this.skin, n, r),
            this.data.defaultSkin &&
              this.data.defaultSkin != this.skin &&
              this.sortPathConstraintAttachment(this.data.defaultSkin, n, r);
          for (let e = 0, t = this.data.skins.length; e < t; e++)
            this.sortPathConstraintAttachment(this.data.skins[e], n, r);
          let i = t.getAttachment();
          i instanceof Xs && this.sortPathConstraintAttachmentWith(i, r);
          let a = e.bones,
            o = a.length;
          for (let e = 0; e < o; e++) this.sortBone(a[e]);
          this._updateCache.push(e);
          for (let e = 0; e < o; e++) this.sortReset(a[e].children);
          for (let e = 0; e < o; e++) a[e].sorted = !0;
        }
        sortTransformConstraint(e) {
          if (
            ((e.active =
              e.target.isActive() &&
              (!e.data.skinRequired ||
                (this.skin && G.contains(this.skin.constraints, e.data, !0)))),
            !e.active)
          )
            return;
          this.sortBone(e.target);
          let t = e.bones,
            n = t.length;
          if (e.data.local)
            for (let e = 0; e < n; e++) {
              let n = t[e];
              this.sortBone(n.parent), this.sortBone(n);
            }
          else for (let e = 0; e < n; e++) this.sortBone(t[e]);
          this._updateCache.push(e);
          for (let e = 0; e < n; e++) this.sortReset(t[e].children);
          for (let e = 0; e < n; e++) t[e].sorted = !0;
        }
        sortPathConstraintAttachment(e, t, n) {
          let r = e.attachments[t];
          if (r)
            for (let e in r) this.sortPathConstraintAttachmentWith(r[e], n);
        }
        sortPathConstraintAttachmentWith(e, t) {
          if (!(e instanceof Xs)) return;
          let n = e.bones;
          if (!n) this.sortBone(t);
          else {
            let e = this.bones;
            for (let t = 0, r = n.length; t < r; ) {
              let r = n[t++];
              for (r += t; t < r; ) this.sortBone(e[n[t++]]);
            }
          }
        }
        sortBone(e) {
          if (!e || e.sorted) return;
          let t = e.parent;
          t && this.sortBone(t), (e.sorted = !0), this._updateCache.push(e);
        }
        sortReset(e) {
          for (let t = 0, n = e.length; t < n; t++) {
            let n = e[t];
            n.active &&
              (n.sorted && this.sortReset(n.children), (n.sorted = !1));
          }
        }
        updateWorldTransform() {
          let e = this.bones;
          for (let t = 0, n = e.length; t < n; t++) {
            let n = e[t];
            (n.ax = n.x),
              (n.ay = n.y),
              (n.arotation = n.rotation),
              (n.ascaleX = n.scaleX),
              (n.ascaleY = n.scaleY),
              (n.ashearX = n.shearX),
              (n.ashearY = n.shearY);
          }
          let t = this._updateCache;
          for (let e = 0, n = t.length; e < n; e++) t[e].update();
        }
        updateWorldTransformWith(e) {
          let t = this.getRootBone(),
            n = e.matrix.a,
            r = e.matrix.c,
            i = e.matrix.b,
            a = e.matrix.d;
          (t.matrix.tx = n * this.x + r * this.y + e.worldX),
            (t.matrix.ty = i * this.x + a * this.y + e.worldY);
          let o = t.rotation + 90 + t.shearY,
            s = W.cosDeg(t.rotation + t.shearX) * t.scaleX,
            c = W.cosDeg(o) * t.scaleY,
            l = W.sinDeg(t.rotation + t.shearX) * t.scaleX,
            u = W.sinDeg(o) * t.scaleY,
            d = this.scaleX,
            f = js.yDown ? -this.scaleY : this.scaleY;
          (t.matrix.a = (n * s + r * l) * d),
            (t.matrix.c = (n * c + r * u) * d),
            (t.matrix.b = (i * s + a * l) * f),
            (t.matrix.d = (i * c + a * u) * f);
          let p = this._updateCache;
          for (let e = 0, n = p.length; e < n; e++) {
            let n = p[e];
            n != t && n.update();
          }
        }
        setToSetupPose() {
          this.setBonesToSetupPose(), this.setSlotsToSetupPose();
        }
        setBonesToSetupPose() {
          let e = this.bones;
          for (let t = 0, n = e.length; t < n; t++) e[t].setToSetupPose();
          let t = this.ikConstraints;
          for (let e = 0, n = t.length; e < n; e++) {
            let n = t[e];
            (n.mix = n.data.mix),
              (n.softness = n.data.softness),
              (n.bendDirection = n.data.bendDirection),
              (n.compress = n.data.compress),
              (n.stretch = n.data.stretch);
          }
          let n = this.transformConstraints;
          for (let e = 0, t = n.length; e < t; e++) {
            let t = n[e],
              r = t.data;
            (t.mixRotate = r.mixRotate),
              (t.mixX = r.mixX),
              (t.mixY = r.mixY),
              (t.mixScaleX = r.mixScaleX),
              (t.mixScaleY = r.mixScaleY),
              (t.mixShearY = r.mixShearY);
          }
          let r = this.pathConstraints;
          for (let e = 0, t = r.length; e < t; e++) {
            let t = r[e],
              n = t.data;
            (t.position = n.position),
              (t.spacing = n.spacing),
              (t.mixRotate = n.mixRotate),
              (t.mixX = n.mixX),
              (t.mixY = n.mixY);
          }
        }
        setSlotsToSetupPose() {
          let e = this.slots;
          G.arrayCopy(e, 0, this.drawOrder, 0, e.length);
          for (let t = 0, n = e.length; t < n; t++) e[t].setToSetupPose();
        }
        getRootBone() {
          return this.bones.length == 0 ? null : this.bones[0];
        }
        findBone(e) {
          if (!e) throw Error(`boneName cannot be null.`);
          let t = this.bones;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (r.data.name == e) return r;
          }
          return null;
        }
        findBoneIndex(e) {
          if (!e) throw Error(`boneName cannot be null.`);
          let t = this.bones;
          for (let n = 0, r = t.length; n < r; n++)
            if (t[n].data.name == e) return n;
          return -1;
        }
        findSlot(e) {
          if (!e) throw Error(`slotName cannot be null.`);
          let t = this.slots;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (r.data.name == e) return r;
          }
          return null;
        }
        findSlotIndex(e) {
          if (!e) throw Error(`slotName cannot be null.`);
          let t = this.slots;
          for (let n = 0, r = t.length; n < r; n++)
            if (t[n].data.name == e) return n;
          return -1;
        }
        setSkinByName(e) {
          let t = this.data.findSkin(e);
          if (!t) throw Error(`Skin not found: ${e}`);
          this.setSkin(t);
        }
        setSkin(e) {
          if (e != this.skin) {
            if (e)
              if (this.skin) e.attachAll(this, this.skin);
              else {
                let t = this.slots;
                for (let n = 0, r = t.length; n < r; n++) {
                  let r = t[n],
                    i = r.data.attachmentName;
                  if (i) {
                    let t = e.getAttachment(n, i);
                    t && r.setAttachment(t);
                  }
                }
              }
            (this.skin = e), this.updateCache();
          }
        }
        getAttachmentByName(e, t) {
          let n = this.data.findSlot(e);
          if (!n) throw Error(`Can't find slot with name ${e}`);
          return this.getAttachment(n.index, t);
        }
        getAttachment(e, t) {
          if (!t) throw Error(`attachmentName cannot be null.`);
          if (this.skin) {
            let n = this.skin.getAttachment(e, t);
            if (n) return n;
          }
          return this.data.defaultSkin
            ? this.data.defaultSkin.getAttachment(e, t)
            : null;
        }
        setAttachment(e, t) {
          if (!e) throw Error(`slotName cannot be null.`);
          let n = this.slots;
          for (let r = 0, i = n.length; r < i; r++) {
            let i = n[r];
            if (i.data.name == e) {
              let n = null;
              if (t && ((n = this.getAttachment(r, t)), !n))
                throw Error(`Attachment not found: ${t}, for slot: ${e}`);
              i.setAttachment(n);
              return;
            }
          }
          throw Error(`Slot not found: ${e}`);
        }
        findIkConstraint(e) {
          if (!e) throw Error(`constraintName cannot be null.`);
          let t = this.ikConstraints;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (r.data.name == e) return r;
          }
          return null;
        }
        findTransformConstraint(e) {
          if (!e) throw Error(`constraintName cannot be null.`);
          let t = this.transformConstraints;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (r.data.name == e) return r;
          }
          return null;
        }
        findPathConstraint(e) {
          if (!e) throw Error(`constraintName cannot be null.`);
          let t = this.pathConstraints;
          for (let n = 0, r = t.length; n < r; n++) {
            let r = t[n];
            if (r.data.name == e) return r;
          }
          return null;
        }
        getBoundsRect() {
          let e = new Os(),
            t = new Os();
          return (
            this.getBounds(e, t), { x: e.x, y: e.y, width: t.x, height: t.y }
          );
        }
        getBounds(e, t, n = [, ,]) {
          if (!e) throw Error(`offset cannot be null.`);
          if (!t) throw Error(`size cannot be null.`);
          let r = this.drawOrder,
            i = 1 / 0,
            a = 1 / 0,
            o = -1 / 0,
            s = -1 / 0;
          for (let e = 0, t = r.length; e < t; e++) {
            let t = r[e];
            if (!t.bone.active) continue;
            let c = 0,
              l = null,
              u = t.getAttachment();
            if (u instanceof q)
              (c = 8),
                (l = G.setArraySize(n, c, 0)),
                u.computeWorldVertices(t, l, 0, 2);
            else if (u instanceof Js) {
              let e = u;
              (c = e.worldVerticesLength),
                (l = G.setArraySize(n, c, 0)),
                e.computeWorldVertices(t, 0, c, l, 0, 2);
            }
            if (l)
              for (let e = 0, t = l.length; e < t; e += 2) {
                let t = l[e],
                  n = l[e + 1];
                (i = Math.min(i, t)),
                  (a = Math.min(a, n)),
                  (o = Math.max(o, t)),
                  (s = Math.max(s, n));
              }
          }
          e.set(i, a), t.set(o - i, s - a);
        }
        get flipX() {
          return this.scaleX == -1;
        }
        set flipX(e) {
          Dl.deprecatedWarning1 ||
            ((Dl.deprecatedWarning1 = !0),
            console.warn(
              "Spine Deprecation Warning: `Skeleton.flipX/flipY` was deprecated, please use scaleX/scaleY"
            )),
            (this.scaleX = e ? 1 : -1);
        }
        get flipY() {
          return this.scaleY == -1;
        }
        set flipY(e) {
          Dl.deprecatedWarning1 ||
            ((Dl.deprecatedWarning1 = !0),
            console.warn(
              "Spine Deprecation Warning: `Skeleton.flipX/flipY` was deprecated, please use scaleX/scaleY"
            )),
            (this.scaleY = e ? 1 : -1);
        }
      }),
      (Ol = Dl),
      (Ol.deprecatedWarning1 = !1);
  }))();
}
var Al;
function jl() {
  return (jl = t(() => {
    Al = class {
      constructor() {
        (this.name = null),
          (this.bones = []),
          (this.slots = []),
          (this.skins = []),
          (this.defaultSkin = null),
          (this.events = []),
          (this.animations = []),
          (this.ikConstraints = []),
          (this.transformConstraints = []),
          (this.pathConstraints = []),
          (this.x = 0),
          (this.y = 0),
          (this.width = 0),
          (this.height = 0),
          (this.version = null),
          (this.hash = null),
          (this.fps = 0),
          (this.imagesPath = null),
          (this.audioPath = null);
      }
      findBone(e) {
        if (!e) throw Error(`boneName cannot be null.`);
        let t = this.bones;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findBoneIndex(e) {
        if (!e) throw Error(`boneName cannot be null.`);
        let t = this.bones;
        for (let n = 0, r = t.length; n < r; n++) if (t[n].name == e) return n;
        return -1;
      }
      findSlot(e) {
        if (!e) throw Error(`slotName cannot be null.`);
        let t = this.slots;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findSlotIndex(e) {
        if (!e) throw Error(`slotName cannot be null.`);
        let t = this.slots;
        for (let n = 0, r = t.length; n < r; n++) if (t[n].name == e) return n;
        return -1;
      }
      findSkin(e) {
        if (!e) throw Error(`skinName cannot be null.`);
        let t = this.skins;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findEvent(e) {
        if (!e) throw Error(`eventDataName cannot be null.`);
        let t = this.events;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findAnimation(e) {
        if (!e) throw Error(`animationName cannot be null.`);
        let t = this.animations;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findIkConstraint(e) {
        if (!e) throw Error(`constraintName cannot be null.`);
        let t = this.ikConstraints;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findTransformConstraint(e) {
        if (!e) throw Error(`constraintName cannot be null.`);
        let t = this.transformConstraints;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findPathConstraint(e) {
        if (!e) throw Error(`constraintName cannot be null.`);
        let t = this.pathConstraints;
        for (let n = 0, r = t.length; n < r; n++) {
          let r = t[n];
          if (r.name == e) return r;
        }
        return null;
      }
      findPathConstraintIndex(e) {
        if (e == null) throw Error(`pathConstraintName cannot be null.`);
        let t = this.pathConstraints;
        for (let n = 0, r = t.length; n < r; n++) if (t[n].name == e) return n;
        return -1;
      }
    };
  }))();
}
var Ml;
function Nl() {
  return (Nl = t(() => {
    K(),
      R(),
      (Ml = class {
        constructor(e, t, n) {
          if (
            ((this.index = 0),
            (this.color = new U(1, 1, 1, 1)),
            (this.darkColor = null),
            (this.attachmentName = null),
            (this.blendMode = F.NORMAL),
            e < 0)
          )
            throw Error(`index must be >= 0.`);
          if (!t) throw Error(`name cannot be null.`);
          if (!n) throw Error(`boneData cannot be null.`);
          (this.index = e), (this.name = t), (this.boneData = n);
        }
      });
  }))();
}
var Pl;
function Fl() {
  return (Fl = t(() => {
    ll(),
      (Pl = class extends cl {
        constructor(e) {
          super(e, 0, !1),
            (this.bones = []),
            (this._target = null),
            (this.mixRotate = 0),
            (this.mixX = 0),
            (this.mixY = 0),
            (this.mixScaleX = 0),
            (this.mixScaleY = 0),
            (this.mixShearY = 0),
            (this.offsetRotation = 0),
            (this.offsetX = 0),
            (this.offsetY = 0),
            (this.offsetScaleX = 0),
            (this.offsetScaleY = 0),
            (this.offsetShearY = 0),
            (this.relative = !1),
            (this.local = !1);
        }
        set target(e) {
          this._target = e;
        }
        get target() {
          if (this._target) return this._target;
          throw Error(`BoneData not set.`);
        }
      });
  }))();
}
var Il, Ll;
function Rl() {
  return (Rl = t(() => {
    Us(),
      K(),
      Ys(),
      tc(),
      oc(),
      (Il = class {
        constructor(e, t, n) {
          (this.slotIndex = e), (this.name = t), (this.attachment = n);
        }
      }),
      (Ll = class {
        constructor(e) {
          if (
            ((this.attachments = []),
            (this.bones = []),
            (this.constraints = []),
            !e)
          )
            throw Error(`name cannot be null.`);
          this.name = e;
        }
        setAttachment(e, t, n) {
          if (!n) throw Error(`attachment cannot be null.`);
          let r = this.attachments;
          e >= r.length && (r.length = e + 1),
            r[e] || (r[e] = {}),
            (r[e][t] = n);
        }
        addSkin(e) {
          for (let t = 0; t < e.bones.length; t++) {
            let n = e.bones[t],
              r = !1;
            for (let e = 0; e < this.bones.length; e++)
              if (this.bones[e] == n) {
                r = !0;
                break;
              }
            r || this.bones.push(n);
          }
          for (let t = 0; t < e.constraints.length; t++) {
            let n = e.constraints[t],
              r = !1;
            for (let e = 0; e < this.constraints.length; e++)
              if (this.constraints[e] == n) {
                r = !0;
                break;
              }
            r || this.constraints.push(n);
          }
          let t = e.getAttachments();
          for (let e = 0; e < t.length; e++) {
            let n = t[e];
            this.setAttachment(n.slotIndex, n.name, n.attachment);
          }
        }
        copySkin(e) {
          for (let t = 0; t < e.bones.length; t++) {
            let n = e.bones[t],
              r = !1;
            for (let e = 0; e < this.bones.length; e++)
              if (this.bones[e] == n) {
                r = !0;
                break;
              }
            r || this.bones.push(n);
          }
          for (let t = 0; t < e.constraints.length; t++) {
            let n = e.constraints[t],
              r = !1;
            for (let e = 0; e < this.constraints.length; e++)
              if (this.constraints[e] == n) {
                r = !0;
                break;
              }
            r || this.constraints.push(n);
          }
          let t = e.getAttachments();
          for (let e = 0; e < t.length; e++) {
            let n = t[e];
            n.attachment &&
              (n.attachment instanceof Js
                ? ((n.attachment = n.attachment.newLinkedMesh()),
                  this.setAttachment(n.slotIndex, n.name, n.attachment))
                : ((n.attachment = n.attachment.copy()),
                  this.setAttachment(n.slotIndex, n.name, n.attachment)));
          }
        }
        getAttachment(e, t) {
          let n = this.attachments[e];
          return n ? n[t] : null;
        }
        removeAttachment(e, t) {
          let n = this.attachments[e];
          n && delete n[t];
        }
        getAttachments() {
          let e = [];
          for (let t = 0; t < this.attachments.length; t++) {
            let n = this.attachments[t];
            if (n)
              for (let r in n) {
                let i = n[r];
                i && e.push(new Il(t, r, i));
              }
          }
          return e;
        }
        getAttachmentsForSlot(e, t) {
          let n = this.attachments[e];
          if (n)
            for (let r in n) {
              let i = n[r];
              i && t.push(new Il(e, r, i));
            }
        }
        clear() {
          (this.attachments.length = 0),
            (this.bones.length = 0),
            (this.constraints.length = 0);
        }
        attachAll(e, t) {
          let n = 0;
          for (let r = 0; r < e.slots.length; r++) {
            let i = e.slots[r],
              a = i.getAttachment();
            if (a && n < t.attachments.length) {
              let e = t.attachments[n];
              for (let t in e)
                if (a == e[t]) {
                  let e = this.getAttachment(n, t);
                  e && i.setAttachment(e);
                  break;
                }
            }
            n++;
          }
        }
      });
  }))();
}
function zl(e, t, n) {
  let r = e.readFloat(),
    i = e.readFloat() * n;
  for (
    let a = 0, o = 0, s = t.getFrameCount() - 1;
    t.setFrame(a, r, i), a != s;
    a++
  ) {
    let s = e.readFloat(),
      c = e.readFloat() * n;
    switch (e.readByte()) {
      case du:
        t.setStepped(a);
        break;
      case fu:
        Z(e, t, o++, a, 0, r, s, i, c, n);
    }
    (r = s), (i = c);
  }
  return t;
}
function Bl(e, t, n) {
  let r = e.readFloat(),
    i = e.readFloat() * n,
    a = e.readFloat() * n;
  for (
    let o = 0, s = 0, c = t.getFrameCount() - 1;
    t.setFrame(o, r, i, a), o != c;
    o++
  ) {
    let c = e.readFloat(),
      l = e.readFloat() * n,
      u = e.readFloat() * n;
    switch (e.readByte()) {
      case du:
        t.setStepped(o);
        break;
      case fu:
        Z(e, t, s++, o, 0, r, c, i, l, n), Z(e, t, s++, o, 1, r, c, a, u, n);
    }
    (r = c), (i = l), (a = u);
  }
  return t;
}
function Z(e, t, n, r, i, a, o, s, c, l) {
  t.setBezier(
    n,
    r,
    i,
    a,
    s,
    e.readFloat(),
    e.readFloat() * l,
    e.readFloat(),
    e.readFloat() * l,
    o,
    c
  );
}
var Vl,
  Hl,
  Ul,
  Wl,
  Gl,
  Kl,
  ql,
  Jl,
  Yl,
  Xl,
  Zl,
  Ql,
  $l,
  eu,
  tu,
  nu,
  ru,
  iu,
  au,
  ou,
  su,
  cu,
  lu,
  uu,
  du,
  fu;
function pu() {
  return (pu = t(() => {
    zc(),
      dl(),
      jl(),
      Nl(),
      sl(),
      _l(),
      Fl(),
      yl(),
      Rl(),
      pl(),
      K(),
      R(),
      Us(),
      tc(),
      oc(),
      (Vl = class {
        constructor(e) {
          (this.ver40 = !1),
            (this.scale = 1),
            (this.linkedMeshes = []),
            (this.attachmentLoader = e);
        }
        readSkeletonData(e) {
          let t = this.scale,
            n = new Al();
          n.name = ``;
          let r = new rs(e),
            i = r.readInt32(),
            a = r.readInt32();
          (n.hash = a == 0 && i == 0 ? null : a.toString(16) + i.toString(16)),
            (n.version = r.readString());
          let o = n.version.substr(0, 3);
          if (o !== `4.0` && o !== `4.1`) {
            let e = `Spine 4.1 loader cant load version ${n.version}. Please configure your pixi-spine bundle`;
            console.error(e);
          }
          (this.ver40 = o === `4.0`),
            (n.x = r.readFloat()),
            (n.y = r.readFloat()),
            (n.width = r.readFloat()),
            (n.height = r.readFloat());
          let s = r.readBoolean();
          s &&
            ((n.fps = r.readFloat()),
            (n.imagesPath = r.readString()),
            (n.audioPath = r.readString()));
          let c = 0;
          c = r.readInt(!0);
          for (let e = 0; e < c; e++) {
            let e = r.readString();
            if (!e) throw Error(`String in string table must not be null.`);
            r.strings.push(e);
          }
          c = r.readInt(!0);
          for (let e = 0; e < c; e++) {
            let i = r.readString();
            if (!i) throw Error(`Bone name must not be null.`);
            let a = e == 0 ? null : n.bones[r.readInt(!0)],
              o = new ol(e, i, a);
            (o.rotation = r.readFloat()),
              (o.x = r.readFloat() * t),
              (o.y = r.readFloat() * t),
              (o.scaleX = r.readFloat()),
              (o.scaleY = r.readFloat()),
              (o.shearX = r.readFloat()),
              (o.shearY = r.readFloat()),
              (o.length = r.readFloat() * t),
              (o.transformMode = r.readInt(!0)),
              (o.skinRequired = r.readBoolean()),
              s && U.rgba8888ToColor(o.color, r.readInt32()),
              n.bones.push(o);
          }
          c = r.readInt(!0);
          for (let e = 0; e < c; e++) {
            let t = r.readString();
            if (!t) throw Error(`Slot name must not be null.`);
            let i = n.bones[r.readInt(!0)],
              a = new Ml(e, t, i);
            U.rgba8888ToColor(a.color, r.readInt32());
            let o = r.readInt32();
            o != -1 && U.rgb888ToColor((a.darkColor = new U()), o),
              (a.attachmentName = r.readStringRef()),
              (a.blendMode = r.readInt(!0)),
              n.slots.push(a);
          }
          c = r.readInt(!0);
          for (let e = 0, i; e < c; e++) {
            let e = r.readString();
            if (!e) throw Error(`IK constraint data name must not be null.`);
            let a = new gl(e);
            (a.order = r.readInt(!0)),
              (a.skinRequired = r.readBoolean()),
              (i = r.readInt(!0));
            for (let e = 0; e < i; e++) a.bones.push(n.bones[r.readInt(!0)]);
            (a.target = n.bones[r.readInt(!0)]),
              (a.mix = r.readFloat()),
              (a.softness = r.readFloat() * t),
              (a.bendDirection = r.readByte()),
              (a.compress = r.readBoolean()),
              (a.stretch = r.readBoolean()),
              (a.uniform = r.readBoolean()),
              n.ikConstraints.push(a);
          }
          c = r.readInt(!0);
          for (let e = 0, i; e < c; e++) {
            let e = r.readString();
            if (!e)
              throw Error(`Transform constraint data name must not be null.`);
            let a = new Pl(e);
            (a.order = r.readInt(!0)),
              (a.skinRequired = r.readBoolean()),
              (i = r.readInt(!0));
            for (let e = 0; e < i; e++) a.bones.push(n.bones[r.readInt(!0)]);
            (a.target = n.bones[r.readInt(!0)]),
              (a.local = r.readBoolean()),
              (a.relative = r.readBoolean()),
              (a.offsetRotation = r.readFloat()),
              (a.offsetX = r.readFloat() * t),
              (a.offsetY = r.readFloat() * t),
              (a.offsetScaleX = r.readFloat()),
              (a.offsetScaleY = r.readFloat()),
              (a.offsetShearY = r.readFloat()),
              (a.mixRotate = r.readFloat()),
              (a.mixX = r.readFloat()),
              (a.mixY = r.readFloat()),
              (a.mixScaleX = r.readFloat()),
              (a.mixScaleY = r.readFloat()),
              (a.mixShearY = r.readFloat()),
              n.transformConstraints.push(a);
          }
          c = r.readInt(!0);
          for (let e = 0, i; e < c; e++) {
            let e = r.readString();
            if (!e) throw Error(`Path constraint data name must not be null.`);
            let a = new vl(e);
            (a.order = r.readInt(!0)),
              (a.skinRequired = r.readBoolean()),
              (i = r.readInt(!0));
            for (let e = 0; e < i; e++) a.bones.push(n.bones[r.readInt(!0)]);
            (a.target = n.slots[r.readInt(!0)]),
              (a.positionMode = r.readInt(!0)),
              (a.spacingMode = r.readInt(!0)),
              (a.rotateMode = r.readInt(!0)),
              (a.offsetRotation = r.readFloat()),
              (a.position = r.readFloat()),
              a.positionMode == ss.Fixed && (a.position *= t),
              (a.spacing = r.readFloat()),
              (a.spacingMode == X.Length || a.spacingMode == X.Fixed) &&
                (a.spacing *= t),
              (a.mixRotate = r.readFloat()),
              (a.mixX = r.readFloat()),
              (a.mixY = r.readFloat()),
              n.pathConstraints.push(a);
          }
          let l = this.readSkin(r, n, !0, s);
          l && ((n.defaultSkin = l), n.skins.push(l));
          {
            let e = n.skins.length;
            for (G.setArraySize(n.skins, (c = e + r.readInt(!0))); e < c; e++) {
              let t = this.readSkin(r, n, !1, s);
              if (!t) throw Error(`readSkin() should not have returned null.`);
              n.skins[e] = t;
            }
          }
          c = this.linkedMeshes.length;
          for (let e = 0; e < c; e++) {
            let t = this.linkedMeshes[e],
              r = t.skin ? n.findSkin(t.skin) : n.defaultSkin;
            if (!r) throw Error(`Not skin found for linked mesh.`);
            if (!t.parent) throw Error(`Linked mesh parent must not be null`);
            let i = r.getAttachment(t.slotIndex, t.parent);
            if (!i) throw Error(`Parent mesh not found: ${t.parent}`);
            (t.mesh.timelineAttachment = t.inheritTimeline ? i : t.mesh),
              t.mesh.setParentMesh(i);
          }
          (this.linkedMeshes.length = 0), (c = r.readInt(!0));
          for (let e = 0; e < c; e++) {
            let e = r.readStringRef();
            if (!e) throw Error();
            let t = new fl(e);
            (t.intValue = r.readInt(!1)),
              (t.floatValue = r.readFloat()),
              (t.stringValue = r.readString()),
              (t.audioPath = r.readString()),
              t.audioPath &&
                ((t.volume = r.readFloat()), (t.balance = r.readFloat())),
              n.events.push(t);
          }
          c = r.readInt(!0);
          for (let e = 0; e < c; e++) {
            let e = r.readString();
            if (!e) throw Error(`Animatio name must not be null.`);
            n.animations.push(this.readAnimation(r, e, n));
          }
          return n;
        }
        readSkin(e, t, n, r) {
          let i = null,
            a = 0;
          if (n) {
            if (((a = e.readInt(!0)), a == 0)) return null;
            i = new Ll(`default`);
          } else {
            let n = e.readStringRef();
            if (!n) throw Error(`Skin name must not be null.`);
            (i = new Ll(n)), (i.bones.length = e.readInt(!0));
            for (let n = 0, r = i.bones.length; n < r; n++)
              i.bones[n] = t.bones[e.readInt(!0)];
            for (let n = 0, r = e.readInt(!0); n < r; n++)
              i.constraints.push(t.ikConstraints[e.readInt(!0)]);
            for (let n = 0, r = e.readInt(!0); n < r; n++)
              i.constraints.push(t.transformConstraints[e.readInt(!0)]);
            for (let n = 0, r = e.readInt(!0); n < r; n++)
              i.constraints.push(t.pathConstraints[e.readInt(!0)]);
            a = e.readInt(!0);
          }
          for (let n = 0; n < a; n++) {
            let n = e.readInt(!0);
            for (let a = 0, o = e.readInt(!0); a < o; a++) {
              let a = e.readStringRef();
              if (!a) throw Error(`Attachment name must not be null`);
              let o = this.readAttachment(e, t, i, n, a, r);
              o && i.setAttachment(n, a, o);
            }
          }
          return i;
        }
        readAttachment(e, t, n, r, i, a) {
          let o = this.scale,
            s = e.readStringRef();
          switch (((s ||= i), e.readByte())) {
            case V.Region: {
              let t = e.readStringRef(),
                r = e.readFloat(),
                i = e.readFloat(),
                a = e.readFloat(),
                c = e.readFloat(),
                l = e.readFloat(),
                u = e.readFloat(),
                d = e.readFloat(),
                f = e.readInt32(),
                p = this.readSequence(e);
              t ||= s;
              let m = this.attachmentLoader.newRegionAttachment(n, s, t, p);
              return m
                ? ((m.path = t),
                  (m.x = i * o),
                  (m.y = a * o),
                  (m.scaleX = c),
                  (m.scaleY = l),
                  (m.rotation = r),
                  (m.width = u * o),
                  (m.height = d * o),
                  U.rgba8888ToColor(m.color, f),
                  (m.sequence = p),
                  p ?? m.updateRegion(),
                  m)
                : null;
            }
            case V.BoundingBox: {
              let t = e.readInt(!0),
                r = this.readVertices(e, t),
                i = a ? e.readInt32() : 0,
                o = this.attachmentLoader.newBoundingBoxAttachment(n, s);
              return o
                ? ((o.worldVerticesLength = t << 1),
                  (o.vertices = r.vertices),
                  (o.bones = r.bones),
                  a && U.rgba8888ToColor(o.color, i),
                  o)
                : null;
            }
            case V.Mesh: {
              let t = e.readStringRef(),
                r = e.readInt32(),
                i = e.readInt(!0),
                c = this.readFloatArray(e, i << 1, 1),
                l = this.readShortArray(e),
                u = this.readVertices(e, i),
                d = e.readInt(!0),
                f = this.readSequence(e),
                p = [],
                m = 0,
                h = 0;
              a &&
                ((p = this.readShortArray(e)),
                (m = e.readFloat()),
                (h = e.readFloat())),
                (t ||= s);
              let g = this.attachmentLoader.newMeshAttachment(n, s, t, f);
              return g
                ? ((g.path = t),
                  U.rgba8888ToColor(g.color, r),
                  (g.bones = u.bones),
                  (g.vertices = u.vertices),
                  (g.worldVerticesLength = i << 1),
                  (g.triangles = l),
                  (g.regionUVs = new Float32Array(c)),
                  (g.hullLength = d << 1),
                  (g.sequence = f),
                  a && ((g.edges = p), (g.width = m * o), (g.height = h * o)),
                  g)
                : null;
            }
            case V.LinkedMesh: {
              let t = e.readStringRef(),
                i = e.readInt32(),
                c = e.readStringRef(),
                l = e.readStringRef(),
                u = e.readBoolean(),
                d = this.readSequence(e),
                f = 0,
                p = 0;
              a && ((f = e.readFloat()), (p = e.readFloat())), (t ||= s);
              let m = this.attachmentLoader.newMeshAttachment(n, s, t, d);
              return m
                ? ((m.path = t),
                  U.rgba8888ToColor(m.color, i),
                  (m.sequence = d),
                  a && ((m.width = f * o), (m.height = p * o)),
                  this.linkedMeshes.push(new Hl(m, c, r, l, u)),
                  m)
                : null;
            }
            case V.Path: {
              let t = e.readBoolean(),
                r = e.readBoolean(),
                i = e.readInt(!0),
                c = this.readVertices(e, i),
                l = G.newArray(i / 3, 0);
              for (let t = 0, n = l.length; t < n; t++)
                l[t] = e.readFloat() * o;
              let u = a ? e.readInt32() : 0,
                d = this.attachmentLoader.newPathAttachment(n, s);
              return d
                ? ((d.closed = t),
                  (d.constantSpeed = r),
                  (d.worldVerticesLength = i << 1),
                  (d.vertices = c.vertices),
                  (d.bones = c.bones),
                  (d.lengths = l),
                  a && U.rgba8888ToColor(d.color, u),
                  d)
                : null;
            }
            case V.Point: {
              let t = e.readFloat(),
                r = e.readFloat(),
                i = e.readFloat(),
                c = a ? e.readInt32() : 0,
                l = this.attachmentLoader.newPointAttachment(n, s);
              return l
                ? ((l.x = r * o),
                  (l.y = i * o),
                  (l.rotation = t),
                  a && U.rgba8888ToColor(l.color, c),
                  l)
                : null;
            }
            case V.Clipping: {
              let r = e.readInt(!0),
                i = e.readInt(!0),
                o = this.readVertices(e, i),
                c = a ? e.readInt32() : 0,
                l = this.attachmentLoader.newClippingAttachment(n, s);
              return l
                ? ((l.endSlot = t.slots[r]),
                  (l.worldVerticesLength = i << 1),
                  (l.vertices = o.vertices),
                  (l.bones = o.bones),
                  a && U.rgba8888ToColor(l.color, c),
                  l)
                : null;
            }
          }
          return null;
        }
        readSequence(e) {
          if (this.ver40 || !e.readBoolean()) return null;
          let t = new rc(e.readInt(!0));
          return (
            (t.start = e.readInt(!0)),
            (t.digits = e.readInt(!0)),
            (t.setupIndex = e.readInt(!0)),
            t
          );
        }
        readDeformTimelineType(e) {
          return this.ver40 ? ou : e.readByte();
        }
        readVertices(e, t) {
          let n = this.scale,
            r = t << 1,
            i = new Ul();
          if (!e.readBoolean())
            return (i.vertices = this.readFloatArray(e, r, n)), i;
          let a = [],
            o = [];
          for (let r = 0; r < t; r++) {
            let t = e.readInt(!0);
            o.push(t);
            for (let r = 0; r < t; r++)
              o.push(e.readInt(!0)),
                a.push(e.readFloat() * n),
                a.push(e.readFloat() * n),
                a.push(e.readFloat());
          }
          return (i.vertices = G.toFloatArray(a)), (i.bones = o), i;
        }
        readFloatArray(e, t, n) {
          let r = Array(t);
          if (n == 1) for (let n = 0; n < t; n++) r[n] = e.readFloat();
          else for (let i = 0; i < t; i++) r[i] = e.readFloat() * n;
          return r;
        }
        readShortArray(e) {
          let t = e.readInt(!0),
            n = Array(t);
          for (let r = 0; r < t; r++) n[r] = e.readShort();
          return n;
        }
        readAnimation(e, t, n) {
          e.readInt(!0);
          let r = [],
            i = this.scale;
          for (let t = 0, n = e.readInt(!0); t < n; t++) {
            let t = e.readInt(!0);
            for (let n = 0, i = e.readInt(!0); n < i; n++) {
              let n = e.readByte(),
                i = e.readInt(!0),
                a = i - 1;
              switch (n) {
                case eu: {
                  let n = new Ec(i, t);
                  for (let t = 0; t < i; t++)
                    n.setFrame(t, e.readFloat(), e.readStringRef());
                  r.push(n);
                  break;
                }
                case tu: {
                  let n = e.readInt(!0),
                    o = new xc(i, n, t),
                    s = e.readFloat(),
                    c = e.readUnsignedByte() / 255,
                    l = e.readUnsignedByte() / 255,
                    u = e.readUnsignedByte() / 255,
                    d = e.readUnsignedByte() / 255;
                  for (
                    let t = 0, n = 0;
                    o.setFrame(t, s, c, l, u, d), t != a;
                    t++
                  ) {
                    let r = e.readFloat(),
                      i = e.readUnsignedByte() / 255,
                      a = e.readUnsignedByte() / 255,
                      f = e.readUnsignedByte() / 255,
                      p = e.readUnsignedByte() / 255;
                    switch (e.readByte()) {
                      case du:
                        o.setStepped(t);
                        break;
                      case fu:
                        Z(e, o, n++, t, 0, s, r, c, i, 1),
                          Z(e, o, n++, t, 1, s, r, l, a, 1),
                          Z(e, o, n++, t, 2, s, r, u, f, 1),
                          Z(e, o, n++, t, 3, s, r, d, p, 1);
                    }
                    (s = r), (c = i), (l = a), (u = f), (d = p);
                  }
                  r.push(o);
                  break;
                }
                case nu: {
                  let n = e.readInt(!0),
                    o = new Sc(i, n, t),
                    s = e.readFloat(),
                    c = e.readUnsignedByte() / 255,
                    l = e.readUnsignedByte() / 255,
                    u = e.readUnsignedByte() / 255;
                  for (
                    let t = 0, n = 0;
                    o.setFrame(t, s, c, l, u), t != a;
                    t++
                  ) {
                    let r = e.readFloat(),
                      i = e.readUnsignedByte() / 255,
                      a = e.readUnsignedByte() / 255,
                      d = e.readUnsignedByte() / 255;
                    switch (e.readByte()) {
                      case du:
                        o.setStepped(t);
                        break;
                      case fu:
                        Z(e, o, n++, t, 0, s, r, c, i, 1),
                          Z(e, o, n++, t, 1, s, r, l, a, 1),
                          Z(e, o, n++, t, 2, s, r, u, d, 1);
                    }
                    (s = r), (c = i), (l = a), (u = d);
                  }
                  r.push(o);
                  break;
                }
                case ru: {
                  let n = e.readInt(!0),
                    o = new wc(i, n, t),
                    s = e.readFloat(),
                    c = e.readUnsignedByte() / 255,
                    l = e.readUnsignedByte() / 255,
                    u = e.readUnsignedByte() / 255,
                    d = e.readUnsignedByte() / 255,
                    f = e.readUnsignedByte() / 255,
                    p = e.readUnsignedByte() / 255,
                    m = e.readUnsignedByte() / 255;
                  for (
                    let t = 0, n = 0;
                    o.setFrame(t, s, c, l, u, d, f, p, m), t != a;
                    t++
                  ) {
                    let r = e.readFloat(),
                      i = e.readUnsignedByte() / 255,
                      a = e.readUnsignedByte() / 255,
                      h = e.readUnsignedByte() / 255,
                      g = e.readUnsignedByte() / 255,
                      _ = e.readUnsignedByte() / 255,
                      v = e.readUnsignedByte() / 255,
                      y = e.readUnsignedByte() / 255;
                    switch (e.readByte()) {
                      case du:
                        o.setStepped(t);
                        break;
                      case fu:
                        Z(e, o, n++, t, 0, s, r, c, i, 1),
                          Z(e, o, n++, t, 1, s, r, l, a, 1),
                          Z(e, o, n++, t, 2, s, r, u, h, 1),
                          Z(e, o, n++, t, 3, s, r, d, g, 1),
                          Z(e, o, n++, t, 4, s, r, f, _, 1),
                          Z(e, o, n++, t, 5, s, r, p, v, 1),
                          Z(e, o, n++, t, 6, s, r, m, y, 1);
                    }
                    (s = r),
                      (c = i),
                      (l = a),
                      (u = h),
                      (d = g),
                      (f = _),
                      (p = v),
                      (m = y);
                  }
                  r.push(o);
                  break;
                }
                case iu: {
                  let n = e.readInt(!0),
                    o = new Tc(i, n, t),
                    s = e.readFloat(),
                    c = e.readUnsignedByte() / 255,
                    l = e.readUnsignedByte() / 255,
                    u = e.readUnsignedByte() / 255,
                    d = e.readUnsignedByte() / 255,
                    f = e.readUnsignedByte() / 255,
                    p = e.readUnsignedByte() / 255;
                  for (
                    let t = 0, n = 0;
                    o.setFrame(t, s, c, l, u, d, f, p), t != a;
                    t++
                  ) {
                    let r = e.readFloat(),
                      i = e.readUnsignedByte() / 255,
                      a = e.readUnsignedByte() / 255,
                      m = e.readUnsignedByte() / 255,
                      h = e.readUnsignedByte() / 255,
                      g = e.readUnsignedByte() / 255,
                      _ = e.readUnsignedByte() / 255;
                    switch (e.readByte()) {
                      case du:
                        o.setStepped(t);
                        break;
                      case fu:
                        Z(e, o, n++, t, 0, s, r, c, i, 1),
                          Z(e, o, n++, t, 1, s, r, l, a, 1),
                          Z(e, o, n++, t, 2, s, r, u, m, 1),
                          Z(e, o, n++, t, 3, s, r, d, h, 1),
                          Z(e, o, n++, t, 4, s, r, f, g, 1),
                          Z(e, o, n++, t, 5, s, r, p, _, 1);
                    }
                    (s = r),
                      (c = i),
                      (l = a),
                      (u = m),
                      (d = h),
                      (f = g),
                      (p = _);
                  }
                  r.push(o);
                  break;
                }
                case au: {
                  let n = new Cc(i, e.readInt(!0), t),
                    o = e.readFloat(),
                    s = e.readUnsignedByte() / 255;
                  for (let t = 0, r = 0; n.setFrame(t, o, s), t != a; t++) {
                    let i = e.readFloat(),
                      a = e.readUnsignedByte() / 255;
                    switch (e.readByte()) {
                      case du:
                        n.setStepped(t);
                        break;
                      case fu:
                        Z(e, n, r++, t, 0, o, i, s, a, 1);
                    }
                    (o = i), (s = a);
                  }
                  r.push(n);
                }
              }
            }
          }
          for (let t = 0, n = e.readInt(!0); t < n; t++) {
            let t = e.readInt(!0);
            for (let n = 0, a = e.readInt(!0); n < a; n++) {
              let n = e.readByte(),
                a = e.readInt(!0),
                o = e.readInt(!0);
              switch (n) {
                case Wl:
                  r.push(zl(e, new dc(a, o, t), 1));
                  break;
                case Gl:
                  r.push(Bl(e, new fc(a, o, t), i));
                  break;
                case Kl:
                  r.push(zl(e, new pc(a, o, t), i));
                  break;
                case ql:
                  r.push(zl(e, new mc(a, o, t), i));
                  break;
                case Jl:
                  r.push(Bl(e, new hc(a, o, t), 1));
                  break;
                case Yl:
                  r.push(zl(e, new gc(a, o, t), 1));
                  break;
                case Xl:
                  r.push(zl(e, new _c(a, o, t), 1));
                  break;
                case Zl:
                  r.push(Bl(e, new vc(a, o, t), 1));
                  break;
                case Ql:
                  r.push(zl(e, new yc(a, o, t), 1));
                  break;
                case $l:
                  r.push(zl(e, new bc(a, o, t), 1));
              }
            }
          }
          for (let t = 0, n = e.readInt(!0); t < n; t++) {
            let t = e.readInt(!0),
              n = e.readInt(!0),
              a = n - 1,
              o = new Mc(n, e.readInt(!0), t),
              s = e.readFloat(),
              c = e.readFloat(),
              l = e.readFloat() * i;
            for (
              let t = 0, n = 0;
              o.setFrame(
                t,
                s,
                c,
                l,
                e.readByte(),
                e.readBoolean(),
                e.readBoolean()
              ),
                t != a;
              t++
            ) {
              let r = e.readFloat(),
                a = e.readFloat(),
                u = e.readFloat() * i;
              switch (e.readByte()) {
                case du:
                  o.setStepped(t);
                  break;
                case fu:
                  Z(e, o, n++, t, 0, s, r, c, a, 1),
                    Z(e, o, n++, t, 1, s, r, l, u, i);
              }
              (s = r), (c = a), (l = u);
            }
            r.push(o);
          }
          for (let t = 0, n = e.readInt(!0); t < n; t++) {
            let t = e.readInt(!0),
              n = e.readInt(!0),
              i = n - 1,
              a = new Nc(n, e.readInt(!0), t),
              o = e.readFloat(),
              s = e.readFloat(),
              c = e.readFloat(),
              l = e.readFloat(),
              u = e.readFloat(),
              d = e.readFloat(),
              f = e.readFloat();
            for (
              let t = 0, n = 0;
              a.setFrame(t, o, s, c, l, u, d, f), t != i;
              t++
            ) {
              let r = e.readFloat(),
                i = e.readFloat(),
                p = e.readFloat(),
                m = e.readFloat(),
                h = e.readFloat(),
                g = e.readFloat(),
                _ = e.readFloat();
              switch (e.readByte()) {
                case du:
                  a.setStepped(t);
                  break;
                case fu:
                  Z(e, a, n++, t, 0, o, r, s, i, 1),
                    Z(e, a, n++, t, 1, o, r, c, p, 1),
                    Z(e, a, n++, t, 2, o, r, l, m, 1),
                    Z(e, a, n++, t, 3, o, r, u, h, 1),
                    Z(e, a, n++, t, 4, o, r, d, g, 1),
                    Z(e, a, n++, t, 5, o, r, f, _, 1);
              }
              (o = r), (s = i), (c = p), (l = m), (u = h), (d = g), (f = _);
            }
            r.push(a);
          }
          for (let t = 0, a = e.readInt(!0); t < a; t++) {
            let t = e.readInt(!0),
              a = n.pathConstraints[t];
            for (let n = 0, o = e.readInt(!0); n < o; n++)
              switch (e.readByte()) {
                case cu:
                  r.push(
                    zl(
                      e,
                      new Pc(e.readInt(!0), e.readInt(!0), t),
                      a.positionMode == ss.Fixed ? i : 1
                    )
                  );
                  break;
                case lu:
                  r.push(
                    zl(
                      e,
                      new Fc(e.readInt(!0), e.readInt(!0), t),
                      a.spacingMode == X.Length || a.spacingMode == X.Fixed
                        ? i
                        : 1
                    )
                  );
                  break;
                case uu:
                  let n = new Ic(e.readInt(!0), e.readInt(!0), t),
                    o = e.readFloat(),
                    s = e.readFloat(),
                    c = e.readFloat(),
                    l = e.readFloat();
                  for (
                    let t = 0, r = 0, i = n.getFrameCount() - 1;
                    n.setFrame(t, o, s, c, l), t != i;
                    t++
                  ) {
                    let i = e.readFloat(),
                      a = e.readFloat(),
                      u = e.readFloat(),
                      d = e.readFloat();
                    switch (e.readByte()) {
                      case du:
                        n.setStepped(t);
                        break;
                      case fu:
                        Z(e, n, r++, t, 0, o, i, s, a, 1),
                          Z(e, n, r++, t, 1, o, i, c, u, 1),
                          Z(e, n, r++, t, 2, o, i, l, d, 1);
                    }
                    (o = i), (s = a), (c = u), (l = d);
                  }
                  r.push(n);
              }
          }
          for (let t = 0, a = e.readInt(!0); t < a; t++) {
            let t = n.skins[e.readInt(!0)];
            for (let n = 0, a = e.readInt(!0); n < a; n++) {
              let n = e.readInt(!0);
              for (let a = 0, o = e.readInt(!0); a < o; a++) {
                let a = e.readStringRef();
                if (!a) throw Error(`attachmentName must not be null.`);
                let o = t.getAttachment(n, a),
                  s = this.readDeformTimelineType(e),
                  c = e.readInt(!0),
                  l = c - 1;
                switch (s) {
                  case ou: {
                    let t = o,
                      a = t.bones,
                      s = t.vertices,
                      u = a ? (s.length / 3) * 2 : s.length,
                      d = e.readInt(!0),
                      f = new Dc(c, d, n, t),
                      p = e.readFloat();
                    for (let t = 0, n = 0; ; t++) {
                      let r,
                        o = e.readInt(!0);
                      if (o == 0) r = a ? G.newFloatArray(u) : s;
                      else {
                        r = G.newFloatArray(u);
                        let t = e.readInt(!0);
                        if (((o += t), i == 1))
                          for (let n = t; n < o; n++) r[n] = e.readFloat();
                        else
                          for (let n = t; n < o; n++) r[n] = e.readFloat() * i;
                        if (!a)
                          for (let e = 0, t = r.length; e < t; e++)
                            r[e] += s[e];
                      }
                      if ((f.setFrame(t, p, r), t == l)) break;
                      let c = e.readFloat();
                      switch (e.readByte()) {
                        case du:
                          f.setStepped(t);
                          break;
                        case fu:
                          Z(e, f, n++, t, 0, p, c, 0, 1, 1);
                      }
                      p = c;
                    }
                    r.push(f);
                    break;
                  }
                  case su: {
                    let t = new Rc(c, n, o);
                    for (let n = 0; n < c; n++) {
                      let r = e.readFloat(),
                        i = e.readInt32();
                      t.setFrame(n, r, ac[i & 15], i >> 4, e.readFloat());
                    }
                    r.push(t);
                    break;
                  }
                }
              }
            }
          }
          let a = e.readInt(!0);
          if (a > 0) {
            let t = new jc(a),
              i = n.slots.length;
            for (let n = 0; n < a; n++) {
              let r = e.readFloat(),
                a = e.readInt(!0),
                o = G.newArray(i, 0);
              for (let e = i - 1; e >= 0; e--) o[e] = -1;
              let s = G.newArray(i - a, 0),
                c = 0,
                l = 0;
              for (let t = 0; t < a; t++) {
                let t = e.readInt(!0);
                for (; c != t; ) s[l++] = c++;
                o[c + e.readInt(!0)] = c++;
              }
              for (; c < i; ) s[l++] = c++;
              for (let e = i - 1; e >= 0; e--) o[e] == -1 && (o[e] = s[--l]);
              t.setFrame(n, r, o);
            }
            r.push(t);
          }
          let o = e.readInt(!0);
          if (o > 0) {
            let t = new kc(o);
            for (let r = 0; r < o; r++) {
              let i = e.readFloat(),
                a = n.events[e.readInt(!0)],
                o = new ul(i, a);
              (o.intValue = e.readInt(!1)),
                (o.floatValue = e.readFloat()),
                (o.stringValue = e.readBoolean()
                  ? e.readString()
                  : a.stringValue),
                o.data.audioPath &&
                  ((o.volume = e.readFloat()), (o.balance = e.readFloat())),
                t.setFrame(r, o);
            }
            r.push(t);
          }
          let s = 0;
          for (let e = 0, t = r.length; e < t; e++)
            s = Math.max(s, r[e].getDuration());
          return new sc(t, r, s);
        }
      }),
      (Vl.BlendModeValues = [F.NORMAL, F.ADD, F.MULTIPLY, F.SCREEN]),
      (Hl = class {
        constructor(e, t, n, r, i) {
          (this.mesh = e),
            (this.skin = t),
            (this.slotIndex = n),
            (this.parent = r),
            (this.inheritTimeline = i);
        }
      }),
      (Ul = class {
        constructor(e = null, t = null) {
          (this.bones = e), (this.vertices = t);
        }
      }),
      (Wl = 0),
      (Gl = 1),
      (Kl = 2),
      (ql = 3),
      (Jl = 4),
      (Yl = 5),
      (Xl = 6),
      (Zl = 7),
      (Ql = 8),
      ($l = 9),
      (eu = 0),
      (tu = 1),
      (nu = 2),
      (ru = 3),
      (iu = 4),
      (au = 5),
      (ou = 0),
      (su = 1),
      (cu = 0),
      (lu = 1),
      (uu = 2),
      (du = 1),
      (fu = 2);
  }))();
}
function mu() {
  return (mu = t(() => {
    K();
  }))();
}
function hu(e, t, n, r) {
  let i = e[0],
    a = $(i, `time`, 0),
    o = $(i, `value`, n) * r,
    s = 0;
  for (let c = 0; ; c++) {
    t.setFrame(c, a, o);
    let l = e[c + 1];
    if (!l) return t.shrink(s), t;
    let u = $(l, `time`, 0),
      d = $(l, `value`, n) * r;
    i.curve && (s = Q(i.curve, t, s, c, 0, a, u, o, d, r)),
      (a = u),
      (o = d),
      (i = l);
  }
}
function gu(e, t, n, r, i, a) {
  let o = e[0],
    s = $(o, `time`, 0),
    c = $(o, n, i) * a,
    l = $(o, r, i) * a,
    u = 0;
  for (let d = 0; ; d++) {
    t.setFrame(d, s, c, l);
    let f = e[d + 1];
    if (!f) return t.shrink(u), t;
    let p = $(f, `time`, 0),
      m = $(f, n, i) * a,
      h = $(f, r, i) * a,
      g = o.curve;
    g &&
      ((u = Q(g, t, u, d, 0, s, p, c, m, a)),
      (u = Q(g, t, u, d, 1, s, p, l, h, a))),
      (s = p),
      (c = m),
      (l = h),
      (o = f);
  }
}
function Q(e, t, n, r, i, a, o, s, c, l) {
  if (e == `stepped`) return t.setStepped(r), n;
  let u = i << 2,
    d = e[u],
    f = e[u + 1] * l,
    p = e[u + 2],
    m = e[u + 3] * l;
  return t.setBezier(n, r, i, a, s, d, f, p, m, o, c), n + 1;
}
function $(e, t, n) {
  return e[t] === void 0 ? n : e[t];
}
var _u, vu;
function yu() {
  return (yu = t(() => {
    zc(),
      dl(),
      jl(),
      Nl(),
      sl(),
      _l(),
      Fl(),
      yl(),
      Rl(),
      pl(),
      K(),
      R(),
      oc(),
      (_u = class e {
        constructor(e) {
          (this.scale = 1),
            (this.linkedMeshes = []),
            (this.attachmentLoader = e);
        }
        readSkeletonData(t) {
          let n = this.scale,
            r = new Al(),
            i = typeof t == `string` ? JSON.parse(t) : t,
            a = i.skeleton;
          if (a) {
            (r.hash = a.hash), (r.version = a.spine);
            let e = r.version.substr(0, 3);
            if (e !== `4.0` && e !== `4.1`) {
              let e = `Spine 4.1 loader cant load version ${a.spine}. Please configure your pixi-spine bundle`;
              console.error(e);
            }
            (r.x = a.x),
              (r.y = a.y),
              (r.width = a.width),
              (r.height = a.height),
              (r.fps = a.fps),
              (r.imagesPath = a.images);
          }
          if (i.bones)
            for (let e = 0; e < i.bones.length; e++) {
              let t = i.bones[e],
                a = null,
                o = $(t, `parent`, null);
              if (o != null && ((a = r.findBone(o)), a == null))
                throw Error(`Parent bone not found: ${o}`);
              let s = new ol(r.bones.length, t.name, a);
              (s.length = $(t, `length`, 0) * n),
                (s.x = $(t, `x`, 0) * n),
                (s.y = $(t, `y`, 0) * n),
                (s.rotation = $(t, `rotation`, 0)),
                (s.scaleX = $(t, `scaleX`, 1)),
                (s.scaleY = $(t, `scaleY`, 1)),
                (s.shearX = $(t, `shearX`, 0)),
                (s.shearY = $(t, `shearY`, 0)),
                (s.transformMode = G.enumValue(
                  us,
                  $(t, `transform`, `Normal`)
                )),
                (s.skinRequired = $(t, `skin`, !1));
              let c = $(t, `color`, null);
              c && s.color.setFromString(c), r.bones.push(s);
            }
          if (i.slots)
            for (let t = 0; t < i.slots.length; t++) {
              let n = i.slots[t],
                a = r.findBone(n.bone);
              if (!a)
                throw Error(`Couldn't find bone ${n.bone} for slot ${n.name}`);
              let o = new Ml(r.slots.length, n.name, a),
                s = $(n, `color`, null);
              s && o.color.setFromString(s);
              let c = $(n, `dark`, null);
              c && (o.darkColor = U.fromString(c)),
                (o.attachmentName = $(n, `attachment`, null)),
                (o.blendMode = e.blendModeFromString($(n, `blend`, `normal`))),
                r.slots.push(o);
            }
          if (i.ik)
            for (let e = 0; e < i.ik.length; e++) {
              let t = i.ik[e],
                a = new gl(t.name);
              (a.order = $(t, `order`, 0)), (a.skinRequired = $(t, `skin`, !1));
              for (let e = 0; e < t.bones.length; e++) {
                let n = t.bones[e],
                  i = r.findBone(n);
                if (i == null) throw Error(`IK bone not found: ${n}`);
                a.bones.push(i);
              }
              (a.target = r.findBone(t.target)),
                (a.mix = $(t, `mix`, 1)),
                (a.softness = $(t, `softness`, 0) * n),
                (a.bendDirection = $(t, `bendPositive`, !0) ? 1 : -1),
                (a.compress = $(t, `compress`, !1)),
                (a.stretch = $(t, `stretch`, !1)),
                (a.uniform = $(t, `uniform`, !1)),
                r.ikConstraints.push(a);
            }
          if (i.transform)
            for (let e = 0; e < i.transform.length; e++) {
              let t = i.transform[e],
                a = new Pl(t.name);
              (a.order = $(t, `order`, 0)), (a.skinRequired = $(t, `skin`, !1));
              for (let e = 0; e < t.bones.length; e++) {
                let n = t.bones[e],
                  i = r.findBone(n);
                if (!i)
                  throw Error(
                    `Couldn't find bone ${n} for transform constraint ${t.name}.`
                  );
                a.bones.push(i);
              }
              let o = t.target,
                s = r.findBone(o);
              if (!s)
                throw Error(
                  `Couldn't find target bone ${o} for transform constraint ${t.name}.`
                );
              (a.target = s),
                (a.local = $(t, `local`, !1)),
                (a.relative = $(t, `relative`, !1)),
                (a.offsetRotation = $(t, `rotation`, 0)),
                (a.offsetX = $(t, `x`, 0) * n),
                (a.offsetY = $(t, `y`, 0) * n),
                (a.offsetScaleX = $(t, `scaleX`, 0)),
                (a.offsetScaleY = $(t, `scaleY`, 0)),
                (a.offsetShearY = $(t, `shearY`, 0)),
                (a.mixRotate = $(t, `mixRotate`, 1)),
                (a.mixX = $(t, `mixX`, 1)),
                (a.mixY = $(t, `mixY`, a.mixX)),
                (a.mixScaleX = $(t, `mixScaleX`, 1)),
                (a.mixScaleY = $(t, `mixScaleY`, a.mixScaleX)),
                (a.mixShearY = $(t, `mixShearY`, 1)),
                r.transformConstraints.push(a);
            }
          if (i.path)
            for (let e = 0; e < i.path.length; e++) {
              let t = i.path[e],
                a = new vl(t.name);
              (a.order = $(t, `order`, 0)), (a.skinRequired = $(t, `skin`, !1));
              for (let e = 0; e < t.bones.length; e++) {
                let n = t.bones[e],
                  i = r.findBone(n);
                if (!i)
                  throw Error(
                    `Couldn't find bone ${n} for path constraint ${t.name}.`
                  );
                a.bones.push(i);
              }
              let o = t.target,
                s = r.findSlot(o);
              if (!s)
                throw Error(
                  `Couldn't find target slot ${o} for path constraint ${t.name}.`
                );
              (a.target = s),
                (a.positionMode = G.enumValue(
                  ss,
                  $(t, `positionMode`, `Percent`)
                )),
                (a.spacingMode = G.enumValue(X, $(t, `spacingMode`, `Length`))),
                (a.rotateMode = G.enumValue(cs, $(t, `rotateMode`, `Tangent`))),
                (a.offsetRotation = $(t, `rotation`, 0)),
                (a.position = $(t, `position`, 0)),
                a.positionMode == ss.Fixed && (a.position *= n),
                (a.spacing = $(t, `spacing`, 0)),
                (a.spacingMode == X.Length || a.spacingMode == X.Fixed) &&
                  (a.spacing *= n),
                (a.mixRotate = $(t, `mixRotate`, 1)),
                (a.mixX = $(t, `mixX`, 1)),
                (a.mixY = $(t, `mixY`, a.mixX)),
                r.pathConstraints.push(a);
            }
          if (i.skins)
            for (let e = 0; e < i.skins.length; e++) {
              let t = i.skins[e],
                n = new Ll(t.name);
              if (t.bones)
                for (let e = 0; e < t.bones.length; e++) {
                  let i = t.bones[e],
                    a = r.findBone(i);
                  if (!a)
                    throw Error(`Couldn't find bone ${i} for skin ${t.name}.`);
                  n.bones.push(a);
                }
              if (t.ik)
                for (let e = 0; e < t.ik.length; e++) {
                  let i = t.ik[e],
                    a = r.findIkConstraint(i);
                  if (!a)
                    throw Error(
                      `Couldn't find IK constraint ${i} for skin ${t.name}.`
                    );
                  n.constraints.push(a);
                }
              if (t.transform)
                for (let e = 0; e < t.transform.length; e++) {
                  let i = t.transform[e],
                    a = r.findTransformConstraint(i);
                  if (!a)
                    throw Error(
                      `Couldn't find transform constraint ${i} for skin ${t.name}.`
                    );
                  n.constraints.push(a);
                }
              if (t.path)
                for (let e = 0; e < t.path.length; e++) {
                  let i = t.path[e],
                    a = r.findPathConstraint(i);
                  if (!a)
                    throw Error(
                      `Couldn't find path constraint ${i} for skin ${t.name}.`
                    );
                  n.constraints.push(a);
                }
              for (let e in t.attachments) {
                let i = r.findSlot(e);
                if (!i)
                  throw Error(`Couldn't find slot ${e} for skin ${t.name}.`);
                let a = t.attachments[e];
                for (let e in a) {
                  let t = this.readAttachment(a[e], n, i.index, e, r);
                  t && n.setAttachment(i.index, e, t);
                }
              }
              r.skins.push(n), n.name == "default" && (r.defaultSkin = n);
            }
          for (let e = 0, t = this.linkedMeshes.length; e < t; e++) {
            let t = this.linkedMeshes[e],
              n = t.skin ? r.findSkin(t.skin) : r.defaultSkin;
            if (!n) throw Error(`Skin not found: ${t.skin}`);
            let i = n.getAttachment(t.slotIndex, t.parent);
            if (!i) throw Error(`Parent mesh not found: ${t.parent}`);
            (t.mesh.timelineAttachment = t.inheritTimeline ? i : t.mesh),
              t.mesh.setParentMesh(i);
          }
          if (((this.linkedMeshes.length = 0), i.events))
            for (let e in i.events) {
              let t = i.events[e],
                n = new fl(e);
              (n.intValue = $(t, `int`, 0)),
                (n.floatValue = $(t, `float`, 0)),
                (n.stringValue = $(t, `string`, ``)),
                (n.audioPath = $(t, `audio`, null)),
                n.audioPath &&
                  ((n.volume = $(t, `volume`, 1)),
                  (n.balance = $(t, `balance`, 0))),
                r.events.push(n);
            }
          if (i.animations)
            for (let e in i.animations) {
              let t = i.animations[e];
              this.readAnimation(t, e, r);
            }
          return r;
        }
        readAttachment(e, t, n, r, i) {
          let a = this.scale;
          switch (((r = $(e, `name`, r)), $(e, `type`, `region`))) {
            case `region`: {
              let n = $(e, `path`, r),
                i = this.readSequence($(e, `sequence`, null)),
                o = this.attachmentLoader.newRegionAttachment(t, r, n, i);
              if (!o) return null;
              (o.path = n),
                (o.x = $(e, `x`, 0) * a),
                (o.y = $(e, `y`, 0) * a),
                (o.scaleX = $(e, `scaleX`, 1)),
                (o.scaleY = $(e, `scaleY`, 1)),
                (o.rotation = $(e, `rotation`, 0)),
                (o.width = e.width * a),
                (o.height = e.height * a),
                (o.sequence = i);
              let s = $(e, `color`, null);
              return s && o.color.setFromString(s), o;
            }
            case `boundingbox`: {
              let n = this.attachmentLoader.newBoundingBoxAttachment(t, r);
              if (!n) return null;
              this.readVertices(e, n, e.vertexCount << 1);
              let i = $(e, `color`, null);
              return i && n.color.setFromString(i), n;
            }
            case `mesh`:
            case `linkedmesh`: {
              let i = $(e, `path`, r),
                o = this.readSequence($(e, `sequence`, null)),
                s = this.attachmentLoader.newMeshAttachment(t, r, i, o);
              if (!s) return null;
              s.path = i;
              let c = $(e, `color`, null);
              c && s.color.setFromString(c),
                (s.width = $(e, `width`, 0) * a),
                (s.height = $(e, `height`, 0) * a),
                (s.sequence = o);
              let l = $(e, `parent`, null);
              if (l)
                return (
                  this.linkedMeshes.push(
                    new vu(s, $(e, `skin`, null), n, l, $(e, `timelines`, !0))
                  ),
                  s
                );
              let u = e.uvs;
              return (
                this.readVertices(e, s, u.length),
                (s.triangles = e.triangles),
                (s.regionUVs = new Float32Array(u)),
                (s.edges = $(e, `edges`, null)),
                (s.hullLength = $(e, `hull`, 0) * 2),
                s
              );
            }
            case `path`: {
              let n = this.attachmentLoader.newPathAttachment(t, r);
              if (!n) return null;
              (n.closed = $(e, `closed`, !1)),
                (n.constantSpeed = $(e, `constantSpeed`, !0));
              let i = e.vertexCount;
              this.readVertices(e, n, i << 1);
              let o = G.newArray(i / 3, 0);
              for (let t = 0; t < e.lengths.length; t++)
                o[t] = e.lengths[t] * a;
              n.lengths = o;
              let s = $(e, `color`, null);
              return s && n.color.setFromString(s), n;
            }
            case `point`: {
              let n = this.attachmentLoader.newPointAttachment(t, r);
              if (!n) return null;
              (n.x = $(e, `x`, 0) * a),
                (n.y = $(e, `y`, 0) * a),
                (n.rotation = $(e, `rotation`, 0));
              let i = $(e, `color`, null);
              return i && n.color.setFromString(i), n;
            }
            case `clipping`: {
              let n = this.attachmentLoader.newClippingAttachment(t, r);
              if (!n) return null;
              let a = $(e, `end`, null);
              if (a != null) {
                let e = i.findSlot(a);
                if (e == null) throw Error(`Clipping end slot not found: ${a}`);
                n.endSlot = e;
              }
              let o = e.vertexCount;
              this.readVertices(e, n, o << 1);
              let s = $(e, `color`, null);
              return s && n.color.setFromString(s), n;
            }
          }
          return null;
        }
        readSequence(e) {
          if (e == null) return null;
          let t = new rc($(e, `count`, 0));
          return (
            (t.start = $(e, `start`, 1)),
            (t.digits = $(e, `digits`, 0)),
            (t.setupIndex = $(e, `setup`, 0)),
            t
          );
        }
        readVertices(e, t, n) {
          let r = this.scale;
          t.worldVerticesLength = n;
          let i = e.vertices;
          if (n == i.length) {
            let e = G.toFloatArray(i);
            if (r != 1) for (let t = 0, n = i.length; t < n; t++) e[t] *= r;
            t.vertices = e;
            return;
          }
          let a = [],
            o = [];
          for (let e = 0, t = i.length; e < t; ) {
            let t = i[e++];
            o.push(t);
            for (let n = e + t * 4; e < n; e += 4)
              o.push(i[e]),
                a.push(i[e + 1] * r),
                a.push(i[e + 2] * r),
                a.push(i[e + 3]);
          }
          (t.bones = o), (t.vertices = G.toFloatArray(a));
        }
        readAnimation(e, t, n) {
          let r = this.scale,
            i = [];
          if (e.slots)
            for (let t in e.slots) {
              let r = e.slots[t],
                a = n.findSlot(t);
              if (!a) throw Error(`Slot not found: ${t}`);
              let o = a.index;
              for (let e in r) {
                let t = r[e];
                if (!t) continue;
                let n = t.length;
                if (e == `attachment`) {
                  let e = new Ec(n, o);
                  for (let r = 0; r < n; r++) {
                    let n = t[r];
                    e.setFrame(r, $(n, `time`, 0), $(n, `name`, null));
                  }
                  i.push(e);
                } else if (e == `rgba`) {
                  let e = new xc(n, n << 2, o),
                    r = t[0],
                    a = $(r, `time`, 0),
                    s = U.fromString(r.color);
                  for (let n = 0, i = 0; ; n++) {
                    e.setFrame(n, a, s.r, s.g, s.b, s.a);
                    let o = t[n + 1];
                    if (!o) {
                      e.shrink(i);
                      break;
                    }
                    let c = $(o, `time`, 0),
                      l = U.fromString(o.color),
                      u = r.curve;
                    u &&
                      ((i = Q(u, e, i, n, 0, a, c, s.r, l.r, 1)),
                      (i = Q(u, e, i, n, 1, a, c, s.g, l.g, 1)),
                      (i = Q(u, e, i, n, 2, a, c, s.b, l.b, 1)),
                      (i = Q(u, e, i, n, 3, a, c, s.a, l.a, 1))),
                      (a = c),
                      (s = l),
                      (r = o);
                  }
                  i.push(e);
                } else if (e == `rgb`) {
                  let e = new Sc(n, n * 3, o),
                    r = t[0],
                    a = $(r, `time`, 0),
                    s = U.fromString(r.color);
                  for (let n = 0, i = 0; ; n++) {
                    e.setFrame(n, a, s.r, s.g, s.b);
                    let o = t[n + 1];
                    if (!o) {
                      e.shrink(i);
                      break;
                    }
                    let c = $(o, `time`, 0),
                      l = U.fromString(o.color),
                      u = r.curve;
                    u &&
                      ((i = Q(u, e, i, n, 0, a, c, s.r, l.r, 1)),
                      (i = Q(u, e, i, n, 1, a, c, s.g, l.g, 1)),
                      (i = Q(u, e, i, n, 2, a, c, s.b, l.b, 1))),
                      (a = c),
                      (s = l),
                      (r = o);
                  }
                  i.push(e);
                } else if (e == `alpha`) i.push(hu(t, new Cc(n, n, o), 0, 1));
                else if (e == `rgba2`) {
                  let e = new wc(n, n * 7, o),
                    r = t[0],
                    a = $(r, `time`, 0),
                    s = U.fromString(r.light),
                    c = U.fromString(r.dark);
                  for (let n = 0, i = 0; ; n++) {
                    e.setFrame(n, a, s.r, s.g, s.b, s.a, c.r, c.g, c.b);
                    let o = t[n + 1];
                    if (!o) {
                      e.shrink(i);
                      break;
                    }
                    let l = $(o, `time`, 0),
                      u = U.fromString(o.light),
                      d = U.fromString(o.dark),
                      f = r.curve;
                    f &&
                      ((i = Q(f, e, i, n, 0, a, l, s.r, u.r, 1)),
                      (i = Q(f, e, i, n, 1, a, l, s.g, u.g, 1)),
                      (i = Q(f, e, i, n, 2, a, l, s.b, u.b, 1)),
                      (i = Q(f, e, i, n, 3, a, l, s.a, u.a, 1)),
                      (i = Q(f, e, i, n, 4, a, l, c.r, d.r, 1)),
                      (i = Q(f, e, i, n, 5, a, l, c.g, d.g, 1)),
                      (i = Q(f, e, i, n, 6, a, l, c.b, d.b, 1))),
                      (a = l),
                      (s = u),
                      (c = d),
                      (r = o);
                  }
                  i.push(e);
                } else if (e == `rgb2`) {
                  let e = new Tc(n, n * 6, o),
                    r = t[0],
                    a = $(r, `time`, 0),
                    s = U.fromString(r.light),
                    c = U.fromString(r.dark);
                  for (let n = 0, i = 0; ; n++) {
                    e.setFrame(n, a, s.r, s.g, s.b, c.r, c.g, c.b);
                    let o = t[n + 1];
                    if (!o) {
                      e.shrink(i);
                      break;
                    }
                    let l = $(o, `time`, 0),
                      u = U.fromString(o.light),
                      d = U.fromString(o.dark),
                      f = r.curve;
                    f &&
                      ((i = Q(f, e, i, n, 0, a, l, s.r, u.r, 1)),
                      (i = Q(f, e, i, n, 1, a, l, s.g, u.g, 1)),
                      (i = Q(f, e, i, n, 2, a, l, s.b, u.b, 1)),
                      (i = Q(f, e, i, n, 3, a, l, c.r, d.r, 1)),
                      (i = Q(f, e, i, n, 4, a, l, c.g, d.g, 1)),
                      (i = Q(f, e, i, n, 5, a, l, c.b, d.b, 1))),
                      (a = l),
                      (s = u),
                      (c = d),
                      (r = o);
                  }
                  i.push(e);
                }
              }
            }
          if (e.bones)
            for (let t in e.bones) {
              let a = e.bones[t],
                o = n.findBone(t);
              if (!o) throw Error(`Bone not found: ${t}`);
              let s = o.index;
              for (let e in a) {
                let t = a[e],
                  n = t.length;
                if (n != 0) {
                  if (e === `rotate`) i.push(hu(t, new dc(n, n, s), 0, 1));
                  else if (e === `translate`) {
                    let e = new fc(n, n << 1, s);
                    i.push(gu(t, e, `x`, `y`, 0, r));
                  } else if (e === `translatex`) {
                    let e = new pc(n, n, s);
                    i.push(hu(t, e, 0, r));
                  } else if (e === `translatey`) {
                    let e = new mc(n, n, s);
                    i.push(hu(t, e, 0, r));
                  } else if (e === `scale`) {
                    let e = new hc(n, n << 1, s);
                    i.push(gu(t, e, `x`, `y`, 1, 1));
                  } else if (e === `scalex`) {
                    let e = new gc(n, n, s);
                    i.push(hu(t, e, 1, 1));
                  } else if (e === `scaley`) {
                    let e = new _c(n, n, s);
                    i.push(hu(t, e, 1, 1));
                  } else if (e === `shear`) {
                    let e = new vc(n, n << 1, s);
                    i.push(gu(t, e, `x`, `y`, 0, 1));
                  } else if (e === `shearx`) {
                    let e = new yc(n, n, s);
                    i.push(hu(t, e, 0, 1));
                  } else if (e === `sheary`) {
                    let e = new bc(n, n, s);
                    i.push(hu(t, e, 0, 1));
                  }
                }
              }
            }
          if (e.ik)
            for (let t in e.ik) {
              let a = e.ik[t],
                o = a[0];
              if (!o) continue;
              let s = n.findIkConstraint(t);
              if (!s) throw Error(`IK Constraint not found: ${t}`);
              let c = n.ikConstraints.indexOf(s),
                l = new Mc(a.length, a.length << 1, c),
                u = $(o, `time`, 0),
                d = $(o, `mix`, 1),
                f = $(o, `softness`, 0) * r;
              for (let e = 0, t = 0; ; e++) {
                l.setFrame(
                  e,
                  u,
                  d,
                  f,
                  $(o, `bendPositive`, !0) ? 1 : -1,
                  $(o, `compress`, !1),
                  $(o, `stretch`, !1)
                );
                let n = a[e + 1];
                if (!n) {
                  l.shrink(t);
                  break;
                }
                let i = $(n, `time`, 0),
                  s = $(n, `mix`, 1),
                  c = $(n, `softness`, 0) * r,
                  p = o.curve;
                p &&
                  ((t = Q(p, l, t, e, 0, u, i, d, s, 1)),
                  (t = Q(p, l, t, e, 1, u, i, f, c, r))),
                  (u = i),
                  (d = s),
                  (f = c),
                  (o = n);
              }
              i.push(l);
            }
          if (e.transform)
            for (let t in e.transform) {
              let r = e.transform[t],
                a = r[0];
              if (!a) continue;
              let o = n.findTransformConstraint(t);
              if (!o) throw Error(`Transform constraint not found: ${t}`);
              let s = n.transformConstraints.indexOf(o),
                c = new Nc(r.length, r.length * 6, s),
                l = $(a, `time`, 0),
                u = $(a, `mixRotate`, 1),
                d = $(a, `mixX`, 1),
                f = $(a, `mixY`, d),
                p = $(a, `mixScaleX`, 1),
                m = $(a, `mixScaleY`, p),
                h = $(a, `mixShearY`, 1);
              for (let e = 0, t = 0; ; e++) {
                c.setFrame(e, l, u, d, f, p, m, h);
                let n = r[e + 1];
                if (!n) {
                  c.shrink(t);
                  break;
                }
                let i = $(n, `time`, 0),
                  o = $(n, `mixRotate`, 1),
                  s = $(n, `mixX`, 1),
                  g = $(n, `mixY`, s),
                  _ = $(n, `mixScaleX`, 1),
                  v = $(n, `mixScaleY`, _),
                  y = $(n, `mixShearY`, 1),
                  b = a.curve;
                b &&
                  ((t = Q(b, c, t, e, 0, l, i, u, o, 1)),
                  (t = Q(b, c, t, e, 1, l, i, d, s, 1)),
                  (t = Q(b, c, t, e, 2, l, i, f, g, 1)),
                  (t = Q(b, c, t, e, 3, l, i, p, _, 1)),
                  (t = Q(b, c, t, e, 4, l, i, m, v, 1)),
                  (t = Q(b, c, t, e, 5, l, i, h, y, 1))),
                  (l = i),
                  (u = o),
                  (d = s),
                  (f = g),
                  (p = _),
                  (m = v),
                  (p = _),
                  (a = n);
              }
              i.push(c);
            }
          if (e.path)
            for (let t in e.path) {
              let a = e.path[t],
                o = n.findPathConstraint(t);
              if (!o) throw Error(`Path constraint not found: ${t}`);
              let s = n.pathConstraints.indexOf(o);
              for (let e in a) {
                let t = a[e],
                  n = t[0];
                if (!n) continue;
                let c = t.length;
                if (e === `position`) {
                  let e = new Pc(c, c, s);
                  i.push(hu(t, e, 0, o.positionMode == ss.Fixed ? r : 1));
                } else if (e === `spacing`) {
                  let e = new Fc(c, c, s);
                  i.push(
                    hu(
                      t,
                      e,
                      0,
                      o.spacingMode == X.Length || o.spacingMode == X.Fixed
                        ? r
                        : 1
                    )
                  );
                } else if (e === `mix`) {
                  let e = new Ic(c, c * 3, s),
                    r = $(n, `time`, 0),
                    a = $(n, `mixRotate`, 1),
                    o = $(n, `mixX`, 1),
                    l = $(n, `mixY`, o);
                  for (let i = 0, s = 0; ; i++) {
                    e.setFrame(i, r, a, o, l);
                    let c = t[i + 1];
                    if (!c) {
                      e.shrink(s);
                      break;
                    }
                    let u = $(c, `time`, 0),
                      d = $(c, `mixRotate`, 1),
                      f = $(c, `mixX`, 1),
                      p = $(c, `mixY`, f),
                      m = n.curve;
                    m &&
                      ((s = Q(m, e, s, i, 0, r, u, a, d, 1)),
                      (s = Q(m, e, s, i, 1, r, u, o, f, 1)),
                      (s = Q(m, e, s, i, 2, r, u, l, p, 1))),
                      (r = u),
                      (a = d),
                      (o = f),
                      (l = p),
                      (n = c);
                  }
                  i.push(e);
                }
              }
            }
          if (e.deform) {
            e.attachments = {};
            for (let t in e.deform) {
              let n = e.deform[t],
                r = (e.attachments[t] = {});
              for (let e in n) {
                let t = n[e],
                  i = (r[e] = {});
                for (let e in t) i[e] = { deform: t[e] };
              }
            }
          }
          if (e.attachments)
            for (let t in e.attachments) {
              let a = e.attachments[t],
                o = n.findSkin(t);
              if (o == null) {
                if (js.FAIL_ON_NON_EXISTING_SKIN)
                  throw Error(`Skin not found: ${t}`);
                continue;
              }
              for (let e in a) {
                let t = a[e],
                  s = n.findSlot(e);
                if (!s) throw Error(`Slot not found: ${e}`);
                let c = s.index;
                for (let e in t) {
                  let n = t[e],
                    a = o.getAttachment(c, e);
                  for (let e in n) {
                    let t = n[e],
                      o = t[0];
                    if (o) {
                      if (e == `deform`) {
                        let e = a.bones,
                          n = a.vertices,
                          s = e ? (n.length / 3) * 2 : n.length,
                          l = new Dc(t.length, t.length, c, a),
                          u = $(o, `time`, 0);
                        for (let i = 0, a = 0; ; i++) {
                          let c,
                            d = $(o, `vertices`, null);
                          if (!d) c = e ? G.newFloatArray(s) : n;
                          else {
                            c = G.newFloatArray(s);
                            let t = $(o, `offset`, 0);
                            if ((G.arrayCopy(d, 0, c, t, d.length), r != 1))
                              for (let e = t, n = e + d.length; e < n; e++)
                                c[e] *= r;
                            if (!e) for (let e = 0; e < s; e++) c[e] += n[e];
                          }
                          l.setFrame(i, u, c);
                          let f = t[i + 1];
                          if (!f) {
                            l.shrink(a);
                            break;
                          }
                          let p = $(f, `time`, 0),
                            m = o.curve;
                          m && (a = Q(m, l, a, i, 0, u, p, 0, 1, 1)),
                            (u = p),
                            (o = f);
                        }
                        i.push(l);
                      } else if (e == `sequence`) {
                        let e = new Rc(t.length, c, a),
                          n = 0;
                        for (let r = 0; r < t.length; r++) {
                          let i = $(o, `delay`, n),
                            a = $(o, `time`, 0),
                            s = ic[$(o, `mode`, `hold`)],
                            c = $(o, `index`, 0);
                          e.setFrame(r, a, s, c, i), (n = i), (o = t[r + 1]);
                        }
                        i.push(e);
                      }
                    }
                  }
                }
              }
            }
          if (e.drawOrder) {
            let t = new jc(e.drawOrder.length),
              r = n.slots.length,
              a = 0;
            for (let i = 0; i < e.drawOrder.length; i++, a++) {
              let o = e.drawOrder[i],
                s = null,
                c = $(o, `offsets`, null);
              if (c) {
                s = G.newArray(r, -1);
                let e = G.newArray(r - c.length, 0),
                  t = 0,
                  i = 0;
                for (let r = 0; r < c.length; r++) {
                  let a = c[r],
                    o = n.findSlot(a.slot);
                  if (!o) throw Error(`Slot not found: ${o}`);
                  let l = o.index;
                  for (; t != l; ) e[i++] = t++;
                  s[t + a.offset] = t++;
                }
                for (; t < r; ) e[i++] = t++;
                for (let t = r - 1; t >= 0; t--) s[t] == -1 && (s[t] = e[--i]);
              }
              t.setFrame(a, $(o, `time`, 0), s);
            }
            i.push(t);
          }
          if (e.events) {
            let t = new kc(e.events.length),
              r = 0;
            for (let i = 0; i < e.events.length; i++, r++) {
              let a = e.events[i],
                o = n.findEvent(a.name);
              if (!o) throw Error(`Event not found: ${a.name}`);
              let s = new ul(G.toSinglePrecision($(a, `time`, 0)), o);
              (s.intValue = $(a, `int`, o.intValue)),
                (s.floatValue = $(a, `float`, o.floatValue)),
                (s.stringValue = $(a, `string`, o.stringValue)),
                s.data.audioPath &&
                  ((s.volume = $(a, `volume`, 1)),
                  (s.balance = $(a, `balance`, 0))),
                t.setFrame(r, s);
            }
            i.push(t);
          }
          let a = 0;
          for (let e = 0, t = i.length; e < t; e++)
            a = Math.max(a, i[e].getDuration());
          if (isNaN(a))
            throw Error(`Error while parsing animation, duration is NaN`);
          n.animations.push(new sc(t, i, a));
        }
        static blendModeFromString(e) {
          if (((e = e.toLowerCase()), e == `normal`)) return F.NORMAL;
          if (e == `additive`) return F.ADD;
          if (e == `multiply`) return F.MULTIPLY;
          if (e == `screen`) return F.SCREEN;
          throw Error(`Unknown blend mode: ${e}`);
        }
      }),
      (vu = class {
        constructor(e, t, n, r, i) {
          (this.mesh = e),
            (this.skin = t),
            (this.slotIndex = n),
            (this.parent = r),
            (this.inheritTimeline = i);
        }
      });
  }))();
}
var bu;
function xu() {
  return (xu = t(() => {
    K(),
      kl(),
      $c(),
      tl(),
      (bu = class extends Ls {
        createSkeleton(e) {
          (this.skeleton = new Ol(e)),
            this.skeleton.updateWorldTransform(),
            (this.stateData = new el(e)),
            (this.state = new Vc(this.stateData));
        }
      });
  }))();
}
function Su() {
  return (Su = t(() => {
    Us(),
      Gs(),
      qs(),
      Ys(),
      Zs(),
      $s(),
      tc(),
      oc(),
      zc(),
      $c(),
      rl(),
      al(),
      sl(),
      hl(),
      Sl(),
      yl(),
      kl(),
      pu(),
      mu(),
      yu(),
      Rl(),
      wl(),
      Nl(),
      El(),
      xu();
  }))();
}
function Cu() {
  return (Cu = t(() => {
    Oo(), K(), Su(), z.Asset, z.LoadParser, ur.High + 1;
  }))();
}
function wu(e, t) {
  return t?.parsers.find((t) => t.name === e);
}
function Tu(e, t, n) {
  return qn(e, n) || Jn(e, t);
}
function Eu(e) {
  return Tu(e.src, `.json`, `application/json`);
}
async function Du(e, t) {
  let n = e.data?.atlasRawData;
  if (n) return n;
  let r = e.data?.atlasFile;
  if (r) {
    let e = wu(`loadTxt`, t),
      n;
    try {
      n = await e?.load?.(r);
    } catch (e) {
      console.error(`[PixiSpineExtension] Error loading atlas file "${r}":`, e);
      return;
    }
    if (!n) {
      console.error(
        `[PixiSpineExtension] Unknown error with atlas file "${r}"`
      );
      return;
    }
    return n;
  }
  console.error(
    `[PixiSpineExtension] No atlas specified in the metadata. You must specify either "atlasRawData" or "atlasFile"`
  );
}
function Ou(e) {
  let t = e.split(/\r\n|\r|\n/),
    n = [];
  for (let e of t)
    if (e.includes(`.png`)) {
      let t = L.basename(e.trim());
      n.push(t);
    }
  return (
    n.length === 0 &&
      console.warn(
        `[PixiSpineExtension] No image names found in the atlas file`
      ),
    n
  );
}
async function ku(e, t, n) {
  let r = t.data?.images?.[e];
  if (r) return r;
  let i = t.data?.imageFiles?.[e];
  if (i) {
    let e = wu(`loadTextures`, n),
      r;
    try {
      let a = L.toAbsolute(i),
        o = t.data?.imageMetadata;
      r = await e?.load?.(a, { src: a, data: o }, n);
    } catch (e) {
      console.error(`[PixiSpineExtension] Error loading image file "${i}":`, e);
      return;
    }
    if (!r) {
      console.error(
        `[PixiSpineExtension] Unknown error with image file "${i}"`
      );
      return;
    }
    return r;
  }
  console.error(
    `[PixiSpineExtension] No image found for "${e}" in the metadata. You must specify it either in "images" or "imageFiles"`
  );
}
function Au() {
  return (Au = t(() => {
    Oo();
  }))();
}
function ju() {
  I.add(Nu);
}
function Mu() {
  I.remove(Nu);
}
var Nu;
function Pu() {
  return (Pu = t(() => {
    Oo(),
      K(),
      Su(),
      Au(),
      (Nu = {
        extension: z.Asset,
        loader: {
          name: `loadSpine`,
          extension: { type: z.LoadParser, priority: ur.High },
          load: (e, t, n) => wu(`loadJson`, n)?.load?.(e, t, n),
          testParse: (e, t) => {
            let n = e?.hasOwnProperty(`bones`);
            return n && !t
              ? (console.warn(
                  `[PixiSpineExtension] Possible Spine asset without "LoadAsset" associated. Will NOT be processed`,
                  e
                ),
                Promise.resolve(!1))
              : Promise.resolve(n && !!t && Eu(t));
          },
          parse: async (e, t, n) => {
            if (!t) return;
            let r = await Du(t, n);
            if (!r) return;
            let i = Ou(r),
              a = {};
            for (let e of i) {
              let r = await ku(e, t, n);
              if (!r) return;
              a[e] = r;
            }
            let o = new vs(r, (e, t) => {
                let n = L.basename(e.trim());
                t(a[n].baseTexture);
              }),
              s = new nl(o),
              c = new _u(s);
            return (
              (c.scale = t?.data?.spineSkeletonScale ?? 1),
              { spineAtlas: o, spineData: c.readSkeletonData(e), images: a }
            );
          },
          unload: (e) => {
            Object.values(e.images).forEach((e) => e.destroy(!0));
          },
        },
      });
  }))();
}
function Fu() {
  return (Fu = t(() => {
    Cu(), Pu();
  }))();
}
var Iu, Lu, Ru, zu, Bu, Vu, Hu, Uu, Wu, Gu, Ku, qu, Ju;
function Yu() {
  return (Yu = t(() => {
    p(),
      (Iu = e(s())),
      (Lu = e(a())),
      Oo(),
      Vo(),
      Go(),
      ts(),
      Fu(),
      No(),
      g(),
      (Ru = 3),
      (zu = 500),
      (Bu = 3e4),
      (Vu = class extends Error {
        constructor(e) {
          super(e), (this.name = `PixiJSLoadTimeoutError`);
        }
      }),
      (Hu = (e, t) => {
        let n,
          r = new Promise((e, r) => {
            n = window.setTimeout(
              () => r(new Vu(`Timed out after ${Bu}ms loading ${t}`)),
              Bu
            );
          });
        return Promise.race([e, r]).finally(() => window.clearTimeout(n));
      }),
      (Uu = /\.(mp3|ogg|wav|m4a|json)(\?|#|$)/i),
      (Wu =
        /\S*\.(mp3|ogg|wav|m4a|json|atlas|png|jpe?g|webp|avif|gif|svg)\b\S*/gi),
      (Gu = ({ loadParser: e, url: t }) =>
        e ? e === `loadTextures` || e === `loadSVG` : !Uu.test(t)),
      (Ku = (e) =>
        (e instanceof Error ? e.message : String(e))
          .replaceAll(/\s+/g, ` `)
          .trim()
          .slice(0, zu)),
      (qu = (e) =>
        e.replaceAll(/https?:\/\/\S+/g, `<url>`).replaceAll(Wu, `<asset>`)),
      (Ju = class e extends Mo {
        static get instance() {
          return (
            e._instance || ((e._instance = new e()), Zr.init()), e._instance
          );
        }
        constructor() {
          super(),
            (this._isLoading = !1),
            (this.memoizedDebouncedReportResourceNotFoundError = Ho((e) => {
              d(Error(`Pixi resource "${e}" not found`), { name: e }, `error`);
            }, 1e3)),
            (this.memoizedDebouncedReportResourceTypeError = Ho(
              (e, t) => {
                d(
                  Error(`Pixi resource "${e.name}" is NOT "${t}"`),
                  { resource: e },
                  `error`
                );
              },
              1e3,
              void 0,
              (e, t) => `${e.name}-${t}`
            )),
            (this.memoizedDebouncedReportLoadFailure = Ho(
              (e, { addedResource: t, attempts: n, reason: r }) => {
                let i = qu(r);
                d(
                  Error(`Pixi resource failed to load: ${i}`),
                  {
                    name: e,
                    url: t.url,
                    loadParser: t.loadParser ?? null,
                    attempts: n,
                    reason: r,
                  },
                  `error`,
                  [`pixi-resource-load-failed`, i]
                );
              },
              1e3,
              void 0,
              (e, { reason: t }) => `${e}-${t}`
            )),
            (this.logType = `loader`),
            (this.enqueuedResources = {}),
            (this.failedToLoadResources = {}),
            (this.loadedResources = {}),
            (this._config = {
              registerSoundResources: !1,
              registerSpineResources: !1,
            }),
            this.log(`Created`);
        }
        get isLoading() {
          return this._isLoading;
        }
        get theme() {
          return this._theme;
        }
        set theme(e) {
          this._theme = e;
        }
        getInternalResourceName(e, t) {
          return t ? `${e}__${t}` : e;
        }
        updateLoadProgress() {
          Bo(this.getLoadProgress());
        }
        getLoadProgress() {
          let e = Object.keys(this.enqueuedResources),
            t = e.length;
          return t
            ? (e.filter((e) => e in this.loadedResources).length +
                e.filter((e) => e in this.failedToLoadResources).length) /
                t
            : 1;
        }
        destroy() {
          (this._isLoading = !1),
            (this._theme = void 0),
            (this.enqueuedResources = {}),
            (this.failedToLoadResources = {}),
            this.log(`destroy(): Unloading resources`);
          let e = Object.values(this.loadedResources).map(
            (e) => e.addedResource.url
          );
          Zr.unload(e)
            .then(() => {
              this.log(` ✓ All assets unloaded successfully`);
            })
            .catch((e) => {
              this.warn(` ✕ Error unloading assets`, e);
            })
            .finally(() => {
              Zr.reset();
            }),
            (this.loadedResources = {}),
            this.log(`destroy(): Destroy finished`),
            this.dispatchEvent(m.DESTROYED);
        }
        enqueue(e) {
          this.log(`enqueue(): Enqueue resources`),
            e.forEach((e) => {
              let t = this.getInternalResourceName(e.name, e.theme);
              if (this.hasResource(t)) {
                this.log(` --> (Skipping) "${t}" [${e.url}]`);
                return;
              }
              this.log(` --> "${t}" [${e.url}]`),
                (this.enqueuedResources[t] = e);
            });
        }
        setup(e) {
          this._config = {
            registerSoundResources:
              e?.registerSoundResources || this._config.registerSoundResources,
            registerSpineResources:
              e?.registerSpineResources || this._config.registerSpineResources,
          };
        }
        async load() {
          if (this._isLoading) {
            this.warn(`load(): Called while already loading`);
            return;
          }
          if ((0, Lu.default)(this.enqueuedResources)) {
            this.log(`load(): No resources to load`),
              this.dispatchEvent(m.LOADED);
            return;
          }
          let e = Object.keys(this.enqueuedResources),
            t = {};
          e.forEach((e) => {
            let n = this.enqueuedResources[e];
            t[n.url] = n;
          });
          let n = e.map((e) => {
            let t = this.enqueuedResources[e];
            return {
              src: t.url,
              alias: [e],
              loadParser: t.loadParser,
              data: t.data,
            };
          });
          this.log(`load(): Loading resources`, e), (this._isLoading = !0);
          let r = Object.values(this.failedToLoadResources)
            .filter(({ attempts: e }) => e < Ru)
            .map(({ addedResource: e }) => e.url);
          if (r.length > 0)
            try {
              await Zr.unload(r);
            } catch (e) {
              this.warn(`✕ Error unloading failed resources`, e);
            }
          let { registerSoundResources: i, registerSpineResources: a } =
            this._config;
          i &&
            (this.log(
              `- Config "registerSoundResources" found: registering PixiSound extension`
            ),
            Jo()),
            a &&
              (this.log(
                `- Config "registerSpineResources" found: registering PixiSpine extension`
              ),
              ju()),
            await Promise.all(
              n.map((e) =>
                Hu(Zr.load([e]), e.src)
                  .then((e) => {
                    Object.keys(e).forEach((n) => {
                      let r = t[n];
                      if (!r) {
                        this.warn(
                          ` ✕ Error: Resource not found for loaded texture`,
                          n
                        );
                        return;
                      }
                      let i = this.getInternalResourceName(r.name, r.theme);
                      this.log(` ✓ Loaded: `, i),
                        (this.loadedResources[i] = {
                          name: i,
                          addedResource: r,
                          resource: e[n],
                        }),
                        delete this.failedToLoadResources[i];
                    }),
                      this.updateLoadProgress();
                  })
                  .catch((n) => {
                    this.warn(`✕  Error loading single resource`, n);
                    let r = t[e.src];
                    if (!r) return;
                    let i = this.getInternalResourceName(r.name, r.theme),
                      a = this.failedToLoadResources[i]?.attempts ?? 0;
                    this.failedToLoadResources[i] = {
                      addedResource: r,
                      attempts: n instanceof Vu ? Ru : a + 1,
                      reason: Ku(n),
                    };
                  })
              )
            ),
            i && (this.log(`- Unregistering PixiSound extension`), Yo()),
            a && (this.log(`- Unregistering PixiSpine extension`), Mu()),
            this.log(`load(): Load finished`),
            e.forEach((e) => {
              let t = this.failedToLoadResources[e];
              (!t || t.attempts >= Ru) && delete this.enqueuedResources[e];
            }),
            this.updateLoadProgress(),
            (this._isLoading = !1),
            (0, Lu.default)(this.enqueuedResources)
              ? (Object.entries(this.failedToLoadResources).forEach(
                  ([e, t]) => {
                    let { addedResource: n, reason: r } = t;
                    this.warn(` ✕ Giving up on "${e}" [${n.url}]: ${r}`),
                      this.memoizedDebouncedReportLoadFailure(e, t),
                      Gu(n) &&
                        (this.loadedResources[e] = {
                          name: e,
                          addedResource: n,
                          resource: B.EMPTY,
                        });
                  }
                ),
                (this.failedToLoadResources = {}),
                this.updateLoadProgress(),
                this.dispatchEvent(m.LOADED))
              : (this.log(
                  ` --> [Continue to load more resources]`,
                  Object.keys(this.enqueuedResources)
                ),
                this.load());
        }
        hasResource(e) {
          return this.hasEnqueuedResource(e) || this.hasLoadedResource(e);
        }
        hasEnqueuedResource(e) {
          let t = this.getInternalResourceName(e, this.theme);
          return !!this.enqueuedResources[t] || !!this.enqueuedResources[e];
        }
        hasLoadedResource(e) {
          let t = this.getInternalResourceName(e, this.theme);
          return !!this.loadedResources[t] || !!this.loadedResources[e];
        }
        getResource(e, t = !0) {
          if (!this.hasLoadedResource(e)) {
            t &&
              (this.warn(`getResource(): Resource with name "${e}" not found`),
              this.memoizedDebouncedReportResourceNotFoundError(e));
            return;
          }
          let n = this.getInternalResourceName(e, this.theme);
          return this.loadedResources[n] ?? this.loadedResources[e];
        }
        getResources(e, t = !0) {
          return (0, Iu.default)(e.map((e) => this.getResource(e, t)));
        }
        getResourceTexture(e, t = !0) {
          let n = this.getResource(e, t);
          if (n) {
            if (!(n.resource instanceof B)) {
              t &&
                (this.warn(
                  `getResourceTexture(): Resource with name "${e}" is not a Texture resource`
                ),
                this.memoizedDebouncedReportResourceTypeError(n, `texture`));
              return;
            }
            return n.resource;
          }
        }
        getResourceTextures(e, t = !0) {
          return (0, Iu.default)(e.map((e) => this.getResourceTexture(e, t)));
        }
        getResourceSound(e, t = !0) {
          let n = this.getResource(e, t);
          if (n) {
            if (!(n.resource instanceof Ko)) {
              t &&
                (this.warn(
                  `getResourceSound(): Resource with name "${e}" is not a Sound resource`
                ),
                this.memoizedDebouncedReportResourceTypeError(n, `sound`));
              return;
            }
            return n.resource;
          }
        }
        getResourceSounds(e, t = !0) {
          return (0, Iu.default)(e.map((e) => this.getResourceSound(e, t)));
        }
        getResourceSpine(e, t = !0) {
          let n = this.getResource(e, t);
          if (n) {
            if (!n.resource?.spineData) {
              t &&
                (this.warn(
                  `getResourceSpine(): Resource with name "${e}" is not a Spine resource`
                ),
                this.memoizedDebouncedReportResourceTypeError(n, `spine`));
              return;
            }
            return n.resource;
          }
        }
        getResourceJSON(e, t = !0) {
          let n = this.getResource(e, t);
          if (n) {
            if (typeof n.resource != `object`) {
              t &&
                (this.warn(
                  `getResourceJSON(): Resource with name "${e}" is not a JSON resource`
                ),
                this.memoizedDebouncedReportResourceTypeError(n, `json`));
              return;
            }
            return n.resource;
          }
        }
        getResourceUrl(e, t = !0) {
          return this.getResource(e, t)?.addedResource.url;
        }
      });
  }))();
}
var Xu, Zu;
function Qu() {
  return (Qu = t(() => {
    (Xu = e(s())),
      Oo(),
      v(),
      y(),
      zo(),
      u(),
      No(),
      Yu(),
      g(),
      (Zu = class e extends Mo {
        constructor(t) {
          super(),
            (this._disposedAssetsOnDestroy = !1),
            (this._withTweening = !1),
            (this._withSound = !1),
            (this._withSpine = !1),
            (this._withContextReuse = !1),
            (this._isResponsive = !1),
            (this._isLoaded = !1),
            (this._isLoading = !1),
            (this._isAttached = !1),
            (this._isStarted = !1),
            (this._isFinished = !1),
            (this._isDestroyed = !1),
            (this._isFirstTickAfterVisiblityChange = !1),
            (this._currentTime = 0),
            (this._onLoaderComplete = () => this.onLoaderComplete()),
            (this.handleVisibilityChange = () => {
              document.visibilityState === `hidden` &&
                (this._isFirstTickAfterVisiblityChange = !0);
            }),
            (this.addChild = (...e) => this.app.stage.addChild(...e)),
            (this.removeChild = (...e) => this.app.stage.removeChild(...e)),
            (this.setChildIndex = (...e) => this.app.stage.setChildIndex(...e)),
            (this.disableContextMenu = (e) => {
              e.preventDefault();
            }),
            (this.sprites = {}),
            (this._tweens = {});
          let {
            antialias: n,
            forceCanvas: r,
            width: i,
            height: a,
            backgroundColor: o,
            backgroundAlpha: s,
            resolution: c,
            withTweening: l,
            withSound: u,
            withSpine: d,
            withContextReuse: p,
            disposeAssetsOnDestroy: m,
            skipGlobalRegistration: h,
            minFPS: g,
          } = { ...f(), ...t };
          (this._initialWidth = i),
            (this._initialHeight = a),
            (this._withTweening = !!l),
            (this._withSound = !!u),
            (this._withSpine = !!d),
            (this._disposedAssetsOnDestroy = !!m),
            (this._withContextReuse = !!p),
            this.log(`Creating`),
            this._withTweening && this.log(` - With tweening support!`),
            this._withSound && this.log(` - With sound support!`),
            this._withSpine && this.log(` - With spine support!`),
            this._withContextReuse &&
              this.log(` - With context reuse support!`),
            (this.app = new Ro({
              antialias: n,
              forceCanvas: r,
              width: i,
              height: a,
              backgroundColor: o,
              backgroundAlpha: s,
              resolution: c,
              preserveContext: !r && this._withContextReuse,
            })),
            (e._app = this.app),
            g !== void 0 && (this.app.ticker.minFPS = g),
            this.app.view.addEventListener(
              `contextmenu`,
              this.disableContextMenu
            ),
            document.addEventListener(
              `visibilitychange`,
              this.handleVisibilityChange
            ),
            h
              ? this.log(`- [WARNING] Skipping global PIXI app registration`)
              : ((globalThis.__PIXI_APP__ = this.app),
                this.log(`- Registered global PIXI app for devtools`)),
            this.log(`Created`),
            this._withContextReuse &&
              (this.app.isReusingContext &&
                this.log(` - [WithContextReuse] Reusing context`),
              this.app.isReusingContext ||
                this.log(` - [WithContextReuse] NOT reusing context`));
        }
        get children() {
          return this.app?.stage?.children;
        }
        get loader() {
          if (!this._loader)
            throw Error(`Trying to access loader in a non-loaded game`);
          return this._loader;
        }
        get gameConfig() {
          return this._gameConfig;
        }
        get gameFinishedData() {
          return this._gameFinishData;
        }
        get initialWidth() {
          return this._initialWidth;
        }
        get initialHeight() {
          return this._initialHeight;
        }
        get isLoaded() {
          return this._isLoaded;
        }
        get isLoading() {
          return this._isLoading;
        }
        get isAttached() {
          return this._isAttached;
        }
        get isStarted() {
          return this._isStarted;
        }
        get isFinished() {
          return this._isFinished;
        }
        get isDestroyed() {
          return this._isDestroyed;
        }
        get currentTime() {
          return this._currentTime;
        }
        static get app() {
          return this._app;
        }
        static get stage() {
          return this._app?.stage;
        }
        onLoaderComplete() {
          this.log(`onLoaderComplete()`),
            this._loader?.removeListener(m.LOADED, this._onLoaderComplete),
            (this._isLoading = !1),
            (this._isLoaded = !0),
            this.dispatchEvent(h.LOADED);
        }
        static async preloadResourcesAsync(e, t) {
          let n = Ju.instance;
          return n.setup(t), n.enqueue(e), n.load();
        }
        static preloadResources(t, n) {
          e.preloadResourcesAsync(t, n);
        }
        load() {
          if (
            (this._isDestroyed && this.warn(`Trying to load a destroyed game`),
            this._isLoaded)
          ) {
            this.warn(`Trying to load an already loaded game`);
            return;
          }
          if (this._isLoading) {
            this.warn(`Trying to load a game that is currently being loaded`);
            return;
          }
          this.log(`load()`),
            (this._isLoading = !0),
            this.dispatchEvent(h.LOADING),
            (this._loader = Ju.instance),
            this._loader.addListener(m.LOADED, this._onLoaderComplete),
            this._loader.enqueue(this.getResources()),
            setTimeout(() => {
              this._isDestroyed ||
                (this._loader &&
                  !this._loader.isLoading &&
                  (this._loader.setup({
                    registerSoundResources: this._withSound,
                    registerSpineResources: this._withSpine,
                  }),
                  this._loader.load()));
            });
        }
        attachToView(e, t) {
          if ((this.log(`attachToView()`), this._isDestroyed))
            throw Error(`Cannot attach a destroyed game`);
          if (this._isAttached)
            throw Error(`Cannot attach an already attached game`);
          (this._isAttached = !0),
            (this._isResponsive = !!t),
            e.appendChild(this.app.view),
            t && (this.app.resizeTo = e);
        }
        async start(e) {
          if ((this.log(`start()`), this._isDestroyed))
            throw Error(`Cannot start a destroyed game`);
          if (!this._isLoaded) throw Error(`Game must be loaded before start`);
          this._withTweening &&
            (this.log(`tweening scheduling captured`),
            (this._updateTweens = b(() => this._currentTime))),
            (this._gameConfig = e);
          try {
            await this.gameSetup();
          } catch (e) {
            this.warn(`Error during game setup`, e),
              this.dispatchEvent(h.ERROR, e);
          }
          (this._isStarted = !0),
            this.dispatchEvent(h.STARTED, e),
            this.app.ticker?.add(this.loop.bind(this));
        }
        pauseRendering() {
          this._isDestroyed || !this._isStarted || this.app.ticker?.stop();
        }
        resumeRendering() {
          this._isDestroyed || !this._isStarted || this.app.ticker?.start();
        }
        update(e) {
          if ((this.log(`update()`), this._isDestroyed))
            throw Error(`Cannot update a destroyed game`);
          if (!this._isLoaded) throw Error(`Game must be loaded before update`);
          this._isStarted || this.warn(`Updating a non-started game`);
          let t = this._gameConfig;
          (this._gameConfig = e),
            this.gameUpdate(t),
            this.dispatchEvent(h.UPDATED, e);
        }
        destroy() {
          if (this._isDestroyed) {
            this.warn(`Trying to destroy an already destroyed game`);
            return;
          }
          this.log(`destroy()`),
            document.removeEventListener(
              `visibilitychange`,
              this.handleVisibilityChange
            ),
            this._withTweening &&
              (this.log(`- tweening scheduling released`), x()),
            this._withSound &&
              (this.log(`- stopping all sounds`),
              (0, Xu.default)(
                this.getResources()
                  .map(({ name: e }) => e)
                  .filter((e) => this._loader?.hasLoadedResource(e))
                  .map((e) => this._loader?.getResourceSound(e, !1))
              ).forEach((e) => e.stop())),
            this.gameDestroy(),
            (this._gameConfig = void 0),
            (this._isAttached = !1),
            (this._isResponsive = !1),
            (this._isLoaded = !1),
            (this._isLoading = !1),
            (this._isStarted = !1),
            (this._isFinished = !1),
            (this._isDestroyed = !0),
            (this._withTweening = !1),
            (this._withSound = !1),
            (this._withSpine = !1),
            (this._currentTime = 0),
            this._loader?.removeListener(m.LOADED, this._onLoaderComplete);
          for (let e of Object.keys(this._tweens)) this._tweens[e].destroy();
          for (let e of Object.keys(this.sprites))
            this.sprites[e].destroyed ||
              this.sprites[e].destroy({
                children: !0,
                texture: this._disposedAssetsOnDestroy,
                baseTexture: this._disposedAssetsOnDestroy,
              });
          this.app.view.removeEventListener(
            `contextmenu`,
            this.disableContextMenu
          ),
            this.app.ticker?.stop(),
            (this.app.view.width = 1),
            (this.app.view.height = 1),
            this.app.destroy(!0, { children: !0 }),
            (e._app = void 0),
            this.dispatchEvent(h.DESTROYED),
            this.log(`Destroyed`);
        }
        resize(e, t) {
          if (!this._isResponsive) {
            this.warn(`resize() has no effect on non-responsive games`);
            return;
          }
          this.app.resize(), this.gameResize(e, t);
        }
        dispatchDataEvent(e) {
          this.dispatchEvent(h.DATA, e);
        }
        loop() {
          if (this._isFirstTickAfterVisiblityChange) {
            this._isFirstTickAfterVisiblityChange = !1;
            return;
          }
          if (!this._isFinished && this.isGameFinished()) {
            this._isFinished = !0;
            let e = this.gameFinished();
            (this._gameFinishData = e), this.dispatchEvent(h.FINISHED, e);
          }
          let e = this.app.ticker.deltaTime,
            t = this.app.ticker.deltaMS;
          this._currentTime += t;
          try {
            this._updateTweens?.(), this.gameLoop(e, t);
          } catch (e) {
            this.warn(`Error during game loop`, e),
              this.dispatchEvent(h.ERROR, e);
          }
        }
        gameUpdate(e) {
          this.warn(`gameUpdate() is not implemented in derived class`);
        }
        gameResize(e, t) {
          this.warn(
            `gameResize(${e}, ${t}) is not implemented in derived class`
          );
        }
        gameLoop(e, t) {}
        isGameFinished() {
          return !1;
        }
        gameFinished() {
          this.warn(`gameFinished() is not implemented in derived class`);
        }
        gameDestroy() {}
        trackSprite(e) {
          let { name: t, sprite: n } = e;
          this.sprites[t] &&
            this.warn(`Another Sprite was already created with name "${t}"`),
            (this.sprites[t] = n);
        }
        getSprite(e) {
          let { name: t, textureName: n } = e,
            r;
          n && (r = this._loader?.getResourceTexture(n));
          let i = new w(r);
          return this.trackSprite({ name: t, sprite: i }), i;
        }
        getTilingSprite(e) {
          let { name: t, textureName: n, width: r, height: i } = e,
            a = this._loader?.getResourceTexture(n);
          if (!a) throw Error(`Cannot find texture with name "${n}"`);
          let o = new Me(a, r, i);
          return this.trackSprite({ name: t, sprite: o }), o;
        }
        getTween(e) {
          let { name: t, config: n, autoPlay: r, autoDispose: i } = e,
            a = _({
              ...n,
              onFinish: (e, r) => {
                n.onFinish?.(e, r), i && (a.destroy(), delete this._tweens[t]);
              },
            });
          return (
            r && a.play(),
            this._tweens[t] &&
              (this.warn(
                `Another Tween was already created with name "${t}". It will be disposed`
              ),
              this._tweens[t].destroy()),
            (this._tweens[t] = a),
            a
          );
        }
        resolution() {
          return this.app.renderer.resolution;
        }
        stageWidth() {
          return this.app.renderer.screen.width;
        }
        stageHeight() {
          return this.app.renderer.screen.height;
        }
      });
  }))();
}
export {
  nt as S,
  Ot as _,
  Su as a,
  ut as b,
  Mo as c,
  Ea as d,
  Da as f,
  Dt as g,
  kt as h,
  Yu as i,
  No as l,
  Ht as m,
  Qu as n,
  bu as o,
  Vt as p,
  Ju as r,
  xu as s,
  Zu as t,
  Oo as u,
  St as v,
  dt as x,
  Ct as y,
};
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/pixijs-game-zi5bgXGP.js.map
