import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import {
  Bt as t,
  H as n,
  Rt as r,
  U as i,
  Y as a,
  at as o,
} from "./lib-BTerfQ6O.js";
function s(e, t) {
  if (e) {
    if (typeof e == `function`) return e;
    if (typeof e == `string`) return m[e];
  } else return m[t];
}
var c,
  l,
  u,
  d,
  f,
  p,
  m,
  h,
  g,
  _,
  v,
  y,
  b,
  x,
  S,
  C,
  w,
  T,
  E,
  D,
  O,
  k,
  A,
  j,
  M,
  N,
  P,
  F,
  I,
  L,
  R,
  z,
  B,
  V,
  H,
  U,
  W;
function G() {
  return (G = e(() => {
    a(),
      n(),
      (c = Object.defineProperty),
      (l = (e, t, n) =>
        t in e
          ? c(e, t, {
              enumerable: !0,
              configurable: !0,
              writable: !0,
              value: n,
            })
          : (e[t] = n)),
      (u = (e, t, n) => (l(e, typeof t == `symbol` ? t : t + ``, n), n)),
      (d = class {
        constructor(e) {
          u(this, `parent`),
            u(this, `paused`),
            (this.parent = e),
            (this.paused = !1);
        }
        destroy() {}
        down(e) {
          return !1;
        }
        move(e) {
          return !1;
        }
        up(e) {
          return !1;
        }
        wheel(e) {
          return !1;
        }
        update(e) {}
        resize() {}
        reset() {}
        pause() {
          this.paused = !0;
        }
        resume() {
          this.paused = !1;
        }
      }),
      (f =
        typeof globalThis < `u`
          ? globalThis
          : typeof window < `u`
          ? window
          : typeof global < `u`
          ? global
          : typeof self < `u`
          ? self
          : {}),
      (p = { exports: {} }),
      (function (e, t) {
        (function () {
          var t = {
            linear: function (e, t, n, r) {
              return (n * e) / r + t;
            },
            easeInQuad: function (e, t, n, r) {
              return n * (e /= r) * e + t;
            },
            easeOutQuad: function (e, t, n, r) {
              return -n * (e /= r) * (e - 2) + t;
            },
            easeInOutQuad: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (n / 2) * e * e + t
                : (-n / 2) * (--e * (e - 2) - 1) + t;
            },
            easeInCubic: function (e, t, n, r) {
              return n * (e /= r) * e * e + t;
            },
            easeOutCubic: function (e, t, n, r) {
              return n * ((e = e / r - 1) * e * e + 1) + t;
            },
            easeInOutCubic: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (n / 2) * e * e * e + t
                : (n / 2) * ((e -= 2) * e * e + 2) + t;
            },
            easeInQuart: function (e, t, n, r) {
              return n * (e /= r) * e * e * e + t;
            },
            easeOutQuart: function (e, t, n, r) {
              return -n * ((e = e / r - 1) * e * e * e - 1) + t;
            },
            easeInOutQuart: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (n / 2) * e * e * e * e + t
                : (-n / 2) * ((e -= 2) * e * e * e - 2) + t;
            },
            easeInQuint: function (e, t, n, r) {
              return n * (e /= r) * e * e * e * e + t;
            },
            easeOutQuint: function (e, t, n, r) {
              return n * ((e = e / r - 1) * e * e * e * e + 1) + t;
            },
            easeInOutQuint: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (n / 2) * e * e * e * e * e + t
                : (n / 2) * ((e -= 2) * e * e * e * e + 2) + t;
            },
            easeInSine: function (e, t, n, r) {
              return -n * Math.cos((e / r) * (Math.PI / 2)) + n + t;
            },
            easeOutSine: function (e, t, n, r) {
              return n * Math.sin((e / r) * (Math.PI / 2)) + t;
            },
            easeInOutSine: function (e, t, n, r) {
              return (-n / 2) * (Math.cos((Math.PI * e) / r) - 1) + t;
            },
            easeInExpo: function (e, t, n, r) {
              return e === 0 ? t : n * 2 ** (10 * (e / r - 1)) + t;
            },
            easeOutExpo: function (e, t, n, r) {
              return e === r ? t + n : n * (-(2 ** ((-10 * e) / r)) + 1) + t;
            },
            easeInOutExpo: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (n / 2) * 2 ** (10 * (e - 1)) + t
                : (n / 2) * (-(2 ** (-10 * --e)) + 2) + t;
            },
            easeInCirc: function (e, t, n, r) {
              return -n * (Math.sqrt(1 - (e /= r) * e) - 1) + t;
            },
            easeOutCirc: function (e, t, n, r) {
              return n * Math.sqrt(1 - (e = e / r - 1) * e) + t;
            },
            easeInOutCirc: function (e, t, n, r) {
              return (e /= r / 2) < 1
                ? (-n / 2) * (Math.sqrt(1 - e * e) - 1) + t
                : (n / 2) * (Math.sqrt(1 - (e -= 2) * e) + 1) + t;
            },
            easeInElastic: function (e, t, n, r) {
              var i, a, o;
              return (
                (o = 1.70158),
                (a = 0),
                (i = n),
                e === 0 || (e /= r),
                (a ||= r * 0.3),
                i < Math.abs(n)
                  ? ((i = n), (o = a / 4))
                  : (o = (a / (2 * Math.PI)) * Math.asin(n / i)),
                -(
                  i *
                  2 ** (10 * --e) *
                  Math.sin(((e * r - o) * (2 * Math.PI)) / a)
                ) + t
              );
            },
            easeOutElastic: function (e, t, n, r) {
              var i, a, o;
              return (
                (o = 1.70158),
                (a = 0),
                (i = n),
                e === 0 || (e /= r),
                (a ||= r * 0.3),
                i < Math.abs(n)
                  ? ((i = n), (o = a / 4))
                  : (o = (a / (2 * Math.PI)) * Math.asin(n / i)),
                i *
                  2 ** (-10 * e) *
                  Math.sin(((e * r - o) * (2 * Math.PI)) / a) +
                  n +
                  t
              );
            },
            easeInOutElastic: function (e, t, n, r) {
              var i, a, o;
              return (
                (o = 1.70158),
                (a = 0),
                (i = n),
                e === 0 || (e /= r / 2),
                (a ||= 0.3 * 1.5 * r),
                i < Math.abs(n)
                  ? ((i = n), (o = a / 4))
                  : (o = (a / (2 * Math.PI)) * Math.asin(n / i)),
                e < 1
                  ? -0.5 *
                      (i *
                        2 ** (10 * --e) *
                        Math.sin(((e * r - o) * (2 * Math.PI)) / a)) +
                    t
                  : i *
                      2 ** (-10 * --e) *
                      Math.sin(((e * r - o) * (2 * Math.PI)) / a) *
                      0.5 +
                    n +
                    t
              );
            },
            easeInBack: function (e, t, n, r, i) {
              return (
                i === void 0 && (i = 1.70158),
                n * (e /= r) * e * ((i + 1) * e - i) + t
              );
            },
            easeOutBack: function (e, t, n, r, i) {
              return (
                i === void 0 && (i = 1.70158),
                n * ((e = e / r - 1) * e * ((i + 1) * e + i) + 1) + t
              );
            },
            easeInOutBack: function (e, t, n, r, i) {
              return (
                i === void 0 && (i = 1.70158),
                (e /= r / 2) < 1
                  ? (n / 2) * (e * e * (((i *= 1.525) + 1) * e - i)) + t
                  : (n / 2) *
                      ((e -= 2) * e * (((i *= 1.525) + 1) * e + i) + 2) +
                    t
              );
            },
            easeInBounce: function (e, n, r, i) {
              var a;
              return (a = t.easeOutBounce(i - e, 0, r, i)), r - a + n;
            },
            easeOutBounce: function (e, t, n, r) {
              return (e /= r) < 1 / 2.75
                ? n * (7.5625 * e * e) + t
                : e < 2 / 2.75
                ? n * (7.5625 * (e -= 1.5 / 2.75) * e + 0.75) + t
                : e < 2.5 / 2.75
                ? n * (7.5625 * (e -= 2.25 / 2.75) * e + 0.9375) + t
                : n * (7.5625 * (e -= 2.625 / 2.75) * e + 0.984375) + t;
            },
            easeInOutBounce: function (e, n, r, i) {
              var a;
              return e < i / 2
                ? ((a = t.easeInBounce(e * 2, 0, r, i)), a * 0.5 + n)
                : ((a = t.easeOutBounce(e * 2 - i, 0, r, i)),
                  a * 0.5 + r * 0.5 + n);
            },
          };
          (function (t) {
            return (e.exports = t);
          })(t);
        }.call(f));
      })(p),
      (m = p.exports),
      (h = { removeOnInterrupt: !1, ease: `linear`, time: 1e3 }),
      (g = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `startX`),
            u(this, `startY`),
            u(this, `deltaX`),
            u(this, `deltaY`),
            u(this, `keepCenter`),
            u(this, `startWidth`, null),
            u(this, `startHeight`, null),
            u(this, `deltaWidth`, null),
            u(this, `deltaHeight`, null),
            u(this, `width`, null),
            u(this, `height`, null),
            u(this, `time`, 0),
            (this.options = Object.assign({}, h, t)),
            (this.options.ease = s(this.options.ease)),
            this.setupPosition(),
            this.setupZoom(),
            (this.time = 0);
        }
        setupPosition() {
          typeof this.options.position < `u`
            ? ((this.startX = this.parent.center.x),
              (this.startY = this.parent.center.y),
              (this.deltaX = this.options.position.x - this.parent.center.x),
              (this.deltaY = this.options.position.y - this.parent.center.y),
              (this.keepCenter = !1))
            : (this.keepCenter = !0);
        }
        setupZoom() {
          (this.width = null),
            (this.height = null),
            typeof this.options.scale < `u`
              ? (this.width = this.parent.screenWidth / this.options.scale)
              : typeof this.options.scaleX < `u` ||
                typeof this.options.scaleY < `u`
              ? (typeof this.options.scaleX < `u` &&
                  (this.width = this.parent.screenWidth / this.options.scaleX),
                typeof this.options.scaleY < `u` &&
                  (this.height =
                    this.parent.screenHeight / this.options.scaleY))
              : (typeof this.options.width < `u` &&
                  (this.width = this.options.width),
                typeof this.options.height < `u` &&
                  (this.height = this.options.height)),
            this.width !== null &&
              ((this.startWidth = this.parent.screenWidthInWorldPixels),
              (this.deltaWidth = this.width - this.startWidth)),
            this.height !== null &&
              ((this.startHeight = this.parent.screenHeightInWorldPixels),
              (this.deltaHeight = this.height - this.startHeight));
        }
        down() {
          return (
            this.options.removeOnInterrupt &&
              this.parent.plugins.remove(`animate`),
            !1
          );
        }
        complete() {
          this.parent.plugins.remove(`animate`),
            this.width !== null &&
              this.parent.fitWidth(
                this.width,
                this.keepCenter,
                this.height === null
              ),
            this.height !== null &&
              this.parent.fitHeight(
                this.height,
                this.keepCenter,
                this.width === null
              ),
            !this.keepCenter &&
              this.options.position &&
              this.parent.moveCenter(this.options.position),
            this.parent.emit(`animate-end`, this.parent),
            this.options.callbackOnComplete &&
              this.options.callbackOnComplete(this.parent);
        }
        update(e) {
          if (this.paused) return;
          this.time += e;
          let n = new t(this.parent.scale.x, this.parent.scale.y);
          if (this.time >= this.options.time) {
            let e = this.parent.width,
              t = this.parent.height;
            this.complete(),
              (e !== this.parent.width || t !== this.parent.height) &&
                this.parent.emit(`zoomed`, {
                  viewport: this.parent,
                  original: n,
                  type: `animate`,
                });
          } else {
            let e = this.options.ease(this.time, 0, 1, this.options.time);
            if (this.width !== null) {
              let t = this.startWidth,
                n = this.deltaWidth;
              this.parent.fitWidth(
                t + n * e,
                this.keepCenter,
                this.height === null
              );
            }
            if (this.height !== null) {
              let t = this.startHeight,
                n = this.deltaHeight;
              this.parent.fitHeight(
                t + n * e,
                this.keepCenter,
                this.width === null
              );
            }
            if (
              (this.width === null
                ? (this.parent.scale.x = this.parent.scale.y)
                : this.height === null &&
                  (this.parent.scale.y = this.parent.scale.x),
              !this.keepCenter)
            ) {
              let n = this.startX,
                r = this.startY,
                i = this.deltaX,
                a = this.deltaY,
                o = new t(this.parent.x, this.parent.y);
              this.parent.moveCenter(n + i * e, r + a * e),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  original: o,
                  type: `animate`,
                });
            }
            (this.width || this.height) &&
              this.parent.emit(`zoomed`, {
                viewport: this.parent,
                original: n,
                type: `animate`,
              });
          }
        }
      }),
      (_ = {
        sides: `all`,
        friction: 0.5,
        time: 150,
        ease: `easeInOutSine`,
        underflow: `center`,
        bounceBox: null,
      }),
      (v = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `left`),
            u(this, `top`),
            u(this, `right`),
            u(this, `bottom`),
            u(this, `underflowX`),
            u(this, `underflowY`),
            u(this, `ease`),
            u(this, `toX`),
            u(this, `toY`),
            (this.options = Object.assign({}, _, t)),
            (this.ease = s(this.options.ease, `easeInOutSine`)),
            this.options.sides
              ? this.options.sides === `all`
                ? (this.top = this.bottom = this.left = this.right = !0)
                : this.options.sides === `horizontal`
                ? ((this.right = this.left = !0), (this.top = this.bottom = !1))
                : this.options.sides === `vertical`
                ? ((this.left = this.right = !1), (this.top = this.bottom = !0))
                : ((this.top = this.options.sides.indexOf(`top`) !== -1),
                  (this.bottom = this.options.sides.indexOf(`bottom`) !== -1),
                  (this.left = this.options.sides.indexOf(`left`) !== -1),
                  (this.right = this.options.sides.indexOf(`right`) !== -1))
              : (this.left = this.top = this.right = this.bottom = !1);
          let n = this.options.underflow.toLowerCase();
          n === `center`
            ? ((this.underflowX = 0), (this.underflowY = 0))
            : ((this.underflowX =
                n.indexOf(`left`) === -1
                  ? n.indexOf(`right`) === -1
                    ? 0
                    : 1
                  : -1),
              (this.underflowY =
                n.indexOf(`top`) === -1
                  ? n.indexOf(`bottom`) === -1
                    ? 0
                    : 1
                  : -1)),
            this.reset();
        }
        isActive() {
          return this.toX !== null || this.toY !== null;
        }
        down() {
          return (this.toX = this.toY = null), !1;
        }
        up() {
          return this.bounce(), !1;
        }
        update(e) {
          if (!this.paused) {
            if ((this.bounce(), this.toX)) {
              let t = this.toX;
              (t.time += e),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `bounce-x`,
                }),
                t.time >= this.options.time
                  ? ((this.parent.x = t.end),
                    (this.toX = null),
                    this.parent.emit(`bounce-x-end`, this.parent))
                  : (this.parent.x = this.ease(
                      t.time,
                      t.start,
                      t.delta,
                      this.options.time
                    ));
            }
            if (this.toY) {
              let t = this.toY;
              (t.time += e),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `bounce-y`,
                }),
                t.time >= this.options.time
                  ? ((this.parent.y = t.end),
                    (this.toY = null),
                    this.parent.emit(`bounce-y-end`, this.parent))
                  : (this.parent.y = this.ease(
                      t.time,
                      t.start,
                      t.delta,
                      this.options.time
                    ));
            }
          }
        }
        calcUnderflowX() {
          let e;
          switch (this.underflowX) {
            case -1:
              e = 0;
              break;
            case 1:
              e = this.parent.screenWidth - this.parent.screenWorldWidth;
              break;
            default:
              e = (this.parent.screenWidth - this.parent.screenWorldWidth) / 2;
          }
          return e;
        }
        calcUnderflowY() {
          let e;
          switch (this.underflowY) {
            case -1:
              e = 0;
              break;
            case 1:
              e = this.parent.screenHeight - this.parent.screenWorldHeight;
              break;
            default:
              e =
                (this.parent.screenHeight - this.parent.screenWorldHeight) / 2;
          }
          return e;
        }
        oob() {
          let e = this.options.bounceBox;
          if (e) {
            let n = typeof e.x > `u` ? 0 : e.x,
              r = typeof e.y > `u` ? 0 : e.y,
              i = typeof e.width > `u` ? this.parent.worldWidth : e.width,
              a = typeof e.height > `u` ? this.parent.worldHeight : e.height;
            return {
              left: this.parent.left < n,
              right: this.parent.right > i,
              top: this.parent.top < r,
              bottom: this.parent.bottom > a,
              topLeft: new t(n * this.parent.scale.x, r * this.parent.scale.y),
              bottomRight: new t(
                i * this.parent.scale.x - this.parent.screenWidth,
                a * this.parent.scale.y - this.parent.screenHeight
              ),
            };
          }
          return {
            left: this.parent.left < 0,
            right: this.parent.right > this.parent.worldWidth,
            top: this.parent.top < 0,
            bottom: this.parent.bottom > this.parent.worldHeight,
            topLeft: new t(0, 0),
            bottomRight: new t(
              this.parent.worldWidth * this.parent.scale.x -
                this.parent.screenWidth,
              this.parent.worldHeight * this.parent.scale.y -
                this.parent.screenHeight
            ),
          };
        }
        bounce() {
          if (this.paused) return;
          let e,
            t = this.parent.plugins.get(`decelerate`, !0);
          t &&
            (t.x || t.y) &&
            ((t.x && t.percentChangeX === t.options?.friction) ||
              (t.y && t.percentChangeY === t.options?.friction)) &&
            ((e = this.oob()),
            ((e.left && this.left) || (e.right && this.right)) &&
              (t.percentChangeX = this.options.friction),
            ((e.top && this.top) || (e.bottom && this.bottom)) &&
              (t.percentChangeY = this.options.friction));
          let n = this.parent.plugins.get(`drag`, !0) || {},
            r = this.parent.plugins.get(`pinch`, !0) || {};
          if (
            ((t ||= {}),
            !(n != null && n.active) &&
              !(r != null && r.active) &&
              (!this.toX || !this.toY) &&
              (!t.x || !t.y))
          ) {
            e ||= this.oob();
            let n = e.topLeft,
              r = e.bottomRight;
            if (!this.toX && !t.x) {
              let t = null;
              e.left && this.left
                ? (t =
                    this.parent.screenWorldWidth < this.parent.screenWidth
                      ? this.calcUnderflowX()
                      : -n.x)
                : e.right &&
                  this.right &&
                  (t =
                    this.parent.screenWorldWidth < this.parent.screenWidth
                      ? this.calcUnderflowX()
                      : -r.x),
                t !== null &&
                  this.parent.x !== t &&
                  ((this.toX = {
                    time: 0,
                    start: this.parent.x,
                    delta: t - this.parent.x,
                    end: t,
                  }),
                  this.parent.emit(`bounce-x-start`, this.parent));
            }
            if (!this.toY && !t.y) {
              let t = null;
              e.top && this.top
                ? (t =
                    this.parent.screenWorldHeight < this.parent.screenHeight
                      ? this.calcUnderflowY()
                      : -n.y)
                : e.bottom &&
                  this.bottom &&
                  (t =
                    this.parent.screenWorldHeight < this.parent.screenHeight
                      ? this.calcUnderflowY()
                      : -r.y),
                t !== null &&
                  this.parent.y !== t &&
                  ((this.toY = {
                    time: 0,
                    start: this.parent.y,
                    delta: t - this.parent.y,
                    end: t,
                  }),
                  this.parent.emit(`bounce-y-start`, this.parent));
            }
          }
        }
        reset() {
          (this.toX = this.toY = null), this.bounce();
        }
      }),
      (y = {
        left: !1,
        right: !1,
        top: !1,
        bottom: !1,
        direction: null,
        underflow: `center`,
      }),
      (b = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `last`),
            u(this, `noUnderflow`),
            u(this, `underflowX`),
            u(this, `underflowY`),
            (this.options = Object.assign({}, y, t)),
            this.options.direction &&
              ((this.options.left =
                this.options.direction === `x` ||
                this.options.direction === `all` ||
                null),
              (this.options.right =
                this.options.direction === `x` ||
                this.options.direction === `all` ||
                null),
              (this.options.top =
                this.options.direction === `y` ||
                this.options.direction === `all` ||
                null),
              (this.options.bottom =
                this.options.direction === `y` ||
                this.options.direction === `all` ||
                null)),
            this.parseUnderflow(),
            (this.last = { x: null, y: null, scaleX: null, scaleY: null }),
            this.update();
        }
        parseUnderflow() {
          let e = this.options.underflow.toLowerCase();
          e === `none`
            ? (this.noUnderflow = !0)
            : e === `center`
            ? ((this.underflowX = this.underflowY = 0), (this.noUnderflow = !1))
            : ((this.underflowX =
                e.indexOf(`left`) === -1
                  ? e.indexOf(`right`) === -1
                    ? 0
                    : 1
                  : -1),
              (this.underflowY =
                e.indexOf(`top`) === -1
                  ? e.indexOf(`bottom`) === -1
                    ? 0
                    : 1
                  : -1),
              (this.noUnderflow = !1));
        }
        move() {
          return this.update(), !1;
        }
        update() {
          if (
            this.paused ||
            (this.parent.x === this.last.x &&
              this.parent.y === this.last.y &&
              this.parent.scale.x === this.last.scaleX &&
              this.parent.scale.y === this.last.scaleY)
          )
            return;
          let e = new t(this.parent.x, this.parent.y),
            n = this.parent.plugins.decelerate || {};
          if (this.options.left !== null || this.options.right !== null) {
            let t = !1;
            if (
              !this.noUnderflow &&
              this.parent.screenWorldWidth < this.parent.screenWidth
            )
              switch (this.underflowX) {
                case -1:
                  this.parent.x !== 0 && ((this.parent.x = 0), (t = !0));
                  break;
                case 1:
                  this.parent.x !==
                    this.parent.screenWidth - this.parent.screenWorldWidth &&
                    ((this.parent.x =
                      this.parent.screenWidth - this.parent.screenWorldWidth),
                    (t = !0));
                  break;
                default:
                  this.parent.x !==
                    (this.parent.screenWidth - this.parent.screenWorldWidth) /
                      2 &&
                    ((this.parent.x =
                      (this.parent.screenWidth - this.parent.screenWorldWidth) /
                      2),
                    (t = !0));
              }
            else
              this.options.left !== null &&
                this.parent.left <
                  (this.options.left === !0 ? 0 : this.options.left) &&
                ((this.parent.x =
                  -(this.options.left === !0 ? 0 : this.options.left) *
                  this.parent.scale.x),
                (n.x = 0),
                (t = !0)),
                this.options.right !== null &&
                  this.parent.right >
                    (this.options.right === !0
                      ? this.parent.worldWidth
                      : this.options.right) &&
                  ((this.parent.x =
                    -(this.options.right === !0
                      ? this.parent.worldWidth
                      : this.options.right) *
                      this.parent.scale.x +
                    this.parent.screenWidth),
                  (n.x = 0),
                  (t = !0));
            t &&
              this.parent.emit(`moved`, {
                viewport: this.parent,
                original: e,
                type: `clamp-x`,
              });
          }
          if (this.options.top !== null || this.options.bottom !== null) {
            let t = !1;
            if (
              !this.noUnderflow &&
              this.parent.screenWorldHeight < this.parent.screenHeight
            )
              switch (this.underflowY) {
                case -1:
                  this.parent.y !== 0 && ((this.parent.y = 0), (t = !0));
                  break;
                case 1:
                  this.parent.y !==
                    this.parent.screenHeight - this.parent.screenWorldHeight &&
                    ((this.parent.y =
                      this.parent.screenHeight - this.parent.screenWorldHeight),
                    (t = !0));
                  break;
                default:
                  this.parent.y !==
                    (this.parent.screenHeight - this.parent.screenWorldHeight) /
                      2 &&
                    ((this.parent.y =
                      (this.parent.screenHeight -
                        this.parent.screenWorldHeight) /
                      2),
                    (t = !0));
              }
            else
              this.options.top !== null &&
                this.parent.top <
                  (this.options.top === !0 ? 0 : this.options.top) &&
                ((this.parent.y =
                  -(this.options.top === !0 ? 0 : this.options.top) *
                  this.parent.scale.y),
                (n.y = 0),
                (t = !0)),
                this.options.bottom !== null &&
                  this.parent.bottom >
                    (this.options.bottom === !0
                      ? this.parent.worldHeight
                      : this.options.bottom) &&
                  ((this.parent.y =
                    -(this.options.bottom === !0
                      ? this.parent.worldHeight
                      : this.options.bottom) *
                      this.parent.scale.y +
                    this.parent.screenHeight),
                  (n.y = 0),
                  (t = !0));
            t &&
              this.parent.emit(`moved`, {
                viewport: this.parent,
                original: e,
                type: `clamp-y`,
              });
          }
          (this.last.x = this.parent.x),
            (this.last.y = this.parent.y),
            (this.last.scaleX = this.parent.scale.x),
            (this.last.scaleY = this.parent.scale.y);
        }
        reset() {
          this.update();
        }
      }),
      (x = {
        minWidth: null,
        minHeight: null,
        maxWidth: null,
        maxHeight: null,
        minScale: null,
        maxScale: null,
      }),
      (S = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            (this.options = Object.assign({}, x, t)),
            this.clamp();
        }
        resize() {
          this.clamp();
        }
        clamp() {
          if (!this.paused) {
            if (
              this.options.minWidth ||
              this.options.minHeight ||
              this.options.maxWidth ||
              this.options.maxHeight
            ) {
              let e = this.parent.worldScreenWidth,
                t = this.parent.worldScreenHeight;
              if (this.options.minWidth !== null && e < this.options.minWidth) {
                let n = this.parent.scale.x;
                this.parent.fitWidth(this.options.minWidth, !1, !1, !0),
                  (this.parent.scale.y *= this.parent.scale.x / n),
                  (e = this.parent.worldScreenWidth),
                  (t = this.parent.worldScreenHeight),
                  this.parent.emit(`zoomed`, {
                    viewport: this.parent,
                    type: `clamp-zoom`,
                  });
              }
              if (this.options.maxWidth !== null && e > this.options.maxWidth) {
                let n = this.parent.scale.x;
                this.parent.fitWidth(this.options.maxWidth, !1, !1, !0),
                  (this.parent.scale.y *= this.parent.scale.x / n),
                  (e = this.parent.worldScreenWidth),
                  (t = this.parent.worldScreenHeight),
                  this.parent.emit(`zoomed`, {
                    viewport: this.parent,
                    type: `clamp-zoom`,
                  });
              }
              if (
                this.options.minHeight !== null &&
                t < this.options.minHeight
              ) {
                let n = this.parent.scale.y;
                this.parent.fitHeight(this.options.minHeight, !1, !1, !0),
                  (this.parent.scale.x *= this.parent.scale.y / n),
                  (e = this.parent.worldScreenWidth),
                  (t = this.parent.worldScreenHeight),
                  this.parent.emit(`zoomed`, {
                    viewport: this.parent,
                    type: `clamp-zoom`,
                  });
              }
              if (
                this.options.maxHeight !== null &&
                t > this.options.maxHeight
              ) {
                let e = this.parent.scale.y;
                this.parent.fitHeight(this.options.maxHeight, !1, !1, !0),
                  (this.parent.scale.x *= this.parent.scale.y / e),
                  this.parent.emit(`zoomed`, {
                    viewport: this.parent,
                    type: `clamp-zoom`,
                  });
              }
            } else if (this.options.minScale || this.options.maxScale) {
              let e = { x: null, y: null },
                t = { x: null, y: null };
              if (typeof this.options.minScale == `number`)
                (e.x = this.options.minScale), (e.y = this.options.minScale);
              else if (this.options.minScale !== null) {
                let t = this.options.minScale;
                (e.x = typeof t.x > `u` ? null : t.x),
                  (e.y = typeof t.y > `u` ? null : t.y);
              }
              if (typeof this.options.maxScale == `number`)
                (t.x = this.options.maxScale), (t.y = this.options.maxScale);
              else if (this.options.maxScale !== null) {
                let e = this.options.maxScale;
                (t.x = typeof e.x > `u` ? null : e.x),
                  (t.y = typeof e.y > `u` ? null : e.y);
              }
              let n = this.parent.scale.x,
                r = this.parent.scale.y;
              e.x !== null && n < e.x && (n = e.x),
                t.x !== null && n > t.x && (n = t.x),
                e.y !== null && r < e.y && (r = e.y),
                t.y !== null && r > t.y && (r = t.y),
                (n !== this.parent.scale.x || r !== this.parent.scale.y) &&
                  (this.parent.scale.set(n, r),
                  this.parent.emit(`zoomed`, {
                    viewport: this.parent,
                    type: `clamp-zoom`,
                  }));
            }
          }
        }
        reset() {
          this.clamp();
        }
      }),
      (C = { friction: 0.98, bounce: 0.8, minSpeed: 0.01 }),
      (w = 16),
      (T = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `x`),
            u(this, `y`),
            u(this, `percentChangeX`),
            u(this, `percentChangeY`),
            u(this, `saved`),
            u(this, `timeSinceRelease`),
            (this.options = Object.assign({}, C, t)),
            (this.saved = []),
            (this.timeSinceRelease = 0),
            this.reset(),
            this.parent.on(`moved`, (e) => this.handleMoved(e));
        }
        down() {
          return (this.saved = []), (this.x = this.y = null), !1;
        }
        isActive() {
          return !!(this.x || this.y);
        }
        move() {
          if (this.paused) return !1;
          let e = this.parent.input.count();
          return (
            (e === 1 || (e > 1 && !this.parent.plugins.get(`pinch`, !0))) &&
              (this.saved.push({
                x: this.parent.x,
                y: this.parent.y,
                time: performance.now(),
              }),
              this.saved.length > 60 && this.saved.splice(0, 30)),
            !1
          );
        }
        handleMoved(e) {
          if (this.saved.length) {
            let t = this.saved[this.saved.length - 1];
            e.type === `clamp-x` && e.original
              ? t.x === e.original.x && (t.x = this.parent.x)
              : e.type === `clamp-y` &&
                e.original &&
                t.y === e.original.y &&
                (t.y = this.parent.y);
          }
        }
        up() {
          if (this.parent.input.count() === 0 && this.saved.length) {
            let e = performance.now();
            for (let t of this.saved)
              if (t.time >= e - 100) {
                let n = e - t.time;
                (this.x = (this.parent.x - t.x) / n),
                  (this.y = (this.parent.y - t.y) / n),
                  (this.percentChangeX = this.percentChangeY =
                    this.options.friction),
                  (this.timeSinceRelease = 0);
                break;
              }
          }
          return !1;
        }
        activate(e) {
          (e ||= {}),
            typeof e.x < `u` &&
              ((this.x = e.x), (this.percentChangeX = this.options.friction)),
            typeof e.y < `u` &&
              ((this.y = e.y), (this.percentChangeY = this.options.friction));
        }
        update(e) {
          if (this.paused) return;
          let t = this.x || this.y,
            n = this.timeSinceRelease,
            r = this.timeSinceRelease + e;
          if (this.x) {
            let t = this.percentChangeX,
              i = Math.log(t);
            (this.parent.x +=
              ((this.x * w) / i) * (t ** +(r / w) - t ** +(n / w))),
              (this.x *= this.percentChangeX ** +(e / w));
          }
          if (this.y) {
            let t = this.percentChangeY,
              i = Math.log(t);
            (this.parent.y +=
              ((this.y * w) / i) * (t ** +(r / w) - t ** +(n / w))),
              (this.y *= this.percentChangeY ** +(e / w));
          }
          (this.timeSinceRelease += e),
            this.x && this.y
              ? Math.abs(this.x) < this.options.minSpeed &&
                Math.abs(this.y) < this.options.minSpeed &&
                ((this.x = 0), (this.y = 0))
              : (Math.abs(this.x || 0) < this.options.minSpeed && (this.x = 0),
                Math.abs(this.y || 0) < this.options.minSpeed && (this.y = 0)),
            t &&
              this.parent.emit(`moved`, {
                viewport: this.parent,
                type: `decelerate`,
              });
        }
        reset() {
          this.x = this.y = null;
        }
      }),
      (E = {
        direction: `all`,
        pressDrag: !0,
        wheel: !0,
        wheelScroll: 1,
        reverse: !1,
        clampWheel: !1,
        underflow: `center`,
        factor: 1,
        mouseButtons: `all`,
        keyToPress: null,
        ignoreKeyToPressOnTouch: !1,
        lineHeight: 20,
        wheelSwapAxes: !1,
      }),
      (D = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `moved`),
            u(this, `reverse`),
            u(this, `xDirection`),
            u(this, `yDirection`),
            u(this, `keyIsPressed`),
            u(this, `mouse`),
            u(this, `underflowX`),
            u(this, `underflowY`),
            u(this, `last`),
            u(this, `current`),
            u(this, `windowEventHandlers`, []),
            (this.options = Object.assign({}, E, t)),
            (this.moved = !1),
            (this.reverse = this.options.reverse ? 1 : -1),
            (this.xDirection =
              !this.options.direction ||
              this.options.direction === `all` ||
              this.options.direction === `x`),
            (this.yDirection =
              !this.options.direction ||
              this.options.direction === `all` ||
              this.options.direction === `y`),
            (this.keyIsPressed = !1),
            this.parseUnderflow(),
            this.mouseButtons(this.options.mouseButtons),
            this.options.keyToPress &&
              this.handleKeyPresses(this.options.keyToPress);
        }
        handleKeyPresses(e) {
          this.addWindowEventHandler(`keyup`, (t) => {
            e.includes(t.code) && (this.keyIsPressed = !1);
          }),
            this.addWindowEventHandler(`keydown`, (t) => {
              e.includes(t.code) && (this.keyIsPressed = !0);
            });
        }
        addWindowEventHandler(e, t) {
          window.addEventListener(e, t),
            this.windowEventHandlers.push({ event: e, handler: t });
        }
        destroy() {
          this.windowEventHandlers.forEach(({ event: e, handler: t }) => {
            window.removeEventListener(e, t);
          });
        }
        mouseButtons(e) {
          this.mouse =
            !e || e === `all`
              ? [!0, !0, !0]
              : [
                  e.indexOf(`left`) !== -1,
                  e.indexOf(`middle`) !== -1,
                  e.indexOf(`right`) !== -1,
                ];
        }
        parseUnderflow() {
          let e = this.options.underflow.toLowerCase();
          e === `center`
            ? ((this.underflowX = 0), (this.underflowY = 0))
            : ((this.underflowX = e.includes(`left`)
                ? -1
                : +!!e.includes(`right`)),
              (this.underflowY = e.includes(`top`)
                ? -1
                : +!!e.includes(`bottom`)));
        }
        checkButtons(e) {
          let t = e.pointerType === `mouse`,
            n = this.parent.input.count();
          return !!(
            (n === 1 || (n > 1 && !this.parent.plugins.get(`pinch`, !0))) &&
            (!t || this.mouse[e.button])
          );
        }
        checkKeyPress(e) {
          return (
            !this.options.keyToPress ||
            this.keyIsPressed ||
            (this.options.ignoreKeyToPressOnTouch &&
              e.data.pointerType === `touch`)
          );
        }
        down(e) {
          return this.paused || !this.options.pressDrag
            ? !1
            : this.checkButtons(e) && this.checkKeyPress(e)
            ? ((this.last = { x: e.global.x, y: e.global.y }),
              (this.current = e.pointerId),
              !0)
            : ((this.last = null), !1);
        }
        get active() {
          return this.moved;
        }
        move(e) {
          if (this.paused || !this.options.pressDrag) return !1;
          if (this.last && this.current === e.data.pointerId) {
            let n = e.global.x,
              r = e.global.y,
              i = this.parent.input.count();
            if (i === 1 || (i > 1 && !this.parent.plugins.get(`pinch`, !0))) {
              let i = n - this.last.x,
                a = r - this.last.y;
              if (
                this.moved ||
                (this.xDirection && this.parent.input.checkThreshold(i)) ||
                (this.yDirection && this.parent.input.checkThreshold(a))
              ) {
                let i = { x: n, y: r };
                return (
                  this.xDirection &&
                    (this.parent.x +=
                      (i.x - this.last.x) * this.options.factor),
                  this.yDirection &&
                    (this.parent.y +=
                      (i.y - this.last.y) * this.options.factor),
                  (this.last = i),
                  this.moved ||
                    this.parent.emit(`drag-start`, {
                      event: e,
                      screen: new t(this.last.x, this.last.y),
                      world: this.parent.toWorld(
                        new t(this.last.x, this.last.y)
                      ),
                      viewport: this.parent,
                    }),
                  (this.moved = !0),
                  this.parent.emit(`moved`, {
                    viewport: this.parent,
                    type: `drag`,
                  }),
                  !0
                );
              }
            } else this.moved = !1;
          }
          return !1;
        }
        up(e) {
          if (this.paused) return !1;
          let n = this.parent.input.touches;
          if (n.length === 1) {
            let e = n[0];
            return (
              e.last &&
                ((this.last = { x: e.last.x, y: e.last.y }),
                (this.current = e.id)),
              (this.moved = !1),
              !0
            );
          }
          if (this.last && this.moved) {
            let n = new t(this.last.x, this.last.y);
            return (
              this.parent.emit(`drag-end`, {
                event: e,
                screen: n,
                world: this.parent.toWorld(n),
                viewport: this.parent,
              }),
              (this.last = null),
              (this.moved = !1),
              !0
            );
          }
          return !1;
        }
        wheel(e) {
          if (this.paused) return !1;
          if (this.options.wheel) {
            let t = this.parent.plugins.get(`wheel`, !0);
            if (!t || (!t.options.wheelZoom && !e.ctrlKey)) {
              let t = e.deltaMode ? this.options.lineHeight : 1,
                n = [e.deltaX, e.deltaY],
                [r, i] = this.options.wheelSwapAxes ? n.reverse() : n;
              return (
                this.xDirection &&
                  (this.parent.x +=
                    r * t * this.options.wheelScroll * this.reverse),
                this.yDirection &&
                  (this.parent.y +=
                    i * t * this.options.wheelScroll * this.reverse),
                this.options.clampWheel && this.clamp(),
                this.parent.emit(`wheel-scroll`, this.parent),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `wheel`,
                }),
                this.parent.options.passiveWheel || e.preventDefault(),
                this.parent.options.stopPropagation && e.stopPropagation(),
                !0
              );
            }
          }
          return !1;
        }
        resume() {
          (this.last = null), (this.paused = !1);
        }
        clamp() {
          let e = this.parent.plugins.get(`decelerate`, !0) || {};
          if (this.options.clampWheel !== `y`)
            if (this.parent.screenWorldWidth < this.parent.screenWidth)
              switch (this.underflowX) {
                case -1:
                  this.parent.x = 0;
                  break;
                case 1:
                  this.parent.x =
                    this.parent.screenWidth - this.parent.screenWorldWidth;
                  break;
                default:
                  this.parent.x =
                    (this.parent.screenWidth - this.parent.screenWorldWidth) /
                    2;
              }
            else
              this.parent.left < 0
                ? ((this.parent.x = 0), (e.x = 0))
                : this.parent.right > this.parent.worldWidth &&
                  ((this.parent.x =
                    -this.parent.worldWidth * this.parent.scale.x +
                    this.parent.screenWidth),
                  (e.x = 0));
          if (this.options.clampWheel !== `x`)
            if (this.parent.screenWorldHeight < this.parent.screenHeight)
              switch (this.underflowY) {
                case -1:
                  this.parent.y = 0;
                  break;
                case 1:
                  this.parent.y =
                    this.parent.screenHeight - this.parent.screenWorldHeight;
                  break;
                default:
                  this.parent.y =
                    (this.parent.screenHeight - this.parent.screenWorldHeight) /
                    2;
              }
            else
              this.parent.top < 0 && ((this.parent.y = 0), (e.y = 0)),
                this.parent.bottom > this.parent.worldHeight &&
                  ((this.parent.y =
                    -this.parent.worldHeight * this.parent.scale.y +
                    this.parent.screenHeight),
                  (e.y = 0));
        }
      }),
      (O = { speed: 0, acceleration: null, radius: null }),
      (k = class extends d {
        constructor(e, t, n = {}) {
          super(e),
            u(this, `options`),
            u(this, `target`),
            u(this, `velocity`),
            (this.target = t),
            (this.options = Object.assign({}, O, n)),
            (this.velocity = { x: 0, y: 0 });
        }
        update(e) {
          if (this.paused) return;
          let t = this.parent.center,
            n = this.target.x,
            r = this.target.y;
          if (this.options.radius)
            if (
              Math.sqrt(
                (this.target.y - t.y) ** 2 + (this.target.x - t.x) ** 2
              ) > this.options.radius
            ) {
              let e = Math.atan2(this.target.y - t.y, this.target.x - t.x);
              (n = this.target.x - Math.cos(e) * this.options.radius),
                (r = this.target.y - Math.sin(e) * this.options.radius);
            } else return;
          let i = n - t.x,
            a = r - t.y;
          if (i || a)
            if (this.options.speed)
              if (this.options.acceleration) {
                let o = Math.atan2(r - t.y, n - t.x),
                  s = Math.sqrt(i ** 2 + a ** 2);
                if (s) {
                  this.velocity =
                    s >
                    (this.velocity.x ** 2 + this.velocity.y ** 2) /
                      (2 * this.options.acceleration)
                      ? {
                          x: Math.min(
                            this.velocity.x +
                              (this.options.acceleration * e,
                              this.options.speed)
                          ),
                          y: Math.min(
                            this.velocity.y +
                              (this.options.acceleration * e,
                              this.options.speed)
                          ),
                        }
                      : {
                          x: Math.max(
                            this.velocity.x -
                              this.options.acceleration * this.options.speed,
                            0
                          ),
                          y: Math.max(
                            this.velocity.y -
                              this.options.acceleration * this.options.speed,
                            0
                          ),
                        };
                  let c = Math.cos(o) * this.velocity.x,
                    l = Math.sin(o) * this.velocity.y,
                    u = Math.abs(c) > Math.abs(i) ? n : t.x + c,
                    d = Math.abs(l) > Math.abs(a) ? r : t.y + l;
                  this.parent.moveCenter(u, d),
                    this.parent.emit(`moved`, {
                      viewport: this.parent,
                      type: `follow`,
                    });
                }
              } else {
                let e = Math.atan2(r - t.y, n - t.x),
                  o = Math.cos(e) * this.options.speed,
                  s = Math.sin(e) * this.options.speed,
                  c = Math.abs(o) > Math.abs(i) ? n : t.x + o,
                  l = Math.abs(s) > Math.abs(a) ? r : t.y + s;
                this.parent.moveCenter(c, l),
                  this.parent.emit(`moved`, {
                    viewport: this.parent,
                    type: `follow`,
                  });
              }
            else
              this.parent.moveCenter(n, r),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `follow`,
                });
        }
      }),
      (A = {
        radius: null,
        distance: null,
        top: null,
        bottom: null,
        left: null,
        right: null,
        speed: 8,
        reverse: !1,
        noDecelerate: !1,
        linear: !1,
        allowButtons: !1,
      }),
      (j = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `reverse`),
            u(this, `radiusSquared`),
            u(this, `left`),
            u(this, `top`),
            u(this, `right`),
            u(this, `bottom`),
            u(this, `horizontal`),
            u(this, `vertical`),
            (this.options = Object.assign({}, A, t)),
            (this.reverse = this.options.reverse ? 1 : -1),
            (this.radiusSquared =
              typeof this.options.radius == `number`
                ? this.options.radius ** 2
                : null),
            this.resize();
        }
        resize() {
          let e = this.options.distance;
          e === null
            ? this.options.radius ||
              ((this.left = this.options.left),
              (this.top = this.options.top),
              (this.right =
                this.options.right === null
                  ? null
                  : this.parent.screenWidth - this.options.right),
              (this.bottom =
                this.options.bottom === null
                  ? null
                  : this.parent.screenHeight - this.options.bottom))
            : ((this.left = e),
              (this.top = e),
              (this.right = this.parent.screenWidth - e),
              (this.bottom = this.parent.screenHeight - e));
        }
        down() {
          return (
            this.paused ||
              this.options.allowButtons ||
              (this.horizontal = this.vertical = null),
            !1
          );
        }
        move(e) {
          if (
            this.paused ||
            (e.pointerType !== `mouse` && e.pointerId !== 1) ||
            (!this.options.allowButtons && e.buttons !== 0)
          )
            return !1;
          let t = e.global.x,
            n = e.global.y;
          if (this.radiusSquared) {
            let e = this.parent.toScreen(this.parent.center);
            if ((e.x - t) ** 2 + (e.y - n) ** 2 >= this.radiusSquared) {
              let r = Math.atan2(e.y - n, e.x - t);
              this.options.linear
                ? ((this.horizontal =
                    Math.round(Math.cos(r)) *
                    this.options.speed *
                    this.reverse *
                    (60 / 1e3)),
                  (this.vertical =
                    Math.round(Math.sin(r)) *
                    this.options.speed *
                    this.reverse *
                    (60 / 1e3)))
                : ((this.horizontal =
                    Math.cos(r) *
                    this.options.speed *
                    this.reverse *
                    (60 / 1e3)),
                  (this.vertical =
                    Math.sin(r) *
                    this.options.speed *
                    this.reverse *
                    (60 / 1e3)));
            } else
              this.horizontal && this.decelerateHorizontal(),
                this.vertical && this.decelerateVertical(),
                (this.horizontal = this.vertical = 0);
          } else
            this.left !== null && t < this.left
              ? (this.horizontal =
                  Number(this.reverse) * this.options.speed * (60 / 1e3))
              : this.right !== null && t > this.right
              ? (this.horizontal =
                  -1 * this.reverse * this.options.speed * (60 / 1e3))
              : (this.decelerateHorizontal(), (this.horizontal = 0)),
              this.top !== null && n < this.top
                ? (this.vertical =
                    Number(this.reverse) * this.options.speed * (60 / 1e3))
                : this.bottom !== null && n > this.bottom
                ? (this.vertical =
                    -1 * this.reverse * this.options.speed * (60 / 1e3))
                : (this.decelerateVertical(), (this.vertical = 0));
          return !1;
        }
        decelerateHorizontal() {
          let e = this.parent.plugins.get(`decelerate`, !0);
          this.horizontal &&
            e &&
            !this.options.noDecelerate &&
            e.activate({
              x:
                (this.horizontal * this.options.speed * this.reverse) /
                (1e3 / 60),
            });
        }
        decelerateVertical() {
          let e = this.parent.plugins.get(`decelerate`, !0);
          this.vertical &&
            e &&
            !this.options.noDecelerate &&
            e.activate({
              y:
                (this.vertical * this.options.speed * this.reverse) /
                (1e3 / 60),
            });
        }
        up() {
          return (
            this.paused ||
              (this.horizontal && this.decelerateHorizontal(),
              this.vertical && this.decelerateVertical(),
              (this.horizontal = this.vertical = null)),
            !1
          );
        }
        update() {
          if (!this.paused && (this.horizontal || this.vertical)) {
            let e = this.parent.center;
            this.horizontal && (e.x += this.horizontal * this.options.speed),
              this.vertical && (e.y += this.vertical * this.options.speed),
              this.parent.moveCenter(e),
              this.parent.emit(`moved`, {
                viewport: this.parent,
                type: `mouse-edges`,
              });
          }
        }
      }),
      (M = { noDrag: !1, percent: 1, center: null, factor: 1, axis: `all` }),
      (N = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `active`, !1),
            u(this, `pinching`, !1),
            u(this, `moved`, !1),
            u(this, `lastCenter`),
            (this.options = Object.assign({}, M, t));
        }
        down() {
          return this.parent.input.count() >= 2 && ((this.active = !0), !0);
        }
        isAxisX() {
          return [`all`, `x`].includes(this.options.axis);
        }
        isAxisY() {
          return [`all`, `y`].includes(this.options.axis);
        }
        move(e) {
          if (this.paused || !this.active) return !1;
          let n = e.global.x,
            r = e.global.y,
            i = this.parent.input.touches;
          if (i.length >= 2) {
            let a = i[0],
              o = i[1],
              s =
                a.last && o.last
                  ? Math.sqrt(
                      (o.last.x - a.last.x) ** 2 + (o.last.y - a.last.y) ** 2
                    )
                  : null;
            if (
              (a.id === e.pointerId
                ? (a.last = { x: n, y: r, data: e })
                : o.id === e.pointerId && (o.last = { x: n, y: r, data: e }),
              s)
            ) {
              let e,
                n = new t(
                  a.last.x + (o.last.x - a.last.x) / 2,
                  a.last.y + (o.last.y - a.last.y) / 2
                );
              this.options.center || (e = this.parent.toLocal(n));
              let r = Math.sqrt(
                (o.last.x - a.last.x) ** 2 + (o.last.y - a.last.y) ** 2
              );
              r = r === 0 ? (r = 1e-10) : r;
              let i =
                (1 - s / r) *
                this.options.percent *
                (this.isAxisX() ? this.parent.scale.x : this.parent.scale.y);
              this.isAxisX() && (this.parent.scale.x += i),
                this.isAxisY() && (this.parent.scale.y += i),
                this.parent.emit(`zoomed`, {
                  viewport: this.parent,
                  type: `pinch`,
                  center: n,
                });
              let c = this.parent.plugins.get(`clamp-zoom`, !0);
              if ((c && c.clamp(), this.options.center))
                this.parent.moveCenter(this.options.center);
              else {
                let t = this.parent.toGlobal(e);
                (this.parent.x += (n.x - t.x) * this.options.factor),
                  (this.parent.y += (n.y - t.y) * this.options.factor),
                  this.parent.emit(`moved`, {
                    viewport: this.parent,
                    type: `pinch`,
                  });
              }
              !this.options.noDrag &&
                this.lastCenter &&
                ((this.parent.x +=
                  (n.x - this.lastCenter.x) * this.options.factor),
                (this.parent.y +=
                  (n.y - this.lastCenter.y) * this.options.factor),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `pinch`,
                })),
                (this.lastCenter = n),
                (this.moved = !0);
            } else
              this.pinching ||=
                (this.parent.emit(`pinch-start`, this.parent), !0);
            return !0;
          }
          return !1;
        }
        up() {
          return this.pinching && this.parent.input.touches.length <= 1
            ? ((this.active = !1),
              (this.lastCenter = null),
              (this.pinching = !1),
              (this.moved = !1),
              this.parent.emit(`pinch-end`, this.parent),
              !0)
            : !1;
        }
      }),
      (P = {
        topLeft: !1,
        friction: 0.8,
        time: 1e3,
        ease: `easeInOutSine`,
        interrupt: !0,
        removeOnComplete: !1,
        removeOnInterrupt: !1,
        forceStart: !1,
      }),
      (F = class extends d {
        constructor(e, t, n, r = {}) {
          super(e),
            u(this, `options`),
            u(this, `ease`),
            u(this, `x`),
            u(this, `y`),
            u(this, `percent`),
            u(this, `snapping`),
            u(this, `deltaX`),
            u(this, `deltaY`),
            u(this, `startX`),
            u(this, `startY`),
            (this.options = Object.assign({}, P, r)),
            (this.ease = s(r.ease, `easeInOutSine`)),
            (this.x = t),
            (this.y = n),
            this.options.forceStart && this.snapStart();
        }
        snapStart() {
          (this.percent = 0), (this.snapping = { time: 0 });
          let e = this.options.topLeft
            ? this.parent.corner
            : this.parent.center;
          (this.deltaX = this.x - e.x),
            (this.deltaY = this.y - e.y),
            (this.startX = e.x),
            (this.startY = e.y),
            this.parent.emit(`snap-start`, this.parent);
        }
        wheel() {
          return (
            this.options.removeOnInterrupt &&
              this.parent.plugins.remove(`snap`),
            !1
          );
        }
        down() {
          return (
            this.options.removeOnInterrupt
              ? this.parent.plugins.remove(`snap`)
              : this.options.interrupt && (this.snapping = null),
            !1
          );
        }
        up() {
          if (this.parent.input.count() === 0) {
            let e = this.parent.plugins.get(`decelerate`, !0);
            e &&
              (e.x || e.y) &&
              (e.percentChangeX = e.percentChangeY = this.options.friction);
          }
          return !1;
        }
        update(e) {
          if (
            !this.paused &&
            !(this.options.interrupt && this.parent.input.count() !== 0)
          )
            if (this.snapping) {
              let t = this.snapping;
              t.time += e;
              let n,
                r,
                i,
                a = this.startX,
                o = this.startY,
                s = this.deltaX,
                c = this.deltaY;
              if (t.time > this.options.time)
                (n = !0), (r = a + s), (i = o + c);
              else {
                let e = this.ease(t.time, 0, 1, this.options.time);
                (r = a + s * e), (i = o + c * e);
              }
              this.options.topLeft
                ? this.parent.moveCorner(r, i)
                : this.parent.moveCenter(r, i),
                this.parent.emit(`moved`, {
                  viewport: this.parent,
                  type: `snap`,
                }),
                n &&
                  (this.options.removeOnComplete &&
                    this.parent.plugins.remove(`snap`),
                  this.parent.emit(`snap-end`, this.parent),
                  (this.snapping = null));
            } else {
              let e = this.options.topLeft
                ? this.parent.corner
                : this.parent.center;
              (e.x !== this.x || e.y !== this.y) && this.snapStart();
            }
        }
      }),
      (I = {
        width: 0,
        height: 0,
        time: 1e3,
        ease: `easeInOutSine`,
        center: null,
        interrupt: !0,
        removeOnComplete: !1,
        removeOnInterrupt: !1,
        forceStart: !1,
        noMove: !1,
      }),
      (L = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `ease`),
            u(this, `xScale`),
            u(this, `yScale`),
            u(this, `xIndependent`),
            u(this, `yIndependent`),
            u(this, `snapping`),
            (this.options = Object.assign({}, I, t)),
            (this.ease = s(this.options.ease)),
            (this.xIndependent = !1),
            (this.yIndependent = !1),
            (this.xScale = 0),
            (this.yScale = 0),
            this.options.width > 0 &&
              ((this.xScale = e.screenWidth / this.options.width),
              (this.xIndependent = !0)),
            this.options.height > 0 &&
              ((this.yScale = e.screenHeight / this.options.height),
              (this.yIndependent = !0)),
            (this.xScale = this.xIndependent ? this.xScale : this.yScale),
            (this.yScale = this.yIndependent ? this.yScale : this.xScale),
            this.options.time === 0
              ? ((e.container.scale.x = this.xScale),
                (e.container.scale.y = this.yScale),
                this.options.removeOnComplete &&
                  this.parent.plugins.remove(`snap-zoom`))
              : t.forceStart && this.createSnapping();
        }
        createSnapping() {
          let e = this.parent.worldScreenWidth,
            t = this.parent.worldScreenHeight,
            n = this.parent.screenWidth / this.xScale,
            r = this.parent.screenHeight / this.yScale;
          (this.snapping = {
            time: 0,
            startX: e,
            startY: t,
            deltaX: n - e,
            deltaY: r - t,
          }),
            this.parent.emit(`snap-zoom-start`, this.parent);
        }
        resize() {
          (this.snapping = null),
            this.options.width > 0 &&
              (this.xScale = this.parent.screenWidth / this.options.width),
            this.options.height > 0 &&
              (this.yScale = this.parent.screenHeight / this.options.height),
            (this.xScale = this.xIndependent ? this.xScale : this.yScale),
            (this.yScale = this.yIndependent ? this.yScale : this.xScale);
        }
        wheel() {
          return (
            this.options.removeOnInterrupt &&
              this.parent.plugins.remove(`snap-zoom`),
            !1
          );
        }
        down() {
          return (
            this.options.removeOnInterrupt
              ? this.parent.plugins.remove(`snap-zoom`)
              : this.options.interrupt && (this.snapping = null),
            !1
          );
        }
        update(e) {
          if (
            this.paused ||
            (this.options.interrupt && this.parent.input.count() !== 0)
          )
            return;
          let t;
          if (
            (!this.options.center &&
              !this.options.noMove &&
              (t = this.parent.center),
            !this.snapping)
          )
            (this.parent.scale.x !== this.xScale ||
              this.parent.scale.y !== this.yScale) &&
              this.createSnapping();
          else if (this.snapping) {
            let n = this.snapping;
            if (((n.time += e), n.time >= this.options.time))
              this.parent.scale.set(this.xScale, this.yScale),
                this.options.removeOnComplete &&
                  this.parent.plugins.remove(`snap-zoom`),
                this.parent.emit(`snap-zoom-end`, this.parent),
                (this.snapping = null);
            else {
              let e = this.snapping,
                t = this.ease(e.time, e.startX, e.deltaX, this.options.time),
                n = this.ease(e.time, e.startY, e.deltaY, this.options.time);
              (this.parent.scale.x = this.parent.screenWidth / t),
                (this.parent.scale.y = this.parent.screenHeight / n);
            }
            let r = this.parent.plugins.get(`clamp-zoom`, !0);
            r && r.clamp(),
              this.options.noMove ||
                (this.options.center
                  ? this.parent.moveCenter(this.options.center)
                  : this.parent.moveCenter(t));
          }
        }
        resume() {
          (this.snapping = null), super.resume();
        }
      }),
      (R = {
        percent: 0.1,
        smooth: !1,
        interrupt: !0,
        reverse: !1,
        center: null,
        lineHeight: 20,
        axis: `all`,
        keyToPress: null,
        trackpadPinch: !1,
        wheelZoom: !0,
      }),
      (z = class extends d {
        constructor(e, t = {}) {
          super(e),
            u(this, `options`),
            u(this, `smoothing`),
            u(this, `smoothingCenter`),
            u(this, `smoothingCount`),
            u(this, `keyIsPressed`),
            (this.options = Object.assign({}, R, t)),
            (this.keyIsPressed = !1),
            this.options.keyToPress &&
              this.handleKeyPresses(this.options.keyToPress);
        }
        handleKeyPresses(e) {
          window.addEventListener(`keydown`, (t) => {
            e.includes(t.code) && (this.keyIsPressed = !0);
          }),
            window.addEventListener(`keyup`, (t) => {
              e.includes(t.code) && (this.keyIsPressed = !1);
            });
        }
        checkKeyPress() {
          return !this.options.keyToPress || this.keyIsPressed;
        }
        down() {
          return this.options.interrupt && (this.smoothing = null), !1;
        }
        isAxisX() {
          return [`all`, `x`].includes(this.options.axis);
        }
        isAxisY() {
          return [`all`, `y`].includes(this.options.axis);
        }
        update() {
          if (this.smoothing) {
            let e = this.smoothingCenter,
              t = this.smoothing,
              n;
            this.options.center || (n = this.parent.toLocal(e)),
              this.isAxisX() && (this.parent.scale.x += t.x),
              this.isAxisY() && (this.parent.scale.y += t.y),
              this.parent.emit(`zoomed`, {
                viewport: this.parent,
                type: `wheel`,
              });
            let r = this.parent.plugins.get(`clamp-zoom`, !0);
            if ((r && r.clamp(), this.options.center))
              this.parent.moveCenter(this.options.center);
            else {
              let t = this.parent.toGlobal(n);
              (this.parent.x += e.x - t.x), (this.parent.y += e.y - t.y);
            }
            this.parent.emit(`moved`, { viewport: this.parent, type: `wheel` }),
              this.smoothingCount++,
              this.smoothingCount >= this.options.smooth &&
                (this.smoothing = null);
          }
        }
        pinch(e) {
          if (this.paused) return;
          let t = this.parent.input.getPointerPosition(e),
            n = (-e.deltaY * (e.deltaMode ? this.options.lineHeight : 1)) / 200,
            r = 2 ** ((1 + this.options.percent) * n),
            i;
          this.options.center || (i = this.parent.toLocal(t)),
            this.isAxisX() && (this.parent.scale.x *= r),
            this.isAxisY() && (this.parent.scale.y *= r),
            this.parent.emit(`zoomed`, {
              viewport: this.parent,
              type: `wheel`,
            });
          let a = this.parent.plugins.get(`clamp-zoom`, !0);
          if ((a && a.clamp(), this.options.center))
            this.parent.moveCenter(this.options.center);
          else {
            let e = this.parent.toGlobal(i);
            (this.parent.x += t.x - e.x), (this.parent.y += t.y - e.y);
          }
          this.parent.emit(`moved`, { viewport: this.parent, type: `wheel` }),
            this.parent.emit(`wheel-start`, {
              event: e,
              viewport: this.parent,
            });
        }
        wheel(e) {
          if (this.paused || !this.checkKeyPress()) return !1;
          if (e.ctrlKey && this.options.trackpadPinch) this.pinch(e);
          else if (this.options.wheelZoom) {
            let t = this.parent.input.getPointerPosition(e),
              n =
                ((this.options.reverse ? -1 : 1) *
                  -e.deltaY *
                  (e.deltaMode ? this.options.lineHeight : 1)) /
                500,
              r = 2 ** ((1 + this.options.percent) * n);
            if (this.options.smooth) {
              let e = {
                x: this.smoothing
                  ? this.smoothing.x *
                    (this.options.smooth - this.smoothingCount)
                  : 0,
                y: this.smoothing
                  ? this.smoothing.y *
                    (this.options.smooth - this.smoothingCount)
                  : 0,
              };
              (this.smoothing = {
                x:
                  ((this.parent.scale.x + e.x) * r - this.parent.scale.x) /
                  this.options.smooth,
                y:
                  ((this.parent.scale.y + e.y) * r - this.parent.scale.y) /
                  this.options.smooth,
              }),
                (this.smoothingCount = 0),
                (this.smoothingCenter = t);
            } else {
              let e;
              this.options.center || (e = this.parent.toLocal(t)),
                this.isAxisX() && (this.parent.scale.x *= r),
                this.isAxisY() && (this.parent.scale.y *= r),
                this.parent.emit(`zoomed`, {
                  viewport: this.parent,
                  type: `wheel`,
                });
              let n = this.parent.plugins.get(`clamp-zoom`, !0);
              if ((n && n.clamp(), this.options.center))
                this.parent.moveCenter(this.options.center);
              else {
                let n = this.parent.toGlobal(e);
                (this.parent.x += t.x - n.x), (this.parent.y += t.y - n.y);
              }
            }
            this.parent.emit(`moved`, { viewport: this.parent, type: `wheel` }),
              this.parent.emit(`wheel-start`, {
                event: e,
                viewport: this.parent,
              });
          }
          return !this.parent.options.passiveWheel;
        }
      }),
      (B = class {
        constructor(e) {
          u(this, `viewport`),
            u(this, `clickedAvailable`),
            u(this, `isMouseDown`),
            u(this, `last`),
            u(this, `wheelFunction`),
            u(this, `touches`),
            (this.viewport = e),
            (this.touches = []),
            this.addListeners();
        }
        addListeners() {
          (this.viewport.interactive = !0),
            this.viewport.forceHitArea ||
              (this.viewport.hitArea = new r(
                0,
                0,
                this.viewport.worldWidth,
                this.viewport.worldHeight
              )),
            this.viewport.on(`pointerdown`, this.down, this),
            this.viewport.options.allowPreserveDragOutside
              ? this.viewport.on(`globalpointermove`, this.move, this)
              : this.viewport.on(`pointermove`, this.move, this),
            this.viewport.on(`pointerup`, this.up, this),
            this.viewport.on(`pointerupoutside`, this.up, this),
            this.viewport.on(`pointercancel`, this.up, this),
            this.viewport.options.allowPreserveDragOutside ||
              this.viewport.on(`pointerleave`, this.up, this),
            (this.wheelFunction = (e) => this.handleWheel(e)),
            this.viewport.options.events.domElement.addEventListener(
              `wheel`,
              this.wheelFunction,
              { passive: this.viewport.options.passiveWheel }
            ),
            (this.isMouseDown = !1);
        }
        destroy() {
          this.viewport.options.events.domElement.removeEventListener(
            `wheel`,
            this.wheelFunction
          );
        }
        down(e) {
          if (!(this.viewport.pause || !this.viewport.worldVisible)) {
            if (
              (e.pointerType === `mouse`
                ? (this.isMouseDown = !0)
                : this.get(e.pointerId) ||
                  this.touches.push({ id: e.pointerId, last: null }),
              this.count() === 1)
            ) {
              this.last = e.global.clone();
              let t = this.viewport.plugins.get(`decelerate`, !0),
                n = this.viewport.plugins.get(`bounce`, !0);
              this.clickedAvailable =
                (!t || !t.isActive()) && (!n || !n.isActive());
            } else this.clickedAvailable = !1;
            this.viewport.plugins.down(e) &&
              this.viewport.options.stopPropagation &&
              e.stopPropagation();
          }
        }
        clear() {
          (this.isMouseDown = !1), (this.touches = []), (this.last = null);
        }
        checkThreshold(e) {
          return Math.abs(e) >= this.viewport.threshold;
        }
        move(e) {
          if (this.viewport.pause || !this.viewport.worldVisible) return;
          let t = this.viewport.plugins.move(e);
          if (this.clickedAvailable && this.last) {
            let t = e.global.x - this.last.x,
              n = e.global.y - this.last.y;
            (this.checkThreshold(t) || this.checkThreshold(n)) &&
              (this.clickedAvailable = !1);
          }
          t && this.viewport.options.stopPropagation && e.stopPropagation();
        }
        up(e) {
          if (this.viewport.pause || !this.viewport.worldVisible) return;
          e.pointerType === `mouse` && (this.isMouseDown = !1),
            e.pointerType !== `mouse` && this.remove(e.pointerId);
          let t = this.viewport.plugins.up(e);
          this.clickedAvailable &&
            this.count() === 0 &&
            this.last &&
            (this.viewport.emit(`clicked`, {
              event: e,
              screen: this.last,
              world: this.viewport.toWorld(this.last),
              viewport: this.viewport,
            }),
            (this.clickedAvailable = !1)),
            t && this.viewport.options.stopPropagation && e.stopPropagation();
        }
        getPointerPosition(e) {
          let n = new t();
          return (
            this.viewport.options.events.mapPositionToPoint(
              n,
              e.clientX,
              e.clientY
            ),
            n
          );
        }
        handleWheel(e) {
          if (this.viewport.pause || !this.viewport.worldVisible) return;
          let t = this.viewport.toLocal(this.getPointerPosition(e));
          this.viewport.left <= t.x &&
            t.x <= this.viewport.right &&
            this.viewport.top <= t.y &&
            t.y <= this.viewport.bottom &&
            this.viewport.plugins.wheel(e) &&
            !this.viewport.options.passiveWheel &&
            e.preventDefault();
        }
        pause() {
          (this.touches = []), (this.isMouseDown = !1);
        }
        get(e) {
          for (let t of this.touches) if (t.id === e) return t;
          return null;
        }
        remove(e) {
          for (let t = 0; t < this.touches.length; t++)
            if (this.touches[t].id === e) {
              this.touches.splice(t, 1);
              return;
            }
        }
        count() {
          return +!!this.isMouseDown + this.touches.length;
        }
      }),
      (V = [
        `drag`,
        `pinch`,
        `wheel`,
        `follow`,
        `mouse-edges`,
        `decelerate`,
        `animate`,
        `bounce`,
        `snap-zoom`,
        `clamp-zoom`,
        `snap`,
        `clamp`,
      ]),
      (H = class {
        constructor(e) {
          u(this, `plugins`),
            u(this, `list`),
            u(this, `viewport`),
            (this.viewport = e),
            (this.list = []),
            (this.plugins = {});
        }
        add(e, t, n = V.length) {
          let r = this.plugins[e];
          r && r.destroy(), (this.plugins[e] = t);
          let i = V.indexOf(e);
          i !== -1 && V.splice(i, 1), V.splice(n, 0, e), this.sort();
        }
        get(e, t) {
          var n;
          return t && (n = this.plugins[e]) != null && n.paused
            ? null
            : this.plugins[e];
        }
        update(e) {
          for (let t of this.list) t.update(e);
        }
        resize() {
          for (let e of this.list) e.resize();
        }
        reset() {
          for (let e of this.list) e.reset();
        }
        removeAll() {
          this.list.forEach((e) => {
            e.destroy();
          }),
            (this.plugins = {}),
            this.sort();
        }
        remove(e) {
          var t;
          this.plugins[e] &&
            ((t = this.plugins[e]) == null || t.destroy(),
            delete this.plugins[e],
            this.viewport.emit(`plugin-remove`, e),
            this.sort());
        }
        pause(e) {
          var t;
          (t = this.plugins[e]) == null || t.pause();
        }
        resume(e) {
          var t;
          (t = this.plugins[e]) == null || t.resume();
        }
        sort() {
          this.list = [];
          for (let e of V) this.plugins[e] && this.list.push(this.plugins[e]);
        }
        down(e) {
          let t = !1;
          for (let n of this.list) n.down(e) && (t = !0);
          return t;
        }
        move(e) {
          let t = !1;
          for (let n of this.viewport.plugins.list) n.move(e) && (t = !0);
          return t;
        }
        up(e) {
          let t = !1;
          for (let n of this.list) n.up(e) && (t = !0);
          return t;
        }
        wheel(e) {
          let t = !1;
          for (let n of this.list) n.wheel(e) && (t = !0);
          return t;
        }
      }),
      (U = {
        screenWidth: window.innerWidth,
        screenHeight: window.innerHeight,
        worldWidth: null,
        worldHeight: null,
        threshold: 5,
        passiveWheel: !0,
        stopPropagation: !1,
        forceHitArea: null,
        noTicker: !1,
        disableOnContextMenu: !1,
        ticker: o.shared,
        allowPreserveDragOutside: !1,
      }),
      (W = class extends i {
        constructor(e) {
          super(),
            u(this, `moving`),
            u(this, `screenWidth`),
            u(this, `screenHeight`),
            u(this, `threshold`),
            u(this, `input`),
            u(this, `plugins`),
            u(this, `zooming`),
            u(this, `lastViewport`),
            u(this, `options`),
            u(this, `_dirty`),
            u(this, `_forceHitArea`),
            u(this, `_hitAreaDefault`),
            u(this, `_pause`),
            u(this, `tickerFunction`),
            u(this, `_worldWidth`),
            u(this, `_worldHeight`),
            u(this, `_disableOnContextMenu`, (e) => e.preventDefault()),
            (this.options = { ...U, ...e }),
            (this.screenWidth = this.options.screenWidth),
            (this.screenHeight = this.options.screenHeight),
            (this._worldWidth = this.options.worldWidth),
            (this._worldHeight = this.options.worldHeight),
            (this.forceHitArea = this.options.forceHitArea),
            (this.threshold = this.options.threshold),
            this.options.disableOnContextMenu &&
              this.options.events.domElement.addEventListener(
                `contextmenu`,
                this._disableOnContextMenu
              ),
            this.options.noTicker ||
              ((this.tickerFunction = () =>
                this.update(this.options.ticker.elapsedMS)),
              this.options.ticker.add(this.tickerFunction)),
            (this.input = new B(this)),
            (this.plugins = new H(this));
        }
        destroy(e) {
          !this.options.noTicker &&
            this.tickerFunction &&
            this.options.ticker.remove(this.tickerFunction),
            this.options.disableOnContextMenu &&
              this.options.events.domElement.removeEventListener(
                `contextmenu`,
                this._disableOnContextMenu
              ),
            this.input.destroy(),
            super.destroy(e);
        }
        update(e) {
          this.pause ||
            (this.plugins.update(e),
            this.lastViewport &&
              (this.lastViewport.x !== this.x || this.lastViewport.y !== this.y
                ? (this.moving = !0)
                : (this.moving &&= (this.emit(`moved-end`, this), !1)),
              this.lastViewport.scaleX !== this.scale.x ||
              this.lastViewport.scaleY !== this.scale.y
                ? (this.zooming = !0)
                : (this.zooming &&= (this.emit(`zoomed-end`, this), !1))),
            this.forceHitArea ||
              ((this._hitAreaDefault = new r(
                this.left,
                this.top,
                this.worldScreenWidth,
                this.worldScreenHeight
              )),
              (this.hitArea = this._hitAreaDefault)),
            (this._dirty =
              this._dirty ||
              !this.lastViewport ||
              this.lastViewport.x !== this.x ||
              this.lastViewport.y !== this.y ||
              this.lastViewport.scaleX !== this.scale.x ||
              this.lastViewport.scaleY !== this.scale.y),
            (this.lastViewport = {
              x: this.x,
              y: this.y,
              scaleX: this.scale.x,
              scaleY: this.scale.y,
            }),
            this.emit(`frame-end`, this));
        }
        resize(e = window.innerWidth, t = window.innerHeight, n, r) {
          (this.screenWidth = e),
            (this.screenHeight = t),
            typeof n < `u` && (this._worldWidth = n),
            typeof r < `u` && (this._worldHeight = r),
            this.plugins.resize(),
            (this.dirty = !0);
        }
        get worldWidth() {
          return this._worldWidth
            ? this._worldWidth
            : this.width / this.scale.x;
        }
        set worldWidth(e) {
          (this._worldWidth = e), this.plugins.resize();
        }
        get worldHeight() {
          return this._worldHeight
            ? this._worldHeight
            : this.height / this.scale.y;
        }
        set worldHeight(e) {
          (this._worldHeight = e), this.plugins.resize();
        }
        getVisibleBounds() {
          return new r(
            this.left,
            this.top,
            this.worldScreenWidth,
            this.worldScreenHeight
          );
        }
        toWorld(e, n) {
          return arguments.length === 2
            ? this.toLocal(new t(e, n))
            : this.toLocal(e);
        }
        toScreen(e, n) {
          return arguments.length === 2
            ? this.toGlobal(new t(e, n))
            : this.toGlobal(e);
        }
        get worldScreenWidth() {
          return this.screenWidth / this.scale.x;
        }
        get worldScreenHeight() {
          return this.screenHeight / this.scale.y;
        }
        get screenWorldWidth() {
          return this.worldWidth * this.scale.x;
        }
        get screenWorldHeight() {
          return this.worldHeight * this.scale.y;
        }
        get center() {
          return new t(
            this.worldScreenWidth / 2 - this.x / this.scale.x,
            this.worldScreenHeight / 2 - this.y / this.scale.y
          );
        }
        set center(e) {
          this.moveCenter(e);
        }
        moveCenter(...e) {
          let t, n;
          typeof e[0] == `number`
            ? ((t = e[0]), (n = e[1]))
            : ((t = e[0].x), (n = e[0].y));
          let r = (this.worldScreenWidth / 2 - t) * this.scale.x,
            i = (this.worldScreenHeight / 2 - n) * this.scale.y;
          return (
            (this.x !== r || this.y !== i) &&
              (this.position.set(r, i),
              this.plugins.reset(),
              (this.dirty = !0)),
            this
          );
        }
        get corner() {
          return new t(-this.x / this.scale.x, -this.y / this.scale.y);
        }
        set corner(e) {
          this.moveCorner(e);
        }
        moveCorner(...e) {
          let t, n;
          return (
            e.length === 1
              ? ((t = -e[0].x * this.scale.x), (n = -e[0].y * this.scale.y))
              : ((t = -e[0] * this.scale.x), (n = -e[1] * this.scale.y)),
            (t !== this.x || n !== this.y) &&
              (this.position.set(t, n),
              this.plugins.reset(),
              (this.dirty = !0)),
            this
          );
        }
        get screenWidthInWorldPixels() {
          return this.screenWidth / this.scale.x;
        }
        get screenHeightInWorldPixels() {
          return this.screenHeight / this.scale.y;
        }
        findFitWidth(e) {
          return this.screenWidth / e;
        }
        findFitHeight(e) {
          return this.screenHeight / e;
        }
        findFit(e, t) {
          let n = this.screenWidth / e,
            r = this.screenHeight / t;
          return Math.min(n, r);
        }
        findCover(e, t) {
          let n = this.screenWidth / e,
            r = this.screenHeight / t;
          return Math.max(n, r);
        }
        fitWidth(e = this.worldWidth, t, n = !0, r) {
          let i;
          t && (i = this.center),
            (this.scale.x = this.screenWidth / e),
            n && (this.scale.y = this.scale.x);
          let a = this.plugins.get(`clamp-zoom`, !0);
          return !r && a && a.clamp(), t && i && this.moveCenter(i), this;
        }
        fitHeight(e = this.worldHeight, t, n = !0, r) {
          let i;
          t && (i = this.center),
            (this.scale.y = this.screenHeight / e),
            n && (this.scale.x = this.scale.y);
          let a = this.plugins.get(`clamp-zoom`, !0);
          return !r && a && a.clamp(), t && i && this.moveCenter(i), this;
        }
        fitWorld(e) {
          let t;
          e && (t = this.center),
            (this.scale.x = this.screenWidth / this.worldWidth),
            (this.scale.y = this.screenHeight / this.worldHeight),
            this.scale.x < this.scale.y
              ? (this.scale.y = this.scale.x)
              : (this.scale.x = this.scale.y);
          let n = this.plugins.get(`clamp-zoom`, !0);
          return n && n.clamp(), e && t && this.moveCenter(t), this;
        }
        fit(e, t = this.worldWidth, n = this.worldHeight) {
          let r;
          e && (r = this.center),
            (this.scale.x = this.screenWidth / t),
            (this.scale.y = this.screenHeight / n),
            this.scale.x < this.scale.y
              ? (this.scale.y = this.scale.x)
              : (this.scale.x = this.scale.y);
          let i = this.plugins.get(`clamp-zoom`, !0);
          return i && i.clamp(), e && r && this.moveCenter(r), this;
        }
        setZoom(e, t) {
          let n;
          t && (n = this.center), this.scale.set(e);
          let r = this.plugins.get(`clamp-zoom`, !0);
          return r && r.clamp(), t && n && this.moveCenter(n), this;
        }
        zoomPercent(e, t) {
          return this.setZoom(this.scale.x + this.scale.x * e, t);
        }
        zoom(e, t) {
          return this.fitWidth(e + this.worldScreenWidth, t), this;
        }
        get scaled() {
          return this.scale.x;
        }
        set scaled(e) {
          this.setZoom(e, !0);
        }
        snapZoom(e) {
          return this.plugins.add(`snap-zoom`, new L(this, e)), this;
        }
        OOB() {
          return {
            left: this.left < 0,
            right: this.right > this.worldWidth,
            top: this.top < 0,
            bottom: this.bottom > this.worldHeight,
            cornerPoint: new t(
              this.worldWidth * this.scale.x - this.screenWidth,
              this.worldHeight * this.scale.y - this.screenHeight
            ),
          };
        }
        get right() {
          return -this.x / this.scale.x + this.worldScreenWidth;
        }
        set right(e) {
          (this.x = -e * this.scale.x + this.screenWidth), this.plugins.reset();
        }
        get left() {
          return -this.x / this.scale.x;
        }
        set left(e) {
          (this.x = -e * this.scale.x), this.plugins.reset();
        }
        get top() {
          return -this.y / this.scale.y;
        }
        set top(e) {
          (this.y = -e * this.scale.y), this.plugins.reset();
        }
        get bottom() {
          return -this.y / this.scale.y + this.worldScreenHeight;
        }
        set bottom(e) {
          (this.y = -e * this.scale.y + this.screenHeight),
            this.plugins.reset();
        }
        get dirty() {
          return !!this._dirty;
        }
        set dirty(e) {
          this._dirty = e;
        }
        get forceHitArea() {
          return this._forceHitArea;
        }
        set forceHitArea(e) {
          e
            ? ((this._forceHitArea = e), (this.hitArea = e))
            : ((this._forceHitArea = null),
              (this.hitArea = new r(0, 0, this.worldWidth, this.worldHeight)));
        }
        drag(e) {
          return this.plugins.add(`drag`, new D(this, e)), this;
        }
        clamp(e) {
          return this.plugins.add(`clamp`, new b(this, e)), this;
        }
        decelerate(e) {
          return this.plugins.add(`decelerate`, new T(this, e)), this;
        }
        bounce(e) {
          return this.plugins.add(`bounce`, new v(this, e)), this;
        }
        pinch(e) {
          return this.plugins.add(`pinch`, new N(this, e)), this;
        }
        snap(e, t, n) {
          return this.plugins.add(`snap`, new F(this, e, t, n)), this;
        }
        follow(e, t) {
          return this.plugins.add(`follow`, new k(this, e, t)), this;
        }
        wheel(e) {
          return this.plugins.add(`wheel`, new z(this, e)), this;
        }
        animate(e) {
          return this.plugins.add(`animate`, new g(this, e)), this;
        }
        clampZoom(e) {
          return this.plugins.add(`clamp-zoom`, new S(this, e)), this;
        }
        mouseEdges(e) {
          return this.plugins.add(`mouse-edges`, new j(this, e)), this;
        }
        get pause() {
          return !!this._pause;
        }
        set pause(e) {
          (this._pause = e),
            (this.lastViewport = null),
            (this.moving = !1),
            (this.zooming = !1),
            e && this.input.pause();
        }
        ensureVisible(e, t, n, r, i) {
          i &&
            (n > this.worldScreenWidth || r > this.worldScreenHeight) &&
            (this.fit(!0, n, r),
            this.emit(`zoomed`, { viewport: this, type: `ensureVisible` }));
          let a = !1;
          e < this.left
            ? ((this.left = e), (a = !0))
            : e + n > this.right && ((this.right = e + n), (a = !0)),
            t < this.top
              ? ((this.top = t), (a = !0))
              : t + r > this.bottom && ((this.bottom = t + r), (a = !0)),
            a && this.emit(`moved`, { viewport: this, type: `ensureVisible` });
        }
      });
  }))();
}
export { G as n, W as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/pixi_viewport-72U2r_0l.js.map
