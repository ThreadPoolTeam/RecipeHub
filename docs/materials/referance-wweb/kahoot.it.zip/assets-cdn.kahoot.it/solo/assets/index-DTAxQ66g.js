import { t as e } from "./solo-z64LhsmC.js";
e();
