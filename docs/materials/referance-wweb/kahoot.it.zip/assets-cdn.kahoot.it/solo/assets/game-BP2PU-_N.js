import { a as e, n as t, r as n, t as r } from "./rolldown-runtime-B0Z9INg1.js";
import {
  Go as i,
  Ra as a,
  fr as o,
  ft as s,
  gl as c,
  in as l,
  ll as u,
  mt as d,
  nn as f,
  rn as p,
  ro as m,
  si as ee,
  tn as h,
  xl as te,
  xt as ne,
} from "./app-Bv1T6OmB.js";
import {
  $ as re,
  $n as ie,
  $t as g,
  A as _,
  Aa as ae,
  An as oe,
  Ar as v,
  At as se,
  Ba as ce,
  Bn as le,
  Bt as y,
  C as b,
  Cn as x,
  Co as ue,
  Cr as S,
  Ct as de,
  D as fe,
  Da as pe,
  Dn as me,
  Dt as he,
  E as ge,
  En as _e,
  Eo as ve,
  Er as ye,
  Et as be,
  F as xe,
  Fn as Se,
  Ft as Ce,
  G as we,
  Gn as Te,
  Gt as Ee,
  Hn as De,
  Ht as Oe,
  I as ke,
  In as Ae,
  It as je,
  J as Me,
  Jn as Ne,
  Jt as Pe,
  K as Fe,
  Kn as Ie,
  Kt as Le,
  Ln as Re,
  Lt as ze,
  M as Be,
  Mn as Ve,
  Mr as C,
  Mt as He,
  N as Ue,
  Na as We,
  Nn as Ge,
  Nr as Ke,
  Nt as qe,
  O as Je,
  Oa as Ye,
  On as Xe,
  Oo as Ze,
  Ot as Qe,
  P as $e,
  Pn as et,
  Pr as w,
  Pt as tt,
  Q as nt,
  Qn as rt,
  Qt as it,
  Ra as at,
  Rn as ot,
  Rt as st,
  S as ct,
  Sn as lt,
  So as ut,
  Sr as dt,
  St as ft,
  T,
  Tn as pt,
  To as mt,
  Tr as ht,
  Tt as gt,
  U as _t,
  Un as vt,
  Ut as yt,
  Vn as bt,
  Vt as xt,
  W as St,
  Wn as Ct,
  Wt as wt,
  X as Tt,
  Xn as Et,
  Xt as Dt,
  Y as Ot,
  Ya as kt,
  Yn as At,
  Yt as jt,
  Z as Mt,
  Zn as Nt,
  Zt as Pt,
  _ as Ft,
  _a as It,
  _n as Lt,
  _r as Rt,
  _t as zt,
  ai as E,
  an as Bt,
  ar as Vt,
  at as Ht,
  b as Ut,
  ba as D,
  bn as Wt,
  bt as Gt,
  c as Kt,
  ci as O,
  cn as qt,
  co as Jt,
  cr as Yt,
  ct as Xt,
  d as Zt,
  da as Qt,
  dn as $t,
  dr as en,
  dt as tn,
  ei as nn,
  en as rn,
  er as an,
  et as on,
  fa as k,
  fn as sn,
  fo as cn,
  fr as ln,
  ft as un,
  g as dn,
  gn as fn,
  gr as pn,
  gt as mn,
  h as A,
  ha as hn,
  hn as gn,
  hr as _n,
  ht as vn,
  ii as j,
  in as yn,
  ir as M,
  it as bn,
  j as xn,
  jn as Sn,
  jt as Cn,
  k as wn,
  ka as Tn,
  kn as En,
  ko as Dn,
  kr as On,
  kt as kn,
  li as N,
  ln as An,
  lo as P,
  lr as jn,
  lt as Mn,
  m as Nn,
  ma as F,
  mn as Pn,
  mt as Fn,
  nn as In,
  nr as Ln,
  nt as Rn,
  o as I,
  on as zn,
  or as Bn,
  ot as Vn,
  pa as Hn,
  pn as Un,
  pr as Wn,
  pt as Gn,
  q as Kn,
  qn,
  qt as Jn,
  rn as Yn,
  rr as Xn,
  rt as Zn,
  s as Qn,
  sn as $n,
  so as er,
  sr as tr,
  st as nr,
  ti as rr,
  tn as ir,
  tr as L,
  tt as ar,
  ua as or,
  un as sr,
  ur as cr,
  ut as lr,
  v as ur,
  va as dr,
  vn as fr,
  vr as pr,
  vt as mr,
  w as hr,
  wn as gr,
  wo as _r,
  wr as R,
  wt as vr,
  x as yr,
  xa as z,
  xn as br,
  xr,
  xt as Sr,
  y as Cr,
  ya as wr,
  yn as Tr,
  yo as Er,
  yr as Dr,
  yt as Or,
  zn as kr,
  zt as Ar,
} from "./solo-z64LhsmC.js";
import {
  B,
  Bt as jr,
  Ct as Mr,
  On as Nr,
  P as Pr,
  Rt as V,
  U as H,
  Y as Fr,
  at as Ir,
  b as Lr,
  c as Rr,
  gn as zr,
  ht as U,
  pn as Br,
  u as Vr,
  w as Hr,
  yn as Ur,
} from "./lib-BTerfQ6O.js";
import {
  a as W,
  g as Wr,
  i as G,
  n as Gr,
  o as K,
  p as Kr,
  r as q,
  t as qr,
  u as J,
  v as Jr,
} from "./pixijs-game-zi5bgXGP.js";
import {
  a as Yr,
  i as Xr,
  n as Zr,
  o as Qr,
  s as $r,
} from "./random-XVBdEtiK.js";
import {
  a as ei,
  i as ti,
  n as ni,
  o as ri,
  r as ii,
  t as Y,
} from "./pixijs-particle-emitter-B_TZCnbP.js";
import { n as ai, t as oi } from "./android-webgl-hack-BKgRYXLm.js";
import {
  a as si,
  c as ci,
  d as li,
  i as ui,
  l as di,
  n as fi,
  o as pi,
  t as mi,
  u as hi,
} from "./confetti-CEJnA6uf.js";
import { n as gi, t as _i } from "./pixi_viewport-72U2r_0l.js";
import { n as vi, t as yi } from "./filter-outline-DZFGJaGV.js";
import { n as bi, t as xi } from "./filter-glow-BQjf2rFW.js";
var Si;
function Ci() {
  return (Ci = t(() => {
    Si = ({ radius: e = 100 }) => ({
      lifetime: { min: 0.75, max: 1 },
      frequency: 0.001,
      emitterLifetime: 0.3,
      maxParticles: 1e3,
      addAtBack: !1,
      pos: { x: 0, y: 0 },
      behaviors: [
        {
          type: `alpha`,
          config: {
            alpha: {
              list: [
                { time: 0, value: 1 },
                { time: 0.85, value: 1 },
                { time: 1, value: 0 },
              ],
            },
          },
        },
        {
          type: `moveAcceleration`,
          config: {
            accel: { x: 0, y: 1e3 },
            minStart: 500,
            maxStart: 500,
            rotate: !0,
            maxSpeed: 0,
          },
        },
        {
          type: `scale`,
          config: {
            scale: {
              list: [
                { time: 0, value: 0.15 },
                { time: 0.5, value: 1 },
                { time: 1, value: 0 },
              ],
            },
            minMult: 1,
          },
        },
        {
          type: `rotation`,
          config: {
            accel: 0,
            minSpeed: 0,
            maxSpeed: 280,
            minStart: 245,
            maxStart: 300,
          },
        },
        {
          type: `spawnShape`,
          config: {
            type: `torus`,
            data: { x: 0, y: 0, radius: e, innerRadius: 0, affectRotation: !1 },
          },
        },
        { type: `colorStatic`, config: { color: `#ffffff` } },
        {
          type: `colorRandomStatic`,
          config: {
            colors: [
              `#DFFF00`,
              `#FFBF00`,
              `#FF7F50`,
              `#DE3163`,
              `#9FE2BF`,
              `#40E0D0`,
              `#6495ED`,
              `#CCCCFF`,
            ],
          },
        },
      ],
    });
  }))();
}
var X;
function Z() {
  return (Z = t(() => {
    J(),
      (X = class e extends Rr {
        static set isRtl(t) {
          if (e._isRtl !== void 0 && e._isRtl !== t && {}.K_DEV === `true`) {
            console.warn(
              `IslandText._isRtl is already set to "${e._isRtl}" and cannot be changed to "${t}".`
            );
            return;
          }
          e._isRtl = t;
        }
        get y() {
          return this._yRaw;
        }
        set y(e) {
          (this._yRaw = e), (super.y = e + this._yOffset);
        }
        get style() {
          return super.style;
        }
        set style(t) {
          (super.style = t),
            e._isRtl && (this.style.textBaseline = `ideographic`);
        }
        constructor(t, n, r) {
          if (e._isRtl === void 0)
            throw Error(`IslandText._isRtl is not initialized`);
          super(t, n, r),
            (this.onTick = () => {
              this.height !== this._prevHeight &&
                ((this._prevHeight = this.height),
                (this._yOffset = this.height * 0.15),
                (this.y = this._yRaw));
            }),
            (this._prevHeight = 0),
            (this._yRaw = 0),
            (this._yOffset = 0),
            e._isRtl &&
              ((this.style.textBaseline = `ideographic`),
              Ir.shared.add(this.onTick));
        }
        destroy(e) {
          Ir.shared.remove(this.onTick), super.destroy(e);
        }
        static {
          this._isRtl = void 0;
        }
      });
  }))();
}
var wi;
function Ti() {
  return (Ti = t(() => {
    wi = `https://assets-cdn.kahoot.it/solo/assets/async-rewards-notifications-koala-DdNlyOCC.atlas`;
  }))();
}
var Ei;
function Di() {
  return (Di = t(() => {
    Ei = `https://assets-cdn.kahoot.it/solo/assets/async-rewards-notifications-koala-B6FfYe84.json`;
  }))();
}
var Oi;
function ki() {
  return (ki = t(() => {
    Oi = `https://assets-cdn.kahoot.it/solo/assets/async-rewards-notifications-koala-CB9yS2Wo.png`;
  }))();
}
var Ai, ji, Mi;
function Ni() {
  return (Ni = t(() => {
    Ti(),
      Di(),
      ki(),
      ht(),
      (Ai = `zoom_in_animation_sound`),
      (ji = `async_rewards_notifications_koala`),
      (Mi = [
        { name: Ai, url: ye },
        {
          name: ji,
          url: Ei,
          loadParser: `loadSpine`,
          data: {
            atlasFile: wi,
            imageFiles: { "async-rewards-notifications-koala.png": Oi },
            spineSkeletonScale: 0.55,
          },
        },
      ]);
  }))();
}
var Pi;
function Fi() {
  return (Fi = t(() => {
    Pi = `https://assets-cdn.kahoot.it/solo/assets/island_time-lapse-music-BcZzo_cg.mp3`;
  }))();
}
var Ii, Li;
function Ri() {
  return (Ri = t(() => {
    Fi(), (Ii = `time_lapse_music`), (Li = [{ name: Ii, url: Pi }]);
  }))();
}
var zi, Bi;
function Vi() {
  return (Vi = t(() => {
    An(),
      pr(),
      y(),
      (zi = [
        {
          name: un,
          theme: Rt.Valentines,
          url: sr.mp3.background[`lobby-beatbox`],
          loadParser: `loadSound`,
          data: { loop: !0 },
        },
      ]),
      (Bi = (e, t) => {
        let { theme: n } = t;
        return n === Rt.Valentines
          ? zi.filter((t) => e.some((e) => e.name === t.name))
          : [];
      });
  }))();
}
var Hi,
  Ui,
  Wi,
  Gi,
  Ki,
  qi,
  Ji,
  Yi,
  Xi,
  Q,
  Zi,
  Qi,
  $i,
  ea,
  ta,
  na,
  ra,
  ia,
  aa,
  oa,
  sa,
  ca,
  la;
function ua() {
  return (ua = t(() => {
    (Hi = e(s())),
      (Ui = e(o())),
      cn(),
      kt(),
      R(),
      We(),
      D(),
      Vt(),
      F(),
      En(),
      pr(),
      _(),
      qt(),
      me(),
      Ni(),
      y(),
      xe(),
      Ri(),
      St(),
      fn(),
      tn(),
      Vn(),
      bn(),
      on(),
      Vi(),
      Tt(),
      (Wi = (e) => e?.type === pn.Final),
      (Gi = (e) => e?.type === pn.Sequential),
      (Ki = (e) => e.type === `central`),
      (qi = (e) => e.type === `static`),
      (Ji = (e) => e.type === `spine`),
      (Yi = (e, t) => z(t.textureNames, k(e.seed)) ?? t.textureNames[0]),
      (Xi = (e) => Zi(e.type, e.xp)?.type),
      (Q = (e) => {
        let t = Zi(e.type, e.xp);
        if (t && `resourceNames` in t) return z(t.resourceNames, k(e.seed));
      }),
      (Zi = (e, t = 0) => {
        let n = we[e];
        if (!n) return;
        if (Wi(n) || Gi(n)) return n.spriteResource;
        let { level: r } = b(e, t);
        return n.spriteResourcePerStep[r] ?? n.spriteResourcePerStep.at(-1);
      }),
      (Qi = (e, t = 0) => {
        let n = Zi(e, t);
        if (n?.type === `spine`) return n.animationName;
      }),
      ($i = (e) => {
        if (e.type !== M.GenericGame) return;
        if (e.partnerThemeCoverImage)
          return {
            name: e.partnerThemeCoverImage,
            url: e.partnerThemeCoverImage,
            loadParser: `loadTextures`,
          };
        let t = ea(e.gameMode, e.gameModeSkin);
        return Oe.find((e) => e.name === t);
      }),
      (ea = (e, t) => {
        switch (e) {
          case P.Classic:
          case P.Large:
          case void 0:
            return;
          case P.Confidence:
          case P.Presentation:
          case P.Puzzlebox:
          case P.Marble:
          case P.Sphere:
            return ft;
          case P.Collaboration:
          case P.Stadium:
          case P.Team:
            return kn;
          case P.Accuracy:
            return Sr;
          case P.Walking:
            return Cn;
          case P.TapToCollect:
            return Qe;
          case P.Submarine:
            return he;
          case P.PaintWar:
            return gt;
          case P.Temple:
            return se;
          case P.Picasso:
            return be;
          case P.HighestTowers:
            return t === Tn.HighestTowersSpace ? de : vr;
          case P.Unplugged:
          case P.Turnstile:
            return ft;
          default:
            return ft;
        }
      }),
      (ta = (e) => {
        let t = [
            ...ia(),
            ...aa(e),
            ...oa(e),
            ...ca(e),
            ...la(e),
            ...sa(e),
            ...gn(e),
          ],
          n = [
            ...lr(t, e),
            ...re(t, e),
            ...Ot(t, e),
            ...Ht(t, e),
            ...Bi(t, e),
            ...Zn(t, e),
          ];
        return [...t, ...n];
      }),
      (na = (e) =>
        e
          ? (Wi(e) || Gi(e)
              ? [e.spriteResource]
              : e.spriteResourcePerStep
            ).flatMap((e) =>
              Ki(e) ? [] : qi(e) || Ji(e) ? e.resourceNames : []
            )
          : []),
      (ra = (e, t) =>
        (0, Hi.default)(
          (0, Ui.default)(t).map((t) => e.find((e) => e.name === t))
        )),
      (ia = () => {
        let e = Xe.find((e) => e.name === Wt);
        return [...$n, ...(e ? [e] : [])];
      }),
      (aa = (e) => {
        let { items: t, gameResultConfig: n } = e,
          r = (0, Hi.default)(
            t.flatMap((e) =>
              e.type === S.BasicBuilding
                ? n
                  ? na(we[S.BasicBuilding])
                  : Q(e)
                : e.type === S.League
                ? n
                  ? [Q(e), x, lt, gr]
                  : Q(e)
                : e.type === S.AssignmentBuilding &&
                  e.data?.status === `in-progress`
                ? [pt, _e, Q(e)]
                : e.type === S.AssignmentBuilding &&
                  e.data?.status === `pending`
                ? [pt, Q(e)]
                : e.type === S.AssignmentBuilding &&
                  e.data?.status === `completed`
                ? [Lt, pt, Q(e)]
                : Q(e)
            )
          );
        return r.push(Wt), ra(Xe, r);
      }),
      (oa = (e) => (e.gameResultConfig ? [] : Mi)),
      (sa = (e) => (e.initialAnimationStyle === `timeLapse` ? Li : [])),
      (ca = (e) => {
        let { gameResultConfig: t, initialAnimationStyle: n, items: r } = e;
        if (!t) return [];
        let i = [];
        n === `zoomOut`
          ? i.push(Or)
          : n === `podium` && (i.push(st), i.push(Or)),
          t.type === M.GameClassic
            ? (i.push(un), i.push(mr))
            : t.type === M.GenericGame && (i.push(un), i.push(mr), i.push(Gt)),
          r.forEach((e) => {
            if (Sn(e) && (e.xp ?? 0) > 0)
              switch (e.type) {
                case S.BrandEventPortalExample:
                  i.push(Gn);
                  break;
                case S.BrandEventPortalKahootPirates:
                  i.push(Fn);
                  break;
                case S.BrandEventPortalTourDeFrance:
                  i.push(vn);
                  break;
                default:
              }
          });
        let a = ra(Oe, i),
          o = (0, Hi.default)([$i(t)]);
        return [...xt, ...a, ...o];
      }),
      (la = (e) => {
        let {
          gridWidth: t,
          gridHeight: n,
          terrain: r,
          initialAnimationStyle: i,
        } = e;
        if (i === `timeLapse`) return ke;
        let a = [];
        for (let e = 0; e < n; e++)
          for (let i = 0; i < t; i++) {
            let o = r[e]?.[i],
              s = Je(e, i, r, t, n);
            if (!o || !s) continue;
            let c = Yi(o, s);
            c && a.push(c);
          }
        return ra(ke, a);
      });
  }))();
}
function $() {
  return ($ = t(() => {
    qt(), me(), Ni(), y(), fn(), tn(), St(), ua();
  }))();
}
var da;
function fa() {
  return (fa = t(() => {
    J(),
      G(),
      $(),
      (da = class extends H {
        set allowFullFill(e) {
          this._allowFullFill = e;
        }
        get progress() {
          return this._progress;
        }
        set progress(e) {
          this._progress = e;
          let t = this._bgSprite.width,
            n =
              this._progress >= 1 || this._allowFullFill
                ? t
                : t - this._progressFillOffset,
            r = yn[0] + yn[2],
            i = Math.min(
              n,
              Math.max(r, t * this._progress + this._progressFillOffset)
            );
          (this._progressSprite.width = Math.max(yn[0] + yn[2], i)),
            this._isRtl &&
              ((this._progressSprite.x = t - this._progressSprite.width),
              (this._progressMask.x = t - i)),
            (this._progressMask.width = i);
        }
        constructor({
          isRtl: e,
          barWidth: t,
          barHeight: n,
          progressFillOffset: r = 0,
        }) {
          super(),
            (this._allowFullFill = !1),
            (this._progress = 0),
            (this._isRtl = e),
            (this._barContainer = new H()),
            (this._progressSprite = this.createNineSlicePlane(Yn, t, n)),
            (this._progressFillOffset = r),
            (this._bgSprite = this.createNineSlicePlane(ir, t, n)),
            (this._progressMask = this.createMask(this._progressSprite)),
            (this._progressSprite.mask = this._progressMask),
            (this._borderSprite = this.createNineSlicePlane(In, t, n)),
            this._barContainer.addChild(
              this._bgSprite,
              this._progressSprite,
              this._progressMask,
              this._borderSprite
            ),
            this.addChild(this._barContainer);
        }
        destroy(e) {
          this._progressMask?.destroy(!0), super.destroy(e);
        }
        get barContainer() {
          return this._barContainer;
        }
        get progressSprite() {
          return this._progressSprite;
        }
        createNineSlicePlane(e, t, n) {
          let r = q.instance.getResourceTexture(e) ?? U.EMPTY,
            i = new Hr(r, ...yn);
          return (i.width = t), (i.height = n), i;
        }
        createMask(e) {
          let t = new Pr()
            .beginFill(0)
            .drawRect(0, 0, e.width, e.height)
            .endFill();
          return (t.x = e.x), (t.y = e.y), t;
        }
      });
  }))();
}
var pa, ma, ha, ga;
function _a() {
  return (_a = t(() => {
    J(),
      Z(),
      L(),
      G(),
      j(),
      N(),
      C(),
      $(),
      fa(),
      (pa = 24),
      (ma = 24),
      (ha = 3930880),
      (ga = class extends da {
        set showText(e) {
          this._tween?.stop(),
            e
              ? ((this._text.y = -23), (this._text.alpha = 1))
              : ((this._text.y = 13), (this._text.alpha = 0));
        }
        fadeInText(e) {
          this._tween?.stop(),
            (this._text.y = 0),
            (this._text.alpha = 0),
            (this._tween = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: 500,
              easing: E.EASE_OUT_CIRC,
              onTick: ({ value: e }) => {
                (this._text.alpha = e), (this._text.y = w(0, -23, e));
              },
              onFinish: e,
            })),
            this._tween.play();
        }
        fadeOutText(e) {
          this._tween?.stop();
          let t = this._text.alpha,
            n = this._text.y;
          (this._tween = O({
            from: { value: 0 },
            to: { value: 1 },
            duration: 500,
            easing: E.EASE_IN_SINE,
            onTick: ({ value: e }) => {
              (this._text.alpha = w(t, 0, e)),
                (this._text.y = w(n, n - ma / 2, e));
            },
            onFinish: () => {
              e?.();
            },
          })),
            this._tween.play();
        }
        constructor(e) {
          let {
              itemWidth: t,
              positionY: n,
              textContent: r,
              isRtl: i,
              startTime: a,
              endTime: o,
            } = e,
            s = Dr(a, o),
            c = t - pa;
          super({ isRtl: i, barWidth: c, barHeight: ma }),
            (this.y = n + ma),
            (this.x = t / -2),
            this._isRtl
              ? (this.barContainer.x = 0)
              : (this.barContainer.x = pa),
            (this.progressSprite.tint = ha),
            (this._text = this.createText(r, t));
          let l = this.createIcon(t);
          this.addChild(l, this._text), (this.progress = s);
        }
        destroy(e) {
          this._tween?.destroy(), super.destroy(e);
        }
        createText(e, t) {
          let n = new X();
          return (
            (n.style = {
              fontFamily: `Grandstander`,
              fontSize: 30,
              fontWeight: `700`,
              fill: `white`,
              dropShadow: !0,
              dropShadowColor: `black`,
              dropShadowDistance: 0,
              dropShadowAngle: 90,
              dropShadowAlpha: 1,
              dropShadowBlur: 3,
            }),
            n.anchor.set(0.5, 0.5),
            (n.x = t / 2 + 0),
            (n.resolution = 2),
            (n.text = e ?? ``),
            n
          );
        }
        createIcon(e) {
          let t = q.instance.getResourceTexture(_e),
            n = new H(),
            r = new B(t);
          (r.tint = 0),
            (r.alpha = 0.4),
            (r.width = 25),
            (r.height = 25),
            (r.x = this._isRtl ? e - r.width + 3 + 1 : -2),
            (r.y = 1),
            n.addChild(r);
          let i = new B(t);
          return (
            (i.width = pa),
            (i.height = pa),
            (i.x = this._isRtl ? e - r.width + 3 : -3),
            (i.y = 0),
            n.addChild(i),
            n
          );
        }
      });
  }))();
}
var va, ya, ba;
function xa() {
  return (xa = t(() => {
    J(),
      vi(),
      nn(),
      j(),
      N(),
      L(),
      (va = 8),
      (ya = 1.205),
      (ba = class extends H {
        prepareAnimateAppear() {
          this._itemContainer.scale.set(0);
        }
        prepareAnimateProgressUp() {
          this._itemContainer.scale.set(1);
        }
        prepareAnimateLevelUp() {
          this._itemContainer.scale.set(0);
        }
        animateAppear(e, t) {
          let n = (e) => {
              this.destroyed ||
                ((this._tween = O({
                  from: { scale: 0 },
                  to: { scale: 1 },
                  duration: 500,
                  easing: E.EASE_OUT_BACK,
                  onTick: (e) => {
                    this._itemContainer.scale.set(e.scale);
                  },
                  onFinish: e,
                })),
                this._tween.play());
            },
            r = (t) => {
              this.destroyed ||
                (this._auxTimeoutId = window.setTimeout(() => {
                  this.destroyed || (e?.(), t?.());
                }, 300));
            },
            i = (e) => {
              this.destroyed ||
                (this._auxTimeoutId = window.setTimeout(() => {
                  this.destroyed || e?.();
                }, 350));
            },
            a = () => {
              this.destroyed ||
                (this._tween?.destroy(),
                clearTimeout(this._auxTimeoutId),
                t?.());
            };
          n(() => r(() => i(a)));
        }
        animateProgressUp(e, t) {
          let n = (e) => {
              this.destroyed ||
                ((this._tween = O({
                  from: { scale: 1 },
                  to: { scale: 1.1 },
                  duration: 500 / 2,
                  easing: E.EASE_OUT_BACK,
                  onTick: (e) => {
                    this._itemContainer.scale.set(e.scale);
                  },
                  onFinish: e,
                })),
                this._tween.play());
            },
            r = (e) => {
              this.destroyed ||
                ((this._tween = O({
                  from: { scale: 1.1 },
                  to: { scale: 1 },
                  duration: 500 / 2,
                  easing: E.EASE_OUT_BACK,
                  onTick: (e) => {
                    this._itemContainer.scale.set(e.scale);
                  },
                  onFinish: e,
                })),
                this._tween.play());
            };
          n(() =>
            r(() => {
              e?.(), t?.();
            })
          );
        }
        animateLevelUp(e, t) {
          let n = (e) => {
              this.destroyed ||
                ((this._tween = O({
                  from: { scale: 0.5 },
                  to: { scale: 1 },
                  duration: 500,
                  easing: E.EASE_OUT_BOUNCE,
                  onTick: (e) => {
                    this._itemContainer.scale.set(e.scale);
                  },
                  onFinish: e,
                })),
                this._tween.play());
            },
            r = (t) => {
              this.destroyed ||
                (this._auxTimeoutId = window.setTimeout(() => {
                  this.destroyed || (e?.(), t?.());
                }, 500));
            },
            i = (e) => {
              this.destroyed ||
                (this._auxTimeoutId = window.setTimeout(() => {
                  this.destroyed || e?.();
                }, rt));
            },
            a = () => {
              this.destroyed ||
                (this._tween?.destroy(),
                clearTimeout(this._auxTimeoutId),
                t?.());
            };
          n(() => r(() => i(a)));
        }
        constructor(e) {
          super(),
            (this._auxTimeoutId = -1),
            (this._islandConfig = e.islandConfig),
            (this._config = e.config),
            (this._itemContainer = new H()),
            this.addChild(this._itemContainer),
            this.initialize(this._itemContainer);
        }
        destroy(e) {
          this._tween?.destroy(),
            this._selectFilter?.destroy(),
            clearTimeout(this._auxTimeoutId),
            super.destroy(e);
        }
        get itemContainer() {
          return this._itemContainer;
        }
        get islandConfig() {
          return this._islandConfig;
        }
        get config() {
          return this._config;
        }
        get _outlineFilterThickness() {
          return (this.worldTransform.a * va) / ya;
        }
        updateTransform() {
          super.updateTransform(),
            this._selectFilter instanceof yi &&
              (this._selectFilter.thickness = this._outlineFilterThickness);
        }
        setSelectedFilter(e, t) {
          let n = () => {
            if (rr()) return new yi(this._outlineFilterThickness, 16777215);
            let e = new Wr();
            return e.brightness(1.5, !0), e;
          };
          if (((this._selectFilter ||= n()), !t)) {
            e.filters =
              e.filters?.filter((e) => e !== this._selectFilter) ?? [];
            return;
          }
          e.filters = [...(e.filters ?? []), this._selectFilter];
        }
      });
  }))();
}
var Sa, Ca, wa, Ta;
function Ea() {
  return (Ea = t(() => {
    J(),
      W(),
      D(),
      G(),
      F(),
      $(),
      _(),
      xa(),
      (Sa = `default`),
      (Ca = `IDLE`),
      (wa = `COLORIZE`),
      (Ta = class extends ba {
        select() {
          this._spine && this.setSelectedFilter(this._spine, !0);
        }
        deselect() {
          this._spine && this.setSelectedFilter(this._spine, !1);
        }
        initialize(e) {
          let t = Q(this.config);
          if (!t) return;
          let n = q.instance.getResourceSpine(t);
          n &&
            ((this._spine = new K(n.spineData)),
            this._spine.skeleton.setSkinByName(Sa),
            e.addChild(this._spine),
            this.colorizeSlots(),
            this.selectAnimation());
        }
        syncFilterArea() {
          if (!this._spine) return;
          if (!this._spine.filters?.length) {
            this._spine.filterArea !== null && (this._spine.filterArea = null);
            return;
          }
          let e = this._spine.worldTransform,
            t = (this._spine.skeleton.data.width * Math.abs(e.a)) / 2,
            n = (this._spine.skeleton.data.height * Math.abs(e.d)) / 2;
          this._spine.filterArea || (this._spine.filterArea = new V()),
            (this._spine.filterArea.x = e.tx - t),
            (this._spine.filterArea.y = e.ty - n),
            (this._spine.filterArea.width = t * 2),
            (this._spine.filterArea.height = n * 2);
        }
        updateTransform() {
          super.updateTransform(), this.syncFilterArea();
        }
        selectAnimation() {
          if (!this._spine) return;
          let e = Qi(this.config.type, this.config.xp);
          if (e) this._spine.state.setAnimation(0, e, !0);
          else {
            let e = this._spine.state.data.skeletonData.animations
                .map((e) => e.name)
                .filter((e) => e.includes(Ca)),
              t = z(e, k(this.config.seed));
            if (!t) return;
            this._spine.state.setAnimation(0, t, !0);
          }
          this._spine.state.timeScale = Hn()(0.8, 1.2);
        }
        colorizeSlots() {
          if (!this._spine) return;
          let e = Nn(this.config),
            t = e ? Fe[e] : void 0;
          if (!t) return;
          let n = this._spine.skeleton.data.slots.map((e) => e.name);
          for (let e of n)
            e.includes(wa) &&
              this._spine.skeleton.findSlot(e)?.color.setFromString(t);
        }
      });
  }))();
}
var Da, Oa, ka, Aa, ja, Ma;
function Na() {
  return (Na = t(() => {
    (Da = e(m())),
      W(),
      _a(),
      $(),
      _(),
      G(),
      Ea(),
      (Oa = `default`),
      (ka = `01 IDLE`),
      (Aa = `default`),
      (ja = `animation`),
      (Ma = class extends Ta {
        select() {
          super.select(),
            this._progressBar?.fadeInText(),
            this._present && this.setSelectedFilter(this._present, !0);
        }
        deselect() {
          super.deselect(),
            this._progressBar?.fadeOutText(),
            this._present && this.setSelectedFilter(this._present, !1);
        }
        updateStatus(e) {
          this._status !== e && ((this._status = e), this.setup());
        }
        initialize(e) {
          super.initialize(e),
            (this._status = this.config.data.status),
            this.setup();
        }
        setup() {
          if (this._spine)
            switch (
              (this._present && this.itemContainer.removeChild(this._present),
              this._flag && this.itemContainer.removeChild(this._flag),
              this._progressBar &&
                this.itemContainer.removeChild(this._progressBar),
              (this._spine.visible = !1),
              this._status)
            ) {
              case `in-progress`:
                this.addPresentItem(), this.addProgressBar();
                break;
              case `pending`:
                this.addPresentItem();
                break;
              default:
                (this._spine.visible = !0),
                  this.addFlagItem(),
                  this.pullBaseSpriteUp();
            }
        }
        addFlagItem() {
          let e = q.instance.getResourceSpine(Lt);
          e &&
            ((this._flag = new K(e.spineData)),
            this._flag.position.set(0, this.height * -0.15),
            this._flag.skeleton.setSkinByName(Aa),
            this._flag.state.setAnimation(0, ja, !0),
            this.itemContainer.addChild(this._flag));
        }
        pullBaseSpriteUp() {
          let { level: e } = b(this.config.type, this.config.xp);
          this._spine &&
            e > 0 &&
            (this._spine.position.y = this.height * -0.13);
        }
        addPresentItem() {
          let e = q.instance.getResourceSpine(pt);
          e &&
            ((this._present = new K(e.spineData)),
            this._present.skeleton.setSkinByName(Oa),
            (this._present.state.data.defaultMix = 0.2),
            this._present.state.setAnimation(0, ka, !0),
            this.itemContainer.addChild(this._present));
        }
        addProgressBar() {
          let { startTime: e, endTime: t } = this.config.data,
            n = !!t && xr(t);
          if (e && n) {
            let n =
              wn(`assignmentTimeLeft`)?.find((e) =>
                (0, Da.default)(e.gridPosition, this.config.gridPosition)
              )?.translation ?? ``;
            (this._progressBar = new ga({
              itemWidth: this.width,
              startTime: e,
              endTime: t,
              positionY: -this.height + 20,
              isRtl: this.islandConfig.isRtl,
              textContent: n,
            })),
              (this._progressBar.showText = !1),
              this.itemContainer.addChild(this._progressBar);
          }
        }
      });
  }))();
}
var Pa;
function Fa() {
  return (Fa = t(() => {
    ri(),
      (Pa = class {
        static {
          this.type = `scaleExt`;
        }
        constructor(e) {
          (this.order = 2),
            (this.listX = new ti(!1)),
            (this.listY = new ti(!1)),
            this.listX.reset(ei.createList(e.scaleX)),
            this.listY.reset(ei.createList(e.scaleY)),
            (this.minMultX = e.minMultX ?? 1),
            (this.minMultY = e.minMultY ?? 1);
        }
        initParticles(e) {
          let t = e;
          for (; t; ) {
            let e = Math.random() * (1 - this.minMultX) + this.minMultX,
              n = Math.random() * (1 - this.minMultY) + this.minMultY;
            (t.config.scaleMultX = e),
              (t.config.scaleMultY = n),
              (t.scale.x = this.listX.first.value * e),
              (t.scale.y = this.listY.first.value * n),
              (t = t.next);
          }
        }
        updateParticle(e) {
          (e.scale.x =
            this.listX.interpolate(e.agePercent) * e.config.scaleMultX),
            (e.scale.y =
              this.listY.interpolate(e.agePercent) * e.config.scaleMultY);
        }
      });
  }))();
}
var Ia, La, Ra;
function za() {
  return (za = t(() => {
    Fr(),
      (Ia = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
}`),
      (La = `varying vec2 vTextureCoord;
uniform sampler2D uSampler;
uniform vec3 color;
uniform float alpha;

void main(void) {
    vec4 currentColor = texture2D(uSampler, vTextureCoord);
    gl_FragColor = vec4(mix(currentColor.rgb, color.rgb, currentColor.a * alpha), currentColor.a);
}
`),
      (Ra = class extends Mr {
        constructor(e = 0, t = 1) {
          super(Ia, La),
            (this._color = 0),
            (this._alpha = 1),
            (this.uniforms.color = new Float32Array(3)),
            (this.color = e),
            (this.alpha = t);
        }
        set color(e) {
          let t = this.uniforms.color;
          typeof e == `number`
            ? (Br(e, t), (this._color = e))
            : ((t[0] = e[0]),
              (t[1] = e[1]),
              (t[2] = e[2]),
              (this._color = zr(t)));
        }
        get color() {
          return this._color;
        }
        set alpha(e) {
          (this.uniforms.alpha = e), (this._alpha = e);
        }
        get alpha() {
          return this._alpha;
        }
      });
  }))();
}
var Ba;
function Va() {
  return (Va = t(() => {
    Ba = () => ({
      lifetime: { min: 0.5, max: 1 },
      particlesPerWave: 16,
      frequency: 0.04,
      emitterLifetime: 0.15,
      maxParticles: 1e3,
      addAtBack: !1,
      pos: { x: 0, y: 0 },
      behaviors: [
        {
          type: `alpha`,
          config: {
            alpha: {
              list: [
                { time: 0, value: 1 },
                { time: 1, value: 0 },
              ],
            },
          },
        },
        {
          type: `moveSpeed`,
          config: {
            speed: {
              list: [
                { time: 0, value: 250 },
                { time: 1, value: 0 },
              ],
            },
            minMult: 1.25,
          },
        },
        {
          type: `scale`,
          config: {
            scale: {
              list: [
                { time: 0, value: 0.75 },
                { time: 1, value: 0.001 },
              ],
            },
            minMult: 1,
          },
        },
        { type: `spawnBurst`, config: { start: 0, spacing: 0, distance: 0 } },
      ],
    });
  }))();
}
function Ha(e, t) {
  return e < 0 && (e = 0), e > t.length - 1 && (e = t.length - 1), t[e];
}
function Ua(e, t, n) {
  return (t * (Ha(e + 1, n) - Ha(e - 1, n))) / 2;
}
function Wa(e, t, n = 1) {
  let r = Math.floor(t),
    i = [Ua(r, n, e), Ua(r + 1, n, e)],
    a = [Ha(r, e), Ha(r + 1, e)];
  t -= r;
  let o = t * t,
    s = t * o;
  return (
    (2 * s - 3 * o + 1) * a[0] +
    (s - 2 * o + t) * i[0] +
    (-2 * s + 3 * o) * a[1] +
    (s - o) * i[1]
  );
}
var Ga;
function Ka() {
  return (Ka = t(() => {
    J(),
      di(),
      (Ga = (e, t, n = `#ffffff`) => {
        let r = ci(e, t);
        if (!r) return U.EMPTY;
        r.clearRect(0, 0, e, t),
          r.beginPath(),
          r.moveTo(0, t / 2 - t / 2),
          r.lineTo(e, t / 2),
          r.lineTo(0, t / 2 + t / 2),
          r.closePath();
        let i =
            typeof n == `number` ? `#${n.toString(16).padStart(6, `0`)}` : n,
          a = r.createLinearGradient(0, 0, e, 0);
        return (
          a.addColorStop(0, i),
          a.addColorStop(0.7, i),
          a.addColorStop(1, `rgba(255, 255, 255, 0)`),
          (r.fillStyle = a),
          r.fill(),
          U.from(r.canvas, { pixiIdPrefix: `trail` })
        );
      });
  }))();
}
var qa;
function Ja() {
  return (Ja = t(() => {
    J(),
      Ka(),
      (qa = class extends Lr {
        constructor({
          texture: e,
          pointsSize: t = 20,
          historySize: n = 20,
          initialPosition: r = { x: 0, y: 0 },
        }) {
          let i = e instanceof U ? e : Ga(e.length, e.thickness, e.color),
            a = Array.from({ length: t }, () => new jr(r.x, r.y));
          super(i, a),
            (this.historyX = []),
            (this.historyY = []),
            (this.points = []),
            (this.points = a),
            (this.historyX = Array.from({ length: n }, () => r.x)),
            (this.historyY = Array.from({ length: n }, () => r.y));
        }
        update(e, t) {
          this.historyX.pop(),
            this.historyX.unshift(e),
            this.historyY.pop(),
            this.historyY.unshift(t);
          for (let e = 0; e < this.points.length; e++) {
            let t = (e / this.points.length) * this.historyX.length;
            (this.points[e].x = Wa(this.historyX, t)),
              (this.points[e].y = Wa(this.historyY, t));
          }
        }
      });
  }))();
}
function Ya() {
  return (Ya = t(() => {
    Ja(), Ka();
  }))();
}
var Xa, Za;
function Qa() {
  return (Qa = t(() => {
    mt(),
      J(),
      za(),
      kt(),
      R(),
      G(),
      ni(),
      mi(),
      Va(),
      Ya(),
      j(),
      N(),
      C(),
      $(),
      (Xa = 15),
      (Za = class {
        prepare() {
          this._itemRef.itemSpriteRef.levelBarRef?.update(
            this._startPoints,
            this._totalPoints
          );
        }
        animate(e) {
          if (this._renderPoints <= 0) {
            e?.();
            return;
          }
          let t = Array.from({ length: this._renderPoints }, (e, t) =>
            this.animatePointSprite(t)
          );
          this.animateBackdropIn()
            .then(() => Promise.all(t))
            .then(
              () => (
                this.animateTargetItemBar(!0), this.waitForMilliseconds(500)
              )
            )
            .then(() => this.animateBackdropOut())
            .finally(() => {
              e?.();
            })
            .catch((e) => {
              ve(`Brand Event Portal Points animation error`, { error: e });
            });
        }
        constructor({ container: e, centerRef: t, itemRef: n, viewport: r }) {
          (this._timeOutIds = []),
            (this._pointTweens = []),
            (this._sparklesTextures = []),
            (this._sparkles = []),
            (this._trails = []),
            (this._completedPointAnimCount = 0),
            (this._parentContainer = e),
            (this._container = new H()),
            this._parentContainer.addChild(this._container),
            (this._centerRef = t),
            (this._itemRef = n),
            (this._viewport = r),
            (this._pointTexture = this.getPointTexture()),
            (this._targetItemFilter = this.addColorOverlayToItem(
              this._itemRef
            )),
            (this._sparklesTextures = [si(10), pi(10)]),
            (this._sparklesConfig = Ba()),
            (this._trailTexture = Ga(
              256,
              (this._pointTexture?.height ?? 20) / 2,
              5089023
            ));
        }
        update(e) {
          this._sparkles.forEach((t) => t.update(e));
        }
        destroy() {
          this._backdrop?.destroy(!0),
            this._backdropTween?.destroy(),
            this._pointTweens.forEach((e) => e.destroy()),
            (this._pointTweens = []),
            this._targetItemTween?.destroy(),
            this._timeOutIds.forEach((e) => window.clearTimeout(e)),
            this._sparklesTextures.forEach((e) => e.destroy(!0)),
            (this._sparklesTextures = []),
            this._sparkles.forEach((e) => e.destroy(!0)),
            (this._sparkles = []),
            this._trails.forEach((e) => e.destroy()),
            (this._trails = []),
            this._parentContainer.removeChild(this._container),
            this._container.destroy({ children: !0 }),
            this._itemRef.itemSpriteRef.scale.set(1),
            this.removeColorOverlayFromItem(
              this._itemRef,
              this._targetItemFilter
            );
        }
        get _gainedPoints() {
          return this._itemRef.config.xp ?? 0;
        }
        get _startPoints() {
          return Math.min(
            Math.max(0, this._currPoints - this._gainedPoints),
            this._totalPoints
          );
        }
        get _currPoints() {
          return this._itemRef.config.data.points ?? 0;
        }
        get _totalPoints() {
          return this._itemRef.config.data.total ?? 0;
        }
        get _renderPoints() {
          return Math.min(this._gainedPoints, Xa);
        }
        get _incPoints() {
          return Math.max(
            1,
            this._renderPoints > 0
              ? Math.floor(this._gainedPoints / this._renderPoints)
              : 1
          );
        }
        getPointTexture() {
          switch (this._itemRef.config.type) {
            case S.BrandEventPortalExample:
              return q.instance.getResourceTexture(Gn);
            case S.BrandEventPortalKahootPirates:
              return q.instance.getResourceTexture(Fn);
            case S.BrandEventPortalTourDeFrance:
              return q.instance.getResourceTexture(vn);
            default:
              return this._itemRef.config.type, U.EMPTY;
          }
        }
        addColorOverlayToItem(e) {
          let t = new Ra(16777215, 0);
          return (
            (e.itemSpriteRef.filters = [...(e.itemSpriteRef.filters ?? []), t]),
            t
          );
        }
        removeColorOverlayFromItem(e, t) {
          (e.itemSpriteRef.filters =
            e.itemSpriteRef.filters?.filter((e) => e !== t) ?? null),
            e.itemSpriteRef.filters?.length === 0 &&
              (e.itemSpriteRef.filters = null);
        }
        waitForMilliseconds(e) {
          return new Promise((t) =>
            this._timeOutIds.push(window.setTimeout(t, e))
          );
        }
        getRandomPosInItem() {
          let e = { x: this._itemRef.x, y: this._itemRef.y },
            t = Math.min(this._itemRef.width, this._itemRef.height) / 8;
          return {
            x: e.x + (Math.random() * 2 - 1) * t,
            y: e.y + (Math.random() * 2 - 1) * t,
          };
        }
        animateBackdropIn() {
          return (
            (this._backdrop = new B(U.WHITE)),
            (this._backdrop.tint = 0),
            (this._backdrop.alpha = 0),
            (this._backdrop.width = this._viewport.width),
            (this._backdrop.height = this._viewport.height),
            (this._backdrop.x = this._viewport.x),
            (this._backdrop.y = this._viewport.y),
            this._container.addChildAt(this._backdrop, 0),
            new Promise((e) => {
              this._backdropTween?.destroy(),
                (this._backdropTween = O({
                  from: { value: 0 },
                  to: { value: 0.3 },
                  duration: 300,
                  onTick: ({ value: e }) => {
                    this._backdrop && (this._backdrop.alpha = e);
                  },
                  onFinish: () => e(),
                })),
                this._backdropTween.play();
            })
          );
        }
        animateBackdropOut() {
          return new Promise((e) => {
            this._backdropTween?.destroy(),
              (this._backdropTween = O({
                from: { value: this._backdrop?.alpha ?? 0 },
                to: { value: 0 },
                duration: 500,
                onTick: ({ value: e }) => {
                  this._backdrop && (this._backdrop.alpha = e);
                },
                onFinish: () => e(),
              })),
              this._backdropTween.play();
          });
        }
        animatePointSprite(e) {
          let t = { x: this._centerRef.x, y: this._centerRef.y },
            n = this.getRandomPosInItem(),
            r = new B(this._pointTexture);
          (r.visible = !1),
            r.anchor.set(0.5),
            r.position.set(t.x, t.y),
            r.scale.set(0),
            this._container.addChild(r);
          let i = new qa({
            initialPosition: { x: t.x, y: t.y },
            historySize: 30,
            pointsSize: 10,
            texture: this._trailTexture ?? U.EMPTY,
          });
          (i.blendMode = Nr.ADD),
            (i.visible = !1),
            this._container.addChildAt(i, 0),
            this._trails.push(i);
          let a = 1.5,
            o = Math.random() < 0.5 ? 1 : -1,
            s = 100 + Math.random() * 200,
            c = 1e3 + Math.random() * 250,
            l = 1e3 + e * 150 + Math.random() * 50;
          return new Promise((e) => {
            let u = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: c,
              delay: l,
              easing: E.EASE_IN_OUT_CUBIC,
              onTick: ({ value: e }) => {
                if (
                  (e > 0 && (r.visible = !0),
                  e > 0.1 && (i.visible = !0),
                  e <= 0.5)
                ) {
                  let t = (e / 0.5) * a;
                  r.scale.set(t);
                } else {
                  let t = a - ((e - 0.5) / 0.5) * 1;
                  r.scale.set(t);
                }
                let c = { x: (t.x + n.x) / 2, y: (t.y + n.y) / 2 + o * s },
                  l = 1 - e,
                  u = l * l * t.x + 2 * l * e * c.x + e * e * n.x,
                  d = l * l * t.y + 2 * l * e * c.y + e * e * n.y;
                r.position.set(u, d), i.update(u, d), (i.alpha = r.scale.y);
              },
              onFinish: () => {
                this.animateTargetItem(),
                  this.animateTargetItemBar(),
                  this.animateSparkles(n.x, n.y),
                  this._container.removeChild(r),
                  i.destroy(),
                  e();
              },
            });
            u.play(), this._pointTweens.push(u);
          });
        }
        animateTargetItem() {
          this._targetItemTween?.destroy(),
            (this._targetItemTween = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: 200,
              easing: E.EASE_OUT_BACK,
              onTick: ({ value: e }) => {
                if (e <= 0.8) {
                  let t = 1 + (e / 0.8) * 0.050000000000000044;
                  this._itemRef.itemSpriteRef.scale.set(t),
                    (this._targetItemFilter.alpha = w(0, 0.5, e / 0.8));
                } else {
                  let t = 1.05 - ((e - 0.8) / 0.2) * 0.050000000000000044;
                  this._itemRef.itemSpriteRef.scale.set(t),
                    (this._targetItemFilter.alpha = Math.max(
                      0,
                      w(0.5, 0, (e - 0.8) / 0.2)
                    ));
                }
              },
              onFinish: () => {
                this._itemRef.itemSpriteRef.scale.set(1);
              },
            })),
            this._targetItemTween.play();
        }
        animateTargetItemBar(e = !1) {
          if (this._currPoints <= 0) return;
          if (e) {
            this._itemRef.itemSpriteRef.levelBarRef?.update(
              this._currPoints,
              this._totalPoints
            );
            return;
          }
          this._completedPointAnimCount++;
          let t = Math.min(
            this._startPoints + this._completedPointAnimCount * this._incPoints,
            this._currPoints
          );
          this._itemRef.itemSpriteRef.levelBarRef?.update(t, this._totalPoints);
        }
        animateSparkles(e, t) {
          let n = new Y({
            textures: this._sparklesTextures,
            config: this._sparklesConfig,
            mode: `fixed`,
          });
          n.position.set(e, t),
            this._container.addChild(n),
            n.play(),
            this._sparkles.push(n);
        }
      });
  }))();
}
var $a;
function eo() {
  return (eo = t(() => {
    J(),
      j(),
      N(),
      G(),
      $(),
      _(),
      ($a = class extends H {
        constructor(e, t) {
          super(), (this.tweens = []), (this.eventMode = `none`);
          let n = T(`clouds`),
            r = q.instance.getResourceTexture(Pe),
            i = q.instance.getResourceTexture(jt),
            a = q.instance.getResourceTexture(Dt),
            o = e > t ? 0.8 : 0.4,
            s = 3500,
            c = 5500,
            l = 5500,
            u = E.EASE_IN_OUT_SINE;
          if (r === void 0 || i === void 0 || a === void 0) return;
          let d = e > t ? e / r.width : t / r.height,
            f = e > t ? 1.3 : 0.8;
          (this.bigCloudTopLeft = new B(r)),
            this.bigCloudTopLeft.anchor.set(0.5),
            (this.bigCloudTopLeft.x = 0),
            (this.bigCloudTopLeft.y = t * 0.25),
            this.bigCloudTopLeft.scale.set(d * f * 1.5 * -1),
            (this.bigCloudTopLeft.name = `cloudTopLeft`),
            n !== void 0 && (this.bigCloudTopLeft.tint = n),
            (this.bigCloudTopRight = new B(r)),
            this.bigCloudTopRight.anchor.set(0.5),
            (this.bigCloudTopRight.x = e),
            (this.bigCloudTopRight.y = t * 0.25),
            this.bigCloudTopRight.scale.set(d * f * 1.5),
            (this.bigCloudTopRight.name = `cloudTopRight`),
            n !== void 0 && (this.bigCloudTopRight.tint = n),
            (this.bigCloudBottomLeft = new B(r)),
            this.bigCloudBottomLeft.anchor.set(0.5),
            (this.bigCloudBottomLeft.x = 0),
            (this.bigCloudBottomLeft.y = t * 0.75),
            this.bigCloudBottomLeft.scale.set(d * f),
            (this.bigCloudBottomLeft.name = `cloudBottomLeft`),
            n !== void 0 && (this.bigCloudBottomLeft.tint = n),
            (this.bigCloudBottomRight = new B(r)),
            this.bigCloudBottomRight.anchor.set(0.5),
            (this.bigCloudBottomRight.x = e),
            (this.bigCloudBottomRight.y = t * 0.95),
            this.bigCloudBottomRight.scale.set(d * f * -1),
            (this.bigCloudBottomRight.name = `cloudBottomRight`),
            n !== void 0 && (this.bigCloudBottomRight.tint = n),
            (this.smallCloudLeft = new B(i)),
            this.smallCloudLeft.anchor.set(0.5),
            (this.smallCloudLeft.x = e * 0.35),
            (this.smallCloudLeft.y = t * 0.6),
            this.smallCloudLeft.scale.set(d * o),
            (this.smallCloudLeft.name = `smalleCloudLeft`),
            (this.smallCloudLeft.alpha = 0.7),
            n !== void 0 && (this.smallCloudLeft.tint = n),
            (this.smallCloudRight = new B(a)),
            this.smallCloudRight.anchor.set(0.5),
            (this.smallCloudRight.x = e * 0.65),
            (this.smallCloudRight.y = t * 0.25),
            this.smallCloudRight.scale.set(d * o),
            (this.smallCloudRight.name = `smallCloudRight`),
            (this.smallCloudRight.alpha = 0.7),
            n !== void 0 && (this.smallCloudRight.tint = n),
            this.addChild(this.smallCloudLeft),
            this.addChild(this.smallCloudRight),
            this.addChild(this.bigCloudTopLeft),
            e > t && this.addChild(this.bigCloudTopRight),
            e > t && this.addChild(this.bigCloudBottomLeft),
            this.addChild(this.bigCloudBottomRight);
          let p = O({
            from: { x: this.bigCloudTopLeft.x, alpha: 1 },
            to: { x: -this.bigCloudTopLeft.width, alpha: 0 },
            easing: u,
            duration: s,
            onTick: ({ x: e, alpha: t }) => {
              this.bigCloudTopLeft &&
                ((this.bigCloudTopLeft.position.x = e),
                (this.bigCloudTopLeft.alpha = t));
            },
            onFinish: () => {
              this.bigCloudTopLeft?.destroy(), this.checkDestroySelf();
            },
          });
          p.play(),
            this.tweens.push(p),
            (p = O({
              from: { x: this.bigCloudTopRight.x, alpha: 1 },
              to: { x: this.bigCloudTopRight.width * 1.4, alpha: 0 },
              easing: u,
              duration: s,
              onTick: ({ x: e, alpha: t }) => {
                this.bigCloudTopRight &&
                  ((this.bigCloudTopRight.position.x = e),
                  (this.bigCloudTopRight.alpha = t));
              },
              onFinish: () => {
                this.bigCloudTopRight?.destroy(), this.checkDestroySelf();
              },
            })),
            p.play(),
            this.tweens.push(p),
            (p = O({
              from: { x: this.bigCloudBottomLeft.x, alpha: 1 },
              to: { x: -this.bigCloudBottomLeft.width, alpha: 0 },
              easing: u,
              duration: c,
              onTick: ({ x: e, alpha: t }) => {
                this.bigCloudBottomLeft &&
                  ((this.bigCloudBottomLeft.position.x = e),
                  (this.bigCloudBottomLeft.alpha = t));
              },
              onFinish: () => {
                this.bigCloudBottomLeft?.destroy(), this.checkDestroySelf();
              },
            })),
            p.play(),
            this.tweens.push(p),
            (p = O({
              from: { x: this.bigCloudBottomRight.x, alpha: 1 },
              to: { x: e + this.bigCloudBottomRight.width, alpha: 0 },
              easing: u,
              duration: c,
              onTick: ({ x: e, alpha: t }) => {
                this.bigCloudBottomRight &&
                  ((this.bigCloudBottomRight.position.x = e),
                  (this.bigCloudBottomRight.alpha = t));
              },
              onFinish: () => {
                this.bigCloudBottomRight?.destroy(), this.checkDestroySelf();
              },
            })),
            p.play(),
            this.tweens.push(p),
            (p = O({
              from: {
                x: this.smallCloudLeft.x,
                alpha: this.smallCloudLeft.alpha,
              },
              to: { x: -this.smallCloudLeft.width, alpha: 0 },
              delay: 300,
              easing: u,
              duration: l,
              onTick: ({ x: e, alpha: t }) => {
                this.smallCloudLeft &&
                  ((this.smallCloudLeft.position.x = e),
                  (this.smallCloudLeft.alpha = t));
              },
              onFinish: () => {
                this.smallCloudLeft?.destroy(), this.checkDestroySelf();
              },
            })),
            p.play(),
            this.tweens.push(p),
            (p = O({
              from: {
                x: this.smallCloudRight.x,
                alpha: this.smallCloudRight.alpha,
              },
              to: { x: e + this.smallCloudRight.width, alpha: 0 },
              delay: 300,
              easing: u,
              duration: l,
              onTick: ({ x: e, alpha: t }) => {
                this.smallCloudRight &&
                  ((this.smallCloudRight.position.x = e),
                  (this.smallCloudRight.alpha = t));
              },
              onFinish: () => {
                this.smallCloudRight?.destroy(), this.checkDestroySelf();
              },
            })),
            p.play(),
            this.tweens.push(p);
        }
        checkDestroySelf() {
          this.tweens.every((e) => e.isFinished) && this.destroy();
        }
        destroy(e) {
          this.tweens.forEach((e) => e.destroy()), super.destroy(e);
        }
      });
  }))();
}
var to;
function no() {
  return (no = t(() => {
    J(),
      ue(),
      j(),
      N(),
      G(),
      L(),
      $(),
      (to = class extends H {
        static {
          this.willHaveContent = () =>
            q.instance.hasResource(`corner_decoration_top_left`) ||
            q.instance.hasResource(`corner_decoration_top_right`);
        }
        constructor(e, t = !0) {
          super(), (this.name = `CornerDecoration`);
          let n = q.instance.getResourceTexture(fr, !1),
            r = q.instance.getResourceTexture(Tr, !1);
          (!n && !r) ||
            (n &&
              ((this.spriteTopLeft = new B(n)),
              (this.spriteTopLeft.name = `CornerDecorationTopLeft`),
              this.addChild(this.spriteTopLeft)),
            r &&
              ((this.spriteTopRight = new B(r)),
              (this.spriteTopRight.name = `CornerDecorationTopRight`),
              this.spriteTopRight.anchor.set(1, 0),
              (this.spriteTopRight.x = e),
              this.addChild(this.spriteTopRight)),
            this.updateScale(),
            this.updateVisibility(),
            t && ((this.alpha = 0), this.fadeIn()));
        }
        updateScale() {
          this.spriteTopRight &&
            ((this.spriteTopRight.width = this.width * 0.23),
            (this.spriteTopRight.height =
              this.spriteTopRight.texture.height *
              (this.spriteTopRight.width / this.spriteTopRight.texture.width))),
            this.spriteTopLeft &&
              ((this.spriteTopLeft.width = this.width * 0.23),
              (this.spriteTopLeft.height =
                this.spriteTopLeft.texture.height *
                (this.spriteTopLeft.width / this.spriteTopLeft.texture.width)));
        }
        updateVisibility() {
          this.spriteTopRight && (this.spriteTopRight.visible = _r()),
            this.spriteTopLeft && (this.spriteTopLeft.visible = _r());
        }
        resize(e) {
          this.spriteTopRight && (this.spriteTopRight.x = e),
            this.updateScale(),
            this.updateVisibility();
        }
        fadeIn() {
          this.alphaTween?.destroy(),
            (this.alphaTween = O({
              delay: 400,
              from: { alpha: this.alpha },
              to: { alpha: 1 },
              duration: 700,
              easing: E.EASE_OUT_QUAD,
              onTick: ({ alpha: e }) => {
                this.alpha = e;
              },
              onFinish: () => {
                this.alphaTween?.destroy(), (this.alphaTween = void 0);
              },
            })),
            this.alphaTween.play();
        }
        fadeOut() {
          this.alphaTween?.destroy(),
            (this.alphaTween = O({
              from: { alpha: this.alpha },
              to: { alpha: 0 },
              duration: 500,
              onTick: ({ alpha: e }) => {
                this.alpha = e;
              },
              onFinish: () => {
                this.alphaTween?.destroy(), (this.alphaTween = void 0);
              },
            })),
            this.alphaTween.play();
        }
        destroy(e) {
          this.alphaTween?.destroy(), super.destroy(e);
        }
      });
  }))();
}
var ro, io, ao, oo, so;
function co() {
  return (co = t(() => {
    J(),
      W(),
      G(),
      $(),
      (ro = `default`),
      (io = `01 IDLE`),
      (ao = `02 SHAKE`),
      (oo = `03 OPEN`),
      (so = class extends H {
        playIdleAnimation() {
          this._spine?.state.setAnimation(0, io, !0);
        }
        playOpeningAnimation() {
          this._spine?.state.setAnimation(0, ao, !0);
        }
        playOpenAnimation() {
          this._spine?.state.setAnimation(0, oo, !1);
        }
        constructor({ tileCount: e, useAssignmentPresent: t = !1 }) {
          super();
          let n = q.instance.getResourceSpine(t ? pt : He);
          n &&
            ((this._spine = new K(n.spineData)),
            this._spine.scale.set(e),
            this._spine.skeleton.setSkinByName(ro),
            (this._spine.state.data.defaultMix = 0.2),
            this._spine.state.setAnimation(0, io, !0),
            this.addChild(this._spine));
        }
      });
  }))();
}
var lo;
function uo() {
  return (uo = t(() => {
    J(),
      D(),
      L(),
      G(),
      cr(),
      $(),
      _(),
      co(),
      (lo = class {
        constructor(e) {
          (this._sounds = []),
            (this._drumrollSoundInitialVolume = 1),
            (this._timeoutId = -1),
            (this._itemRef = e);
        }
        destroy() {
          clearTimeout(this._timeoutId),
            this._gift?.destroy(),
            this._drumrollSound &&
              (this._drumrollSound.volume = this._drumrollSoundInitialVolume),
            this._sounds.forEach((e) => e.stop()),
            (this._sounds = []);
        }
        get itemRef() {
          return this._itemRef;
        }
        get gift() {
          return this._gift;
        }
        get timeoutId() {
          return this._timeoutId;
        }
        set timeoutId(e) {
          this._timeoutId = e;
        }
        get _config() {
          return this._itemRef.config;
        }
        get _itemGridSize() {
          return Bn(this._config.type);
        }
        get _itemSize() {
          return A(this._config.type);
        }
        playAndTrackSound(e, t = 1) {
          let n = q.instance.getResourceSound(e);
          if (n)
            return (
              n.playing && n.stop(),
              (n.rate = t),
              n.play(),
              this._sounds.push(n),
              n
            );
        }
        getTextStyle() {
          return new Vr({
            fontFamily: `Grandstander`,
            align: `center`,
            dropShadow: !0,
            dropShadowAlpha: 0.5,
            dropShadowDistance: 0,
            dropShadowAngle: 90,
            dropShadowBlur: 3,
            fontWeight: `700`,
            fill: `white`,
          });
        }
        animateGift() {
          return new Promise((e) => {
            if (!this._gift) {
              e();
              return;
            }
            this._gift?.playOpeningAnimation(),
              (this._drumrollSound = this.playAndTrackSound(Ce)),
              (this._drumrollSoundInitialVolume =
                this._drumrollSound?.volume ?? 1),
              (this._timeoutId = window.setTimeout(() => {
                this._gift?.playOpenAnimation(),
                  this._drumrollSound?.fade(this._drumrollSound.volume, 0, 500);
                let t = z(je);
                t && this.playAndTrackSound(t), e();
              }, At));
          });
        }
        setupGift(e = !1) {
          (this._gift = new so({
            tileCount: Math.min(...this._itemGridSize),
            useAssignmentPresent: e,
          })),
            this._gift.playIdleAnimation(),
            this._itemRef.addChild(this._gift);
        }
      });
  }))();
}
var fo, po;
function mo() {
  return (mo = t(() => {
    uo(),
      N(),
      L(),
      Z(),
      (fo = 2e3),
      (po = class extends lo {
        prepare() {
          this.setupGift(), this.itemRef.itemSpriteRef.prepareAnimateAppear();
        }
        async animate(e, t) {
          await this.animateGift(),
            await new Promise((e) => {
              (this._kahootTitleText = new X(
                this._config.data.kahootName,
                this.getTextStyle()
              )),
                (this._kahootTitleText.style.fontSize = 20),
                (this._kahootTitleText.style.wordWrap = !0),
                (this._kahootTitleText.style.wordWrapWidth = 600),
                (this._kahootTitleText.style.lineHeight = 24),
                (this._kahootTitleText.resolution = 3),
                this._kahootTitleText.anchor.set(0.5, 1),
                (this._kahootTitleText.x = 0),
                (this._kahootTitleText.y = -(this._itemSize[1] / 2) - 15),
                (this._kahootTitleText.name = `kahootName`),
                this.itemRef.addChild(this._kahootTitleText),
                (this._kahootTitleTextTween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: 250,
                  onTick: ({ value: e }) => {
                    this._kahootTitleText && (this._kahootTitleText.alpha = e);
                  },
                  onFinish: e,
                })),
                this._kahootTitleTextTween.play();
            }),
            this.itemRef.itemSpriteRef.animateAppear(e),
            (() => {
              let e = !this.itemRef.islandConfig.persistAssignmentTitle;
              (this._kahootTitleTextTween = O({
                from: { value: 1 },
                to: { value: 0 },
                delay: fo,
                duration: 250,
                onTick: e
                  ? ({ value: e }) => {
                      this._kahootTitleText &&
                        (this._kahootTitleText.alpha = e);
                    }
                  : void 0,
                onFinish: t,
              })),
                this._kahootTitleTextTween.play();
            })();
        }
        destroy() {
          super.destroy(),
            this._kahootTitleTextTween?.destroy(),
            (this._kahootTitleTextTween = void 0);
        }
      });
  }))();
}
var ho, go, _o, vo, yo, bo;
function xo() {
  return (xo = t(() => {
    N(),
      L(),
      $(),
      _(),
      Z(),
      fa(),
      (ho = -5),
      (go = -35),
      (_o = 10),
      (vo = 10),
      (yo = 4325306),
      (bo = class extends da {
        get count() {
          return this._count;
        }
        get total() {
          return this._total;
        }
        set visibility(e) {
          switch ((this._tweenBarVisibility?.stop(), e)) {
            case `hidden`:
              this.barContainer.alpha = 0;
              break;
            case `visible`:
              this.barContainer.alpha = 1;
          }
        }
        animateVisibility(e) {
          this._tweenBarVisibility?.stop();
          let t = (e) => {
            let t = +!!e;
            return O({
              from: { value: this.barContainer.alpha },
              to: { value: t },
              delay: e ? 200 : 0,
              duration: 500,
              onTick: ({ value: e }) => {
                this.barContainer.alpha = e;
              },
            });
          };
          switch (e) {
            case `hidden`:
              this._tweenBarVisibility = t(!1);
              break;
            case `visible`:
              this._tweenBarVisibility = t(!0);
          }
          this._tweenBarVisibility?.play();
        }
        constructor(e) {
          let { count: t = 0, total: n = 0, color: r = yo, isRtl: i } = e,
            a = 256 + _o;
          super({
            isRtl: i,
            barWidth: a,
            barHeight: 40,
            progressFillOffset: vo,
          }),
            (this._count = 0),
            (this._total = 0),
            (this.barContainer.y = go),
            (this.barContainer.x = -128 + ho),
            (this._currentLevelText = this.createCurrentLevelText()),
            this._currentLevelText.anchor.set(0.5, 0.5),
            (this._currentLevelText.x = this.barContainer.width / 2),
            (this._currentLevelText.y = 40 / 2),
            this.barContainer.addChild(this._currentLevelText),
            (this.progressSprite.tint = r),
            this.update(t, n);
        }
        update(e, t) {
          let n = Math.max(0, Math.min(e, t)),
            r = Math.max(0, t);
          if (((this._count = n), (this._total = r), r <= 0)) {
            this.visible = !1;
            return;
          }
          (this.visible = !0),
            (this.progress = n / r),
            (this._currentLevelText.text = (
              wn(`countOfTotal`) ?? `{count}/{total}`
            )
              .replace(`{count}`, n.toString())
              .replace(`{total}`, r.toString()));
        }
        destroy(e) {
          this._tweenBarVisibility?.destroy(), super.destroy(e);
        }
        createCurrentLevelText() {
          let e = new X();
          return (
            (e.style = {
              fontFamily: `Grandstander`,
              fontSize: 20,
              fontWeight: `700`,
              fill: `white`,
              dropShadow: !0,
              dropShadowColor: `black`,
              dropShadowDistance: 0,
              dropShadowAngle: 90,
              dropShadowAlpha: 1,
              dropShadowBlur: 3,
            }),
            (e.resolution = 2),
            e
          );
        }
      });
  }))();
}
var So, Co, wo, To;
function Eo() {
  return (Eo = t(() => {
    J(),
      xo(),
      Ea(),
      (So = `IDLE`),
      (Co = `IDLE LOCKED DOWN`),
      (wo = `IDLE BRIGHT`),
      (To = class extends Ta {
        get levelBarRef() {
          return this._progressBar;
        }
        forceUpdateData(e) {
          e.currPoints !== void 0 &&
            e.totalPoints !== void 0 &&
            ((this.config.data.points = e.currPoints),
            (this.config.data.total = e.totalPoints),
            this._progressBar?.update(e.currPoints, e.totalPoints)),
            (this.config.data.locked = e.locked),
            e.locked ? this.setLockedAnimation() : this.setIdleAnimation();
        }
        initialize(e) {
          super.initialize(e),
            this.setIdleAnimation(),
            this.addProgressBar(e),
            this.config.data.locked && this.setLockedAnimation();
        }
        destroy(e) {
          super.destroy(e), this._desaturateFilter?.destroy();
        }
        get isCompleted() {
          let e = this.config.data.points,
            t = this.config.data.total;
          return e !== void 0 && t !== void 0 && e >= t;
        }
        addProgressBar(e) {
          this.config.data.live &&
            ((this._progressBar = new bo({
              count: this.config.data.points,
              total: this.config.data.total,
              isRtl: this.islandConfig.isRtl,
            })),
            (this._progressBar.y = -this.height / 2),
            e.addChild(this._progressBar));
        }
        setIdleAnimation() {
          if (
            (this._progressBar && (this._progressBar.visible = !0),
            !this._spine)
          )
            return;
          let e = this.isCompleted ? wo : So;
          this._spine.state.setAnimation(0, e, !0), this.setLockedFilter(!1);
        }
        setLockedAnimation() {
          this._progressBar && (this._progressBar.visible = !1),
            this._spine &&
              (this._spine.state.setAnimation(0, Co, !0),
              this._desaturateFilter ||
                ((this._desaturateFilter = new Wr()),
                this._desaturateFilter.desaturate()),
              this.setLockedFilter(!0));
        }
        setLockedFilter(e) {
          if (!(!this._spine || !this._desaturateFilter)) {
            if (!e) {
              this._spine.filters =
                this._spine.filters?.filter(
                  (e) => e !== this._desaturateFilter
                ) ?? [];
              return;
            }
            this._spine.filters?.includes(this._desaturateFilter) ||
              (this._spine.filters = [
                ...(this._spine.filters ?? []),
                this._desaturateFilter,
              ]);
          }
        }
      });
  }))();
}
var Do, Oo, ko, Ao, jo, Mo, No, Po, Fo;
function Io() {
  return (Io = t(() => {
    J(),
      W(),
      G(),
      N(),
      $(),
      (Do = -30),
      (Oo = 10),
      (ko = `AAA IDLE`),
      (Ao = `BBB GO TO MAILBAG`),
      (jo = `BBB MAILBAG IDLE`),
      (Mo = `CCC GIFTFOUND`),
      (No = `DDD GIFTIDLE`),
      (Po = 4e3),
      (Fo = class extends H {
        constructor() {
          super(), (this._asyncRewardsCount = 0), (this._timeoutId = -1);
          let e = q.instance.getResourceSpine(ji);
          e &&
            ((this._koala = new K(e.spineData)),
            (this._koala.stateData.defaultMix = 0.2),
            this.addChild(this._koala),
            this.setIdleAnimation());
        }
        fadeIn() {
          this._koala &&
            ((this._koala.alpha = 0),
            (this._tween = O({
              from: { alpha: 0 },
              to: { alpha: 1 },
              duration: 500,
              onTick: ({ alpha: e }) => {
                this._koala && (this._koala.alpha = e);
              },
            })),
            this._tween.play());
        }
        setPendingAsyncRewardsCount(e) {
          this._koala &&
            ((this._asyncRewardsCount = e),
            this.setLoadingAnimation(),
            clearTimeout(this._timeoutId),
            (this._timeoutId = window.setTimeout(
              () => this.setCompletedAnimation(),
              Po
            )));
        }
        destroy(e) {
          clearTimeout(this._timeoutId),
            this._tween?.destroy(),
            super.destroy(e);
        }
        setIdleAnimation() {
          this._koala &&
            (this._koala.position.set(Do, Oo),
            this._koala.state.setAnimation(0, ko, !0));
        }
        setLoadingAnimation() {
          this._koala &&
            (this._koala.state.setAnimation(0, Ao),
            this._koala.state.addAnimation(0, jo, !0));
        }
        setCompletedAnimation() {
          if (this._koala) {
            if (this._asyncRewardsCount <= 0) {
              this.setIdleAnimation();
              return;
            }
            this._koala.state.setAnimation(0, Mo),
              this._koala.state.addAnimation(0, No, !0);
          }
        }
      });
  }))();
}
var Lo, Ro, zo, Bo, Vo, Ho, Uo, Wo, Go;
function Ko() {
  return (Ko = t(() => {
    J(),
      kt(),
      G(),
      $(),
      (Lo = [-32, -96]),
      (Ro = [-2, -77]),
      (zo = [-116, -65]),
      (Bo = [-63, -58]),
      (Vo = [64, -60]),
      (Ho = [62, -50]),
      (Uo = [-140, -15]),
      (Wo = [140, -15]),
      (Go = class extends B {
        get goldBadge() {
          return this._goldBadge;
        }
        get silverBadge() {
          return this._silverBadge;
        }
        get bronzeBadge() {
          return this._bronzeBadge;
        }
        getCharacterOffsetByRank(e) {
          switch (e) {
            case 0:
              return Ro;
            case 1:
              return Bo;
            case 2:
              return Ho;
            case 3:
              return Uo;
            case 4:
              return Wo;
            default:
              return [0, 0];
          }
        }
        constructor() {
          super(q.instance.getResourceTexture(rn)),
            this.scale.set(0.75),
            this.anchor.set(0.5, 1),
            (this.name = `classic-podium`),
            (this._goldBadge = new B(q.instance.getResourceTexture(it))),
            this._goldBadge.position.set(...Lo),
            (this._goldBadge.name = `classic-podium-gold-badge`),
            this.addChild(this._goldBadge),
            (this._silverBadge = new B(q.instance.getResourceTexture(g))),
            this._silverBadge.position.set(...zo),
            (this._silverBadge.name = `classic-podium-silver-badge`),
            this.addChild(this._silverBadge),
            (this._bronzeBadge = new B(q.instance.getResourceTexture(Pt))),
            this._bronzeBadge.position.set(...Vo),
            (this._bronzeBadge.name = `classic-podium-bronze-badge`),
            this.addChild(this._bronzeBadge);
        }
      });
  }))();
}
function qo(e) {
  var t,
    n = [],
    r = 1,
    i;
  if (typeof e == `string`)
    if (fs[e]) (n = fs[e].slice()), (i = `rgb`);
    else if (e === `transparent`) (r = 0), (i = `rgb`), (n = [0, 0, 0]);
    else if (/^#[A-Fa-f0-9]+$/.test(e)) {
      var a = e.slice(1),
        o = a.length,
        s = o <= 4;
      (r = 1),
        s
          ? ((n = [
              parseInt(a[0] + a[0], 16),
              parseInt(a[1] + a[1], 16),
              parseInt(a[2] + a[2], 16),
            ]),
            o === 4 && (r = parseInt(a[3] + a[3], 16) / 255))
          : ((n = [
              parseInt(a[0] + a[1], 16),
              parseInt(a[2] + a[3], 16),
              parseInt(a[4] + a[5], 16),
            ]),
            o === 8 && (r = parseInt(a[6] + a[7], 16) / 255)),
        n[0] || (n[0] = 0),
        n[1] || (n[1] = 0),
        n[2] || (n[2] = 0),
        (i = `rgb`);
    } else if (
      (t =
        /^((?:rgb|hs[lvb]|hwb|cmyk?|xy[zy]|gray|lab|lchu?v?|[ly]uv|lms)a?)\s*\(([^\)]*)\)/.exec(
          e
        ))
    ) {
      var c = t[1],
        l = c === `rgb`,
        a = c.replace(/a$/, ``);
      i = a;
      var o = a === `cmyk` ? 4 : a === `gray` ? 1 : 3;
      (n = t[2]
        .trim()
        .split(/\s*[,\/]\s*|\s+/)
        .map(function (e, t) {
          if (/%$/.test(e))
            return t === o
              ? parseFloat(e) / 100
              : a === `rgb`
              ? (parseFloat(e) * 255) / 100
              : parseFloat(e);
          if (a[t] === `h`) {
            if (/deg$/.test(e)) return parseFloat(e);
            if (ps[e] !== void 0) return ps[e];
          }
          return parseFloat(e);
        })),
        c === a && n.push(1),
        (r = l || n[o] === void 0 ? 1 : n[o]),
        (n = n.slice(0, o));
    } else
      e.length > 10 &&
        /[0-9](?:\s|\/)/.test(e) &&
        ((n = e.match(/([0-9]+)/g).map(function (e) {
          return parseFloat(e);
        })),
        (i = e
          .match(/([a-z])/gi)
          .join(``)
          .toLowerCase()));
  else
    isNaN(e)
      ? Array.isArray(e) || e.length
        ? ((n = [e[0], e[1], e[2]]),
          (i = `rgb`),
          (r = e.length === 4 ? e[3] : 1))
        : e instanceof Object &&
          (e.r != null || e.red != null || e.R != null
            ? ((i = `rgb`),
              (n = [
                e.r || e.red || e.R || 0,
                e.g || e.green || e.G || 0,
                e.b || e.blue || e.B || 0,
              ]))
            : ((i = `hsl`),
              (n = [
                e.h || e.hue || e.H || 0,
                e.s || e.saturation || e.S || 0,
                e.l || e.lightness || e.L || e.b || e.brightness,
              ])),
          (r = e.a || e.alpha || e.opacity || 1),
          e.opacity != null && (r /= 100))
      : ((i = `rgb`), (n = [e >>> 16, (e & 65280) >>> 8, e & 255]));
  return { space: i, values: n, alpha: r };
}
function Jo(e) {
  Array.isArray(e) && e.raw && (e = String.raw(...arguments));
  var t,
    n = qo(e);
  if (!n.space) return [];
  let r = n.space[0] === `h` ? hs.min : ms.min,
    i = n.space[0] === `h` ? hs.max : ms.max;
  return (
    (t = [, , ,]),
    (t[0] = Math.min(Math.max(n.values[0], r[0]), i[0])),
    (t[1] = Math.min(Math.max(n.values[1], r[1]), i[1])),
    (t[2] = Math.min(Math.max(n.values[2], r[2]), i[2])),
    n.space[0] === `h` && (t = hs.rgb(t)),
    t.push(Math.min(Math.max(n.alpha, 0), 1)),
    t
  );
}
function Yo(e) {
  switch (typeof e) {
    case `string`:
      return Xo(e);
    case `number`:
      return Br(e);
    default:
      return e;
  }
}
function Xo(e) {
  let t = Jo(e);
  if (!t) throw Error(`Unable to parse color "${e}" as RGBA.`);
  return [t[0] / 255, t[1] / 255, t[2] / 255, t[3]];
}
function Zo(e) {
  let t = ds(os(e));
  if (t.length === 0) throw Error(`Invalid CSS gradient.`);
  if (t.length !== 1)
    throw Error(
      `Unsupported CSS gradient (multiple gradients is not supported).`
    );
  let n = t[0];
  return {
    type: Qo(n.type),
    stops: $o(n.colorStops),
    angle: is(n.orientation),
  };
}
function Qo(e) {
  let t = { "linear-gradient": 0, "radial-gradient": 1 };
  if (!(e in t)) throw Error(`Unsupported gradient type "${e}"`);
  return t[e];
}
function $o(e) {
  let t = ns(e),
    n = [];
  for (let r = 0; r < e.length; r++) {
    let i = es(e[r]);
    n.push({ offset: t[r], color: i.slice(0, 3), alpha: i[3] });
  }
  return n;
}
function es(e) {
  return Yo(ts(e));
}
function ts(e) {
  switch (e.type) {
    case `hex`:
      return `#${e.value}`;
    case `literal`:
      return e.value;
    default:
      return `${e.type}(${e.value.join(`,`)})`;
  }
}
function ns(e) {
  let t = [];
  for (let n = 0; n < e.length; n++) {
    let r = e[n],
      i = -1;
    r.type === `literal` &&
      r.length &&
      `type` in r.length &&
      r.length.type === `%` &&
      `value` in r.length &&
      (i = parseFloat(r.length.value) / 100),
      t.push(i);
  }
  let n = (e) => {
      for (let n = e; n < t.length; n++)
        if (t[n] !== -1) return { indexDelta: n - e, offset: t[n] };
      return { indexDelta: t.length - 1 - e, offset: 1 };
    },
    r = 0;
  for (let e = 0; e < t.length; e++) {
    let i = t[e];
    if (i !== -1) r = i;
    else if (e === 0) t[e] = 0;
    else if (e + 1 === t.length) t[e] = 1;
    else {
      let i = n(e),
        a = (i.offset - r) / (1 + i.indexDelta);
      for (let n = 0; n <= i.indexDelta; n++) t[e + n] = r + (n + 1) * a;
      (e += i.indexDelta), (r = t[e]);
    }
  }
  return t.map(rs);
}
function rs(e) {
  return e.toString().length > 6 ? parseFloat(e.toString().substring(0, 6)) : e;
}
function is(e) {
  if (e === void 0) return 0;
  if (`type` in e && `value` in e)
    switch (e.type) {
      case `angular`:
        return parseFloat(e.value);
      case `directional`:
        return as(e.value);
    }
  return 0;
}
function as(e) {
  let t = {
    left: 270,
    top: 0,
    bottom: 180,
    right: 90,
    "left top": 315,
    "top left": 315,
    "left bottom": 225,
    "bottom left": 225,
    "right top": 45,
    "top right": 45,
    "right bottom": 135,
    "bottom right": 135,
  };
  if (!(e in t)) throw Error(`Unsupported directional value "${e}"`);
  return t[e];
}
function os(e) {
  let t = e.replace(/\s{2,}/gu, ` `);
  return (
    (t = t.replace(/;/g, ``)),
    (t = t.replace(/ ,/g, `,`)),
    (t = t.replace(/\( /g, `(`)),
    (t = t.replace(/ \)/g, `)`)),
    t.trim()
  );
}
function ss(e) {
  return [...e].sort((e, t) => e.offset - t.offset);
}
var cs,
  ls,
  us,
  ds,
  fs,
  ps,
  ms,
  hs,
  gs,
  _s,
  vs,
  ys,
  bs,
  xs,
  Ss,
  Cs,
  ws,
  Ts,
  Es,
  Ds;
function Os() {
  return (Os = t(() => {
    Fr(),
      (cs = `const float PI = 3.1415926538;
const float PI_2 = PI*2.;

varying vec2 vTextureCoord;
varying vec2 vFilterCoord;
uniform sampler2D uSampler;

const int TYPE_LINEAR = 0;
const int TYPE_RADIAL = 1;
const int TYPE_CONIC = 2;
const int MAX_STOPS = 32;

uniform int uNumStops;
uniform float uAlphas[3*MAX_STOPS];
uniform vec3 uColors[MAX_STOPS];
uniform float uOffsets[MAX_STOPS];
uniform int uType;
uniform float uAngle;
uniform float uAlpha;
uniform int uMaxColors;
uniform bool uReplace;

struct ColorStop {
    float offset;
    vec3 color;
    float alpha;
};

mat2 rotate2d(float angle){
    return mat2(cos(angle), -sin(angle),
    sin(angle), cos(angle));
}

float projectLinearPosition(vec2 pos, float angle){
    vec2 center = vec2(0.5);
    vec2 result = pos - center;
    result = rotate2d(angle) * result;
    result = result + center;
    return clamp(result.x, 0., 1.);
}

float projectRadialPosition(vec2 pos) {
    float r = distance(vFilterCoord, vec2(0.5));
    return clamp(2.*r, 0., 1.);
}

float projectAnglePosition(vec2 pos, float angle) {
    vec2 center = pos - vec2(0.5);
    float polarAngle=atan(-center.y, center.x);
    return mod(polarAngle + angle, PI_2) / PI_2;
}

float projectPosition(vec2 pos, int type, float angle) {
    if (type == TYPE_LINEAR) {
        return projectLinearPosition(pos, angle);
    } else if (type == TYPE_RADIAL) {
        return projectRadialPosition(pos);
    } else if (type == TYPE_CONIC) {
        return projectAnglePosition(pos, angle);
    }

    return pos.y;
}

void main(void) {
    // current/original color
    vec4 currentColor = texture2D(uSampler, vTextureCoord);

    // skip calculations if gradient alpha is 0
    if (0.0 == uAlpha) {
        gl_FragColor = currentColor;
        return;
    }

    // project position
    float y = projectPosition(vFilterCoord, uType, radians(uAngle));

    // check gradient bounds
    float offsetMin = uOffsets[0];
    float offsetMax = 0.0;

    for (int i = 0; i < MAX_STOPS; i++) {
        if (i == uNumStops-1){ // last index
            offsetMax = uOffsets[i];
        }
    }

    if (y  < offsetMin || y > offsetMax) {
        gl_FragColor = currentColor;
        return;
    }

    // limit colors
    if (uMaxColors > 0) {
        float stepSize = 1./float(uMaxColors);
        float stepNumber = float(floor(y/stepSize));
        y = stepSize * (stepNumber + 0.5);// offset by 0.5 to use color from middle of segment
    }

    // find color stops
    ColorStop from;
    ColorStop to;

    for (int i = 0; i < MAX_STOPS; i++) {
        if (y >= uOffsets[i]) {
            from = ColorStop(uOffsets[i], uColors[i], uAlphas[i]);
            to = ColorStop(uOffsets[i+1], uColors[i+1], uAlphas[i+1]);
        }

        if (i == uNumStops-1){ // last index
            break;
        }
    }

    // mix colors from stops
    vec4 colorFrom = vec4(from.color * from.alpha, from.alpha);
    vec4 colorTo = vec4(to.color * to.alpha, to.alpha);

    float segmentHeight = to.offset - from.offset;
    float relativePos = y - from.offset;// position from 0 to [segmentHeight]
    float relativePercent = relativePos / segmentHeight;// position in percent between [from.offset] and [to.offset].

    float gradientAlpha = uAlpha * currentColor.a;
    vec4 gradientColor = mix(colorFrom, colorTo, relativePercent) * gradientAlpha;

    if (uReplace == false) {
        // mix resulting color with current color
        gl_FragColor = gradientColor + currentColor*(1.-gradientColor.a);
    } else {
        // replace with gradient color
        gl_FragColor = gradientColor;
    }
}
`),
      (ls = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;
uniform vec4 inputSize;
uniform vec4 outputFrame;

varying vec2 vTextureCoord;
varying vec2 vFilterCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
    vFilterCoord = vTextureCoord * inputSize.xy / outputFrame.zw;
}
`),
      (us ||= {}),
      (us.stringify = (function () {
        var e = {
          "visit_linear-gradient": function (t) {
            return e.visit_gradient(t);
          },
          "visit_repeating-linear-gradient": function (t) {
            return e.visit_gradient(t);
          },
          "visit_radial-gradient": function (t) {
            return e.visit_gradient(t);
          },
          "visit_repeating-radial-gradient": function (t) {
            return e.visit_gradient(t);
          },
          visit_gradient: function (t) {
            var n = e.visit(t.orientation);
            return (
              n && (n += `, `), t.type + `(` + n + e.visit(t.colorStops) + `)`
            );
          },
          visit_shape: function (t) {
            var n = t.value,
              r = e.visit(t.at),
              i = e.visit(t.style);
            return i && (n += ` ` + i), r && (n += ` at ` + r), n;
          },
          "visit_default-radial": function (t) {
            var n = ``,
              r = e.visit(t.at);
            return r && (n += r), n;
          },
          "visit_extent-keyword": function (t) {
            var n = t.value,
              r = e.visit(t.at);
            return r && (n += ` at ` + r), n;
          },
          "visit_position-keyword": function (e) {
            return e.value;
          },
          visit_position: function (t) {
            return e.visit(t.value.x) + ` ` + e.visit(t.value.y);
          },
          "visit_%": function (e) {
            return e.value + `%`;
          },
          visit_em: function (e) {
            return e.value + `em`;
          },
          visit_px: function (e) {
            return e.value + `px`;
          },
          visit_literal: function (t) {
            return e.visit_color(t.value, t);
          },
          visit_hex: function (t) {
            return e.visit_color(`#` + t.value, t);
          },
          visit_rgb: function (t) {
            return e.visit_color(`rgb(` + t.value.join(`, `) + `)`, t);
          },
          visit_rgba: function (t) {
            return e.visit_color(`rgba(` + t.value.join(`, `) + `)`, t);
          },
          visit_color: function (t, n) {
            var r = t,
              i = e.visit(n.length);
            return i && (r += ` ` + i), r;
          },
          visit_angular: function (e) {
            return e.value + `deg`;
          },
          visit_directional: function (e) {
            return `to ` + e.value;
          },
          visit_array: function (t) {
            var n = ``,
              r = t.length;
            return (
              t.forEach(function (t, i) {
                (n += e.visit(t)), i < r - 1 && (n += `, `);
              }),
              n
            );
          },
          visit: function (t) {
            if (!t) return ``;
            var n = ``;
            if (t instanceof Array) return e.visit_array(t, n);
            if (t.type) {
              var r = e[`visit_` + t.type];
              if (r) return r(t);
              throw Error(`Missing visitor visit_` + t.type);
            }
            throw Error(`Invalid node.`);
          },
        };
        return function (t) {
          return e.visit(t);
        };
      })()),
      (us ||= {}),
      (us.parse = (function () {
        var e = {
            linearGradient: /^(\-(webkit|o|ms|moz)\-)?(linear\-gradient)/i,
            repeatingLinearGradient:
              /^(\-(webkit|o|ms|moz)\-)?(repeating\-linear\-gradient)/i,
            radialGradient: /^(\-(webkit|o|ms|moz)\-)?(radial\-gradient)/i,
            repeatingRadialGradient:
              /^(\-(webkit|o|ms|moz)\-)?(repeating\-radial\-gradient)/i,
            sideOrCorner:
              /^to (left (top|bottom)|right (top|bottom)|left|right|top|bottom)/i,
            extentKeywords:
              /^(closest\-side|closest\-corner|farthest\-side|farthest\-corner|contain|cover)/,
            positionKeywords: /^(left|center|right|top|bottom)/i,
            pixelValue: /^(-?(([0-9]*\.[0-9]+)|([0-9]+\.?)))px/,
            percentageValue: /^(-?(([0-9]*\.[0-9]+)|([0-9]+\.?)))\%/,
            emValue: /^(-?(([0-9]*\.[0-9]+)|([0-9]+\.?)))em/,
            angleValue: /^(-?(([0-9]*\.[0-9]+)|([0-9]+\.?)))deg/,
            startCall: /^\(/,
            endCall: /^\)/,
            comma: /^,/,
            hexColor: /^\#([0-9a-fA-F]+)/,
            literalColor: /^([a-zA-Z]+)/,
            rgbColor: /^rgb/i,
            rgbaColor: /^rgba/i,
            number: /^(([0-9]*\.[0-9]+)|([0-9]+\.?))/,
          },
          t = ``;
        function n(e) {
          var n = Error(t + `: ` + e);
          throw ((n.source = t), n);
        }
        function r() {
          var e = i();
          return t.length > 0 && n(`Invalid input not EOF`), e;
        }
        function i() {
          return re(a);
        }
        function a() {
          return (
            o(`linear-gradient`, e.linearGradient, c) ||
            o(`repeating-linear-gradient`, e.repeatingLinearGradient, c) ||
            o(`radial-gradient`, e.radialGradient, d) ||
            o(`repeating-radial-gradient`, e.repeatingRadialGradient, d)
          );
        }
        function o(t, r, i) {
          return s(r, function (r) {
            var a = i();
            return (
              a && (x(e.comma) || n(`Missing comma before color stops`)),
              { type: t, orientation: a, colorStops: re(ie) }
            );
          });
        }
        function s(t, r) {
          var i = x(t);
          if (i) {
            x(e.startCall) || n(`Missing (`);
            var a = r(i);
            return x(e.endCall) || n(`Missing )`), a;
          }
        }
        function c() {
          return l() || u();
        }
        function l() {
          return b(`directional`, e.sideOrCorner, 1);
        }
        function u() {
          return b(`angular`, e.angleValue, 1);
        }
        function d() {
          var n,
            r = f(),
            i;
          return (
            r &&
              ((n = []),
              n.push(r),
              (i = t),
              x(e.comma) && ((r = f()), r ? n.push(r) : (t = i))),
            n
          );
        }
        function f() {
          var e = p() || m();
          if (e) e.at = h();
          else {
            var t = ee();
            if (t) {
              e = t;
              var n = h();
              n && (e.at = n);
            } else {
              var r = te();
              r && (e = { type: `default-radial`, at: r });
            }
          }
          return e;
        }
        function p() {
          var e = b(`shape`, /^(circle)/i, 0);
          return e && (e.style = y() || ee()), e;
        }
        function m() {
          var e = b(`shape`, /^(ellipse)/i, 0);
          return e && (e.style = ce() || ee()), e;
        }
        function ee() {
          return b(`extent-keyword`, e.extentKeywords, 1);
        }
        function h() {
          if (b(`position`, /^at/, 0)) {
            var e = te();
            return e || n(`Missing positioning value`), e;
          }
        }
        function te() {
          var e = ne();
          if (e.x || e.y) return { type: `position`, value: e };
        }
        function ne() {
          return { x: ce(), y: ce() };
        }
        function re(t) {
          var r = t(),
            i = [];
          if (r)
            for (i.push(r); x(e.comma); )
              (r = t()), r ? i.push(r) : n(`One extra comma`);
          return i;
        }
        function ie() {
          var e = g();
          return e || n(`Expected color definition`), (e.length = ce()), e;
        }
        function g() {
          return ae() || v() || oe() || _();
        }
        function _() {
          return b(`literal`, e.literalColor, 0);
        }
        function ae() {
          return b(`hex`, e.hexColor, 1);
        }
        function oe() {
          return s(e.rgbColor, function () {
            return { type: `rgb`, value: re(se) };
          });
        }
        function v() {
          return s(e.rgbaColor, function () {
            return { type: `rgba`, value: re(se) };
          });
        }
        function se() {
          return x(e.number)[1];
        }
        function ce() {
          return b(`%`, e.percentageValue, 1) || le() || y();
        }
        function le() {
          return b(`position-keyword`, e.positionKeywords, 1);
        }
        function y() {
          return b(`px`, e.pixelValue, 1) || b(`em`, e.emValue, 1);
        }
        function b(e, t, n) {
          var r = x(t);
          if (r) return { type: e, value: r[n] };
        }
        function x(e) {
          var n, r;
          return (
            (r = /^[\n\r\t\s]+/.exec(t)),
            r && ue(r[0].length),
            (n = e.exec(t)),
            n && ue(n[0].length),
            n
          );
        }
        function ue(e) {
          t = t.substr(e);
        }
        return function (e) {
          return (t = e.toString()), r();
        };
      })()),
      (ds = us.parse),
      us.stringify,
      (fs = {
        aliceblue: [240, 248, 255],
        antiquewhite: [250, 235, 215],
        aqua: [0, 255, 255],
        aquamarine: [127, 255, 212],
        azure: [240, 255, 255],
        beige: [245, 245, 220],
        bisque: [255, 228, 196],
        black: [0, 0, 0],
        blanchedalmond: [255, 235, 205],
        blue: [0, 0, 255],
        blueviolet: [138, 43, 226],
        brown: [165, 42, 42],
        burlywood: [222, 184, 135],
        cadetblue: [95, 158, 160],
        chartreuse: [127, 255, 0],
        chocolate: [210, 105, 30],
        coral: [255, 127, 80],
        cornflowerblue: [100, 149, 237],
        cornsilk: [255, 248, 220],
        crimson: [220, 20, 60],
        cyan: [0, 255, 255],
        darkblue: [0, 0, 139],
        darkcyan: [0, 139, 139],
        darkgoldenrod: [184, 134, 11],
        darkgray: [169, 169, 169],
        darkgreen: [0, 100, 0],
        darkgrey: [169, 169, 169],
        darkkhaki: [189, 183, 107],
        darkmagenta: [139, 0, 139],
        darkolivegreen: [85, 107, 47],
        darkorange: [255, 140, 0],
        darkorchid: [153, 50, 204],
        darkred: [139, 0, 0],
        darksalmon: [233, 150, 122],
        darkseagreen: [143, 188, 143],
        darkslateblue: [72, 61, 139],
        darkslategray: [47, 79, 79],
        darkslategrey: [47, 79, 79],
        darkturquoise: [0, 206, 209],
        darkviolet: [148, 0, 211],
        deeppink: [255, 20, 147],
        deepskyblue: [0, 191, 255],
        dimgray: [105, 105, 105],
        dimgrey: [105, 105, 105],
        dodgerblue: [30, 144, 255],
        firebrick: [178, 34, 34],
        floralwhite: [255, 250, 240],
        forestgreen: [34, 139, 34],
        fuchsia: [255, 0, 255],
        gainsboro: [220, 220, 220],
        ghostwhite: [248, 248, 255],
        gold: [255, 215, 0],
        goldenrod: [218, 165, 32],
        gray: [128, 128, 128],
        green: [0, 128, 0],
        greenyellow: [173, 255, 47],
        grey: [128, 128, 128],
        honeydew: [240, 255, 240],
        hotpink: [255, 105, 180],
        indianred: [205, 92, 92],
        indigo: [75, 0, 130],
        ivory: [255, 255, 240],
        khaki: [240, 230, 140],
        lavender: [230, 230, 250],
        lavenderblush: [255, 240, 245],
        lawngreen: [124, 252, 0],
        lemonchiffon: [255, 250, 205],
        lightblue: [173, 216, 230],
        lightcoral: [240, 128, 128],
        lightcyan: [224, 255, 255],
        lightgoldenrodyellow: [250, 250, 210],
        lightgray: [211, 211, 211],
        lightgreen: [144, 238, 144],
        lightgrey: [211, 211, 211],
        lightpink: [255, 182, 193],
        lightsalmon: [255, 160, 122],
        lightseagreen: [32, 178, 170],
        lightskyblue: [135, 206, 250],
        lightslategray: [119, 136, 153],
        lightslategrey: [119, 136, 153],
        lightsteelblue: [176, 196, 222],
        lightyellow: [255, 255, 224],
        lime: [0, 255, 0],
        limegreen: [50, 205, 50],
        linen: [250, 240, 230],
        magenta: [255, 0, 255],
        maroon: [128, 0, 0],
        mediumaquamarine: [102, 205, 170],
        mediumblue: [0, 0, 205],
        mediumorchid: [186, 85, 211],
        mediumpurple: [147, 112, 219],
        mediumseagreen: [60, 179, 113],
        mediumslateblue: [123, 104, 238],
        mediumspringgreen: [0, 250, 154],
        mediumturquoise: [72, 209, 204],
        mediumvioletred: [199, 21, 133],
        midnightblue: [25, 25, 112],
        mintcream: [245, 255, 250],
        mistyrose: [255, 228, 225],
        moccasin: [255, 228, 181],
        navajowhite: [255, 222, 173],
        navy: [0, 0, 128],
        oldlace: [253, 245, 230],
        olive: [128, 128, 0],
        olivedrab: [107, 142, 35],
        orange: [255, 165, 0],
        orangered: [255, 69, 0],
        orchid: [218, 112, 214],
        palegoldenrod: [238, 232, 170],
        palegreen: [152, 251, 152],
        paleturquoise: [175, 238, 238],
        palevioletred: [219, 112, 147],
        papayawhip: [255, 239, 213],
        peachpuff: [255, 218, 185],
        peru: [205, 133, 63],
        pink: [255, 192, 203],
        plum: [221, 160, 221],
        powderblue: [176, 224, 230],
        purple: [128, 0, 128],
        rebeccapurple: [102, 51, 153],
        red: [255, 0, 0],
        rosybrown: [188, 143, 143],
        royalblue: [65, 105, 225],
        saddlebrown: [139, 69, 19],
        salmon: [250, 128, 114],
        sandybrown: [244, 164, 96],
        seagreen: [46, 139, 87],
        seashell: [255, 245, 238],
        sienna: [160, 82, 45],
        silver: [192, 192, 192],
        skyblue: [135, 206, 235],
        slateblue: [106, 90, 205],
        slategray: [112, 128, 144],
        slategrey: [112, 128, 144],
        snow: [255, 250, 250],
        springgreen: [0, 255, 127],
        steelblue: [70, 130, 180],
        tan: [210, 180, 140],
        teal: [0, 128, 128],
        thistle: [216, 191, 216],
        tomato: [255, 99, 71],
        turquoise: [64, 224, 208],
        violet: [238, 130, 238],
        wheat: [245, 222, 179],
        white: [255, 255, 255],
        whitesmoke: [245, 245, 245],
        yellow: [255, 255, 0],
        yellowgreen: [154, 205, 50],
      }),
      (ps = {
        red: 0,
        orange: 60,
        yellow: 120,
        green: 180,
        blue: 240,
        purple: 300,
      }),
      (ms = {
        name: `rgb`,
        min: [0, 0, 0],
        max: [255, 255, 255],
        channel: [`red`, `green`, `blue`],
        alias: [`RGB`],
      }),
      (hs = {
        name: `hsl`,
        min: [0, 0, 0],
        max: [360, 100, 100],
        channel: [`hue`, `saturation`, `lightness`],
        alias: [`HSL`],
        rgb: function (e) {
          var t = e[0] / 360,
            n = e[1] / 100,
            r = e[2] / 100,
            i,
            a,
            o,
            s,
            c;
          if (n === 0) return (c = r * 255), [c, c, c];
          (a = r < 0.5 ? r * (1 + n) : r + n - r * n),
            (i = 2 * r - a),
            (s = [0, 0, 0]);
          for (var l = 0; l < 3; l++)
            (o = t + (1 / 3) * -(l - 1)),
              o < 0 ? o++ : o > 1 && o--,
              (c =
                6 * o < 1
                  ? i + (a - i) * 6 * o
                  : 2 * o < 1
                  ? a
                  : 3 * o < 2
                  ? i + (a - i) * (2 / 3 - o) * 6
                  : i),
              (s[l] = c * 255);
          return s;
        },
      }),
      (ms.hsl = function (e) {
        var t = e[0] / 255,
          n = e[1] / 255,
          r = e[2] / 255,
          i = Math.min(t, n, r),
          a = Math.max(t, n, r),
          o = a - i,
          s,
          c,
          l;
        return (
          a === i
            ? (s = 0)
            : t === a
            ? (s = (n - r) / o)
            : n === a
            ? (s = 2 + (r - t) / o)
            : r === a && (s = 4 + (t - n) / o),
          (s = Math.min(s * 60, 360)),
          s < 0 && (s += 360),
          (l = (i + a) / 2),
          (c = a === i ? 0 : l <= 0.5 ? o / (a + i) : o / (2 - a - i)),
          [s, c * 100, l * 100]
        );
      }),
      (gs = Object.defineProperty),
      (_s = Object.defineProperties),
      (vs = Object.getOwnPropertyDescriptors),
      (ys = Object.getOwnPropertySymbols),
      (bs = Object.prototype.hasOwnProperty),
      (xs = Object.prototype.propertyIsEnumerable),
      (Ss = (e, t, n) =>
        t in e
          ? gs(e, t, {
              enumerable: !0,
              configurable: !0,
              writable: !0,
              value: n,
            })
          : (e[t] = n)),
      (Cs = (e, t) => {
        for (var n in (t ||= {})) bs.call(t, n) && Ss(e, n, t[n]);
        if (ys) for (var n of ys(t)) xs.call(t, n) && Ss(e, n, t[n]);
        return e;
      }),
      (ws = (e, t) => _s(e, vs(t))),
      (Ts = 90),
      (Es = class extends Mr {
        constructor(e) {
          let t;
          if (
            ((t =
              e && `css` in e
                ? ws(Cs({}, Zo(e.css || ``)), {
                    alpha: e.alpha ?? Es.defaults.alpha,
                    maxColors: e.maxColors ?? Es.defaults.maxColors,
                  })
                : Cs(Cs({}, Es.defaults), e)),
            !t.stops || t.stops.length < 2)
          )
            throw Error(`ColorGradientFilter requires at least 2 color stops.`);
          super(ls, cs),
            (this._stops = []),
            (this.autoFit = !1),
            Object.assign(this, t);
        }
        get stops() {
          return this._stops;
        }
        set stops(e) {
          let t = ss(e),
            n = new Float32Array(t.length * 3);
          for (let e = 0; e < t.length; e++) {
            let r = Yo(t[e].color),
              i = e * 3;
            (n[i + 0] = r[0]), (n[i + 1] = r[1]), (n[i + 2] = r[2]);
          }
          (this.uniforms.uColors = n),
            (this.uniforms.uOffsets = t.map((e) => e.offset)),
            (this.uniforms.uAlphas = t.map((e) => e.alpha)),
            (this.uniforms.uNumStops = t.length),
            (this._stops = t);
        }
        set type(e) {
          this.uniforms.uType = e;
        }
        get type() {
          return this.uniforms.uType;
        }
        set angle(e) {
          this.uniforms.uAngle = e - Ts;
        }
        get angle() {
          return this.uniforms.uAngle + Ts;
        }
        set alpha(e) {
          this.uniforms.uAlpha = e;
        }
        get alpha() {
          return this.uniforms.uAlpha;
        }
        set maxColors(e) {
          this.uniforms.uMaxColors = e;
        }
        get maxColors() {
          return this.uniforms.uMaxColors;
        }
        set replace(e) {
          this.uniforms.uReplace = e;
        }
        get replace() {
          return this.uniforms.uReplace;
        }
      }),
      (Ds = Es),
      (Ds.LINEAR = 0),
      (Ds.RADIAL = 1),
      (Ds.CONIC = 2),
      (Ds.defaults = {
        type: Es.LINEAR,
        stops: [
          { offset: 0, color: 16711680, alpha: 1 },
          { offset: 1, color: 255, alpha: 1 },
        ],
        alpha: 1,
        angle: 90,
        maxColors: 0,
        replace: !1,
      });
  }))();
}
var ks, As, js, Ms, Ns, Ps, Fs;
function Is() {
  return (Is = t(() => {
    Fr(),
      (ks = `attribute vec2 aVertexPosition;
attribute vec2 aTextureCoord;

uniform mat3 projectionMatrix;

varying vec2 vTextureCoord;

void main(void)
{
    gl_Position = vec4((projectionMatrix * vec3(aVertexPosition, 1.0)).xy, 0.0, 1.0);
    vTextureCoord = aTextureCoord;
}`),
      (As = `varying vec2 vTextureCoord;

uniform sampler2D uSampler;
uniform float blur;
uniform float gradientBlur;
uniform vec2 start;
uniform vec2 end;
uniform vec2 delta;
uniform vec2 texSize;

float random(vec3 scale, float seed)
{
    return fract(sin(dot(gl_FragCoord.xyz + seed, scale)) * 43758.5453 + seed);
}

void main(void)
{
    vec4 color = vec4(0.0);
    float total = 0.0;

    float offset = random(vec3(12.9898, 78.233, 151.7182), 0.0);
    vec2 normal = normalize(vec2(start.y - end.y, end.x - start.x));
    float radius = smoothstep(0.0, 1.0, abs(dot(vTextureCoord * texSize - start, normal)) / gradientBlur) * blur;

    for (float t = -30.0; t <= 30.0; t++)
    {
        float percent = (t + offset - 0.5) / 30.0;
        float weight = 1.0 - abs(percent);
        vec4 sample = texture2D(uSampler, vTextureCoord + delta / texSize * percent * radius);
        sample.rgb *= sample.a;
        color += sample * weight;
        total += weight;
    }

    color /= total;
    color.rgb /= color.a + 0.00001;

    gl_FragColor = color;
}
`),
      (js = class extends Mr {
        constructor(e) {
          super(ks, As),
            (this.uniforms.blur = e.blur),
            (this.uniforms.gradientBlur = e.gradientBlur),
            (this.uniforms.start =
              e.start ?? new jr(0, window.innerHeight / 2)),
            (this.uniforms.end = e.end ?? new jr(600, window.innerHeight / 2)),
            (this.uniforms.delta = new jr(30, 30)),
            (this.uniforms.texSize = new jr(
              window.innerWidth,
              window.innerHeight
            )),
            this.updateDelta();
        }
        updateDelta() {
          (this.uniforms.delta.x = 0), (this.uniforms.delta.y = 0);
        }
        get blur() {
          return this.uniforms.blur;
        }
        set blur(e) {
          this.uniforms.blur = e;
        }
        get gradientBlur() {
          return this.uniforms.gradientBlur;
        }
        set gradientBlur(e) {
          this.uniforms.gradientBlur = e;
        }
        get start() {
          return this.uniforms.start;
        }
        set start(e) {
          (this.uniforms.start = e), this.updateDelta();
        }
        get end() {
          return this.uniforms.end;
        }
        set end(e) {
          (this.uniforms.end = e), this.updateDelta();
        }
      }),
      (Ms = class extends js {
        updateDelta() {
          let e = this.uniforms.end.x - this.uniforms.start.x,
            t = this.uniforms.end.y - this.uniforms.start.y,
            n = Math.sqrt(e * e + t * t);
          (this.uniforms.delta.x = e / n), (this.uniforms.delta.y = t / n);
        }
      }),
      (Ns = class extends js {
        updateDelta() {
          let e = this.uniforms.end.x - this.uniforms.start.x,
            t = this.uniforms.end.y - this.uniforms.start.y,
            n = Math.sqrt(e * e + t * t);
          (this.uniforms.delta.x = -t / n), (this.uniforms.delta.y = e / n);
        }
      }),
      (Ps = class extends Mr {
        constructor(e, t, n, r) {
          super(),
            typeof e == `number` &&
              (Ur(
                `5.3.0`,
                `TiltShiftFilter constructor arguments is deprecated, use options.`
              ),
              (e = { blur: e, gradientBlur: t, start: n, end: r })),
            (e = Object.assign({}, Ps.defaults, e)),
            (this.tiltShiftXFilter = new Ms(e)),
            (this.tiltShiftYFilter = new Ns(e));
        }
        apply(e, t, n, r) {
          let i = e.getFilterTexture();
          this.tiltShiftXFilter.apply(e, t, i, 1),
            this.tiltShiftYFilter.apply(e, i, n, r),
            e.returnFilterTexture(i);
        }
        get blur() {
          return this.tiltShiftXFilter.blur;
        }
        set blur(e) {
          this.tiltShiftXFilter.blur = this.tiltShiftYFilter.blur = e;
        }
        get gradientBlur() {
          return this.tiltShiftXFilter.gradientBlur;
        }
        set gradientBlur(e) {
          this.tiltShiftXFilter.gradientBlur =
            this.tiltShiftYFilter.gradientBlur = e;
        }
        get start() {
          return this.tiltShiftXFilter.start;
        }
        set start(e) {
          this.tiltShiftXFilter.start = this.tiltShiftYFilter.start = e;
        }
        get end() {
          return this.tiltShiftXFilter.end;
        }
        set end(e) {
          this.tiltShiftXFilter.end = this.tiltShiftYFilter.end = e;
        }
      }),
      (Fs = Ps),
      (Fs.defaults = {
        blur: 100,
        gradientBlur: 600,
        start: void 0,
        end: void 0,
      });
  }))();
}
function Ls() {
  return (Ls = t(() => {
    J(), Is();
  }))();
}
var Rs,
  zs,
  Bs,
  Vs,
  Hs,
  Us,
  Ws,
  Gs,
  Ks,
  qs,
  Js,
  Ys,
  Xs,
  Zs,
  Qs,
  $s,
  ec,
  tc,
  nc,
  rc,
  ic,
  ac,
  oc,
  sc,
  cc,
  lc,
  uc,
  dc,
  fc,
  pc,
  mc,
  hc,
  gc,
  _c,
  vc,
  yc,
  bc,
  xc,
  Sc,
  Cc,
  wc,
  Tc,
  Ec,
  Dc,
  Oc,
  kc,
  Ac,
  jc,
  Mc,
  Nc,
  Pc,
  Fc,
  Ic,
  Lc,
  Rc;
function zc() {
  return (zc = t(() => {
    (Rs = e(a())),
      J(),
      W(),
      za(),
      kt(),
      Jt(),
      Zt(),
      D(),
      On(),
      Yr(),
      Qr(),
      G(),
      j(),
      N(),
      L(),
      $(),
      Z(),
      (zs = `NORMAL`),
      (Bs = `FANG`),
      (Vs = `BUCK`),
      (Hs = 0),
      (Us = 1),
      (Ws = 2),
      (Gs = `FACE_IDLE`),
      (Ks = `FACE_HAPPY`),
      (qs = `FACE_SAD`),
      (Js = `BODY_IDLE`),
      (Ys = `BODY_CLAP`),
      (Xs = `BODY_HEART`),
      (Zs = `BODY_THUMBS_UP`),
      (Qs = `BODY_TROPHY`),
      ($s = `BODY_PODIUMDANCE`),
      (ec = `BODY_PODIUMDANCEWINNER_ARMS`),
      (tc = `BODY_PODIUMDANCEWINNER_NOARMS`),
      (nc = `HEAD`),
      (rc = `ITEM2C3`),
      (ic = `eyebrowColor`),
      (ac = `eyebrowColor2`),
      (oc = `pupilColor`),
      (sc = `pupilColor2`),
      (cc = `eyeballColor`),
      (lc = `eyeballColor2`),
      (uc = `eyeBorderColor`),
      (dc = `eyeBorderColor2`),
      (fc = `mouthColor`),
      (pc = `lipColor`),
      (mc = `teethColor`),
      (hc = `teethColor2`),
      (gc = `teethColor3`),
      (_c = `tongueColor`),
      (vc = `chinColor`),
      (yc = `faceeyeparpado`),
      (bc = `faceeyeparpado2`),
      (xc = `iris`),
      (Sc = `iris2`),
      (Cc = {
        [ic]: `#40383a`,
        [ac]: `#40383a`,
        [oc]: `#40383a`,
        [sc]: `#40383a`,
        [cc]: `#ffffff`,
        [lc]: `#ffffff`,
        [uc]: `#00000000`,
        [dc]: `#00000000`,
        [fc]: `#40383a`,
        [pc]: `#40383a`,
        [mc]: `#ffffff`,
        [hc]: `#ffffff`,
        [gc]: `#ffffff`,
        [_c]: `#ff6666`,
        [vc]: `#be8907`,
        [yc]: `#e5a609`,
        [bc]: `#e5a609`,
        [xc]: `#00000000`,
        [Sc]: `#00000000`,
      }),
      (wc = [`arm`, `arm2`, `bodyup`]),
      (Tc = [`leg`, `leg2`, `hips`]),
      (Ec = [`feet`, `feet2`]),
      (Dc = [-25, -95, 53, 100]),
      (Oc = `START`),
      (kc = [0.85, 1.25]),
      (Ac = [0.95, 1.05]),
      (jc = -85),
      (Mc = 10),
      (Nc = 14),
      (Pc = [5, 1]),
      (Fc = 4),
      (Ic = 0.05),
      (Lc = {
        [Kt.Heart]: `heart`,
        [Kt.Trophy]: `trophy`,
        [Kt.Victory]: `victory`,
      }),
      (Rc = class extends H {
        get data() {
          return this._config.data;
        }
        get rank() {
          return this._params?.podiumRank;
        }
        get cid() {
          return this._config.cid;
        }
        get textSprite() {
          return this._nameTextContainer;
        }
        get currentAnimation() {
          return this._currentAnimation;
        }
        toggleNameTextDisplay(e, t = !1) {
          if (!this._nameText) return;
          let n = this._nameText.text;
          (this._nameText.text =
            e === `full` ? this._nameTextFull : this._nameTextReduced),
            !(!this._nameTextBackground || (this._nameText.text === n && !t)) &&
              (this._nameTextBackground.clear(),
              this._nameTextBackground.beginFill(0, Ic),
              this._nameTextBackground.drawRoundedRect(
                this._nameText.x - this._nameText.width / 2 - Pc[0],
                this._nameText.y - Nc / 2 - Pc[1],
                this._nameText.width + Pc[0] * 2,
                Nc + Pc[1] * 2,
                Fc
              ),
              this._nameTextBackground.endFill());
        }
        toggleNameVisibility(e) {
          this._nameTextContainer &&
            ((e && this._nameTextContainer.visible && !this._nameTextTween) ||
              (!e &&
                !this._nameTextContainer.visible &&
                !this._nameTextTween) ||
              (this._nameTextContainer.visible ||
                ((this._nameTextContainer.alpha = 0),
                (this._nameTextContainer.visible = !0)),
              this._nameTextTween?.destroy(),
              (this._nameTextTween = O({
                from: { value: +!e },
                to: { value: +!!e },
                duration: 500,
                onTick: ({ value: e }) => {
                  this.destroyed ||
                    !this._nameTextContainer ||
                    (this._nameTextContainer.alpha = e);
                },
                onFinish: () => {
                  this.destroyed ||
                    !this._nameTextContainer ||
                    e ||
                    (this._nameTextContainer.visible = !1);
                },
              })),
              this._nameTextTween?.play()));
        }
        setEmote(e, t) {
          let n = Lc[e];
          n &&
            this.fadeInWhiteOverlayAndPlayEmote(() => this.setAnimation(n, t));
        }
        setFace(e) {
          if (!this._spine) return;
          let t;
          switch (e) {
            case v.Idle:
              t = this._spine.state.setAnimation(Hs, Gs, !0);
              break;
            case v.Happy:
              t = this._spine.state.setAnimation(Hs, Ks, !0);
              break;
            case v.Sad:
              t = this._spine.state.setAnimation(Hs, qs, !0);
          }
          t &&
            ((t.trackTime =
              t.animationStart +
              Math.random() * Math.max(0, t.animationEnd - t.animationStart)),
            (t.timeScale = Zr(...Ac)));
        }
        setAnimation(e, t) {
          if (((this._currentAnimation = e), this._spine))
            switch (
              ((this._spine.state.timeScale = t === void 0 ? Zr(...kc) : t), e)
            ) {
              case `idle`:
                this.setFace(v.Idle),
                  this._spine.state.setAnimation(Us, Js, !0),
                  this._spine.state.setEmptyAnimation(Ws);
                return;
              case `dance`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, z([$s, tc]) ?? $s, !0),
                  this._spine.state.setEmptyAnimation(Ws);
                return;
              case `victory`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, tc, !0),
                  this._spine.state.setAnimation(Ws, ec);
                return;
              case `heart`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, Xs, !0),
                  this._spine.state.setEmptyAnimation(Ws);
                return;
              case `trophy`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, Qs, !0),
                  this._spine.state.setEmptyAnimation(Ws);
                return;
              case `applause`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, Ys, !0),
                  this._spine.state.setEmptyAnimation(Ws);
                return;
              case `thumbsUp`:
                this.setFace(v.Happy),
                  this._spine.state.setAnimation(Us, Js, !0),
                  this._spine.state.setAnimation(Ws, Zs);
                return;
            }
        }
        addAnimationListener(e, t) {
          this._spine?.state.addListener({
            event: (n, r) => {
              r.data.name === e && t();
            },
          });
        }
        clearAnimationListeners() {
          this._spine?.state.clearListeners();
        }
        constructor(e, t) {
          super(),
            (this._currentAnimation = `idle`),
            (this._nameTextReduced = ``),
            (this._nameTextFull = ``),
            (this.hasColor = (e) => {
              if (!e) return !1;
              try {
                return (0, Rs.default)(e).rgba()[3] !== 0;
              } catch {
                return !1;
              }
            }),
            (this.hideSlot = (e) => {
              if (!this._spine) return;
              let t = this._spine.skeleton.findSlotIndex(e),
                n = this._spine.slotContainers[t];
              n && (n.renderable = !1);
            }),
            (this.colorizeSlot = (e, t) => {
              let n = this._config?.avatar?.type?.id,
                r = this._config?.avatar?.type?.name,
                i = this._spine?.skeleton.findSlot(e);
              if (!i) {
                console.warn(`- [${n}] ${r} - Slot not found: ${e}`);
                return;
              }
              let a = t.find(this.hasColor);
              if (!a) {
                this.hideSlot(e);
                return;
              }
              try {
                i.color.setFromString((0, Rs.default)(a).hex());
              } catch {
                console.warn(
                  `- [${n}] ${r} - Invalid color (${a}) provided for slot: ${e}`
                );
                return;
              }
            }),
            (this._config = e),
            (this._params = t),
            this.createSpine(),
            this.setHeadTextures()
              .then(() => {
                this.setHeadColors(), this.setHeadSkin();
              })
              .catch(() => {
                this.setDefaultHeadColors();
              }),
            this.setBodyColors(),
            this.addName();
        }
        destroy(e) {
          this._whiteFlashTween?.destroy(),
            this._nameTextTween?.destroy(),
            this._nameTextBackground?.destroy(!0),
            this._spine &&
              ((this._spine.filters = []), this._spine.state.clearListeners()),
            this.removeAllListeners(),
            super.destroy(e);
        }
        createSpine() {
          let e = q.instance.getResourceSpine(mr);
          e &&
            ((this._spine = new K(e.spineData)),
            (this._spine.stateData.defaultMix = 0.2),
            this._params?.animation &&
              this.setAnimation(this._params.animation),
            this._params?.face && this.setFace(this._params.face),
            this.addChild(this._spine));
        }
        async setHeadTextures() {
          if (!this._spine) return;
          let [e, t] = await Promise.allSettled([
              $r.instance.getBaseTexture(this._config.avatar),
              $r.instance.getItemTexture(this._config.avatar),
            ]),
            n = e.status === `fulfilled` ? e.value : null,
            r = t.status === `fulfilled` ? t.value : null;
          if (!n)
            throw Error(
              `No base texture found for character head, falling back to default`
            );
          this._spine.hackTextureBySlotName(nc, n),
            r
              ? this._spine.hackTextureBySlotName(rc, r)
              : this._spine.skeleton.setAttachment(rc, null);
        }
        setBodyColors() {
          let e = Xr(this._config.name);
          wc.forEach((t) => this.colorizeSlot(t, [e.shirt])),
            Tc.forEach((t) => this.colorizeSlot(t, [e.pants])),
            Ec.forEach((t) => this.colorizeSlot(t, [e.shoes]));
        }
        setDefaultHeadColors() {
          Object.entries(Cc).forEach(([e, t]) => {
            this.colorizeSlot(e, [t]);
          });
        }
        setHeadColors() {
          let e = this._config?.avatar?.type?.colors;
          if (!e) return;
          this.colorizeSlot(ic, [e.leftEyebrowColor, e.eyebrowColor]),
            this.colorizeSlot(ac, [e.rightEyebrowColor, e.eyebrowColor]),
            this.colorizeSlot(oc, [e.leftEyePupilColor, e.pupilColor]),
            this.colorizeSlot(sc, [e.rightEyePupilColor, e.pupilColor]),
            this.colorizeSlot(cc, [e.leftEyeballColor, e.eyeballColor]),
            this.colorizeSlot(lc, [e.rightEyeballColor, e.eyeballColor]),
            this.colorizeSlot(uc, [e.leftEyeBorderColor, e.eyeBorderColor]),
            this.colorizeSlot(dc, [e.rightEyeBorderColor, e.eyeBorderColor]),
            this.colorizeSlot(fc, [e.mouthColor]),
            this.colorizeSlot(pc, [e.lipColor]),
            this.colorizeSlot(mc, [e.teethColor]),
            this.colorizeSlot(hc, [e.teethColor]),
            this.colorizeSlot(gc, [e.teethColor]),
            this.colorizeSlot(_c, [e.tongueColor]),
            this.colorizeSlot(vc, [e.chinColor]);
          let t = this.hasColor(e.leftEyeballColor ?? e.eyeballColor),
            n = this.hasColor(e.rightEyeballColor ?? e.eyeballColor);
          t
            ? this.colorizeSlot(yc, [
                e.leftEyelidColor,
                e.eyelidColor,
                e.leftEyeBorderColor,
                e.eyeBorderColor,
                e.chinColor,
                e.leftEyebrowColor,
                e.eyebrowColor,
              ])
            : this.hideSlot(yc),
            n
              ? this.colorizeSlot(bc, [
                  e.rightEyelidColor,
                  e.eyelidColor,
                  e.rightEyeBorderColor,
                  e.eyeBorderColor,
                  e.chinColor,
                  e.rightEyebrowColor,
                  e.eyebrowColor,
                ])
              : this.hideSlot(bc),
            t || this.hideSlot(xc),
            n || this.hideSlot(Sc);
        }
        setHeadSkin() {
          let e = this._config?.avatar?.type?.colors?.teethType;
          e === er.Normal
            ? this._spine?.skeleton.setSkinByName(zs)
            : e === er.Fangs
            ? this._spine?.skeleton.setSkinByName(Bs)
            : e === er.Buck && this._spine?.skeleton.setSkinByName(Vs);
        }
        addName() {
          this._params?.showName &&
            ((this._nameTextFull = this._config.name),
            (this._nameTextReduced =
              this._nameTextFull.length > 13
                ? this._nameTextFull.slice(0, Mc) + `…`
                : this._nameTextFull),
            (this._nameTextContainer = new H()),
            (this._nameTextContainer.y = jc),
            (this._nameTextContainer.visible = !1),
            this.addChild(this._nameTextContainer),
            (this._nameTextBackground = new Pr()),
            this._nameTextContainer.addChild(this._nameTextBackground),
            (this._nameText = new X(this._nameTextReduced, et)),
            (this._nameText.resolution = 5),
            this._nameText.anchor.set(0.5),
            this._nameTextContainer.addChild(this._nameText),
            this.toggleNameTextDisplay(`reduced`, !0),
            (this.eventMode = `static`),
            (this.hitArea = new V(...Dc)),
            this.on(`pointerover`, () => {
              this.toggleNameTextDisplay(`full`);
            }),
            this.on(`pointerout`, () => {
              this.toggleNameTextDisplay(`reduced`);
            }));
        }
        fadeInWhiteOverlayAndPlayEmote(e) {
          this._spine &&
            (this._overlayFilter ||
              ((this._overlayFilter = new Ra()),
              (this._overlayFilter.color = 16777215)),
            this._whiteFlashTween?.destroy(),
            (this._whiteFlashTween = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: 500,
              easing: E.EASE_IN_EXPO,
              onTick: ({ value: e }) => {
                this.destroyed ||
                  !this._overlayFilter ||
                  (this._overlayFilter.alpha = e);
              },
              onFinish: () => {
                this.destroyed || (e(), this.fadeOutWhiteOverlayEffect());
              },
            })),
            (this._overlayFilter.alpha = 0),
            (this._spine.filters = [this._overlayFilter]),
            this._whiteFlashTween?.play());
        }
        fadeOutWhiteOverlayEffect() {
          !this._spine ||
            !this._overlayFilter ||
            (this._whiteFlashTween?.destroy(),
            (this._whiteFlashTween = O({
              delay: 200,
              from: { value: 1 },
              to: { value: 0 },
              duration: 500,
              easing: E.EASE_OUT_EXPO,
              onTick: ({ value: e }) => {
                this.destroyed ||
                  !this._overlayFilter ||
                  (this._overlayFilter.alpha = e);
              },
              onFinish: () => {
                this.destroyed || (this._spine && (this._spine.filters = []));
              },
            })),
            this._whiteFlashTween?.play());
        }
      });
  }))();
}
var Bc;
function Vc() {
  return (Vc = t(() => {
    J(),
      R(),
      F(),
      _(),
      zc(),
      (Bc = class extends H {
        get config() {
          return this._config;
        }
        get width() {
          return A(S.CentralSquare)[0];
        }
        set width(e) {
          throw Error(`ResultGameBase: width is read-only`);
        }
        get height() {
          return A(S.CentralSquare)[1];
        }
        set height(e) {
          throw Error(`ResultGameBase: height is read-only`);
        }
        select(e = !0) {
          this._createdCharacters.forEach((e) => e.toggleNameVisibility(!0));
        }
        deselect(e = !0) {
          this._createdCharacters.forEach((e) => e.toggleNameVisibility(!1));
        }
        getAllCharacters() {
          return this._createdCharacters.slice();
        }
        getCharacterByRank(e) {
          return this._createdCharacters.find((t) => t.rank === e);
        }
        getCharacterByCid(e) {
          return this._createdCharacters.find((t) => t.cid === e);
        }
        constructor(e) {
          super(), (this._createdCharacters = []), (this._config = e);
        }
        destroy(e) {
          super.destroy(e);
          for (let t of this._createdCharacters) t.destroy(e);
        }
        createCharacter(e, t, n = [0, 0]) {
          let r = new Rc(e, t);
          return (
            (r.x = n[0]),
            (r.zIndex = r.y = n[1]),
            (r.name = `character-${e.name}`),
            this._createdCharacters.push(r),
            r
          );
        }
        getCharactersInArea(e, t) {
          let n = new H();
          if (e.length === 0) return n;
          n.sortableChildren = !0;
          let r = t.area,
            i = Math.min(...r.map((e) => e.y)),
            a = Math.max(...r.map((e) => e.y + e.height)) - i,
            o = Qt(r);
          for (let { config: r, params: s } of e) {
            let [e, c] = o(),
              l = this.createCharacter(r, s, [e, c]);
            if (
              ((l.name = `area-character-${r.name}`), n.addChild(l), t.scale)
            ) {
              let e = a > 0 ? (l.y - i) / a : 0,
                n = t.scale.min,
                r = n + e * (t.scale.max - n);
              l.scale.set(r);
            }
          }
          return n;
        }
      });
  }))();
}
var Hc, Uc, Wc, Gc, Kc, qc, Jc, Yc, Xc, Zc, Qc, $c, el, tl, nl, rl;
function il() {
  return (il = t(() => {
    (Hc = e(ne())),
      J(),
      Os(),
      Er(),
      Ye(),
      G(),
      Ls(),
      N(),
      F(),
      L(),
      $(),
      _(),
      Ko(),
      Vc(),
      (Uc = 5),
      (Wc = 7),
      (Gc = 30),
      (Kc = 0.1),
      (qc = 0.25),
      (Jc = -60),
      (Yc = -15),
      (Xc = -130),
      (Zc = 1.1),
      (Qc = 0.15),
      ($c = 20),
      (el = 1.7),
      (tl = 0.6),
      (nl = [
        { offset: 0, color: `#ffffff`, alpha: 0.2 },
        { offset: 1, color: `#ffffff`, alpha: 0.6 },
      ]),
      (rl = class extends Bc {
        get podium() {
          return this._podium;
        }
        select(e = !0) {
          super.select(e),
            e
              ? this.createAlphaTween(`in`, 500)
              : (this.setAlpha(1),
                this.setBackdrop(`in`),
                this.setFilters(`in`));
        }
        deselect(e = !0) {
          super.deselect(e),
            e
              ? this.createAlphaTween(`out`)
              : (this.setAlpha(0),
                this.setBackdrop(`out`),
                this.setFilters(`out`));
        }
        constructor(e) {
          super(e),
            (this._sortedCharacters = []),
            (this._sortedCharacters = (0, Hc.default)(
              e.players,
              (e) => e.data?.rank ?? 1 / 0,
              (e) => -(e.data?.score ?? -1 / 0)
            )),
            (this._filteredContainer = new H()),
            this.addChild(this._filteredContainer),
            (this._nonFilteredContainer = new H()),
            this.addChild(this._nonFilteredContainer),
            this.addBackground(),
            this.addPodiumBackCharacters(),
            this.addPodium(),
            this.addPodiumCharacters(),
            this.addPodiumFrontCharacters(),
            (this._tiltShiftFilter = void 0),
            (this._podiumBackCharsFilter = new Ds({
              type: Ds.LINEAR,
              angle: 0,
              stops:
                T(`resultsPodiumBackCharsGradientFilterStops`) ??
                Pn.resultsPodiumBackCharsGradientFilterStops ??
                nl,
              alpha: 1,
              replace: !1,
            })),
            (this._podiumFrontCharsFilter = void 0);
        }
        destroy(e) {
          super.destroy(e),
            this._tween?.destroy(),
            this._tiltShiftFilter?.destroy(),
            this._podiumBackCharsFilter?.destroy(),
            this._podiumFrontCharsFilter?.destroy();
        }
        addBackground() {
          let e = q.instance.getResourceTexture(br);
          e &&
            ((this._bgContainer = new H()),
            (this._bgContainer.y = Jc),
            (this._bgContainer.alpha = 0),
            this._filteredContainer.addChild(this._bgContainer),
            (this._bgBackdrop = new B(U.WHITE)),
            this._bgBackdrop.anchor.set(0.5),
            (this._bgBackdrop.tint = 0),
            (this._bgBackdrop.width = e.width + 100),
            (this._bgBackdrop.height = e.height + 100),
            (this._bgBackdrop.visible = !1),
            this._bgContainer.addChild(this._bgBackdrop),
            (this._bg = new B(e)),
            this._bg.anchor.set(0.5),
            this._bgContainer.addChild(this._bg));
        }
        getCrowdDistribution() {
          let e = this._sortedCharacters.length,
            t = Math.max(0, e - Uc);
          if (t === 0) return { backCount: 0, frontCount: 0 };
          let n = Math.min(Math.floor(t * Kc), Wc);
          return { backCount: n, frontCount: Math.min(t, Gc) - n };
        }
        getCrowdCharacterAnimation(e) {
          return k(pe(e))() < qc ? `applause` : `idle`;
        }
        addPodiumBackCharacters() {
          let e = new V(
              (-1 * this.width * Zc) / 2,
              Xc,
              this.width * Zc,
              this.height * Qc
            ),
            t = 1 / 3.65,
            n = new V(e.x, e.y, e.width * t, e.height),
            r = new V(
              e.x + e.width * 0.726027397260274,
              e.y,
              e.width * t,
              e.height
            ),
            { backCount: i } = this.getCrowdDistribution(),
            a = this._sortedCharacters
              .slice(Uc, Uc + i)
              .map((e) => ({
                config: e,
                params: { animation: this.getCrowdCharacterAnimation(e.cid) },
              }));
          (this._podiumBackCharactersContainer = this.getCharactersInArea(a, {
            area: [n, r],
            scale: { min: 0.3, max: 0.7 },
          })),
            (this._podiumBackCharactersContainer.alpha = 0),
            this._filteredContainer.addChild(
              this._podiumBackCharactersContainer
            );
        }
        addPodium() {
          (this._podium = new Go()),
            (this._podium.y = Yc),
            this._filteredContainer.addChild(this._podium);
        }
        addPodiumCharacters() {
          if (this._podium)
            for (let e of [0, 1, 2, 3, 4]) {
              let t = this._sortedCharacters[e];
              if (!t) continue;
              let n = this._podium.getCharacterOffsetByRank(e),
                r = [n[0] + this._podium.x, this._podium.y + n[1]],
                i = this.createCharacter(
                  t,
                  { showName: !0, podiumRank: e, animation: `idle` },
                  r
                );
              (i.name = `podium-character-${e}-${t.name}-${
                t.data?.score ?? 0
              }`),
                e <= 2
                  ? this._nonFilteredContainer.addChild(i)
                  : this._filteredContainer.addChild(i);
            }
        }
        addPodiumFrontCharacters() {
          let e = new V(
              (-1 * this.width * el) / 2,
              $c,
              this.width * el,
              this.height * tl
            ),
            { backCount: t, frontCount: n } = this.getCrowdDistribution(),
            r = Uc + t,
            i = this._sortedCharacters
              .slice(r, r + n)
              .map((e) => ({
                config: e,
                params: { animation: this.getCrowdCharacterAnimation(e.cid) },
              }));
          (this._podiumFrontCharactersContainer = this.getCharactersInArea(i, {
            area: [e],
            scale: { min: 1.1, max: 1.75 },
          })),
            (this._podiumFrontCharactersContainer.alpha = 0),
            this._filteredContainer.addChild(
              this._podiumFrontCharactersContainer
            );
        }
        setAlpha(e) {
          this._bgContainer && (this._bgContainer.alpha = e),
            this._podiumBackCharactersContainer &&
              (this._podiumBackCharactersContainer.alpha = e),
            this._podiumFrontCharactersContainer &&
              (this._podiumFrontCharactersContainer.alpha = e);
        }
        setBackdrop(e) {
          this._bgBackdrop && (this._bgBackdrop.visible = e === `in`);
        }
        setFilters(e) {
          if (e === `in`) {
            if (ut()) return;
            this._tiltShiftFilter &&
              (this._filteredContainer.filters = [this._tiltShiftFilter]),
              this._podiumBackCharsFilter &&
                this._podiumBackCharactersContainer &&
                (this._podiumBackCharactersContainer.filters = [
                  this._podiumBackCharsFilter,
                ]),
              this._podiumFrontCharsFilter &&
                this._podiumFrontCharactersContainer &&
                (this._podiumFrontCharactersContainer.filters = [
                  this._podiumFrontCharsFilter,
                ]);
          } else
            (this._filteredContainer.filters = []),
              this._podiumBackCharactersContainer &&
                (this._podiumBackCharactersContainer.filters = []),
              this._podiumFrontCharactersContainer &&
                (this._podiumFrontCharactersContainer.filters = []);
        }
        createAlphaTween(e, t = 0) {
          this._tween?.destroy(),
            e === `in` && this.setFilters(`in`),
            e === `out` && this.setBackdrop(`out`),
            (this._tween = O({
              from: { alpha: this._bgContainer?.alpha ?? (e === `in` ? 0 : 1) },
              to: { alpha: +(e === `in`) },
              delay: t,
              duration: 500,
              onTick: ({ alpha: e }) => this.setAlpha(e),
              onFinish: () => {
                this._tween?.destroy(),
                  e === `in` && this.setBackdrop(`in`),
                  e === `out` && this.setFilters(`out`);
              },
            })),
            this._tween.play();
        }
      });
  }))();
}
var al, ol, sl, cl, ll, ul, dl, fl, pl;
function ml() {
  return (ml = t(() => {
    J(),
      Gr(),
      G(),
      j(),
      N(),
      C(),
      $(),
      il(),
      (al = 1500),
      (ol = 1e3),
      (sl = 2e3),
      (cl = 145),
      (ll = 90),
      (ul = 300),
      (dl = 0.5),
      (fl = 800),
      (pl = class extends rl {
        select(e = !0) {
          super.select(e), this.showSpider();
        }
        constructor(e) {
          super(e),
            (this._shouldShowSpider = Math.random() < 1 / 3),
            (this._isShowingSpider = !1),
            this.addSpider();
        }
        destroy(e) {
          super.destroy(e), this._spiderTween?.destroy();
        }
        addSpider() {
          if (!qr.stage || !this._shouldShowSpider) return;
          this._spiderContainer = new H();
          let e = qr.app?.renderer.screen.width ?? 0,
            t = qr.app?.renderer.screen.height ?? 0;
          (this._spiderContainer.alpha = 0),
            this._spiderContainer.scale.set(e < fl || t < fl ? dl : 1),
            qr.stage.addChild(this._spiderContainer),
            (this._spiderThread = new B(q.instance.getResourceTexture(Xt))),
            this._spiderThread.anchor.set(0.5, 0),
            this._spiderThread.position.set(cl, ll),
            (this._spiderThread.height = 0),
            this._spiderContainer.addChild(this._spiderThread);
          let n = new B(q.instance.getResourceTexture(Mn));
          this._spiderContainer.addChild(n),
            (this._spider = new B(q.instance.getResourceTexture(nr))),
            this._spider.anchor.set(0.5, 0.1),
            this._spider.position.set(cl, ll),
            this.addChild(this._spider),
            this._spiderContainer.addChild(this._spider);
        }
        showSpider() {
          if (!this._shouldShowSpider || this._isShowingSpider) return;
          this._isShowingSpider = !0;
          let e = ({ p: e }) => {
            let t = w(ll, ul, e);
            this._spider && this._spider.position.set(cl, t),
              this._spiderThread && (this._spiderThread.height = t - ll),
              this._spiderContainer && (this._spiderContainer.alpha = e);
          };
          this._spiderTween?.destroy(),
            (this._spiderTween = O({
              from: { p: 0 },
              to: { p: 1 },
              delay: ol,
              duration: al,
              easing: E.EASE_OUT_BOUNCE,
              onTick: e,
              onFinish: () => {
                this._spiderTween?.destroy(),
                  (this._spiderTween = O({
                    from: { p: 1 },
                    to: { p: 0 },
                    delay: sl,
                    duration: al,
                    easing: E.EASE_IN_BACK,
                    onTick: e,
                    onFinish: () => {
                      this._spiderTween?.destroy(),
                        (this._isShowingSpider = !1);
                    },
                  })),
                  this._spiderTween.play();
              },
            })),
            this._spiderTween.play();
        }
      });
  }))();
}
var hl = r((e, t) => {
    var n = d(),
      r = c(),
      i = f();
    function a(e, t) {
      return i(r(e), n(t, 0, e.length));
    }
    t.exports = a;
  }),
  gl = r((e, t) => {
    var n = d(),
      r = f(),
      i = h();
    function a(e, t) {
      var a = i(e);
      return r(a, n(t, 0, a.length));
    }
    t.exports = a;
  }),
  _l = r((e, t) => {
    var n = hl(),
      r = gl(),
      i = te(),
      a = u(),
      o = ee();
    function s(e, t, s) {
      return (
        (t = (s ? a(e, t, s) : t === void 0) ? 1 : o(t)), (i(e) ? n : r)(e, t)
      );
    }
    t.exports = s;
  }),
  vl,
  yl,
  bl,
  xl,
  Sl,
  Cl,
  wl;
function Tl() {
  return (Tl = t(() => {
    (vl = e(_l())),
      J(),
      G(),
      $(),
      Vc(),
      (yl = -100),
      (bl = 0),
      (xl = [310, 162]),
      (Sl = 50),
      (Cl = 30),
      (wl = class extends Bc {
        constructor(e) {
          super(e), this.addScreen(), this.addCharacters();
        }
        fitScreenImage(e) {
          (e.width = xl[0]), (e.height = xl[1]), (e.y = yl), e.anchor.set(0.5);
        }
        getScreenScreenshot() {
          let e = $i(this._config)?.name,
            t = e ? q.instance.getResourceTexture(e) : void 0,
            n = new B(t);
          return (n.filters = [new Kr()]), this.fitScreenImage(n), n;
        }
        addScreen() {
          let e = new B(U.WHITE);
          (e.tint = bl), this.fitScreenImage(e), this.addChild(e);
          let t = this.getScreenScreenshot();
          this.addChild(t);
          let n = new B(q.instance.getResourceTexture(Gt));
          n.anchor.set(0.5), (n.y = yl), this.addChild(n);
        }
        addCharacters() {
          let e = new V(
              -this.width / 2 + Cl,
              0,
              this.width - 60,
              this.height / 2 - 20
            ),
            t = this._config.players.slice(0, Sl),
            n = (0, vl.default)(t, Math.floor(Sl * 0.25)),
            r = t.map((e) => ({
              config: e,
              params: {
                podiumRank: n.includes(e) ? 0 : void 0,
                animation: `idle`,
              },
            })),
            i = this.getCharactersInArea(r, { area: [e] });
          this.addChild(i);
        }
      });
  }))();
}
var El;
function Dl() {
  return (Dl = t(() => {
    J(),
      kt(),
      We(),
      G(),
      Vt(),
      $(),
      Io(),
      xa(),
      Ko(),
      il(),
      ml(),
      Tl(),
      (El = class extends ba {
        get gameResult() {
          return this._gameResult;
        }
        select(e = !0) {
          this._gameResult?.select(e);
        }
        deselect(e = !0) {
          this._gameResult?.deselect(e);
        }
        setPendingAsyncRewardsCount(e) {
          e > 0 &&
            !this._asyncRewardsKoala &&
            ((this._asyncRewardsKoala = new Fo()),
            this.itemContainer.addChild(this._asyncRewardsKoala),
            this._asyncRewardsKoala.fadeIn()),
            this._asyncRewardsKoala?.setPendingAsyncRewardsCount(e);
        }
        initialize(e) {
          let t = q.instance.getResourceTexture($t);
          (this._sprite = new B(t)),
            this._sprite.anchor.set(0.5),
            e.addChild(this._sprite);
          let n = this.islandConfig.gameResultConfig,
            r = this.islandConfig.initialAnimationStyle === `timeLapse`;
          if (!n && r) {
            this.addPreGamePodium(e);
            return;
          }
          if (!n && !r) {
            this.addPreGamePodium(e);
            return;
          }
          if (n && n.type === M.FakeResult) {
            this.addPreGamePodium(e);
            return;
          }
          if (n) {
            this.addResultGameItem(e, n);
            return;
          }
          console.warn(`Unexpected case in ItemSpriteCentral`),
            this.addPreGamePodium(e);
        }
        addPreGamePodium(e) {
          let t = new Go();
          e.addChild(t);
        }
        addResultGameItem(e, t) {
          this._gameResult?.destroy({ children: !0 }),
            (this._gameResult = void 0);
          let n = this.getResultGameItem(t);
          n && ((this._gameResult = n), e.addChild(this._gameResult));
        }
        getResultGameItem(e) {
          switch (e.type) {
            case M.GameClassic:
              return e.gameModeSkin === ae.Halloween ? new pl(e) : new rl(e);
            case M.GenericGame:
              return new wl(e);
            case M.FakeResult:
              return;
            default:
              return new wl(e);
          }
        }
      });
  }))();
}
var Ol, kl;
function Al() {
  return (Al = t(() => {
    J(),
      j(),
      N(),
      C(),
      L(),
      Z(),
      (Ol = -50 / 2),
      (kl = class extends H {
        get text() {
          return this._text.text;
        }
        set text(e) {
          this._text.text = e;
        }
        set show(e) {
          this._tween?.stop(),
            e
              ? ((this.visible = !0),
                (this._text.y = Ol),
                (this._text.alpha = 1))
              : ((this.visible = !1),
                (this._text.y = 0),
                (this._text.alpha = 0));
        }
        animateShow(e) {
          this._tween?.stop(),
            (this._text.y = 0),
            (this._text.alpha = 0),
            (this.visible = !0),
            (this._tween = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: 500,
              easing: E.EASE_OUT_CIRC,
              onTick: ({ value: e }) => {
                (this._text.alpha = e), (this._text.y = w(0, Ol, e));
              },
              onFinish: e,
            })),
            this._tween.play();
        }
        animateHide(e) {
          this._tween?.stop();
          let t = this._text.alpha,
            n = this._text.y;
          (this._tween = O({
            from: { value: 0 },
            to: { value: 1 },
            duration: 500,
            easing: E.EASE_IN_SINE,
            onTick: ({ value: e }) => {
              (this._text.alpha = w(t, 0, e)), (this._text.y = w(n, n + Ol, e));
            },
            onFinish: () => {
              e?.(), (this.visible = !1);
            },
          })),
            this._tween.play();
        }
        constructor(e) {
          super(),
            (this._text = new X(e)),
            (this._text.style = {
              fontFamily: `Grandstander`,
              fontSize: 33,
              fontWeight: `700`,
              fill: `white`,
              dropShadow: !0,
              dropShadowColor: `black`,
              dropShadowDistance: 0,
              dropShadowAngle: 90,
              dropShadowAlpha: 1,
              dropShadowBlur: 3,
            }),
            (this._text.resolution = 2),
            this._text.anchor.set(0.5),
            (this._text.alpha = 0),
            this.addChild(this._text),
            (this.visible = !1);
        }
        destroy(e) {
          this._tween?.destroy(), super.destroy(e);
        }
      });
  }))();
}
var jl, Ml, Nl, Pl;
function Fl() {
  return (Fl = t(() => {
    (jl = e(i())),
      _(),
      Al(),
      Ea(),
      (Ml = -15),
      (Nl = 15),
      (Pl = class extends Ta {
        select() {
          this._periodItemName?.animateShow(),
            this._tierItemName?.animateShow(),
            super.select();
        }
        deselect() {
          this._periodItemName?.animateHide(),
            this._tierItemName?.animateHide(),
            super.deselect();
        }
        initialize(e) {
          super.initialize(e);
          let t = this.config.data?.startTime,
            n = this.config.data?.endTime,
            r = this.config.data?.tier;
          if (!(0, jl.default)(t) && !(0, jl.default)(n) && r !== void 0) {
            let e = -A(this.config.type)[1] / 2;
            (this._tierItemName = new kl(Cr(this.config))),
              (this._tierItemName.y = e + Ml),
              this._tierItemName.scale.set(0.5),
              this.addChild(this._tierItemName),
              (this._periodItemName = new kl(ur(this.config))),
              (this._periodItemName.y = e + Nl),
              this._periodItemName.scale.set(0.45),
              this.addChild(this._periodItemName);
          }
        }
      });
  }))();
}
var Il, Ll, Rl, zl;
function Bl() {
  return (Bl = t(() => {
    W(),
      za(),
      G(),
      j(),
      N(),
      C(),
      L(),
      $(),
      _(),
      xa(),
      (Il = `default`),
      (Ll = `IDLE`),
      (Rl = `COLORIZE`),
      (zl = class extends ba {
        select() {
          this._spine &&
            this.playItemEvolution(!0, () => {
              this._spine && this.setSelectedFilter(this._spine, !0);
            });
        }
        deselect() {
          this._spine &&
            (this.stopSequencePlayback(),
            this.destroyPrevItemSpine(),
            this.loopCurrentEvolutionStep(),
            this.setSelectedFilter(this._spine, !1));
        }
        gotoCurrentStep() {
          if (
            !this._spine ||
            !this._idleAnimations ||
            this._currentStepInSequence === void 0
          )
            return;
          let e = Math.max(this._currentStepInSequence - 1, 0),
            t = this._idleAnimations[e].name;
          t &&
            (this.stopSequencePlayback(),
            this._spine.state.setAnimation(0, t, !0));
        }
        playItemEvolution(e, t) {
          if (
            (this._timeoutId && clearTimeout(this._timeoutId),
            !this._spine ||
              this._idleAnimations === void 0 ||
              !this._currentStepInSequence)
          ) {
            t?.();
            return;
          }
          let n = e ? 1 : this._currentStepInSequence,
            r = this._currentStepInSequence + 1,
            i = () => {
              if (n >= r) this.destroyPrevItemSpine(), t?.();
              else {
                let t = e ? 1e3 : 0;
                this.playEvolutionStep(
                  n,
                  () => {
                    n++, i();
                  },
                  t
                );
              }
            };
          i();
        }
        stopSequencePlayback() {
          this._upgradeTween?.destroy(),
            this._spine?.state.clearListeners(),
            this._prevItemSpine?.state.clearListeners(),
            this._timeoutId && clearTimeout(this._timeoutId);
        }
        destroy(e) {
          this.stopSequencePlayback(), super.destroy(e);
        }
        initialize(e) {
          this._container = e;
          let t = Q(this.config);
          t &&
            ((this._spineResource = q.instance.getResourceSpine(t)),
            this._spineResource &&
              ((this._spine = new K(this._spineResource.spineData)),
              this._spine.skeleton.setSkinByName(Il),
              e.addChild(this._spine),
              (this._idleAnimations =
                this._spine.state.data.skeletonData.animations
                  .map(({ name: e, duration: t }) => ({ name: e, duration: t }))
                  .sort((e, t) => (e.name > t.name ? 1 : -1))
                  .filter((e) => e.name.includes(Ll))),
              (this._currentStepInSequence = this.config.xp
                ? Math.min(this.config.xp, this._idleAnimations.length - 1)
                : 0),
              this.colorizeSlots(),
              this.loopCurrentEvolutionStep()));
        }
        loopCurrentEvolutionStep() {
          if (
            !this._spine ||
            !this._idleAnimations ||
            this._currentStepInSequence === void 0
          )
            return;
          let e = this._idleAnimations[this._currentStepInSequence].name;
          e &&
            (this._spine.scale.set(1),
            (this._spine.alpha = 1),
            this._spine.state.setAnimation(0, e, !0));
        }
        colorizeSlots() {
          if (!this._spine) return;
          let e = Nn(this.config),
            t = e ? Fe[e] : void 0;
          if (!t) return;
          let n = this._spine.skeleton.data.slots.map((e) => e.name);
          for (let e of n)
            e.includes(Rl) &&
              this._spine.skeleton.findSlot(e)?.color.setFromString(t);
        }
        animateLevelUpSpine(e) {
          let t = (e) => {
              this.destroyed ||
                ((this._upgradeTween = O({
                  from: { scale: 0.5 },
                  to: { scale: 1 },
                  duration: 500,
                  easing: E.EASE_OUT_BOUNCE,
                  onTick: (e) => {
                    this._spine && this._spine.scale.set(e.scale);
                  },
                  onFinish: e,
                })),
                this._upgradeTween.play());
            },
            n = (e) => {
              this.destroyed ||
                (this._timeoutId = setTimeout(() => {
                  this.destroyed || e?.();
                }, 500));
            },
            r = () => {
              this.destroyed ||
                (this._upgradeTween?.destroy(),
                this._timeoutId && clearTimeout(this._timeoutId),
                e?.());
            };
          t(() => n(() => r()));
        }
        playEvolutionStep(e, t, n) {
          if (
            this.destroyed ||
            this._spineResource === void 0 ||
            !this._container ||
            !this._idleAnimations ||
            !this._spine
          ) {
            t();
            return;
          }
          this._prevItemSpine === void 0 &&
            ((this._prevItemSpine = new K(this._spineResource.spineData)),
            this._prevItemSpine.skeleton.setSkinByName(Il)),
            this._prevItemSpine.state.setAnimation(
              0,
              this._idleAnimations[e - 1].name,
              !1
            );
          let r = e === this._currentStepInSequence;
          this._spine.state.setAnimation(0, this._idleAnimations[e].name, r),
            this._spine.scale.set(0),
            this._container.addChild(this._prevItemSpine),
            this._prevItemSpine.scale.set(1),
            (this._prevItemSpine.alpha = 1),
            (this._prevItemFilter = new Ra(16777215, 0)),
            (this._prevItemSpine.filters = [this._prevItemFilter]);
          let i = (e) => {
              (this._upgradeTween = O({
                from: { value: 0 },
                to: { value: 1 },
                duration: 1e3,
                delay: n,
                onTick: ({ value: e }) => {
                  this._prevItemFilter && (this._prevItemFilter.alpha = e);
                },
                onFinish: () => {
                  e();
                },
              })),
                this._upgradeTween.play();
            },
            a = () => {
              (this._upgradeTween = O({
                from: { value: 0 },
                to: { value: 1 },
                duration: 500,
                easing: E.EASE_OUT_EXPO,
                onTick: ({ value: e }) => {
                  this._prevItemSpine &&
                    (this._prevItemSpine.scale.set(w(1, 2, e)),
                    (this._prevItemSpine.alpha = 1 - e));
                },
              })),
                this._upgradeTween.play();
            };
          i(() => {
            this._prevItemSpine && (a(), this.animateLevelUpSpine(t));
          });
        }
        destroyPrevItemSpine() {
          this._prevItemSpine &&= (this._prevItemSpine.destroy(), void 0);
        }
      });
  }))();
}
var Vl;
function Hl() {
  return (Hl = t(() => {
    J(),
      G(),
      $(),
      xa(),
      (Vl = class extends ba {
        select() {
          this.setSelectedFilter(this._sprite, !0);
        }
        deselect() {
          this.setSelectedFilter(this._sprite, !1);
        }
        initialize(e) {
          let t = Q(this.config);
          if (!t) return;
          let n = q.instance.getResourceTexture(t);
          (this._sprite = new B(n)),
            this._sprite.anchor.set(0.5),
            e.addChild(this._sprite);
        }
      });
  }))();
}
var Ul;
function Wl() {
  return (Wl = t(() => {
    kt(),
      En(),
      $(),
      pr(),
      _(),
      Na(),
      Eo(),
      Dl(),
      Fl(),
      Ea(),
      Bl(),
      Hl(),
      (Ul = (e, t) => {
        let n = Xi(t),
          r = ct(t.type);
        if (Ve(t)) return new Pl({ islandConfig: e, config: t });
        if (oe(t)) return new Ma({ islandConfig: e, config: t });
        if (Sn(t)) return new To({ islandConfig: e, config: t });
        switch (n) {
          case `central`:
            return new El({ islandConfig: e, config: t });
          case `spine`:
            return r === pn.Sequential
              ? new zl({ islandConfig: e, config: t })
              : new Ta({ islandConfig: e, config: t });
          case `static`:
          case void 0:
            return new Vl({ islandConfig: e, config: t });
          default:
            return new Vl({ islandConfig: e, config: t });
        }
      });
  }))();
}
var Gl;
function Kl() {
  return (Kl = t(() => {
    R(),
      D(),
      uo(),
      Wl(),
      ni(),
      mi(),
      j(),
      N(),
      L(),
      $(),
      _(),
      Z(),
      (Gl = class extends lo {
        constructor(...e) {
          super(...e), (this._startingLevel = 0), (this._finalLevel = 1);
        }
        prepare() {
          if (
            (this._config.prevXp === void 0
              ? this._config.type === S.AssignmentBuilding
                ? this.setupGift(!0)
                : this.setupGift()
              : ((this._buildingAppearing = this.createBuildingForXp(
                  this._config.prevXp
                )),
                this.itemRef.addChild(this._buildingAppearing)),
            (this._startingLevel = b(
              this._config.type,
              this._config.prevXp
            ).level),
            (this._finalLevel = Math.min(
              b(this._config.type, this._config.xp).level,
              fe(this._config.type) - 1
            )),
            this.shouldShowConfetti)
          ) {
            let e = Math.max(...this._itemSize) / 2;
            (this._confettiEmitter = new Y({
              textures: ui(12),
              config: Si({ radius: e }),
            })),
              this.itemRef.addChild(this._confettiEmitter);
          }
          this.itemRef.itemSpriteRef.prepareAnimateAppear();
        }
        async animate(e, t) {
          let n = () =>
              new Promise((e) => {
                (this._accuracyText = new X(
                  `${Math.floor((this._config.prevXp ?? 0) * 100)}%`,
                  this.getTextStyle()
                )),
                  (this._accuracyText.style.fontSize = 50),
                  (this._accuracyText.resolution = 3),
                  this._accuracyText.anchor.set(0.5, 1),
                  (this._accuracyText.x = 0),
                  (this._accuracyText.y = -(this._itemSize[1] / 2) - 25),
                  (this._accuracyText.name = `accuracyText`),
                  (this._accuracyText.alpha = 0),
                  this.itemRef.addChild(this._accuracyText),
                  (this._accuracyTextTween = O({
                    from: { value: 0 },
                    to: { value: 1 },
                    duration: 250,
                    onTick: ({ value: e }) => {
                      this._accuracyText && (this._accuracyText.alpha = e);
                    },
                    onFinish: e,
                  })),
                  this._accuracyTextTween.play(),
                  (this._correctAnswersText = new X(
                    wn(`correctAnswers`) ?? `Correct answers`,
                    this.getTextStyle()
                  )),
                  (this._correctAnswersText.style.fontSize = 18),
                  (this._correctAnswersText.resolution = 3),
                  this._correctAnswersText.anchor.set(0.5, 1),
                  (this._correctAnswersText.x = 0),
                  (this._correctAnswersText.y = -(this._itemSize[1] / 2) - 11),
                  (this._correctAnswersText.name = `correctAnswersText`),
                  (this._correctAnswersText.alpha = 0),
                  this.itemRef.addChild(this._correctAnswersText),
                  (this._correctAnswersTextTween = O({
                    from: { value: 0 },
                    to: { value: 1 },
                    duration: 250,
                    onTick: ({ value: e }) => {
                      this._correctAnswersText &&
                        (this._correctAnswersText.alpha = e);
                    },
                  })),
                  this._correctAnswersTextTween.play(),
                  (this._kahootNameText = new X(
                    this._config.data.kahootName,
                    this.getTextStyle()
                  )),
                  (this._kahootNameText.style.fontSize = 20),
                  (this._kahootNameText.style.wordWrap = !0),
                  (this._kahootNameText.style.wordWrapWidth = 600),
                  (this._kahootNameText.style.lineHeight = 24),
                  (this._kahootNameText.resolution = 3),
                  this._kahootNameText.anchor.set(0.5, 1),
                  (this._kahootNameText.x = 0),
                  (this._kahootNameText.y = -(this._itemSize[1] / 2) - 80),
                  (this._kahootNameText.name = `kahootName`),
                  this.itemRef.addChild(this._kahootNameText),
                  (this._kahootNameTextTween = O({
                    from: { value: 0 },
                    to: { value: 1 },
                    duration: 250,
                    onTick: ({ value: e }) => {
                      this._kahootNameText && (this._kahootNameText.alpha = e);
                    },
                  })),
                  this._kahootNameTextTween.play();
              }),
            r = () => {
              if (!this._confettiEmitter) return;
              this._confettiEmitter.play(() =>
                this._confettiEmitter?.destroy(!0)
              );
              let e = z(ze) ?? ze[0];
              this.playAndTrackSound(e);
            },
            i = (e, t) =>
              new Promise((n) => {
                if (!this._accuracyText || this._config.xp === void 0) {
                  n();
                  return;
                }
                this._accuracyTextTween?.destroy();
                let i =
                    e > 0
                      ? Math.max(
                          this._config.prevXp ?? 0,
                          this.cumulativelyCalculateExperience(e - 1)
                        )
                      : this._config.prevXp ?? 0,
                  a =
                    e < this._finalLevel
                      ? this.cumulativelyCalculateExperience(e)
                      : this._config.xp;
                (this._accuracyTextTween = O({
                  from: { value: i },
                  to: { value: a },
                  delay: this.gift && e === 0 ? 500 : 0,
                  duration: Math.max((a - i) * 2500, 500),
                  onTick: ({ value: e }) => {
                    this._accuracyText &&
                      (this._accuracyText.text = `${Math.floor(e * 100)}%`);
                  },
                  onFinish: () => n(),
                })),
                  (this._buildingHiding = this._buildingAppearing),
                  this._buildingHiding &&
                    e > this._startingLevel &&
                    ((this._buildingHidingTween = O({
                      from: { scale: 1 },
                      to: { scale: 0 },
                      duration: 300,
                      easing: E.EASE_IN_BACK,
                      onTick: (e) => {
                        this._buildingHiding &&
                          this._buildingHiding.scale.set(e.scale);
                      },
                      onFinish: () => {
                        this._buildingHiding?.destroy(),
                          (this._buildingHiding = void 0);
                      },
                    })),
                    this._buildingHidingTween.play()),
                  e === this._finalLevel
                    ? (this._config.prevXp === void 0 ||
                        (this._finalLevel > 0 &&
                          this._finalLevel > this._startingLevel)) &&
                      (this.timeoutId = window.setTimeout(() => {
                        r(), this.itemRef.itemSpriteRef.animateAppear(t);
                      }, 0))
                    : (e > this._startingLevel ||
                        this._config.prevXp === void 0) &&
                      ((this._buildingAppearing = this.createBuildingForXp(
                        e === this._startingLevel ? i : a
                      )),
                      this.itemRef.addChild(this._buildingAppearing),
                      (this._buildingAppearingTween = O({
                        from: { scale: 0 },
                        to: { scale: 1 },
                        delay: 0,
                        duration: 500,
                        easing: E.EASE_OUT_BACK,
                        onTick: (e) => {
                          this._buildingAppearing &&
                            this._buildingAppearing.scale.set(e.scale);
                        },
                      })),
                      this._buildingAppearingTween.play()),
                  this._accuracyTextTween.play(),
                  e > this._startingLevel &&
                    this.playAndTrackSound(qe, fe(this._config.type) - e);
              });
          await this.animateGift(),
            await n(),
            await (() => {
              let t = this._startingLevel,
                n = () => (
                  t++,
                  t > this._finalLevel ? Promise.resolve() : i(t, e).then(n)
                );
              return i(t, e).then(n);
            })(),
            await new Promise((e) => {
              this.timeoutId = window.setTimeout(e, 300);
            }),
            await new Promise((e) => {
              let t = wn(`feedback`) ?? [];
              (this._feedbackText = new X(
                t[this._finalLevel] ?? ``,
                this.getTextStyle()
              )),
                (this._feedbackText.style.fontSize = 50),
                (this._feedbackText.style.wordWrap = !0),
                (this._feedbackText.style.wordWrapWidth = 600),
                (this._feedbackText.style.lineHeight = 50),
                (this._feedbackText.resolution = 3),
                this._feedbackText.anchor.set(0.5, 0),
                (this._feedbackText.x = 0),
                (this._feedbackText.y = -(this._itemSize[1] / 2) - 80),
                (this._feedbackText.name = `feedbackText`),
                this._feedbackText.scale.set(0),
                this.itemRef.addChild(this._feedbackText),
                (this._feedbackTextTween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: 300,
                  delay: 300,
                  easing: E.EASE_OUT_BACK,
                  onTick: ({ value: e }) => {
                    this._feedbackText && this._feedbackText.scale.set(e);
                  },
                  onFinish: e,
                })),
                this._feedbackTextTween.play(),
                this.shouldShowConfetti || this.playAndTrackSound(Ar),
                (this._correctAnswersTextTween = O({
                  from: { value: 1 },
                  to: { value: 0 },
                  delay: 300,
                  duration: 300,
                  onTick: ({ value: e }) => {
                    this._correctAnswersText &&
                      ((this._correctAnswersText.alpha = e),
                      this._accuracyText && (this._accuracyText.alpha = e));
                  },
                })),
                this._correctAnswersTextTween.play();
            }),
            await new Promise((e) => {
              this.timeoutId = window.setTimeout(e, Ae);
            }),
            new Promise((e) => {
              (this._feedbackTextTween = O({
                from: { value: 1 },
                to: { value: 0 },
                duration: 250,
                onTick: ({ value: e }) => {
                  this._feedbackText && (this._feedbackText.alpha = e);
                },
                onFinish: e,
              })),
                this._feedbackTextTween.play(),
                (this._kahootNameTextTween = O({
                  from: { value: 1 },
                  to: { value: 0 },
                  duration: 250,
                  onTick: ({ value: e }) => {
                    this._kahootNameText && (this._kahootNameText.alpha = e);
                  },
                })),
                this._kahootNameTextTween.play();
            }),
            t?.();
        }
        update(e) {
          this._confettiEmitter?.update(e);
        }
        destroy() {
          super.destroy(),
            this._accuracyText?.destroy(!0),
            (this._accuracyText = void 0),
            this._accuracyTextTween?.destroy(),
            (this._accuracyTextTween = void 0),
            this._correctAnswersText?.destroy(!0),
            (this._correctAnswersText = void 0),
            this._correctAnswersTextTween?.destroy(),
            (this._correctAnswersTextTween = void 0),
            this._feedbackTextTween?.destroy(),
            (this._feedbackTextTween = void 0),
            this._feedbackText?.destroy(!0),
            (this._feedbackText = void 0),
            this._kahootNameTextTween?.destroy(),
            (this._kahootNameTextTween = void 0),
            this._buildingAppearingTween?.destroy(),
            (this._buildingAppearingTween = void 0),
            this._buildingHidingTween?.destroy(),
            (this._buildingHidingTween = void 0),
            this._confettiEmitter?.destroy(!0),
            (this._confettiEmitter = void 0);
        }
        get shouldShowConfetti() {
          return this._finalLevel >= fe(this._config.type) - 2;
        }
        cumulativelyCalculateExperience(e) {
          return _t.slice(0, e + 1).reduce((e, t) => e + t, 0);
        }
        createBuildingForXp(e) {
          return Ul(this.itemRef.islandConfig, { ...this._config, xp: e });
        }
      });
  }))();
}
var ql;
function Jl() {
  return (Jl = t(() => {
    J(),
      di(),
      (ql = (e, t, n, r, i) => {
        let a = ci(e, t);
        if (!a) return;
        let o = e / 2,
          s = t / 2,
          c = a.createRadialGradient(o, s, 1, o, s, n);
        return (
          i.forEach(([e, t]) => {
            c.addColorStop(e, `rgba(0, 0, 0, ${t})`);
          }),
          a.beginPath(),
          (a.fillStyle = r),
          a.fillRect(0, 0, e, t),
          (a.globalCompositeOperation = `destination-out`),
          a.arc(o, s, n, 0, Math.PI * 2, !1),
          (a.fillStyle = c),
          a.fill(),
          U.from(a.canvas, { pixiIdPrefix: `spotlight` })
        );
      });
  }))();
}
var Yl;
function Xl() {
  return (Xl = t(() => {
    Yl = {
      viewportWidth: 500,
      viewportHeight: 500,
      radius: 100,
      addedRadius: 0.25,
      bgColor: `rgba(0, 0, 0, 0.65)`,
      spotlightAlphaRange: [
        [0, 1],
        [0.75, 1],
        [1, 0],
      ],
    };
  }))();
}
var Zl;
function Ql() {
  return (Ql = t(() => {
    J(),
      Xl(),
      Jl(),
      (Zl = class extends B {
        constructor(e) {
          let t = Object.fromEntries(
              Object.entries(e).filter(([, e]) => e !== void 0)
            ),
            n = { ...Yl, ...t },
            r = n.viewportWidth,
            i = n.viewportHeight,
            a = n.radius * (1 + n.addedRadius),
            o = n.bgColor,
            s = n.spotlightAlphaRange,
            c = ql(r, i, a, o, s);
          super(c), this.anchor.set(0.5);
        }
        destroy(e) {
          super.destroy(e);
        }
      });
  }))();
}
function $l() {
  return ($l = t(() => {
    Jl(), Ql();
  }))();
}
var eu, tu;
function nu() {
  return (nu = t(() => {
    D(),
      G(),
      ni(),
      mi(),
      $l(),
      ln(),
      cr(),
      j(),
      N(),
      C(),
      L(),
      $(),
      _(),
      co(),
      (eu = 20),
      (tu = class {
        prepare() {
          if (
            ((this._gift = new so({
              tileCount: Math.min(...this._itemGridSize),
            })),
            this._gift.playIdleAnimation(),
            this._itemRef.addChild(this._gift),
            this._isItemRare)
          ) {
            let e = Math.max(...this._itemSize) / 2;
            (this._confettiEmitter = new Y({
              textures: ui(20),
              config: Si({ radius: e }),
            })),
              this._itemRef.addChild(this._confettiEmitter);
          }
          this._itemSpriteRef.prepareAnimateAppear(),
            this._itemLevelBarRef &&
              (this._itemLevelBarRef.visibility = `hidden`);
        }
        animate(e, t, n) {
          let r = () => {
              if (!this._isItemRare) return;
              let t = Math.max(...this._itemSize) / 2;
              (this._spotlight = new Zl({
                viewportWidth: e.screenWidthInWorldPixels + eu,
                viewportHeight: e.screenHeightInWorldPixels + eu,
                radius: t,
              })),
                (this._spotlight.alpha = 0),
                (this._spotlight.zIndex = vt),
                (this._spotlight.x = this._itemRef.x),
                (this._spotlight.y = this._itemRef.y),
                this._itemRef.parent?.addChild(this._spotlight);
            },
            i = (e) => {
              if (!this._isItemRare) {
                e();
                return;
              }
              this._timeoutId = window.setTimeout(e, en);
            },
            a = () => {
              this._spotlight &&
                (this._spotlightTween?.destroy(),
                (this._spotlightTween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: Nt,
                  easing: E.EASE_OUT_SINE,
                  onTick: ({ value: e }) => {
                    this._spotlight &&
                      (this._spotlight.scale.set(w(1.2, 1, e)),
                      (this._spotlight.alpha = e));
                  },
                })),
                this._spotlightTween.play());
            },
            o = () => {
              this._spotlight &&
                (this._spotlightTween?.destroy(),
                (this._spotlightTween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: Et,
                  easing: E.EASE_OUT_SINE,
                  onTick: ({ value: e }) => {
                    this._spotlight &&
                      ((this._spotlight.alpha = 1 - e),
                      this._spotlight.scale.set(w(1, 2, e)));
                  },
                })),
                this._spotlightTween.play());
            },
            s = (e) => {
              this._gift?.playOpeningAnimation(),
                (this._drumrollSound = this.playAndTrackSound(Ce)),
                (this._drumrollSoundInitialVolume =
                  this._drumrollSound?.volume ?? 1);
              let t = this._isItemRare ? Ne : At;
              this._timeoutId = window.setTimeout(() => {
                this._gift?.playOpenAnimation(),
                  this._drumrollSound?.fade(this._drumrollSound.volume, 0, 500);
                let t = z(this._isItemRare ? ze : je);
                t && this.playAndTrackSound(t), e();
              }, t);
            },
            c = (e) => {
              this._timeoutId = window.setTimeout(e, 500);
            },
            l = () => {
              this._confettiEmitter?.play(() =>
                this._confettiEmitter?.destroy(!0)
              );
            },
            u = () => {
              this._itemLevelBarRef &&
                this._itemLevelBarRef.animateVisibility(`hidden`),
                this._itemNameRef?.animateHide(),
                n?.();
            };
          i(() => {
            r(),
              a(),
              s(() => {
                o(),
                  c(() => {
                    l(),
                      this._itemNameRef?.animateShow(),
                      this._itemSpriteRef.animateAppear(t, u);
                  });
              });
          });
        }
        constructor(e) {
          (this._sounds = []),
            (this._drumrollSoundInitialVolume = 1),
            (this._timeoutId = -1),
            (this._itemRef = e);
        }
        update(e) {
          this._confettiEmitter?.update(e);
        }
        destroy() {
          clearTimeout(this._timeoutId),
            this._spotlightTween?.destroy(),
            this._gift?.destroy(),
            (this._gift = void 0),
            this._spotlight?.destroy(!0),
            (this._spotlight = void 0),
            this._confettiEmitter?.destroy(!0),
            (this._confettiEmitter = void 0),
            this._drumrollSound &&
              (this._drumrollSound.volume = this._drumrollSoundInitialVolume),
            this._sounds.forEach((e) => e.stop()),
            (this._sounds = []);
        }
        get _itemType() {
          return this._itemRef.config.type;
        }
        get _itemGridSize() {
          return Bn(this._itemType);
        }
        get _itemSize() {
          return A(this._itemType);
        }
        get _isItemRare() {
          return tr(this._itemType);
        }
        get _itemSpriteRef() {
          return this._itemRef.itemSpriteRef;
        }
        get _itemLevelBarRef() {
          return this._itemRef.levelBarRef;
        }
        get _itemNameRef() {
          return this._itemRef.itemNameRef;
        }
        playAndTrackSound(e) {
          let t = q.instance.getResourceSound(e);
          if (t) return t.play(), this._sounds.push(t), t;
        }
      });
  }))();
}
var ru, iu, au;
function ou() {
  return (ou = t(() => {
    J(),
      W(),
      D(),
      G(),
      F(),
      $(),
      (ru = `default`),
      (iu = `BASE`),
      (au = class extends H {
        constructor(e) {
          super();
          let t = q.instance.getResourceSpine(Wt);
          if (!t) return;
          let n = new K(t.spineData);
          n.skeleton.setSkinByName(ru);
          let r = n.state.data.skeletonData.animations
            .map((e) => e.name)
            .filter((e) => e.includes(iu));
          if (r.length === 0) {
            console.warn(`No animations found for decoration`);
            return;
          }
          let i = z(r, k(e));
          if (!i) {
            console.warn(`Failed to select an animation for decoration`);
            return;
          }
          n.state.setAnimation(0, i, !0),
            (n.state.timeScale = Hn()(0.8, 1.2)),
            this.addChild(n);
        }
      });
  }))();
}
var su;
function cu() {
  return (cu = t(() => {
    J(),
      xi(),
      G(),
      ni(),
      j(),
      N(),
      C(),
      L(),
      $(),
      (su = class {
        prepare() {
          let e = q.instance.getResourceTexture(x, !1),
            t = q.instance.getResourceJSON(lt, !1);
          if (e && t) {
            let n = t;
            (n.emitterLifetime =
              Math.max(10, this._itemLeaguePoints * 0.3) * n.frequency),
              (this._pointsEmitter = new Y({ textures: [e], config: n })),
              this._itemRef.addChildAt(this._pointsEmitter, 0);
          }
          let n = new Rr(`+${this._itemLeaguePoints}`);
          (n.style = {
            fontFamily: `Grandstander`,
            fontSize: 70,
            fontWeight: `700`,
            fill: `white`,
          }),
            (n.resolution = 2),
            n.anchor.set(0, 0.5),
            (n.filters = [
              new bi({
                distance: 20,
                outerStrength: 10,
                innerStrength: 0,
                alpha: 0.5,
                color: 9107704,
              }),
            ]);
          let r = new B(e);
          (r.x = n.width + 40),
            r.anchor.set(0.5),
            (this._pointsContainer = new H()),
            this._pointsContainer.addChild(n, r),
            (this._pointsContainer.x = -this._pointsContainer.width / 2 + 20),
            (this._pointsContainer.y = -(this._itemRef.height / 2)),
            (this._pointsContainer.alpha = 0),
            (this._pointsContainer.visible = !1),
            this._itemRef.addChild(this._pointsContainer);
        }
        animate(e) {
          let t = () => {
              (this._pointsSound = this.playAndTrackSound(gr)),
                this._pointsEmitter?.play(() => {
                  this._pointsSound?.stop(),
                    clearTimeout(this._pointsEmitterTimeoutId);
                }),
                (this._pointsEmitterTimeoutId = window.setTimeout(() => {
                  this._pointsSound?.stop(), this._pointsEmitter?.stop();
                }, Ct));
            },
            n = (e) => {
              if (!this._shouldDisplayTexts) {
                this._textTimeoutId = window.setTimeout(e, Te);
                return;
              }
              let t = this._pointsContainer?.y ?? 0;
              this._pointsContainer && (this._pointsContainer.visible = !0),
                (this._textTween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: Te,
                  easing: E.EASE_OUT_CUBIC,
                  onTick: ({ value: e }) => {
                    this._pointsContainer &&
                      ((this._pointsContainer.alpha = e),
                      (this._pointsContainer.scale.y = w(
                        0,
                        1,
                        Math.min(1, e * 2)
                      )),
                      (this._pointsContainer.y = w(t, t - 128 / 4, e)));
                  },
                  onFinish: e,
                })),
                this._textTween.play();
            },
            r = () => {
              this._shouldDisplayTexts &&
                (this._textTween?.destroy(),
                (this._textTween = O({
                  from: { value: 1 },
                  to: { value: 0 },
                  duration: Ie,
                  easing: E.EASE_IN_SINE,
                  onTick: ({ value: e }) => {
                    this._pointsContainer && (this._pointsContainer.alpha = e);
                  },
                })),
                this._textTween.play());
            };
          t(),
            n(() => {
              e?.(), r();
            });
        }
        constructor(e) {
          (this._sounds = []),
            (this._pointsEmitterTimeoutId = -1),
            (this._textTimeoutId = -1),
            (this._itemRef = e);
        }
        update(e) {
          this._pointsEmitter?.update(e);
        }
        destroy() {
          clearTimeout(this._pointsEmitterTimeoutId),
            clearTimeout(this._textTimeoutId),
            this._pointsEmitter?.destroy(),
            this._pointsContainer?.destroy({ children: !0 }),
            this._textTween?.destroy(),
            this._sounds.forEach((e) => e.stop()),
            (this._sounds = []);
        }
        get _shouldDisplayTexts() {
          return (
            this._itemRef.islandConfig.leaguesConfig?.isParticipating ?? !1
          );
        }
        get _itemLeaguePoints() {
          return this._itemRef.config.leaguePoints ?? 0;
        }
        playAndTrackSound(e) {
          let t = q.instance.getResourceSound(e, !1);
          if (t) return t.play(), this._sounds.push(t), t;
        }
      });
  }))();
}
var lu, uu;
function du() {
  return (du = t(() => {
    J(),
      za(),
      G(),
      j(),
      N(),
      C(),
      $(),
      (lu = 0.3),
      (uu = class extends H {
        get type() {
          return this._type;
        }
        hide() {
          this.visible && ((this.visible = !1), this.clearTween());
        }
        show() {
          this.visible ||
            ((this.visible = !0),
            this.clearTween(),
            (this._tween = O({
              from: { value: 0 },
              to: { value: 1 },
              duration: 500,
              easing: E.EASE_IN_OUT_EXPO,
              onTick: ({ value: e }) => (this.alpha = e),
              onFinish: () => this.animate(),
            })),
            this._tween?.play());
        }
        constructor(e) {
          super(), (this._type = e);
          let t = e === `important` ? Jn : Le;
          (this._icon = new B(q.instance.getResourceTexture(t))),
            this._icon.anchor.set(0.5),
            this.addChild(this._icon),
            (this._iconFilter = new Ra(16777215, 0)),
            (this._icon.filters = [this._iconFilter]),
            this.animate();
        }
        destroy(e) {
          this.clearTween(), super.destroy(e);
        }
        clearTween() {
          this._tween?.destroy(), (this._tween = void 0);
        }
        animate() {
          this.clearTween(),
            this._type === `gift`
              ? (this._tween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: 2500,
                  delay: 2e3,
                  onTick: ({ value: e }) => {
                    if (!(e < 0.8)) {
                      if (e < 0.9) {
                        let t = Ke(0.8, 0.9, e);
                        this._iconFilter.alpha = w(0, lu, t);
                      }
                      if (e >= 0.9) {
                        let t = Ke(0.9, 1, e);
                        this._iconFilter.alpha = w(lu, 0, t);
                      }
                    }
                  },
                  onFinish: () => {
                    this._tween?.play();
                  },
                }))
              : this._type === `important` &&
                (this._tween = O({
                  from: { value: 0 },
                  to: { value: 1 },
                  duration: 2500,
                  delay: 2e3,
                  easing: E.EASE_IN_OUT_EXPO,
                  onTick: ({ value: e }) => {
                    if (!(e < 0.8)) {
                      if (e < 0.9) {
                        let t = Ke(0.8, 0.9, e),
                          n = w(1, 1.23, t),
                          r = w(0, lu, t);
                        this._icon.scale.set(n), (this._iconFilter.alpha = r);
                      }
                      if (e >= 0.9) {
                        let t = Ke(0.9, 1, e),
                          n = w(1.23, 1, t),
                          r = w(lu, 0, t);
                        this._icon.scale.set(n), (this._iconFilter.alpha = r);
                      }
                    }
                  },
                  onFinish: () => {
                    this._tween?.play();
                  },
                })),
            this._tween?.play();
        }
      });
  }))();
}
var fu;
function pu() {
  return (pu = t(() => {
    G(),
      L(),
      $(),
      _(),
      (fu = class {
        get _itemConfig() {
          return this._itemRef.config;
        }
        get _itemLevelBarRef() {
          return this._itemRef.levelBarRef;
        }
        get _itemNameRef() {
          return this._itemRef.itemNameRef;
        }
        constructor(e) {
          (this._sounds = []),
            (this._auxTimeoutId = -1),
            (this._itemRef = e),
            (this._itemSpriteSequential = e.itemSpriteRef),
            (this._itemLevelProgress = b(
              this._itemConfig.type,
              this._itemConfig.xp
            )),
            (this._prevItemLevelProgress = b(
              this._itemConfig.type,
              (this._itemConfig.xp ?? 0) - 1
            ));
        }
        prepare() {
          this._itemLevelBarRef &&
            ((this._itemLevelBarRef.level = this._prevItemLevelProgress.level),
            (this._itemLevelBarRef.levelsCount =
              this._prevItemLevelProgress.levelsCount),
            (this._itemLevelBarRef.progress =
              this._prevItemLevelProgress.progress)),
            this._itemSpriteSequential.gotoCurrentStep(),
            (this._soundProgress = this.getAndTrackSound(mn));
        }
        animate(e) {
          let t = (e) => {
              if (!this._itemLevelBarRef) {
                e?.();
                return;
              }
              this._auxTimeoutId = window.setTimeout(e, 500);
            },
            n = (e) => {
              if (!this._itemLevelBarRef) {
                e();
                return;
              }
              this._soundProgress?.play(),
                this._itemLevelBarRef.animateProgress(1, () => {
                  if ((this._soundProgress?.stop(), !this._itemLevelBarRef)) {
                    e();
                    return;
                  }
                  (this._itemLevelBarRef.level = this._itemLevelProgress.level),
                    (this._itemLevelBarRef.levelsCount =
                      this._itemLevelProgress.levelsCount),
                    e(),
                    this._itemLevelProgress.level <
                      this._itemLevelProgress.levelsCount - 1 &&
                      (this._itemLevelBarRef.progress = 0),
                    this._itemLevelProgress.progress > 0 &&
                      (this._soundProgress?.play(),
                      this._itemLevelBarRef.animateProgress(
                        this._itemLevelProgress.progress,
                        () => {
                          this._soundProgress?.stop();
                        }
                      ));
                });
            },
            r = (e) => {
              this._auxTimeoutId = window.setTimeout(() => {
                e?.();
              }, rt);
            },
            i = () => {
              this._itemNameRef?.animateHide(),
                this._itemLevelBarRef?.animateVisibility(`hidden`),
                this.destroy(),
                e?.();
            };
          this._itemLevelBarRef?.animateVisibility(`visible`),
            this._itemNameRef?.animateShow(),
            t(() =>
              n(() => {
                this.getAndTrackSound(qe)?.play(),
                  this._itemSpriteSequential?.playItemEvolution(!1, () => r(i));
              })
            );
        }
        destroy() {
          clearTimeout(this._auxTimeoutId),
            this._tween?.destroy(),
            this._itemSpriteSequential?.stopSequencePlayback();
        }
        getAndTrackSound(e) {
          let t = q.instance.getResourceSound(e);
          if (t) return this._sounds.push(t), t;
        }
      });
  }))();
}
var mu;
function hu() {
  return (hu = t(() => {
    mu = class {
      prepare() {
        this._itemRef.toggleDecorationVisibility(!1),
          this._itemSpriteRef.prepareAnimateAppear();
      }
      animate(e) {
        this._itemRef.toggleDecorationVisibility(!0),
          this._itemSpriteRef.animateAppear(void 0, e);
      }
      constructor(e) {
        this._itemRef = e;
      }
      destroy() {}
      get _itemSpriteRef() {
        return this._itemRef.itemSpriteRef;
      }
    };
  }))();
}
var gu;
function _u() {
  return (_u = t(() => {
    za(),
      G(),
      j(),
      N(),
      C(),
      L(),
      $(),
      _(),
      Wl(),
      (gu = class {
        prepare() {
          this.shouldAnimateLevelUp
            ? ((this._prevItemSprite = Ul(this._islandConfig, {
                ...this._itemConfig,
                xp: this._prevItemLevelProgress.xp,
              })),
              this._itemSpriteRef.parent.addChild(this._prevItemSprite),
              (this._prevItemFilter = new Ra(16777215, 0)),
              (this._prevItemSprite.filters = [this._prevItemFilter]),
              this._itemSpriteRef.prepareAnimateLevelUp())
            : this._itemSpriteRef.prepareAnimateProgressUp(),
            this._itemLevelBarRef &&
              ((this._itemLevelBarRef.level =
                this._prevItemLevelProgress.level),
              (this._itemLevelBarRef.levelsCount =
                this._prevItemLevelProgress.levelsCount),
              (this._itemLevelBarRef.progress =
                this._prevItemLevelProgress.progress)),
            (this._soundProgress = this.getAndTrackSound(mn));
        }
        animate(e, t) {
          let n = (e) => {
              if (!this._itemLevelBarRef) {
                e?.();
                return;
              }
              this._auxTimeoutId = window.setTimeout(e, 500);
            },
            r = (e) => {
              if (!this._itemLevelBarRef) {
                e();
                return;
              }
              this._soundProgress?.play();
              let t = this.shouldAnimateLevelUp
                ? 1
                : this._itemLevelProgress.progress;
              this._itemLevelBarRef.animateProgress(t, () => {
                if ((this._soundProgress?.stop(), !this._itemLevelBarRef)) {
                  e();
                  return;
                }
                this._itemLevelBarRef.level !== this._itemLevelProgress.level &&
                  ((this._itemLevelBarRef.visibility = `hidden`),
                  (this._itemLevelBarRef.level = this._itemLevelProgress.level),
                  this._itemLevelBarRef.animateVisibility(`visible`)),
                  (this._itemLevelBarRef.levelsCount =
                    this._itemLevelProgress.levelsCount),
                  e(),
                  this.shouldAnimateLevelUp &&
                    (this._itemLevelProgress.level <
                      this._itemLevelProgress.levelsCount - 1 &&
                      (this._itemLevelBarRef.progress = 0),
                    this._itemLevelProgress.progress > 0 &&
                      (this._soundProgress?.play(),
                      this._itemLevelBarRef.animateProgress(
                        this._itemLevelProgress.progress,
                        () => {
                          this._soundProgress?.stop();
                        }
                      )));
              });
            },
            i = (e) => {
              (this._tween = O({
                from: { value: 0 },
                to: { value: 1 },
                duration: 1e3,
                onTick: ({ value: e }) => {
                  this._prevItemFilter && (this._prevItemFilter.alpha = e);
                },
                onFinish: () => {
                  e();
                },
              })),
                this._tween.play();
            },
            a = () => {
              (this._tween = O({
                from: { value: 0 },
                to: { value: 1 },
                duration: 500,
                easing: E.EASE_OUT_EXPO,
                onTick: ({ value: e }) => {
                  this._prevItemSprite &&
                    (this._prevItemSprite.scale.set(w(1, 2, e)),
                    (this._prevItemSprite.alpha = 1 - e));
                },
              })),
                this._tween.play();
            },
            o = () => {
              this._itemLevelBarRef?.animateVisibility(`hidden`),
                this.destroy(),
                t?.();
            };
          this._itemLevelBarRef?.animateVisibility(`visible`),
            this._itemNameRef?.animateShow(),
            n(() =>
              r(() => {
                if (
                  (this._itemNameRef?.animateHide(), !this.shouldAnimateLevelUp)
                ) {
                  this.getAndTrackSound(tt)?.play(),
                    this._itemSpriteRef.animateProgressUp(e, o);
                  return;
                }
                this.getAndTrackSound(qe)?.play(),
                  this.getAndTrackSound(zt)?.play(),
                  i(() => {
                    a(), this._itemSpriteRef.animateLevelUp(e, o);
                  });
              })
            );
        }
        constructor(e) {
          (this._sounds = []),
            (this._auxTimeoutId = -1),
            (this._itemRef = e),
            (this._itemLevelProgress = b(
              this._itemConfig.type,
              this._itemConfig.xp
            )),
            (this._prevItemLevelProgress = b(
              this._itemConfig.type,
              (this._itemConfig.xp ?? 0) - 1
            ));
        }
        destroy() {
          clearTimeout(this._auxTimeoutId),
            this._tween?.destroy(),
            this._prevItemSprite?.destroy(),
            (this._prevItemSprite = void 0),
            this._prevItemFilter?.destroy(),
            (this._prevItemFilter = void 0);
        }
        get shouldAnimateLevelUp() {
          return (
            this._itemLevelProgress.level > this._prevItemLevelProgress.level
          );
        }
        get _islandConfig() {
          return this._itemRef.islandConfig;
        }
        get _itemConfig() {
          return this._itemRef.config;
        }
        get _itemSpriteRef() {
          return this._itemRef.itemSpriteRef;
        }
        get _itemLevelBarRef() {
          return this._itemRef.levelBarRef;
        }
        get _itemNameRef() {
          return this._itemRef.itemNameRef;
        }
        getAndTrackSound(e) {
          let t = q.instance.getResourceSound(e);
          if (t) return this._sounds.push(t), t;
        }
      });
  }))();
}
var vu, yu, bu, xu, Su, Cu;
function wu() {
  return (wu = t(() => {
    N(),
      L(),
      $(),
      _(),
      Z(),
      fa(),
      (vu = -5),
      (yu = -35),
      (bu = 10),
      (xu = 10),
      (Su = 4325306),
      (Cu = class extends da {
        get level() {
          return this._level;
        }
        set level(e) {
          (this._level = e),
            (this._currentLevelText.text = (
              wn(`level`) ?? `Level {currentLevel}`
            ).replace(`{currentLevel}`, (this._level + 1).toString()));
        }
        get levelsCount() {
          return this._levelsCount;
        }
        set levelsCount(e) {
          this._levelsCount = e;
        }
        set visibility(e) {
          switch ((this._tweenBarVisibility?.stop(), e)) {
            case `hidden`:
              this.barContainer.alpha = 0;
              break;
            case `visible`:
              this.barContainer.alpha = 1;
          }
        }
        animateVisibility(e) {
          if (
            (this._tweenBarVisibility?.stop(),
            e === `visible` && this._level >= this._levelsCount - 1)
          )
            return;
          let t = (e) => {
            let t = +!!e;
            return O({
              from: { value: this.barContainer.alpha },
              to: { value: t },
              delay: e ? 200 : 0,
              duration: 500,
              onTick: ({ value: e }) => {
                this.barContainer.alpha = e;
              },
            });
          };
          switch (e) {
            case `hidden`:
              this._tweenBarVisibility = t(!1);
              break;
            case `visible`:
              this._tweenBarVisibility = t(!0);
          }
          this._tweenBarVisibility?.play();
        }
        animateProgress(e, t) {
          this._tweenProgress?.stop();
          let n = this.progress;
          e >= 1 && (this.allowFullFill = !0),
            (this._tweenProgress = O({
              from: { value: n },
              to: { value: e },
              duration: qn,
              onTick: ({ value: e }) => {
                this.progress = e;
              },
              onFinish: () => {
                (this.allowFullFill = !1), (this.progress = e), t?.();
              },
            })),
            this._tweenProgress.play();
        }
        constructor(e) {
          let {
              level: t = 0,
              progress: n = 0,
              levelsCount: r = 0,
              isRtl: i,
            } = e,
            a = 256 + bu;
          super({
            isRtl: i,
            barWidth: a,
            barHeight: 40,
            progressFillOffset: xu,
          }),
            (this._level = 0),
            (this._levelsCount = 0),
            (this.barContainer.y = yu),
            (this.barContainer.x = -128 + vu),
            (this._currentLevelText = this.createCurrentLevelText()),
            this._currentLevelText.anchor.set(0.5, 0.5),
            (this._currentLevelText.x = this.barContainer.width / 2),
            (this._currentLevelText.y = 40 / 2),
            this.barContainer.addChild(this._currentLevelText),
            (this.progressSprite.tint = Su),
            (this.level = t),
            (this.levelsCount = r),
            (this.progress = n);
        }
        destroy(e) {
          this._tweenBarVisibility?.destroy(),
            this._tweenProgress?.destroy(),
            super.destroy(e);
        }
        createCurrentLevelText() {
          let e = new X();
          return (
            (e.style = {
              fontFamily: `Grandstander`,
              fontSize: 20,
              fontWeight: `700`,
              fill: `white`,
              dropShadow: !0,
              dropShadowColor: `black`,
              dropShadowDistance: 0,
              dropShadowAngle: 90,
              dropShadowAlpha: 1,
              dropShadowBlur: 3,
            }),
            (e.resolution = 2),
            e
          );
        }
      });
  }))();
}
var Tu, Eu, Du, Ou;
function ku() {
  return (ku = t(() => {
    J(),
      R(),
      wr(),
      mo(),
      cr(),
      F(),
      L(),
      pr(),
      _(),
      Kl(),
      nu(),
      ou(),
      cu(),
      Al(),
      du(),
      pu(),
      Wl(),
      hu(),
      _u(),
      wu(),
      (Tu = -35),
      (Eu = 10),
      (Du = new Set([
        S.CentralSquare,
        S.Decoration,
        S.BasicBuilding,
        S.AssignmentBuilding,
      ])),
      (Ou = class extends H {
        get config() {
          return this._config;
        }
        get islandConfig() {
          return this._islandConfig;
        }
        get isSelected() {
          return this._selected;
        }
        get isSelectable() {
          return Yt(this._type);
        }
        get interactionType() {
          return this.isSelectable
            ? this.eventMode === `passive`
              ? `only-children`
              : this.eventMode === `static`
              ? `full`
              : `none`
            : `none`;
        }
        set interactionType(e) {
          if (!this.isSelectable) {
            super.eventMode = `none`;
            return;
          }
          e === `only-children`
            ? (super.eventMode = `passive`)
            : e === `full`
            ? (super.eventMode = `static`)
            : (super.eventMode = `none`);
        }
        get shouldAnimateAppear() {
          return [
            S.BasicBuilding,
            S.AssignmentBuilding,
            S.LeagueTrophy,
          ].includes(this._type)
            ? !!this._config.animateAppear
            : _n(this._type)
            ? !!this._config.animateAppear && this._config.xp === 0
            : !!this._config.animateAppear && !yr(this._type, this._config.xp);
        }
        get shouldAnimateLeaguePoints() {
          return (
            !!this._islandConfig.leaguesConfig?.canParticipate &&
            (this._config.leaguePoints ?? 0) > 0
          );
        }
        get shouldAnimateCreation() {
          return !this.shouldAnimateAppear ||
            this._type === S.BasicBuilding ||
            this._type === S.AssignmentBuilding
            ? !1
            : !this._config.xp || this._type === S.LeagueTrophy;
        }
        get shouldAnimateBasicBuilding() {
          return this.shouldAnimateAppear
            ? this._type === S.BasicBuilding ||
                (this._type === S.AssignmentBuilding &&
                  !this.isAssignmentInProgress)
            : !1;
        }
        get shouldAnimateAssignmentInProgress() {
          return this.shouldAnimateAppear
            ? this._type === S.AssignmentBuilding && this.isAssignmentInProgress
            : !1;
        }
        get shouldAnimateSequentialUpgrade() {
          return this.shouldAnimateAppear
            ? !!this._config.xp && ct(this._type) === pn.Sequential
            : !1;
        }
        get shouldAnimateUpgrade() {
          return !this.shouldAnimateAppear ||
            this._type === S.BasicBuilding ||
            this._type === S.AssignmentBuilding ||
            this._type === S.LeagueTrophy ||
            _n(this._type)
            ? !1
            : !!this._config.xp && ct(this._type) === pn.Upgradable;
        }
        get shouldAnimateTimeLapse() {
          return this._islandConfig.initialAnimationStyle === `timeLapse`;
        }
        get tileCountX() {
          return Bn(this._type)[0];
        }
        get width() {
          return A(this._type)[0];
        }
        set width(e) {
          throw Error(`Item width is read-only`);
        }
        get tileCountY() {
          return Bn(this._type)[1];
        }
        get height() {
          return A(this._type)[1];
        }
        set height(e) {
          throw Error(`Item height is read-only`);
        }
        get itemSpriteRef() {
          return this._itemSprite;
        }
        get levelBarRef() {
          return this._levelBar;
        }
        get itemNameRef() {
          return this._itemName;
        }
        select(e) {
          !this.isSelectable ||
            this._selected ||
            ((this._selected = !0),
            this.bringToFront(),
            this._itemSprite.select(e),
            e
              ? (this._levelBar?.animateVisibility(`visible`),
                this._itemName?.animateShow())
              : (this._levelBar && (this._levelBar.visibility = `visible`),
                this._itemName && (this._itemName.show = !0)));
        }
        deselect(e, t) {
          !this.isSelectable ||
            !this._selected ||
            ((this._selected = !1),
            this.restoreOriginalZIndex(t),
            this._itemSprite.deselect(e),
            e
              ? (this._levelBar?.animateVisibility(`hidden`),
                this._itemName?.animateHide())
              : (this._levelBar && (this._levelBar.visibility = `hidden`),
                this._itemName && (this._itemName.show = !1)));
        }
        hasNotification(e) {
          return this._notificationIcon?.type === e;
        }
        dismissNotification() {
          this._notificationIcon &&=
            (this._notificationIcon.destroy({ children: !0 }), void 0);
        }
        constructor(e) {
          if (
            (super(),
            (this._originalZIndex = 0),
            (this._itemDecorations = []),
            (this._animateAppearClearTimeoutId = -1),
            (this._deselectDelayTimeoutId = -1),
            (this._selected = !1),
            (this._islandConfig = e.islandConfig),
            (this._config = e.config),
            (this.zIndex = this._originalZIndex = e.zIndex),
            this.isSelectable
              ? ((this.hitArea = new V(
                  -this.width / 2,
                  -this.height / 2,
                  this.width,
                  this.height
                )),
                (super.eventMode = `static`),
                (this.cursor = `pointer`))
              : (super.eventMode = `none`),
            this.addDecoration(),
            (this._itemSprite = Ul(this._islandConfig, this._config)),
            this.addChild(this._itemSprite),
            this._showLevel)
          ) {
            let {
              level: t,
              progress: n,
              levelsCount: r,
            } = b(this._type, this._config.xp);
            (this._levelBar = new Cu({
              level: t,
              levelsCount: r,
              progress: n,
              isRtl: e.isRtl,
            })),
              (this._levelBar.visibility = `hidden`),
              (this._levelBar.y = -this.height / 2),
              this.addChild(this._levelBar);
          }
          this._showName &&
            ((this._itemName = new kl(Ut(this._type))),
            (this._itemName.y = -this.height / 2 + Tu),
            this.addChild(this._itemName)),
            this._islandConfig.initialAnimationStyle !== `timeLapse` &&
              this.addNotificationIcon(),
            (this.name = `${this._config.type}_${this.config.gridPosition[0]}_${this.config.gridPosition[1]}`);
        }
        toggleDecorationVisibility(e) {
          this._itemDecorations.forEach((t) => (t.visible = e));
        }
        prepareAnimateAppear() {
          if (this.shouldAnimateTimeLapse) {
            (this._itemTimeLapseAnim = new mu(this)),
              this._itemTimeLapseAnim.prepare();
            return;
          }
          if (!(!this.shouldAnimateAppear && !this.shouldAnimateLeaguePoints)) {
            if (
              (this._notificationIcon?.hide(),
              this.shouldAnimateLeaguePoints &&
                ((this._itemLeaguePointsAnim = new su(this)),
                this._itemLeaguePointsAnim.prepare()),
              this.shouldAnimateCreation)
            ) {
              (this._itemCreateAnim = new tu(this)),
                this._itemCreateAnim.prepare();
              return;
            }
            if (this.shouldAnimateBasicBuilding) {
              (this._itemBasicBuildingAnimation = new Gl(this)),
                this._itemBasicBuildingAnimation.prepare();
              return;
            }
            if (this.shouldAnimateAssignmentInProgress) {
              (this._itemAssignmentInProgressAnimation = new po(this)),
                this._itemAssignmentInProgressAnimation.prepare();
              return;
            }
            if (this.shouldAnimateSequentialUpgrade) {
              (this._itemSequentialUpgradeAnimation = new fu(this)),
                this._itemSequentialUpgradeAnimation.prepare();
              return;
            }
            if (this.shouldAnimateUpgrade) {
              (this._itemUpgradeAnim = new gu(this)),
                this._itemUpgradeAnim.prepare();
              return;
            }
          }
        }
        animateAppear(e, t, n) {
          if (
            !this.shouldAnimateAppear &&
            !this.shouldAnimateLeaguePoints &&
            !this.shouldAnimateTimeLapse
          ) {
            n?.();
            return;
          }
          this.bringToFront();
          let r = () => {
            this.restoreOriginalZIndex(),
              n?.(),
              (this._animateAppearClearTimeoutId = window.setTimeout(() => {
                this._itemLeaguePointsAnim?.destroy(),
                  (this._itemLeaguePointsAnim = void 0),
                  this._itemCreateAnim?.destroy(),
                  (this._itemCreateAnim = void 0),
                  this._itemBasicBuildingAnimation?.destroy(),
                  (this._itemBasicBuildingAnimation = void 0),
                  this._itemAssignmentInProgressAnimation?.destroy(),
                  (this._itemAssignmentInProgressAnimation = void 0),
                  this._itemSequentialUpgradeAnimation?.destroy(),
                  (this._itemSequentialUpgradeAnimation = void 0),
                  this._itemUpgradeAnim?.destroy(),
                  (this._itemUpgradeAnim = void 0),
                  this._itemTimeLapseAnim?.destroy(),
                  (this._itemTimeLapseAnim = void 0);
              }, bt));
          };
          if (this.shouldAnimateTimeLapse) {
            this._itemTimeLapseAnim?.animate(r);
            return;
          }
          let i = () => {
            if (
              !this.shouldAnimateLeaguePoints ||
              !this._itemLeaguePointsAnim
            ) {
              r();
              return;
            }
            this._itemLeaguePointsAnim.animate(r);
          };
          if (this.shouldAnimateCreation && this._itemCreateAnim && e) {
            this.bringToFront(),
              t?.(`about-to-create`),
              this._itemCreateAnim.animate(e, () => t?.(`create`), i);
            return;
          }
          if (
            this.shouldAnimateBasicBuilding &&
            this._itemBasicBuildingAnimation
          ) {
            this.bringToFront(),
              this._itemBasicBuildingAnimation.animate(
                () => t?.(this._config.prevXp ? `upgrade` : `create`),
                i
              );
            return;
          }
          if (
            this.shouldAnimateAssignmentInProgress &&
            this._itemAssignmentInProgressAnimation
          ) {
            this.bringToFront(),
              this._itemAssignmentInProgressAnimation.animate(
                () => t?.(this._config.prevXp ? `upgrade` : `create`),
                i
              );
            return;
          }
          if (
            this.shouldAnimateSequentialUpgrade &&
            this._itemSequentialUpgradeAnimation
          ) {
            this.bringToFront(),
              this._itemSequentialUpgradeAnimation.animate(i);
            return;
          }
          if (this.shouldAnimateUpgrade && this._itemUpgradeAnim) {
            this.bringToFront(),
              this._itemUpgradeAnim.animate(() => t?.(`upgrade`), i);
            return;
          }
          i();
        }
        cleanUpAnimateAppear() {
          this._notificationIcon?.show();
        }
        update(e) {
          this._itemLeaguePointsAnim?.update(e),
            this._itemCreateAnim?.update(e),
            this._itemBasicBuildingAnimation?.update(e);
        }
        destroy(e) {
          this._itemLeaguePointsAnim?.destroy(),
            this._itemCreateAnim?.destroy(),
            this._itemUpgradeAnim?.destroy(),
            this._itemSequentialUpgradeAnimation?.destroy(),
            this._itemBasicBuildingAnimation?.destroy(),
            this._itemSprite.destroy(),
            clearTimeout(this._animateAppearClearTimeoutId),
            clearTimeout(this._deselectDelayTimeoutId),
            super.destroy(e);
        }
        get isAssignmentInProgress() {
          return (
            !!this._config.data &&
            `status` in this._config.data &&
            this._config.data.status === `in-progress`
          );
        }
        get _type() {
          return this._config.type;
        }
        get _showLevel() {
          return (
            jn(this._type) &&
            !_n(this._type) &&
            !Du.has(this._type) &&
            !yr(this._type, this._config.xp)
          );
        }
        get _showName() {
          return !Du.has(this._type);
        }
        bringToFront() {
          clearTimeout(this._deselectDelayTimeoutId), (this.zIndex = De);
        }
        restoreOriginalZIndex(e = 0) {
          if ((clearTimeout(this._deselectDelayTimeoutId), e <= 0)) {
            this.zIndex = this._originalZIndex;
            return;
          }
          this._deselectDelayTimeoutId = window.setTimeout(() => {
            this.zIndex = this._originalZIndex;
          }, e);
        }
        addDecoration() {
          if (!xn(this._config.type)) return;
          let e = new H();
          this.addChild(e);
          let t = -this.width / 2 + 128 / 2,
            n = this.height / 2 - 128 / 2,
            r = [];
          for (let e = 0; e < this.tileCountX; e++)
            for (let i = 0; i < this.tileCountY; i++)
              r.push([t + e * 128, n - i * 128]);
          or(r, Math.floor(r.length * 0.75), k(this._config.seed)).forEach(
            ([t, n]) => {
              let r = new au(dr(t, n) + this._config.seed);
              r.position.set(t, n),
                this._itemDecorations.push(r),
                e.addChild(r);
            }
          );
        }
        addNotificationIcon() {
          this._config.notificationType &&
            ((this._notificationIcon = new uu(this._config.notificationType)),
            (this._notificationIcon.y = -this.height / 2 + Eu),
            this.addChild(this._notificationIcon));
        }
      });
  }))();
}
var Au;
function ju() {
  return (ju = t(() => {
    R(),
      Dl(),
      (Au = (e) =>
        e.config.type === S.CentralSquare && e.itemSpriteRef instanceof El);
  }))();
}
var Mu;
function Nu() {
  return (Nu = t(() => {
    J(),
      N(),
      L(),
      ju(),
      il(),
      (Mu = class extends B {
        constructor(e, t, n, r) {
          super(U.WHITE),
            (this.playTween = (e, t, n) => {
              (this._tween = O({
                from: { v: this.alpha },
                to: { v: e },
                delay: n,
                duration: t,
                onTick: ({ v: e }) => {
                  this.alpha = e;
                },
                onFinish: () => {
                  this._tween?.destroy(),
                    (this._tween = void 0),
                    e <= 0 && (this.visible = !1);
                },
              })),
                this._tween.play();
            }),
            (this.x = e),
            (this.y = t),
            (this.width = n),
            (this.height = r),
            (this.tint = 0),
            (this.alpha = 0),
            (this.visible = !1),
            (this.zIndex = De - 1),
            (this.eventMode = `none`);
        }
        show(e, t) {
          if (
            (this._tween?.destroy(),
            (this._tween = void 0),
            (this.visible = !0),
            Au(e) && e.itemSpriteRef.gameResult instanceof rl)
          ) {
            if (!t) {
              this.alpha = 1;
              return;
            }
            this.playTween(1, 500, 500);
            return;
          }
          if (Au(e)) {
            if (!t) {
              this.alpha = 0.3;
              return;
            }
            this.playTween(0.3, 500, 500);
            return;
          }
          (this.visible = !1), (this.alpha = 0);
        }
        hide(e, t) {
          if ((this._tween?.destroy(), (this._tween = void 0), Au(e))) {
            if (!t) {
              (this.alpha = 0), (this.visible = !1);
              return;
            }
            this.playTween(0, 500);
            return;
          }
          (this.alpha = 0), (this.visible = !1);
        }
        destroy(e) {
          this._tween?.destroy(), (this._tween = void 0), super.destroy(e);
        }
      });
  }))();
}
var Pu, Fu, Iu, Lu, Ru, zu, Bu;
function Vu() {
  return (Vu = t(() => {
    J(),
      j(),
      N(),
      F(),
      _(),
      (Pu = 1e3),
      (Fu = 9e3),
      (Iu = 0.02),
      (Lu = 0.035),
      (Ru = 3e3),
      (zu = 1e4),
      (Bu = class extends H {
        constructor(e, t, n, r) {
          super(),
            (this.speed = 0),
            (this.randomInRange = Hn(Math.random)),
            (this.worldHeight = n),
            (this.viewport = r),
            (this.eventMode = `none`),
            (this.minAlpha = T(`passingCloudsMinAlpha`) ?? 0.35),
            (this.maxAlpha = T(`passingCloudsMaxAlpha`) ?? 0.8),
            (this.alpha = this.randomInRange(this.minAlpha, this.maxAlpha, !0)),
            t.anchor.set(0.5),
            this.addChild(t),
            (this.name = `cloud${e + 1}`),
            T(`passingCloudsBlendMode`) === `screen` &&
              (t.blendMode = Nr.SCREEN),
            this.startMovementAnimation(!0),
            this.startAlphaAnimation();
        }
        update(e) {
          !this.visible ||
            this.destroyed ||
            ((this.x += e * this.speed),
            this.x > this.viewport.right + this.width / 2 &&
              this.loopAnimationAfterDelay());
        }
        startMovementAnimation(e) {
          (this.visible = !0),
            (this.speed = this.randomInRange(Iu, Lu, !0)),
            (this.x = e
              ? this.randomInRange(this.viewport.left, this.viewport.right, !0)
              : this.viewport.left - this.width / 2),
            (this.y =
              this.worldHeight * 0.2 +
              this.randomInRange(0, this.worldHeight * 0.6, !0));
        }
        startAlphaAnimation() {
          (this.alphaTween = O({
            from: { alpha: this.alpha },
            to: { alpha: this.randomInRange(this.minAlpha, this.maxAlpha, !0) },
            easing: E.LINEAR,
            duration: this.randomInRange(Ru, zu, !0),
            onTick: ({ alpha: e }) => {
              this.alpha = e;
            },
            onFinish: () => {
              this.startAlphaAnimation();
            },
          })),
            this.alphaTween.play();
        }
        loopAnimationAfterDelay() {
          (this.visible = !1), this.delayedMovementAnimationStart();
        }
        delayedMovementAnimationStart() {
          this.timeout = setTimeout(
            () => this.startMovementAnimation(!1),
            this.randomInRange(Pu, Fu, !0)
          );
        }
        destroy(e) {
          this.timeout && clearTimeout(this.timeout),
            this.alphaTween?.destroy(),
            super.destroy(e);
        }
      });
  }))();
}
var Hu;
function Uu() {
  return (Uu = t(() => {
    J(),
      N(),
      G(),
      L(),
      $(),
      _(),
      Vu(),
      (Hu = class extends H {
        constructor(e, t) {
          super(), (this.clouds = []), (this.eventMode = `none`);
          let n = q.instance.getResourceTextures(Un),
            r = T(`passingCloudsCount`);
          for (let i = 0; i < r; i++) {
            let r = n[i % n.length];
            if (!r) return;
            let a = new B(r),
              o = new Bu(i, a, e, t);
            this.addChild(o), this.clouds.push(o);
          }
        }
        update(e) {
          this.clouds.forEach((t) => t.update(e));
        }
        fadeIn() {
          this.alphaTween?.destroy(),
            (this.alphaTween = O({
              from: { alpha: this.alpha },
              to: { alpha: 1 },
              duration: 500,
              onTick: ({ alpha: e }) => {
                this.alpha = e;
              },
              onFinish: () => {
                this.alphaTween?.destroy(), (this.alphaTween = void 0);
              },
            })),
            this.alphaTween.play();
        }
        fadeOut() {
          this.alphaTween?.destroy(),
            (this.alphaTween = O({
              from: { alpha: this.alpha },
              to: { alpha: 0 },
              duration: 500,
              onTick: ({ alpha: e }) => {
                this.alpha = e;
              },
              onFinish: () => {
                this.alphaTween?.destroy(), (this.alphaTween = void 0);
              },
            })),
            this.alphaTween.play();
        }
        destroy(e) {
          this.alphaTween?.destroy(),
            this.clouds.forEach((e) => e.destroy()),
            super.destroy(e);
        }
      });
  }))();
}
var Wu;
function Gu() {
  return (Gu = t(() => {
    ce(),
      Qn(),
      j(),
      L(),
      _(),
      zc(),
      Z(),
      (Wu = class {
        constructor({ centerItem: e, centerItemClassic: t, utils: n }) {
          (this._centerItem = e),
            (this._centerItemClassic = t),
            (this._utils = n);
        }
        destroy() {
          this.getAllCharacters().forEach((e) => e.clearAnimationListeners());
        }
        getAllCharacters() {
          return (
            this._centerItem.itemSpriteRef.gameResult?.getAllCharacters() ?? []
          );
        }
        getCharacterAtRankAsWithResultGameClassic(e) {
          return this._centerItemClassic?.itemSpriteRef.gameResult?.getCharacterByRank(
            e
          );
        }
        popInCharacter(e, t = 0) {
          if (!e) return;
          let n = e.scale.x;
          (e.visible = !0),
            this._utils.addTween({
              from: { value: 0 },
              to: { value: n },
              duration: I.durations.popIn * 1e3,
              delay: t,
              easing: E.SWING_TO,
              onTick: ({ value: t }) => e.scale.set(t),
            });
        }
        createScoreText(e, t) {
          let n = wn(`podiumPointsTemplate`) ?? Ln,
            r = (n.includes(`[value]`) ? n : Ln).replace(Xn, at(t) ?? `0`),
            i = new X(r, Ge);
          return (
            (i.style.align = `center`),
            (i.resolution = 5),
            i.anchor.set(0.5),
            (i.x = this._centerItem.x + e[0]),
            (i.y = this._centerItem.y + e[1]),
            (i.zIndex = vt - 1),
            (i.alpha = 0),
            i
          );
        }
        fadeCharacterText(e, t) {
          let n = t?.textSprite;
          n &&
            this._utils.addTween({
              from: { value: n.alpha },
              to: { value: +(e === `in`) },
              duration:
                (e === `in` ? I.durations.popIn : I.durations.snapBack) * 1e3,
              onTick: ({ value: e }) => (n.alpha = e),
            });
        }
        animateResultGameClassicCharacter(e, t, ...n) {
          if (!t) return;
          let r = n.find((e) => e && e.currentAnimation !== `idle`);
          if (!r) {
            t.setAnimation(e, 1);
            return;
          }
          r.addAnimationListener(Oc, () => {
            r.clearAnimationListeners(), t.setAnimation(e, 1);
          });
        }
        popInCrowdCharacters() {
          let e = this.getAllCharacters().filter((e) => !e.visible),
            t = Math.max(50, Math.floor(2e3 / e.length));
          e.forEach((e, n) => {
            (e.visible = !0), this.popInCharacter(e, n * t);
          });
        }
      });
  }))();
}
var Ku;
function qu() {
  return (qu = t(() => {
    J(),
      ni(),
      mi(),
      $l(),
      j(),
      C(),
      Va(),
      L(),
      (Ku = class {
        constructor({
          centerItem: e,
          centerItemFocusSize: t,
          addTween: n,
          fadeTo: r,
        }) {
          (this.spotlights = []),
            (this.onTick = () => {
              let e = Ir.shared.deltaMS / 1e3;
              this.update(e);
            }),
            (this.centerItem = e),
            (this.centerItemFocusSize = t),
            (this.addTween = n),
            (this.fadeTo = r),
            Ir.shared.add(this.onTick);
        }
        destroy() {
          Ir.shared.remove(this.onTick),
            !this.sparklesEmitter?.destroyed &&
              this.sparklesEmitter?.destroy(!0),
            !this.confettiEmitter?.destroyed &&
              this.confettiEmitter?.destroy(!0),
            this.spotlights.forEach((e) => !e.destroyed && e.destroy(!0));
        }
        showSparkles(e) {
          this.sparklesEmitter?.destroy(!0),
            (this.sparklesEmitter = new Y({ textures: si(10), config: Ba() })),
            (this.sparklesEmitter.zIndex = vt),
            (this.sparklesEmitter.x = this.centerItem.x + e[0]),
            (this.sparklesEmitter.y = this.centerItem.y + e[1]),
            this.centerItem.parent?.addChild(this.sparklesEmitter),
            this.sparklesEmitter.play();
        }
        showConfetti() {
          this.confettiEmitter?.destroy(!0),
            (this.confettiEmitter = new Y({
              textures: ui(5),
              config: fi({
                x: this.centerItem.x - this.centerItem.width / 2,
                y: this.centerItem.y - this.centerItem.height * 1.5,
                width: this.centerItem.width,
                height: 0,
              }),
            })),
            (this.confettiEmitter.zIndex = vt),
            this.confettiEmitter.play(),
            this.centerItem.parent?.addChild(this.confettiEmitter);
        }
        hideConfetti() {
          !this.confettiEmitter ||
            this.confettiEmitter.destroyed ||
            this.fadeTo(this.confettiEmitter, 0, 500, 0, () => {
              !this.confettiEmitter ||
                this.confettiEmitter.destroyed ||
                this.confettiEmitter?.stop();
            });
        }
        createSpotlight(e, t) {
          let n = new Zl({
            viewportWidth: this.centerItemFocusSize[0] * 2,
            viewportHeight: this.centerItemFocusSize[0] * 2,
            radius: 40,
            bgColor: t,
            spotlightAlphaRange: [
              [0, 1],
              [0.9, 1],
              [1, 0],
            ],
          });
          return (
            (n.alpha = 0),
            (n.zIndex = vt),
            (n.x = this.centerItem.x + e[0]),
            (n.y = this.centerItem.y + e[1]),
            this.centerItem.parent?.addChild(n),
            this.spotlights.push(n),
            n
          );
        }
        showSpotlight(e, t) {
          !e ||
            e.destroyed ||
            this.addTween({
              from: { value: 0 },
              to: { value: 1 },
              duration: t,
              easing: E.EASE_OUT_SINE,
              onTick: ({ value: t }) => {
                !e || e.destroyed || (e.scale.set(w(1.2, 1, t)), (e.alpha = t));
              },
            });
        }
        hideSpotlight(e, t, n = !0) {
          !e ||
            e.destroyed ||
            this.addTween({
              from: { value: 0 },
              to: { value: 1 },
              duration: t,
              easing: E.EASE_OUT_SINE,
              onTick: ({ value: t }) => {
                !e ||
                  e.destroyed ||
                  ((e.alpha = 1 - t), e.scale.set(w(1, 2, t)));
              },
              onFinish: () => {
                n && this.removeSpotlight(e);
              },
            });
        }
        removeSpotlight(e) {
          if (e.destroyed) return;
          let t = this.spotlights.indexOf(e);
          t >= 0 && this.spotlights.splice(t, 1), e.destroy(!0);
        }
        update(e) {
          !this.sparklesEmitter?.destroyed && this.sparklesEmitter?.update(e),
            !this.confettiEmitter?.destroyed && this.confettiEmitter?.update(e);
        }
      });
  }))();
}
var Ju;
function Yu() {
  return (Yu = t(() => {
    N(),
      (Ju = class {
        constructor() {
          (this._tweens = []),
            (this._timeoutIds = []),
            (this.removeTween = (e) => {
              let t = this._tweens.indexOf(e);
              t >= 0 && this._tweens.splice(t, 1), e.destroy();
            });
        }
        createAndPlayTween(e) {
          let t = O({
            ...e,
            onFinish: (...n) => {
              e.onFinish?.(...n), this.removeTween(t);
            },
          });
          return t.play(), t;
        }
        addTween(e) {
          let t = this.createAndPlayTween(e);
          this._tweens.push(t);
        }
        addTimeout(e, t) {
          if (t <= 0) {
            e();
            return;
          }
          let n = window.setTimeout(e, t);
          this._timeoutIds.push(n);
        }
        fadeTo(e, t, n, r = 0, i) {
          this.addTween({
            from: { value: e.alpha },
            to: { value: t },
            duration: n,
            delay: r,
            onTick: ({ value: t }) => {
              !e || e.destroyed || (e.alpha = t);
            },
            onFinish: i,
          });
        }
        destroy() {
          [...this._tweens].forEach((e) => e.destroy()),
            (this._tweens = []),
            this._timeoutIds.forEach((e) => clearTimeout(e)),
            (this._timeoutIds = []);
        }
      });
  }))();
}
var Xu, Zu;
function Qu() {
  return (Qu = t(() => {
    il(),
      Qn(),
      _(),
      Gu(),
      qu(),
      Yu(),
      (Xu = 1e3),
      (Zu = class {
        get isAnimatable() {
          return !!this._centerItemClassic;
        }
        animate(e, t) {
          if (!this.isAnimatable) {
            t?.();
            return;
          }
          this._centerItemClassic
            ? e
              ? this.animateResultGameClassicFast(t)
              : this.animateResultGameClassic(t)
            : (console.error(`PodiumAnim.animate(): Unsupported podium type`),
              t?.());
        }
        constructor({ centerItem: e, centerItemPos: t, focusAreaFunction: n }) {
          (this._tempSprites = []),
            (this._centerItem = e),
            (this._centerItemPos = t),
            (this._centerItemFocusSize = Ft(e.config.type, e.islandConfig)),
            (this._focusAreaFunction = n),
            (this._utils = new Ju()),
            (this._characters = new Wu({
              centerItem: e,
              centerItemClassic: this._centerItemClassic,
              utils: this._utils,
            })),
            (this._effects = new Ku({
              centerItem: e,
              centerItemFocusSize: this._centerItemFocusSize,
              addTween: this._utils.addTween.bind(this._utils),
              fadeTo: this._utils.fadeTo.bind(this._utils),
            }));
        }
        destroy() {
          this._characters.destroy(),
            this._tempSprites.forEach((e) => !e.destroyed && e.destroy()),
            this._utils.destroy(),
            this._effects.destroy();
        }
        get _centerItemClassic() {
          if (this._centerItem.itemSpriteRef.gameResult instanceof rl)
            return this._centerItem;
        }
        focusCenterItemPart(e, t, n = !1) {
          let r = [this._centerItemPos.x + e[0], this._centerItemPos.y + e[1]],
            i = [
              this._centerItemFocusSize[0] * t,
              this._centerItemFocusSize[1] * t,
            ];
          this._focusAreaFunction(r, i, n);
        }
        animateResultGameClassicFast(e) {
          let t = this._centerItemClassic,
            n = t?.itemSpriteRef.gameResult,
            r = n?.config.reactionsEnabled ?? !1,
            i = n?.podium;
          if (!t || !n || !i) {
            e?.();
            return;
          }
          let a = r ? `dance` : `victory`;
          [2, 1, 0].forEach((e) => {
            this._characters
              .getCharacterAtRankAsWithResultGameClassic(e)
              ?.setAnimation(a, 1);
          }),
            this._utils.addTimeout(() => this._effects.showConfetti(), Xu),
            this._utils.addTimeout(() => {
              this._effects.hideConfetti(), e?.();
            }, 11e3);
        }
        animateResultGameClassic(e) {
          let t = this._centerItemClassic,
            n = t?.itemSpriteRef.gameResult,
            r = n?.config.reactionsEnabled ?? !1,
            i = n?.podium;
          if (!t || !n || !i) {
            e?.();
            return;
          }
          let a = (e) => {
              let t = i.getCharacterOffsetByRank(e);
              return {
                center: [i.x + t[0], i.y + t[1] - 50],
                focus: [i.x + t[0], i.y + t[1] - 35],
                sparkles: [i.x + t[0], i.y + t[1] - 30],
              };
            },
            o = 0.5,
            s = [i.x, i.y - 65],
            c = 1e3;
          this.focusCenterItemPart(s, o),
            this._characters
              .getAllCharacters()
              .forEach((e) => (e.visible = !1)),
            (i.goldBadge.alpha = 0),
            (i.silverBadge.alpha = 0),
            (i.bronzeBadge.alpha = 0);
          let l = this._centerItem.interactionType;
          this._centerItem.interactionType = `none`;
          let { center: u, focus: d, sparkles: f } = a(2),
            p = this._characters.getCharacterAtRankAsWithResultGameClassic(2);
          p?.toggleNameTextDisplay(`full`);
          let m = this._characters.createScoreText(u, p?.data?.score ?? 0);
          this._centerItem.parent?.addChild(m), this._tempSprites.push(m);
          let ee = I.delays.bronzePopIn * 1e3;
          this._utils.addTimeout(() => {
            this._utils.fadeTo(i.bronzeBadge, 1, 500),
              this._utils.fadeTo(m, 1, 500),
              this.focusCenterItemPart(d, o, !0);
          }, ee);
          let h = I.delays.playerPopBronze * 1e3;
          this._utils.addTimeout(() => {
            this._characters.popInCharacter(p),
              this._utils.fadeTo(m, 0, 150),
              this._effects.showSparkles(f);
          }, h);
          let te = I.delays.playerGrooveBronze * 1e3;
          this._utils.addTimeout(
            () =>
              this._characters.animateResultGameClassicCharacter(`dance`, p),
            te
          );
          let { center: ne, focus: re, sparkles: ie } = a(1),
            g = this._characters.getCharacterAtRankAsWithResultGameClassic(1);
          g?.toggleNameTextDisplay(`full`);
          let _ = this._characters.createScoreText(ne, g?.data?.score ?? 0);
          this._centerItem.parent?.addChild(_), this._tempSprites.push(_);
          let ae = I.delays.silverPopIn * 1e3;
          this._utils.addTimeout(() => {
            this._characters.fadeCharacterText(`out`, p),
              this._utils.fadeTo(i.silverBadge, 1, 500, 150),
              this._utils.fadeTo(_, 1, 500),
              this.focusCenterItemPart(re, o, !0);
          }, ae);
          let oe = I.delays.playerPopSilver * 1e3;
          this._utils.addTimeout(() => {
            this._characters.popInCharacter(g),
              this._utils.fadeTo(_, 0, 150),
              this._effects.showSparkles(ie);
          }, oe);
          let v = I.delays.playerGrooveSilver * 1e3;
          this._utils.addTimeout(
            () =>
              this._characters.animateResultGameClassicCharacter(`dance`, g, p),
            v - c
          );
          let { center: se, focus: ce, sparkles: le } = a(0),
            y = this._characters.getCharacterAtRankAsWithResultGameClassic(0);
          y?.toggleNameTextDisplay(`full`);
          let b = this._characters.createScoreText(se, y?.data?.score ?? 0);
          this._centerItem.parent?.addChild(b), this._tempSprites.push(b);
          let x = I.delays.goldPopIn * 1e3;
          this._utils.addTimeout(() => {
            this._characters.fadeCharacterText(`out`, g),
              this._utils.fadeTo(i.goldBadge, 1, 500, 500),
              this._utils.fadeTo(b, 1, 500),
              this.focusCenterItemPart(ce, o, !0);
          }, x);
          let ue = I.delays.spotlightEnter * 1e3,
            S = I.durations.spotlightEnter * 1e3,
            de = I.delays.confetti * 1e3,
            fe = I.durations.confetti * 1e3,
            pe = I.delays.spotlightExit * 1e3,
            me = I.durations.spotlightExit * 1e3,
            he = this._effects.createSpotlight(se, `rgba(0, 0, 0, 0.8)`);
          this._utils.addTimeout(() => this._effects.showSpotlight(he, S), ue),
            this._utils.addTimeout(() => this._effects.showConfetti(), de),
            this._utils.addTimeout(
              () => this._effects.hideSpotlight(he, me),
              pe
            );
          let ge = I.delays.playerPopGold * 1e3;
          this._utils.addTimeout(() => {
            this._characters.popInCharacter(y),
              this._utils.fadeTo(b, 0, 150),
              this._effects.showSparkles(le);
          }, ge);
          let _e = I.delays.playerGrooveGold * 1e3;
          this._utils.addTimeout(
            () =>
              this._characters.animateResultGameClassicCharacter(
                r ? `dance` : `victory`,
                y,
                g,
                p
              ),
            _e - c
          );
          let ve =
            this._characters.getCharacterAtRankAsWithResultGameClassic(3);
          ve?.toggleNameTextDisplay(`full`);
          let ye =
            this._characters.getCharacterAtRankAsWithResultGameClassic(4);
          ye?.toggleNameTextDisplay(`full`);
          let be = I.delays.runnerUps * 1e3,
            xe = I.durations.runnerUps * 1e3;
          this._utils.addTimeout(() => {
            this.focusCenterItemPart(dn(t.config.type), 1, !0),
              p?.toggleNameTextDisplay(`reduced`),
              g?.toggleNameTextDisplay(`reduced`),
              y?.toggleNameTextDisplay(`reduced`),
              this._characters.fadeCharacterText(`in`, p),
              this._characters.fadeCharacterText(`in`, g);
          }, be),
            this._utils.addTimeout(() => {
              this._characters.popInCharacter(ve);
            }, be + xe / 4),
            this._utils.addTimeout(() => {
              this._characters.popInCharacter(ye);
            }, be + xe / 4 + 500);
          let Se = be + xe;
          this._utils.addTimeout(() => {
            this._characters.fadeCharacterText(`out`, ve),
              this._characters.fadeCharacterText(`out`, ye),
              this._characters.popInCrowdCharacters();
          }, Se),
            this._utils.addTimeout(() => {
              this._effects.hideConfetti();
            }, de + fe);
          let Ce = I.delays.bottomBarWithRunnerUps * 1e3;
          this._utils.addTimeout(() => {
            this._characters
              .getAllCharacters()
              .forEach((e) => e.toggleNameTextDisplay(`reduced`)),
              (this._centerItem.interactionType = l),
              e?.();
          }, Ce);
          let we = Math.max(Ce + 1e4, de + fe + 1e4);
          this._utils.addTimeout(() => this.destroy(), we);
        }
      });
  }))();
}
var $u;
function ed() {
  return (ed = t(() => {
    J(),
      G(),
      ni(),
      bn(),
      on(),
      Tt(),
      pr(),
      ($u = class extends H {
        constructor(e, t, n) {
          super(), (this.name = `SeasonalParticles`);
          let r = [],
            i;
          switch (n) {
            case Rt.Thanksgiving:
              (r = q.instance.getResourceTextures(nt)),
                (i = q.instance.getResourceJSON(Mt));
              break;
            case Rt.Winter:
              (r = q.instance.getResourceTextures(Me)),
                (i = q.instance.getResourceJSON(Kn));
              break;
            case Rt.Spring:
              (r = q.instance.getResourceTextures(Rn)),
                (i = q.instance.getResourceJSON(ar));
              break;
            default:
              return;
          }
          if (r.length === 0) return;
          let a = { ...i };
          a?.behaviors &&
            (a.behaviors.forEach((n) => {
              n.type === `spawnShape` &&
                (n.config.data = { x: 0, y: 0, w: e, h: t }),
                n.type === `textureRandom` && (n.config.textures = r);
            }),
            (this._emitter = new Y({ textures: r, config: a })),
            this._emitter.play(),
            this.addChild(this._emitter));
        }
        update(e) {
          this._emitter?.update(e);
        }
        destroy(e) {
          this._emitter?.destroy(), super.destroy(e);
        }
      });
  }))();
}
var td, nd, rd, id, ad;
function od() {
  return (od = t(() => {
    J(),
      W(),
      N(),
      G(),
      L(),
      $(),
      (td = 4500),
      (nd = 1.5),
      (rd = 57),
      (id = 40),
      (ad = class extends H {
        constructor({ itemCenter: e, viewport: t }) {
          super(), (this._playTimeout = -1);
          let n = q.instance.getResourceSpine(Bt);
          if (!n) return;
          (this.eventMode = `none`),
            (this.visible = !1),
            (this._spine = new K(n.spineData)),
            (this._spine.name = `handAnimation`);
          let r = t.scale.x ?? 1;
          r !== 0 && this.scale.set(1 / r),
            (this.x = e.x + this.scale.x * rd),
            (this.y = e.y + this.scale.y * id),
            this.addChild(this._spine),
            t.addChild(this);
        }
        play() {
          if (this.destroyed || !this._spine) return;
          let e =
            this._spine.state.setAnimation(0, `TAP`, !1).animation?.duration ??
            0;
          this._playTimeout = window.setTimeout(() => {
            this.destroyed ||
              !this._spine ||
              ((this.visible = !0),
              this._spine.state.setAnimation(0, `TAP`, !1),
              this._spine.state.addAnimation(0, `TAP`, !1, e + nd),
              (this._destroyTimeout = window.setTimeout(
                () => this.destroy(),
                (2 * e + nd) * 1e3
              )));
          }, td);
        }
        fadeOutAndDestroy() {
          this.destroyed ||
            (window.clearTimeout(this._playTimeout),
            this._alphaTween?.destroy(),
            (this._alphaTween = O({
              from: { alpha: this.alpha },
              to: { alpha: 0 },
              duration: 500,
              onTick: ({ alpha: e }) => {
                this.alpha = e;
              },
            })),
            this._alphaTween.play());
        }
        destroy(e) {
          window.clearTimeout(this._destroyTimeout),
            (this._destroyTimeout = void 0),
            window.clearTimeout(this._playTimeout),
            this._alphaTween?.destroy(),
            (this._trackEntry &&= ((this._trackEntry.listener = null), void 0)),
            this._spine &&
              (this._spine.state.clearTrack(0),
              this._spine.state.clearTrack(1),
              this.parent?.removeChild(this),
              this.removeChild(this._spine)),
            super.destroy(e);
        }
      });
  }))();
}
var sd;
function cd() {
  return (cd = t(() => {
    J(),
      D(),
      F(),
      G(),
      L(),
      $(),
      _(),
      (sd = class extends H {
        constructor(e) {
          super();
          let t = k(e),
            n = z(Ee, t),
            r = q.instance.getResourceTexture(n ?? Ee[0]);
          (this.grassSprite = new B(r)),
            this.grassSprite.anchor.set(0.5),
            (this.grassSprite.x = 128 / 2),
            (this.grassSprite.y = 128 / 2);
          let i = T(`terrain`);
          (this.grassSprite.tint = z(i, t) ?? i[0]),
            this.addChild(this.grassSprite);
        }
      });
  }))();
}
var ld;
function ud() {
  return (ud = t(() => {
    J(),
      G(),
      L(),
      $(),
      (ld = class extends H {
        get width() {
          return 128;
        }
        set width(e) {
          throw Error(`TerrainTile: width is read-only`);
        }
        get height() {
          return 128;
        }
        set height(e) {
          throw Error(`TerrainTile: height is read-only`);
        }
        initialize() {
          let { flip: e, rotation: t } = this.data;
          (this.tileSpriteFlipContainer = new H()),
            (this.tileSpriteFlipContainer.x = this.width / 2),
            (this.tileSpriteFlipContainer.y = this.height / 2),
            this.addChild(this.tileSpriteFlipContainer),
            (this.tileSpriteRotationContainer = new H()),
            this.tileSpriteFlipContainer.addChild(
              this.tileSpriteRotationContainer
            ),
            (this.tileSprite = new B()),
            this.tileSprite.anchor.set(0.5),
            this.tileSpriteRotationContainer.addChild(this.tileSprite),
            e === `horizontal` && (this.tileSpriteFlipContainer.scale.x *= -1),
            e === `vertical` && (this.tileSpriteFlipContainer.scale.y *= -1),
            t !== void 0 && (this.tileSpriteRotationContainer.angle = t);
        }
        drawTile() {
          let e = Yi(this.config, this.data),
            t = q.instance.getResourceTexture(e);
          t && (this.tileSprite.texture = t);
        }
        constructor(e, t) {
          super(),
            (this.config = e),
            (this.data = t),
            this.initialize(),
            this.drawTile();
        }
      });
  }))();
}
var dd, fd, pd, md;
function hd() {
  return (hd = t(() => {
    R(),
      ln(),
      (dd = 17500),
      (fd = 1e3),
      (pd = 0.25),
      (md = class {
        async animate(e, t, n, r, i, a, o) {
          let s = e.map((e) => e.map((e) => ({ ...e, type: 0 })));
          this.addItemToTerrain(t[0], s, r, i, a),
            n.forEach((e) => e.prepareAnimateAppear()),
            await this.pause(fd);
          let c = performance.now();
          n.find((e) => e.config.type === S.CentralSquare)?.animateAppear();
          let l = Array(t.length)
            .fill(0)
            .map((e, n) => Math.floor(c + (n / (t.length - 1)) * dd));
          for (let e = 1; e < t.length; e++) {
            let o = t[e],
              c = l[e],
              u = Math.max(0, c - performance.now()),
              d = u * pd,
              f = u * 0.75;
            if ((await this.pause(d), o?.type)) {
              d > 0 && (await this.pause(d)),
                this.addItemToTerrain(o, s, r, i, a);
              let e = n.find(
                (e) =>
                  e.config.gridPosition[0] === o.gridPosition[0] &&
                  e.config.gridPosition[1] === o.gridPosition[1]
              );
              e && (f > 0 && (await this.pause(f)), e.animateAppear());
            }
          }
          o?.();
        }
        addItemToTerrain(e, t, n, r, i) {
          let a = Wn[e.type].dimensions;
          for (let n = 0; n < a[0]; n++)
            for (let r = 0; r < a[1]; r++)
              t[e.gridPosition[1] + r][e.gridPosition[0] + n] = {
                ...t[e.gridPosition[1] + r][e.gridPosition[0] + n],
                type: 1,
              };
          this.clearTerrainTiles(n, r), i(t);
        }
        clearTerrainTiles(e, t) {
          for (let t = e.length - 1; t >= 0; t--) e[t].destroy();
          for (let e = t.length - 1; e >= 0; e--) t[e].destroy();
        }
        pause(e) {
          return new Promise((t) => setTimeout(t, e));
        }
      });
  }))();
}
var gd;
function _d() {
  return (_d = t(() => {
    J(),
      (gd = class extends H {
        constructor(e, t, n) {
          super();
          let r = new Jr(30, 15, 1),
            i = new Pr();
          i.lineStyle(15, n),
            i.moveTo(0, 0).lineTo(e, 0),
            i.moveTo(0, t).lineTo(e, t),
            i.moveTo(0, 0).lineTo(0, t),
            i.moveTo(e, 0).lineTo(e, t),
            (i.filters = [r]),
            (i.cacheAsBitmap = !0),
            this.addChild(i);
        }
        destroy(e) {
          super.destroy(e);
        }
      });
  }))();
}
var vd, yd;
function bd() {
  return (bd = t(() => {
    J(),
      p(),
      G(),
      ni(),
      F(),
      L(),
      $(),
      _(),
      (vd = {
        lifetime: { min: 3, max: 5 },
        frequency: 0.4,
        emitterLifetime: -1,
        maxParticles: 100,
        addAtBack: !1,
        pos: { x: 0, y: 0 },
        behaviors: [
          {
            type: `alpha`,
            config: {
              alpha: {
                list: [
                  { time: 0, value: 0 },
                  { time: 0.5, value: 1 },
                  { time: 1, value: 0 },
                ],
              },
            },
          },
          {
            type: `scaleExt`,
            config: {
              scaleX: {
                list: [
                  { time: 0, value: 1 },
                  { time: 0.25, value: 0.85 },
                  { time: 5, value: 1 },
                  { time: 0.75, value: 0.85 },
                  { time: 1, value: 1 },
                ],
              },
              scaleY: {
                list: [
                  { time: 0, value: 0.5 },
                  { time: 0.25, value: 1.2 },
                  { time: 0.5, value: 0.5 },
                  { time: 0.75, value: 1.2 },
                  { time: 1, value: 0.5 },
                ],
              },
            },
          },
          {
            type: `spawnShape`,
            config: { type: `rect`, data: { x: 0, y: 0, w: 500, h: 500 } },
          },
        ],
      }),
      (yd = class extends H {
        createContainer() {
          let e = new H();
          return (e.eventMode = `none`), this.addChild(e), e;
        }
        initWaterTiles(e, t, n, r) {
          let i = T(`waterReflections`),
            a = this.createContainer(),
            o = n[0] / 128,
            s = n[1] / 128,
            c = Math.floor(n[2] / 128),
            l = Math.floor(n[3] / 128);
          for (let n = 0; n * 128 < t; n++)
            for (let u = 0; u * 128 < e; u++) {
              let d = u - o,
                f = n - s,
                p = d > 0 && d < c && f > 0 && f < l ? r[f]?.[d] : void 0;
              if (p && p.type !== 0) continue;
              let m = new B(U.WHITE);
              (m.width = 128), (m.height = 128);
              let ee = u * 128,
                h = n * 128;
              (m.x = ee), (m.y = h), i !== void 0 && (m.tint = i);
              let te = ee + 128 / 2 - e / 2,
                ne = h + 128 / 2 - t / 2;
              (m.alpha =
                (1 - (te ** 2 + ne ** 2) / ((e / 2) ** 2 + (t / 2) ** 2)) ** 7 *
                0.4),
                (m.eventMode = `none`),
                a.addChild(m),
                this._squaresList.push({ sprite: m, maxAlpha: m.alpha });
            }
        }
        initWaveParticles(e, t) {
          let n = q.instance.getResourceTexture(zn);
          if (!n) return;
          let r = this.createContainer(),
            i = { ...vd };
          i.behaviors.forEach((n) => {
            n.type === `spawnShape` &&
              (n.config.data = { x: 0, y: 0, w: e, h: t });
          }),
            (this._wavesEmitter = new Y({ textures: [n], config: i })),
            this._wavesEmitter.play(),
            r.addChild(this._wavesEmitter);
        }
        initWaterDecorations(e, t, n) {
          let r = q.instance.getResourceTextures(sn, !1);
          if (r.length === 0) return;
          let i = this.createContainer(),
            a = k(e),
            o = [3, 4, 4, 5, 6],
            s = Math.floor(t[2] / 128),
            c = Math.floor(t[3] / 128),
            l = [];
          for (let e = -3; e < c + 3; e++)
            for (let t = -3; t < s + 3; t++) Be(e, t, n) && l.push([e, t]);
          l = It(l, a);
          let u = [];
          l.forEach(([e, t]) => {
            let n = hn(o, a),
              r = hr(e, t, n).flat();
            u.find(([e, t]) => r.some(([n, r]) => n === e && r === t)) ||
              u.push([e, t]);
          });
          let d = s + 6,
            f = c + 6,
            p = f / 2 - 3,
            m = d / 2 - 3,
            ee = Math.min(d / 2, f / 2) ** 2;
          (u = u.filter(([e, t]) => (t - m) ** 2 + (e - p) ** 2 <= ee)),
            (u = u.sort(([e, t], [n, r]) => e - n || t - r));
          let h = [];
          u.forEach(([e, n]) => {
            h.length === 0 && h.push(...It(r, a));
            let o = h.pop(),
              s = new B(o);
            s.anchor.set(0.5),
              (s.x = t[0] + n * 128 + Hn(a)(0, 128)),
              (s.y = t[1] + e * 128 + Hn(a)(0, 128)),
              i.addChild(s);
          });
        }
        constructor({
          seed: e,
          width: t,
          height: n,
          islandArea: r,
          terrain: i,
        }) {
          super(),
            (this._squaresList = []),
            (this._timeElapsed = 0),
            (this.name = `Water`),
            this.initWaterTiles(t, n, r, i),
            this.initWaveParticles(t, n),
            this.initWaterDecorations(e, r, i),
            (this._noise3D = l(Math.random).noise3D);
        }
        update(e) {
          this._wavesEmitter.update(e),
            (this._timeElapsed += e * an),
            this._squaresList.forEach(({ sprite: e, maxAlpha: t }) => {
              e.alpha =
                this._noise3D(e.x * ie, e.y * ie, this._timeElapsed) * t + 0;
            });
        }
      });
  }))();
}
var xd = n({ default: () => Cd }),
  Sd,
  Cd;
function wd() {
  return (wd = t(() => {
    (Sd = e(ne())),
      gi(),
      J(),
      ri(),
      dt(),
      R(),
      D(),
      Ze(),
      Na(),
      li(),
      Fa(),
      Gr(),
      ai(),
      cr(),
      Vt(),
      G(),
      Qa(),
      eo(),
      no(),
      Z(),
      ku(),
      Nu(),
      Eo(),
      Uu(),
      Qu(),
      ed(),
      od(),
      cd(),
      ud(),
      hd(),
      _d(),
      bd(),
      L(),
      En(),
      ju(),
      $(),
      Ri(),
      _(),
      (Cd = class extends qr {
        get worldWidth() {
          return this.islandWidth + 2560;
        }
        get worldHeight() {
          return this.islandHeight + 2560;
        }
        get islandX() {
          return 1280;
        }
        get islandY() {
          return 1280;
        }
        get itemsInItemContainer() {
          return (
            this.itemsContainer?.children.filter((e) => e instanceof Ou) ?? []
          );
        }
        deselectAllItems() {
          if (this.isDestroyed || !this.itemSelected) return;
          this.itemsInItemContainer.forEach((e) => e.deselect(!0, 500));
          let e = this.itemSelected;
          (this.itemSelected = null),
            this.focusIsland(!0, { time: 500 }),
            this.itemBackdrop?.hide(e, !0),
            this.dispatchDataEvent({ type: `item-deselect-all` });
        }
        pauseAudio(e = 500) {
          this.isDestroyed ||
            this.isAudioPaused ||
            ((this.isAudioPaused = !0),
            this.bgMusic?.fade(1, 0, e),
            this.ambienceSound?.fade(1, 0, e));
        }
        resumeAudio(e = 2e3) {
          this.isDestroyed ||
            !this.isAudioPaused ||
            ((this.isAudioPaused = !1),
            this.bgMusic?.play(),
            this.bgMusic?.fade(this.bgMusic.volume, 1, e),
            this.ambienceSound?.play(),
            this.ambienceSound?.fade(this.ambienceSound.volume, 1, e));
        }
        updateAssignment(e, t, n) {
          if (!this.isDestroyed) {
            for (let r of this.itemsInItemContainer)
              if (
                r.config.type === S.AssignmentBuilding &&
                r.itemSpriteRef instanceof Ma &&
                r.config.data.kahootId === e &&
                r.config.data.subject === t
              ) {
                r.itemSpriteRef.updateStatus(n);
                break;
              }
          }
        }
        updateBrandEventPortalItem(e) {
          if (!this.isDestroyed) {
            for (let t of this.itemsInItemContainer)
              if (t.config.type === e.type && t.itemSpriteRef instanceof To) {
                t.itemSpriteRef.forceUpdateData(e);
                break;
              }
          }
        }
        dismissItemNotificationByType(e, t) {
          this.isDestroyed ||
            this.itemsInItemContainer.forEach((n) => {
              n.config.type === e &&
                n.hasNotification(t) &&
                n.dismissNotification();
            });
        }
        setPendingAsyncRewardsCount(e, t) {
          if (this.isDestroyed) return;
          let n = this.getCenterItem();
          n &&
            (n.itemSpriteRef.setPendingAsyncRewardsCount(e),
            e > 0 && t && this.toggleSelectItem(n));
        }
        setEmote(e, t) {
          if (this.isDestroyed) return;
          let n = this.getCenterItem();
          n && n?.itemSpriteRef.gameResult?.getCharacterByCid(e)?.setEmote(t);
        }
        constructor(e, t) {
          super({
            width: Se,
            height: 720,
            backgroundColor: parseInt(ge(e?.theme, `water`).slice(1), 16),
            withSound: !0,
            withSpine: !0,
            resolution: Math.min(window.devicePixelRatio || 1, 2),
            ...t,
          }),
            (this.islandWidth = 0),
            (this.islandHeight = 0),
            (this.itemSelected = null),
            (this.appearingItems = []),
            (this.brandEventPortalPointsAnims = []),
            (this.itemsToBeAnimated = []),
            (this.isAudioPaused = !1),
            (this.preloadInfo = e),
            this.linkGameTheme(e.theme),
            ii.registerBehavior(Pa),
            ii.registerBehavior(hi);
        }
        linkGameTheme(e) {
          (q.instance.theme = e), Ue(e);
        }
        playBackgroundMusic(e) {
          if (
            (this.bgMusic?.fade(1, 0, 3e3), (this.bgMusic = void 0), e !== null)
          ) {
            switch (e) {
              case `claim`:
                this.bgMusic = this.loader.getResourceSound(Or, !1);
                break;
              case `podium`:
                this.bgMusic = this.loader.getResourceSound(st, !1);
                break;
              case `timelapse`:
                this.bgMusic = this.loader.getResourceSound(Ii, !1);
                break;
              default:
                this.bgMusic = this.loader.getResourceSound(un, !1);
            }
            this.isAudioPaused ||
              (this.bgMusic?.play(), this.bgMusic?.fade(0, 1, 3e3));
          }
        }
        setViewportInteractionType(e) {
          if (this.viewport)
            if (e === `center-only-children`) {
              (this.viewport.eventMode = `passive`),
                this.itemsInItemContainer.forEach(
                  (e) => (e.interactionType = `none`)
                );
              let e = this.getCenterItem();
              e && (e.interactionType = `only-children`);
            } else
              e === `full`
                ? ((this.viewport.eventMode = `static`),
                  this.itemsInItemContainer.forEach(
                    (e) => (e.interactionType = `full`)
                  ))
                : ((this.viewport.eventMode = `none`),
                  this.itemsInItemContainer.forEach(
                    (e) => (e.interactionType = `none`)
                  ));
        }
        toggleSelectItem(e) {
          if (e.isSelectable) {
            if (this.itemSelected === e) {
              this.deselectAllItems();
              return;
            }
            this.itemsInItemContainer.forEach((e) => e.deselect(!0, 500)),
              e.select(!0),
              (this.itemSelected = e),
              this.focusItem(e, !0, { time: 500 }),
              this.itemBackdrop?.show(e, !0),
              this.dispatchDataEvent({ type: `item-select`, item: e.config }),
              this.tapHandAnimation?.fadeOutAndDestroy();
          }
        }
        drawWaterTiles() {
          (this.backgroundDecoration = new yd({
            seed: this.gameConfig?.seed ?? 0,
            width: this.worldWidth,
            height: this.worldHeight,
            islandArea: [
              this.islandX,
              this.islandY,
              this.islandWidth,
              this.islandHeight,
            ],
            terrain: this.gameConfig?.terrain ?? [],
          })),
            this.backgroundContainer?.addChild(this.backgroundDecoration);
        }
        drawParticles() {
          (this.seasonalParticles = new $u(
            this.islandWidth,
            this.islandHeight,
            this.preloadInfo.theme
          )),
            this.islandContainer?.addChild(this.seasonalParticles);
        }
        addCornerDecorations() {
          this.cornerDecoration?.destroy(),
            to.willHaveContent() &&
              ((this.cornerDecoration = new to(
                this.app.screen.width,
                this.gameConfig?.initialAnimationStyle !== void 0
              )),
              this.addChild(this.cornerDecoration));
        }
        drawTerrain() {
          this.gameConfig && this.drawTerrainTiles(this.gameConfig.terrain);
        }
        drawTerrainTiles(e) {
          if (!this.gameConfig) return;
          let { gridWidth: t, gridHeight: n } = this.gameConfig;
          for (let r = 0; r < n; r++)
            for (let i = 0; i < t; i++) {
              let a = e[r]?.[i],
                o = Je(r, i, e, t, n);
              if (!a || !o) continue;
              let s = i * 128,
                c = r * 128;
              if (o.type === 0) {
                let e = new ld(a, o);
                (e.x = s), (e.y = c), this.tilesContainer?.addChild(e);
              }
              if (o.type !== 1) continue;
              let l = new sd(a.seed);
              (l.x = s), (l.y = c), this.tilesGrassContainer?.addChild(l);
            }
        }
        drawItems() {
          if (!this.gameConfig) return;
          let { items: e, gridHeight: t, isRtl: n } = this.gameConfig,
            r = (0, Sd.default)(
              e,
              (e) => e.gridPosition[0] + e.gridPosition[1] * t
            );
          for (let e of r) {
            let [r, i] = e.gridPosition,
              a = new Ou({
                islandConfig: this.gameConfig,
                config: e,
                zIndex: r + i * t,
                isRtl: n,
              });
            a.on(`pointerdown`, (e) => {
              a.isSelectable && (e.stopPropagation(), this.toggleSelectItem(a));
            }),
              (a.x = r * 128 + a.width / 2),
              (a.y = i * 128 + a.height / 2),
              this.itemsContainer?.addChild(a);
          }
        }
        drawOpeningTransitionClouds() {
          let e = new $a(this.stageWidth(), this.stageHeight());
          this.addChild(e);
        }
        drawPassingClouds() {
          this.gameConfig?.initialAnimationStyle === `timeLapse` ||
            this.gameConfig?.gameResultConfig?.type === M.FakeResult ||
            !this.islandContainer ||
            !this.viewport ||
            ((this.passingClouds = new Hu(this.worldHeight, this.viewport)),
            (this.passingClouds.x = -this.islandContainer.x),
            (this.passingClouds.y = -this.islandContainer.y),
            (this.passingClouds.name = `passingCloudsContainer`),
            this.islandContainer.addChild(this.passingClouds));
        }
        drawTapHandAnimation() {
          if (
            this.gameConfig?.initialAnimationStyle !== `zoomIn` &&
            this.gameConfig?.initialAnimationStyle !== `podium` &&
            this.gameConfig?.initialAnimationStyle !== `zoomOut` &&
            this.gameConfig?.initialAnimationStyle !== void 0
          )
            return;
          let e = this.itemsInItemContainer.find(
            (e) =>
              e.config.type === S.BrandEventPortalTourDeFrance &&
              e.config.animateAppear &&
              (e.config?.xp ?? 0) > 0
          );
          if (!e || !this.viewport) return;
          let t = this.getItemCenterPosition(e);
          this.tapHandAnimation = new ad({
            itemCenter: t,
            viewport: this.viewport,
          });
        }
        drawVignette() {
          let e = T(`vignette`);
          e !== void 0 &&
            (this.vignette?.destroy(),
            (this.vignette = new gd(
              this.app.screen.width,
              this.app.screen.height,
              e
            )),
            this.addChild(this.vignette));
        }
        initializeData() {
          if (!this.gameConfig) return;
          let { gridWidth: e, gridHeight: t, isRtl: n } = this.gameConfig;
          (X.isRtl = n),
            (this.islandWidth = e * 128),
            (this.islandHeight = t * 128),
            this.dispatchDataEvent({ type: `initialize` }),
            $e(this.gameConfig.translations),
            this.linkGameTheme(this.gameConfig.theme);
        }
        initializeViewport() {
          this.viewport && this.removeChild(this.viewport),
            this.viewport?.destroy(),
            (this.viewport = new _i({
              screenWidth: this.stageWidth(),
              screenHeight: this.stageHeight(),
              worldWidth: this.worldWidth,
              worldHeight: this.worldHeight,
              events: this.app.renderer.events,
            })),
            this.viewport.on(`pointerdown`, () => {
              this.itemSelected && this.deselectAllItems();
            }),
            this.addChild(this.viewport),
            this.focusIsland(),
            (this.backgroundContainer = new H()),
            (this.backgroundContainer.name = `backgroundContainer`),
            this.viewport.addChild(this.backgroundContainer),
            (this.islandContainer = new H()),
            (this.islandContainer.name = `islandContainer`),
            (this.islandContainer.x = this.islandX),
            (this.islandContainer.y = this.islandY),
            this.viewport.addChild(this.islandContainer),
            (this.tilesContainer = new H()),
            (this.tilesContainer.name = `tilesContainer`),
            (this.tilesContainer.eventMode = `none`),
            this.islandContainer.addChild(this.tilesContainer),
            (this.tilesGrassContainer = new H()),
            (this.tilesGrassContainer.name = `tilesGrassContainer`),
            (this.tilesGrassContainer.eventMode = `none`),
            this.islandContainer.addChild(this.tilesGrassContainer),
            (this.itemsContainer = new H()),
            (this.itemsContainer.name = `itemsContainer`),
            (this.itemsContainer.sortableChildren = !0),
            this.islandContainer.addChild(this.itemsContainer),
            (this.itemBackdrop = new Mu(
              -this.islandX,
              -this.islandY,
              this.worldWidth,
              this.worldHeight
            )),
            (this.itemBackdrop.name = `itemBackdrop`),
            this.itemsContainer.addChild(this.itemBackdrop),
            (this.foregroundContainer = new H()),
            (this.foregroundContainer.name = `foregroundContainer`),
            this.islandContainer.addChild(this.foregroundContainer),
            this.drawWaterTiles(),
            this.gameConfig?.initialAnimationStyle !== `timeLapse` &&
              (this.drawTerrain(), this.drawIsland());
        }
        drawIsland() {
          this.drawItems(),
            this.drawTapHandAnimation(),
            this.drawParticles(),
            this.drawPassingClouds(),
            this.drawVignette();
        }
        initialAnimation() {
          if (!this.viewport) return;
          let e = this.gameConfig?.initialAnimationStyle;
          if (!e) {
            this.playBackgroundMusic(`idle`),
              this.addCornerDecorations(),
              this.dispatchDataEvent({ type: `revealed-without-animation` }),
              this.tapHandAnimation?.play();
            return;
          }
          this.setViewportInteractionType(
            [`podium`, `fastPodium`, `zoomOut`].includes(e)
              ? `center-only-children`
              : `none`
          );
          let t = () => {
              this.setViewportInteractionType(`none`),
                this.dispatchDataEvent({ type: `reveal-animation-started` });
            },
            n = () => {
              this.animateBrandEventPortalPoints(r);
            },
            r = () => {
              this.dispatchDataEvent({ type: `reveal-animation-finished` }),
                e !== `timeLapse` &&
                  (this.setViewportInteractionType(`full`),
                  this.playBackgroundMusic(`idle`),
                  this.addCornerDecorations(),
                  this.tapHandAnimation?.play());
            };
          this.drawOpeningTransitionClouds(),
            e === `zoomIn`
              ? this.animateZoomIn(t, r)
              : e === `zoomOut`
              ? (this.prepareBrandEventPortalPointsAnims(),
                this.animateZoomOut(t, n))
              : e === `podium`
              ? (this.prepareBrandEventPortalPointsAnims(),
                this.animatePodium(!1, t, n))
              : e === `fastPodium`
              ? this.animatePodium(!0, t, r)
              : e === `timeLapse`
              ? this.animateTimeLapse(t, r)
              : (t(), r());
        }
        initializeDebug() {}
        getIslandFocusSize() {
          return [
            Math.max(896, this.islandWidth),
            Math.max(896, this.islandHeight),
          ];
        }
        getViewportSizeOptionToFitSize([e, t]) {
          let n = this.viewport?.screenWidth ?? 0,
            r = this.viewport?.screenHeight ?? 0,
            i = Math.min(n / e, r / t);
          return n - e * i > r - t * i ? { height: t } : { width: e };
        }
        getWorldCenterPosition() {
          return { x: this.worldWidth / 2, y: this.worldHeight / 2 };
        }
        getIslandCenterPosition() {
          return {
            x: this.islandX + this.islandWidth / 2,
            y: this.islandY + this.islandHeight / 2,
          };
        }
        getItemCenterPosition(e) {
          return { x: this.islandX + e.x, y: this.islandY + e.y };
        }
        getCenterItem() {
          return this.itemsInItemContainer.find(Au);
        }
        animateZoomIn(e, t) {
          e?.();
          let n = this.getIslandFocusSize(),
            r = [5 * n[0], 5 * n[1]];
          this.isAudioPaused || this.loader.getResourceSound(Ai)?.play(),
            this.focusArea(this.getWorldCenterPosition(), r),
            this.focusIsland(!0, {
              time: kr,
              ease: `easeOutCubic`,
              callbackOnComplete: () => t?.(),
            });
        }
        animateZoomOut(e, t) {
          this.prepareNewItemsAppearing(), this.playBackgroundMusic(`claim`);
          let n = this.getCenterItem();
          n
            ? (this.focusItem(n), n.select(!1), this.itemBackdrop?.show(n, !1))
            : this.focusArea(
                this.getIslandCenterPosition(),
                A(S.CentralSquare)
              );
          let r = !1;
          this.dispatchDataEvent({
            type: `reveal-animation-available-trigger`,
            triggerCallback: () => {
              r ||
                ((r = !0),
                e?.(),
                n && (n.deselect(!0, le), this.itemBackdrop?.hide(n, !0)),
                this.focusIsland(!0, {
                  time: le,
                  ease: `easeInOutCubic`,
                  callbackOnComplete: () =>
                    this.animateNewItemsAppearing(() => {
                      this.playBackgroundMusic(null), t?.();
                    }),
                }));
            },
          });
        }
        animatePodium(e, t, n) {
          let r = this.getCenterItem(),
            i = () => {
              e ||
                (r
                  ? this.focusItem(r, !0, {
                      time: ot,
                      callbackOnComplete: () => this.animateZoomOut(t, n),
                    })
                  : this.animateZoomOut(t, n));
            };
          if (!r) {
            i();
            return;
          }
          if (
            ((this.podiumAnim = new Zu({
              centerItem: r,
              centerItemPos: this.getItemCenterPosition(r),
              focusAreaFunction: ([e, t], n, r) => {
                this.focusArea({ x: e, y: t }, n, r, {
                  time: 500,
                  ease: `easeInOutSine`,
                });
              },
            })),
            !this.podiumAnim.isAnimatable)
          ) {
            this.podiumAnim.destroy(), (this.podiumAnim = void 0), i();
            return;
          }
          this.dispatchDataEvent({ type: `podium-animation-started` }),
            e || this.playBackgroundMusic(`podium`),
            r.select(!1),
            this.focusItem(r, !1),
            this.itemBackdrop?.show(r, !1),
            this.podiumAnim.animate(e, i);
        }
        animateTimeLapse(e, t) {
          if (
            (this.itemSelected && this.deselectAllItems(), !this.gameConfig)
          ) {
            e?.(), t?.();
            return;
          }
          e?.(),
            (this.timeLapseAnimation ||= (this.drawIsland(), new md())),
            this.drawOpeningTransitionClouds(),
            this.playBackgroundMusic(`timelapse`);
          let n = this.getCenterItem();
          if (n) {
            let e = this.getItemCenterPosition(n),
              t = dn(n.config.type),
              r = { x: e.x + t[0], y: e.y + t[1] },
              i = Ft(n.config.type),
              a = [i[0] + 256, i[1] + 256];
            this.focusArea(r, a, !1),
              this.focusIsland(!0, { time: dd, ease: `easeInQuad` });
          }
          this.timeLapseAnimation.animate(
            this.gameConfig.terrain,
            this.gameConfig.items,
            this.itemsInItemContainer,
            this.tilesContainer?.children ?? [],
            this.tilesGrassContainer?.children ?? [],
            this.drawTerrainTiles.bind(this),
            t
          );
        }
        prepareNewItemsAppearing() {
          (this.appearingItems = this.itemsInItemContainer.filter(
            (e) => e.shouldAnimateAppear || e.shouldAnimateLeaguePoints
          )),
            this.appearingItems.forEach((e) => e.prepareAnimateAppear());
        }
        animateNewItemsAppearing(e) {
          if (this.isDestroyed) return;
          this.itemsToBeAnimated = (0, Sd.default)(
            this.appearingItems,
            (e) =>
              e.shouldAnimateLeaguePoints && !e.shouldAnimateAppear
                ? 0
                : e.shouldAnimateCreation && !tr(e.config.type)
                ? 1
                : e.shouldAnimateUpgrade
                ? 2
                : 3,
            (e) => e.tileCountX * e.tileCountY,
            (e) =>
              Math.hypot(
                this.islandWidth / 2 - e.x,
                this.islandHeight / 2 - e.y
              )
          );
          let t = () => {
              this.itemsToBeAnimated.forEach((e) => e.cleanUpAnimateAppear()),
                e?.();
            },
            n = -1,
            r = () => {
              if (this.isDestroyed) return;
              n++;
              let e = this.itemsToBeAnimated[n];
              if (!e) {
                let e =
                  this.gameConfig?.revealEndFocus === `gift`
                    ? this.itemsInItemContainer.find(
                        (e) =>
                          e.config.notificationType === `gift` &&
                          e.config.animateAppear
                      )
                    : void 0;
                e
                  ? (this.toggleSelectItem(e), e.dismissNotification(), t())
                  : this.focusIsland(!0, { time: Re, callbackOnComplete: t });
                return;
              }
              this.focusItem(e, !0, {
                callbackOnComplete: () => {
                  this.isDestroyed ||
                    e.animateAppear(
                      this.viewport,
                      (t) => {
                        this.isDestroyed ||
                          (t === `about-to-create` &&
                            this.dispatchDataEvent({
                              type: `item-about-to-be-created`,
                              item: e.config,
                            }),
                          t === `create` &&
                            this.dispatchDataEvent({
                              type: `item-created`,
                              item: e.config,
                            }),
                          t === `upgrade` &&
                            this.dispatchDataEvent({
                              type: `item-upgraded`,
                              item: e.config,
                            }));
                      },
                      r
                    );
                },
              });
            };
          r();
        }
        prepareBrandEventPortalPointsAnims() {
          if (this.isDestroyed) return;
          this.brandEventPortalPointsAnims.forEach((e) => e.destroy()),
            (this.brandEventPortalPointsAnims = []);
          let e = this.foregroundContainer,
            t = this.getCenterItem(),
            n = this.itemsInItemContainer.filter(
              (e) =>
                !!e.config.animateAppear &&
                (e.config.xp ?? 0) > 0 &&
                Sn(e.config) &&
                e.itemSpriteRef instanceof To &&
                (e.config.data.points ?? 0) - (e.config.xp ?? 0) <
                  (e.config.data.total ?? 0)
            );
          !e ||
            !t ||
            n.length === 0 ||
            (this.brandEventPortalPointsAnims = n.map((n) => {
              let r = new Za({
                container: e,
                centerRef: t,
                itemRef: n,
                viewport: {
                  x: -this.islandX,
                  y: -this.islandY,
                  width: this.worldWidth,
                  height: this.worldHeight,
                },
              });
              return r.prepare(), r;
            }));
        }
        animateBrandEventPortalPoints(e) {
          if (!this.isDestroyed) {
            if (this.brandEventPortalPointsAnims.length === 0) {
              e?.();
              return;
            }
            Promise.allSettled(
              this.brandEventPortalPointsAnims.map(
                (e) => new Promise((t) => e.animate(t))
              )
            )
              .finally(() => {
                this.brandEventPortalPointsAnims.forEach((e) => e.destroy()),
                  (this.brandEventPortalPointsAnims = []),
                  e?.();
              })
              .catch(() => {
                this.warn(
                  `Error animating Brand Event Portal points animation`
                );
              });
          }
        }
        focusArea(e, t, n = !1, r) {
          if (!this.viewport) return;
          let [i, a] = t,
            { x: o, y: s } = e;
          if (((this.viewportFocusedArea = { center: e, size: t }), !n)) {
            this.viewport.fit(!0, i, a),
              this.viewport.moveCenter(o, s),
              r?.callbackOnComplete?.(this.viewport);
            return;
          }
          this.viewport.animate({
            position: e,
            ...this.getViewportSizeOptionToFitSize(t),
            ...r,
          });
        }
        focusItem(e, t = !1, n) {
          let r = { time: 500, ease: `easeInOutSine` },
            i = this.getItemCenterPosition(e),
            a = dn(e.config.type),
            o = { x: i.x + a[0], y: i.y + a[1] },
            s = Ft(e.config.type, e.islandConfig);
          this.focusArea(o, s, t, { ...r, ...n }),
            t &&
              !this.isAudioPaused &&
              (this.focusSounds?.forEach((e) => e.stop()),
              z(this.focusSounds ?? [])?.play()),
            this.passingClouds?.fadeOut(),
            this.cornerDecoration?.fadeOut();
        }
        focusIsland(e = !1, t) {
          this.passingClouds?.fadeIn(),
            this.cornerDecoration?.fadeIn(),
            this.focusArea(
              this.getIslandCenterPosition(),
              this.getIslandFocusSize(),
              e,
              { time: 500, ease: `easeInOutSine`, ...t }
            ),
            e &&
              !this.isAudioPaused &&
              (this.focusSounds?.forEach((e) => e.stop()),
              z(this.focusSounds ?? [])?.play());
        }
        static async preload(e) {
          let t = ta(e);
          return super.preloadResourcesAsync(t, {
            registerSoundResources: !0,
            registerSpineResources: !0,
          });
        }
        getResources() {
          return ta(this.preloadInfo);
        }
        gameSetup() {
          oi(),
            this.initializeData(),
            this.initializeViewport(),
            this.initialAnimation(),
            this.initializeDebug(),
            (this.ambienceSound = this.loader.getResourceSound(yt)),
            this.isAudioPaused || this.ambienceSound?.play(),
            (this.focusSounds = this.loader.getResourceSounds(wt));
        }
        gameUpdate() {
          Dn() ||
            console.log(
              `[!] IslandGame: gameUpdate() is not supported, no action will be taken`
            );
        }
        gameLoop(e, t) {
          let n = t / 1e3;
          this.backgroundDecoration?.update(n),
            this.itemsInItemContainer.forEach((e) => e.update?.(n)),
            this.seasonalParticles?.update(n),
            this.passingClouds?.update(t),
            this.brandEventPortalPointsAnims.forEach((e) => e.update(n));
        }
        gameResize(e, t) {
          if (
            (this.viewport?.resize(e, t),
            this.cornerDecoration?.resize(e),
            this.drawVignette(),
            this.viewportFocusedArea)
          ) {
            let { center: e, size: t } = this.viewportFocusedArea;
            this.focusArea(e, t);
          }
        }
        gameDestroy() {
          this.tapHandAnimation?.destroy(),
            this.viewport?.destroy(),
            this.podiumAnim?.destroy(),
            this.itemsToBeAnimated.forEach((e) => e.destroy()),
            this.ambienceSound?.stop(),
            this.passingClouds?.destroy(),
            this.seasonalParticles?.destroy(),
            this.cornerDecoration?.destroy(),
            this.brandEventPortalPointsAnims.forEach((e) => e.destroy()),
            (this.brandEventPortalPointsAnims = []),
            this.linkGameTheme(void 0);
        }
      });
  }))();
}
export { Ci as i, xd as n, wd as r, Cd as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/game-BP2PU-_N.js.map
