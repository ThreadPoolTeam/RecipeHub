import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { ht as t } from "./lib-BTerfQ6O.js";
import { u as n } from "./pixijs-game-zi5bgXGP.js";
var r;
function i() {
  return (i = e(() => {
    n(),
      (r = () => {
        t.WHITE.baseTexture.resource.source
          .getContext(`2d`)
          ?.fillRect(0, 0, 1, 1);
      });
  }))();
}
export { i as n, r as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/android-webgl-hack-BKgRYXLm.js.map
