import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import {
  Bi as t,
  Li as n,
  So as r,
  ai as i,
  ca as a,
  ci as o,
  fa as s,
  ii as c,
  la as l,
  li as u,
  ma as d,
  ni as f,
  oa as p,
  pa as m,
  ri as h,
  sa as g,
  yo as _,
  zi as v,
} from "./solo-z64LhsmC.js";
import { B as y, U as b } from "./lib-BTerfQ6O.js";
import { d as x, u as S } from "./pixijs-game-zi5bgXGP.js";
import {
  a as C,
  d as w,
  f as T,
  l as E,
  m as D,
  n as O,
  o as k,
  p as A,
  s as j,
  t as M,
  u as N,
} from "./game-base-B1GqEX2D.js";
var P;
function F() {
  return (F = e(() => {
    S(),
      c(),
      u(),
      (P = class extends b {
        constructor({
          textures: e,
          bgColor: t,
          bgTexture: n,
          bgShadowTexture: r,
          shouldAnimate: i,
        }) {
          super(),
            (this._spriteEffects = []),
            (this._container = new b()),
            (this._container.x = -10),
            (this._container.y = i ? 100 : 0),
            this.addChild(this._container);
          let a = e.map((e) => ({ texture: e, time: 100 }));
          (this._headSprite = new x(a, !1)),
            (this._headSprite.name = `Head Sprite`),
            (this._headSprite.loop = !0),
            this._headSprite.play(),
            this._headSprite.anchor.set(1, 1),
            this._headSprite.scale.set(0.25, 0.25),
            (this._headSprite.x = -20),
            (this._headSprite.y = -25),
            this._spriteEffects.push(this._headSprite);
          let o = new y(n);
          (o.name = `Bg Sprite`), o.anchor.set(1, 1), (o.tint = t);
          let s = new y(r);
          (s.name = `Bg Shadow Sprite`),
            s.anchor.set(1, 1),
            this._container.addChild(s, o, ...this._spriteEffects),
            i && this.appear();
        }
        appear() {
          (this._tween = o({
            from: { y: 100 },
            to: { y: 0 },
            duration: 300,
            easing: i.EASE_IN_OUT_QUART,
            onTick: ({ y: e }) =>
              this._container.position.set(this._container.position.x, e),
            onFinish: () => {
              this._tween?.destroy();
            },
          })),
            this._tween.play();
        }
        update(e) {
          if (!this.destroyed) {
            for (let t of this._spriteEffects) t.update(e);
            for (let e = this._spriteEffects.length - 1; e >= 0; e--) {
              let t = this._spriteEffects[e];
              t.playing ||
                (t.parent.removeChild(t),
                t.destroy(),
                this._spriteEffects.splice(e, 1));
            }
          }
        }
        destroy() {
          super.destroy(), this._tween?.destroy();
        }
      });
  }))();
}
var I, L, R, z;
function B() {
  return (B = e(() => {
    _(),
      g(),
      l(),
      d(),
      D(),
      F(),
      N(),
      E(),
      O(),
      t(),
      h(),
      (I = 70),
      (L = r() ? s(0) : Math.random),
      (R = m(L)),
      (z = class extends M {
        constructor(e, t, n) {
          super(e, v.Solo, t, n),
            (this._clickCallback = this.handleClick.bind(this)),
            (this._processingHangedBlock = !1),
            (this._isVisible = !1),
            (this._timer = 0),
            (this._bonusTime = 0),
            (this._showBonus = !0),
            (this._playingBonusDisappearAnimation = !1),
            (this._bonusShown = !1),
            (this._bonusBlocksSpawned = 0),
            (this._processingBonusBlocks = !1),
            (this._currentHangingBlockCol = -1),
            (this._finishData = { missedBlocks: 0, blocks: 0, rows: 0 }),
            (this._blocksData = []);
        }
        get tower() {
          return this._teams[0].tower;
        }
        get lowestColumnOfTower() {
          let [e, t] = this.tower.getTowerGridRowPos(),
            n = {};
          for (let r = e; r < t + 1; r++) n[r] = 0;
          return Object.entries(
            this._blocksData.reduce(
              (e, t) => ({
                ...e,
                [t.column]: e[t.column] ? e[t.column] + 1 : 1,
              }),
              n
            ) || n
          )
            .sort((e, t) => e[1] - t[1])
            .map((e) => parseInt(e[0]))[0];
        }
        getConfigValue(e, t) {
          return this.gameConfig?.[e] ?? t;
        }
        emitBlockScoreEvent(e) {
          e !== n.TooHigh &&
            (this.dispatchDataEvent({ type: f.Score, scoreType: e }),
            this.updateFinishData(e));
        }
        emitBlockEvent(e) {
          this._blocksData.push({ column: e }),
            this.dispatchDataEvent({ type: f.AddBlock, col: e });
        }
        emitBlockFlyEvent() {
          this.dispatchDataEvent({ type: f.BlockFly });
        }
        updateFinishData(e) {
          if (e === n.Misses) {
            this._finishData.missedBlocks += 1;
            return;
          }
          (this._finishData.blocks += 1),
            e === n.CompletesRow && (this._finishData.rows += 1);
        }
        handleClick(e) {
          e.stopPropagation(),
            !this.isGameFinished() && this.hangingBlockCallback();
        }
        hangingBlockCallback() {
          this._processingHangedBlock ||
            ((this._processingHangedBlock = !0),
            this.emitBlockFlyEvent(),
            this.tower.dropHangingBlock((e, t, r, i) => {
              if ((this.emitBlockScoreEvent(t), t === n.Misses)) {
                this.addHangingBlock();
                return;
              }
              this.emitBlockEvent(e),
                this.updateTowerViewport(),
                i && !r && this.dispatchDataEvent({ type: f.OnTrackToBonus }),
                r && !this._playingBonusDisappearAnimation
                  ? (this.dispatchDataEvent({ type: f.BonusReached }),
                    this.disableBonus(),
                    this.spawnBonusBlocks())
                  : this.addHangingBlock();
            }));
        }
        spawnBonusBlock() {
          let e = this.gameConfig?.bonusCompletingLowestColumns
            ? this.lowestColumnOfTower
            : void 0;
          this.emitBlockFlyEvent(),
            this.tower.addBonusBlock(
              (e, t) => {
                this.emitBlockScoreEvent(t),
                  this.emitBlockEvent(e),
                  this.updateTowerViewport(),
                  (this._bonusBlocksSpawned += 1),
                  this._bonusBlocksSpawned ===
                  this.getConfigValue(`bonusBlocksAmount`, 9)
                    ? (this._finishProcessingBonusBlocksTimeout = setTimeout(
                        () => {
                          (this._processingBonusBlocks = !1),
                            this.addHangingBlock();
                        },
                        1e3
                      ))
                    : this.spawnBonusBlock();
              },
              `solo`,
              e
            );
        }
        spawnBonusBlocks() {
          (this._processingBonusBlocks = !0),
            this.tower.removeHangingBlock(),
            (this._bonusBlocksSpawned = 0),
            this.spawnBonusBlock();
        }
        addHangingBlock() {
          this._processingBonusBlocks ||
            this.isGameFinished() ||
            ((this._processingHangedBlock = !1), this.tower.addHangingBlock());
        }
        enableBonus() {
          (this._showBonus = !1),
            (this._bonusShown = !0),
            this.dispatchDataEvent({ type: f.ShowBonus }),
            this.tower.enableBonus(this.getConfigValue(`bonusLength`, 4), !0);
        }
        disableBonus(e = !1) {
          (this._bonusShown = !1),
            e && (this._playingBonusDisappearAnimation = !0),
            this.tower.disableBonus(e, () => {
              this._playingBonusDisappearAnimation = !1;
            });
        }
        updateTowerViewport() {
          let { tower: e, viewport: t } = this._teams[0];
          e.viewportBounds = t.viewportBounds;
        }
        updateBgViewport() {
          let { background: e, viewport: t } = this._teams[0];
          e.viewportBounds = t.viewportBounds;
        }
        updateGorillaKingHeadPos(e, t) {
          this._gorillaKingHead &&
            ((this._gorillaKingHead.x = e),
            (this._gorillaKingHead.y = t),
            this.setChildIndex(
              this._gorillaKingHead,
              this.children.length - 1
            ));
        }
        removeGorillaKingHead() {
          this._gorillaKingHead &&=
            (this.removeChild(this._gorillaKingHead), void 0);
        }
        attachClickEvent() {
          this.app.stage.onpointerdown = this._clickCallback;
        }
        updateViewportsCamera(e) {
          let t = (e) => {
              let { viewportHeight: t, viewportScale: n } = e,
                r = 75 * n,
                i = this.getConfigValue(`bonusLength`, 4) * r,
                a = Math.max(0, t - i - 300);
              return Math.floor(a / r);
            },
            n = (e) => {
              let { tower: t, viewport: n } = e,
                { viewportHeight: r, viewportScale: i } = n,
                a = 75 * i,
                o = 150 * i,
                s = this._towerBottomOffset * i,
                c = this.getConfigValue(`bonusLength`, 4) * a,
                l = o + s,
                u = Math.max(0, r - c - l - 300);
              return t.highestFinishedGridRow * a <= u;
            };
          this._teams.forEach((r) => {
            let { tower: i, viewport: a } = r;
            if (n(r)) {
              a.moveCamera(i.x, i.y, e);
              return;
            }
            let o = i.y - 150 + -i.highestFinishedGridRow * 75,
              { viewportUnscaledHeight: s } = a,
              c = -s / 2,
              l = t(a),
              u = Math.max(2, l) * 75,
              d = i.x,
              f = o + c + u;
            a.moveCamera(d, f, e);
          });
        }
        get isVisible() {
          return this._isVisible;
        }
        set isVisible(e) {
          this._isVisible = e;
        }
        addGorillaKingHead(e = !0) {
          if (this._gorillaKingHead) return;
          let t = this.loader.getResourceTexture(w),
            n = this.loader.getResourceTexture(T);
          if (!t || !n) return;
          let r = this.loader.getResourceTextures(A);
          this._gorillaKingHead = new P({
            textures: r,
            shouldAnimate: e,
            bgTexture: t,
            bgShadowTexture: n,
            bgColor: p(
              this.gameConfig?.towers?.[0]?.theme || a.Red,
              this._skin
            ),
          });
          let i = this.teamViewportsSizes[0]
              ? this.teamViewportsSizes[0].width
              : this.initialWidth,
            o = this.teamViewportsSizes[0]
              ? this.teamViewportsSizes[0].height
              : this.initialHeight;
          (this._gorillaKingHead.x = i),
            (this._gorillaKingHead.y = o),
            this.addChild(this._gorillaKingHead);
        }
        gameSetup() {
          super.gameSetup(),
            this.updateTowerViewport(),
            this.updateBgViewport(),
            this.attachClickEvent(),
            this.addHangingBlock(),
            this.gameConfig &&
              ((this._blocksData = [...this.gameConfig.blocks]),
              (this._iBlock = this.gameConfig.blocks.length),
              (this._bonusTime =
                this.gameConfig.gameDuration *
                R(
                  this.getConfigValue(`minPercentTimeBonusSpawn`, j),
                  this.getConfigValue(`maxPercentTimeBonusSpawn`, k)
                )),
              this.gameConfig.showKingGorillaHead &&
                this.addGorillaKingHead(!1));
        }
        gameLoop(e, t) {
          if (!this._isVisible) return;
          let n = this._processingHangedBlock
            ? -1
            : this.tower.getHangingBlockCol();
          if (
            (n !== this._currentHangingBlockCol &&
              ((this._currentHangingBlockCol = n),
              this.dispatchDataEvent({
                type: f.HangingBlockColumnChange,
                col: n,
              })),
            this._gorillaKingHead?.update(e),
            this._teams.forEach(
              ({
                tower: n,
                background: r,
                viewport: i,
                confettiEmitter: a,
              }) => {
                r.update(t),
                  n.update(e),
                  a &&
                    (a.update(t * 0.001),
                    (a.x = n.x),
                    (a.y = i.viewportBounds.top - I));
              }
            ),
            !this.isGameFinished())
          ) {
            if (
              ((this._timer += t),
              this.dispatchDataEvent({ type: f.Tick, deltaMS: t }),
              this.gameConfig?.gameDuration && !this._processingHangedBlock)
            ) {
              let e = this.getConfigValue(`hangingBlockMovementStart`, C),
                t = this.getConfigValue(`hangingBlockMovementEnd`, 400),
                n = this._timer / this.gameConfig.gameDuration,
                r = (e - t) / this.gameConfig.totalMiniGameCount,
                i = e - (this.gameConfig.numberOfGame - 1) * r - r * n;
              this.tower.updateHangingBlockMovementSpeed(i);
            }
            this._timer >= this._bonusTime &&
              this._showBonus &&
              this.enableBonus(),
              this._timer >=
                this._bonusTime + this.getConfigValue(`bonusDuration`, 8e3) &&
                this._bonusShown &&
                !this._playingBonusDisappearAnimation &&
                this.disableBonus(!0);
          }
        }
        gameUpdate() {
          this.isGameFinished() ||
            (this.gameConfig &&
              this.gameConfig.showKingGorillaHead &&
              this.addGorillaKingHead(!0),
            this.updateViewportsCamera());
        }
        gameResize(e, t) {
          super.gameResize(e, t), this.updateGorillaKingHeadPos(e, t);
        }
        isGameFinished() {
          return !!(
            this.gameConfig &&
            this._timer >= this.gameConfig.gameDuration &&
            !this._processingHangedBlock &&
            !this._bonusShown &&
            !this._playingBonusDisappearAnimation &&
            !this._processingBonusBlocks
          );
        }
        gameFinished() {
          return (
            this.tower.disableMonster(),
            this.gameConfig?.removeUIOnFinish
              ? (this.removeGorillaKingHead(), this.tower.destroy())
              : (this.tower.removeHangingBlock(),
                this.gameConfig?.showKingGorillaHead &&
                  this.createConfetti(this._teams[0])),
            this._finishData
          );
        }
        gameDestroy() {
          super.gameDestroy(),
            this._finishProcessingBonusBlocksTimeout &&
              clearTimeout(this._finishProcessingBonusBlocksTimeout);
        }
      });
  }))();
}
B();
export { z as default };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/game-solo-DGNxua74.js.map
