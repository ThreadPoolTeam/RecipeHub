import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { kr as t } from "./solo-z64LhsmC.js";
var n, r, i;
function a() {
  return (a = e(() => {
    t(),
      (n = (e, t) => e?.type?.id === t?.type?.id),
      (r = (e, t) => e?.item?.id === t?.item?.id),
      (i = (e, t) => r(e, t) && n(e, t));
  }))();
}
export { a as i, n, i as r, r as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/utils-BM7-EmnV.js.map
