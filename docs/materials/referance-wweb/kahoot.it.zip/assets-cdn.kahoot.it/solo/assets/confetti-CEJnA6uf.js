import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { ht as t } from "./lib-BTerfQ6O.js";
import { u as n } from "./pixijs-game-zi5bgXGP.js";
import { i as r } from "./game-BP2PU-_N.js";
var i;
function a() {
  return (a = e(() => {
    i = class {
      static {
        this.type = `colorRandomStatic`;
      }
      stringColorToNumber(e) {
        let t = e;
        return (
          e.startsWith(`#`)
            ? (t = e.slice(1))
            : e.startsWith(`0x`) && (t = e.slice(2)),
          parseInt(t, 16)
        );
      }
      constructor(e) {
        (this.order = 2),
          (this.values = e.colors.map((e) => this.stringColorToNumber(e)));
      }
      initParticles(e) {
        let t = e;
        for (; t; )
          (t.tint =
            this.values[Math.floor(Math.random() * this.values.length)]),
            (t = t.next);
      }
    };
  }))();
}
var o;
function s() {
  return (s = e(() => {
    o = (e, t) => {
      let n = document.createElement(`canvas`);
      return (n.width = e), (n.height = t), n.getContext(`2d`) ?? void 0;
    };
  }))();
}
var c, l, u, d;
function f() {
  return (f = e(() => {
    n(),
      s(),
      (c = (e) => {
        let n = o(e, e);
        return n
          ? (n.clearRect(0, 0, e, e),
            (n.fillStyle = `#ffffff`),
            n.fillRect(0, 0, e, e),
            t.from(n.canvas, { pixiIdPrefix: `confetti` }))
          : t.EMPTY;
      }),
      (l = (e) => {
        let n = o(e, e);
        return n
          ? (n.clearRect(0, 0, e, e),
            (n.fillStyle = `#ffffff`),
            n.beginPath(),
            n.arc(e / 2, e / 2, e / 2, 0, Math.PI * 2),
            n.fill(),
            t.from(n.canvas, { pixiIdPrefix: `confetti` }))
          : t.EMPTY;
      }),
      (u = (e, n) => {
        let r = o(e, n);
        return r
          ? (r.clearRect(0, 0, e, n),
            (r.fillStyle = `#ffffff`),
            r.fillRect(0, 0, e, n),
            t.from(r.canvas, { pixiIdPrefix: `confetti` }))
          : t.EMPTY;
      }),
      (d = (e) => [l(e), c(e), u(e, e * 2)]);
  }))();
}
var p;
function m() {
  return (m = e(() => {
    p = ({ x: e = -500, y: t = 0, width: n = 1e3, height: r = 0 }) => ({
      lifetime: { min: 4, max: 8 },
      frequency: 0.004,
      emitterLifetime: -1,
      maxParticles: 1e3,
      addAtBack: !1,
      pos: { x: 0, y: 0 },
      behaviors: [
        {
          type: `moveSpeed`,
          config: {
            speed: {
              list: [
                { time: 0, value: 20 },
                { time: 1, value: 500 },
              ],
            },
            minMult: 1,
          },
        },
        {
          type: `scale`,
          config: {
            scale: {
              list: [
                { time: 0, value: 1 },
                { time: 1, value: 0.001 },
              ],
            },
            minMult: 1,
          },
        },
        {
          type: `rotation`,
          config: {
            accel: 0,
            minSpeed: 0,
            maxSpeed: 200,
            minStart: 110,
            maxStart: 70,
          },
        },
        {
          type: `spawnShape`,
          config: { type: `rect`, data: { x: e, y: t, w: n, h: r } },
        },
        {
          type: `colorRandomStatic`,
          config: {
            colors: [
              `#DFFF00`,
              `#FFBF00`,
              `#FF7F50`,
              `#DE3163`,
              `#9FE2BF`,
              `#40E0D0`,
              `#6495ED`,
              `#CCCCFF`,
            ],
          },
        },
      ],
    });
  }))();
}
function h() {
  return (h = e(() => {
    f(), r(), m();
  }))();
}
export {
  l as a,
  o as c,
  a as d,
  d as i,
  s as l,
  p as n,
  c as o,
  m as r,
  f as s,
  h as t,
  i as u,
};
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/confetti-CEJnA6uf.js.map
