import { n as e } from "./rolldown-runtime-B0Z9INg1.js";
import { l as t } from "./app-Bv1T6OmB.js";
import {
  Da as n,
  Ea as r,
  Oa as i,
  Or as a,
  Ta as o,
  fa as s,
  ha as c,
  io as l,
  ma as u,
  ro as d,
} from "./solo-z64LhsmC.js";
import { ht as f } from "./lib-BTerfQ6O.js";
import { c as p, l as m, u as h } from "./pixijs-game-zi5bgXGP.js";
import { i as g } from "./utils-BM7-EmnV.js";
function _() {
  return (_ = e(() => {
    t(), h(), a(), m(), g();
  }))();
}
var v, y, b;
function x() {
  return (x = e(() => {
    h(),
      r(),
      d(),
      m(),
      (v = `pixi-avatar-loader-spine`),
      (y = [350, 350]),
      (b = class e extends p {
        static get instance() {
          return (e._instance ||= new e()), e._instance;
        }
        constructor() {
          super(),
            (this._textureSize = y),
            (this._baseTextures = {}),
            (this._itemTextures = {}),
            (this.renderSvgToImg = (e, t, n) => {
              let [r, i] = this.getTextureSize();
              o(e)
                .then((e) => {
                  let a = new DOMParser().parseFromString(e, `image/svg+xml`);
                  a.documentElement.setAttribute(`width`, String(r)),
                    a.documentElement.setAttribute(`height`, String(i));
                  let o = new XMLSerializer().serializeToString(a),
                    s = new Blob([o], { type: `image/svg+xml;charset=utf-8` }),
                    c = URL.createObjectURL(s),
                    l = new Image();
                  (l.onload = () => {
                    URL.revokeObjectURL(c), t(l);
                  }),
                    (l.onerror = (e) => {
                      URL.revokeObjectURL(c),
                        this.warn(`Failed to create image from SVG`, e),
                        n();
                    }),
                    (l.src = c);
                })
                .catch((e) => {
                  this.warn(`Failed to get SVG code`, e), n();
                });
            }),
            (this.logType = `loader`),
            this.log(`Created`);
        }
        getTextureSize() {
          return this._textureSize;
        }
        setTextureSize(e, t) {
          this._textureSize = [e, t];
        }
        getBaseTexture(e) {
          let t = e?.type?.id ?? 0,
            n = e?.type?.resource;
          if (!t || !n) {
            this.log(
              `No ID or resource URL provided for base texture (id: ${t}, resource: ${n})`
            );
            return;
          }
          return (
            this.log(`Getting avatar base texture with id: ${t}`),
            this._baseTextures[t]
              ? (this.log(`Base texture found, returning it`),
                this._baseTextures[t])
              : (this.log(`Creating new texture for base id: ${t}`),
                this.createTexturePromise(`base`, t, n))
          );
        }
        getItemTexture(e) {
          let t = e?.item?.id ?? 0,
            n = e?.item?.resource;
          if (!t || !n) {
            this.log(
              `No ID or resource URL provided for item texture (id: ${t}, resource: ${n})`
            );
            return;
          }
          return (
            this.log(`Getting avatar item texture with id: ${t}`),
            this._itemTextures[t]
              ? (this.log(`Item texture found, returning it`),
                this._itemTextures[t])
              : (this.log(`Creating new texture for item id: ${t}`),
                this.createTexturePromise(`item`, t, n))
          );
        }
        destroyBaseTexture(e) {
          let t = this._baseTextures[e];
          t instanceof f && t.destroy(!0), delete this._baseTextures[e];
        }
        destroyItemTexture(e) {
          let t = this._itemTextures[e];
          t instanceof f && t.destroy(!0), delete this._itemTextures[e];
        }
        destroyAllTextures() {
          l(this._baseTextures).forEach((e) => this.destroyBaseTexture(e)),
            l(this._itemTextures).forEach((e) => this.destroyItemTexture(e));
        }
        dispose() {
          this.destroyAllTextures();
        }
        createTexturePromise(e, t, n) {
          let r = new Promise((r, i) => {
              this.renderSvgToImg(
                n,
                (n) => {
                  let a =
                    e === `item` ? this._itemTextures : this._baseTextures;
                  if (!a[t]) {
                    i();
                    return;
                  }
                  let o = f.from(n, { pixiIdPrefix: v });
                  (a[t] = o), r(o);
                },
                () => {
                  i();
                }
              );
            }),
            i = e === `item` ? this._itemTextures : this._baseTextures;
          return (i[t] = r), r;
        }
      });
  }))();
}
function S() {
  return (S = e(() => {
    h(), _();
  }))();
}
function C() {
  return (C = e(() => {
    _(), x(), S();
  }))();
}
var w, T, E, D;
function O() {
  return (O = e(() => {
    i(),
      u(),
      (w =
        `#864CBF.#6BCB3C.#2E9B00.#58A6E8.#2167C9.#FF4B6A.#F2173F.#FFD04D.#FFB000.#FFA33A.#F56A00.#45C7CC.#18A7AC.#FF96A3.#F56B78.#74E0B5.#2CC48F.#8BC7FF.#219FE9.#63D9F2.#00AFCF.#8B8AF2.#5B59D9.#C9EB5B.#8BD900.#F08BC3.#F748A5`.split(
          `.`
        )),
      (T =
        `#2E9B00.#1F7A00.#2167C9.#1448B5.#F2173F.#C60929.#FFB000.#D89B00.#F56A00.#D94B00.#18A7AC.#0A8A8F.#F56B78.#D94F5C.#2CC48F.#1D9B72.#219FE9.#2D7CCF.#00AFCF.#008DA6.#5B59D9.#3C3BB3.#8BD900.#7FB000.#F748A5.#C73C8D`.split(
          `.`
        )),
      (E = [
        `#1F7A00`,
        `#1448B5`,
        `#C60929`,
        `#D89B00`,
        `#D94B00`,
        `#0A8A8F`,
        `#D94F5C`,
        `#1D9B72`,
        `#2D7CCF`,
        `#008DA6`,
        `#3C3BB3`,
        `#7FB000`,
        `#C73C8D`,
      ]),
      (D = (e, t) => {
        let r = s(n(e));
        return {
          shirt: t?.shirt ?? c(w, r),
          pants: t?.pants ?? c(T, r),
          shoes: t?.shoes ?? c(E, r),
        };
      });
  }))();
}
function k(e, t, n = Math.random) {
  return (
    (e = Math.ceil(e)), (t = Math.floor(t)), Math.floor(n() * (t - e + 1)) + e
  );
}
function A(e, t) {
  return Math.random() * (t - e) + e;
}
function j(e, t = Math.random) {
  return e[k(0, e.length - 1, t)];
}
function M() {
  return (M = e(() => {}))();
}
export { O as a, x as c, D as i, A as n, C as o, j as r, b as s, M as t };
//# sourceMappingURL=https://sourcemaps.kahoot.it/assets/random-XVBdEtiK.js.map
