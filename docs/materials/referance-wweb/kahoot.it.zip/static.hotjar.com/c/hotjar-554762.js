window.hjSiteSettings = window.hjSiteSettings || {
  site_id: 554762,
  rec_value: 1.0,
  state_change_listen_mode: "automatic_with_fragments",
  record: true,
  continuous_capture_enabled: true,
  recording_capture_keystrokes: true,
  session_capture_console_consent: false,
  anonymize_digits: false,
  anonymize_emails: false,
  suppress_all: false,
  suppress_all_on_specific_pages: [],
  suppress_text: null,
  suppress_location: false,
  user_attributes_enabled: true,
  legal_name: "Kahoot! AS",
  privacy_policy_url: "https://kahoot.com/privacy-policy/",
  deferred_page_contents: [],
  record_targeting_rules: [
    {
      component: "url",
      match_operation: "simple",
      pattern: "https://create.kahoot.it/security/account-sharing",
      negate: false,
    },
  ],
  heatmaps: [],
  polls: [
    {
      id: 1887242,
      created_epoch_time: 1792142116,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "d18e8484-0fab-44ec-be2b-3cc857fbe0c5",
            type: "single-close-ended",
            text: "👋 Hi there! We're looking for feedback on K! Language Learning. Schedule a chat?",
            required: false,
            nextIfSkipped: "byOrder",
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "Yes, sure", comments: false },
              { text: "Not today, thanks", comments: false },
            ],
            nextByAnswer: ["byOrder", "thankYou"],
            next: "byAnswer",
          },
          {
            uuid: "3def2abe-dead-48eb-ad6b-6e61f608ed4a",
            type: "title-and-description",
            text: "Find a suitable time slot and let's chat! https://scheduler.zoom.us/laura-korsmaa/language-learning",
            required: true,
            next: "thankYou",
          },
        ],
        thankyou:
          "Thanks! \nhttps://scheduler.zoom.us/laura-korsmaa/language-learning",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "delay",
      display_delay: 5,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "exact",
          negate: false,
          pattern: "https://create.kahoot.it/language-learning",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "ed9e4037-d6e8-4530-a1a1-f92bbf8f1960",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "popover",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#00CE5C",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1882613,
      created_epoch_time: 1789637925,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "bd48f09a-5abe-4194-9aca-6f5ce2011448",
            type: "email",
            text: "Leave your email so we can reach out to you!",
            required: true,
            next: "thankYou",
          },
        ],
        thankyou: "Thanks! ",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "once",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "bbe6dca3-d8c9-4dc2-8a97-11f27d3ee7e0",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#00CE5C",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1870507,
      created_epoch_time: 1782788597,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "6e697d00-1e1f-42ca-85b0-855dd502faea",
            type: "single-open-ended-multiple-line",
            text: "Quick feedback: Why wasn't this helpful?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_usproduction",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_production",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "c3d759ff-607b-4a38-b09e-b5d94433d53a",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "full_screen",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#1368CE",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1870506,
      created_epoch_time: 1782788540,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "6e697d00-1e1f-42ca-85b0-855dd502faea",
            type: "single-open-ended-multiple-line",
            text: "Quick feedback: What made this helpful?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_production",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_usproduction",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "2cefbd86-444e-484b-bdff-7c0d94f8ba63",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "full_screen",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#1368CE",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1854284,
      created_epoch_time: 1775035300,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "6e697d00-1e1f-42ca-85b0-855dd502faea",
            type: "single-open-ended-multiple-line",
            text: "Quick feedback: What made this helpful?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_preview",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_dev",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_experimental",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_stage",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_up_assistant_qa",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "5fb52b2c-f6f5-468d-8fe2-6056ff242616",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "full_screen",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#1368CE",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1853644,
      created_epoch_time: 1774862317,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "6e697d00-1e1f-42ca-85b0-855dd502faea",
            type: "single-open-ended-multiple-line",
            text: "Quick feedback: Why wasn't this helpful?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_experimental",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_preview",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_dev",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_stage",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "thumbs_down_assistant_qa",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "2cd114d0-19ec-4516-92d5-5aa7b628612e",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "full_screen",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#1368CE",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1847520,
      created_epoch_time: 1772418048,
      skin: "light",
      background: "#202641",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "3ab8d6a8-84ed-4d95-8540-9d76f48ba012",
            type: "reaction",
            text: "How would you rate your experience?",
            required: false,
            nextIfSkipped: "byOrder",
            labels: [{ text: "Not good at all" }, { text: "Very good" }],
            reaction_style: "default",
            next: "byOrder",
          },
          {
            uuid: "95b34ea6-f29f-4292-b02c-65ec0fe0daa8",
            type: "single-open-ended-multiple-line",
            text: "Tell us about your experience...",
            required: false,
            nextIfSkipped: "byOrder",
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "718c9300-9ff5-4d19-8650-141d39280750",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#00CE5C",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1835654,
      created_epoch_time: 1767628358,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "c7a5c24d-1951-453b-a69c-cc97de435f36",
            type: "multiple-close-ended",
            text: "What do you use Kahoot! mostly for? Select top 3.",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself (ie. flashcards)", comments: false },
              { text: "For class presentations/ assignments", comments: false },
              { text: "To study in a group", comments: false },
              { text: "To join student-hosted quizzes", comments: false },
              { text: "To join teacher-hosted class quizzes", comments: false },
              { text: "For study breaks", comments: false },
              { text: "For parties and celebrations", comments: false },
              { text: "To teach students", comments: false },
              { text: "To build new skills", comments: false },
              { text: "Other", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "cc67621a-b117-4c35-81ce-f1f859174c33",
            type: "multiple-close-ended",
            text: "What’s the most valuable part of your current plan?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "Up to 200 participants per session", comments: false },
              {
                text: "AI-powered features to create study sets instantly",
                comments: false,
              },
              {
                text: "All question types to create better kahoots",
                comments: false,
              },
              {
                text: "Practice sessions in Test mode to prepare for exams",
                comments: false,
              },
              { text: "Access to premium ready-made content", comments: false },
              { text: "Premium study groups options", comments: false },
              { text: "Other", comments: true },
              {
                text: "Scanning and importing large documents to create study sets with AI",
                comments: false,
              },
              {
                text: "More creation tools for personalization, i.e. full size background images",
                comments: false,
              },
            ],
            next: "byOrder",
          },
          {
            uuid: "27bedaaf-f902-460d-9535-94bda23fba2c",
            type: "multiple-close-ended",
            text: "Which of the following features are you aware of or have used?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "AI Experiences", comments: false },
              { text: "Offline mode", comments: false },
              { text: "Test Mode", comments: false },
              { text: "Study buddies", comments: false },
              { text: "I haven't used any of these", comments: false },
              { text: "I wasn't aware of any of these", comments: false },
            ],
            next: "byOrder",
          },
          {
            uuid: "da89de14-43ef-4dd3-befb-2b45facbc6a3",
            type: "single-close-ended",
            text: "What would most improve your experience with Kahoot! now?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "Better guidance when getting started", comments: false },
              { text: "More tips and reminder over time", comments: false },
              {
                text: "Seeing real examples of how others use Kahoot! for studying",
                comments: false,
              },
              {
                text: "Nothing, it already works well for me",
                comments: false,
              },
            ],
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for completing the survey!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "ddea3095-3ba3-432a-9331-646c8103357d",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1835645,
      created_epoch_time: 1767627450,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "c7a5c24d-1951-453b-a69c-cc97de435f36",
            type: "multiple-close-ended",
            text: "What do you use Kahoot! mostly for? Select top 3.",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself (ie. flashcards)", comments: false },
              { text: "For class presentations/ assignments", comments: false },
              { text: "To study in a group", comments: false },
              { text: "To join student-hosted quizzes", comments: false },
              { text: "To join teacher-hosted class quizzes", comments: false },
              { text: "For study breaks", comments: false },
              { text: "For parties and celebrations", comments: false },
              { text: "To teach students", comments: false },
              { text: "To build new skills", comments: false },
              { text: "Other", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "cc67621a-b117-4c35-81ce-f1f859174c33",
            type: "multiple-close-ended",
            text: "What’s the most valuable part of your current plan?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "Up to 100 participants per session", comments: false },
              { text: "Create AI-powered presentations", comments: false },
              {
                text: "More question types & question bank for easier creation",
                comments: false,
              },
              {
                text: "Extra features for class presentations",
                comments: false,
              },
              { text: "Access to more ready-made content", comments: false },
              {
                text: "More gamification & game modes to stay motivated",
                comments: false,
              },
              { text: "Other", comments: true },
              {
                text: "AI-powered features to create study sets instantly",
                comments: false,
              },
              {
                text: "Scanning and importing large documents to create study sets with AI",
                comments: false,
              },
            ],
            next: "byOrder",
          },
          {
            uuid: "6f72b635-6e74-4e4b-8b44-1058a78018bc",
            type: "single-close-ended",
            text: "What would motivate you to upgrade to a paid plan?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "More participants per session", comments: false },
              {
                text: "More AI-powered and personalization tools",
                comments: false,
              },
              {
                text: "More self-study features to prepare for exams",
                comments: false,
              },
              {
                text: "More presentation features for class projects",
                comments: false,
              },
              { text: "More collaboration features", comments: false },
              {
                text: "Access to more ready-made study content",
                comments: false,
              },
              { text: "More gamification to stay motivated", comments: false },
              { text: "Other", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "7d53bfea-3c36-4df0-bb76-3251080f12d2",
            type: "single-close-ended",
            text: "How clear is the difference between your current plan and higher plan?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              {
                text: "Very clear — I know what I would get by upgrading",
                comments: false,
              },
              {
                text: "Somewhat clear — but the value isn’t compelling enough",
                comments: false,
              },
              {
                text: "Not very clear — I don’t see the difference",
                comments: false,
              },
              {
                text: "I haven’t looked at other plans / Indifferent",
                comments: false,
              },
            ],
            next: "byOrder",
          },
          {
            uuid: "27bedaaf-f902-460d-9535-94bda23fba2c",
            type: "multiple-close-ended",
            text: "Which of the following features are you aware of or have used?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "AI Experiences", comments: false },
              { text: "Offline mode", comments: false },
              { text: "Test Mode", comments: false },
              { text: "Study buddies", comments: false },
              { text: "I haven't used any of these", comments: false },
              { text: "I wasn't aware of any of these", comments: false },
            ],
            next: "byOrder",
          },
          {
            uuid: "da89de14-43ef-4dd3-befb-2b45facbc6a3",
            type: "single-close-ended",
            text: "What would most improve your experience with Kahoot! now?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              {
                text: "A clearer overview of what each plan offers",
                comments: false,
              },
              { text: "Better guidance when getting started", comments: false },
              { text: "More tips and reminder over time", comments: false },
              {
                text: "Seeing real examples of how others use Kahoot! for studying",
                comments: false,
              },
              {
                text: "Nothing, it already works well for me",
                comments: false,
              },
            ],
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for completing the survey!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "0e922e28-f480-44e8-bc36-09aaad52470b",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1835644,
      created_epoch_time: 1767627358,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "c7a5c24d-1951-453b-a69c-cc97de435f36",
            type: "multiple-close-ended",
            text: "What do you use Kahoot! mostly for? Select top 3.",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself (ie. flashcards)", comments: false },
              { text: "For class presentations/ assignments", comments: false },
              { text: "To study in a group", comments: false },
              { text: "To join student-hosted quizzes", comments: false },
              { text: "To join teacher-hosted class quizzes", comments: false },
              { text: "For study breaks", comments: false },
              { text: "For parties and celebrations", comments: false },
              { text: "To teach students", comments: false },
              { text: "To build new skills", comments: false },
              { text: "Other", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "cc67621a-b117-4c35-81ce-f1f859174c33",
            type: "multiple-close-ended",
            text: "What’s the most valuable part of your current plan?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "Up to 50 participants per session", comments: false },
              {
                text: "AI-powered features to create study sets instantly",
                comments: false,
              },
              {
                text: "More question types & question bank for easier creation",
                comments: false,
              },
              {
                text: "More collaboration features like study groups",
                comments: false,
              },
              { text: "Access to more ready-made content", comments: false },
              { text: "More gamification to stay motivated", comments: false },
              { text: "Other", comments: true },
              {
                text: "Scanning and importing up to 3-page documents to create study sets with AI",
                comments: false,
              },
            ],
            next: "byOrder",
          },
          {
            uuid: "6f72b635-6e74-4e4b-8b44-1058a78018bc",
            type: "single-close-ended",
            text: "What would motivate you to upgrade to a paid plan?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: false,
            answers: [
              { text: "More participants per session", comments: false },
              {
                text: "More AI-powered and personalization tools",
                comments: false,
              },
              {
                text: "More self-study features to prepare for exams",
                comments: false,
              },
              {
                text: "More presentation features for class projects",
                comments: false,
              },
              { text: "More collaboration features", comments: false },
              {
                text: "Access to more ready-made study content",
                comments: false,
              },
              { text: "More gamification to stay motivated", comments: false },
              { text: "Other", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "7d53bfea-3c36-4df0-bb76-3251080f12d2",
            type: "single-close-ended",
            text: "How clear is the difference between your current plan and higher plan?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              {
                text: "Very clear — I know what I would get by upgrading",
                comments: false,
              },
              {
                text: "Somewhat clear — but the value isn’t compelling enough",
                comments: false,
              },
              {
                text: "Not very clear — I don’t see the difference",
                comments: false,
              },
              {
                text: "I haven’t looked at other plans / Indifferent",
                comments: false,
              },
            ],
            next: "byOrder",
          },
          {
            uuid: "27bedaaf-f902-460d-9535-94bda23fba2c",
            type: "multiple-close-ended",
            text: "Which of the following features are you aware of or have used?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "AI Experiences", comments: false },
              { text: "Offline mode", comments: false },
              { text: "Test Mode", comments: false },
              { text: "Study buddies", comments: false },
              { text: "I haven't used any of these", comments: false },
              { text: "I wasn't aware of any of these", comments: false },
            ],
            next: "byOrder",
          },
          {
            uuid: "da89de14-43ef-4dd3-befb-2b45facbc6a3",
            type: "single-close-ended",
            text: "What would most improve your experience with Kahoot! now?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              {
                text: "A clearer overview of what each plan offers",
                comments: false,
              },
              { text: "Better guidance when getting started", comments: false },
              { text: "More tips and reminder over time", comments: false },
              {
                text: "Seeing real examples of how others use Kahoot! for studying",
                comments: false,
              },
              {
                text: "Nothing, it already works well for me",
                comments: false,
              },
            ],
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for completing the survey!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "7cc5ef9d-d530-49e9-9382-2e89f7f36f22",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1826765,
      created_epoch_time: 1763598276,
      skin: "light",
      background: "#202641",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "3ab8d6a8-84ed-4d95-8540-9d76f48ba012",
            type: "reaction",
            text: "How would you rate your experience?",
            required: false,
            nextIfSkipped: "byOrder",
            labels: [{ text: "Not good at all" }, { text: "Very good" }],
            reaction_style: "default",
            next: "byOrder",
          },
          {
            uuid: "95b34ea6-f29f-4292-b02c-65ec0fe0daa8",
            type: "single-open-ended-multiple-line",
            text: "Tell us about your experience...",
            required: false,
            nextIfSkipped: "byOrder",
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for your feedback!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "3c5b039e-8862-4ae2-add2-bb50f3a4ca5e",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#00CE5C",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814239,
      created_epoch_time: 1759789410,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "5cf40d01-ab79-4413-8151-d69f7d716f7a",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/cae811e6729e41c1ae967d781940849a",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814238,
      created_epoch_time: 1759789361,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "cfa683b7-54ee-44e9-90d7-e26b892e962e",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/a30f69b9ca674ead9f3277f1ffe82247",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814237,
      created_epoch_time: 1759789306,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "33db2455-4f16-4dc7-9635-70801e48f836",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/a4e7fc5a7f914aa4b30e093a8217e9e0",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814236,
      created_epoch_time: 1759789261,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "b6125c40-bf69-44c8-9545-0355586103be",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/c7d8a0ee21bb40029d96785a163ce774",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814235,
      created_epoch_time: 1759789235,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "c61fec0b-da5e-4939-9ad9-1602f6d83968",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/fcc6b1d87ae24abca278963595db1e0c",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1814234,
      created_epoch_time: 1759789195,
      skin: "light",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "fedd756d-3ce3-47fd-92c7-75bea13914af",
            type: "multiple-close-ended",
            text: "How can we make the results better?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Answers are incorrect", comments: false },
              { text: "Images are wrong or irrelevant ", comments: false },
              { text: "Too simple / not challenging enough", comments: false },
              { text: "Low variety of question types", comments: false },
              { text: "Not enough results generated", comments: false },
              { text: "Not enough experiences/formats", comments: false },
              {
                text: "Lack of settings (difficulty, tone of voice)",
                comments: false,
              },
              { text: "Hard to use / confusing", comments: false },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "286dc5f5-6391-4f57-9db8-95f5f4a36994",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/e735708284974aa49ea6a90bacdff50e",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1600786,
      created_epoch_time: 1743539717,
      skin: "dark",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "62da7ecb-c23d-40b2-97c0-ed35e8805d47",
            type: "single-close-ended",
            text: "What did you make this Kahoot for?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself", comments: false },
              { text: "To study in a group", comments: false },
              { text: "For a test or quiz", comments: false },
              { text: "For homework or classwork", comments: false },
              { text: "For a class presentation", comments: false },
              { text: "To teach students", comments: false },
              { text: "For a social event", comments: false },
              { text: "Just for fun", comments: false },
              { text: "Something else", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "315b26b7-8676-48fa-b84e-b0323fae8136",
            type: "multiple-close-ended",
            text: "What would you like to improve about the AI question generator?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Optimize for learning new content", comments: false },
              { text: "Better question accuracy", comments: false },
              { text: "Easier to use", comments: false },
              { text: "More source options", comments: true },
              {
                text: "More customization options (e.g., difficulty, topic)",
                comments: false,
              },
              { text: "More slides and explanations", comments: false },
              { text: "More question types", comments: false },
              { text: "More formats or templates", comments: true },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "1d603cc2-622e-441a-9652-c1dd43020bba",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/89bf18be10824dce837ca1713a490400",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1600784,
      created_epoch_time: 1743539521,
      skin: "dark",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "62da7ecb-c23d-40b2-97c0-ed35e8805d47",
            type: "single-close-ended",
            text: "What did you make this Kahoot for?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself", comments: false },
              { text: "To study in a group", comments: false },
              { text: "For a test or quiz", comments: false },
              { text: "For homework or classwork", comments: false },
              { text: "For a class presentation", comments: false },
              { text: "To teach students", comments: false },
              { text: "For a social event", comments: false },
              { text: "Just for fun", comments: false },
              { text: "Something else", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "315b26b7-8676-48fa-b84e-b0323fae8136",
            type: "multiple-close-ended",
            text: "What would you like to improve about the AI question generator?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Optimize for learning new content", comments: false },
              { text: "Better question accuracy", comments: false },
              { text: "Easier to use", comments: false },
              { text: "More source options", comments: true },
              {
                text: "More customization options (e.g., difficulty, topic)",
                comments: false,
              },
              { text: "More slides and explanations", comments: false },
              { text: "More question types", comments: false },
              { text: "More formats or templates", comments: true },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "b64dcfd5-5972-4294-9ce0-87d5a3da42ed",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/c804770eda044ec2b06bc0af1583e37d",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1527987,
      created_epoch_time: 1731285242,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "middle_right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "3246007e-4448-4b7a-98c6-a42285b7dd0c",
            type: "reaction",
            text: "How would you rate your experience?",
            required: true,
            labels: [{ text: "Not good at all" }, { text: "Very good" }],
            reaction_style: "emoji",
            next: "byOrder",
          },
          {
            uuid: "8e7b0282-bede-4ea5-9ab4-ccace5b7d916",
            type: "single-open-ended-multiple-line",
            text: "What would you like us to improve in the AI generator?",
            required: true,
            next: "byOrder",
          },
        ],
        thankyou:
          "Thank you for your feedback! 🙏\n\nIf you're open to sharing more insights, we'd love to invite you to a 15-minute call. You can book a time that works for you here: https://bit.ly/kahoot-ai.",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_production",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_usproduction",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "aef4886a-ed84-4f16-8c97-b7f306127fd4",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "button",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1077168,
      created_epoch_time: 1726582089,
      skin: "dark",
      background: "#320055",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "62da7ecb-c23d-40b2-97c0-ed35e8805d47",
            type: "single-close-ended",
            text: "What did you make this Kahoot for?",
            required: true,
            randomize_answer_order: false,
            pin_last_to_bottom: false,
            answers: [
              { text: "To study by myself", comments: false },
              { text: "To study in a group", comments: false },
              { text: "For a test or quiz", comments: false },
              { text: "For homework or classwork", comments: false },
              { text: "For a class presentation", comments: false },
              { text: "To teach students", comments: false },
              { text: "For a social event", comments: false },
              { text: "Just for fun", comments: false },
              { text: "Something else", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "315b26b7-8676-48fa-b84e-b0323fae8136",
            type: "multiple-close-ended",
            text: "What would you like to improve about the AI question generator?",
            required: true,
            randomize_answer_order: true,
            pin_last_to_bottom: true,
            answers: [
              { text: "Optimize for learning new content", comments: false },
              { text: "Better question accuracy", comments: false },
              { text: "Easier to use", comments: false },
              { text: "More source options", comments: true },
              {
                text: "More customization options (e.g., difficulty, topic)",
                comments: false,
              },
              { text: "More slides and explanations", comments: false },
              { text: "More question types", comments: false },
              { text: "More formats or templates", comments: true },
              { text: "Other (please explain)", comments: true },
            ],
            next: "byOrder",
          },
          {
            uuid: "c56d0722-fa37-4348-ba53-128a332196fc",
            type: "single-open-ended-multiple-line",
            text: "How exactly would you like us to improve the AI kahoot generator?",
            required: false,
            nextIfSkipped: "thankYou",
            next: "thankYou",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "db7bc944-1860-49fe-b5ad-e0f6a1c20a2d",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: "surveys/logo/10167ff5f6e045e4876bf119d32d0119",
      button_color: "#320055",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1105288,
      created_epoch_time: 1724911192,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "middle_right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "56868f4e-b5ec-442c-9785-696dc0b57cb2",
            type: "reaction",
            text: "How would you rate your experience with the AI generator?",
            required: true,
            labels: [{ text: "Hate" }, { text: "Love" }],
            reaction_style: "default",
            next: "byOrder",
          },
          {
            uuid: "94957012-b67b-42a8-add2-2c66a291a1b8",
            type: "single-open-ended-multiple-line",
            text: "Tell us about your experience...",
            required: true,
            next: "byOrder",
          },
        ],
        thankyou:
          "Thank you for your feedback! 🙏\n\nIf you're open to sharing more insights, we'd love to invite you to a 15-minute call. You can book a time that works for you here: https://bit.ly/kahoot-ai.",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_qa",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_stage",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_experimental",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_dev",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_kahoot_results_preview",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "a409dec4-f0d7-4961-a852-bab825580114",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "button",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: false,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1105289,
      created_epoch_time: 1709012315,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "middle_right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "153d6bfb-ab7c-40f6-99db-601d44c3d9e0",
            type: "reaction",
            text: "How would you rate your experience with the AI generator?",
            required: true,
            labels: [{ text: "Hate" }, { text: "Love" }],
            reaction_style: "default",
            next: "byOrder",
          },
          {
            uuid: "479b8aed-f981-49c9-b460-33fd5a40ec9b",
            type: "single-open-ended-multiple-line",
            text: "Tell us about your experience...",
            required: true,
            next: "byOrder",
          },
        ],
        thankyou: "Thank you for sharing your feedback with us!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_questions_results_qa",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_questions_results_experimental",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_questions_results_preview",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_questions_results_dev",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_ai_questions_results_stage",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "6b9acb33-3d69-43b7-8c40-0a10ca892fa0",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "button",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: true,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 901499,
      created_epoch_time: 1683040162,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "368a2a35-e094-4956-8edb-2615f72d05f5",
            type: "single-open-ended-multiple-line",
            text: "How can we improve Kahoot! Kids for your child?",
            required: true,
            next: "byOrder",
          },
        ],
        thankyou: "Thanks for sharing your feedback!",
      },
      connect_visit_data: "never",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "url",
          match_operation: "contains",
          negate: false,
          pattern: "/",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "00960ffb-b6b9-4e67-8bc9-e0b3a00ab982",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "external_link",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: false,
      logo_path: "surveys/logo/f61384f35443423dbeebe667d0466cc9",
      button_color: "#25076b",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 1094797,
      created_epoch_time: 1665756422,
      skin: "light",
      background: "#ffffff",
      effective_show_branding: false,
      position: "middle_right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "e68fbe26-b7a5-4e0c-82e9-39ea132975d2",
            type: "reaction",
            text: "How would you rate your experience?",
            required: true,
            labels: [{ text: "Hate" }, { text: "Love" }],
            reaction_style: "default",
            next: "byOrder",
          },
          {
            uuid: "f0ca2b19-7fb0-450e-aef2-8f8cf965c568",
            type: "single-open-ended-multiple-line",
            text: "Tell us about your experience...",
            required: true,
            next: "byOrder",
          },
          {
            uuid: "9a3ccba6-84d4-429c-a3ce-0680fa5693a0",
            type: "email",
            text: "We may wish to follow up. Enter your email if you're happy for us to contact you.",
            required: false,
            nextIfSkipped: "byOrder",
            next: "byOrder",
          },
        ],
        thankyou: "Thank you for sharing your feedback with us!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "always",
      targeting_percentage: 10,
      targeting: [
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_my-library_paying_business_users",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_creator_paying_business_users",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_user-reports_paying_business_users",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_organization_paying_business_users",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_groups_paying_business_users",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_home_paying_business_users",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "62045326-dd26-4ad9-92d4-0b82f9d6cb30",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "button",
      auto_screenshot: true,
      etr_enabled: false,
      show_legal: true,
      logo_path: null,
      button_color: "#e21b3c",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
    {
      id: 800610,
      created_epoch_time: 1650464371,
      skin: "light",
      background: "#FFFFFF",
      effective_show_branding: false,
      position: "right",
      content: {
        version: 2,
        questions: [
          {
            uuid: "747de536-b21c-42a7-8b16-beaac603540e",
            type: "single-open-ended-multiple-line",
            text: "What do you think about the new thing?",
            required: true,
            next: "byOrder",
          },
        ],
        thankyou:
          "Thank you for answering this survey. Your feedback is highly appreciated!",
      },
      connect_visit_data: "always",
      ask_for_consent: false,
      language: "en",
      display_condition: "immediate",
      display_delay: 0,
      persist_condition: "response",
      targeting_percentage: 100,
      targeting: [
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "phone",
          name: null,
          rule_type: null,
        },
        {
          component: "trigger",
          match_operation: "exact",
          negate: false,
          pattern: "builder_multipleorgs_topbar_poll",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "tablet",
          name: null,
          rule_type: null,
        },
        {
          component: "device",
          match_operation: "exact",
          negate: false,
          pattern: "desktop",
          name: null,
          rule_type: null,
        },
      ],
      uuid: "21ff61da-bf49-4ac1-b749-d4ff95fe030f",
      invite: {
        title: "Your feedback is important to us!",
        description:
          "Tell us what you think about this page by taking our quick Survey.",
        button: "Yes, I will give feedback",
        close: "No thanks",
      },
      invite_enabled: false,
      display_type: "popover",
      auto_screenshot: false,
      etr_enabled: false,
      show_legal: true,
      logo_path: null,
      button_color: "#00C764",
      parent_element_selector: null,
      button_survey_label: null,
      custom_css: null,
      targeting_user_attribute_match_logic: "and",
    },
  ],
  integrations: {
    optimizely: { tag_recordings: false },
    abtasty: { tag_recordings: false },
    kissmetrics: { send_user_id: false },
    mixpanel: { send_events: false },
    unbounce: { tag_recordings: false },
    hubspot: { enabled: false, send_recordings: false, send_surveys: false },
  },
  features: [
    "ask.popover_redesign",
    "client_script.compression.pc",
    "csq_theme",
    "error_reporting",
    "feedback.embeddable_widget",
    "feedback.widgetV2",
    "feedback.widget_telemetry",
    "settings.billing_v2",
    "survey.embeddable_widget",
    "survey.image_question",
    "survey.screenshots",
    "survey.type_button",
    "tcvs_v2",
  ],
  tracking_code_verified: true,
  cs_project_id: null,
  cs_tag_name: null,
  account_id: 324033,
  account_signature:
    "07af0520d1bc6812edf8e416ca1e64b86d6dae43e92728c6e25a6a9f578e4c05",
};

!(function () {
  "use strict";
  function e(t) {
    return (
      (e =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            }),
      e(t)
    );
  }
  function t(e, t) {
    for (var r = 0; r < t.length; r++) {
      var i = t[r];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(e, n(i.key), i);
    }
  }
  function n(t) {
    var n = (function (t, n) {
      if ("object" != e(t) || !t) return t;
      var r = t[Symbol.toPrimitive];
      if (void 0 !== r) {
        var i = r.call(t, "string");
        if ("object" != e(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return String(t);
    })(t);
    return "symbol" == e(n) ? n : String(n);
  }
  var r,
    i = (function () {
      function e(t) {
        var n =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10,
          r =
            arguments.length > 2 && void 0 !== arguments[2]
              ? arguments[2]
              : 1e3;
        !(function (e, t) {
          if (!(e instanceof t))
            throw new TypeError("Cannot call a class as a function");
        })(this, e),
          (this.send = t),
          (this.batchSize = n),
          (this.flushInterval = r),
          (this.buffer = []),
          (this.flushTimer = null);
      }
      var n, r;
      return (
        (n = e),
        (r = [
          {
            key: "getBuffer",
            value: function () {
              return this.buffer;
            },
          },
          {
            key: "add",
            value: function (e) {
              var t = this;
              this.buffer.push(e),
                this.buffer.length >= this.batchSize
                  ? this.flush()
                  : this.flushTimer ||
                    (this.flushTimer = setTimeout(function () {
                      t.flush();
                    }, this.flushInterval));
            },
          },
          {
            key: "flush",
            value: function () {
              this.buffer.length > 0 &&
                (this.send(this.buffer), (this.buffer = [])),
                this.flushTimer &&
                  (clearTimeout(this.flushTimer), (this.flushTimer = null));
            },
          },
        ]) && t(n.prototype, r),
        Object.defineProperty(n, "prototype", { writable: !1 }),
        e
      );
    })();
  function o() {
    return (
      (o = Object.assign
        ? Object.assign.bind()
        : function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }),
      o.apply(this, arguments)
    );
  }
  var a,
    s = function () {
      try {
        return "performance" in window && "now" in window.performance;
      } catch (e) {
        return !1;
      }
    },
    c = {
      version: 6,
      metricsUrl:
        (null === (r = window._hjSettings) || void 0 === r
          ? void 0
          : r.metricsUrl) || "https://metrics.hotjar.io",
      sampling: {
        metrics: 0.1,
        fieldMetrics: 0.01,
        debug: 0.5,
        universalDebug: 0.05 * 0.1,
      },
      browser: { hasPerformance: !1, shouldLogMetrics: !1, inLab: !1 },
      buffer: { bufferSize: 40, flushInterval: 3e3 },
    },
    u = {
      isDebugEnabled: !1,
      isMetricsEnabled: !1,
      isFieldMetricsEnabled: !1,
      loggedMetrics: {},
      genericTags: {},
    },
    l = function (e, t, n) {
      var r;
      u.loggedMetrics[e] = o(
        o({}, u.loggedMetrics[e]),
        {},
        (((r = {})[t] = n || {}), r)
      );
    },
    d = function (e) {
      if (!e) return "value";
      var t = Object.keys(e)[0];
      return (t && e[t]) || "value";
    },
    f = function (e) {
      var t,
        n = null !== (t = e.tag) && void 0 !== t ? t : void 0;
      return u.isDebugEnabled ? o(o(o({}, n), e.extraTags), u.genericTags) : n;
    },
    g = function (e, t) {
      if (!a) return !1;
      var n = u.isMetricsEnabled || u.isDebugEnabled;
      return (
        "lab" === e && (n = c.browser.inLab),
        "field" === e && (n = u.isFieldMetricsEnabled),
        t ? n && t.flush : n
      );
    },
    h = function (e) {
      var t = !1,
        n = "v=".concat(c.version),
        r =
          ""
            .concat(c.metricsUrl, "?")
            .concat(n, "&site_id=")
            .concat(window.hjSiteSettings.site_id) +
          (u.isDebugEnabled ? "&debug=true" : ""),
        i = JSON.stringify(e);
      if ("sendBeacon" in navigator)
        try {
          t = navigator.sendBeacon.bind(navigator)(r, i);
        } catch (e) {}
      if (!1 === t)
        try {
          var o = new XMLHttpRequest();
          o.open("POST", r), (o.timeout = 1e4), o.send(i);
        } catch (e) {}
      c.browser.shouldLogMetrics && console.debug("New Metrics: ", e);
    },
    v = {
      getConfig: function (e) {
        return c[e];
      },
      getState: function (e) {
        return u[e];
      },
      start: function () {
        try {
          c.browser = {
            hasPerformance: s(),
            shouldLogMetrics: /hjMetrics=1/.test(location.search),
            inLab: /hjLab=true/.test(location.search),
          };
          var e = v.time(),
            t = window.hjSiteSettings || {},
            n = t.features,
            r = t.site_id,
            o = new Set(n),
            l = c.sampling;
          return (
            (u.genericTags = { site_id: r }),
            (u.isDebugEnabled =
              Math.random() <= l.universalDebug ||
              (o.has("client_script.metrics.debug") &&
                Math.random() <= l.debug)),
            (u.isMetricsEnabled = Math.random() <= l.metrics),
            (u.isFieldMetricsEnabled =
              u.isMetricsEnabled && Math.random() <= l.fieldMetrics),
            (a = new i(h, c.buffer.bufferSize, c.buffer.flushInterval)),
            e
          );
        } catch (e) {
          console.debug("Error in metrics.start", { error: e });
        }
      },
      reset: function () {
        u.loggedMetrics = {};
      },
      stop: function () {
        (u.isDebugEnabled = !1),
          (u.isMetricsEnabled = !1),
          (u.genericTags = {});
      },
      count: function (e, t) {
        var n = t.incr,
          r = t.tag,
          i = t.extraTags,
          s = t.type;
        try {
          var c,
            l = d(r),
            h = u.loggedMetrics[e],
            v = 0;
          if (
            (n
              ? ((v = ((h && h[l]) || 0) + (n.value || 1)),
                (u.loggedMetrics[e] = o(
                  o({}, h),
                  {},
                  (((c = {})[l] = null != n && n.flush ? 0 : v), c)
                )))
              : (v = 1),
            g(s, n))
          ) {
            var p = {
              name: e,
              type: "count",
              value: v,
              tags: f({ tag: r, extraTags: i }),
            };
            a.add(p);
          }
        } catch (e) {}
      },
      distr: function (e, t) {
        var n = t.task,
          r = t.value,
          i = t.extraTags;
        g() &&
          a.add({
            name: e,
            type: "distribution",
            value: r,
            tags: f({ tag: { task: n }, extraTags: i }),
          });
      },
      time: function () {
        try {
          if (!c.browser.hasPerformance) return;
          return performance.now();
        } catch (e) {}
      },
      timeEnd: function (e, t) {
        var n = t.tag,
          r = t.start,
          i = t.total,
          o = t.extraTags,
          s = t.type;
        try {
          var c = v.time();
          if (!i && !c) return;
          var u = d(n),
            h = i || (r && c ? c - r : void 0);
          if ((l(e, u, {}), h && h > 0 && g(s))) {
            var p = {
              name: e,
              type: "distribution",
              value: Math.round(h),
              tags: f({ tag: n, extraTags: o }),
            };
            a.add(p);
          }
          return c;
        } catch (t) {
          console.debug("Failed to send timer metric: ", {
            name: e,
            tag: n,
            error: t,
          });
        }
      },
      timeIncr: function (e, t) {
        var n,
          r,
          i,
          o,
          a = t.tag,
          s = t.start,
          c = t.flush,
          f = t.extraTags,
          g = t.type,
          h = hj.metrics.time(),
          p = s && h ? h - s : void 0,
          m =
            ((n = e),
            {
              tagName: (r = d(a)),
              start: (o = ((i = u.loggedMetrics[n]) && i[r]) || {}).start,
              total: o.total,
            }),
          w = p ? p + (m.total || 0) : m.total;
        return (
          l(e, m.tagName, { total: w }),
          c && v.timeEnd(e, { tag: a, total: w, extraTags: f, type: g }),
          w
        );
      },
      timeWatcher: function () {
        var e,
          t = 0,
          n = !1,
          r = function () {
            var n,
              r = v.time();
            return (
              (t += null !== (n = e && r && r - e) && void 0 !== n ? n : 0),
              (e = v.time()),
              t
            );
          };
        return {
          start: function () {
            if (!n) return (n = !0), (e = v.time());
          },
          incr: r,
          end: function () {
            var n = r();
            return (t = 0), (e = void 0), n;
          },
        };
      },
      getErrorMessage: function (e) {
        return e instanceof Error ? e.message : "string" == typeof e ? e : "";
      },
    },
    p = function () {
      (window.hj =
        window.hj ||
        function () {
          for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
            t[n] = arguments[n];
          (window.hj.q = window.hj.q || []).push(t);
        }),
        (window.hj.metrics = v);
    },
    m = (function (e) {
      return (
        (e.replayRecordingMaskedUrlRegex = "replayRecordingMaskedUrlRegex"),
        (e.replayRecordingMaskedUrlRegexRules =
          "replayRecordingMaskedUrlRegexRules"),
        e
      );
    })({}),
    w = (function (e) {
      return (
        (e.START = "start"),
        (e.NOT_START = "not-start"),
        (e.END = "end"),
        (e.NOT_END = "not-end"),
        (e.CONTAIN = "contain"),
        (e.NOT_CONTAIN = "not-contain"),
        (e.EXACT = "exact"),
        (e.NOT_EXACT = "not-exact"),
        e
      );
    })({});
  function b() {
    return (
      (b = Object.assign
        ? Object.assign.bind()
        : function (e) {
            for (var t = 1; t < arguments.length; t++) {
              var n = arguments[t];
              for (var r in n)
                Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
            }
            return e;
          }),
      b.apply(this, arguments)
    );
  }
  var y = "https://voc.hotjar.com",
    j = [
      y,
      "https://voc.ew1-integration-1.hotjarians.net",
      "https://hj-engage-unmoderated-review.s3.eu-west-1.amazonaws.com",
    ],
    _ = "hj-uut",
    S = {
      get: function () {
        var e = window.sessionStorage.getItem(_);
        return e ? JSON.parse(e) : null;
      },
      getValue: function (e) {
        var t = S.get();
        return null == t ? void 0 : t[e];
      },
      set: function (e) {
        if (e) {
          var t,
            n = null !== (t = S.get()) && void 0 !== t ? t : {};
          window.sessionStorage.setItem(_, JSON.stringify(b(b({}, n), e)));
        }
      },
      clear: function () {
        window.sessionStorage.removeItem(_);
      },
      validDomains: j,
    },
    T = function (e) {
      var t = new URLSearchParams(e);
      return (
        !!t.has("project_uuid") ||
        ("1" === t.get("is_preview")
          ? t.has("task_uuid")
          : t.has("response_uuid") &&
            t.has("task_uuid") &&
            t.has("participation_uuid"))
      );
    },
    R = function () {
      var e,
        t =
          null !==
            (e = (function () {
              var e = document.referrer;
              if (
                "string" == typeof e &&
                (function (e) {
                  if ("string" != typeof e) return !1;
                  try {
                    var t = new URL(e),
                      n = "1" === t.searchParams.get("is_preview");
                    return (
                      !!j.some(function (t) {
                        return null == e ? void 0 : e.includes(t);
                      }) ||
                      (!!n &&
                        t.hostname.endsWith(".hotjar.com") &&
                        t.pathname.includes("research/projects/tests"))
                    );
                  } catch (e) {
                    return !1;
                  }
                })(e) &&
                T(new URL(e).search)
              )
                return e;
            })()) && void 0 !== e
            ? e
            : (function () {
                var e = new URLSearchParams(window.location.search).get(
                  "hj_uut"
                );
                if (
                  j.some(function (e) {
                    var t;
                    return null === (t = document.referrer) || void 0 === t
                      ? void 0
                      : t.includes(e);
                  }) &&
                  e
                ) {
                  var t = window.atob(e);
                  if (T(t)) {
                    var n = new URL(y);
                    return (n.search = t), n.toString();
                  }
                }
              })(),
        n = void 0 !== t,
        r = null !== S.get();
      return n && S.set({ referrer: t }), r || n;
    };
  function E(e, t, n) {
    if (t && !Array.isArray(t) && "number" == typeof t.length) {
      var r = t.length;
      return x(t, void 0 !== n && n < r ? n : r);
    }
    return e(t, n);
  }
  function O(e) {
    return (
      (function (e) {
        if (Array.isArray(e)) return x(e);
      })(e) ||
      (function (e) {
        if (
          ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
          null != e["@@iterator"]
        )
          return Array.from(e);
      })(e) ||
      (function (e, t) {
        if (e) {
          if ("string" == typeof e) return x(e, t);
          var n = Object.prototype.toString.call(e).slice(8, -1);
          return (
            "Object" === n && e.constructor && (n = e.constructor.name),
            "Map" === n || "Set" === n
              ? Array.from(e)
              : "Arguments" === n ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
              ? x(e, t)
              : void 0
          );
        }
      })(e) ||
      (function () {
        throw new TypeError(
          "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      })()
    );
  }
  function x(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
    return r;
  }
  var M,
    C = "data-hj-csq-tag",
    I = function () {
      var e,
        t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
        n = null === (e = _hjSettings) || void 0 === e ? void 0 : e.environment,
        r = t.isCSQLite ? "t.contentsquare.net" : "static.hotjar.com";
      n &&
        "live" !== n &&
        (r = t.isCSQLite
          ? "t-staging.contentsquare.net"
          : "static-integration.hotjar.com");
      var i = t.isCSQLite ? "smb/tag" : hjSiteSettings.cs_tag_name;
      if (i) {
        var o = document.createElement("script");
        return (
          (o.type = "text/javascript"),
          (o.async = !0),
          (o.src = "//".concat(r, "/uxa/").concat(i, ".js")),
          o.setAttribute(C, ""),
          document.getElementsByTagName("head")[0].appendChild(o),
          (window.hjCSQTagInjected = !0),
          o
        );
      }
    };
  function A() {
    var e, t, n;
    p(), hj.metrics.start();
    var r,
      i,
      o,
      a,
      s,
      c,
      u,
      l,
      d,
      f,
      g,
      h,
      v = !(
        !window.CS_CONF ||
        null === (e = window.CS_CONF.voc) ||
        void 0 === e ||
        !e.enabled
      ),
      b = !(
        window.CS_CONF ||
        null === (t = window.hjSiteSettings) ||
        void 0 === t ||
        null === (n = t.features) ||
        void 0 === n ||
        !n.includes("cs_lite")
      );
    if (v && window._uxa)
      window._uxa.push(["start:hotjar", hjSiteSettings]),
        (window.hj.scriptLoaded = !0);
    else if (b) {
      var y =
          ((c =
            (r = hjSiteSettings).suppress_all ||
            r.suppress_text ||
            (null === (i = r.suppress_all_on_specific_pages) || void 0 === i
              ? void 0
              : i.length)),
          (u = (function (e) {
            var t,
              n,
              r,
              i,
              o,
              a = {
                anonymisationMethod: null,
                replayRecordingMaskedUrlRegex: null,
                replayRecordingMaskedUrlRegexRules: null,
              };
            if (
              ((e.suppress_all || e.suppress_text) &&
                ((a.anonymisationMethod = m.replayRecordingMaskedUrlRegex),
                (a.replayRecordingMaskedUrlRegex = ".*")),
              null !== (t = e.suppress_all_on_specific_pages) &&
                void 0 !== t &&
                t.length)
            ) {
              a.anonymisationMethod = m.replayRecordingMaskedUrlRegexRules;
              var s =
                ((n = e.suppress_all_on_specific_pages),
                (r = {
                  contains: w.CONTAIN,
                  regex: w.CONTAIN,
                  simple: w.CONTAIN,
                  ends_with: w.END,
                  exact: w.EXACT,
                  starts_with: w.START,
                }),
                (i = []),
                (o = Object.keys(r)),
                n.forEach(function (e) {
                  if (e.pattern && o.includes(e.match_operation)) {
                    var t = {
                      operator: r[e.match_operation],
                      value: e.pattern,
                      ignoreQueryParams: "simple" === e.match_operation,
                      ignoreURIFragments: "simple" === e.match_operation,
                      ignoreCaseSensitivity: "simple" === e.match_operation,
                      notOperator: e.negate,
                    };
                    i.push(t);
                  }
                }),
                i.length ? i : void 0);
              a.replayRecordingMaskedUrlRegexRules = s || null;
            }
            return a;
          })(r)),
          (l = u.anonymisationMethod),
          (d = u.replayRecordingMaskedUrlRegex),
          (f = u.replayRecordingMaskedUrlRegexRules),
          (g = !(
            null === (o = _hjSettings) ||
            void 0 === o ||
            !o.environment ||
            "live" === _hjSettings.environment
          )),
          {
            CS_CONF_BASE: {
              projectId: r.cs_project_id,
              smbConfig: {
                siteId: r.site_id,
                record: !!hjSiteSettings.record,
                useCSTC: !0,
                useSentry: !0,
                csLiteDomain: g
                  ? "insights-integration.live.eks.hotjar.com"
                  : "insights.hotjar.com",
              },
              hostnames: [window.location.hostname],
              voc:
                (null !== (a = r.polls) && void 0 !== a && a.length) || R()
                  ? { enabled: 1, siteId: r.site_id }
                  : { enabled: 0 },
              whitelistedAttributes: [],
              anonymizeDigits: !!c || r.anonymize_digits,
              implementations:
                ((s = r),
                E(
                  O,
                  ((h = s.state_change_listen_mode),
                  "manual" === h
                    ? []
                    : [
                        {
                          template: { name: "ArtificialPageview", args: {} },
                          triggers: [
                            {
                              name: "HistoryChange",
                              args: {
                                listeners:
                                  "popstate, pushState, replaceState" +
                                  ("automatic_with_fragments" === h
                                    ? ", hashchange"
                                    : ""),
                                useDebounce: "no",
                                window: 400,
                              },
                            },
                          ],
                        },
                      ])
                )),
              recordTargetingRules: E(O, r.record_targeting_rules),
              anonymisationMethod: l,
              replayRecordingMaskedUrlRegex: d,
              replayRecordingMaskedUrlRegexRules: f,
            },
            PII_SELECTORS: r.suppress_all
              ? ["picture, img, video, audio"]
              : null,
          }),
        j = y.CS_CONF_BASE,
        _ = y.PII_SELECTORS;
      (window.CS_CONF_BASE = j),
        (window._uxa = window._uxa || []),
        _ && window._uxa.push(["setPIISelectors", { PIISelectors: _ }]),
        I({ isCSQLite: b });
    } else
      (window.hjBootstrap =
        window.hjBootstrap ||
        function (e, t, n) {
          var r,
            i,
            o = new RegExp(
              "bot|google|headless|baidu|bing|msn|duckduckbot|teoma|slurp|yandex|phantomjs|pingdom|ahrefsbot|facebook|cispa|bytespider",
              "i"
            ),
            a =
              (null === (r = window.navigator) || void 0 === r
                ? void 0
                : r.userAgent) || "unknown";
          if (o.test(a))
            return (
              hj.metrics.count("session-rejection", { tag: { reason: "bot" } }),
              void console.warn(
                "Hotjar not launching due to suspicious userAgent:",
                a
              )
            );
          var s = "http:" === window.location.protocol,
            c = Boolean(
              null === (i = _hjSettings) || void 0 === i ? void 0 : i.preview
            );
          if (s && !c)
            return (
              hj.metrics.count("session-rejection", {
                tag: { reason: "https" },
              }),
              void console.warn(
                "For security reasons, Hotjar only works over HTTPS. Learn more: https://help.hotjar.com/hc/en-us/articles/115011624047"
              )
            );
          (window.hjBootstrap = function (e, t, n) {
            var r;
            (window.hjBootstrapCalled = (window.hjBootstrapCalled || []).concat(
              n
            )),
              window.hj &&
                window.hj._init &&
                !hj.features.isUchRouted() &&
                (null === (r = hj._init) ||
                  void 0 === r ||
                  r._verifyInstallation());
          }),
            window.hjBootstrap(e, t, n),
            (window.hjBootstrap.revision = "eb56410");
          var u = window.document,
            l = u.head || u.getElementsByTagName("head")[0];
          hj.scriptDomain = e;
          var d = u.createElement("script");
          (d.async = !0),
            (d.src = hj.scriptDomain + t),
            (d.charset = "utf-8"),
            l.appendChild(d);
        }),
        window.hjBootstrap(
          "https://script.hotjar.com/",
          "modules.e85a87e594b0aace33cf.js",
          "554762"
        );
  }
  window.hjLazyModules = window.hjLazyModules || {
    SURVEY_V2: { js: "survey-v2.a510637ec1d6c3b6e36d.js" },
    SURVEY_BOOTSTRAPPER: { js: "survey-bootstrapper.31d6cfe0d16ae931b73c.js" },
    SURVEY_ISOLATED: { js: "survey-isolated.31d6cfe0d16ae931b73c.js" },
    HEATMAP_RETAKER: { js: "heatmap-retaker.3effb74283a86d374eec.js" },
    SURVEY_INVITATION: { js: "survey-invitation.014136c28ea41cdc2e32.js" },
    NOTIFICATION: { js: "notification.ed2bca043f1d9f8c6b56.js" },
    SENTRY: { js: "sentry.58c81e3e25532810f6fd.js" },
    BROWSER_PERF: { js: "browser-perf.8417c6bba72228fa2e29.js" },
    USER_TEST: { js: "user-test.219ed2d53d9cfcf2b3a9.js" },
  };
  var N,
    k,
    U,
    L = null !== (M = hjSiteSettings.features) && void 0 !== M ? M : [];
  function P(e, t) {
    var n;
    (null !== (n = window.hj) && void 0 !== n && n.metrics) ||
      (p(), hj.metrics.start()),
      hj.metrics.count("migration-error", { tag: { error: e }, extraTags: t });
  }
  function D(e) {
    var t =
        arguments.length > 1 && void 0 !== arguments[1]
          ? arguments[1]
          : "csq-tag-already-loaded",
      n = Boolean(window.UXAnalytics) && !e,
      r =
        null !==
        document.querySelector('script[src*="/uxa/"]:not(['.concat(C, "])"));
    (n || r) &&
      P(t, {
        csq_project_ids: (n && window.CSQ_TAGS
          ? window.CSQ_TAGS.join(",")
          : ""
        ).slice(0, 150),
      });
  }
  function B(e) {
    if (e) {
      var t = [
        e.src.split("/uxa/")[0],
        "https://t.contentsquare.net",
        "https://t-staging.contentsquare.net",
      ];
      document.addEventListener("securitypolicyviolation", function e(n) {
        var r,
          i = n.effectiveDirective || n.violatedDirective || "";
        "enforce" !== n.disposition ||
          (0 !== i.indexOf("script-src") && 0 !== i.indexOf("default-src")) ||
          ((r = n.blockedURI),
          !t.some(function (e) {
            if (0 !== r.indexOf(e)) return !1;
            var t = r.slice(e.length);
            return (
              "" === t ||
              "/" === t ||
              0 === t.indexOf("/uxa/") ||
              0 === t.indexOf("/releases/")
            );
          })) ||
          (document.removeEventListener("securitypolicyviolation", e),
          P("csq-tag-blocked-by-csp"));
      }),
        e.addEventListener(
          "error",
          function () {
            return P("csq-tag-load-failed");
          },
          { once: !0 }
        );
    }
  }
  function q() {
    document.addEventListener("securitypolicyviolation", function e(t) {
      var n,
        r,
        i = t.effectiveDirective || t.violatedDirective || "";
      "enforce" === t.disposition &&
        (0 === i.indexOf("connect-src") || 0 === i.indexOf("default-src")) &&
        (r = (n = t.blockedURI.split("/")[2] || "").length - 13) > 0 &&
        n.lastIndexOf(".cs.hotjar.io") === r &&
        (document.removeEventListener("securitypolicyviolation", e),
        P("csq-collect-blocked-by-csp"));
    });
  }
  (U = Boolean(window.hjCSQTagInjected)),
    L.indexOf("one_app_tag") > -1
      ? (D(U), B(I()), q())
      : L.indexOf("one_app_tag_dc") > -1
      ? (A(), D(U), B(I()), q())
      : (A(),
        (null === (N = window.CS_CONF) ||
        void 0 === N ||
        null === (k = N.voc) ||
        void 0 === k
          ? void 0
          : k.enabled) || D(U, "csq-tag-coexisting"));
})();
