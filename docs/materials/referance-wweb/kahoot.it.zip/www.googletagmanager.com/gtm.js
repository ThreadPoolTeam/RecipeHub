// Copyright 2012 Google Inc. All rights reserved.

(function (w, g) {
  w[g] = w[g] || {};
  w[g].e = function (s) {
    return eval(s);
  };
})(window, "google_tag_manager");

(function () {
  var data = {
    resource: {
      version: "51",

      macros: [
        {
          function: "__u",
          vtp_component: "HOST",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__jsm",
          vtp_javascript: [
            "template",
            '(function(){var a=!!localStorage.getItem("isMobileApp");return a})();',
          ],
        },
        {
          function: "__jsm",
          vtp_javascript: [
            "template",
            '(function(){var a=localStorage.getItem("theme")==="mobileApp";return!!a})();',
          ],
        },
        {
          function: "__jsm",
          vtp_javascript: [
            "template",
            '(function(){return sessionStorage.getItem("platform")==="LTI"})();',
          ],
        },
        { function: "__e" },
        {
          function: "__v",
          vtp_dataLayerVersion: 2,
          vtp_setDefaultValue: false,
          vtp_name: "OnetrustActiveGroups",
        },
        { function: "__j", vtp_name: "Optanon" },
        { function: "__k", vtp_decodeCookie: true, vtp_name: "OptanonConsent" },
        {
          function: "__u",
          vtp_component: "URL",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        {
          function: "__u",
          vtp_component: "PATH",
          vtp_enableMultiQueryKeys: false,
          vtp_enableIgnoreEmptyQueryParam: false,
        },
        { function: "__f", vtp_component: "URL" },
        { function: "__e" },
      ],
      tags: [
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\n\u003Cscript src="https://cdn-ukwest.onetrust.com/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8" data-domain-script="a2ce1858-883a-4d3d-829a-79f20d1c5d41"\u003E\u003C/script\u003E\n\u003Cscript type="text/javascript"\u003Efunction OptanonWrapper(){window.dispatchEvent(new Event("oneTrustCategoriesChanged"))};\u003C/script\u003E\n',
          vtp_supportDocumentWrite: true,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          vtp_usePostscribe: true,
          tag_id: 10,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cscript type="text/gtmscript"\u003Efunction removeTargettingCookies(){if(typeof Optanon!=="undefined"){var c=Optanon.GetDomainData().Groups[3];c.Cookies.forEach(function(a){document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+a.Host;document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+a.Host;document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahoot.it";document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahootus.com";\ndocument.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"});c.Hosts.forEach(function(a){a.Cookies.forEach(function(b){document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"})})}}setTimeout(function(){removeTargettingCookies()},2E3);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 17,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cscript type="text/gtmscript"\u003Evar regex=/x{3,}/g;function getCookie(a){if(a.match(regex)){a=a.replace(regex,"");var d=document.cookie.split(a).pop().split("\\x3d")[0];return a+=d}return a}\nfunction removePerformanceCookies(){if(typeof Optanon!=="undefined"){var a=Optanon.GetDomainData().Groups[1];a.Cookies.forEach(function(c){var b=getCookie(c.Name);document.cookie=b+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+c.Host;document.cookie=b+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+c.Host;document.cookie=b+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahoot.it";document.cookie=b+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahootus.com";\ndocument.cookie=b+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"});a.Hosts.forEach(function(c){c.Cookies.forEach(function(b){document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"})});a=getCookie("amplitude_id");var d=getCookie("_gat_UA");document.cookie=\na+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d.kahoot.it";document.cookie=d+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d.kahoot.it";document.cookie=a+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d.kahootus.com";document.cookie=d+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d.kahootus.com"}}setTimeout(function(){removePerformanceCookies()},2E3);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 18,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cscript type="text/gtmscript"\u003Efunction removeFunctionalCookies(){if(typeof Optanon!=="undefined"){var c=Optanon.GetDomainData().Groups[2];c.Cookies.forEach(function(a){document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+a.Host;document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+a.Host;document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahoot.it";document.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;domain\\x3d.kahootus.com";\ndocument.cookie=a.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"});c.Hosts.forEach(function(a){a.Cookies.forEach(function(b){document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d"+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/; domain\\x3d."+b.Host;document.cookie=b.Name+"\\x3d; expires\\x3dThu, 01 Jan 1970 00:00:00 UTC; path\\x3d/;"})})}}setTimeout(function(){removeFunctionalCookies()},2E3);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 19,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\n\u003Cscript src="https://cdn-ukwest.onetrust.com/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8" data-domain-script="a2ce1858-883a-4d3d-829a-79f20d1c5d41-test"\u003E\u003C/script\u003E\n\u003Cscript type="text/javascript"\u003Efunction OptanonWrapper(){window.dispatchEvent(new Event("oneTrustCategoriesChanged"))};\u003C/script\u003E\n',
          vtp_supportDocumentWrite: true,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          vtp_usePostscribe: true,
          tag_id: 28,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cstyle\u003E\n  #onetrust-consent-sdk {\n    position: absolute;\n    z-index: -9999999;\n  }\n\u003C/style\u003E\n\n\u003Cscript type="text/gtmscript"\u003Edocument.cookie.includes("OptanonAlertBoxClosed")||(document.cookie="kahoot_auto_consent\\x3d1;domain\\x3d.kahoot.it;path\\x3d/;max-age\\x3d31536000;SameSite\\x3dLax");function closeOptanonAlert(a){setTimeout(function(){typeof Optanon!=="undefined"?Optanon.hasOwnProperty("Close")\u0026\u0026Optanon.hasOwnProperty("IsAlertBoxClosed")\u0026\u0026(Optanon.IsAlertBoxClosed()||Optanon.Close()):a\u003E0\u0026\u0026closeOptanonAlert(a-1)},2E3)}closeOptanonAlert(5);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 32,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cscript type="text/gtmscript"\u003Ewindow.OptanonActiveGroups=",C0001,C0002,C0003,C0004,";setTimeout(function(){window.dispatchEvent(new Event("oneTrustCategoriesChanged"))},2E3);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 37,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\n\u003Cscript src="https://cdn-ukwest.onetrust.com/scripttemplates/otSDKStub.js" type="text/javascript" charset="UTF-8" data-domain-script="0192f72a-ffec-7a89-a821-45965ce5db4a"\u003E\u003C/script\u003E\n\u003Cscript type="text/javascript"\u003Efunction OptanonWrapper(){window.dispatchEvent(new Event("oneTrustCategoriesChanged"))};\u003C/script\u003E\n',
          vtp_supportDocumentWrite: true,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          vtp_usePostscribe: true,
          tag_id: 48,
        },
        {
          function: "__html",
          metadata: ["map"],
          once_per_event: true,
          vtp_html:
            '\u003Cscript type="text/gtmscript"\u003Efunction resetAutoConsent(a){document.cookie.includes("kahoot_auto_consent\\x3d1")\u0026\u0026setTimeout(function(){typeof Optanon!=="undefined"\u0026\u0026Optanon.LoadBanner?(document.cookie="kahoot_auto_consent\\x3d;domain\\x3d.kahoot.it;path\\x3d/;max-age\\x3d0;SameSite\\x3dLax",document.cookie="OptanonAlertBoxClosed\\x3d;domain\\x3d.kahoot.it;path\\x3d/;max-age\\x3d0;SameSite\\x3dLax",Optanon.LoadBanner()):a\u003E0\u0026\u0026resetAutoConsent(a-1)},1E3)}resetAutoConsent(5);\u003C/script\u003E',
          vtp_supportDocumentWrite: false,
          vtp_enableIframeMode: false,
          vtp_enableEditJsMacroBehavior: false,
          tag_id: 60,
        },
      ],
      predicates: [
        { function: "_re", arg0: ["macro", 0], arg1: "kahoot\\.it" },
        { function: "_cn", arg0: ["macro", 1], arg1: "isMobileApp=true" },
        { function: "_cn", arg0: ["macro", 1], arg1: "theme=mobileApp" },
        { function: "_cn", arg0: ["macro", 1], arg1: "power-point" },
        { function: "_cn", arg0: ["macro", 1], arg1: "lti" },
        { function: "_eq", arg0: ["macro", 2], arg1: "true" },
        { function: "_eq", arg0: ["macro", 3], arg1: "true" },
        { function: "_eq", arg0: ["macro", 4], arg1: "true" },
        { function: "_eq", arg0: ["macro", 5], arg1: "gtm.init_consent" },
        { function: "_re", arg0: ["macro", 6], arg1: ",C0004," },
        { function: "_re", arg0: ["macro", 5], arg1: "OneTrustGroupsUpdated" },
        { function: "_re", arg0: ["macro", 6], arg1: ",C0002," },
        { function: "_re", arg0: ["macro", 6], arg1: ",C0003," },
        { function: "_cn", arg0: ["macro", 0], arg1: "kahoot-71799" },
        { function: "_cn", arg0: ["macro", 0], arg1: "create" },
        { function: "_cn", arg0: ["macro", 0], arg1: "play" },
        { function: "_re", arg0: ["macro", 0], arg1: "kahootus\\.com" },
        {
          function: "_re",
          arg0: ["macro", 0],
          arg1: "^(create|play)\\.kahoot\\.it$",
        },
      ],
      rules: [
        [
          ["if", 0, 8],
          ["unless", 1, 2, 3, 4, 5, 6, 7],
          ["add", 0],
        ],
        [
          ["if", 10],
          ["unless", 1, 2, 3, 4, 5, 6, 9],
          ["add", 1],
        ],
        [
          ["if", 10],
          ["unless", 1, 2, 3, 4, 5, 6, 11],
          ["add", 2],
        ],
        [
          ["if", 10],
          ["unless", 1, 2, 3, 4, 5, 6, 12],
          ["add", 3],
        ],
        [
          ["if", 8, 13],
          ["add", 4],
        ],
        [
          ["if", 8],
          ["unless", 14, 15],
          ["add", 5],
        ],
        [
          ["if", 1, 8],
          ["add", 6],
        ],
        [
          ["if", 2, 8],
          ["add", 6],
        ],
        [
          ["if", 3, 8],
          ["add", 6],
        ],
        [
          ["if", 4, 8],
          ["add", 6],
        ],
        [
          ["if", 5, 8],
          ["add", 6],
        ],
        [
          ["if", 6, 8],
          ["add", 6],
        ],
        [
          ["if", 7, 8],
          ["add", 6],
        ],
        [
          ["if", 8, 16],
          ["unless", 1, 2, 3, 4, 5, 6],
          ["add", 7],
        ],
        [
          ["if", 8, 17],
          ["unless", 1, 2, 3, 4, 5, 6],
          ["add", 8],
        ],
      ],
    },

    runtime: [
      [
        50,
        "__e",
        [46, "a"],
        [
          36,
          [
            13,
            [41, "$0"],
            [3, "$0", ["require", "internal.getEventData"]],
            ["$0", "event"],
          ],
        ],
      ],
      [
        50,
        "__f",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getReferrerUrl"]],
        [52, "d", ["require", "makeString"]],
        [52, "e", ["require", "parseUrl"]],
        [52, "f", [15, "__module_legacyUrls"]],
        [52, "g", [30, ["b", "gtm.referrer", 1], ["c"]]],
        [22, [28, [15, "g"]], [46, [36, ["d", [15, "g"]]]]],
        [
          38,
          [17, [15, "a"], "component"],
          [46, "PROTOCOL", "HOST", "PORT", "PATH", "QUERY", "FRAGMENT", "URL"],
          [
            46,
            [5, [46, [36, [2, [15, "f"], "B", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "C",
                    [7, [15, "g"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "D", [7, [15, "g"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "f"],
                    "E",
                    [7, [15, "g"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [
              5,
              [
                46,
                [
                  22,
                  [17, [15, "a"], "queryKey"],
                  [
                    46,
                    [
                      53,
                      [
                        36,
                        [
                          2,
                          [15, "f"],
                          "H",
                          [7, [15, "g"], [17, [15, "a"], "queryKey"]],
                        ],
                      ],
                    ],
                  ],
                ],
                [52, "h", ["e", [15, "g"]]],
                [36, [2, [17, [15, "h"], "search"], "replace", [7, "?", ""]]],
              ],
            ],
            [5, [46, [36, [2, [15, "f"], "G", [7, [15, "g"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "f"], "A", [7, ["d", [15, "g"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__html",
        [46, "a"],
        [52, "b", ["require", "internal.getEventData"]],
        [52, "c", ["require", "internal.injectHtml"]],
        [52, "d", ["require", "makeString"]],
        [
          68,
          "e",
          [
            53,
            [52, "e", [20, ["d", ["b", "event"]], "gtag.config"]],
            [
              22,
              [15, "e"],
              [46, [53, [2, [15, "a"], "gtmOnFailure", [7]], [36]]],
            ],
          ],
          [46],
        ],
        [
          "c",
          [17, [15, "a"], "html"],
          [17, [15, "a"], "gtmOnSuccess"],
          [17, [15, "a"], "gtmOnFailure"],
          [17, [15, "a"], "useIframe"],
          [17, [15, "a"], "supportDocumentWrite"],
        ],
      ],
      [
        50,
        "__j",
        [46, "a"],
        [52, "b", ["require", "internal.copyKeyFromWindow"]],
        [36, ["b", [17, [15, "a"], "name"]]],
      ],
      [
        50,
        "__jsm",
        [46, "a"],
        [52, "b", ["require", "internal.executeJavascriptString"]],
        [22, [20, [17, [15, "a"], "javascript"], [44]], [46, [36]]],
        [36, ["b", [17, [15, "a"], "javascript"]]],
      ],
      [
        50,
        "__k",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "getCookieValues"]],
        [52, "d", ["require", "internal.parseCookieValuesFromString"]],
        [52, "e", ["b", "gtm.cookie", 1]],
        [
          22,
          [15, "e"],
          [
            46,
            [
              53,
              [
                36,
                [
                  16,
                  [
                    "d",
                    [15, "e"],
                    [17, [15, "a"], "name"],
                    [28, [28, [17, [15, "a"], "decodeCookie"]]],
                  ],
                  0,
                ],
              ],
            ],
          ],
        ],
        [
          36,
          [
            16,
            [
              "c",
              [17, [15, "a"], "name"],
              [28, [28, [17, [15, "a"], "decodeCookie"]]],
            ],
            0,
          ],
        ],
      ],
      [
        50,
        "__u",
        [46, "a"],
        [
          50,
          "k",
          [46, "l", "m"],
          [52, "n", [17, [15, "m"], "multiQueryKeys"]],
          [52, "o", [30, [17, [15, "m"], "queryKey"], ""]],
          [52, "p", [17, [15, "m"], "ignoreEmptyQueryParam"]],
          [
            22,
            [20, [15, "o"], ""],
            [
              46,
              [
                53,
                [
                  52,
                  "r",
                  [
                    2,
                    [17, ["i", [15, "l"]], "search"],
                    "replace",
                    [7, "?", ""],
                  ],
                ],
                [36, [39, [1, [28, [15, "r"]], [15, "p"]], [44], [15, "r"]]],
              ],
            ],
          ],
          [41, "q"],
          [
            22,
            [15, "n"],
            [
              46,
              [
                53,
                [
                  22,
                  [20, ["e", [15, "o"]], "array"],
                  [46, [53, [3, "q", [15, "o"]]]],
                  [
                    46,
                    [
                      53,
                      [52, "r", ["c", "\\s+", "g"]],
                      [
                        3,
                        "q",
                        [
                          2,
                          [2, ["f", [15, "o"]], "replace", [7, [15, "r"], ""]],
                          "split",
                          [7, ","],
                        ],
                      ],
                    ],
                  ],
                ],
              ],
            ],
            [46, [53, [3, "q", [7, ["f", [15, "o"]]]]]],
          ],
          [
            65,
            "r",
            [15, "q"],
            [
              46,
              [
                53,
                [52, "s", [2, [15, "h"], "H", [7, [15, "l"], [15, "r"]]]],
                [
                  22,
                  [29, [15, "s"], [44]],
                  [
                    46,
                    [
                      53,
                      [
                        22,
                        [1, [15, "p"], [20, [15, "s"], ""]],
                        [46, [53, [6]]],
                      ],
                      [36, [15, "s"]],
                    ],
                  ],
                ],
              ],
            ],
          ],
          [36, [44]],
        ],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getUrl"]],
        [52, "e", ["require", "getType"]],
        [52, "f", ["require", "makeString"]],
        [52, "g", ["require", "parseUrl"]],
        [52, "h", [15, "__module_legacyUrls"]],
        [52, "i", ["require", "internal.legacyParseUrl"]],
        [41, "j"],
        [
          22,
          [17, [15, "a"], "customUrlSource"],
          [46, [53, [3, "j", [17, [15, "a"], "customUrlSource"]]]],
          [46, [53, [3, "j", ["b", "gtm.url", 1]]]],
        ],
        [3, "j", [30, [15, "j"], ["d"]]],
        [
          38,
          [17, [15, "a"], "component"],
          [
            46,
            "PROTOCOL",
            "HOST",
            "PORT",
            "PATH",
            "EXTENSION",
            "QUERY",
            "FRAGMENT",
            "URL",
          ],
          [
            46,
            [5, [46, [36, [2, [15, "h"], "B", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "C",
                    [7, [15, "j"], [17, [15, "a"], "stripWww"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "D", [7, [15, "j"]]]]]],
            [
              5,
              [
                46,
                [
                  36,
                  [
                    2,
                    [15, "h"],
                    "E",
                    [7, [15, "j"], [17, [15, "a"], "defaultPages"]],
                  ],
                ],
              ],
            ],
            [5, [46, [36, [2, [15, "h"], "F", [7, [15, "j"]]]]]],
            [5, [46, [36, ["k", [15, "j"], [15, "a"]]]]],
            [5, [46, [36, [2, [15, "h"], "G", [7, [15, "j"]]]]]],
            [5, [46]],
            [9, [46, [36, [2, [15, "h"], "A", [7, ["f", [15, "j"]]]]]]],
          ],
        ],
      ],
      [
        50,
        "__v",
        [46, "a"],
        [52, "b", ["require", "copyFromDataLayer"]],
        [52, "c", ["require", "internal.createRegex"]],
        [52, "d", ["require", "getType"]],
        [52, "e", [17, [15, "a"], "name"]],
        [
          22,
          [30, [28, [15, "e"]], [21, ["d", [15, "e"]], "string"]],
          [46, [36, false]],
        ],
        [52, "f", [2, [15, "e"], "replace", [7, ["c", "\\\\.", "g"], "."]]],
        [
          52,
          "g",
          ["b", [15, "f"], [30, [17, [15, "a"], "dataLayerVersion"], 1]],
        ],
        [
          36,
          [
            39,
            [21, [15, "g"], [44]],
            [15, "g"],
            [17, [15, "a"], "defaultValue"],
          ],
        ],
      ],
      [
        52,
        "__module_legacyUrls",
        [
          13,
          [41, "$0"],
          [
            3,
            "$0",
            [
              51,
              "",
              [7],
              [
                50,
                "a",
                [46],
                [
                  50,
                  "h",
                  [46, "p"],
                  [52, "q", [2, [15, "p"], "indexOf", [7, "#"]]],
                  [
                    36,
                    [
                      39,
                      [23, [15, "q"], 0],
                      [15, "p"],
                      [2, [15, "p"], "substring", [7, 0, [15, "q"]]],
                    ],
                  ],
                ],
                [
                  50,
                  "i",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "protocol"]],
                  [
                    36,
                    [
                      39,
                      [15, "q"],
                      [2, [15, "q"], "replace", [7, ":", ""]],
                      "",
                    ],
                  ],
                ],
                [
                  50,
                  "j",
                  [46, "p", "q"],
                  [41, "r"],
                  [3, "r", [17, ["e", [15, "p"]], "hostname"]],
                  [22, [28, [15, "r"]], [46, [36, ""]]],
                  [52, "s", ["b", ":[0-9]+"]],
                  [3, "r", [2, [15, "r"], "replace", [7, [15, "s"], ""]]],
                  [
                    22,
                    [15, "q"],
                    [
                      46,
                      [
                        53,
                        [52, "t", ["b", "^www\\d*\\."]],
                        [52, "u", [2, [15, "r"], "match", [7, [15, "t"]]]],
                        [
                          22,
                          [1, [15, "u"], [16, [15, "u"], 0]],
                          [
                            46,
                            [
                              3,
                              "r",
                              [
                                2,
                                [15, "r"],
                                "substring",
                                [7, [17, [16, [15, "u"], 0], "length"]],
                              ],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "r"]],
                ],
                [
                  50,
                  "k",
                  [46, "p"],
                  [52, "q", ["e", [15, "p"]]],
                  [41, "r"],
                  [3, "r", ["f", [17, [15, "q"], "port"]]],
                  [
                    22,
                    [28, [15, "r"]],
                    [
                      46,
                      [
                        53,
                        [
                          22,
                          [20, [17, [15, "q"], "protocol"], "http:"],
                          [46, [53, [3, "r", 80]]],
                          [
                            46,
                            [
                              22,
                              [20, [17, [15, "q"], "protocol"], "https:"],
                              [46, [53, [3, "r", 443]]],
                              [46, [53, [3, "r", ""]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, ["g", [15, "r"]]],
                ],
                [
                  50,
                  "l",
                  [46, "p", "q"],
                  [52, "r", ["e", [15, "p"]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [
                        20,
                        [2, [17, [15, "r"], "pathname"], "indexOf", [7, "/"]],
                        0,
                      ],
                      [17, [15, "r"], "pathname"],
                      [0, "/", [17, [15, "r"], "pathName"]],
                    ],
                  ],
                  [
                    22,
                    [20, ["d", [15, "q"]], "array"],
                    [
                      46,
                      [
                        53,
                        [52, "t", [2, [15, "s"], "split", [7, "/"]]],
                        [
                          22,
                          [
                            19,
                            [
                              2,
                              [15, "q"],
                              "indexOf",
                              [
                                7,
                                [
                                  16,
                                  [15, "t"],
                                  [37, [17, [15, "t"], "length"], 1],
                                ],
                              ],
                            ],
                            0,
                          ],
                          [
                            46,
                            [
                              53,
                              [
                                43,
                                [15, "t"],
                                [37, [17, [15, "t"], "length"], 1],
                                "",
                              ],
                              [3, "s", [2, [15, "t"], "join", [7, "/"]]],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36, [15, "s"]],
                ],
                [
                  50,
                  "m",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "pathname"]],
                  [52, "r", [2, [15, "q"], "split", [7, "."]]],
                  [41, "s"],
                  [
                    3,
                    "s",
                    [
                      39,
                      [18, [17, [15, "r"], "length"], 1],
                      [16, [15, "r"], [37, [17, [15, "r"], "length"], 1]],
                      "",
                    ],
                  ],
                  [36, [16, [2, [15, "s"], "split", [7, "/"]], 0]],
                ],
                [
                  50,
                  "n",
                  [46, "p"],
                  [52, "q", [17, ["e", [15, "p"]], "hash"]],
                  [36, [2, [15, "q"], "replace", [7, "#", ""]]],
                ],
                [
                  50,
                  "o",
                  [46, "p", "q"],
                  [
                    50,
                    "s",
                    [46, "t"],
                    [
                      36,
                      [
                        "c",
                        [2, [15, "t"], "replace", [7, ["b", "\\+", "g"], " "]],
                      ],
                    ],
                  ],
                  [
                    52,
                    "r",
                    [
                      2,
                      [17, ["e", [15, "p"]], "search"],
                      "replace",
                      [7, "?", ""],
                    ],
                  ],
                  [
                    65,
                    "t",
                    [2, [15, "r"], "split", [7, "&"]],
                    [
                      46,
                      [
                        53,
                        [52, "u", [2, [15, "t"], "split", [7, "="]]],
                        [
                          22,
                          [21, ["s", [16, [15, "u"], 0]], [15, "q"]],
                          [46, [6]],
                        ],
                        [
                          36,
                          [
                            "s",
                            [
                              2,
                              [2, [15, "u"], "slice", [7, 1]],
                              "join",
                              [7, "="],
                            ],
                          ],
                        ],
                      ],
                    ],
                  ],
                  [36],
                ],
                [52, "b", ["require", "internal.createRegex"]],
                [52, "c", ["require", "decodeUriComponent"]],
                [52, "d", ["require", "getType"]],
                [52, "e", ["require", "internal.legacyParseUrl"]],
                [52, "f", ["require", "makeNumber"]],
                [52, "g", ["require", "makeString"]],
                [
                  36,
                  [
                    8,
                    "F",
                    [15, "m"],
                    "H",
                    [15, "o"],
                    "G",
                    [15, "n"],
                    "C",
                    [15, "j"],
                    "E",
                    [15, "l"],
                    "D",
                    [15, "k"],
                    "B",
                    [15, "i"],
                    "A",
                    [15, "h"],
                  ],
                ],
              ],
              [36, ["a"]],
            ],
          ],
          ["$0"],
        ],
      ],
    ],

    entities: {
      __e: { 2: true, 6: true },
      __f: { 2: true, 6: true },
      __j: { 2: true },
      __k: { 2: true },
      __u: { 2: true, 6: true },
      __v: { 2: true, 6: true },
    },

    blob: {
      1: "51",
      10: "GTM-5HCKFC",
      12: "",
      14: "6as1",
      15: "0",
      16: "ChAI8ICR1wYQvMyPuvnas+ojEhsAj2fsiYLmp0g4duS5nXIyAwTI4qT2DBGDuLwaAotN",
      19: "dataLayer",
      20: "",
      21: "www.googletagmanager.com",
      22: "eyIwIjoiVk4iLCIxIjoiVk4tU0ciLCIyIjpmYWxzZSwiMyI6Imdvb2dsZS5jb20udm4iLCI0IjoiIiwiNSI6dHJ1ZSwiNiI6ZmFsc2UsIjkiOmZhbHNlfQ",
      23: "google.tagmanager.debugui2.queue",
      24: "tagassistant.google.com",
      27: 0.005,
      3: "www.googletagmanager.com",
      30: "VN",
      31: "VN-SG",
      32: true,
      36: "https://adservice.google.com/pagead/regclk",
      37: "__TAGGY_INSTALLED",
      38: "cct.google",
      39: "googTaggyReferrer",
      40: "https://cct.google/taggy/agent.js",
      41: "google.tagmanager.ta.prodqueue",
      42: 0.01,
      43: '{"keys":[{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BKxVjAbYnMuI4vqs+oSnX2AXRTe+CVX07CkcgE2gSVQ9NXLV22CKT0nOoag+X8mbBWyzhi10QeqkPw0E8JjCtqs=","version":0},"id":"f0183cc0-abab-42fd-86fb-add33d34e4c9"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BIdvghVsYpB4B1WPbHz56v8cJ6HZr8x9VvZ/0vKO+w+D5Qrk1zlBxcu8ushvgOc/pryKCCMuNLCIpFLQjEexZpk=","version":0},"id":"990c70d7-ee15-4b11-88fa-0e98545a2246"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BIEjIH31PxAGOzgQCzWr8KMuD0Jv0/cqMOPuYblHddtP0Lt0MTphpoH4iNyNbCS+YgXskWiM8wmzn5IVT3WHN74=","version":0},"id":"8444cea3-8f0d-4f7b-8db6-d3643bd5bc4b"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BFVJtbnZpZUV/kg+ad/kLcC5lKb+fqwzFe/tOr2TxZ0oQ/eL1cpPhemqr9bJfZG7kGa/yCxvSmAbmH6CyJEww3g=","version":0},"id":"663423d8-4eb6-4f47-9d7b-6a77aef01e80"},{"hpkePublicKey":{"params":{"aead":"AES_128_GCM","kdf":"HKDF_SHA256","kem":"DHKEM_P256_HKDF_SHA256"},"publicKey":"BNO3w5Ehq+NMvoax0o1RetPGCb3dVLZX8Rej9ViM9WmmZns2KhzmWYeyky6rKOVhkS2nPmBShL3/tFSQDBMZhII=","version":0},"id":"397736a3-8c82-4fd5-8285-f1a0a5cd1e97"}]}',
      44: "118897920~118897930~120469145~120469153~121246026~121246034",
      46: {
        1: "1000",
        10: "6al0",
        11: "6a60",
        14: "1000",
        16: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        17: "US-CO~US-CT~US-MT~US-NE~US-NH~US-TX~US-MN~US-NJ~US-MD~US-OR~US-DE",
        2: "9",
        20: "5000",
        21: "5000",
        22: "4.6.0",
        23: "0.0.0",
        25: "1",
        26: "4000",
        27: "100",
        3: "5",
        4: "ad_storage|analytics_storage|ad_user_data|ad_personalization",
        44: "15000",
        48: "30000",
        5: "ad_storage|analytics_storage|ad_user_data",
        6: "1",
        61: "1000",
        62: "A6ONHRY7/bvBro+IMZd/a6LNjn7SSv999SkN/hFAE9L6vMr34dNgfdSVdYmv4U+NHZg1sxd38RtciRpRUtIRPgQAAACCeyJvcmlnaW4iOiJodHRwczovL3d3dy5nb29nbGV0YWdtYW5hZ2VyLmNvbTo0NDMiLCJmZWF0dXJlIjoiU2hhcmVkV29ya2VyRXh0ZW5kZWRMaWZldGltZSIsImV4cGlyeSI6MTc3NjcyOTYwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==",
        63: "1000",
        66: "100",
        7: "10",
        72: "50",
      },
      48: true,
      5: "GTM-5HCKFC",
      55: [],
      56: [
        { 1: 403, 3: 0.5, 4: 115938465, 5: 115938466, 6: 0, 7: 2 },
        { 1: 404, 3: 0.5, 4: 115938468, 5: 115938469, 6: 0, 7: 1 },
        { 1: 674, 3: 0.01, 4: 123692836, 5: 123692834, 6: 123692835, 7: 1 },
        { 1: 671, 3: 0.01, 4: 123691408, 5: 123691407, 6: 0, 7: 3 },
        { 1: 585, 2: true },
        { 1: 602, 2: true },
        { 1: 474, 3: 0.1, 4: 117776795, 5: 117776796, 6: 0, 7: 3 },
        { 1: 609, 3: 0.1, 4: 120420416, 5: 120420414, 6: 120420415, 7: 1 },
        { 1: 607, 3: 0.1, 4: 121191155, 5: 121191153, 6: 121191154, 7: 3 },
        { 1: 568, 3: 0.01, 4: 121399758, 5: 121399757, 6: 0, 7: 3 },
        { 1: 490, 2: true },
        { 1: 491, 3: 0.01, 4: 118012007, 5: 118012008, 6: 118012009, 7: 1 },
        { 1: 480, 2: true },
        { 1: 594, 3: 0.01, 4: 119793974, 5: 119793972, 6: 119793973, 7: 1 },
        { 1: 550, 2: true },
        { 1: 613, 2: true },
        { 1: 592, 3: 0.01, 4: 123322203, 5: 123322201, 6: 123322202, 7: 3 },
        { 1: 669, 3: 1, 4: 123691370, 5: 123691369, 6: 0, 7: 1 },
        { 1: 663, 2: true },
        { 1: 567, 3: 0.1, 4: 120895657, 5: 120895655, 6: 120895656, 7: 3 },
        { 1: 620, 2: true },
        { 1: 642, 3: 0.1, 4: 123814185, 5: 123814183, 6: 123814184, 7: 1 },
        { 1: 617, 3: 0.1, 4: 123814946, 5: 123814944, 6: 123814945, 7: 1 },
        { 1: 626, 2: true },
        { 1: 627, 2: true },
        { 1: 666, 3: 0.1, 4: 123620777, 5: 123620775, 6: 123620776, 7: 1 },
        { 1: 616, 3: 0.01, 4: 123785234, 5: 123785232, 6: 123785233, 7: 1 },
        { 1: 553, 2: true },
        { 1: 608, 3: 0.1, 4: 120412528, 5: 120412526, 6: 120412527, 7: 1 },
        { 1: 506, 2: true },
        { 1: 561, 2: true },
        { 1: 481, 2: true },
        { 1: 562, 3: 0.01, 4: 119404697, 5: 119404696, 6: 0, 7: 1 },
        { 1: 482, 2: true },
        { 1: 612, 3: 0.05, 4: 120912673, 5: 120912672, 6: 121375529, 7: 1 },
        { 1: 547, 3: 0.01, 4: 119860443, 5: 119860442, 6: 119863601, 7: 2 },
        { 1: 679, 2: true },
        { 1: 450, 3: 0.01, 4: 117227714, 5: 117227715, 6: 117227716, 7: 3 },
        { 1: 582, 3: 0.01, 4: 119381664, 5: 119381662, 6: 119381663, 7: 3 },
        { 1: 443, 3: 0.01, 4: 117628654, 5: 117628655, 6: 117628656, 7: 3 },
        { 1: 570, 2: true },
        { 1: 662, 2: true },
        { 1: 498, 3: 0.2, 4: 115616985, 5: 115616986, 6: 0, 7: 1 },
        { 1: 637, 2: true },
        { 1: 495, 3: 0.05, 4: 118131810, 5: 118131808, 6: 118131809, 7: 3 },
        { 1: 564, 3: 0.0001, 4: 119205317, 5: 119205315, 6: 119205316, 7: 1 },
        { 1: 658, 3: 0.001, 4: 123820802, 5: 123820800, 6: 123820801, 7: 1 },
        { 1: 610, 3: 0.5, 4: 120385423, 5: 120385422, 6: 0, 7: 1 },
        { 1: 576, 3: 0.01, 4: 119317810, 5: 119317811, 6: 119318177, 7: 3 },
        { 1: 677, 3: 0.1, 4: 123636747, 5: 123636746, 6: 0, 7: 1 },
        { 1: 605, 3: 0.001, 4: 120032690, 5: 120032689, 6: 120032691, 7: 1 },
        { 1: 664, 2: true },
        { 1: 524, 2: true },
      ],
      59: ["GTM-5HCKFC"],
      6: "1402767",
      62: false,
      63: 0.005,
    },
    permissions: {
      __e: {
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __f: {
        read_data_layer: { keyPatterns: ["gtm.referrer"] },
        get_referrer: { urlParts: "any" },
      },
      __html: {
        unsafe_inject_arbitrary_html: {},
        read_event_data: {
          eventDataAccess: "specific",
          keyPatterns: ["event"],
        },
      },
      __j: { unsafe_access_globals: {}, access_globals: {} },
      __jsm: { unsafe_run_arbitrary_javascript: {} },
      __k: {
        get_cookies: { cookieAccess: "any" },
        read_data_layer: { keyPatterns: ["gtm.cookie"] },
      },
      __u: {
        read_data_layer: { keyPatterns: ["gtm.url"] },
        get_url: { urlParts: "any" },
      },
      __v: { read_data_layer: { allowedKeys: "any" } },
    },

    security_groups: {
      customScripts: ["__html", "__jsm"],
      google: ["__e", "__f", "__j", "__k", "__u", "__v"],
    },
  };

  try {
    (function () {
      /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
      var C = this || self,
        D = function (n, u) {
          for (var x = n.split("."), t = C, q; x.length && (q = x.shift()); )
            x.length || u === void 0
              ? (t = t[q] && t[q] !== Object.prototype[q] ? t[q] : (t[q] = {}))
              : (t[q] = u);
        }; /*
 Copyright (c) 2014 Derek Brans, MIT license https://github.com/krux/postscribe/blob/master/LICENSE. Portions derived from simplehtmlparser, which is licensed under the Apache License, Version 2.0 */
      var E,
        F = function () {};
      (function () {
        function n(h, l) {
          h = h || "";
          l = l || {};
          for (var y in u)
            u.hasOwnProperty(y) &&
              (l.P && (l["fix_" + y] = !0), (l.I = l.I || l["fix_" + y]));
          var z = {
              comment: /^\x3c!--/,
              endTag: /^<\//,
              atomicTag: /^<\s*(script|style|noscript|iframe|textarea)[\s\/>]/i,
              startTag: /^</,
              chars: /^[^<]/,
            },
            e = {
              comment: function () {
                var a = h.indexOf("--\x3e");
                if (a >= 0) return { content: h.substr(4, a), length: a + 3 };
              },
              endTag: function () {
                var a = h.match(t);
                if (a) return { tagName: a[1], length: a[0].length };
              },
              atomicTag: function () {
                var a = e.startTag();
                if (a) {
                  var b = h.slice(a.length);
                  if (
                    b.match(new RegExp("</\\s*" + a.tagName + "\\s*>", "i"))
                  ) {
                    var c = b.match(
                      new RegExp(
                        "([\\s\\S]*?)</\\s*" + a.tagName + "\\s*>",
                        "i"
                      )
                    );
                    if (c)
                      return {
                        tagName: a.tagName,
                        h: a.h,
                        content: c[1],
                        length: c[0].length + a.length,
                      };
                  }
                }
              },
              startTag: function () {
                var a = h.match(x);
                if (a) {
                  var b = {};
                  a[2].replace(q, function (c, d) {
                    var k =
                        arguments[2] ||
                        arguments[3] ||
                        arguments[4] ||
                        (B.test(d) && d) ||
                        null,
                      g = document.createElement("div");
                    g.innerHTML = k;
                    b[d] = g.textContent || g.innerText || k;
                  });
                  return {
                    tagName: a[1],
                    h: b,
                    v: !!a[3],
                    length: a[0].length,
                  };
                }
              },
              chars: function () {
                var a = h.indexOf("<");
                return { length: a >= 0 ? a : h.length };
              },
            },
            f = function () {
              for (var a in z)
                if (z[a].test(h)) {
                  var b = e[a]();
                  return b
                    ? ((b.type = b.type || a),
                      (b.text = h.substr(0, b.length)),
                      (h = h.slice(b.length)),
                      b)
                    : null;
                }
            };
          l.I &&
            (function () {
              var a =
                  /^(AREA|BASE|BASEFONT|BR|COL|FRAME|HR|IMG|INPUT|ISINDEX|LINK|META|PARAM|EMBED)$/i,
                b = /^(COLGROUP|DD|DT|LI|OPTIONS|P|TD|TFOOT|TH|THEAD|TR)$/i,
                c = [];
              c.J = function () {
                return this[this.length - 1];
              };
              c.B = function (m) {
                var p = this.J();
                return (
                  p && p.tagName && p.tagName.toUpperCase() === m.toUpperCase()
                );
              };
              c.X = function (m) {
                for (var p = 0, w; (w = this[p]); p++)
                  if (w.tagName === m) return !0;
                return !1;
              };
              var d = function (m) {
                  m &&
                    m.type === "startTag" &&
                    (m.v = a.test(m.tagName) || m.v);
                  return m;
                },
                k = f,
                g = function () {
                  h = "</" + c.pop().tagName + ">" + h;
                },
                r = {
                  startTag: function (m) {
                    var p = m.tagName;
                    p.toUpperCase() === "TR" && c.B("TABLE")
                      ? ((h = "<TBODY>" + h), v())
                      : l.qa && b.test(p) && c.X(p)
                      ? c.B(p)
                        ? g()
                        : ((h = "</" + m.tagName + ">" + h), v())
                      : m.v || c.push(m);
                  },
                  endTag: function (m) {
                    c.J()
                      ? l.Y && !c.B(m.tagName)
                        ? g()
                        : c.pop()
                      : l.Y && (k(), v());
                  },
                },
                v = function () {
                  var m = h,
                    p = d(k());
                  h = m;
                  if (p && r[p.type]) r[p.type](p);
                };
              f = function () {
                v();
                return d(k());
              };
            })();
          return {
            append: function (a) {
              h += a;
            },
            ga: f,
            ta: function (a) {
              for (var b; (b = f()) && (!a[b.type] || a[b.type](b) !== !1); );
            },
            clear: function () {
              var a = h;
              h = "";
              return a;
            },
            ua: function () {
              return h;
            },
            stack: [],
          };
        }
        var u = (function () {
            var h = {},
              l = this.document.createElement("div");
            l.innerHTML = "<P><I></P></I>";
            h.wa = l.innerHTML !== "<P><I></P></I>";
            l.innerHTML = "<P><i><P></P></i></P>";
            h.va = l.childNodes.length === 2;
            return h;
          })(),
          x =
            /^<([\-A-Za-z0-9_]+)((?:\s+[\w\-]+(?:\s*=?\s*(?:(?:"[^"]*")|(?:'[^']*')|[^>\s]+))?)*)\s*(\/?)>/,
          t = /^<\/([\-A-Za-z0-9_]+)[^>]*>/,
          q =
            /([\-A-Za-z0-9_]+)(?:\s*=\s*(?:(?:"((?:\\.|[^"])*)")|(?:'((?:\\.|[^'])*)')|([^>\s]+)))?/g,
          B =
            /^(checked|compact|declare|defer|disabled|ismap|multiple|nohref|noresize|noshade|nowrap|readonly|selected)$/i;
        n.supports = u;
        for (var A in u);
        E = n;
      })();
      (function () {
        function n() {}
        function u(e) {
          return e !== void 0 && e !== null;
        }
        function x(e, f, a) {
          var b,
            c = (e && e.length) || 0;
          for (b = 0; b < c; b++) f.call(a, e[b], b);
        }
        function t(e, f, a) {
          for (var b in e) e.hasOwnProperty(b) && f.call(a, b, e[b]);
        }
        function q(e, f) {
          t(f, function (a, b) {
            e[a] = b;
          });
          return e;
        }
        function B(e, f) {
          e = e || {};
          t(f, function (a, b) {
            u(e[a]) || (e[a] = b);
          });
          return e;
        }
        function A(e) {
          try {
            return y.call(e);
          } catch (a) {
            var f = [];
            x(e, function (b) {
              f.push(b);
            });
            return f;
          }
        }
        var h = {
            L: n,
            M: n,
            N: n,
            O: n,
            R: n,
            S: function (e) {
              return e;
            },
            done: n,
            error: function (e) {
              throw e;
            },
            ha: !1,
          },
          l = this;
        if (!l.postscribe) {
          var y = Array.prototype.slice,
            z = (function () {
              function e(a, b, c) {
                var d = "data-ps-" + b;
                if (arguments.length === 2) {
                  var k = a.getAttribute(d);
                  return u(k) ? String(k) : k;
                }
                u(c) && c !== "" ? a.setAttribute(d, c) : a.removeAttribute(d);
              }
              function f(a, b) {
                var c = a.ownerDocument;
                q(this, {
                  root: a,
                  options: b,
                  m: c.defaultView || c.parentWindow,
                  j: c,
                  u: E("", { P: !0 }),
                  A: [a],
                  D: "",
                  F: c.createElement(a.nodeName),
                  l: [],
                  i: [],
                });
                e(this.F, "proxyof", 0);
              }
              f.prototype.write = function () {
                [].push.apply(this.i, arguments);
                for (var a; !this.o && this.i.length; )
                  (a = this.i.shift()),
                    "function" === typeof a ? this.W(a) : this.G(a);
              };
              f.prototype.W = function (a) {
                var b = { type: "function", value: a.name || a.toString() };
                this.C(b);
                a.call(this.m, this.j);
                this.K(b);
              };
              f.prototype.G = function (a) {
                this.u.append(a);
                for (
                  var b, c = [], d, k;
                  (b = this.u.ga()) &&
                  !(d =
                    b && "tagName" in b
                      ? !!~b.tagName.toLowerCase().indexOf("script")
                      : !1) &&
                  !(k =
                    b && "tagName" in b
                      ? !!~b.tagName.toLowerCase().indexOf("style")
                      : !1);

                )
                  c.push(b);
                this.ma(c);
                d && this.Z(b);
                k && this.aa(b);
              };
              f.prototype.ma = function (a) {
                var b = this.T(a);
                b.H &&
                  ((b.ba = this.D + b.H),
                  (this.D += b.proxy),
                  (this.F.innerHTML = b.ba),
                  this.ka());
              };
              f.prototype.T = function (a) {
                var b = this.A.length,
                  c = [],
                  d = [],
                  k = [];
                x(a, function (g) {
                  c.push(g.text);
                  if (g.h) {
                    if (!/^noscript$/i.test(g.tagName)) {
                      var r = b++;
                      d.push(
                        g.text.replace(/(\/?>)/, " data-ps-id=" + r + " $1")
                      );
                      g.h.id !== "ps-script" &&
                        g.h.id !== "ps-style" &&
                        k.push(
                          g.type === "atomicTag"
                            ? ""
                            : "<" +
                                g.tagName +
                                " data-ps-proxyof=" +
                                r +
                                (g.v ? " />" : ">")
                        );
                    }
                  } else d.push(g.text), k.push(g.type === "endTag" ? g.text : "");
                });
                return {
                  xa: a,
                  raw: c.join(""),
                  H: d.join(""),
                  proxy: k.join(""),
                };
              };
              f.prototype.ka = function () {
                for (var a, b = [this.F]; u((a = b.shift())); ) {
                  var c = a.nodeType === 1;
                  if (!c || !e(a, "proxyof")) {
                    c && ((this.A[e(a, "id")] = a), e(a, "id", null));
                    var d = a.parentNode && e(a.parentNode, "proxyof");
                    d && this.A[d].appendChild(a);
                  }
                  b.unshift.apply(b, A(a.childNodes));
                }
              };
              f.prototype.Z = function (a) {
                var b = this.u.clear();
                b && this.i.unshift(b);
                a.src = a.h.src || a.h.oa;
                a.src && this.l.length ? (this.o = a) : this.C(a);
                var c = this;
                this.la(a, function () {
                  c.K(a);
                });
              };
              f.prototype.aa = function (a) {
                var b = this.u.clear();
                b && this.i.unshift(b);
                a.type = a.h.type || a.h.TYPE || "text/css";
                this.na(a);
                b && this.write();
              };
              f.prototype.na = function (a) {
                var b = this.V(a);
                this.da(b);
                a.content &&
                  (b.styleSheet && !b.sheet
                    ? (b.styleSheet.cssText = a.content)
                    : b.appendChild(this.j.createTextNode(a.content)));
              };
              f.prototype.V = function (a) {
                var b = this.j.createElement(a.tagName);
                b.setAttribute("type", a.type);
                t(a.h, function (c, d) {
                  b.setAttribute(c, d);
                });
                return b;
              };
              f.prototype.da = function (a) {
                this.G('<span id="ps-style"/>');
                var b = this.j.getElementById("ps-style");
                b.parentNode.replaceChild(a, b);
              };
              f.prototype.C = function (a) {
                a.ea = this.i;
                this.i = [];
                this.l.unshift(a);
              };
              f.prototype.K = function (a) {
                a !== this.l[0]
                  ? this.options.error({
                      message: "Bad script nesting or script finished twice",
                    })
                  : (this.l.shift(),
                    this.write.apply(this, a.ea),
                    !this.l.length &&
                      this.o &&
                      (this.C(this.o), (this.o = null)));
              };
              f.prototype.la = function (a, b) {
                var c = this.U(a),
                  d = this.ja(c),
                  k = this.options.L;
                a.src &&
                  ((c.src = a.src),
                  this.ia(
                    c,
                    d
                      ? k
                      : function () {
                          b();
                          k();
                        }
                  ));
                try {
                  this.ca(c), (a.src && !d) || b();
                } catch (g) {
                  this.options.error(g), b();
                }
              };
              f.prototype.U = function (a) {
                var b = this.j.createElement(a.tagName);
                t(a.h, function (c, d) {
                  b.setAttribute(c, d);
                });
                a.content && (b.text = a.content);
                return b;
              };
              f.prototype.ca = function (a) {
                this.G('<span id="ps-script"/>');
                var b = this.j.getElementById("ps-script");
                b.parentNode.replaceChild(a, b);
              };
              f.prototype.ia = function (a, b) {
                function c() {
                  a = a.onload = a.onreadystatechange = a.onerror = null;
                }
                var d = this.options.error;
                q(a, {
                  onload: function () {
                    c();
                    b();
                  },
                  onreadystatechange: function () {
                    /^(loaded|complete)$/.test(a.readyState) && (c(), b());
                  },
                  onerror: function () {
                    var k = { message: "remote script failed " + a.src };
                    c();
                    d(k);
                    b();
                  },
                });
              };
              f.prototype.ja = function (a) {
                return (
                  !/^script$/i.test(a.nodeName) ||
                  !!(this.options.ha && a.src && a.hasAttribute("async"))
                );
              };
              return f;
            })();
          l.postscribe = (function () {
            function e() {
              var d = b.shift(),
                k;
              d &&
                ((k = d[d.length - 1]),
                k.M(),
                (d.stream = f.apply(null, d)),
                k.N());
            }
            function f(d, k, g) {
              function r(w) {
                w = g.S(w);
                c.write(w);
                g.O(w);
              }
              c = new z(d, g);
              c.id = a++;
              c.name = g.name || c.id;
              var v = d.ownerDocument,
                m = {
                  close: v.close,
                  open: v.open,
                  write: v.write,
                  writeln: v.writeln,
                };
              q(v, {
                close: n,
                open: n,
                write: function () {
                  return r(A(arguments).join(""));
                },
                writeln: function () {
                  return r(A(arguments).join("") + "\n");
                },
              });
              var p = c.m.onerror || n;
              c.m.onerror = function (w, G, H) {
                g.error({ sa: w + " - " + G + ":" + H });
                p.apply(c.m, arguments);
              };
              c.write(k, function () {
                q(v, m);
                c.m.onerror = p;
                g.done();
                c = null;
                e();
              });
              return c;
            }
            var a = 0,
              b = [],
              c = null;
            return q(
              function (d, k, g) {
                "function" === typeof g && (g = { done: g });
                g = B(g, h);
                d = /^#/.test(d)
                  ? l.document.getElementById(d.substr(1))
                  : d.ra
                  ? d[0]
                  : d;
                var r = [d, k, g];
                d.fa = {
                  cancel: function () {
                    r.stream ? r.stream.abort() : (r[1] = n);
                  },
                };
                g.R(r);
                b.push(r);
                c || e();
                return d.fa;
              },
              { streams: {}, queue: b, pa: z }
            );
          })();
          F = l.postscribe;
        }
      })();
      D(
        "google_tag_manager_external.postscribe.installPostscribe",
        function () {
          var n = window.google_tag_manager;
          n && (n.postscribe || (n.postscribe = window.postscribe || F));
        }
      );
      D("google_tag_manager_external.postscribe.getPostscribe", function () {
        return window.google_tag_manager.postscribe;
      });
    }.call(this));
  } catch {}

  var l,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      for (
        var b = [
            "object" == typeof globalThis && globalThis,
            a,
            "object" == typeof window && window,
            "object" == typeof self && self,
            "object" == typeof global && global,
          ],
          c = 0;
        c < b.length;
        ++c
      ) {
        var d = b[c];
        if (d && d.Math == Math) return d;
      }
      throw Error("Cannot find global object");
    },
    ha = ca(this),
    ia = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    ka = {},
    la = {},
    ma = function (a, b, c) {
      if (!c || a != null) {
        var d = la[b];
        if (d == null) return a[b];
        var e = a[d];
        return e !== void 0 ? e : a[b];
      }
    },
    na = function (a, b, c) {
      if (b)
        a: {
          var d = a.split("."),
            e = d.length === 1,
            f = d[0],
            g;
          !e && f in ka ? (g = ka) : (g = ha);
          for (var h = 0; h < d.length - 1; h++) {
            var k = d[h];
            if (!(k in g)) break a;
            g = g[k];
          }
          var m = d[d.length - 1],
            p = ia && c === "es6" ? g[m] : null,
            q = b(p);
          if (q != null)
            if (e) ba(ka, m, { configurable: !0, writable: !0, value: q });
            else if (q !== p) {
              if (la[m] === void 0) {
                var r = (Math.random() * 1e9) >>> 0;
                la[m] = ia ? ha.Symbol(m) : "$jscp$" + r + "$" + m;
              }
              ba(g, la[m], { configurable: !0, writable: !0, value: q });
            }
        }
    },
    oa;
  if (ia && typeof Object.setPrototypeOf == "function")
    oa = Object.setPrototypeOf;
  else {
    var pa;
    a: {
      var qa = { a: !0 },
        ra = {};
      try {
        ra.__proto__ = qa;
        pa = ra.a;
        break a;
      } catch (a) {}
      pa = !1;
    }
    oa = pa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var sa = oa,
    ta = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (sa) sa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.As = b.prototype;
    },
    ua = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    n = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: ua(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    xa = function (a) {
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      return c;
    },
    w = function (a) {
      return a instanceof Array ? a : xa(n(a));
    },
    za = function (a) {
      return ya(a, a);
    },
    ya = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    z = function (a, b) {
      var c;
      b && !b.done && (c = a["return"]) && c.call(a);
    },
    Aa =
      ia && typeof ma(Object, "assign") == "function"
        ? ma(Object, "assign")
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d)
                for (var e in d)
                  Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  na(
    "Object.assign",
    function (a) {
      return a || Aa;
    },
    "es6"
  );
  var Ba = function (a) {
      if (!(a instanceof Object))
        throw new TypeError("Iterator result " + a + " is not an object");
    },
    Ca = function () {
      this.ja = !1;
      this.P = null;
      this.Z = void 0;
      this.H = 1;
      this.T = this.da = 0;
      this.Ia = this.K = null;
    },
    Da = function (a) {
      if (a.ja) throw new TypeError("Generator is already running");
      a.ja = !0;
    };
  Ca.prototype.Aa = function (a) {
    this.Z = a;
  };
  var Ea = function (a, b) {
    a.K = { exception: b, isException: !0 };
    a.H = a.da || a.T;
  };
  Ca.prototype.getNextAddressJsc = function () {
    return this.H;
  };
  Ca.prototype.getYieldResultJsc = function () {
    return this.Z;
  };
  Ca.prototype.return = function (a) {
    this.K = { return: a };
    this.H = this.T;
  };
  Ca.prototype["return"] = Ca.prototype.return;
  Ca.prototype.sj = function (a) {
    this.K = { Ec: a };
    this.T < a ? ((this.H = a), (this.K = null)) : (this.H = this.T);
  };
  Ca.prototype.jumpThroughFinallyBlocks = Ca.prototype.sj;
  Ca.prototype.yield = function (a, b) {
    this.H = b;
    return { value: a };
  };
  Ca.prototype.yield = Ca.prototype.yield;
  Ca.prototype.xr = function (a, b) {
    var c = n(a),
      d = c.next();
    Ba(d);
    if (d.done) (this.Z = d.value), (this.H = b);
    else return (this.P = c), this.yield(d.value, b);
  };
  Ca.prototype.yieldAll = Ca.prototype.xr;
  Ca.prototype.Ec = function (a) {
    this.H = a;
  };
  Ca.prototype.jumpTo = Ca.prototype.Ec;
  Ca.prototype.wj = function () {
    this.H = 0;
  };
  Ca.prototype.jumpToEnd = Ca.prototype.wj;
  Ca.prototype.Fh = function (a, b) {
    this.da = a;
    b != void 0 && (this.T = b);
  };
  Ca.prototype.setCatchFinallyBlocks = Ca.prototype.Fh;
  Ca.prototype.Hh = function (a) {
    this.da = 0;
    this.T = a || 0;
  };
  Ca.prototype.setFinallyBlock = Ca.prototype.Hh;
  Ca.prototype.gr = function (a, b) {
    this.H = a;
    this.da = b || 0;
  };
  Ca.prototype.leaveTryBlock = Ca.prototype.gr;
  Ca.prototype.Pb = function (a) {
    this.da = a || 0;
    var b = this.K.exception;
    this.K = null;
    return b;
  };
  Ca.prototype.enterCatchBlock = Ca.prototype.Pb;
  Ca.prototype.jd = function (a, b, c) {
    c ? (this.Ia[c] = this.K) : (this.Ia = [this.K]);
    this.da = a || 0;
    this.T = b || 0;
    this.K = null;
  };
  Ca.prototype.enterFinallyBlock = Ca.prototype.jd;
  Ca.prototype.Td = function (a, b) {
    var c = this.Ia.splice(b || 0)[0],
      d = (this.K = this.K || c);
    d
      ? d.isException
        ? (this.H = this.da || this.T)
        : d.Ec != void 0 && this.T < d.Ec
        ? ((this.H = d.Ec), (this.K = null))
        : (this.H = this.T)
      : (this.H = a);
  };
  Ca.prototype.leaveFinallyBlock = Ca.prototype.Td;
  Ca.prototype.Sd = function (a) {
    return new Fa(a);
  };
  Ca.prototype.forIn = Ca.prototype.Sd;
  var Fa = function (a) {
    this.K = a;
    this.H = [];
    for (var b in a) this.H.push(b);
    this.H.reverse();
  };
  Fa.prototype.Lm = function () {
    for (; this.H.length > 0; ) {
      var a = this.H.pop();
      if (a in this.K) return a;
    }
    return null;
  };
  Fa.prototype.getNext = Fa.prototype.Lm;
  var Ha = function (a) {
      this.H = new Ca();
      this.K = a;
    },
    Ma = function (a, b) {
      Da(a.H);
      var c = a.H.P;
      if (c)
        return Ia(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.H.return
        );
      a.H.return(b);
      return Ja(a);
    },
    Ia = function (a, b, c, d) {
      try {
        var e = b.call(a.H.P, c);
        Ba(e);
        if (!e.done) return (a.H.ja = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.H.P = null), Ea(a.H, g), Ja(a);
      }
      a.H.P = null;
      d.call(a.H, f);
      return Ja(a);
    },
    Ja = function (a) {
      for (; a.H.H; )
        try {
          var b = a.K(a.H);
          if (b) return (a.H.ja = !1), { value: b.value, done: !1 };
        } catch (d) {
          (a.H.Z = void 0), Ea(a.H, d);
        }
      a.H.ja = !1;
      if (a.H.K) {
        var c = a.H.K;
        a.H.K = null;
        if (c.isException) throw c.exception;
        return { value: c.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Na = function (a) {
      this.next = function (b) {
        var c;
        Da(a.H);
        a.H.P ? (c = Ia(a, a.H.P.next, b, a.H.Aa)) : (a.H.Aa(b), (c = Ja(a)));
        return c;
      };
      this.throw = function (b) {
        var c;
        Da(a.H);
        if (a.H.P) {
          var d = a.H.P["throw"];
          if (d) c = Ia(a, d, b, a.H.Aa);
          else {
            var e = a.H.P;
            a.H.P = null;
            try {
              if (e["return"]) {
                var f = e["return"]();
                Ba(f);
              }
              Ea(
                a.H,
                new TypeError("The iterator does not provide a 'throw' method.")
              );
            } catch (g) {
              Ea(a.H, g);
            }
            c = Ja(a);
          }
        } else Ea(a.H, b), (c = Ja(a));
        return c;
      };
      this.return = function (b) {
        return Ma(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Oa = function (a, b) {
      var c = new Na(new Ha(b));
      if (sa) {
        var d =
          typeof Iterator != "undefined" &&
          Iterator.prototype &&
          !Iterator.prototype.next
            ? Iterator.prototype
            : null;
        if (d)
          if (a.prototype) {
            var e = a.prototype,
              f = Object.getPrototypeOf,
              g =
                ((typeof e === "object" && e !== null) ||
                  typeof e === "function") &&
                f
                  ? f(e)
                  : e.__proto__;
            if (!d.isPrototypeOf(e) && g === Object.prototype)
              try {
                sa(e, d);
              } catch (h) {}
          } else sa(c, d);
        a.prototype && sa(c, a.prototype);
      }
      return c;
    },
    Pa = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Qa = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    },
    Ra = function (a) {
      return a;
    }; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Sa = this || self,
    Ta = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.As = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.base = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Va = function (a, b) {
    this.type = a;
    this.data = b;
  };
  var Wa = function () {
    this.map = {};
    this.H = {};
  };
  Wa.prototype.get = function (a) {
    return this.map["dust." + a];
  };
  Wa.prototype.set = function (a, b) {
    var c = "dust." + a;
    this.H.hasOwnProperty(c) || (this.map[c] = b);
  };
  Wa.prototype.has = function (a) {
    return this.map.hasOwnProperty("dust." + a);
  };
  Wa.prototype.remove = function (a) {
    var b = "dust." + a;
    this.H.hasOwnProperty(b) || delete this.map[b];
  };
  var Xa = function (a, b) {
    var c = [],
      d;
    for (d in a.map)
      if (a.map.hasOwnProperty(d)) {
        var e = d.substring(5);
        switch (b) {
          case 1:
            c.push(e);
            break;
          case 2:
            c.push(a.map[d]);
            break;
          case 3:
            c.push([e, a.map[d]]);
        }
      }
    return c;
  };
  Wa.prototype.Fa = function () {
    return Xa(this, 1);
  };
  Wa.prototype.jc = function () {
    return Xa(this, 2);
  };
  Wa.prototype.hc = function () {
    return Xa(this, 3);
  };
  var Ya = function () {};
  Ya.prototype.reset = function () {};
  var Za = function () {
    this.value = {};
    this.prefix = "gtm.";
  };
  ha.Object.defineProperties(Za.prototype, {
    size: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.keys(this.value).length;
      },
    },
  });
  l = Za.prototype;
  l.set = function (a, b) {
    this.value[this.prefix + String(a)] = b;
  };
  l.get = function (a) {
    return this.value[this.prefix + String(a)];
  };
  l.has = function (a) {
    return this.value.hasOwnProperty(this.prefix + String(a));
  };
  l.delete = function (a) {
    var b = this.prefix + String(a);
    return this.value.hasOwnProperty(b) ? (delete this.value[b], !0) : !1;
  };
  l.clear = function () {
    this.value = {};
  };
  l.values = function () {
    var a = this;
    return (function c() {
      var d, e, f;
      return Oa(c, function (g) {
        switch (g.H) {
          case 1:
            g.Hh(2), (e = g.Sd(a.value));
          case 4:
            if ((d = e.Lm()) == null) {
              g.Ec(2);
              break;
            }
            if (!a.value.hasOwnProperty(d)) {
              g.Ec(4);
              break;
            }
            f = Ra;
            return g.yield(a.value[d], 8);
          case 8:
            f(g.Z);
            g.Ec(4);
            break;
          case 2:
            g.jd(), g.Td(0);
        }
      });
    })();
  };
  function $a() {
    try {
      if (Map) return new Map();
    } catch (a) {}
    return new Za();
  }
  var ab = function () {
    this.values = [];
  };
  ab.prototype.add = function (a) {
    this.values.indexOf(a) === -1 && this.values.push(a);
  };
  ab.prototype.has = function (a) {
    return this.values.indexOf(a) > -1;
  };
  var bb = function (a, b) {
    this.Z = a;
    this.parent = b;
    this.P = this.H = void 0;
    this.Ib = !1;
    this.K = function (d, e, f) {
      return d.apply(e, f);
    };
    this.variables = $a();
    var c;
    a: {
      try {
        if (Set) {
          c = new Set();
          break a;
        }
      } catch (d) {}
      c = new ab();
    }
    this.T = c;
  };
  bb.prototype.add = function (a, b) {
    cb(this, a, b, !1);
  };
  bb.prototype.Gh = function (a, b) {
    cb(this, a, b, !0);
  };
  var cb = function (a, b, c, d) {
    a.Ib || a.T.has(b) || (d && a.T.add(b), a.variables.set(b, c));
  };
  l = bb.prototype;
  l.set = function (a, b) {
    this.Ib ||
      (!this.variables.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.T.has(a) || this.variables.set(a, b));
  };
  l.get = function (a) {
    return this.variables.has(a)
      ? this.variables.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  l.has = function (a) {
    return !!this.variables.has(a) || !(!this.parent || !this.parent.has(a));
  };
  l.wb = function () {
    var a = new bb(this.Z, this);
    this.H && a.Rb(this.H);
    a.ud(this.K);
    a.de(this.P);
    return a;
  };
  l.Ud = function () {
    return this.Z;
  };
  l.Rb = function (a) {
    this.H = a;
  };
  l.Jm = function () {
    return this.H;
  };
  l.ud = function (a) {
    this.K = a;
  };
  l.zj = function () {
    return this.K;
  };
  l.Va = function () {
    this.Ib = !0;
  };
  l.de = function (a) {
    this.P = a;
  };
  l.hb = function () {
    return this.P;
  };
  var eb = function (a, b, c) {
    c = c === void 0 ? !1 : c;
    var d;
    d = Error.call(this, a.message);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.Qj = a;
    this.sm = c;
    this.K = [];
    this.H = b;
  };
  ta(eb, Error);
  var fb = function (a) {
    return a instanceof eb ? a : new eb(a, void 0, !0);
  };
  var gb = $a();
  function hb(a, b) {
    var c,
      d = n(b),
      e = d.next();
    try {
      for (; !e.done && !((c = ib(a, e.value)), c instanceof Va); e = d.next());
    } finally {
      z(d, e);
    }
    return c;
  }
  function ib(a, b) {
    try {
      var c = b[0],
        d = b.slice(1),
        e = String(c),
        f = gb.has(e) ? gb.get(e) : a.get(e);
      if (!f || typeof f.invoke !== "function")
        throw fb(Error("Attempting to execute non-function " + b[0] + "."));
      return f.apply(a, d);
    } catch (h) {
      var g = a.Jm();
      g && g(h, b.context ? { id: b[0], line: b.context.line } : null);
      throw h;
    }
  }
  var jb = function () {
    this.K = new Ya();
    this.H = new bb(this.K);
  };
  l = jb.prototype;
  l.Ud = function () {
    return this.K;
  };
  l.Rb = function (a) {
    this.H.Rb(a);
  };
  l.ud = function (a) {
    this.H.ud(a);
  };
  l.execute = function (a) {
    return this.run([a].concat(w(Qa.apply(1, arguments))));
  };
  l.run = function () {
    var a,
      b = n(Qa.apply(0, arguments)),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) a = ib(this.H, c.value);
    } finally {
      z(b, c);
    }
    return a;
  };
  l.Zo = function (a) {
    var b = Qa.apply(1, arguments),
      c = this.H.wb();
    c.de(a);
    var d,
      e = n(b),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) d = ib(c, f.value);
    } finally {
      z(e, f);
    }
    return d;
  };
  l.Va = function () {
    this.H.Va();
  };
  var lb = function (a, b) {
    this.T = a;
    this.parent = b;
    this.P = this.H = void 0;
    this.Ib = !1;
    this.K = function (c, d, e) {
      return c.apply(d, e);
    };
    this.values = new Wa();
  };
  lb.prototype.add = function (a, b) {
    mb(this, a, b, !1);
  };
  lb.prototype.Gh = function (a, b) {
    mb(this, a, b, !0);
  };
  var mb = function (a, b, c, d) {
    if (!a.Ib)
      if (d) {
        var e = a.values;
        e.set(b, c);
        e.H["dust." + b] = !0;
      } else a.values.set(b, c);
  };
  l = lb.prototype;
  l.set = function (a, b) {
    this.Ib ||
      (!this.values.has(a) && this.parent && this.parent.has(a)
        ? this.parent.set(a, b)
        : this.values.set(a, b));
  };
  l.get = function (a) {
    return this.values.has(a)
      ? this.values.get(a)
      : this.parent
      ? this.parent.get(a)
      : void 0;
  };
  l.has = function (a) {
    return !!this.values.has(a) || !(!this.parent || !this.parent.has(a));
  };
  l.wb = function () {
    var a = new lb(this.T, this);
    this.H && a.Rb(this.H);
    a.ud(this.K);
    a.de(this.P);
    return a;
  };
  l.Ud = function () {
    return this.T;
  };
  l.Rb = function (a) {
    this.H = a;
  };
  l.Jm = function () {
    return this.H;
  };
  l.ud = function (a) {
    this.K = a;
  };
  l.zj = function () {
    return this.K;
  };
  l.Va = function () {
    this.Ib = !0;
  };
  l.de = function (a) {
    this.P = a;
  };
  l.hb = function () {
    return this.P;
  };
  var nb = function () {
    this.Ma = !1;
    this.la = new Wa();
  };
  l = nb.prototype;
  l.get = function (a) {
    return this.la.get(a);
  };
  l.set = function (a, b) {
    this.Ma || this.la.set(a, b);
  };
  l.has = function (a) {
    return this.la.has(a);
  };
  l.remove = function (a) {
    this.Ma || this.la.remove(a);
  };
  l.Fa = function () {
    return this.la.Fa();
  };
  l.jc = function () {
    return this.la.jc();
  };
  l.hc = function () {
    return this.la.hc();
  };
  l.Va = function () {
    this.Ma = !0;
  };
  l.Ib = function () {
    return this.Ma;
  };
  function ob() {
    for (var a = pb, b = {}, c = 0; c < a.length; ++c) b[a[c]] = c;
    return b;
  }
  function qb() {
    var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    a += a.toLowerCase() + "0123456789-_";
    return a + ".";
  }
  var pb, rb;
  function sb(a) {
    pb = pb || qb();
    rb = rb || ob();
    for (var b = [], c = 0; c < a.length; c += 3) {
      var d = c + 1 < a.length,
        e = c + 2 < a.length,
        f = a.charCodeAt(c),
        g = d ? a.charCodeAt(c + 1) : 0,
        h = e ? a.charCodeAt(c + 2) : 0,
        k = f >> 2,
        m = ((f & 3) << 4) | (g >> 4),
        p = ((g & 15) << 2) | (h >> 6),
        q = h & 63;
      e || ((q = 64), d || (p = 64));
      b.push(pb[k], pb[m], pb[p], pb[q]);
    }
    return b.join("");
  }
  function tb(a) {
    function b(k) {
      for (; d < a.length; ) {
        var m = a.charAt(d++),
          p = rb[m];
        if (p != null) return p;
        if (!/^[\s\xa0]*$/.test(m))
          throw Error("Unknown base64 encoding at char: " + m);
      }
      return k;
    }
    pb = pb || qb();
    rb = rb || ob();
    for (var c = "", d = 0; ; ) {
      var e = b(-1),
        f = b(0),
        g = b(64),
        h = b(64);
      if (h === 64 && e === -1) return c;
      c += String.fromCharCode((e << 2) | (f >> 4));
      g !== 64 &&
        ((c += String.fromCharCode(((f << 4) & 240) | (g >> 2))),
        h !== 64 && (c += String.fromCharCode(((g << 6) & 192) | h)));
    }
  }
  var vb = {};
  function wb(a, b) {
    var c = vb[a];
    c || (c = vb[a] = []);
    c[b] = !0;
  }
  function xb() {
    delete vb.GA4_EVENT;
  }
  function yb(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++)
      d % 8 === 0 && d > 0 && (b.push(String.fromCharCode(c)), (c = 0)),
        a[d] && (c |= 1 << d % 8);
    c > 0 && b.push(String.fromCharCode(c));
    return sb(b.join("")).replace(/\.+$/, "");
  } /*
 jQuery (c) 2005, 2012 jQuery Foundation, Inc. jquery.org/license.
*/
  var zb = /\[object (Boolean|Number|String|Function|Array|Date|RegExp)\]/,
    Ab = function (a) {
      if (a == null) return String(a);
      var b = zb.exec(Object.prototype.toString.call(Object(a)));
      return b ? b[1].toLowerCase() : "object";
    },
    Bb = function (a, b) {
      return Object.prototype.hasOwnProperty.call(Object(a), b);
    },
    Db = function (a) {
      if (!a || Ab(a) != "object" || a.nodeType || a == a.window) return !1;
      try {
        if (
          a.constructor &&
          !Bb(a, "constructor") &&
          !Bb(a.constructor.prototype, "isPrototypeOf")
        )
          return !1;
      } catch (c) {
        return !1;
      }
      for (var b in a);
      return b === void 0 || Bb(a, b);
    },
    Eb = function (a, b) {
      var c = b || (Ab(a) == "array" ? [] : {}),
        d;
      for (d in a)
        if (Bb(a, d) && d !== "__proto__") {
          var e = a[d];
          Ab(e) == "array"
            ? (Ab(c[d]) != "array" && (c[d] = []), (c[d] = Eb(e, c[d])))
            : Db(e)
            ? (Db(c[d]) || (c[d] = {}), (c[d] = Eb(e, c[d])))
            : (c[d] = e);
        }
      return c;
    };
  function Fb() {}
  function Gb(a) {
    return typeof a === "function";
  }
  function Hb(a) {
    return typeof a === "string";
  }
  function Kb(a) {
    return typeof a === "number" && !isNaN(a);
  }
  function Lb(a) {
    return Array.isArray(a) ? a : [a];
  }
  function Mb(a, b) {
    if (a && Array.isArray(a))
      for (var c = 0; c < a.length; c++) if (a[c] && b(a[c])) return a[c];
  }
  function Nb(a, b) {
    if (!Kb(a) || !Kb(b) || a > b) (a = 0), (b = 2147483647);
    return Math.floor(Math.random() * (b - a + 1) + a);
  }
  function Ob(a, b) {
    for (var c = new Pb(), d = 0; d < a.length; d++) c.set(a[d], !0);
    for (var e = 0; e < b.length; e++) if (c.get(b[e])) return !0;
    return !1;
  }
  function Qb(a) {
    return (
      !!a &&
      (Object.prototype.toString.call(a) === "[object Arguments]" ||
        Object.prototype.hasOwnProperty.call(a, "callee"))
    );
  }
  function Rb(a) {
    return Math.round(Number(a)) || 0;
  }
  function Sb(a) {
    return "false" === String(a).toLowerCase() ? !1 : !!a;
  }
  function Tb(a) {
    var b = [];
    if (Array.isArray(a))
      for (var c = 0; c < a.length; c++) b.push(String(a[c]));
    return b;
  }
  function Ub(a) {
    return a ? a.replace(/^\s+|\s+$/g, "") : "";
  }
  function Vb() {
    return new Date(Date.now());
  }
  function Wb() {
    return Vb().getTime();
  }
  var Pb = function () {
    this.prefix = "gtm.";
    this.values = {};
  };
  Pb.prototype.set = function (a, b) {
    this.values[this.prefix + a] = b;
  };
  Pb.prototype.get = function (a) {
    return this.values[this.prefix + a];
  };
  Pb.prototype.contains = function (a) {
    return this.get(a) !== void 0;
  };
  function Xb(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = void 0;
        try {
          c();
        } catch (d) {}
      }
    };
  }
  function Yb(a, b) {
    for (var c in b) b.hasOwnProperty(c) && (a[c] = b[c]);
  }
  function Zb(a, b) {
    for (var c = [], d = 0; d < a.length; d++)
      c.push(a[d]), c.push.apply(c, b[a[d]] || []);
    return c;
  }
  function $b(a, b) {
    return a.length >= b.length && a.substring(0, b.length) === b;
  }
  function ac(a, b) {
    return (
      a.length >= b.length && a.substring(a.length - b.length, a.length) === b
    );
  }
  function bc(a, b, c) {
    c = c || [];
    for (var d = a, e = 0; e < b.length - 1; e++) {
      if (!d.hasOwnProperty(b[e])) return;
      d = d[b[e]];
      if (c.indexOf(d) >= 0) return;
    }
    return d;
  }
  function cc(a, b) {
    for (var c = {}, d = c, e = a.split("."), f = 0; f < e.length - 1; f++)
      d = d[e[f]] = {};
    d[e[e.length - 1]] = b;
    return c;
  }
  var dc = /^\w{1,9}$/;
  function ec(a, b) {
    a = a || {};
    b = b || ",";
    var c = [],
      d = n(Object.entries(a)),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = n(e.value),
          g = f.next().value,
          h = f.next().value,
          k = g,
          m = h;
        dc.test(k) && m && c.push(k);
      }
    } finally {
      z(d, e);
    }
    return c.join(b);
  }
  function fc(a) {
    for (var b = [], c = 0; c < a.length; c++) {
      var d = a.charCodeAt(c);
      d < 128
        ? b.push(d)
        : d < 2048
        ? b.push(192 | (d >> 6), 128 | (d & 63))
        : d < 55296 || d >= 57344
        ? b.push(224 | (d >> 12), 128 | ((d >> 6) & 63), 128 | (d & 63))
        : ((d = 65536 + (((d & 1023) << 10) | (a.charCodeAt(++c) & 1023))),
          b.push(
            240 | (d >> 18),
            128 | ((d >> 12) & 63),
            128 | ((d >> 6) & 63),
            128 | (d & 63)
          ));
    }
    return new Uint8Array(b);
  }
  function hc(a) {
    if (!a) return a;
    var b = a;
    try {
      b = decodeURIComponent(a);
    } catch (d) {}
    var c = b.split(",");
    return c.length === 2 && c[0] === c[1] ? c[0] : a;
  }
  function ic(a, b, c) {
    function d(m) {
      var p = m.split("=")[0];
      if (a.indexOf(p) < 0) return m;
      if (c !== void 0) return p + "=" + c;
    }
    function e(m) {
      return m
        .split("&")
        .map(d)
        .filter(function (p) {
          return p !== void 0;
        })
        .join("&");
    }
    var f = b.href.split(/[?#]/)[0],
      g = b.search,
      h = b.hash;
    g[0] === "?" && (g = g.substring(1));
    h[0] === "#" && (h = h.substring(1));
    g = e(g);
    h = e(h);
    g !== "" && (g = "?" + g);
    h !== "" && (h = "#" + h);
    var k = "" + f + g + h;
    k[k.length - 1] === "/" && (k = k.substring(0, k.length - 1));
    return k;
  }
  function jc(a) {
    for (var b = 0; b < 3; ++b)
      try {
        var c = decodeURIComponent(a).replace(/\+/g, " ");
        if (c === a) break;
        a = c;
      } catch (d) {
        return "";
      }
    return a;
  }
  function kc() {
    var a = A,
      b;
    a: {
      var c = a.crypto || a.msCrypto;
      if (c && c.getRandomValues)
        try {
          var d = new Uint8Array(25);
          c.getRandomValues(d);
          b = lc(String.fromCharCode.apply(String, w(d)));
          break a;
        } catch (e) {}
      b = void 0;
    }
    return b;
  }
  function lc(a) {
    return btoa(a).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function mc(a, b) {
    var c = a;
    if (b !== void 0) {
      if (b <= 0) return "";
      c.length > b && (c = c.substring(0, b));
    }
    for (; c.length > 0; )
      try {
        var d = encodeURIComponent(c).replace(
            /%([0-9A-F]{2})/g,
            function (f, g) {
              return String.fromCharCode(Number("0x" + g));
            }
          ),
          e = lc(d);
        if (b === void 0 || e.length <= b) return e;
        c = c.slice(0, -1);
      } catch (f) {
        if (f instanceof URIError && c.length > 0) c = c.slice(0, -1);
        else throw f;
      }
    return "";
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var nc = globalThis.trustedTypes,
    oc;
  function pc() {
    var a = null;
    if (!nc) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = nc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function qc() {
    oc === void 0 && (oc = pc());
    return oc;
  }
  var rc = function (a) {
    this.H = a;
  };
  rc.prototype.toString = function () {
    return this.H + "";
  };
  function sc(a) {
    var b = a,
      c = qc(),
      d = c ? c.createScriptURL(b) : b;
    return new rc(d);
  }
  function tc(a) {
    if (a instanceof rc) return a.H;
    throw Error("");
  }
  var uc = za([""]),
    vc = ya(["\x00"], ["\\0"]),
    wc = ya(["\n"], ["\\n"]),
    xc = ya(["\x00"], ["\\u0000"]);
  function yc(a) {
    return a.toString().indexOf("`") === -1;
  }
  yc(function (a) {
    return a(uc);
  }) ||
    yc(function (a) {
      return a(vc);
    }) ||
    yc(function (a) {
      return a(wc);
    }) ||
    yc(function (a) {
      return a(xc);
    });
  var zc = function (a) {
    this.H = a;
  };
  zc.prototype.toString = function () {
    return this.H;
  };
  var Ac = function (a) {
    this.isValid = a;
  };
  function Bc(a) {
    return new Ac(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var Cc = [
    Bc("data"),
    Bc("http"),
    Bc("https"),
    Bc("mailto"),
    Bc("ftp"),
    new Ac(function (a) {
      return /^[^:]*([/?#]|$)/.test(a);
    }),
  ];
  function Dc(a) {
    var b;
    b = b === void 0 ? Cc : b;
    if (a instanceof zc) return a;
    for (var c = 0; c < b.length; ++c) {
      var d = b[c];
      if (d instanceof Ac && d.isValid(a)) return new zc(a);
    }
  }
  var Ec = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Fc(a) {
    var b;
    if (a instanceof zc)
      if (a instanceof zc) b = a.H;
      else throw Error("");
    else b = Ec.test(a) ? a : void 0;
    return b;
  }
  function Gc(a, b) {
    var c = Fc(b);
    c !== void 0 && (a.action = c);
  }
  function Hc(a, b) {
    throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
  }
  var Ic = function (a) {
    this.H = a;
  };
  Ic.prototype.toString = function () {
    return this.H + "";
  };
  var Kc = function () {
    this.H = Jc[0].toLowerCase();
  };
  Kc.prototype.toString = function () {
    return this.H;
  };
  function Lc(a, b) {
    var c = [new Kc()];
    if (c.length === 0) throw Error("");
    var d = c.map(function (f) {
        var g;
        if (f instanceof Kc) g = f.H;
        else throw Error("");
        return g;
      }),
      e = b.toLowerCase();
    if (
      d.every(function (f) {
        return e.indexOf(f) !== 0;
      })
    )
      throw Error(
        'Attribute "' + b + '" does not match any of the allowed prefixes.'
      );
    a.setAttribute(b, "true");
  }
  var Mc = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Nc(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a;
  }
  var A = window,
    Oc = [],
    Pc = window.history,
    C = document,
    Qc = navigator;
  function Rc() {
    var a;
    try {
      a = Qc.serviceWorker;
    } catch (b) {
      return;
    }
    return a;
  }
  var Sc,
    Tc = C.currentScript,
    Uc = (Sc = Tc && Tc.tagName === "SCRIPT" ? Tc : null) && Sc.src;
  function Vc(a, b) {
    var c = A,
      d = c[a];
    c[a] = d === void 0 ? b : d;
    return c[a];
  }
  function Wc(a) {
    return (Qc.userAgent || "").indexOf(a) !== -1;
  }
  function Xc() {
    return Wc("Firefox") || Wc("FxiOS");
  }
  function Yc() {
    return (Wc("GSA") || Wc("GoogleApp")) && (Wc("iPhone") || Wc("iPad"));
  }
  function Zc() {
    return Wc("Edg/") || Wc("EdgA/") || Wc("EdgiOS/");
  }
  var ad = { async: 1, nonce: 1, onerror: 1, onload: 1, src: 1, type: 1 },
    bd = { height: 1, onload: 1, src: 1, style: 1, width: 1 };
  function cd(a, b, c) {
    if (b) {
      var d = n(Object.entries(b)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = n(e.value),
            g = f.next().value,
            h = f.next().value,
            k = g,
            m = h;
          k = k.toLowerCase();
          c.hasOwnProperty(k) || a.setAttribute(k, m);
        }
      } finally {
        z(d, e);
      }
    }
  }
  function dd(a, b, c, d, e) {
    var f = C.createElement("script");
    cd(f, d, ad);
    f.type = "text/javascript";
    f.async = !(d && d.async === !1);
    var g;
    g = sc(Nc(a));
    f.src = tc(g);
    var h,
      k = f.ownerDocument;
    k = k === void 0 ? document : k;
    var m,
      p,
      q =
        (p = (m = k).querySelector) == null
          ? void 0
          : p.call(m, "script[nonce]");
    (h = q == null ? "" : q.nonce || q.getAttribute("nonce") || "") &&
      f.setAttribute("nonce", h);
    b && (f.onload = b);
    c && (f.onerror = c);
    e ? e.appendChild(f) : ed.lr(f);
    return f;
  }
  function fd() {
    if (Uc) {
      var a = Uc.toLowerCase();
      if (a.indexOf("https://") === 0) return 2;
      if (a.indexOf("http://") === 0) return 3;
    }
    return 1;
  }
  function gd(a, b, c, d, e, f) {
    f = f === void 0 ? !0 : f;
    var g = e,
      h = !1;
    g || ((g = C.createElement("iframe")), (h = !0));
    cd(g, c, bd);
    if (d) {
      var k = n(Object.entries(d)),
        m = k.next();
      try {
        for (; !m.done; m = k.next()) {
          var p = n(m.value),
            q = p.next().value,
            r = p.next().value;
          g.dataset[q] = r;
        }
      } finally {
        z(k, m);
      }
    }
    f &&
      ((g.height = "0"),
      (g.width = "0"),
      (g.style.display = "none"),
      (g.style.visibility = "hidden"));
    a !== void 0 && (g.src = a);
    if (h) {
      var t = (C.body && C.body.lastChild) || C.body || C.head;
      t.parentNode.insertBefore(g, t);
    }
    b && (g.onload = b);
    return g;
  }
  function hd() {
    return ed.uq.apply(ed, w(Qa.apply(0, arguments)));
  }
  function id(a, b, c, d) {
    a.addEventListener && a.addEventListener(b, c, !!d);
  }
  function jd(a, b, c) {
    a.removeEventListener && a.removeEventListener(b, c, !1);
  }
  function kd(a) {
    A.setTimeout(a, 0);
  }
  function ld(a, b) {
    var c = Qa.apply(2, arguments),
      d,
      e = (d = A).setInterval.apply(d, [a, b].concat(w(c)));
    Oc.push(e);
    return e;
  }
  function md(a) {
    var b = A;
    if (Gb(b.queueMicrotask))
      try {
        b.queueMicrotask(a);
        return;
      } catch (d) {}
    var c;
    Gb((c = b.Promise) == null ? void 0 : c.resolve)
      ? b.Promise.resolve()
          .then(function () {
            a();
          })
          .catch(function () {})
      : kd(a);
  }
  function nd(a, b) {
    return a && b && a.attributes && a.attributes[b]
      ? a.attributes[b].value
      : null;
  }
  function od(a) {
    var b = a.innerText || a.textContent || "";
    b &&
      b !== " " &&
      ((b = b.replace(/^[\s\xa0]+/g, "")), (b = b.replace(/[\s\xa0]+$/g, "")));
    b && (b = b.replace(/(\xa0+|\s{2,}|\n|\r\t)/g, " "));
    return b;
  }
  function pd(a) {
    var b = C.createElement("div"),
      c = b,
      d,
      e;
    e = Nc("A<div>" + a + "</div>");
    var f = e,
      g = qc(),
      h = g ? g.createHTML(f) : f;
    d = new Ic(h);
    if (c.nodeType === 1 && /^(script|style)$/i.test(c.tagName))
      throw Error("");
    var k;
    if (d instanceof Ic) k = d.H;
    else throw Error("");
    c.innerHTML = k;
    b = b.lastChild;
    for (var m = []; b && b.firstChild; ) m.push(b.removeChild(b.firstChild));
    return m;
  }
  function qd(a, b, c) {
    c = c || 100;
    for (var d = {}, e = 0; e < b.length; e++) d[b[e]] = !0;
    for (var f = a, g = 0; f && g <= c; g++) {
      if (d[String(f.tagName).toLowerCase()]) return f;
      f = f.parentElement;
    }
    return null;
  }
  function rd(a, b, c) {
    var d;
    try {
      d = Qc.sendBeacon && Qc.sendBeacon(a);
    } catch (e) {
      wb("TAGGING", 15);
    }
    d ? b == null || b() : hd(a, b, c);
  }
  function sd(a, b) {
    try {
      if (Qc.sendBeacon !== void 0) return Qc.sendBeacon(a, b);
    } catch (c) {
      wb("TAGGING", 15);
    }
    return !1;
  }
  function td() {
    return Qc.sendBeacon !== void 0;
  }
  var ud = {
    cache: "no-store",
    credentials: "include",
    keepalive: !0,
    method: "POST",
    mode: "no-cors",
    redirect: "follow",
  };
  function vd(a, b, c, d, e) {
    if (wd()) {
      var f = ma(Object, "assign").call(Object, {}, ud);
      b && (f.body = b);
      c &&
        (c.attributionReporting &&
          (f.attributionReporting = c.attributionReporting),
        c.browsingTopics !== void 0 && (f.browsingTopics = c.browsingTopics),
        c.credentials && (f.credentials = c.credentials),
        c.keepalive !== void 0 && (f.keepalive = c.keepalive),
        c.method && (f.method = c.method),
        c.mode && (f.mode = c.mode));
      try {
        var g = A.fetch(a, f);
        if (g)
          return (
            g
              .then(function (k) {
                k && (k.ok || k.status === 0)
                  ? d == null || d(k)
                  : k
                  ? e == null || e(k)
                  : e == null || e();
              })
              .catch(function () {
                e == null || e();
              }),
            !0
          );
      } catch (k) {}
    }
    if (
      (c == null ? 0 : c.Vm) ||
      ((c == null ? 0 : c.credentials) && c.credentials !== "include")
    )
      return e == null || e(), !1;
    if (b) {
      var h = sd(a, b);
      h ? d == null || d() : e == null || e();
      return h;
    }
    ed.ls(a, d, e);
    return !0;
  }
  function wd() {
    return Gb(A.fetch);
  }
  function xd(a, b) {
    var c = a[b];
    c && typeof c.animVal === "string" && (c = c.animVal);
    return c;
  }
  function yd() {
    var a = A.performance;
    if (a && Gb(a.now)) return a.now();
  }
  function zd() {
    var a,
      b = A.performance;
    if (b && b.getEntriesByType)
      try {
        var c = b.getEntriesByType("navigation");
        c && c.length > 0 && (a = c[0].type);
      } catch (d) {
        return "e";
      }
    if (!a) return "u";
    switch (a) {
      case "navigate":
        return "n";
      case "back_forward":
        return "h";
      case "reload":
        return "r";
      case "prerender":
        return "p";
      default:
        return "x";
    }
  }
  function Ad() {
    return A.performance || void 0;
  }
  function Bd() {
    var a = A.webPixelsManager;
    return a ? a.createShopifyExtend !== void 0 : !1;
  }
  var ed = {
    uq: function (a, b, c, d) {
      var e = new Image(1, 1);
      cd(e, d, {});
      e.onload = function () {
        e.onload = null;
        b && b();
      };
      e.onerror = function () {
        e.onerror = null;
        c && c();
      };
      e.src = a;
      return e;
    },
    lr: function (a) {
      var b = C.getElementsByTagName("script")[0] || C.body || C.head;
      b.parentNode.insertBefore(a, b);
    },
    ls: rd,
  };
  function Cd(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function Dd(a, b) {
    return this.evaluate(a) === this.evaluate(b);
  }
  function Ed(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Fd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    return String(c).indexOf(String(d)) > -1;
  }
  function Gd(a, b) {
    var c = String(this.evaluate(a)),
      d = String(this.evaluate(b));
    return c.substring(0, d.length) === d;
  }
  function Hd(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    switch (c) {
      case "pageLocation":
        var e = A.location.href;
        d instanceof nb &&
          d.get("stripProtocol") &&
          (e = e.replace(/^https?:\/\//, ""));
        return e;
    }
  }
  function Id(a) {
    return (
      (typeof a === "number" && a >= 0 && isFinite(a) && a % 1 === 0) ||
      (typeof a === "string" && a[0] !== "-" && a === "" + parseInt(a))
    );
  }
  var Jd = function (a) {
    a = a === void 0 ? [] : a;
    this.la = new Wa();
    this.values = [];
    this.Ma = !1;
    for (var b in a)
      a.hasOwnProperty(b) &&
        (Id(b)
          ? (this.values[Number(b)] = a[Number(b)])
          : this.la.set(b, a[b]));
  };
  l = Jd.prototype;
  l.toString = function (a) {
    if (a && a.indexOf(this) >= 0) return "";
    for (var b = [], c = 0; c < this.values.length; c++) {
      var d = this.values[c];
      d === null || d === void 0
        ? b.push("")
        : d instanceof Jd
        ? ((a = a || []), a.push(this), b.push(d.toString(a)), a.pop())
        : b.push(String(d));
    }
    return b.join(",");
  };
  l.set = function (a, b) {
    if (!this.Ma)
      if (a === "length") {
        if (!Id(b))
          throw fb(
            Error("RangeError: Length property must be a valid integer.")
          );
        this.values.length = Number(b);
      } else Id(a) ? (this.values[Number(a)] = b) : this.la.set(a, b);
  };
  l.get = function (a) {
    return a === "length"
      ? this.length()
      : Id(a)
      ? this.values[Number(a)]
      : this.la.get(a);
  };
  l.length = function () {
    return this.values.length;
  };
  l.Fa = function () {
    for (var a = this.la.Fa(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(String(b));
    return a;
  };
  l.jc = function () {
    for (var a = this.la.jc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push(this.values[b]);
    return a;
  };
  l.hc = function () {
    for (var a = this.la.hc(), b = 0; b < this.values.length; b++)
      this.values.hasOwnProperty(b) && a.push([String(b), this.values[b]]);
    return a;
  };
  l.remove = function (a) {
    Id(a) ? delete this.values[Number(a)] : this.Ma || this.la.remove(a);
  };
  l.pop = function () {
    return this.values.pop();
  };
  l.push = function () {
    return this.values.push.apply(this.values, w(Qa.apply(0, arguments)));
  };
  l.shift = function () {
    return this.values.shift();
  };
  l.splice = function (a, b) {
    var c = Qa.apply(2, arguments);
    return b === void 0 && c.length === 0
      ? new Jd(this.values.splice(a))
      : new Jd(this.values.splice.apply(this.values, [a, b || 0].concat(w(c))));
  };
  l.unshift = function () {
    return this.values.unshift.apply(this.values, w(Qa.apply(0, arguments)));
  };
  l.has = function (a) {
    return (Id(a) && this.values.hasOwnProperty(a)) || this.la.has(a);
  };
  l.Va = function () {
    this.Ma = !0;
    Object.freeze(this.values);
  };
  l.Ib = function () {
    return this.Ma;
  };
  function Kd(a) {
    for (var b = [], c = 0; c < a.length(); c++) a.has(c) && (b[c] = a.get(c));
    return b;
  }
  var Ld = function (a, b) {
    this.functionName = a;
    this.fn = b;
    this.la = new Wa();
    this.Ma = !1;
  };
  l = Ld.prototype;
  l.toString = function () {
    return this.functionName;
  };
  l.getName = function () {
    return this.functionName;
  };
  l.getKeys = function () {
    return new Jd(this.Fa());
  };
  l.invoke = function (a) {
    return this.fn.call.apply(
      this.fn,
      [new Md(this, a)].concat(w(Qa.apply(1, arguments)))
    );
  };
  l.apply = function (a, b) {
    return this.fn.apply(new Md(this, a), b);
  };
  l.Ic = function (a) {
    var b = Qa.apply(1, arguments);
    try {
      return this.invoke.apply(this, [a].concat(w(b)));
    } catch (c) {}
  };
  l.get = function (a) {
    return this.la.get(a);
  };
  l.set = function (a, b) {
    this.Ma || this.la.set(a, b);
  };
  l.has = function (a) {
    return this.la.has(a);
  };
  l.remove = function (a) {
    this.Ma || this.la.remove(a);
  };
  l.Fa = function () {
    return this.la.Fa();
  };
  l.jc = function () {
    return this.la.jc();
  };
  l.hc = function () {
    return this.la.hc();
  };
  l.Va = function () {
    this.Ma = !0;
  };
  l.Ib = function () {
    return this.Ma;
  };
  var Nd = function (a, b) {
    Ld.call(this, a, b);
  };
  ta(Nd, Ld);
  var Od = function (a, b) {
    Ld.call(this, a, b);
  };
  ta(Od, Ld);
  var Md = function (a, b) {
    this.fn = a;
    this.V = b;
  };
  Md.prototype.evaluate = function (a) {
    var b = this.V;
    return Array.isArray(a) ? ib(b, a) : a;
  };
  Md.prototype.getName = function () {
    return this.fn.getName();
  };
  Md.prototype.Ud = function () {
    return this.V.Ud();
  };
  var Pd = function () {
    this.map = new Map();
  };
  Pd.prototype.set = function (a, b) {
    this.map.set(a, b);
  };
  Pd.prototype.get = function (a) {
    return this.map.get(a);
  };
  var Qd = function () {
    this.keys = [];
    this.values = [];
  };
  Qd.prototype.set = function (a, b) {
    this.keys.push(a);
    this.values.push(b);
  };
  Qd.prototype.get = function (a) {
    var b = this.keys.indexOf(a);
    if (b > -1) return this.values[b];
  };
  function Rd() {
    try {
      return Map ? new Pd() : new Qd();
    } catch (a) {
      return new Qd();
    }
  }
  var Sd = function (a) {
    if (a instanceof Sd) return a;
    var b;
    a: if (a == void 0 || Array.isArray(a) || Db(a)) b = !0;
    else {
      switch (typeof a) {
        case "boolean":
        case "number":
        case "string":
        case "function":
          b = !0;
          break a;
      }
      b = !1;
    }
    if (b) throw Error("Type of given value has an equivalent Pixie type.");
    this.value = a;
  };
  Sd.prototype.getValue = function () {
    return this.value;
  };
  Sd.prototype.toString = function () {
    return String(this.value);
  };
  var Ud = function (a) {
    this.promise = a;
    this.Ma = this.Om = !1;
    this.la = new Wa();
    this.la.set("then", Td(this));
    this.la.set("catch", Td(this, !0));
    this.la.set("finally", Td(this, !1, !0));
  };
  l = Ud.prototype;
  l.get = function (a) {
    return this.la.get(a);
  };
  l.set = function (a, b) {
    this.Ma || this.la.set(a, b);
  };
  l.has = function (a) {
    return this.la.has(a);
  };
  l.remove = function (a) {
    this.Ma || this.la.remove(a);
  };
  l.Fa = function () {
    return this.la.Fa();
  };
  l.jc = function () {
    return this.la.jc();
  };
  l.hc = function () {
    return this.la.hc();
  };
  var Td = function (a, b, c) {
    b = b === void 0 ? !1 : b;
    c = c === void 0 ? !1 : c;
    return new Nd("", function (d, e) {
      a.Om = !0;
      b && ((e = d), (d = void 0));
      c && (e = d);
      d instanceof Nd || (d = void 0);
      e instanceof Nd || (e = void 0);
      var f = this.V.wb(),
        g = function (k) {
          return function (m) {
            try {
              return c ? (k.invoke(f), a.promise) : k.invoke(f, m);
            } catch (p) {
              return Promise.reject(p instanceof Error ? new Sd(p) : String(p));
            }
          };
        },
        h = a.promise.then(d && g(d), e && g(e));
      return new Ud(h);
    });
  };
  Ud.prototype.Va = function () {
    this.Ma = !0;
  };
  Ud.prototype.Ib = function () {
    return this.Ma;
  };
  function D(a, b, c) {
    var d = Rd(),
      e = function (g, h) {
        for (var k = g.Fa(), m = 0; m < k.length; m++) h[k[m]] = f(g.get(k[m]));
      },
      f = function (g) {
        if (g === null || g === void 0) return g;
        var h = d.get(g);
        if (h) return h;
        if (g instanceof Jd) {
          var k = [];
          d.set(g, k);
          for (var m = g.Fa(), p = 0; p < m.length; p++)
            k[m[p]] = f(g.get(m[p]));
          return k;
        }
        if (g instanceof Ud)
          return g.promise.then(
            function (u) {
              return D(u, b, 1);
            },
            function (u) {
              return Promise.reject(D(u, b, 1));
            }
          );
        if (g instanceof nb) {
          var q = {};
          d.set(g, q);
          e(g, q);
          return q;
        }
        if (g instanceof Nd) {
          var r = function () {
            for (var u = [], v = 0; v < arguments.length; v++)
              u[v] = Vd(arguments[v], b, c);
            var x = new lb(b ? b.Ud() : new Ya());
            b && x.de(b.hb());
            return f(g.apply(x, u));
          };
          d.set(g, r);
          e(g, r);
          return r;
        }
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          case 3:
            t = !1;
            break;
          default:
        }
        if (g instanceof Sd && t) return g.getValue();
        switch (typeof g) {
          case "boolean":
          case "number":
          case "string":
          case "undefined":
            return g;
          case "object":
            if (g === null) return null;
        }
      };
    return f(a);
  }
  function Vd(a, b, c) {
    var d = Rd(),
      e = function (g, h) {
        for (var k in g) g.hasOwnProperty(k) && h.set(k, f(g[k]));
      },
      f = function (g) {
        var h = d.get(g);
        if (h) return h;
        if (Array.isArray(g) || Qb(g)) {
          var k = new Jd();
          d.set(g, k);
          for (var m in g) g.hasOwnProperty(m) && k.set(m, f(g[m]));
          return k;
        }
        if (Db(g)) {
          var p = new nb();
          d.set(g, p);
          e(g, p);
          return p;
        }
        if (typeof g === "function") {
          var q = new Nd("", function () {
            for (
              var u = Qa.apply(0, arguments), v = [], x = 0;
              x < u.length;
              x++
            )
              v[x] = D(this.evaluate(u[x]), b, c);
            return f(this.V.zj()(g, g, v));
          });
          d.set(g, q);
          e(g, q);
          return q;
        }
        var r = typeof g;
        if (g === null || r === "string" || r === "number" || r === "boolean")
          return g;
        var t = !1;
        switch (c) {
          case 1:
            t = !0;
            break;
          case 2:
            t = !1;
            break;
          default:
        }
        if (g !== void 0 && t) return new Sd(g);
      };
    return f(a);
  }
  var Wd = {
    supportedMethods:
      "concat every filter forEach hasOwnProperty indexOf join lastIndexOf map pop push reduce reduceRight reverse shift slice some sort splice unshift toString".split(
        " "
      ),
    concat: function (a) {
      for (var b = [], c = 0; c < this.length(); c++) b.push(this.get(c));
      for (var d = 1; d < arguments.length; d++)
        if (arguments[d] instanceof Jd)
          for (var e = arguments[d], f = 0; f < e.length(); f++)
            b.push(e.get(f));
        else b.push(arguments[d]);
      return new Jd(b);
    },
    every: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && !b.invoke(a, this.get(d), d, this)) return !1;
      return !0;
    },
    filter: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && b.invoke(a, this.get(e), e, this) && d.push(this.get(e));
      return new Jd(d);
    },
    forEach: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        this.has(d) && b.invoke(a, this.get(d), d, this);
    },
    hasOwnProperty: function (a, b) {
      return this.has(b);
    },
    indexOf: function (a, b, c) {
      var d = this.length(),
        e = c === void 0 ? 0 : Number(c);
      e < 0 && (e = Math.max(d + e, 0));
      for (var f = e; f < d; f++)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    join: function (a, b) {
      for (var c = [], d = 0; d < this.length(); d++) c.push(this.get(d));
      return c.join(b);
    },
    lastIndexOf: function (a, b, c) {
      var d = this.length(),
        e = d - 1;
      c !== void 0 && (e = c < 0 ? d + c : Math.min(c, e));
      for (var f = e; f >= 0; f--)
        if (this.has(f) && this.get(f) === b) return f;
      return -1;
    },
    map: function (a, b) {
      for (
        var c = this.length(), d = [], e = 0;
        e < this.length() && e < c;
        e++
      )
        this.has(e) && (d[e] = b.invoke(a, this.get(e), e, this));
      return new Jd(d);
    },
    pop: function () {
      return this.pop();
    },
    push: function (a) {
      return this.push.apply(this, w(Qa.apply(1, arguments)));
    },
    reduce: function (a, b, c) {
      var d = this.length(),
        e,
        f = 0;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw fb(Error("TypeError: Reduce on List with no elements."));
        for (var g = 0; g < d; g++)
          if (this.has(g)) {
            e = this.get(g);
            f = g + 1;
            break;
          }
        if (g === d)
          throw fb(Error("TypeError: Reduce on List with no elements."));
      }
      for (var h = f; h < d; h++)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reduceRight: function (a, b, c) {
      var d = this.length(),
        e,
        f = d - 1;
      if (c !== void 0) e = c;
      else {
        if (d === 0)
          throw fb(Error("TypeError: ReduceRight on List with no elements."));
        for (var g = 1; g <= d; g++)
          if (this.has(d - g)) {
            e = this.get(d - g);
            f = d - (g + 1);
            break;
          }
        if (g > d)
          throw fb(Error("TypeError: ReduceRight on List with no elements."));
      }
      for (var h = f; h >= 0; h--)
        this.has(h) && (e = b.invoke(a, e, this.get(h), h, this));
      return e;
    },
    reverse: function () {
      for (var a = Kd(this), b = a.length - 1, c = 0; b >= 0; b--, c++)
        a.hasOwnProperty(b) ? this.set(c, a[b]) : this.remove(c);
      return this;
    },
    shift: function () {
      return this.shift();
    },
    slice: function (a, b, c) {
      var d = this.length();
      b === void 0 && (b = 0);
      b = b < 0 ? Math.max(d + b, 0) : Math.min(b, d);
      c = c === void 0 ? d : c < 0 ? Math.max(d + c, 0) : Math.min(c, d);
      c = Math.max(b, c);
      for (var e = [], f = b; f < c; f++) e.push(this.get(f));
      return new Jd(e);
    },
    some: function (a, b) {
      for (var c = this.length(), d = 0; d < this.length() && d < c; d++)
        if (this.has(d) && b.invoke(a, this.get(d), d, this)) return !0;
      return !1;
    },
    sort: function (a, b) {
      var c = Kd(this);
      b === void 0
        ? c.sort()
        : c.sort(function (e, f) {
            return Number(b.invoke(a, e, f));
          });
      for (var d = 0; d < c.length; d++)
        c.hasOwnProperty(d) ? this.set(d, c[d]) : this.remove(d);
      return this;
    },
    splice: function (a, b, c) {
      return this.splice.apply(this, [b, c].concat(w(Qa.apply(3, arguments))));
    },
    toString: function () {
      return this.toString();
    },
    unshift: function (a) {
      return this.unshift.apply(this, w(Qa.apply(1, arguments)));
    },
  };
  var Yd = {
      charAt: 1,
      concat: 1,
      indexOf: 1,
      lastIndexOf: 1,
      match: 1,
      replace: 1,
      search: 1,
      slice: 1,
      split: 1,
      substring: 1,
      toLowerCase: 1,
      toLocaleLowerCase: 1,
      toString: 1,
      toUpperCase: 1,
      toLocaleUpperCase: 1,
      trim: 1,
    },
    Zd = new Va("break"),
    $d = new Va("continue");
  function ae(a, b) {
    return this.evaluate(a) + this.evaluate(b);
  }
  function be(a, b) {
    return this.evaluate(a) && this.evaluate(b);
  }
  function ce(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!(f instanceof Jd))
      throw Error("Error: Non-List argument given to Apply instruction.");
    if (d === null || d === void 0)
      throw fb(Error("TypeError: Can't read property " + e + " of " + d + "."));
    var g = typeof d === "number";
    if (typeof d === "boolean" || g) {
      if (e === "toString") {
        if (g && f.length()) {
          var h = D(f.get(0));
          try {
            return d.toString(h);
          } catch (u) {}
        }
        return d.toString();
      }
      throw fb(Error("TypeError: " + d + "." + e + " is not a function."));
    }
    if (typeof d === "string") {
      if (Yd.hasOwnProperty(e)) {
        var k = D(f, void 0, 1);
        return Vd(d[e].apply(d, k), this.V);
      }
      throw fb(Error("TypeError: " + e + " is not a function"));
    }
    if (d instanceof Jd) {
      if (d.has(e)) {
        var m = d.get(String(e));
        if (m instanceof Nd) {
          var p = Kd(f);
          return m.apply(this.V, p);
        }
        throw fb(Error("TypeError: " + e + " is not a function"));
      }
      if (Wd.supportedMethods.indexOf(e) >= 0) {
        var q = Kd(f);
        return Wd[e].call.apply(Wd[e], [d, this.V].concat(w(q)));
      }
    }
    if (d instanceof Nd || d instanceof nb || d instanceof Ud) {
      if (d.has(e)) {
        var r = d.get(e);
        if (r instanceof Nd) {
          var t = Kd(f);
          return r.apply(this.V, t);
        }
        throw fb(Error("TypeError: " + e + " is not a function"));
      }
      if (e === "toString") return d instanceof Nd ? d.getName() : d.toString();
      if (e === "hasOwnProperty") return d.has(f.get(0));
    }
    if (d instanceof Sd && e === "toString") return d.toString();
    throw fb(Error("TypeError: Object has no '" + e + "' property."));
  }
  function de(a, b) {
    a = this.evaluate(a);
    if (typeof a !== "string")
      throw Error("Invalid key name given for assignment.");
    var c = this.V;
    if (!c.has(a)) throw Error("Attempting to assign to undefined value " + b);
    var d = this.evaluate(b);
    c.set(a, d);
    return d;
  }
  function ee() {
    var a = Qa.apply(0, arguments),
      b = this.V.wb(),
      c = hb(b, a);
    if (c instanceof Va) return c;
  }
  function fe() {
    return Zd;
  }
  function ge(a) {
    for (var b = this.evaluate(a), c = 0; c < b.length; c++) {
      var d = this.evaluate(b[c]);
      if (d instanceof Va) return d;
    }
  }
  function he() {
    for (var a = this.V, b = 0; b < arguments.length - 1; b += 2) {
      var c = arguments[b];
      if (typeof c === "string") {
        var d = this.evaluate(arguments[b + 1]);
        a.Gh(c, d);
      }
    }
  }
  function ie() {
    return $d;
  }
  function je(a, b) {
    return new Va(a, this.evaluate(b));
  }
  function ke(a, b) {
    var c = Qa.apply(2, arguments),
      d;
    d = new Jd();
    for (var e = this.evaluate(b), f = 0; f < e.length; f++) d.push(e[f]);
    var g = [51, a, d].concat(w(c));
    this.V.add(a, this.evaluate(g));
  }
  function le(a, b) {
    return this.evaluate(a) / this.evaluate(b);
  }
  function me(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b),
      e = c instanceof Sd,
      f = d instanceof Sd;
    return e || f ? (e && f ? c.getValue() === d.getValue() : !1) : c == d;
  }
  function ne() {
    for (var a, b = 0; b < arguments.length; b++)
      a = this.evaluate(arguments[b]);
    return a;
  }
  function oe(a, b, c, d) {
    for (var e = 0; e < b(); e++) {
      var f = a(c(e)),
        g = hb(f, d);
      if (g instanceof Va) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
    }
  }
  function pe(a, b, c) {
    if (typeof b === "string")
      return oe(
        a,
        function () {
          return b.length;
        },
        function (f) {
          return f;
        },
        c
      );
    if (
      b instanceof nb ||
      b instanceof Ud ||
      b instanceof Jd ||
      b instanceof Nd
    ) {
      var d = b.Fa(),
        e = d.length;
      return oe(
        a,
        function () {
          return e;
        },
        function (f) {
          return d[f];
        },
        c
      );
    }
  }
  function qe(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return pe(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function re(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return pe(
      function (h) {
        var k = g.wb();
        k.Gh(d, h);
        return k;
      },
      e,
      f
    );
  }
  function se(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return pe(
      function (h) {
        var k = g.wb();
        k.add(d, h);
        return k;
      },
      e,
      f
    );
  }
  function te(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return ue(
      function (h) {
        g.set(d, h);
        return g;
      },
      e,
      f
    );
  }
  function ve(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return ue(
      function (h) {
        var k = g.wb();
        k.Gh(d, h);
        return k;
      },
      e,
      f
    );
  }
  function we(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c),
      g = this.V;
    return ue(
      function (h) {
        var k = g.wb();
        k.add(d, h);
        return k;
      },
      e,
      f
    );
  }
  function ue(a, b, c) {
    if (typeof b === "string")
      return oe(
        a,
        function () {
          return b.length;
        },
        function (d) {
          return b[d];
        },
        c
      );
    if (b instanceof Jd)
      return oe(
        a,
        function () {
          return b.length();
        },
        function (d) {
          return b.get(d);
        },
        c
      );
    throw fb(Error("The value is not iterable."));
  }
  function xe(a, b, c, d) {
    function e(q, r) {
      for (var t = 0; t < f.length(); t++) {
        var u = f.get(t);
        r.add(u, q.get(u));
      }
    }
    var f = this.evaluate(a);
    if (!(f instanceof Jd))
      throw Error("TypeError: Non-List argument given to ForLet instruction.");
    var g = this.V,
      h = this.evaluate(d),
      k = g.wb();
    for (e(g, k); ib(k, b); ) {
      var m = hb(k, h);
      if (m instanceof Va) {
        if (m.type === "break") break;
        if (m.type === "return") return m;
      }
      var p = g.wb();
      e(k, p);
      ib(p, c);
      k = p;
    }
  }
  function ye(a, b) {
    var c = Qa.apply(2, arguments),
      d = this.V,
      e = this.evaluate(b);
    if (!(e instanceof Jd))
      throw Error("Error: non-List value given for Fn argument names.");
    return new Nd(
      a,
      (function () {
        return function () {
          var f = Qa.apply(0, arguments),
            g = d.wb();
          g.hb() === void 0 && g.de(this.V.hb());
          for (var h = [], k = 0; k < f.length; k++) {
            var m = this.evaluate(f[k]);
            h[k] = m;
          }
          for (var p = e.get("length"), q = 0; q < p; q++)
            q < h.length ? g.add(e.get(q), h[q]) : g.add(e.get(q), void 0);
          g.add("arguments", new Jd(h));
          var r = hb(g, c);
          if (r instanceof Va) return r.type === "return" ? r.data : r;
        };
      })()
    );
  }
  function ze(a) {
    var b = this.evaluate(a),
      c = this.V;
    if (Ae && !c.has(b)) throw new ReferenceError(b + " is not defined.");
    return c.get(b);
  }
  function Be(a, b) {
    var c,
      d = this.evaluate(a),
      e = this.evaluate(b);
    if (d === void 0 || d === null)
      throw fb(
        Error(
          "TypeError: Cannot read properties of " + d + " (reading '" + e + "')"
        )
      );
    if (
      d instanceof nb ||
      d instanceof Ud ||
      d instanceof Jd ||
      d instanceof Nd
    )
      c = d.get(e);
    else if (typeof d === "string")
      e === "length" ? (c = d.length) : Id(e) && (c = d[e]);
    else if (d instanceof Sd) return;
    return c;
  }
  function Ce(a, b) {
    return this.evaluate(a) > this.evaluate(b);
  }
  function De(a, b) {
    return this.evaluate(a) >= this.evaluate(b);
  }
  function Ee(a, b) {
    var c = this.evaluate(a),
      d = this.evaluate(b);
    c instanceof Sd && (c = c.getValue());
    d instanceof Sd && (d = d.getValue());
    return c === d;
  }
  function Fe(a, b) {
    return !Ee.call(this, a, b);
  }
  function Ge(a, b, c) {
    var d = [];
    this.evaluate(a) ? (d = this.evaluate(b)) : c && (d = this.evaluate(c));
    var e = hb(this.V, d);
    if (e instanceof Va) return e;
  }
  var Ae = !1;
  function He(a, b) {
    return this.evaluate(a) < this.evaluate(b);
  }
  function Ie(a, b) {
    return this.evaluate(a) <= this.evaluate(b);
  }
  function Je() {
    for (var a = new Jd(), b = 0; b < arguments.length; b++) {
      var c = this.evaluate(arguments[b]);
      a.push(c);
    }
    return a;
  }
  function Ke() {
    for (var a = new nb(), b = 0; b < arguments.length - 1; b += 2) {
      var c = String(this.evaluate(arguments[b])),
        d = this.evaluate(arguments[b + 1]);
      a.set(c, d);
    }
    return a;
  }
  function Le(a, b) {
    return this.evaluate(a) % this.evaluate(b);
  }
  function Me(a, b) {
    return this.evaluate(a) * this.evaluate(b);
  }
  function Ne(a) {
    return -this.evaluate(a);
  }
  function Oe(a) {
    return !this.evaluate(a);
  }
  function Pe(a, b) {
    return !me.call(this, a, b);
  }
  function Qe() {
    return null;
  }
  function Re(a, b) {
    return this.evaluate(a) || this.evaluate(b);
  }
  function Se(a, b) {
    var c = this.evaluate(a);
    this.evaluate(b);
    return c;
  }
  function Te(a) {
    return this.evaluate(a);
  }
  function Ue() {
    return Qa.apply(0, arguments);
  }
  function Ve(a) {
    return new Va("return", this.evaluate(a));
  }
  function We(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (d === null || d === void 0)
      throw fb(Error("TypeError: Can't set property " + e + " of " + d + "."));
    (d instanceof Nd || d instanceof Jd || d instanceof nb) &&
      d.set(String(e), f);
    return f;
  }
  function Xe(a, b) {
    return this.evaluate(a) - this.evaluate(b);
  }
  function Ye(a, b, c) {
    var d = this.evaluate(a),
      e = this.evaluate(b),
      f = this.evaluate(c);
    if (!Array.isArray(e) || !Array.isArray(f))
      throw Error("Error: Malformed switch instruction.");
    for (var g, h = !1, k = 0; k < e.length; k++)
      if (h || d === this.evaluate(e[k]))
        if (((g = this.evaluate(f[k])), g instanceof Va)) {
          var m = g.type;
          if (m === "break") return;
          if (m === "return" || m === "continue") return g;
        } else h = !0;
    if (
      f.length === e.length + 1 &&
      ((g = this.evaluate(f[f.length - 1])),
      g instanceof Va && (g.type === "return" || g.type === "continue"))
    )
      return g;
  }
  function Ze(a, b, c) {
    return this.evaluate(a) ? this.evaluate(b) : this.evaluate(c);
  }
  function $e(a) {
    var b = this.evaluate(a);
    return b instanceof Nd ? "function" : typeof b;
  }
  function af() {
    for (var a = this.V, b = 0; b < arguments.length; b++) {
      var c = arguments[b];
      typeof c !== "string" || a.add(c, void 0);
    }
  }
  function bf(a, b, c, d) {
    var e = this.evaluate(d);
    if (this.evaluate(c)) {
      var f = hb(this.V, e);
      if (f instanceof Va) {
        if (f.type === "break") return;
        if (f.type === "return") return f;
      }
    }
    for (; this.evaluate(a); ) {
      var g = hb(this.V, e);
      if (g instanceof Va) {
        if (g.type === "break") break;
        if (g.type === "return") return g;
      }
      this.evaluate(b);
    }
  }
  function cf(a) {
    return ~Number(this.evaluate(a));
  }
  function df(a, b) {
    return Number(this.evaluate(a)) << Number(this.evaluate(b));
  }
  function ef(a, b) {
    return Number(this.evaluate(a)) >> Number(this.evaluate(b));
  }
  function ff(a, b) {
    return Number(this.evaluate(a)) >>> Number(this.evaluate(b));
  }
  function gf(a, b) {
    return Number(this.evaluate(a)) & Number(this.evaluate(b));
  }
  function hf(a, b) {
    return Number(this.evaluate(a)) ^ Number(this.evaluate(b));
  }
  function jf(a, b) {
    return Number(this.evaluate(a)) | Number(this.evaluate(b));
  }
  function kf() {}
  function lf(a, b, c) {
    try {
      var d = this.evaluate(b);
      if (d instanceof Va) return d;
    } catch (h) {
      if (!(h instanceof eb && h.sm)) throw h;
      var e = this.V.wb();
      a !== "" && (h instanceof eb && (h = h.Qj), e.add(a, new Sd(h)));
      var f = this.evaluate(c),
        g = hb(e, f);
      if (g instanceof Va) return g;
    }
  }
  function mf(a, b) {
    var c, d;
    try {
      d = this.evaluate(a);
    } catch (f) {
      if (!(f instanceof eb && f.sm)) throw f;
      c = f;
    }
    var e = this.evaluate(b);
    if (e instanceof Va) return e;
    if (c) throw c;
    if (d instanceof Va) return d;
  }
  var of = function () {
    this.H = new jb();
    nf(this);
  };
  of.prototype.execute = function (a) {
    return this.H.run(a);
  };
  var nf = function (a) {
    var b = function (c, d) {
      var e = new Od(String(c), d);
      e.Va();
      var f = String(c);
      a.H.H.set(f, e);
      gb.set(f, e);
    };
    b("map", Ke);
    b("and", Cd);
    b("contains", Fd);
    b("equals", Dd);
    b("or", Ed);
    b("startsWith", Gd);
    b("variable", Hd);
  };
  of.prototype.Rb = function (a) {
    this.H.Rb(a);
  };
  var qf = function () {
    this.K = !1;
    this.H = new jb();
    pf(this);
    this.K = !0;
  };
  qf.prototype.execute = function (a) {
    return sf(this.H.run(a));
  };
  qf.prototype.Va = function () {
    this.H.Va();
  };
  var pf = function (a) {
    var b = function (c, d) {
      var e = String(c),
        f = new Od(e, d);
      f.Va();
      a.H.H.set(e, f);
      gb.set(e, f);
    };
    b(0, ae);
    b(1, be);
    b(2, ce);
    b(3, de);
    b(56, gf);
    b(57, df);
    b(58, cf);
    b(59, jf);
    b(60, ef);
    b(61, ff);
    b(62, hf);
    b(53, ee);
    b(4, fe);
    b(5, ge);
    b(68, lf);
    b(52, he);
    b(6, ie);
    b(49, je);
    b(7, Je);
    b(8, Ke);
    b(9, ge);
    b(50, ke);
    b(10, le);
    b(12, me);
    b(13, ne);
    b(67, mf);
    b(51, ye);
    b(47, qe);
    b(54, re);
    b(55, se);
    b(63, xe);
    b(64, te);
    b(65, ve);
    b(66, we);
    b(15, ze);
    b(16, Be);
    b(17, Be);
    b(18, Ce);
    b(19, De);
    b(20, Ee);
    b(21, Fe);
    b(22, Ge);
    b(23, He);
    b(24, Ie);
    b(25, Le);
    b(26, Me);
    b(27, Ne);
    b(28, Oe);
    b(29, Pe);
    b(45, Qe);
    b(30, Re);
    b(32, Se);
    b(33, Se);
    b(34, Te);
    b(35, Te);
    b(46, Ue);
    b(36, Ve);
    b(43, We);
    b(37, Xe);
    b(38, Ye);
    b(39, Ze);
    b(40, $e);
    b(44, kf);
    b(41, af);
    b(42, bf);
  };
  qf.prototype.Ud = function () {
    return this.H.Ud();
  };
  qf.prototype.Rb = function (a) {
    this.H.Rb(a);
  };
  qf.prototype.ud = function (a) {
    this.H.ud(a);
  };
  function sf(a) {
    if (
      a instanceof Va ||
      a instanceof Nd ||
      a instanceof Jd ||
      a instanceof nb ||
      a instanceof Ud ||
      a instanceof Sd ||
      a === null ||
      a === void 0 ||
      typeof a === "string" ||
      typeof a === "number" ||
      typeof a === "boolean"
    )
      return a;
  }
  var tf = function (a) {
    this.message = a;
  };
  function uf(a) {
    a.pu = !0;
    return a;
  }
  var vf = uf(function (a) {
      return typeof a === "number";
    }),
    wf = uf(function (a) {
      return typeof a === "string";
    }),
    xf = uf(function (a) {
      return typeof a === "boolean";
    });
  function yf(a) {
    var b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
      a
    ];
    return b === void 0
      ? new tf(
          "Value " + a + " can not be encoded in web-safe base64 dictionary."
        )
      : b;
  }
  function zf(a) {
    switch (a) {
      case 1:
        return "1";
      case 2:
      case 4:
        return "0";
      default:
        return "-";
    }
  }
  var Af = /^[1-9a-zA-Z_-][1-9a-c][1-9a-v]\d$/;
  function Bf(a, b) {
    for (var c = "", d = !0; a > 7; ) {
      var e = a & 31;
      a >>= 5;
      d ? (d = !1) : (e |= 32);
      c = "" + yf(e) + c;
    }
    a <<= 2;
    d || (a |= 32);
    return (c = "" + yf(a | b) + c);
  }
  function Cf(a, b) {
    return b === void 0 || b === 0 ? "" : "" + Bf(a, 1) + yf(b);
  }
  function Df(a, b) {
    var c;
    var d = a.bi,
      e = a.Kj;
    d === void 0
      ? (c = "")
      : (e || (e = 0), (c = "" + Bf(1, 1) + yf((d << 2) | e)));
    var f = "4" + c + Cf(2, a.jq),
      g,
      h = a.runtimeVersion;
    g = h && Af.test(h) ? "" + Bf(3, 2) + h : "";
    var k;
    var m = a.ctid;
    if (m && b) {
      var p = Bf(5, 3),
        q = m.split("-"),
        r = q[0].toUpperCase();
      if (r !== "GTM" && r !== "OPT") k = "";
      else {
        var t = q[1];
        k = "" + p + yf(1 + t.length) + (a.zr || 0) + t;
      }
    } else k = "";
    var u = a.canonicalId,
      v = a.Sb,
      x = a.zu,
      y =
        f +
        g +
        Cf(4, a.releaseExperiment) +
        k +
        Cf(6, a.xs) +
        (u ? "" + Bf(7, 3) + yf(u.length) + u : "") +
        (v ? "" + Bf(8, 3) + yf(v.length) + v : "") +
        (x ? "" + Bf(9, 3) + yf(x.length) + x : ""),
      B;
    var E = a.qq;
    E = E === void 0 ? {} : E;
    var F = [],
      G = n(Object.keys(E)),
      I = G.next();
    try {
      for (; !I.done; I = G.next()) {
        var J = I.value;
        F[Number(J)] = E[J];
      }
    } finally {
      z(G, I);
    }
    if (F.length) {
      var M = Bf(10, 3),
        U;
      if (F.length === 0) U = yf(0);
      else {
        for (var W = [], fa = 0, da = !1, ea = 0; ea < F.length; ea++) {
          da = !0;
          var ja = ea % 6;
          F[ea] && (fa |= 1 << ja);
          ja === 5 && (W.push(yf(fa)), (fa = 0), (da = !1));
        }
        da && W.push(yf(fa));
        U = W.join("");
      }
      var va = U;
      B = "" + M + yf(va.length) + va;
    } else B = "";
    var Ga = a.Kr,
      wa = a.Yr;
    return (
      y +
      B +
      (Ga ? "" + Bf(11, 3) + yf(Ga.length) + Ga : "") +
      (wa ? "" + Bf(13, 3) + yf(wa.length) + wa : "") +
      Cf(14, a.ys) +
      Cf(15, a.Uh) +
      Cf(16, a.xn)
    );
  }
  function Ef(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    return b;
  }
  function Ff(a, b) {
    for (var c = tb(b), d = new Uint8Array(c.length), e = 0; e < c.length; e++)
      d[e] = c.charCodeAt(e);
    if (d.length !== 32) throw Error("Key is not 32 bytes.");
    return Gf(a, d);
  }
  function Gf(a, b) {
    if (a === "") return "";
    var c = fc(a),
      d = b.slice(-2),
      e = [].concat(w(d), w(c)).map(function (g, h) {
        return g ^ b[h % b.length];
      }),
      f = new Uint8Array([].concat(w(e), w(d)));
    return sb(String.fromCharCode.apply(String, w(f))).replace(/\.+$/, "");
  }
  function Hf(a, b) {
    var c = {};
    c["function"] = "__" + a;
    for (var d in b) b.hasOwnProperty(d) && (c["vtp_" + d] = b[d]);
    return c;
  }
  function If(a, b) {
    b = b === void 0 ? !1 : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? !!data.blob[a]
      : b;
  }
  function H(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c, d;
    return (
      (c = data) == null ? 0 : (d = c.blob) == null ? 0 : d.hasOwnProperty(a)
    )
      ? String(data.blob[a])
      : b;
  }
  function Jf(a) {
    var b, c;
    return (
      (b = data) == null ? 0 : (c = b.blob) == null ? 0 : c.hasOwnProperty(a)
    )
      ? Number(data.blob[a])
      : 0;
  }
  function Kf(a) {
    var b;
    b = b === void 0 ? [] : b;
    var c,
      d,
      e = (c = data) == null ? void 0 : (d = c.blob) == null ? void 0 : d[a];
    return Array.isArray(e) ? e : b;
  }
  function Lf(a) {
    var b;
    b = b === void 0 ? "" : b;
    var c = Mf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? String(c[a]) : b;
  }
  function Nf(a, b) {
    var c = Mf(46);
    return c && (c == null ? 0 : c.hasOwnProperty(a)) ? Number(c[a]) : b;
  }
  function Mf(a) {
    var b, c;
    return (b = data) == null ? void 0 : (c = b.blob) == null ? void 0 : c[a];
  }
  var Of = function (a, b, c) {
    var d;
    d = Error.call(this, c);
    this.message = d.message;
    "stack" in d && (this.stack = d.stack);
    this.permissionId = a;
    this.parameters = b;
    this.name = "PermissionError";
  };
  ta(Of, Error);
  Of.prototype.getMessage = function () {
    return this.message;
  };
  function Pf(a, b) {
    if (Array.isArray(a)) {
      Object.defineProperty(a, "context", { value: { line: b[0] } });
      for (var c = 1; c < a.length; c++) Pf(a[c], b[c]);
    }
  }
  var Qf = function (a) {
    this.H = a;
  };
  Qf.prototype.K = function (a, b) {
    var c = Qa.apply(2, arguments);
    if (!this.H[a] || !this.H[a][b])
      throw new Of(
        b,
        {},
        "The requested permission " + b + " is not configured."
      );
    this.H[a][b].apply(this.H[a], [b].concat(w(c)));
  };
  function Rf() {
    return function (a, b) {
      var c;
      var d = Sf;
      a instanceof eb ? ((a.H = d), (c = a)) : (c = new eb(a, d));
      var e = c;
      b && e.K.push(b);
      throw e;
    };
  }
  function Sf(a) {
    if (!a.length) return a;
    a.push({ id: "main", line: 0 });
    for (var b = a.length - 1; b > 0; b--) Kb(a[b].id) && a.splice(b++, 1);
    for (var c = a.length - 1; c > 0; c--) a[c].line = a[c - 1].line;
    a.splice(0, 1);
    return a;
  }
  var Tf = RegExp("[^0-9\\.+-]", "g"),
    Uf = RegExp("[^0-9\\,+-]", "g"),
    Vf = RegExp("[^0-9+-]", "g");
  function Wf(a, b) {
    if (typeof a === "number") return a;
    var c = String(a),
      d;
    if (b === "AUTOMATIC") {
      var e = (c.match(/\./g) || []).length,
        f = (c.match(/,/g) || []).length,
        g = "NONE";
      if (e > 0 && f > 0) {
        var h = c.lastIndexOf(".") > c.lastIndexOf(",");
        h && e === 1 ? (g = "PERIOD") : h || f !== 1 || (g = "COMMA");
      } else
        e === 1
          ? (g =
              (c.split(".")[1].match(/[0-9]/g) || []).length !== 3
                ? "PERIOD"
                : "NONE")
          : f === 1 &&
            (g =
              (c.split(",")[1].match(/[0-9]/g) || []).length !== 3
                ? "COMMA"
                : "NONE");
      d = g;
    } else d = b === "COMMA" ? "COMMA" : "PERIOD";
    var k, m;
    d === "PERIOD"
      ? ((k = "."), (m = Tf))
      : d === "COMMA"
      ? ((k = ","), (m = Uf))
      : ((k = ""), (m = Vf));
    var p = c.replace(m, "");
    if (k !== "" && p.split(k).length > 2) return a;
    var q = p.replace(/,/g, ".");
    if (q === "") return a;
    var r = Number(q);
    return isNaN(r) ? a : r;
  }
  var Xf = function (a, b) {
      var c;
      c = c === void 0 ? {} : c;
      this.P = a;
      this.T = b;
      this.H = c;
    },
    Yf = function (a, b, c) {
      var d;
      (d = a.T)[b] != null || (d[b] = c);
    },
    Zf = function (a, b, c) {
      var d;
      (d = a.H)[b] != null || (d[b] = []);
      a.H[b].push(function () {
        return c.apply(null, w(Qa.apply(0, arguments)));
      });
    };
  Xf.prototype.K = function (a) {
    var b = this.H[a],
      c = this.H.all;
    if (b || c) {
      var d = (
        this.T[a] ||
        function () {
          return {};
        }
      ).apply(void 0, [a].concat(w(Qa.apply(1, arguments))));
      $f(b || [], this.P, a, d);
      $f(c || [], this.P, a, d);
    }
  };
  function $f(a, b, c, d) {
    var e = n(a),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) {
        var g = f.value,
          h = void 0,
          k = "A policy function denied the permission request";
        try {
          (h = g(b, c, d)), (k += ".");
        } catch (m) {
          k =
            typeof m === "string"
              ? k + (": " + m)
              : m instanceof Error
              ? k + (": " + m.message)
              : k + ".";
        }
        if (!h) throw new Of(c, d, k);
      }
    } finally {
      z(e, f);
    }
  }
  var bg = function (a, b, c) {
    this.da = c;
    this.K = {};
    this.T = new Set();
    var d = {},
      e = {},
      f = n(Object.entries(b)),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = n(g.value),
          k = h.next().value,
          m = h.next().value,
          p = k,
          q = m;
        d[p] = {};
        var r = n(Object.entries(q)),
          t = r.next();
        try {
          for (; !t.done; t = r.next()) {
            var u = n(t.value),
              v = u.next().value,
              x = u.next().value,
              y = v,
              B = ag(y, x, c),
              E = B.aa,
              F = B.cq;
            d[p][y] = B.assert;
            e[y] = E;
            this.T.add(y);
            F && (this.K[y] = F);
          }
        } finally {
          z(r, t);
        }
      }
    } finally {
      z(f, g);
    }
    this.H = new Xf(a, e);
    this.P = new Qf(d);
  };
  bg.prototype.ja = function (a) {
    var b = Qa.apply(1, arguments);
    if (!this.T.has(a) && this.da["__" + a]) {
      this.T.add(a);
      var c = ag(a, {}, this.da).aa;
      Yf(this.H, a, function () {
        var d = Qa.apply(0, arguments);
        try {
          return c.apply(null, w(d));
        } catch (e) {
          return {};
        }
      });
    }
    this.H.K.apply(this.H, [a].concat(w(b)));
  };
  bg.prototype.Z = function (a, b) {
    var c = Qa.apply(2, arguments),
      d = this;
    this.P.H[a]
      ? (this.P.K.apply(this.P, [a, b].concat(w(c))),
        this.H.K.apply(this.H, [b].concat(w(c))),
        this.K[b] &&
          this.K[b].apply(
            this.K,
            [
              function (e) {
                var f = Qa.apply(1, arguments),
                  g = d.P;
                if (!g.H[a] || !g.H[a][e])
                  throw cg(
                    e,
                    {},
                    "The requested additional permission " +
                      e +
                      " is not configured."
                  );
                d.H.K.apply(d.H, [e].concat(w(f)));
              },
            ].concat(w(c))
          ))
      : wb("TAGGING", 55);
  };
  function ag(a, b, c) {
    try {
      var d = c["__" + a];
      if (!d) throw Error("No function found for permission: " + a + ".");
      var e = Hf(a, b);
      e.vtp_permissionName = a;
      e.vtp_createPermissionError = cg;
      delete e["function"];
      return d(e);
    } catch (f) {
      return {
        assert: function (g) {
          throw new Of(g, {}, "Permission " + g + " is unknown.");
        },
        aa: function () {
          throw new Of(a, {}, "Permission " + a + " is unknown.");
        },
      };
    }
  }
  function cg(a, b, c) {
    return new Of(a, b, c);
  }
  function dg(a) {
    var b = 1,
      c,
      d,
      e;
    if (a)
      for (b = 0, d = a.length - 1; d >= 0; d--)
        (e = a.charCodeAt(d)),
          (b = ((b << 6) & 268435455) + e + (e << 14)),
          (c = b & 266338304),
          (b = c !== 0 ? b ^ (c >> 21) : b);
    return b;
  }
  var eg = function (a) {
    this.cache = a;
  };
  eg.prototype.get = function (a) {
    var b = dg(a),
      c = this.cache.get(b);
    if (!c) return { promise: void 0, uj: 0 };
    if (Date.now() >= c.timestamp + 9e5)
      return this.cache.delete(b), { promise: void 0, uj: 3 };
    var d = c.resolvedValue ? 2 : 1;
    return {
      promise: c.resolvedValue ? Promise.resolve(c.resolvedValue) : c.promise,
      uj: d,
    };
  };
  eg.prototype.set = function (a, b) {
    var c = dg(a),
      d = { promise: b, resolvedValue: void 0, timestamp: Date.now() };
    this.cache.set(c, d);
    b.then(function (e) {
      d.resolvedValue = e;
    });
  };
  function fg(a) {
    switch (a) {
      case 0:
        break;
      case 9:
        return "e4";
      case 6:
        return "e5";
      case 14:
        return "e6";
      default:
        return "e7";
    }
  }
  var K = {
    D: {
      Ra: "ad_personalization",
      ia: "ad_storage",
      ka: "ad_user_data",
      ua: "analytics_storage",
      rc: "region",
      na: "consent_updated",
      Tg: "wait_for_update",
      rf: "endpoint_type",
      Ln: "_&emfm",
      Nn: "app_remove",
      On: "app_store_refund",
      Pn: "app_store_subscription_cancel",
      Qn: "app_store_subscription_convert",
      Rn: "app_store_subscription_renew",
      Sn: "consent_update",
      Tn: "conversion",
      Bk: "add_payment_info",
      Ck: "add_shipping_info",
      tf: "add_to_cart",
      uf: "remove_from_cart",
      Dk: "view_cart",
      je: "begin_checkout",
      Zs: "generate_lead",
      vf: "select_item",
      vd: "view_item_list",
      ke: "select_promotion",
      wd: "view_promotion",
      Tb: "purchase",
      wf: "refund",
      Mc: "view_item",
      Ek: "add_to_wishlist",
      Un: "exception",
      Vn: "first_open",
      Wn: "first_visit",
      sa: "gtag.config",
      Kb: "gtag.get",
      Xn: "in_app_purchase",
      Nc: "page_view",
      Yn: "screen_view",
      Zn: "session_start",
      ao: "source_update",
      bo: "structured_data",
      co: "timing_complete",
      eo: "track_social",
      xf: "user_engagement",
      fo: "user_id_update",
      me: "braid_link_decoration_source",
      ne: "braid_storage_source",
      Oc: "gclid_link_decoration_source",
      Pc: "gclid_storage_source",
      Lb: "gclgb",
      Xa: "gclid",
      Fk: "gclid_len",
      oe: "gclgs",
      pe: "gcllp",
      qe: "gclst",
      lb: "ads_data_redaction",
      yf: "gad_source",
      zf: "gad_source_src",
      xd: "gclid_url",
      Gk: "gclsrc",
      ii: "gbraid",
      se: "wbraid",
      sc: "allow_ad_personalization_signals",
      ji: "allow_custom_scripts",
      Xg: "allow_display_features",
      ki: "allow_enhanced_conversions",
      Qc: "allow_google_signals",
      li: "allow_interest_groups",
      ho: "app_id",
      io: "app_installer_id",
      jo: "app_name",
      ko: "app_version",
      yd: "auid",
      bt: "auto_detection_enabled",
      Hk: "auto_event",
      Ik: "aw_remarketing",
      mi: "aw_remarketing_only",
      te: "discount",
      ue: "aw_feed_country",
      ve: "aw_feed_language",
      Ka: "items",
      we: "aw_merchant_id",
      ni: "aw_basket_type",
      xe: "campaign_content",
      ye: "campaign_id",
      ze: "campaign_medium",
      Ae: "campaign_name",
      Be: "campaign",
      Ce: "campaign_source",
      De: "campaign_term",
      Bb: "client_id",
      Jk: "rnd",
      oi: "consent_update_type",
      lo: "content_group",
      mo: "content_type",
      Af: "conversion_cookie_prefix",
      Bf: "conversion_id",
      Ub: "conversion_linker",
      Yg: "conversion_linker_disabled",
      Ee: "conversion_api",
      ri: "_&rcb",
      Zg: "cookie_deprecation",
      sb: "cookie_domain",
      tb: "cookie_expires",
      Cb: "cookie_flags",
      zd: "cookie_name",
      Mb: "cookie_path",
      Ya: "cookie_prefix",
      uc: "cookie_update",
      vc: "country",
      Za: "currency",
      Ad: "customer_lifetime_value",
      Cf: "customer_type",
      Fe: "custom_map",
      si: "gcldc_link_decoration_source",
      ui: "gcldc_storage_source",
      Df: "gcldc",
      Bd: "dclid",
      ah: "debug_mode",
      Na: "developer_id",
      no: "disable_merchant_reported_purchases",
      Sc: "dc_custom_params",
      oo: "dc_natural_search",
      po: "dynamic_event_settings",
      Kk: "affiliation",
      bh: "checkout_option",
      wi: "checkout_step",
      Lk: "coupon",
      Ef: "item_list_name",
      xi: "list_name",
      qo: "promotions",
      Tc: "shipping",
      Mk: "tax",
      eh: "engagement_time_msec",
      fh: "enhanced_client_id",
      ro: "enhanced_conversions",
      ct: "enhanced_conversions_automatic_settings",
      Cd: "estimated_delivery_date",
      Ff: "event_callback",
      so: "event_category",
      Dd: "event_developer_id_string",
      Ed: "event_id",
      gh: "_event_join_id",
      uo: "event_label",
      Vb: "event",
      Nk: "_&ae",
      yi: "event_settings",
      hh: "event_timeout",
      vo: "description",
      wo: "fatal",
      xo: "experiments",
      Ge: "ext_client_id",
      zi: "firebase_id",
      Gf: "first_party_collection",
      Hf: "_x_20",
      Wb: "_x_19",
      yo: "flight_error_code",
      zo: "flight_error_message",
      Ai: "fl_activity_category",
      Bi: "fl_activity_group",
      ih: "fl_advertiser_id",
      Ci: "match_id",
      Ok: "fl_random_number",
      Pk: "tran",
      Qk: "u",
      jh: "gac_gclid",
      He: "gac_wbraid",
      Rk: "gac_wbraid_multiple_conversions",
      Ao: "ga_restrict_domain",
      Sk: "ga_temp_client_id",
      Bo: "ga_temp_ecid",
      Ie: "gdpr_applies",
      kh: "_gt_metadata",
      Tk: "geo_granularity",
      If: "value_callback",
      Jf: "value_key",
      Sa: "google_analysis_params",
      Gd: "_google_ng",
      Uk: "_ono",
      Kf: "google_signals",
      Co: "google_tld",
      Lf: "gpp_sid",
      Mf: "gpp_string",
      Xb: "groups",
      Vk: "gsa_experiment_id",
      Nf: "gtag_event_feature_usage",
      Wk: "gtm_up",
      Je: "iframe_state",
      Vc: "ignore_referrer",
      Xk: "internal_traffic_results",
      Yk: "_is_fpm",
      wc: "is_legacy_converted",
      Wc: "is_legacy_loaded",
      Di: "is_passthrough",
      Of: "_lps",
      mb: "language",
      Ei: "legacy_developer_id_string",
      Db: "linker",
      Pf: "accept_incoming",
      Xc: "decorate_forms",
      Ca: "domains",
      Yc: "url_position",
      Hd: "merchant_feed_label",
      Id: "merchant_feed_language",
      Jd: "merchant_id",
      Zk: "method",
      Do: "name",
      bl: "navigation_type",
      Kd: "new_customer",
      Fi: "non_interaction",
      Eo: "optimize_id",
      fl: "_octid",
      il: "page_hostname",
      Ke: "page_path",
      Ea: "page_referrer",
      Eb: "page_title",
      Fo: "passengers",
      jl: "phone_conversion_callback",
      Go: "phone_conversion_country_code",
      kl: "phone_conversion_css_class",
      Ho: "phone_conversion_ids",
      ml: "phone_conversion_number",
      nl: "phone_conversion_options",
      Io: "_platinum_request_status",
      Jo: "_protected_audience_enabled",
      Qf: "quantity",
      mh: "redact_device_info",
      ol: "referral_exclusion_definition",
      et: "_request_start_time",
      ub: "restricted_data_processing",
      Ko: "retoken",
      Lo: "sample_rate",
      Gi: "screen_name",
      xc: "screen_resolution",
      pl: "_script_source",
      Mo: "search_term",
      yc: "send_page_view",
      Yb: "send_to",
      Hi: "server_container_3p_enrichment",
      Zb: "server_container_url",
      No: "session_attributes_encoded",
      nh: "session_duration",
      oh: "session_engaged",
      Ii: "session_engaged_time",
      ac: "session_id",
      ph: "session_number",
      Rf: "_shared_user_id",
      Zc: "delivery_postal_code",
      Ji: "_&sdl",
      Ki: "_&sdm",
      ft: "_tag_firing_delay",
      ht: "_tag_firing_time",
      jt: "temporary_client_id",
      ql: "testonly",
      Oo: "_timezone",
      Me: "topmost_url",
      qh: "tracking_id",
      rh: "traffic_type",
      La: "transaction_id",
      rl: "transaction_id_source",
      bc: "transport_url",
      Po: "trip_type",
      Ld: "update",
      Nb: "url_passthrough",
      sl: "uptgs",
      Sf: "_user_agent_architecture",
      Tf: "_user_agent_bitness",
      Uf: "_user_agent_full_version_list",
      Vf: "_user_agent_mobile",
      Wf: "_user_agent_model",
      Xf: "_user_agent_platform",
      Yf: "_user_agent_platform_version",
      Zf: "_user_agent_wow64",
      zc: "user_data",
      tl: "user_data_auto_latency",
      wl: "user_data_auto_meta",
      xl: "user_data_auto_multi",
      yl: "user_data_auto_selectors",
      zl: "user_data_auto_status",
      sh: "user_data_mode",
      Al: "user_data_settings",
      nb: "user_id",
      cg: "user_properties",
      Bl: "_user_region",
      dg: "us_privacy_string",
      Ta: "value",
      Cl: "wbraid_multiple_conversions",
      ad: "_fpm_parameters",
      fg: "_gtb",
      Pi: "_host_name",
      Ml: "_in_page_command",
      Ri: "_ip_override",
      Ql: "_is_passthrough_cid",
      Wi: "_measurement_type",
      Od: "non_personalized_ads",
      cj: "_sst_parameters",
      pp: "sgtm_geo_user_country",
      Rc: "conversion_label",
      ya: "page_location",
      Uc: "_extracted_data",
      Fd: "global_developer_id_string",
      Le: "tc_privacy_string",
    },
  };
  var L = {
    J: {
      ei: "accept_by_default",
      jk: "add_tag_timing",
      fi: "ads_consent_granted",
      he: "ads_event_page_view",
      Kc: "ads_page_view_params",
      qc: "allow_ad_personalization",
      Ms: "auto_event",
      lk: "batch_on_navigation",
      mk: "biscotti_join_id",
      pk: "client_id_source",
      Rg: "consent_event_id",
      Sg: "consent_priority_id",
      rk: "consent_state",
      na: "consent_updated",
      pf: "conversion_linker_enabled",
      Os: "conversion_marking_called",
      Ga: "cookie_options",
      yk: "dc_random",
      Ts: "dedupe_id",
      qf: "do_ec_unification",
      zk: "ec_event_join_id",
      ie: "ec_feature_mask",
      Lc: "em_event",
      Vs: "endpoint_for_debug",
      Ak: "enhanced_client_id_source",
      Ws: "enhanced_match_form_metadata",
      Xs: "enhanced_match_form_metadata_latency",
      Mn: "enhanced_match_result",
      Dl: "euid_logged_in_state",
      eg: "euid_mode_enabled",
      Qo: "event_provenance",
      nt: "event_source",
      Fb: "event_start_timestamp_ms",
      Ro: "event_usage",
      uh: "extra_tag_experiment_ids",
      eb: "fail_on_abort",
      st: "add_parameter",
      Ni: "counting_method",
      wh: "send_as_iframe",
      vt: "parameter_order",
      xh: "parsed_target",
      xt: "form_event_canceled",
      Vo: "ga4_collection_subdomain",
      Oi: "ga4_request_flags",
      Jl: "gbraid_cookie_marked",
      Ll: "gtm_extracted_data",
      Ac: "handle_internally",
      At: "has_ga_conversion_consents",
      HEADERS: "headers",
      fa: "hit_type",
      Md: "hit_type_override",
      Xo: "ignore_dupe_config",
      Ut: "is_config_command",
      yh: "is_consent_update",
      gg: "is_conversion",
      Nl: "is_ecommerce",
      Ol: "is_ec_cm_split",
      dd: "is_external_event",
      hg: "is_first_visit",
      Pl: "is_first_visit_conversion",
      Oe: "is_fpm_encryption",
      zh: "is_fpm_split",
      ab: "is_gcp_browser",
      Si: "is_google_measurement_allowed",
      Ti: "is_google_signals_enabled",
      Nd: "is_merchant_center",
      Ah: "is_new_to_site",
      Ui: "is_server_container_destination",
      Rl: "is_server_container_event",
      Pe: "is_session_start",
      Sl: "is_session_start_conversion",
      Vt: "is_sgtm_ga_ads_conversion_study_control_group",
      Wt: "is_sgtm_prehit",
      Tl: "is_sgtm_service_worker",
      ed: "is_split_conversion",
      Yo: "is_syn",
      ig: "is_test_event",
      jg: "join_id",
      Vi: "join_elapsed",
      kg: "join_timer_sec",
      Ul: "local_storage_aw_conversion_counters",
      Qe: "mav_updated",
      ep: "no_target_group",
      Zi: "pending_pv_claim",
      Pd: "tunnel_updated",
      Yt: "promises",
      Zt: "record_aw_latency",
      Se: "redact_ads_data",
      Qd: "redact_click_ids",
      Zl: "remarketing_only",
      am: "send_ccm_parallel_ping",
      Te: "send_doubleclick_join",
      Bh: "send_fpm_geo_join",
      Ch: "send_fpm_google_join",
      au: "send_ccm_parallel_test_ping",
      bm: "send_google_measurement",
      mg: "send_tld_join",
      ng: "send_to_destinations",
      bj: "send_to_targets",
      dm: "send_user_data_hit",
      Ue: "service_worker_context",
      Gb: "source_canonical_id",
      Oa: "speculative",
      fm: "speculative_in_message",
      Bc: "sd_updated",
      Eh: "suppressed_tag_experiment_ids",
      vp: "suppress_script_load",
      gm: "syn_or_mod",
      kj: "user_data_tr_ra",
      lj: "user_data_tr_rp",
      mj: "transient_ecsid",
      og: "transmission_type",
      Ua: "user_data",
      fu: "user_data_from_automatic",
      gu: "user_data_from_automatic_getter",
      im: "user_data_from_code",
      zp: "user_data_from_manual",
      hu: "user_data_mode",
      Rd: "user_id_updated",
    },
  };
  var ng = {},
    og =
      ((ng.uaa = !0),
      (ng.uab = !0),
      (ng.uafvl = !0),
      (ng.uamb = !0),
      (ng.uam = !0),
      (ng.uap = !0),
      (ng.uapv = !0),
      (ng.uaw = !0),
      ng);
  var tg = function (a, b) {
      for (var c = 0; c < b.length; c++) {
        var d = a,
          e = b[c];
        if (!rg.exec(e)) throw Error("Invalid key wildcard");
        var f = e.indexOf(".*"),
          g = f !== -1 && f === e.length - 2,
          h = g ? e.slice(0, e.length - 2) : e,
          k;
        a: if (d.length === 0) k = !1;
        else {
          for (var m = d.split("."), p = 0; p < m.length; p++)
            if (!sg.exec(m[p])) {
              k = !1;
              break a;
            }
          k = !0;
        }
        if (
          !k || h.length > d.length || (!g && d.length !== e.length)
            ? 0
            : g
            ? $b(d, h) && (d === h || d.charAt(h.length) === ".")
            : d === h
        )
          return !0;
      }
      return !1;
    },
    sg = /^[a-z$_][\w-$]*$/i,
    rg = /^(?:[a-z_$][a-z-_$0-9]*\.)*[a-z_$][a-z-_$0-9]*(?:\.\*)?$/i;
  var ug = [
    "matches",
    "webkitMatchesSelector",
    "mozMatchesSelector",
    "msMatchesSelector",
    "oMatchesSelector",
  ];
  function vg(a, b) {
    if (!a) return !1;
    try {
      for (var c = 0; c < ug.length; c++) {
        var d = ug[c];
        if (a[d] != null) return a[d](b);
      }
    } catch (e) {}
    return !1;
  }
  function wg(a, b) {
    var c = String(a),
      d = String(b),
      e = c.length - d.length;
    return e >= 0 && c.indexOf(d, e) === e;
  }
  function xg(a, b) {
    return String(a).split(",").indexOf(String(b)) >= 0;
  }
  function yg(a, b, c, d) {
    var e = c ? "i" : void 0;
    try {
      var f = String(b) + String(e),
        g = d == null ? void 0 : d.get(f);
      g || ((g = new RegExp(b, e)), d == null || d.set(f, g));
      return g.test(a);
    } catch (h) {
      return !1;
    }
  }
  function zg(a, b) {
    return String(a).indexOf(String(b)) >= 0;
  }
  function Ag(a, b) {
    return String(a) === String(b);
  }
  function Bg(a, b) {
    return Number(a) >= Number(b);
  }
  function Cg(a, b) {
    return Number(a) <= Number(b);
  }
  function Dg(a, b) {
    return Number(a) > Number(b);
  }
  function Eg(a, b) {
    return Number(a) < Number(b);
  }
  function Fg(a, b) {
    return $b(String(a), String(b));
  }
  function Mg(a) {
    var b = a.search;
    return (
      a.protocol +
      "//" +
      a.hostname +
      a.pathname +
      (b ? b + "&richsstsse" : "?richsstsse")
    );
  }
  var Ng = function () {
      this.T = "";
    },
    Pg = function (a, b) {
      return function () {
        var c = b.fallback_url,
          d = b.fallback_url_method;
        if (c && d) {
          var e = {};
          Og(a, ((e[d] = [c]), (e.options = {}), e));
        }
      };
    },
    Qg = function (a, b, c) {
      if (Array.isArray(a)) {
        var d = n(a),
          e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            var f = e.value;
            typeof f === "string" && c(f, b);
          }
        } finally {
          z(d, e);
        }
      }
    },
    Og = function (a, b) {
      if (b) {
        var c = Db(b.options) ? b.options : {},
          d = n(Object.keys(b)),
          e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            var f = e.value,
              g = b[f];
            switch (f) {
              case "send_pixel":
                Qg(g, c, function (h, k) {
                  return void a.K(h, k);
                });
                break;
              case "fetch":
                Qg(g, c, function (h, k) {
                  return void a.H(h, k);
                });
            }
          }
        } finally {
          z(d, e);
        }
      }
    };
  var Rg =
      /^([a-z][a-z0-9]*):(!|\?)(\*|string|boolean|number|Fn|PixieMap|List|OpaqueValue)$/i,
    Sg = { Fn: "function", PixieMap: "Object", List: "Array" };
  function Tg(a, b) {
    for (var c = ["input:!*"], d = 0; d < c.length; d++) {
      var e = Rg.exec(c[d]);
      if (!e) throw Error("Internal Error in " + a);
      var f = e[1],
        g = e[2] === "!",
        h = e[3],
        k = b[d];
      if (k == null) {
        if (g)
          throw Error(
            "Error in " + a + ". Required argument " + f + " not supplied."
          );
      } else if (h !== "*") {
        var m = typeof k;
        k instanceof Nd
          ? (m = "Fn")
          : k instanceof Jd
          ? (m = "List")
          : k instanceof nb
          ? (m = "PixieMap")
          : k instanceof Ud
          ? (m = "PixiePromise")
          : k instanceof Sd && (m = "OpaqueValue");
        if (m !== h)
          throw Error(
            "Error in " +
              a +
              ". Argument " +
              f +
              " has type " +
              ((Sg[m] || m) + ", which does not match required type ") +
              ((Sg[h] || h) + ".")
          );
      }
    }
  }
  function N(a, b, c) {
    var d = [],
      e = n(c),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) {
        var g = f.value;
        g instanceof Nd
          ? d.push("function")
          : g instanceof Jd
          ? d.push("Array")
          : g instanceof nb
          ? d.push("Object")
          : g instanceof Ud
          ? d.push("Promise")
          : g instanceof Sd
          ? d.push("OpaqueValue")
          : d.push(typeof g);
      }
    } finally {
      z(e, f);
    }
    return Error(
      "Argument error in " +
        a +
        ". Expected argument types [" +
        (b.join(",") + "], but received [") +
        (d.join(",") + "].")
    );
  }
  function Ug(a) {
    return a instanceof nb;
  }
  function Vg(a) {
    return Ug(a) || a === null || Wg(a);
  }
  function Xg(a) {
    return a instanceof Nd;
  }
  function Yg(a) {
    return Xg(a) || a === null || Wg(a);
  }
  function Zg(a) {
    return a instanceof Jd;
  }
  function $g(a) {
    return a instanceof Sd;
  }
  function ah(a) {
    return typeof a === "string";
  }
  function bh(a) {
    return ah(a) || a === null || Wg(a);
  }
  function ch(a) {
    return typeof a === "boolean";
  }
  function dh(a) {
    return ch(a) || Wg(a);
  }
  function eh(a) {
    return ch(a) || a === null || Wg(a);
  }
  function fh(a) {
    return typeof a === "number";
  }
  function Wg(a) {
    return a === void 0;
  }
  function gh(a) {
    return "" + a;
  }
  function hh(a, b) {
    var c = [];
    return c;
  }
  function ih(a, b) {
    var c = new Nd(a, function () {
      for (
        var d = Array.prototype.slice.call(arguments, 0), e = 0;
        e < d.length;
        e++
      )
        d[e] = this.evaluate(d[e]);
      try {
        return b.apply(this, d);
      } catch (g) {
        throw fb(g);
      }
    });
    c.Va();
    return c;
  }
  function jh(a, b) {
    var c = new nb(),
      d;
    for (d in b)
      if (b.hasOwnProperty(d)) {
        var e = b[d];
        Gb(e)
          ? c.set(d, ih(a + "_" + d, e))
          : Db(e)
          ? c.set(d, jh(a + "_" + d, e))
          : (Kb(e) || Hb(e) || typeof e === "boolean") && c.set(d, e);
      }
    c.Va();
    return c;
  }
  function kh(a, b) {
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    if (!bh(b)) throw N(this.getName(), ["string", "undefined"], arguments);
    var c = {},
      d = new nb();
    return (d = jh("AssertApiSubject", c));
  }
  function lh(a, b) {
    if (!bh(b)) throw N(this.getName(), ["string", "undefined"], arguments);
    if (a instanceof Ud)
      throw Error(
        "Argument actual cannot have type Promise. Assertions on asynchronous code aren't supported."
      );
    var c = {},
      d = new nb();
    return (d = jh("AssertThatSubject", c));
  }
  function mh(a) {
    return function () {
      for (
        var b = Qa.apply(0, arguments), c = [], d = this.V, e = 0;
        e < b.length;
        ++e
      )
        c.push(D(b[e], d));
      return Vd(a.apply(null, c));
    };
  }
  function nh() {
    for (var a = Math, b = oh, c = {}, d = 0; d < b.length; d++) {
      var e = b[d];
      a.hasOwnProperty(e) && (c[e] = mh(a[e].bind(a)));
    }
    return c;
  }
  function ph(a) {
    return a != null && $b(a, "__cvt_");
  }
  function qh(a) {
    var b;
    return b;
  }
  function rh(a) {
    var b;
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    var c;
    try {
      c = decodeURIComponent(a);
    } catch (d) {}
    b = c;
    return b;
  }
  function sh(a) {
    try {
      return encodeURI(a);
    } catch (b) {}
  }
  function th(a) {
    var b;
    a: {
      try {
        b = encodeURIComponent(String(a));
        break a;
      } catch (c) {}
      b = void 0;
    }
    return b;
  }
  function uh(a, b) {
    var c = !1;
    return c;
  }
  function Bh(a) {
    if (!bh(a)) throw N(this.getName(), ["string|undefined"], arguments);
  }
  function Ch(a) {
    var b = D(a);
    return dg(b ? "" + b : "");
  }
  function Dh(a, b) {
    if (!fh(a) || !fh(b))
      throw N(this.getName(), ["number", "number"], arguments);
    return Nb(a, b);
  }
  function Eh() {
    return new Date().getTime();
  }
  function Fh(a) {
    if (a === null) return "null";
    if (a instanceof Jd) return "array";
    if (a instanceof Nd) return "function";
    if (a instanceof Sd) {
      var b = a.getValue();
      if (
        (b == null ? void 0 : b.constructor) === void 0 ||
        b.constructor.name === void 0
      ) {
        var c = String(b);
        return c.substring(8, c.length - 1);
      }
      return String(b.constructor.name);
    }
    return typeof a;
  }
  function Gh(a) {
    function b(c) {
      return function (d) {
        try {
          return c(d);
        } catch (e) {
          (If(71) || If(29)) && a.call(this, e.message);
        }
      };
    }
    return {
      parse: b(function (c) {
        return Vd(JSON.parse(c));
      }),
      stringify: b(function (c) {
        return JSON.stringify(D(c));
      }),
      publicName: "JSON",
    };
  }
  function Hh(a) {
    return Rb(D(a, this.V));
  }
  function Ih(a) {
    return Number(D(a, this.V));
  }
  function Jh(a) {
    return a === null ? "null" : a === void 0 ? "undefined" : a.toString();
  }
  var Kh = [],
    Lh = {};
  function Mh(a) {
    return Kh[a] === void 0 ? !1 : Kh[a];
  }
  var Nh = new Set();
  Oh(2);
  Oh(13);
  Oh(435);

  function Oh(a) {
    Nh.add(a);
    var b;
    a: {
      switch (a) {
        case 400:
          b = 0;
          break a;
      }
      b = void 0;
    }
    var c = b;
    c !== void 0 && (Kh[c] = !0);
  }
  var Ph = {
      Gn: H(6),
      Jn: H(5),
      lp: H(15),
      mp: H(14),
      wp: H(12),
      xp: H(13),
      Ap: H(43),
      Bp: Nf(37, 10),
      Cp: Nf(38, 100),
      Dp: Nf(41, 6),
      Ep: Nf(39, 1382400),
      Fp: Nf(40, 15),
      Gp: Nh.has(13) ? 100 : Nf(42, 0),
      Hp: Nf(43, 60),
      Ip: Nf(44, 15e3),
      Jp: Nf(45, 0),
      Kp: Nf(46, 0),
      Lp: Nf(64, 2),
      Mp: Nf(72, 0),
      Np: Nf(65, 250),
      Op: Nf(47, 50),
      Pp: Nf(30, 432e5),
      Qp: Nf(48, 5e3),
      Rp: Nf(49, 15),
      Sp: Nf(50, 2e4),
      Tp: Nf(25, 0),
      Up: Nf(26, 0),
      Vp: Lf(23),
      Wp: Lf(22),
      Xp: Nf(51, 5e3),
      Yp: Nf(52, 20),
      VERSION: H(1),
    },
    Qh = {
      canonicalContainerId: Ph.Gn,
      ctid: Ph.Jn,
      yu: Ph.lp,
      runtimeVersion: Ph.mp,
      Au: Ph.wp,
      Bu: Ph.xp,
      Cu: Ph.Ap,
      Du: Ph.Bp,
      Eu: Ph.Cp,
      Fu: Ph.Dp,
      Gu: Ph.Ep,
      Hu: Ph.Fp,
      Iu: Ph.Gp,
      Ju: Ph.Hp,
      Ku: Ph.Ip,
      Lu: Ph.Jp,
      Mu: Ph.Kp,
      Nu: Ph.Lp,
      Ou: Ph.Mp,
      Pu: Ph.Np,
      Qu: Ph.Op,
      Ru: Ph.Pp,
      Su: Ph.Qp,
      Tu: Ph.Rp,
      Uu: Ph.Sp,
      Vu: Ph.Tp,
      Wu: Ph.Up,
      Xu: Ph.Vp,
      Yu: Ph.Wp,
      Is: Ph.Xp,
      Zu: Ph.Yp,
      version: Ph.VERSION,
    };
  ma(Object, "assign").call(Object, {}, Qh);
  function Rh(a, b, c, d) {
    var e = D(a),
      f = d > 0 ? Sh(e, d) : e,
      g = Vd(f);
    g.promise.then(c, function (k) {
      c();
      if (!g.Om) {
        var m = D(k, void 0, 1);
        m = m instanceof eb ? m.Qj.message : m instanceof Error ? m.message : m;
        b("error", "Unhandled rejection - " + JSON.stringify(m));
      }
    });
    var h = function (k) {
      var m = g.get(k);
      g.set(
        k,
        new Nd("", function (p, q) {
          var r = this.V.hb(),
            t = r.Js("25"),
            u = m.invoke(this.V, p, q);
          return Rh(u, r.log, t, d);
        })
      );
    };
    h("then");
    h("catch");
    h("finally");
    g.Va();
    return g;
  }
  function Sh(a, b) {
    var c,
      d = Promise.race([
        a,
        new Promise(function (e, f) {
          var g = setTimeout(function () {
            return void f({ reason: "promise_timed_out" });
          }, b);
          c = function () {
            clearTimeout(g);
            e();
          };
        }),
      ]);
    a.then(c, c);
    return d;
  }
  function Th(a, b, c) {
    var d;
    var r;
    var t = this.V;
    if (d instanceof Promise)
      if (t) {
        var u = t == null ? void 0 : t.hb(),
          v = u.log,
          x = u.Js("23"),
          y;
        y = y === void 0 ? Qh.Is : y;
        var B = Vd(d);
        r = Rh(B, v, x, y);
      } else r = Vd(d, t, 1);
    else r = Vd(d, t, 1);
    return r;
  }
  var oh = "floor ceil round max min abs pow sqrt".split(" ");
  function Uh() {
    var a = {};
    return {
      Lq: function (b) {
        return a.hasOwnProperty(b) ? a[b] : void 0;
      },
      vn: function (b, c) {
        a[b] = c;
      },
      reset: function () {
        a = {};
      },
    };
  }
  function Vh(a, b) {
    return function () {
      return Nd.prototype.invoke.apply(
        a,
        [b].concat(w(Qa.apply(0, arguments)))
      );
    };
  }
  function Wh(a, b) {
    if (!ah(a)) throw N(this.getName(), ["string", "any"], arguments);
  }
  function Xh(a, b) {
    if (!ah(a) || !Ug(b))
      throw N(this.getName(), ["string", "PixieMap"], arguments);
  }
  var Yh = {};
  Yh.keys = function (a) {
    return new Jd();
  };
  Yh.values = function (a) {
    return new Jd();
  };
  Yh.entries = function (a) {
    return new Jd();
  };
  Yh.freeze = function (a) {
    return a;
  };
  Yh.delete = function (a, b) {
    return !1;
  };
  function O(a, b) {
    var c = Qa.apply(2, arguments),
      d = a.V.hb();
    if (!d) throw Error("Missing program state.");
    if (d.Zh) {
      try {
        d.qm.apply(null, [b].concat(w(c)));
      } catch (e) {
        throw (wb("TAGGING", 21), e);
      }
      return;
    }
    d.qm.apply(null, [b].concat(w(c)));
  }
  var $h = function () {
    this.K = {};
    this.H = {};
    this.P = !0;
  };
  $h.prototype.get = function (a, b) {
    var c = this.contains(a) ? this.K[a] : void 0;
    return c;
  };
  $h.prototype.contains = function (a) {
    return this.K.hasOwnProperty(a);
  };
  $h.prototype.add = function (a, b, c) {
    if (this.contains(a))
      throw Error(
        "Attempting to add a function which already exists: " + a + "."
      );
    if (this.H.hasOwnProperty(a))
      throw Error(
        "Attempting to add an API with an existing private API name: " + a + "."
      );
    this.K[a] = c ? void 0 : Gb(b) ? ih(a, b) : jh(a, b);
  };
  function ai(a, b) {
    var c = void 0;
    return c;
  }
  function bi() {
    var a = {};
    return a;
  }
  var ci = {},
    di =
      ((ci[K.D.na] = "gcu"),
      (ci[K.D.rf] = "ept"),
      (ci[K.D.Lb] = "gclgb"),
      (ci[K.D.Xa] = "gclaw"),
      (ci[K.D.Fk] = "gclid_len"),
      (ci[K.D.oe] = "gclgs"),
      (ci[K.D.pe] = "gcllp"),
      (ci[K.D.qe] = "gclst"),
      (ci[K.D.yd] = "auid"),
      (ci[K.D.Hk] = "ae"),
      (ci[K.D.te] = "dscnt"),
      (ci[K.D.ue] = "fcntr"),
      (ci[K.D.ve] = "flng"),
      (ci[K.D.we] = "mid"),
      (ci[K.D.ni] = "bttype"),
      (ci[K.D.Bb] = "gacid"),
      (ci[K.D.Rc] = "label"),
      (ci[K.D.Ee] = "capi"),
      (ci[K.D.Zg] = "pscdl"),
      (ci[K.D.Za] = "currency_code"),
      (ci[K.D.Ad] = "vdltv"),
      (ci[K.D.Cf] = "cloct"),
      (ci[K.D.ah] = "_dbg"),
      (ci[K.D.Cd] = "oedeld"),
      (ci[K.D.Dd] = "edid"),
      (ci[K.D.Ed] = "evnid"),
      (ci[K.D.gh] = "evjid"),
      (ci[K.D.Ge] = "excid"),
      (ci[K.D.jh] = "gac"),
      (ci[K.D.He] = "gacgb"),
      (ci[K.D.Rk] = "gacmcov"),
      (ci[K.D.Ie] = "gdpr"),
      (ci[K.D.Fd] = "gdid"),
      (ci[K.D.Gd] = "_ng"),
      (ci[K.D.Uk] = "_ono"),
      (ci[K.D.Lf] = "gpp_sid"),
      (ci[K.D.Mf] = "gpp"),
      (ci[K.D.Vk] = "gsaexp"),
      (ci[K.D.Nf] = "_tu"),
      (ci[K.D.Je] = "frm"),
      (ci[K.D.Di] = "gtm_up"),
      (ci[K.D.Of] = "lps"),
      (ci[K.D.Ei] = "did"),
      (ci[K.D.Hd] = "fcntr"),
      (ci[K.D.Id] = "flng"),
      (ci[K.D.Jd] = "mid"),
      (ci[K.D.Kd] = void 0),
      (ci[K.D.fl] = "octid"),
      (ci[K.D.Eb] = "tiba"),
      (ci[K.D.ub] = "rdp"),
      (ci[K.D.ac] = "ecsid"),
      (ci[K.D.Rf] = "ga_uid"),
      (ci[K.D.Zc] = "delopc"),
      (ci[K.D.Le] = "gdpr_consent"),
      (ci[K.D.La] = "oid"),
      (ci[K.D.rl] = "oidsrc"),
      (ci[K.D.sl] = "uptgs"),
      (ci[K.D.Sf] = "uaa"),
      (ci[K.D.Tf] = "uab"),
      (ci[K.D.Uf] = "uafvl"),
      (ci[K.D.Vf] = "uamb"),
      (ci[K.D.Wf] = "uam"),
      (ci[K.D.Xf] = "uap"),
      (ci[K.D.Yf] = "uapv"),
      (ci[K.D.Zf] = "uaw"),
      (ci[K.D.tl] = "ec_lat"),
      (ci[K.D.wl] = "ec_meta"),
      (ci[K.D.xl] = "ec_m"),
      (ci[K.D.yl] = "ec_sel"),
      (ci[K.D.zl] = "ec_s"),
      (ci[K.D.sh] = "ec_mode"),
      (ci[K.D.nb] = "userId"),
      (ci[K.D.dg] = "us_privacy"),
      (ci[K.D.Ta] = "value"),
      (ci[K.D.Cl] = "mcov"),
      (ci[K.D.fg] = "gtb"),
      (ci[K.D.Pi] = "hn"),
      (ci[K.D.Ml] = "gtm_ee"),
      (ci[K.D.Ri] = "uip"),
      (ci[K.D.Wi] = "mt"),
      (ci[K.D.Od] = "npa"),
      (ci[K.D.pp] = "sg_uc"),
      (ci[K.D.Bf] = null),
      (ci[K.D.xc] = null),
      (ci[K.D.mb] = null),
      (ci[K.D.Ka] = null),
      (ci[K.D.ya] = null),
      (ci[K.D.Ea] = null),
      (ci[K.D.Me] = null),
      (ci[K.D.ad] = null),
      (ci[K.D.kh] = null),
      (ci[K.D.Oc] = null),
      (ci[K.D.Pc] = null),
      (ci[K.D.me] = null),
      (ci[K.D.ne] = null),
      (ci[K.D.Sa] = null),
      (ci[K.D.Uc] = null),
      ci);
  function ei(a, b) {
    if (a) {
      var c = a.split("x");
      c.length === 2 && (fi(b, "u_w", c[0]), fi(b, "u_h", c[1]));
    }
  }
  function gi(a) {
    var b = hi;
    b = b === void 0 ? ii : b;
    return ji(ki(a, b));
  }
  function ji(a) {
    return (a || [])
      .filter(function (b) {
        return !!b;
      })
      .map(function (b) {
        return (
          "(" +
          [
            li(b.value),
            li(b.quantity),
            li(b.item_id),
            li(b.start_date),
            li(b.end_date),
          ].join("*") +
          ")"
        );
      })
      .join("");
  }
  function ki(a, b) {
    return (a || [])
      .filter(function (c) {
        return !!c;
      })
      .map(function (c) {
        return {
          item_id: b(c),
          quantity: c.quantity,
          value: c.price,
          start_date: c.start_date,
          end_date: c.end_date,
        };
      });
  }
  function ii(a) {
    return [a.item_id, a.id, a.item_name].find(function (b) {
      return b != null;
    });
  }
  function mi(a) {
    if (a && a.length)
      return a
        .map(function (b) {
          return b && b.estimated_delivery_date
            ? b.estimated_delivery_date
            : "";
        })
        .join(",");
  }
  function fi(a, b, c) {
    c === void 0 || c === null || (c === "" && !og[b]) || (a[b] = c);
  }
  function li(a) {
    return typeof a !== "number" && typeof a !== "string" ? "" : a.toString();
  }
  function ni() {
    this.blockSize = -1;
  }
  function oi(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.P = Sa.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.T = this.K = 0;
    this.H = [];
    this.da = a;
    this.Z = b;
    this.ja = Sa.Int32Array ? new Int32Array(64) : Array(64);
    pi === void 0 && (Sa.Int32Array ? (pi = new Int32Array(qi)) : (pi = qi));
    this.reset();
  }
  Ta(oi, ni);
  for (var ri = [], si = 0; si < 63; si++) ri[si] = 0;
  var ti = [].concat(128, ri);
  oi.prototype.reset = function () {
    this.T = this.K = 0;
    var a;
    if (Sa.Int32Array) a = new Int32Array(this.Z);
    else {
      var b = this.Z,
        c = b.length;
      if (c > 0) {
        for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
        a = d;
      } else a = [];
    }
    this.H = a;
  };
  var ui = function (a) {
    for (var b = a.P, c = a.ja, d = 0, e = 0; e < b.length; )
      (c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4);
    for (var f = 16; f < 64; f++) {
      var g = c[f - 15] | 0,
        h = c[f - 2] | 0;
      c[f] =
        ((((c[f - 16] | 0) +
          (((g >>> 7) | (g << 25)) ^ ((g >>> 18) | (g << 14)) ^ (g >>> 3))) |
          0) +
          (((c[f - 7] | 0) +
            (((h >>> 17) | (h << 15)) ^
              ((h >>> 19) | (h << 13)) ^
              (h >>> 10))) |
            0)) |
        0;
    }
    for (
      var k = a.H[0] | 0,
        m = a.H[1] | 0,
        p = a.H[2] | 0,
        q = a.H[3] | 0,
        r = a.H[4] | 0,
        t = a.H[5] | 0,
        u = a.H[6] | 0,
        v = a.H[7] | 0,
        x = 0;
      x < 64;
      x++
    ) {
      var y =
          ((((k >>> 2) | (k << 30)) ^
            ((k >>> 13) | (k << 19)) ^
            ((k >>> 22) | (k << 10))) +
            ((k & m) ^ (k & p) ^ (m & p))) |
          0,
        B =
          (((v +
            (((r >>> 6) | (r << 26)) ^
              ((r >>> 11) | (r << 21)) ^
              ((r >>> 25) | (r << 7)))) |
            0) +
            ((((((r & t) ^ (~r & u)) + (pi[x] | 0)) | 0) + (c[x] | 0)) | 0)) |
          0;
      v = u;
      u = t;
      t = r;
      r = (q + B) | 0;
      q = p;
      p = m;
      m = k;
      k = (B + y) | 0;
    }
    a.H[0] = (a.H[0] + k) | 0;
    a.H[1] = (a.H[1] + m) | 0;
    a.H[2] = (a.H[2] + p) | 0;
    a.H[3] = (a.H[3] + q) | 0;
    a.H[4] = (a.H[4] + r) | 0;
    a.H[5] = (a.H[5] + t) | 0;
    a.H[6] = (a.H[6] + u) | 0;
    a.H[7] = (a.H[7] + v) | 0;
  };
  oi.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.K;
    if (typeof a === "string")
      for (; c < b; )
        (this.P[d++] = a.charCodeAt(c++)),
          d == this.blockSize && (ui(this), (d = 0));
    else {
      var e,
        f = typeof a;
      e = f != "object" ? f : a ? (Array.isArray(a) ? "array" : f) : "null";
      if (e == "array" || (e == "object" && typeof a.length == "number"))
        for (; c < b; ) {
          var g = a[c++];
          if (!("number" == typeof g && 0 <= g && 255 >= g && g == (g | 0)))
            throw Error("message must be a byte array");
          this.P[d++] = g;
          d == this.blockSize && (ui(this), (d = 0));
        }
      else throw Error("message must be string or array");
    }
    this.K = d;
    this.T += b;
  };
  oi.prototype.digest = function () {
    var a = [],
      b = this.T * 8;
    this.K < 56
      ? this.update(ti, 56 - this.K)
      : this.update(ti, this.blockSize - (this.K - 56));
    for (var c = 63; c >= 56; c--) (this.P[c] = b & 255), (b /= 256);
    ui(this);
    for (var d = 0, e = 0; e < this.da; e++)
      for (var f = 24; f >= 0; f -= 8) a[d++] = (this.H[e] >> f) & 255;
    return a;
  };
  var qi = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    pi;
  function vi() {
    oi.call(this, 8, wi);
  }
  Ta(vi, oi);
  var wi = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var xi = /^[0-9A-Fa-f]{64}$/;
  function yi(a) {
    try {
      return new TextEncoder().encode(a);
    } catch (b) {
      return fc(a);
    }
  }
  function zi(a) {
    var b = A;
    if (a === "" || a === "e0") return Promise.resolve(a);
    var c;
    if ((c = b.crypto) == null ? 0 : c.subtle) {
      if (xi.test(a)) return Promise.resolve(a);
      try {
        var d = yi(a);
        return b.crypto.subtle
          .digest("SHA-256", d)
          .then(function (e) {
            return Ai(e, b);
          })
          .catch(function () {
            return "e2";
          });
      } catch (e) {
        return Promise.resolve("e2");
      }
    } else return Promise.resolve("e1");
  }
  function Bi(a) {
    try {
      var b = new vi();
      b.update(yi(a));
      return b.digest();
    } catch (c) {
      return "e2";
    }
  }
  function Ci(a) {
    var b = A;
    if (a === "" || a === "e0" || xi.test(a)) return a;
    var c = Bi(a);
    if (c === "e2") return "e2";
    try {
      return Ai(c, b);
    } catch (d) {
      return "e2";
    }
  }
  function Ai(a, b) {
    var c = Array.from(new Uint8Array(a))
      .map(function (d) {
        return String.fromCharCode(d);
      })
      .join("");
    return b.btoa(c).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function Di() {
    for (var a = !1, b = !1, c = 0; a === b; )
      if (((a = Nb(0, 1) === 0), (b = Nb(0, 1) === 0), c++, c > 30)) return;
    return a;
  }
  var Fi = {
      Zj: function (a, b, c) {
        return Ei.Zj(a, b, c);
      },
    },
    Gi = function () {
      this.studies = {};
      this.H = Di;
    };
  Gi.prototype.Zj = function (a, b, c) {
    var d = this.studies[b];
    if (
      !(
        (c === void 0 ? Nb(0, 9999) : c % 1e4) <
        d.probability * (d.controlId2 ? 4 : 2) * 1e4
      )
    )
      return a;
    a: {
      var e = d.studyId,
        f = d.experimentId,
        g = d.controlId,
        h = d.controlId2;
      if (!((a.exp || {})[f] || (a.exp || {})[g] || (h && (a.exp || {})[h]))) {
        var k = c !== void 0 ? c % 2 === 0 : this.H();
        if (k !== void 0) {
          var m = k ? 0 : 1;
          if (h) {
            var p = c !== void 0 ? (c >> 1) % 2 === 0 : this.H();
            if (p === void 0) break a;
            m |= (p ? 0 : 1) << 1;
          }
          m === 0
            ? Hi(a, f, e)
            : m === 1
            ? Hi(a, g, e)
            : m === 2 && Hi(a, h, e);
        }
      }
    }
    return a;
  };
  var Ji = function (a, b) {
      var c = Ei;
      return c.studies[b]
        ? Ii(c, b) || !!(a.exp || {})[c.studies[b].experimentId]
        : !1;
    },
    Ki = function (a, b) {
      var c = Ei;
      return c.studies[b] && c.studies[b].controlId && !Ii(c, b)
        ? !!(a.exp || {})[c.studies[b].controlId]
        : !1;
    },
    Li = function (a, b) {
      var c = Ei;
      return c.studies[b] && c.studies[b].controlId2 && !Ii(c, b)
        ? !!(a.exp || {})[c.studies[b].controlId2]
        : !1;
    },
    Mi = function (a, b) {
      var c = (a == null ? void 0 : a.exp) || {},
        d = n(Object.keys(c).map(Number)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = e.value;
          if (c[f] === b) return f;
        }
      } finally {
        z(d, e);
      }
    },
    Ii = function (a, b) {
      return !!a.studies[b].active || a.studies[b].probability > 0.5;
    },
    Hi = function (a, b, c) {
      var d = a.exp || {};
      d[b] = c;
      a.exp = d;
    },
    Ei = new Gi();
  var Ni = function (a) {
      switch (a) {
        case 400:
          return 0;
        case 491:
          return 7;
        case 480:
          return 6;
        case 421:
          return 5;
        case 561:
          return 10;
        case 570:
          return 11;
        case 495:
          return 8;
        case 514:
          return 9;
        case 53:
          return 1;
        case 54:
          return 2;
        case 52:
          return 3;
      }
    },
    Oi = function (a, b) {
      a.P.add(b);
      var c = Ni(b);
      c !== void 0 && (Kh[c] = !0);
    },
    P = function (a) {
      return Pi.P.has(a);
    },
    Pi = new (function () {
      this.P = new Set();
      this.K = new Set();
      this.H = new Set();
      Oi(this, 132);
      var a = Nf(69, 1776448920);
      Lh[1] = a;
      Oi(this, 435);
      Oi(this, 603);
      Oi(this, 639);
    })();
  function Vi(a, b) {
    var c = (b == null ? void 0 : b.Xe) !== !1;
    return Object.keys(a)
      .map(function (d) {
        var e = a[d];
        if (e != null) {
          if (e === "") {
            var f;
            if (
              !(typeof (b == null ? void 0 : b.Ve) === "boolean"
                ? b.Ve
                : b == null
                ? 0
                : (f = b.Ve) == null
                ? 0
                : f[d])
            )
              return;
          }
          e =
            e === !0
              ? "1"
              : e === !1
              ? "0"
              : c
              ? encodeURIComponent(String(e))
              : String(e);
          return d + "=" + e;
        }
      })
      .filter(function (d) {
        return !!d;
      })
      .join("&");
  }
  var Wi = function () {
    this.storage = $a();
  };
  Wi.prototype.set = function (a, b) {
    this.storage.set(String(a), b);
  };
  Wi.prototype.get = function (a) {
    return this.storage.get(String(a));
  };
  var Xi;
  function Yi(a, b) {
    Xi || (Xi = new Wi());
    Xi.set(a, b);
  }
  function Zi(a) {
    Xi || (Xi = new Wi());
    return Xi.get(a);
  }
  function $i(a, b) {
    Xi || (Xi = new Wi());
    var c = Xi;
    c.storage.has(String(a)) || c.storage.set(String(a), b());
    return c.storage.get(String(a));
  }
  var aj = {},
    bj =
      ((aj.tdp = 1),
      (aj.exp = 1),
      (aj.gtm = 1),
      (aj.pid = 1),
      (aj.dl = 1),
      (aj.seq = 1),
      (aj.t = 1),
      (aj.v = 1),
      aj),
    dj = function () {
      var a = cj;
      return Object.keys(a.H).filter(function (b) {
        return a.H[b];
      });
    },
    ej = function (a, b, c) {
      if (a.H[b] === void 0 || (c === void 0 ? 0 : c)) a.H[b] = !0;
    },
    fj = function (a) {
      var b = cj;
      a.forEach(function (c) {
        bj[c] || (b.H[c] = !1);
      });
    },
    cj = new (function () {
      this.H = {};
      this.K = {};
    })();
  function gj(a, b, c) {
    var d = c === void 0 ? !0 : c,
      e = cj;
    d = d === void 0 ? !0 : d;
    e.K[a] = b;
    d && ej(e, a);
  }
  var hj = function () {
      this.H = new Set();
      this.K = new Set();
    },
    jj = function (a) {
      var b = ij.H;
      a = a === void 0 ? [] : a;
      var c = []
        .concat(w(b.H))
        .concat([].concat(w(b.K)))
        .concat(a);
      c.sort(function (d, e) {
        return d - e;
      });
      return c;
    },
    kj = function () {
      var a = [].concat(w(ij.H.H));
      a.sort(function (b, c) {
        return b - c;
      });
      return a;
    },
    mj = function () {
      var a = ij.H,
        b = H(44);
      a.H = new Set();
      lj(a, b);
    },
    lj = function (a, b) {
      b && nj(a, b.split("~"));
    },
    nj = function (a, b) {
      if (b) {
        var c = n(b),
          d = c.next();
        try {
          for (; !d.done; d = c.next()) {
            var e = d.value.trim();
            if (e !== "") {
              var f = Number(e);
              isNaN(f) || a.H.add(f);
            }
          }
        } finally {
          z(c, d);
        }
      }
    };
  var oj = {},
    pj = {
      __cl: 1,
      __ecl: 1,
      __ehl: 1,
      __evl: 1,
      __fal: 1,
      __fil: 1,
      __fsl: 1,
      __hl: 1,
      __jel: 1,
      __lcl: 1,
      __sdl: 1,
      __tl: 1,
      __ytl: 1,
    },
    qj = ma(Object, "assign").call(Object, {}, { __paused: 1, __tg: 1 }, pj),
    rj,
    sj = !1;
  rj = sj;
  var tj = "";
  oj.dj = tj;
  var ij = new (function () {
    this.H = new hj();
  })();
  var uj = /:[0-9]+$/,
    vj = /^\d+\.fls\.doubleclick\.net$/;
  function wj(a, b, c, d) {
    var e = xj(a, !!d, b),
      f,
      g;
    return c
      ? (g = e[b]) != null
        ? g
        : []
      : (f = e[b]) == null
      ? void 0
      : f[0];
  }
  function xj(a, b, c) {
    var d = {},
      e = n(a.split("&")),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) {
        var g = n(f.value.split("=")),
          h = g.next().value,
          k = xa(g),
          m = decodeURIComponent(h.replace(/\+/g, " "));
        if (c === void 0 || m === c) {
          var p = k.join("=");
          d[m] || (d[m] = []);
          d[m].push(b ? p : decodeURIComponent(p.replace(/\+/g, " ")));
        }
      }
    } finally {
      z(e, f);
    }
    return d;
  }
  function yj(a) {
    try {
      return decodeURIComponent(a);
    } catch (b) {}
  }
  function zj(a, b, c, d, e) {
    b && (b = String(b).toLowerCase());
    if (b === "protocol" || b === "port")
      a.protocol = Aj(a.protocol) || Aj(A.location.protocol);
    b === "port"
      ? (a.port = String(
          Number(a.hostname ? a.port : A.location.port) ||
            (a.protocol === "http" ? 80 : a.protocol === "https" ? 443 : "")
        ))
      : b === "host" &&
        (a.hostname = (a.hostname || A.location.hostname)
          .replace(uj, "")
          .toLowerCase());
    return Bj(a, b, c, d, e);
  }
  function Bj(a, b, c, d, e) {
    var f,
      g = Aj(a.protocol);
    b && (b = String(b).toLowerCase());
    switch (b) {
      case "url_no_fragment":
        f = Cj(a);
        break;
      case "protocol":
        f = g;
        break;
      case "host":
        f = a.hostname.replace(uj, "").toLowerCase();
        if (c) {
          var h = /^www\d*\./.exec(f);
          h && h[0] && (f = f.substring(h[0].length));
        }
        break;
      case "port":
        f = String(
          Number(a.port) || (g === "http" ? 80 : g === "https" ? 443 : "")
        );
        break;
      case "path":
        a.pathname || a.hostname || wb("TAGGING", 1);
        f = a.pathname.substring(0, 1) === "/" ? a.pathname : "/" + a.pathname;
        var k = f.split("/");
        (d || []).indexOf(k[k.length - 1]) >= 0 && (k[k.length - 1] = "");
        f = k.join("/");
        break;
      case "query":
        f = a.search.replace("?", "");
        e && (f = wj(f, e, !1));
        break;
      case "extension":
        var m = a.pathname.split(".");
        f = m.length > 1 ? m[m.length - 1] : "";
        f = f.split("/")[0];
        break;
      case "fragment":
        f = a.hash.replace("#", "");
        break;
      default:
        f = a && a.href;
    }
    return f;
  }
  function Aj(a) {
    return a ? a.replace(":", "").toLowerCase() : "";
  }
  function Cj(a) {
    var b = "";
    if (a && a.href) {
      var c = a.href.indexOf("#");
      b = c < 0 ? a.href : a.href.substring(0, c);
    }
    return b;
  }
  var Dj = {},
    Ej = 0;
  function Fj(a) {
    var b = Dj[a];
    if (!b) {
      var c = C.createElement("a");
      a && (c.href = a);
      var d = c.pathname;
      d[0] !== "/" && (a || wb("TAGGING", 1), (d = "/" + d));
      var e = c.hostname.replace(uj, "");
      b = {
        href: c.href,
        protocol: c.protocol,
        host: c.host,
        hostname: e,
        pathname: d,
        search: c.search,
        hash: c.hash,
        port: c.port,
      };
      Ej < 5 && ((Dj[a] = b), Ej++);
    }
    return b;
  }
  function Gj(a, b, c) {
    var d = Fj(a);
    return ic(b, d, c);
  }
  function Hj(a) {
    var b = Fj(A.location.href),
      c = zj(b, "host", !1);
    if (c && c.match(vj)) {
      var d = zj(b, "path");
      if (d) {
        var e = d.split(a + "=");
        if (e.length > 1) return e[1].split(";")[0].split("?")[0];
      }
    }
  }
  var Ij = {
      "https://www.google.com": "/g",
      "https://www.googleadservices.com": "/as",
      "https://pagead2.googlesyndication.com": "/gs",
    },
    Jj = [
      "/as/d/ccm/conversion",
      "/g/d/ccm/conversion",
      "/gs/ccm/conversion",
      "/d/ccm/form-data",
    ],
    Kj = "/gtm.js /gtm/js /gtag.js /gtag/js /gtag/destination /gtd".split(" ");
  function Lj() {
    return If(47) ? Jf(54) !== 1 : !1;
  }
  function Mj() {
    var a = H(18),
      b = a.length;
    return a[b - 1] === "/" ? a.substring(0, b - 1) : a;
  }
  function Nj(a, b) {
    if (a) {
      var c = "" + a;
      c.indexOf("http://") !== 0 &&
        c.indexOf("https://") !== 0 &&
        (c = "https://" + c);
      c[c.length - 1] === "/" && (c = c.substring(0, c.length - 1));
      return Fj("" + c + b).href;
    }
  }
  function Oj(a) {
    if (Pj()) return Nj(a, "/analytics.js");
  }
  function Qj(a) {
    return a === 2 || a === 3;
  }
  function Rj(a) {
    return P(588) && a === 3;
  }
  function Pj() {
    return Lj() || If(50);
  }
  function Sj() {
    return !!oj.dj && oj.dj.split("@@").join("") !== "SGTM_TOKEN";
  }
  function Tj(a) {
    var b = n([K.D.Zb, K.D.bc]),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = Q(a, c.value);
        if (d) return d;
      }
    } finally {
      z(b, c);
    }
  }
  function Uj(a, b, c) {
    c = c === void 0 ? "" : c;
    if (!Lj()) return a;
    var d = b ? Ij[a] || "" : "";
    d === "/gs" && (c = "");
    return "" + Mj() + d + c;
  }
  function Vj(a) {
    if (Lj()) {
      var b = n(Jj),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) {
          var d = c.value;
          if ($b(a, "" + Mj() + d)) return "::";
        }
      } finally {
        z(b, c);
      }
    }
  }
  function Wj() {
    var a = A;
    if (!a) return !1;
    try {
      if (a === a.top) return !1;
      var b = a.location.pathname;
      return b.indexOf("/_/service_worker/") !== -1 && ac(b, "/sw_iframe.html");
    } catch (c) {
      return !1;
    }
  }
  function Xj() {
    if (If(47)) {
      var a = Mj();
      if (a && Uc) {
        var b = Fj(Uc),
          c = b.pathname;
        if ($b(c, a + "/"))
          return { zn: c.substring(a.length), search: b.search };
      }
    }
  }
  function Yj() {
    var a = Xj();
    return !!a && Kj.indexOf(a.zn) !== -1;
  }
  function Zj() {
    var a = Xj();
    return !!a && a.zn === "/" && !!wj(a.search.substring(1), "id", !1);
  }
  function ak(a, b, c) {
    var d = "https://" + a + b;
    return c
      ? function () {
          return Lj() ? Mj() + c + b : d;
        }
      : function () {
          return d;
        };
  }
  var bk = {},
    ck =
      ((bk[22] = ak("www.googleadservices.com", "/ccm/conversion", "/as/d")),
      (bk[60] = ak("pagead2.googlesyndication.com", "/ccm/conversion", "/gs")),
      (bk[23] = ak("www.google.com", "/ccm/conversion", "/g/d")),
      bk);
  var dk = {},
    ek =
      ((dk[5] = ak("www.googleadservices.com", "/pagead/conversion")),
      (dk[6] = ak(
        "pagead2.googlesyndication.com",
        "/pagead/conversion",
        "/gs"
      )),
      (dk[8] = ak("www.google.com", "/pagead/1p-conversion")),
      (dk[66] = ak("www.google.com", "/pagead/uconversion")),
      (dk[63] = ak("www.googleadservices.com", "/pagead/conversion")),
      (dk[64] = ak(
        "pagead2.googlesyndication.com",
        "/pagead/conversion",
        "/gs"
      )),
      (dk[65] = ak("www.google.com", "/pagead/1p-conversion")),
      (dk[76] = ak("www.google.com", "/measurement/enhanced", "/d")),
      (dk[74] = function () {
        return Mj() + "/as/p/c";
      }),
      dk);
  var fk = {},
    gk =
      ((fk[45] = ak("www.google.com", "/ccm/collect")),
      (fk[46] = ak("pagead2.googlesyndication.com", "/ccm/collect", "/gs")),
      (fk[69] = ak("ad.doubleclick.net", "/ccm/s/collect")),
      (fk[58] = ak("www.google.com", "/pagead/set_partitioned_cookie")),
      (fk[57] = ak(
        "www.googleadservices.com",
        "/pagead/set_partitioned_cookie"
      )),
      fk);
  var hk = {},
    ik =
      ((hk[9] = ak(
        "googleads.g.doubleclick.net",
        "/pagead/viewthroughconversion"
      )),
      (hk[68] = ak("www.google.com", "/rmkt/collect")),
      hk);
  var jk = {},
    kk =
      ((jk[11] = ak("www.google.com", "/pagead/form-data", "/d")),
      (jk[21] = ak("www.google.com", "/ccm/form-data", "/d")),
      (jk[72] = ak("google.com", "/pagead/form-data", "/d")),
      (jk[73] = ak("google.com", "/ccm/form-data", "/d")),
      jk);
  var lk = {},
    mk =
      ((lk[51] = ak("www.google.com", "/travel/flights/click/conversion")), lk);
  var nk = {},
    ok =
      ((nk[1] = function () {
        return "https://ad.doubleclick.net/activity;";
      }),
      (nk[2] = function () {
        return (
          (Lj() ? Mj() : "https://ade.googlesyndication.com") +
          "/ddm/activity" +
          (P(467) ? ";" : "/")
        );
      }),
      (nk[3] = function (a) {
        return "https://" + a.fq + ".fls.doubleclick.net/activityi;";
      }),
      (nk[77] = function () {
        return "https://www.google.com/gmp/conversion;";
      }),
      nk);
  function pk(a) {
    wb("HEALTH", a);
  }
  function R(a) {
    wb("GTM", a);
  }
  var qk = {
    ba: {
      Ls: "aw_user_data_cache",
      Vg: "cookie_deprecation_label",
      Wg: "diagnostics_page_id",
      Kn: "ememo",
      Ys: "em_registry",
      Li: "eab",
      wt: "fl_user_data_cache",
      zt: "ga4_user_data_cache",
      Rt: "idc_pv_claim",
      Ne: "ip_geo_data_cache",
      Qi: "ip_geo_fetch_in_progress",
      lg: "mtt_study_state",
      Vl: "nb_data",
      hp: "page_experiment_ids",
      Wl: "pld",
      Re: "pt_data",
      Xl: "pt_listener_set",
      aj: "retry_containers",
      Dh: "service_worker_endpoint",
      qp: "shared_user_id",
      rp: "shared_user_id_requested",
      ej: "shared_user_id_source",
      bu: "awh",
      up: "sds",
      yp: "universal_claim_registry",
    },
  };
  var rk = (function (a) {
    return uf(function (b) {
      for (var c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  })(qk.ba);
  function sk(a, b) {
    b = b === void 0 ? !1 : b;
    if (rk(a)) {
      var c,
        d,
        e =
          (d = (c = Vc("google_tag_data", {})).xcd) != null ? d : (c.xcd = {});
      if (e[a]) return e[a];
      if (b) {
        var f = void 0,
          g = 1,
          h = {},
          k = {
            set: function (m) {
              f = m;
              k.notify();
            },
            get: function () {
              return f;
            },
            subscribe: function (m) {
              h[String(g)] = m;
              return g++;
            },
            unsubscribe: function (m) {
              var p = String(m);
              return h.hasOwnProperty(p) ? (delete h[p], !0) : !1;
            },
            notify: function () {
              var m = n(Object.keys(h)),
                p = m.next();
              try {
                for (; !p.done; p = m.next()) {
                  var q = p.value;
                  try {
                    h[q](a, f);
                  } catch (r) {}
                }
              } finally {
                z(m, p);
              }
            },
          };
        return (e[a] = k);
      }
    }
  }
  function tk(a, b) {
    var c = sk(a, !0);
    c && c.set(b);
  }
  function uk(a) {
    var b;
    return (b = sk(a)) == null ? void 0 : b.get();
  }
  function vk(a, b) {
    var c = sk(a, !0);
    if (c) return c.get() === void 0 && c.set(b), c.get();
  }
  function wk(a, b) {
    if (typeof b === "function") {
      var c;
      return (c = sk(a, !0)) == null ? void 0 : c.subscribe(b);
    }
  }
  function xk(a, b) {
    var c = sk(a);
    return c ? c.unsubscribe(b) : !1;
  }
  function yk(a) {
    if (rk(a)) {
      var b;
      (b = sk(a)) == null || b.notify();
    }
  }
  var zk = function () {
    this.H = {};
    this.K = !1;
  };
  zk.prototype.bind = function () {
    this.K ||
      ((this.H = Ak()), this.H["0"] && vk(qk.ba.Ne, JSON.stringify(this.H)));
  };
  var Ek = function () {
      var a = Bk,
        b = Ck,
        c = void 0,
        d = function () {
          c !== void 0 && xk(qk.ba.Ne, c);
          try {
            var f = uk(qk.ba.Ne);
            b.H = JSON.parse(f);
          } catch (g) {
            R(123), pk(2), (b.H = {});
          }
          b.K = !0;
          a();
        },
        e = uk(qk.ba.Ne);
      e ? d(e) : ((c = wk(qk.ba.Ne, d)), Dk());
    },
    Dk = function () {
      if (!uk(qk.ba.Qi)) {
        tk(qk.ba.Qi, !0);
        var a = function (b) {
          tk(qk.ba.Ne, b || "{}");
          tk(qk.ba.Qi, !1);
        };
        try {
          A.fetch("https://www.google.com/ccm/geo", {
            method: "GET",
            cache: "no-store",
            mode: "cors",
            credentials: "omit",
          }).then(
            function (b) {
              b.ok
                ? b.text().then(
                    function (c) {
                      a(c);
                    },
                    function () {
                      a();
                    }
                  )
                : a();
            },
            function () {
              a();
            }
          );
        } catch (b) {
          a();
        }
      }
    },
    Ak = function () {
      var a = H(22);
      try {
        return JSON.parse(tb(a));
      } catch (b) {
        return R(123), pk(2), {};
      }
    },
    Fk = function () {
      return Ck.H["0"] || "";
    },
    Gk = function () {
      return Ck.H["1"] || "";
    },
    Hk = function () {
      var a = Ck,
        b = !1;
      return b;
    },
    Ik = function () {
      return Ck.H["6"] !== !1;
    },
    Jk = function () {
      return Ck.H["9"] !== !1;
    },
    Kk = function () {
      var a = Ck,
        b = "";
      return b;
    },
    Lk = function () {
      var a = Ck,
        b = "";
      return b;
    },
    Ck = new zk();
  function Mk(a) {
    a = a === void 0 ? "g/collect" : a;
    return "https://" + (Kk() || "www") + ".google-analytics.com/" + a;
  }
  function Nk(a) {
    a = a === void 0 ? "g/collect" : a;
    var b = Kk();
    return "https://" + (b ? b + "." : "") + "analytics.google.com/" + a;
  }
  var Ok = {},
    Pk =
      ((Ok[17] = function () {
        return Lj() && !Kk() ? Mj() + "/ag/g/c" : Nk();
      }),
      (Ok[16] = function () {
        return Lj() && !Kk() ? Mj() + "/ga/g/c" : Mk();
      }),
      (Ok[67] = function () {
        var a;
        a = a === void 0 ? "g/collect" : a;
        return Kk() ? "" : "https://www.google.com/" + a;
      }),
      Ok);
  function Qk(a, b, c) {
    var d = ak(b, "/measurement/conversion", c);
    return function () {
      return Kk() ? a("measurement/conversion") : d();
    };
  }
  var Rk = {},
    Sk =
      ((Rk[55] = Qk(Mk, "pagead2.googlesyndication.com", "/gs")),
      (Rk[54] = Qk(Nk, "www.google.com", "/g")),
      Rk);
  function Tk(a) {
    return function () {
      return "" + (Lj() ? Mj() : "https://" + H(21)) + a;
    };
  }
  var Uk = {},
    Vk = ((Uk[61] = Tk("/td")), (Uk[56] = Tk("/a")), Uk);
  var Wk = ma(Object, "assign").call(
    Object,
    {},
    ck,
    ek,
    gk,
    ik,
    kk,
    mk,
    ok,
    Sk,
    Pk,
    Vk
  );
  function Xk(a) {
    var b = 0;
    a.Cc.forEach(function (c) {
      b |= 1 << c;
    });
    return b;
  }
  function Yk() {
    return { total: 0, jb: 0, Cc: new Set(), ff: {} };
  }
  function Zk(a, b, c, d) {
    var e = Object.keys(a.hf)
      .sort(function (f, g) {
        return Number(f) - Number(g);
      })
      .map(function (f) {
        return [f, b(a.hf[f])];
      })
      .filter(function (f) {
        return f[1] !== void 0;
      })
      .map(function (f) {
        return f.join(c);
      })
      .join(d);
    return e ? e : void 0;
  }
  function $k(a, b) {
    var c, d, e;
    c = c === void 0 ? "_" : c;
    d = d === void 0 ? ";" : d;
    e = e === void 0 ? "~" : e;
    var f = [],
      g = n(Object.keys(a.ff).sort()),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = h.value,
          m = Zk(a.ff[k], b, c, d);
        if (m) {
          var p = void 0;
          f.push("" + ((p = k) != null ? p : "") + d + m);
        }
      }
    } finally {
      z(g, h);
    }
    return f.length ? f.join(e) : void 0;
  }
  function al(a) {
    a.jb = 0;
    a.Cc.clear();
    var b = n(Object.keys(a.ff)),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = a.ff[c.value];
        d.jb = 0;
        d.Cc.clear();
        var e = n(Object.keys(d.hf)),
          f = e.next();
        try {
          for (; !f.done; f = e.next()) {
            var g = d.hf[f.value];
            g.jb = 0;
            g.Cc.clear();
          }
        } finally {
          z(e, f);
        }
      }
    } finally {
      z(b, c);
    }
  }
  function bl(a, b, c, d, e) {
    d = d === void 0 ? 1 : d;
    a.total += d;
    a.jb += d;
    var f,
      g = b === void 0 ? "" : b;
    f = a.ff[g] || (a.ff[g] = { total: 0, jb: 0, Cc: new Set(), hf: {} });
    f.total += d;
    f.jb += d;
    var h,
      k = String(c);
    h = f.hf[k] || (f.hf[k] = { total: 0, jb: 0, Cc: new Set() });
    h.total += d;
    h.jb += d;
    e !== void 0 && (a.Cc.add(e), f.Cc.add(e), h.Cc.add(e));
  }
  var cl = function () {
    this.H = Yk();
  };
  cl.prototype.increment = function (a, b) {
    bl(this.H, a, b);
  };
  var dl = new cl();
  function el(a) {
    var b = String(a["function"] || "").replace(/_/g, "");
    return $b(b, "cvt") ? "cvt" : b;
  }
  var fl =
    A.location.search.indexOf("?gtm_latency=") >= 0 ||
    A.location.search.indexOf("&gtm_latency=") >= 0;
  var hl = function () {
      var a = gl;
      return P(603) && If(65, !1) && !a.Z;
    },
    gl = new (function (a) {
      this.T = a();
      var b = Jf(27);
      this.P = fl || this.T < b;
      var c = Jf(42);
      this.Z = fl || this.T >= 1 - c;
      var d = P(603) && If(65, !1);
      this.K = this.Z || d;
      var e = Jf(27),
        f = Jf(63);
      this.H = fl || f === 1 || (this.T >= e && this.T < e + f);
    })(function () {
      return Math.random();
    });
  var il = function () {
    this.H = {};
  };
  il.prototype.register = function (a, b, c) {
    if (gl.K) {
      var d = jl(b, c);
      if (d) {
        var e,
          f = b;
        f === 4 && (f = 5);
        var g = this.H[f];
        g || (g = this.H[f] = {});
        e = g;
        var h = e[d];
        h || (h = e[d] = []);
        h.push(ma(Object, "assign").call(Object, {}, a));
        dl.increment(a.destinationId, a.endpoint);
        a.endpoint !== 56 && a.endpoint !== 61 && ej(cj, "mde", !0);
      }
    }
  };
  var ml = function (a, b) {
      var c = kl,
        d = jl(a, b);
      if (d) {
        var e = ll(c, a);
        if (e) {
          var f = e[d];
          f &&
            (e[d] = f.filter(function (g) {
              return !g.qn;
            }));
        }
      }
    },
    ll = function (a, b) {
      b === 4 && (b = 5);
      return a.H[b];
    },
    jl = function (a, b) {
      var c = b;
      if (b[0] === "/") {
        var d;
        c = ((d = A.location) == null ? void 0 : d.origin) + b;
      }
      try {
        var e = new URL(c);
        return a === 2 ? e.origin : e.origin + e.pathname;
      } catch (f) {}
    },
    kl = new il();
  function nl(a) {
    switch (a) {
      case "script-src":
        return 4;
      case "script-src-elem":
        return 5;
      case "frame-src":
        return 2;
      case "connect-src":
        return 1;
      case "img-src":
        return 3;
    }
  }
  function ol(a, b, c) {
    var d,
      e = a.GooglebQhCsO;
    e || ((e = {}), (a.GooglebQhCsO = e));
    d = e;
    if (d[b]) return !1;
    d[b] = [];
    d[b][0] = c;
    return !0;
  }
  var pl, ql;
  a: {
    for (var rl = ["CLOSURE_FLAGS"], sl = Sa, tl = 0; tl < rl.length; tl++)
      if (((sl = sl[rl[tl]]), sl == null)) {
        ql = null;
        break a;
      }
    ql = sl;
  }
  var ul = ql && ql[610401301];
  pl = ul != null ? ul : !1;
  function vl() {
    var a = Sa.navigator;
    if (a) {
      var b = a.userAgent;
      if (b) return b;
    }
    return "";
  }
  var wl,
    xl = Sa.navigator;
  wl = xl ? xl.userAgentData || null : null;
  function yl(a) {
    if (!pl || !wl) return !1;
    for (var b = 0; b < wl.brands.length; b++) {
      var c = wl.brands[b].brand;
      if (c && c.indexOf(a) != -1) return !0;
    }
    return !1;
  }
  function zl(a) {
    return vl().indexOf(a) != -1;
  }
  function Al() {
    return pl ? !!wl && wl.brands.length > 0 : !1;
  }
  function Bl() {
    return Al() ? !1 : zl("Opera");
  }
  function Cl() {
    return zl("Firefox") || zl("FxiOS");
  }
  function Dl() {
    return Al()
      ? yl("Chromium")
      : ((zl("Chrome") || zl("CriOS")) && !(Al() ? 0 : zl("Edge"))) ||
          zl("Silk");
  }
  function El() {
    return pl ? !!wl && !!wl.platform : !1;
  }
  function Fl() {
    return zl("iPhone") && !zl("iPod") && !zl("iPad");
  }
  function Gl() {
    Fl() || zl("iPad") || zl("iPod");
  }
  var Hl = function (a) {
    Hl[" "](a);
    return a;
  };
  Hl[" "] = function () {};
  Bl();
  Al() || zl("Trident") || zl("MSIE");
  zl("Edge");
  !zl("Gecko") ||
    (vl().toLowerCase().indexOf("webkit") != -1 && !zl("Edge")) ||
    zl("Trident") ||
    zl("MSIE") ||
    zl("Edge");
  vl().toLowerCase().indexOf("webkit") != -1 && !zl("Edge") && zl("Mobile");
  El() || zl("Macintosh");
  El() || zl("Windows");
  (El() ? wl.platform === "Linux" : zl("Linux")) || El() || zl("CrOS");
  El() || zl("Android");
  Fl();
  zl("iPad");
  zl("iPod");
  Gl();
  vl().toLowerCase().indexOf("kaios");
  Cl();
  Fl() || zl("iPod");
  zl("iPad");
  !zl("Android") || Dl() || Cl() || Bl() || zl("Silk");
  Dl();
  !zl("Safari") ||
    Dl() ||
    (Al() ? 0 : zl("Coast")) ||
    Bl() ||
    (Al() ? 0 : zl("Edge")) ||
    (Al() ? yl("Microsoft Edge") : zl("Edg/")) ||
    (Al() ? yl("Opera") : zl("OPR")) ||
    Cl() ||
    zl("Silk") ||
    zl("Android") ||
    Gl();
  var Il = {},
    Jl = null;
  function Kl(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e > 255 && ((b[c++] = e & 255), (e >>= 8));
      b[c++] = e;
    }
    var f = 4;
    f === void 0 && (f = 0);
    if (!Jl) {
      Jl = {};
      for (
        var g =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          h = ["+/=", "+/", "-_=", "-_.", "-_"],
          k = 0;
        k < 5;
        k++
      ) {
        var m = g.concat(h[k].split(""));
        Il[k] = m;
        for (var p = 0; p < m.length; p++) {
          var q = m[p];
          Jl[q] === void 0 && (Jl[q] = p);
        }
      }
    }
    for (
      var r = Il[f],
        t = Array(Math.floor(b.length / 3)),
        u = r[64] || "",
        v = 0,
        x = 0;
      v < b.length - 2;
      v += 3
    ) {
      var y = b[v],
        B = b[v + 1],
        E = b[v + 2],
        F = r[y >> 2],
        G = r[((y & 3) << 4) | (B >> 4)],
        I = r[((B & 15) << 2) | (E >> 6)],
        J = r[E & 63];
      t[x++] = "" + F + G + I + J;
    }
    var M = 0,
      U = u;
    switch (b.length - v) {
      case 2:
        (M = b[v + 1]), (U = r[(M & 15) << 2] || u);
      case 1:
        var W = b[v];
        t[x] = "" + r[W >> 2] + r[((W & 3) << 4) | (M >> 4)] + U + u;
    }
    return t.join("");
  }
  var Ll = function (a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  };
  var Ml = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Nl(a, b, c, d) {
    for (var e = b, f = c.length; (e = a.indexOf(c, e)) >= 0 && e < d; ) {
      var g = a.charCodeAt(e - 1);
      if (g == 38 || g == 63) {
        var h = a.charCodeAt(e + f);
        if (!h || h == 61 || h == 38 || h == 35) return e;
      }
      e += f + 1;
    }
    return -1;
  }
  var Ol = /#|$/;
  function Pl(a, b) {
    var c = a.search(Ol),
      d = Nl(a, 0, b, c);
    if (d < 0) return null;
    var e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return Ll(a.slice(d, e !== -1 ? e : 0));
  }
  var Ql = /[?&]($|#)/;
  function Rl(a, b, c) {
    for (var d, e = a.search(Ol), f = 0, g, h = []; (g = Nl(a, f, b, e)) >= 0; )
      h.push(a.substring(f, g)), (f = Math.min(a.indexOf("&", g) + 1 || e, e));
    h.push(a.slice(f));
    d = h.join("").replace(Ql, "$1");
    var k,
      m = c != null ? "=" + encodeURIComponent(String(c)) : "";
    var p = b + m;
    if (p) {
      var q,
        r = d.indexOf("#");
      r < 0 && (r = d.length);
      var t = d.indexOf("?"),
        u;
      t < 0 || t > r ? ((t = r), (u = "")) : (u = d.substring(t + 1, r));
      q = [d.slice(0, t), u, d.slice(r)];
      var v = q[1];
      q[1] = p ? (v ? v + "&" + p : p) : v;
      k = q[0] + (q[1] ? "?" + q[1] : "") + q[2];
    } else k = d;
    return k;
  }
  function Sl(a, b, c, d, e, f, g) {
    var h = Pl(c, "fmt");
    if (d) {
      var k = Pl(c, "random"),
        m = Pl(c, "label") || "";
      if (!k) return;
      var p = Kl(Ll(m) + ":" + Ll(k));
      if (!ol(a, p, d)) return;
    }
    h && Number(h) !== 4
      ? ((c = Rl(c, "rfmt", h)), (c = Rl(c, "fmt", 4)))
      : h || (c = Rl(c, "fmt", 4));
    dd(
      c,
      function () {
        g == null || Tl(g, c);
        a.google_noFurtherRedirects &&
          d &&
          ((a.google_noFurtherRedirects = null), d());
      },
      function () {
        g == null || Tl(g, c);
        e == null || e();
      },
      f,
      b.getElementsByTagName("script")[0].parentElement || void 0
    );
    return c;
  }
  function Ul(a) {
    var b = Qa.apply(1, arguments);
    kl.register(a, 1, b[0]);
    rd.apply(null, w(b));
  }
  function Vl(a) {
    var b = Qa.apply(1, arguments);
    kl.register(a, 1, b[0]);
    sd.apply(null, w(b));
  }
  function Wl(a) {
    var b = Qa.apply(1, arguments);
    kl.register(a, 3, b[0]);
    hd.apply(null, w(b));
  }
  function Xl(a) {
    var b = Qa.apply(1, arguments);
    kl.register(a, 1, b[0]);
    return vd.apply(null, w(b));
  }
  function Yl(a) {
    var b = Qa.apply(1, arguments);
    kl.register(a, 5, b[0]);
    dd.apply(null, w(b));
  }
  function Zl(a) {
    var b = Qa.apply(1, arguments);
    b[0] && kl.register(a, 2, b[0]);
    gd.apply(null, w(b));
  }
  function $l(a) {
    var b = Sl.apply(null, w(Qa.apply(1, arguments)));
    b && kl.register(a, 4, b);
    return b;
  }
  var am = /gtag[.\/]js/,
    bm = /gtm[.\/]js/,
    dm = function (a) {
      var b = cm;
      if ((a.scriptContainerId || "").indexOf("GTM-") >= 0) {
        var c;
        a: {
          var d,
            e = (d = a.scriptElement) == null ? void 0 : d.src;
          if (e) {
            for (
              var f = If(47),
                g = Fj(e),
                h = f ? g.pathname : "" + g.hostname + g.pathname,
                k = C.scripts,
                m = "",
                p = 0;
              p < k.length;
              ++p
            ) {
              var q = k[p];
              if (
                !(
                  q.innerHTML.length === 0 ||
                  (!f &&
                    q.innerHTML.indexOf(
                      a.scriptContainerId || "SHOULD_NOT_BE_SET"
                    ) < 0) ||
                  q.innerHTML.indexOf(h) < 0
                )
              ) {
                if (q.innerHTML.indexOf("(function(w,d,s,l,i)") >= 0) {
                  c = String(p);
                  break a;
                }
                m = String(p);
              }
            }
            if (m) {
              c = m;
              break a;
            }
          }
          c = void 0;
        }
        var r = c;
        if (r) return (b.H = !0), r;
      }
      var t = [].slice.call(C.scripts);
      return a.scriptElement ? String(t.indexOf(a.scriptElement)) : "-1";
    },
    em = function (a) {
      if (cm.H) return "1";
      var b,
        c = (b = a.scriptElement) == null ? void 0 : b.src;
      if (c) {
        if (am.test(c)) return "3";
        if (bm.test(c)) return "2";
      }
      return "0";
    },
    cm = new (function () {
      this.H = !1;
    })();
  function fm(a) {
    var b = gm().destinationArray[a],
      c = gm().destination[a];
    return b && b.length > 0 ? b[0] : c;
  }
  function hm(a, b) {
    var c = gm();
    Mb(c.pending, function (d) {
      return (
        d.target.ctid === a.ctid && d.target.isDestination === a.isDestination
      );
    }) || c.pending.push({ target: a, onLoad: b });
  }
  var im = function (a) {
    this.container = {};
    this.destination = {};
    this.destinationArray = {};
    this.canonical = {};
    this.pending = [];
    this.injectedFirstPartyContainers = {};
    if (a) {
      var b = !1;
      (a.destinationArray && a.destination) || (b = !0);
      if (b)
        (this.container = a.container),
          (this.canonical = a.canonical),
          (this.pending = a.pending),
          (this.injectedFirstPartyContainers = a.injectedFirstPartyContainers),
          (this.destination = a.destination || {}),
          (this.destinationArray = a.destinationArray || {});
      else return a;
    } else {
      var c = A.google_tags_first_party;
      Array.isArray(c) || (c = []);
      var d = {},
        e = n(c),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) d[f.value] = !0;
      } finally {
        z(e, f);
      }
      this.injectedFirstPartyContainers = Object.freeze(d);
    }
  };
  function gm() {
    var a = Vc("google_tag_data", {}),
      b = a.tidr;
    if (b) return new im(b);
    (b && typeof b === "object") || ((b = new im()), (a.tidr = b));
    return b;
  }
  function jm() {
    return (
      If(7) &&
      km().some(function (a) {
        return a === H(5);
      })
    );
  }
  function lm() {
    var a;
    return (a = Kf(55)) != null ? a : [];
  }
  function mm() {
    return H(6) || "_" + H(5);
  }
  function nm() {
    var a = H(10);
    return a ? a.split("|") : [H(5)];
  }
  function km() {
    var a = Kf(59);
    return Array.isArray(a)
      ? a
          .filter(function (b) {
            return typeof b === "string";
          })
          .filter(function (b) {
            return b.indexOf("GTM-") !== 0;
          })
      : [];
  }
  function om() {
    var a = pm(qm()),
      b = a && a.parent;
    if (b) return pm(b);
  }
  function rm() {
    var a = pm(qm());
    if (a) {
      for (; a.parent; ) {
        var b = pm(a.parent);
        if (!b) break;
        a = b;
      }
      return a;
    }
  }
  function pm(a) {
    var b = gm();
    return a.isDestination ? fm(a.ctid) : b.container[a.ctid];
  }
  function sm() {
    for (
      var a = gm(), b, c = [], d = !1, e = nm(), f = km(), g = {}, h = 0;
      h < a.pending.length;
      g = { Kg: void 0 }, h++
    )
      (g.Kg = a.pending[h]),
        Mb(
          g.Kg.target.isDestination ? f : e,
          (function (k) {
            return function (m) {
              return m === k.Kg.target.ctid;
            };
          })(g)
        )
          ? d || ((b = g.Kg.onLoad), (d = !0))
          : c.push(g.Kg);
    a.pending = c;
    if (b)
      try {
        b(mm());
      } catch (k) {}
  }
  function tm() {
    var a = H(5),
      b = nm(),
      c = km(),
      d = lm(),
      e = function (q, r) {
        var t = {
          canonicalContainerId: H(6),
          scriptContainerId: a,
          state: 2,
          containers: b.slice(),
          destinations: c.slice(),
        };
        Sc && (t.scriptElement = Sc);
        Uc && (t.scriptSource = Uc);
        om() === void 0 &&
          ((t.htmlLoadOrder = dm(t)), (t.loadScriptType = em(t)));
        var u, v;
        switch (r) {
          case 0:
            u = function (B) {
              f.container[q] = B;
            };
            v = f.container[q];
            break;
          case 1:
            u = function (B) {
              f.destinationArray[q] = f.destinationArray[q] || [];
              f.destinationArray[q].unshift(B);
            };
            var x,
              y =
                ((x = f.destinationArray[q]) == null ? void 0 : x[0]) ||
                f.destination[q];
            !y || (y.state !== 0 && y.state !== 1) || (v = y);
            break;
          case 2:
            (u = function (B) {
              f.destinationArray[q] = f.destinationArray[q] || [];
              f.destinationArray[q].push(B);
            }),
              (v = void 0);
        }
        u &&
          (v
            ? (v.state === 0 && R(93), ma(Object, "assign").call(Object, v, t))
            : u(t));
      },
      f = gm(),
      g = n(b),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) e(h.value, 0);
    } finally {
      z(g, h);
    }
    var k = n(c),
      m = k.next();
    try {
      for (; !m.done; m = k.next()) {
        var p = m.value;
        d.includes(p) ? e(p, 1) : e(p, 2);
      }
    } finally {
      z(k, m);
    }
    f.canonical[mm()] = {};
    sm();
  }
  function um() {
    var a = mm();
    return !!gm().canonical[a];
  }
  function wm(a) {
    return !!gm().container[a];
  }
  function xm() {
    var a = qm(),
      b = pm(a);
    return b && b.context;
  }
  function ym(a) {
    var b = fm(a);
    return b ? b.state !== 0 : !1;
  }
  function qm() {
    return { ctid: H(5), isDestination: If(7) };
  }
  function zm(a, b, c) {
    var d = qm(),
      e = gm().container[a];
    (e && e.state !== 3) ||
      ((gm().container[a] = { state: 1, context: b, parent: d }),
      hm({ ctid: a, isDestination: !1 }, c));
  }
  function Am(a, b, c) {
    var d = gm(),
      e = fm(a);
    e
      ? (e.state = 1)
      : ((e = { context: b, state: 1, parent: qm() }),
        (d.destinationArray[a] = [e]));
    hm({ ctid: a, isDestination: !0 }, c);
  }
  function Bm(a, b, c, d) {
    var e = gm(),
      f = fm(a);
    f
      ? (f.state = 0)
      : ((f = { state: 0, transportUrl: b, context: c, parent: qm() }),
        (e.destinationArray[a] = [f]));
    hm({ ctid: a, isDestination: !0 }, d);
    R(91);
  }
  function Cm() {
    var a = gm().container,
      b;
    for (b in a) if (a.hasOwnProperty(b) && a[b].state === 1) return !0;
    return !1;
  }
  function Dm(a) {
    return !!(
      a &&
      a.parent &&
      a.context &&
      a.context.source === 1 &&
      a.parent.ctid.indexOf("GTM-") !== 0
    );
  }
  function Em() {
    var a = gm(),
      b = n(nm()),
      c = b.next();
    try {
      for (; !c.done; c = b.next())
        if (a.injectedFirstPartyContainers[c.value]) return !0;
    } finally {
      z(b, c);
    }
    return !1;
  }
  function Fm() {
    var a = Vc("google_tag_data", {});
    return (a.ics = a.ics || new Gm());
  }
  var Gm = function () {
    this.entries = {};
    this.waitPeriodTimedOut =
      this.wasSetLate =
      this.accessedAny =
      this.accessedDefault =
      this.usedImplicit =
      this.usedUpdate =
      this.usedDefault =
      this.usedDeclare =
      this.active =
        !1;
    this.listeners = [];
  };
  Gm.prototype.default = function (a, b, c, d, e, f, g) {
    this.usedDefault ||
      this.usedDeclare ||
      (!this.accessedDefault && !this.accessedAny) ||
      (this.wasSetLate = !0);
    this.usedDefault = this.active = !0;
    wb("TAGGING", 19);
    b == null ? wb("TAGGING", 18) : Im(this, a, b === "granted", c, d, e, f, g);
  };
  Gm.prototype.waitForUpdate = function (a, b, c) {
    for (var d = 0; d < a.length; d++)
      Im(this, a[d], void 0, void 0, "", "", b, c);
  };
  var Im = function (a, b, c, d, e, f, g, h) {
    var k = a.entries,
      m = k[b] || {},
      p = m.region,
      q = d && Hb(d) ? d.toUpperCase() : void 0;
    e = e.toUpperCase();
    f = f.toUpperCase();
    if (e === "" || q === f || (q === e ? p !== f : !q && !p)) {
      var r = !!(g && g > 0 && m.update === void 0),
        t = {
          region: q,
          declare_region: m.declare_region,
          implicit: m.implicit,
          default: c !== void 0 ? c : m.default,
          declare: m.declare,
          update: m.update,
          quiet: r,
        };
      if (e !== "" || m.default !== !1) k[b] = t;
      r &&
        A.setTimeout(function () {
          k[b] === t &&
            t.quiet &&
            (wb("TAGGING", 2),
            (a.waitPeriodTimedOut = !0),
            a.clearTimeout(b, void 0, h),
            a.notifyListeners());
        }, g);
    }
  };
  l = Gm.prototype;
  l.clearTimeout = function (a, b, c) {
    var d = [a],
      e = c.delegatedConsentTypes,
      f;
    for (f in e) e.hasOwnProperty(f) && e[f] === a && d.push(f);
    var g = this.entries[a] || {},
      h = this.getConsentState(a, c);
    if (g.quiet) {
      g.quiet = !1;
      var k = n(d),
        m = k.next();
      try {
        for (; !m.done; m = k.next()) Jm(this, m.value);
      } finally {
        z(k, m);
      }
    } else if (b !== void 0 && h !== b) {
      var p = n(d),
        q = p.next();
      try {
        for (; !q.done; q = p.next()) Jm(this, q.value);
      } finally {
        z(p, q);
      }
    }
  };
  l.update = function (a, b, c) {
    this.usedDefault ||
      this.usedDeclare ||
      this.usedUpdate ||
      !this.accessedAny ||
      (this.wasSetLate = !0);
    this.usedUpdate = this.active = !0;
    if (b != null) {
      var d = this.getConsentState(a, c),
        e = this.entries;
      (e[a] = e[a] || {}).update = b === "granted";
      this.clearTimeout(a, d, c);
    }
  };
  l.declare = function (a, b, c, d, e) {
    this.usedDeclare = this.active = !0;
    var f = this.entries,
      g = f[a] || {},
      h = g.declare_region,
      k = c && Hb(c) ? c.toUpperCase() : void 0;
    d = d.toUpperCase();
    e = e.toUpperCase();
    if (d === "" || k === e || (k === d ? h !== e : !k && !h)) {
      var m = {
        region: g.region,
        declare_region: k,
        declare: b === "granted",
        implicit: g.implicit,
        default: g.default,
        update: g.update,
        quiet: g.quiet,
      };
      if (d !== "" || g.declare !== !1) f[a] = m;
    }
  };
  l.implicit = function (a, b) {
    this.usedImplicit = !0;
    var c = this.entries,
      d = (c[a] = c[a] || {});
    d.implicit !== !1 && (d.implicit = b === "granted");
  };
  l.getConsentState = function (a, b) {
    var c = this.entries,
      d = c[a] || {},
      e = d.update;
    if (e !== void 0) return e ? 1 : 2;
    if (b.usedContainerScopedDefaults) {
      var f = b.containerScopedDefaults[a];
      if (f === 3) return 1;
      if (f === 2) return 2;
    } else if (((e = d.default), e !== void 0)) return e ? 1 : 2;
    if (b == null ? 0 : b.delegatedConsentTypes.hasOwnProperty(a)) {
      var g = b.delegatedConsentTypes[a],
        h = c[g] || {};
      e = h.update;
      if (e !== void 0) return e ? 1 : 2;
      if (b.usedContainerScopedDefaults) {
        var k = b.containerScopedDefaults[g];
        if (k === 3) return 1;
        if (k === 2) return 2;
      } else if (((e = h.default), e !== void 0)) return e ? 1 : 2;
    }
    e = d.declare;
    if (e !== void 0) return e ? 1 : 2;
    e = d.implicit;
    return e !== void 0 ? (e ? 3 : 4) : 0;
  };
  l.addListener = function (a, b) {
    this.listeners.push({ consentTypes: a, fn: b });
  };
  var Jm = function (a, b) {
    for (var c = 0; c < a.listeners.length; ++c) {
      var d = a.listeners[c];
      Array.isArray(d.consentTypes) &&
        d.consentTypes.indexOf(b) !== -1 &&
        (d.ln = !0);
    }
  };
  Gm.prototype.notifyListeners = function (a, b) {
    for (var c = 0; c < this.listeners.length; ++c) {
      var d = this.listeners[c];
      if (d.ln) {
        d.ln = !1;
        try {
          d.fn({ consentEventId: a, consentPriorityId: b });
        } catch (e) {}
      }
    }
  };
  var Km = !1,
    Lm = !1,
    Mm = {},
    Nm = {
      delegatedConsentTypes: {},
      corePlatformServices: {},
      usedCorePlatformServices: !1,
      selectedAllCorePlatformServices: !1,
      containerScopedDefaults:
        ((Mm.ad_storage = 1),
        (Mm.analytics_storage = 1),
        (Mm.ad_user_data = 1),
        (Mm.ad_personalization = 1),
        Mm),
      usedContainerScopedDefaults: !1,
    };
  function Om(a) {
    var b = Fm();
    b.accessedAny = !0;
    return (Hb(a) ? [a] : a).every(function (c) {
      switch (b.getConsentState(c, Nm)) {
        case 1:
        case 3:
          return !0;
        case 2:
        case 4:
          return !1;
        default:
          return !0;
      }
    });
  }
  function Pm(a) {
    var b = Fm();
    b.accessedAny = !0;
    return b.getConsentState(a, Nm);
  }
  function Qm(a) {
    var b = Fm();
    b.accessedAny = !0;
    return !(b.entries[a] || {}).quiet;
  }
  function Rm(a, b, c, d) {
    var e = Fk(),
      f = Gk();
    d = d === void 0 ? 0 : d;
    Km = !0;
    Lm && wb("TAGGING", 20);
    Fm().default(a, b, c, e, f, d, Nm);
  }
  function Sm() {
    if (!Mh(4)) return !1;
    var a = Fm();
    a.accessedAny = !0;
    if (a.active) return !0;
    if (!Nm.usedContainerScopedDefaults) return !1;
    var b = n(Object.keys(Nm.containerScopedDefaults)),
      c = b.next();
    try {
      for (; !c.done; c = b.next())
        if (Nm.containerScopedDefaults[c.value] !== 1) return !0;
    } finally {
      z(b, c);
    }
    return !1;
  }
  function Tm(a, b) {
    Fm().addListener(a, b);
  }
  function Um(a, b) {
    if (b.every(Qm)) a({});
    else {
      var c = !1;
      Tm(b, function (d) {
        !c && b.every(Qm) && ((c = !0), a(d));
      });
    }
  }
  function Vm(a, b) {
    var c = Hb(b) ? [b] : b,
      d = {},
      e = function () {
        return c.filter(function (h) {
          return Om(h) && !d[h];
        });
      },
      f = e();
    if (f.length !== c.length) {
      var g = function (h) {
        var k = n(h),
          m = k.next();
        try {
          for (; !m.done; m = k.next()) d[m.value] = !0;
        } finally {
          z(k, m);
        }
      };
      g(f);
      Tm(c, function (h) {
        function k(q) {
          q.length !== 0 && (g(q), (h.consentTypes = q), a(h));
        }
        var m = e();
        if (m.length !== 0) {
          var p = Object.keys(d).length;
          m.length + p >= c.length
            ? k(m)
            : A.setTimeout(function () {
                k(e());
              }, 500);
        }
      });
    }
  }
  var Wm = function (a, b) {
    this.H = a;
    this.consentTypes = b;
  };
  Wm.prototype.isConsentGranted = function () {
    switch (this.H) {
      case 0:
        return this.consentTypes.every(function (a) {
          return Om(a);
        });
      case 1:
        return this.consentTypes.some(function (a) {
          return Om(a);
        });
      default:
        Hc(this.H, "consentsRequired had an unknown type");
    }
  };
  var Xm = new (function () {
    var a = {};
    this.H = ((a[0] = 0), (a[1] = 0), (a[2] = 0), (a[3] = 0), a);
    var b = {};
    this.K =
      ((b[0] = new Wm(0, [])),
      (b[1] = new Wm(0, ["ad_storage"])),
      (b[2] = new Wm(0, ["analytics_storage"])),
      (b[3] = new Wm(1, ["ad_storage", "analytics_storage"])),
      b);
  })();
  var Zm = function (a) {
    var b = this;
    this.type = a;
    this.H = [];
    Tm(Xm.K[a].consentTypes, function () {
      Ym(b) || b.flush();
    });
  };
  Zm.prototype.flush = function () {
    var a = n(this.H),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = b.value;
        c();
      }
    } finally {
      z(a, b);
    }
    this.H = [];
  };
  var Ym = function (a) {
      return Xm.H[a.type] === 2 && !Xm.K[a.type].isConsentGranted();
    },
    $m = function (a, b) {
      Ym(a) ? a.H.push(b) : b();
    },
    an = function () {
      this.H = new Map();
    },
    cn = function (a) {
      var b = bn;
      b.H.has(a) || b.H.set(a, new Zm(a));
      return b.H.get(a);
    };
  an.prototype.reset = function () {
    this.H.clear();
  };
  var bn = new an();
  var dn = ["fin", "mcc", "ncc"],
    en = function (a) {
      a = a === void 0 ? !1 : a;
      var b = dj(),
        c = cj.K,
        d = b.filter(function (p) {
          return c[p] !== void 0 && (a || !dn.includes(p));
        });
      fj(d);
      var e = {},
        f = n(d),
        g = f.next();
      try {
        for (; !g.done; g = f.next()) {
          var h = g.value,
            k = c[h];
          typeof k === "function" && (k = k());
          k && (e[h] = k);
        }
      } finally {
        z(f, g);
      }
      var m = Vi(e, { Xe: !1 });
      return m ? "&" + m + "&z=0" : "&z=0";
    },
    fn = function (a, b, c) {
      b = b === void 0 ? !1 : b;
      c = c === void 0 ? !1 : c;
      if (Zi(14) && gl.K && H(5) && (c || !hl())) {
        var d = cn(3);
        if (Ym(d))
          a.H ||
            ((a.H = !0),
            $m(d, function () {
              fn(a);
            }));
        else {
          b && gj("fin", "1");
          var e = en(b),
            f = Wk[61](void 0) + "?id=" + H(5) + e,
            g = { destinationId: H(5), endpoint: 61 };
          b
            ? Xl(g, f, void 0, { Vm: !0 }, void 0, function () {
                hd(f + "&img=1");
              })
            : Wl(g, f);
          a.H = !1;
          gn(e);
        }
      }
    },
    gn = function (a) {
      if (
        Uc &&
        ($b(Uc, "https://www.googletagmanager.com/") || If(47)) &&
        !(a.indexOf("&csp=") < 0 && a.indexOf("&mde=") < 0)
      ) {
        var b;
        a: {
          try {
            if (Uc) {
              b = new URL(Uc);
              break a;
            }
          } catch (c) {}
          b = void 0;
        }
        b && dd("" + Uc + (Uc.indexOf("?") >= 0 ? "&" : "?") + "is_td=1" + a);
      }
    },
    hn = function (a) {
      dj().some(function (b) {
        return !bj[b];
      }) && fn(a, !0);
    },
    jn = new (function () {
      var a = this;
      this.H = !1;
      id(A, "pagehide", function () {
        hn(a);
      });
    })();
  function kn(a, b) {
    fn(jn, a === void 0 ? !1 : a, b === void 0 ? !1 : b);
  }
  var ln = [
      "ad_storage",
      "analytics_storage",
      "ad_user_data",
      "ad_personalization",
    ],
    mn = [
      K.D.Zb,
      K.D.bc,
      K.D.Gf,
      K.D.Bb,
      K.D.ac,
      K.D.nb,
      K.D.Db,
      K.D.Ya,
      K.D.sb,
      K.D.Mb,
    ],
    pn = function () {
      var a = nn;
      !a.T &&
        a.H &&
        (ln.some(function (b) {
          return Nm.containerScopedDefaults[b] !== 1;
        }) ||
          on("mbc"));
      a.T = !0;
    },
    on = function (a) {
      gl.K && (gj(a, "1"), kn());
    },
    qn = function (a, b) {
      var c = nn;
      if (!c.P[b] && ((c.P[b] = !0), c.K[b])) {
        var d = n(mn),
          e = d.next();
        try {
          for (; !e.done; e = d.next())
            if (Q(a, e.value)) {
              on("erc");
              break;
            }
        } finally {
          z(d, e);
        }
      }
    },
    nn = new (function () {
      this.T = this.H = !1;
      this.P = {};
      this.K = {};
    })();
  var rn = {},
    sn = Object.freeze(
      ((rn[K.D.sc] = 1),
      (rn[K.D.Xg] = 1),
      (rn[K.D.ki] = 1),
      (rn[K.D.Qc] = 1),
      (rn[K.D.Ka] = 1),
      (rn[K.D.sb] = 1),
      (rn[K.D.tb] = 1),
      (rn[K.D.Cb] = 1),
      (rn[K.D.zd] = 1),
      (rn[K.D.Mb] = 1),
      (rn[K.D.Ya] = 1),
      (rn[K.D.uc] = 1),
      (rn[K.D.Fe] = 1),
      (rn[K.D.Na] = 1),
      (rn[K.D.po] = 1),
      (rn[K.D.Ff] = 1),
      (rn[K.D.yi] = 1),
      (rn[K.D.hh] = 1),
      (rn[K.D.Uc] = 1),
      (rn[K.D.Gf] = 1),
      (rn[K.D.Ao] = 1),
      (rn[K.D.Sa] = 1),
      (rn[K.D.Kf] = 1),
      (rn[K.D.Co] = 1),
      (rn[K.D.Xb] = 1),
      (rn[K.D.Xk] = 1),
      (rn[K.D.wc] = 1),
      (rn[K.D.Wc] = 1),
      (rn[K.D.Db] = 1),
      (rn[K.D.ol] = 1),
      (rn[K.D.ub] = 1),
      (rn[K.D.yc] = 1),
      (rn[K.D.Yb] = 1),
      (rn[K.D.Hi] = 1),
      (rn[K.D.Zb] = 1),
      (rn[K.D.nh] = 1),
      (rn[K.D.Ii] = 1),
      (rn[K.D.Zc] = 1),
      (rn[K.D.bc] = 1),
      (rn[K.D.Ld] = 1),
      (rn[K.D.Al] = 1),
      (rn[K.D.cg] = 1),
      (rn[K.D.ad] = 1),
      (rn[K.D.cj] = 1),
      rn)
    );
  Object.freeze([
    K.D.ya,
    K.D.Ea,
    K.D.Eb,
    K.D.mb,
    K.D.Gi,
    K.D.nb,
    K.D.zi,
    K.D.lo,
  ]);
  var tn = {},
    un = Object.freeze(
      ((tn[K.D.Nn] = 1),
      (tn[K.D.On] = 1),
      (tn[K.D.Pn] = 1),
      (tn[K.D.Qn] = 1),
      (tn[K.D.Rn] = 1),
      (tn[K.D.Vn] = 1),
      (tn[K.D.Wn] = 1),
      (tn[K.D.Xn] = 1),
      (tn[K.D.Zn] = 1),
      (tn[K.D.xf] = 1),
      tn)
    ),
    vn = {},
    wn = Object.freeze(
      ((vn[K.D.Bk] = 1),
      (vn[K.D.Ck] = 1),
      (vn[K.D.tf] = 1),
      (vn[K.D.uf] = 1),
      (vn[K.D.Dk] = 1),
      (vn[K.D.je] = 1),
      (vn[K.D.vf] = 1),
      (vn[K.D.vd] = 1),
      (vn[K.D.ke] = 1),
      (vn[K.D.wd] = 1),
      (vn[K.D.Tb] = 1),
      (vn[K.D.wf] = 1),
      (vn[K.D.Mc] = 1),
      (vn[K.D.Ek] = 1),
      vn)
    ),
    xn = Object.freeze([
      K.D.sc,
      K.D.Qc,
      K.D.uc,
      K.D.Gf,
      K.D.Vc,
      K.D.yc,
      K.D.Hi,
      K.D.Ld,
    ]),
    yn = Object.freeze([].concat(w(xn))),
    zn = Object.freeze([K.D.tb, K.D.hh, K.D.nh, K.D.Ii, K.D.eh]),
    An = Object.freeze([].concat(w(zn))),
    Bn = {},
    Cn =
      ((Bn[K.D.ia] = "1"),
      (Bn[K.D.ua] = "2"),
      (Bn[K.D.ka] = "3"),
      (Bn[K.D.Ra] = "4"),
      Bn),
    Dn = {},
    En = Object.freeze(
      ((Dn.search = "s"),
      (Dn.youtube = "y"),
      (Dn.playstore = "p"),
      (Dn.shopping = "h"),
      (Dn.ads = "a"),
      (Dn.maps = "m"),
      Dn)
    );
  function Fn(a) {
    return typeof a !== "object" || a === null ? {} : a;
  }
  function Gn(a) {
    return a === void 0 || a === null
      ? ""
      : typeof a === "object"
      ? a.toString()
      : String(a);
  }
  function Hn(a) {
    if (a !== void 0 && a !== null) return Gn(a);
  }
  var co = function () {
      this.H = A.google_tag_manager = A.google_tag_manager || {};
    },
    eo;
  function fo(a, b) {
    go();
    var c = eo;
    return (c.H[a] = c.H[a] || b());
  }
  function ho(a) {
    go();
    return eo.H[a];
  }
  function io(a, b) {
    go();
    eo.H[a] = b;
  }
  function jo(a) {
    var b = H(5);
    go();
    var c = eo;
    c.H[b] = c.H[b] || a;
  }
  function ko() {
    var a = H(19);
    go();
    var b = eo;
    return (b.H[a] = b.H[a] || {});
  }
  function lo() {
    var a = H(19);
    go();
    return eo.H[a];
  }
  function mo() {
    go();
    var a = eo,
      b = a.H.sequence || 1;
    a.H.sequence = b + 1;
    return b;
  }
  function go() {
    eo || (eo = new co());
  }
  var no = function () {};
  no.prototype.toString = function () {
    return "undefined";
  };
  var oo = new no();
  var ro = function (a, b, c) {
      a instanceof po && ((a = a.resolve(qo.P(b, c))), (b = Fb));
      return { er: a, onSuccess: b };
    },
    to = function (a) {
      qo || (qo = new so());
      return qo.K(a);
    },
    uo = function () {
      var a = this;
      this.H = {};
      fo("rm", function () {
        return {};
      })[mm()] = function (b) {
        if (a.H.hasOwnProperty(b)) return a.H[b];
      };
    };
  uo.prototype.K = function (a) {
    if (a === oo) return a;
    var b = mo();
    this.H[b] = a;
    return 'google_tag_manager["rm"]["' + mm() + '"](' + b + ")";
  };
  var vo,
    po = function (a) {
      this.valueOf = this.toString;
      this.resolve = function (b) {
        for (var c = [], d = 0; d < a.length; d++)
          c.push(a[d] === oo ? b : a[d]);
        return c.join("");
      };
    };
  po.prototype.toString = function () {
    return this.resolve("undefined");
  };
  var so = function () {
    this.H = {};
  };
  so.prototype.P = function (a, b) {
    var c = String(mo());
    this.H[c] = [a, b];
    return c;
  };
  so.prototype.K = function (a) {
    var b = this,
      c = a ? 0 : 1;
    return function (d) {
      R(a ? 134 : 135);
      var e = b.H[d];
      if (e && typeof e[c] === "function") e[c]();
      b.H[d] = void 0;
    };
  };
  var qo;
  function wo(a, b) {
    function c(g) {
      var h = Fj(g),
        k = zj(h, "protocol"),
        m = zj(h, "host", !0),
        p = zj(h, "port"),
        q = zj(h, "path").toLowerCase().replace(/\/$/, "");
      if (
        k === void 0 ||
        (k === "http" && p === "80") ||
        (k === "https" && p === "443")
      )
        (k = "web"), (p = "default");
      return [k, m, p, q];
    }
    for (var d = c(String(a)), e = c(String(b)), f = 0; f < d.length; f++)
      if (d[f] !== e[f]) return !1;
    return !0;
  }
  function xo(a) {
    return yo(a) ? 1 : 0;
  }
  function yo(a) {
    var b = a.arg0,
      c = a.arg1;
    if (a.any_of && Array.isArray(c)) {
      for (var d = 0; d < c.length; d++) {
        var e = Eb(a, {});
        Eb({ arg1: c[d], any_of: void 0 }, e);
        if (xo(e)) return !0;
      }
      return !1;
    }
    switch (a["function"]) {
      case "_cn":
        return zg(b, c);
      case "_css":
        return vg(b, c);
      case "_ew":
        return wg(b, c);
      case "_eq":
        return Ag(b, c);
      case "_ge":
        return Bg(b, c);
      case "_gt":
        return Dg(b, c);
      case "_lc":
        return xg(b, c);
      case "_le":
        return Cg(b, c);
      case "_lt":
        return Eg(b, c);
      case "_re":
        return yg(
          b,
          c,
          a.ignore_case,
          $i(20, function () {
            return new Map();
          })
        );
      case "_sw":
        return Fg(b, c);
      case "_um":
        return wo(b, c);
    }
    return !1;
  }
  function zo(a, b, c, d, e) {
    if (Array.isArray(a)) {
      var f;
      switch (a[0]) {
        case "function_id":
          return a[1];
        case "list":
          f = [];
          for (var g = 1; g < a.length; g++) f.push(zo(a[g], b, c, d, e));
          return f;
        case "macro":
          var h = d[a[1]];
          return h ? h.evaluate(b, e) : void 0;
        case "map":
          f = {};
          for (var k = 1; k < a.length; k += 2)
            f[zo(a[k], b, c, d, e)] = zo(a[k + 1], b, c, d, e);
          return f;
        case "template":
          f = [];
          for (var m = !1, p = 1; p < a.length; p++) {
            var q = zo(a[p], b, c, d, e);
            m = m || q === oo;
            f.push(q);
          }
          if (m) return new po(f);
          return f.join("");
        case "escape":
          f = zo(a[1], b, c, d, e);
          var r;
          if ((r = Array.isArray(a[1]) && a[1][0] === "macro")) {
            for (var t = !1, u = !1, v = 2; v < a.length; v++)
              (t = t || a[v] === 8), (u = u || a[v] === 16);
            r = t && u;
          }
          if (r) {
            var x = f;
            vo || (vo = new uo());
            return vo.K(x);
          }
          f = String(f);
          for (var y = 2; y < a.length; y++) On[a[y]] && (f = On[a[y]](f));
          return f;
        case "tag":
          var B = a[1];
          if (!c[B]) throw Error("Unable to resolve tag reference " + B + ".");
          return { Fm: a[2], index: B };
        case "zb":
          var E = {},
            F =
              ((E["function"] = a[1]),
              (E.arg0 = zo(a[2], b, c, d, e)),
              (E.arg1 = zo(a[3], b, c, d, e)),
              (E.ignore_case = zo(a[5], b, c, d, e)),
              E),
            G = xo(F),
            I = !!a[4];
          return I || G !== 2 ? I !== (G === 1) : null;
        default:
          throw Error("Attempting to expand unknown Value type: " + a[0] + ".");
      }
    }
    return a;
  }
  var Bo = function (a, b) {
      this.H = !1;
      this.T = [];
      this.eventData = { tags: [] };
      this.Z = !1;
      this.K = this.P = 0;
      Ao(this, a, b);
    },
    Co = function (a, b, c, d) {
      if (qj.hasOwnProperty(b) || b === "__zone") return -1;
      var e = {};
      Db(d) && (e = Eb(d, e));
      e.id = c;
      e.status = "timeout";
      return a.eventData.tags.push(e) - 1;
    },
    Do = function (a, b, c, d) {
      var e = a.eventData.tags[b];
      e && ((e.status = c), (e.executionTime = d));
    },
    Eo = function (a) {
      if (!a.H) {
        for (var b = a.T, c = 0; c < b.length; c++) b[c]();
        a.H = !0;
        a.T.length = 0;
      }
    },
    Ao = function (a, b, c) {
      b !== void 0 && a.pg(b);
      c &&
        A.setTimeout(function () {
          Eo(a);
        }, Number(c));
    };
  Bo.prototype.pg = function (a) {
    var b = this,
      c = Xb(function () {
        kd(function () {
          a(H(5), b.eventData);
        });
      });
    this.H ? c() : this.T.push(c);
  };
  var Fo = function (a) {
      a.P++;
      return Xb(function () {
        a.K++;
        a.Z && a.K >= a.P && Eo(a);
      });
    },
    Go = function (a) {
      a.Z = !0;
      a.K >= a.P && Eo(a);
    };
  function Ho(a) {
    return a && a.indexOf("pending:") === 0 ? Io(a.substr(8)) : !1;
  }
  function Io(a) {
    if (a == null || a.length === 0) return !1;
    var b = Number(a),
      c = Wb();
    return b < c + 3e5 && b > c - 9e5;
  }
  var Jo = !1,
    Ko = !1,
    Lo = !1,
    Mo = 0,
    No = !1,
    Oo = void 0,
    Po = [];
  function Qo(a) {
    if (Mo === 0) No && Po && (Po.length >= 100 && Po.shift(), Po.push(a));
    else if (Ro()) {
      var b = H(41),
        c = Vc(b, []);
      c.length >= 50 && c.shift();
      c.push(a);
    }
  }
  function So() {
    Ko || (To(), Uo(Mo));
  }
  function Uo(a) {
    if (!Ko || (Mo === 2 && a === 1))
      if (
        ((Ko = !0),
        Lo && (jd(C, "TAProdDebugSignal", So), (Lo = !1)),
        Oo !== void 0 && (A.clearTimeout(Oo), (Oo = void 0)),
        (Mo = a),
        a === 1)
      ) {
        var b = Po;
        Po = void 0;
        b == null ||
          b.forEach(function (c) {
            Qo(c);
          });
      }
  }
  function To() {
    var a = C.documentElement.getAttribute("data-tag-assistant-prod-present");
    Io(a)
      ? (Mo = 1)
      : !Ho(a) || Jo || Lo
      ? (Mo = 2)
      : ((Lo = !0),
        id(C, "TAProdDebugSignal", So, !1),
        (Oo = A.setTimeout(function () {
          Ko || (To(), Uo(Mo));
          Jo = !0;
        }, 200)));
  }
  function Ro() {
    if (!No) return !1;
    switch (Mo) {
      case 1:
      case 0:
        return !0;
      case 2:
        return !1;
      default:
        return !1;
    }
  }
  var Vo = !1;
  function Wo(a, b) {
    var c = nm(),
      d = km();
    H(26);
    var e = If(47) ? 0 : If(50) ? 1 : 3,
      f = Mj();
    if (Ro()) {
      var g = Xo("INIT");
      g.containerLoadSource = a != null ? a : 0;
      b && (g.parentTargetReference = b);
      g.aliases = c;
      g.destinations = d;
      e !== void 0 && (g.gtg = { source: e, mPath: f != null ? f : "" });
      Qo(g);
    }
  }
  function Yo(a) {
    var b, c, d, e;
    b = a.targetId;
    c = a.request;
    d = a.xb;
    e = a.isBatched;
    var f;
    if ((f = Ro())) {
      var g;
      a: switch (c.endpoint) {
        case 68:
        case 69:
        case 19:
        case 62:
        case 18:
        case 47:
          g = !0;
          break a;
        default:
          g = !1;
      }
      f = !g;
    }
    if (f) {
      var h = Xo("GTAG_HIT", { eventId: d.eventId, priorityId: d.priorityId });
      h.target = b;
      h.url = c.url;
      c.postBody && (h.postBody = c.postBody);
      h.parameterEncoding = c.parameterEncoding;
      h.endpoint = c.endpoint;
      e !== void 0 && (h.isBatched = e);
      Qo(h);
    }
  }
  function Zo(a) {
    Ro() && Yo(a());
  }
  function Xo(a, b) {
    b = b === void 0 ? {} : b;
    b.groupId = $o;
    var c,
      d = b,
      e = ap,
      f = { publicId: bp };
    d.eventId != null && (f.eventId = d.eventId);
    d.priorityId != null && (f.priorityId = d.priorityId);
    d.eventName && (f.eventName = d.eventName);
    d.groupId && (f.groupId = d.groupId);
    d.tagName && (f.tagName = d.tagName);
    c = { containerProduct: "GTM", key: f, version: e, messageType: a };
    c.containerProduct = Vo ? "OGT" : "GTM";
    c.key.targetRef = cp;
    return c;
  }
  var bp = "",
    ap = "",
    cp = { ctid: "", isDestination: !1 },
    $o;
  function dp(a) {
    var b = H(5),
      c = If(45),
      d = jm(),
      e = H(6),
      f = H(1);
    H(23);
    Ko || No ? (No = !0) : ((Mo = 0), (No = !0), To());
    $o = a;
    bp = b;
    ap = f;
    Vo = c;
    cp = { ctid: b, isDestination: d, canonicalId: e };
  }
  var ep = [K.D.ia, K.D.ua, K.D.ka, K.D.Ra];
  function fp(a) {
    pn();
    var b = $i(32, function () {
        return !1;
      }),
      c = $i(33, function () {
        return !1;
      });
    !b && c && on("crc");
    Yi(32, !0);
    var d = a[K.D.Tg];
    d && R(41);
    var e = a[K.D.rc];
    e ? R(40) : (e = [""]);
    var f = n(e),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = g.value,
          k = n(Object.entries(a)),
          m = k.next();
        try {
          for (; !m.done; m = k.next()) {
            var p = n(m.value),
              q = p.next().value,
              r = p.next().value,
              t = q;
            t !== K.D.rc && t !== K.D.Tg && Rm(t, Hn(r), h, Number(d));
          }
        } finally {
          z(k, m);
        }
      }
    } finally {
      z(f, g);
    }
  }
  function gp(a, b) {
    pn();
    Yi(33, !0);
    var c = n(Object.entries(a)),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = n(d.value),
          f = e.next().value,
          g = e.next().value,
          h = f,
          k = Gn(g);
        Km = !0;
        Lm && wb("TAGGING", 20);
        Fm().update(h, k, Nm);
      }
    } finally {
      z(c, d);
    }
    var m = b.eventId,
      p = b.priorityId;
    Fm().notifyListeners(m, p);
  }
  function hp(a) {
    Array.isArray(a) || (a = [a]);
    return a.every(function (b) {
      return Om(b);
    });
  }
  function ip() {
    var a = jp;
    Array.isArray(a) || (a = [a]);
    return a.some(function (b) {
      return Om(b);
    });
  }
  function kp(a, b) {
    Tm(a, b);
  }
  function lp(a, b) {
    Vm(a, b);
  }
  function mp(a, b) {
    Um(a, b);
  }
  function np() {
    var a = [K.D.ia, K.D.Ra, K.D.ka];
    Fm().waitForUpdate(a, 500, Nm);
  }
  function op(a) {
    var b = n(a),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = c.value;
        Fm().clearTimeout(d, void 0, Nm);
      }
    } finally {
      z(b, c);
    }
    Fm().notifyListeners(void 0, void 0);
  }
  function pp(a) {
    var b = {},
      c = n(a.split("|")),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) b[d.value] = !0;
    } finally {
      z(c, d);
    }
    return b;
  }
  var qp = function (a, b, c, d, e) {
    this.endpoint = a;
    this.da = c;
    this.Aa = d;
    this.parameterEncoding = e;
    this.Z = b.slice();
  };
  qp.prototype.K = function () {
    return !this.Z.length || hp(this.Z);
  };
  qp.prototype.isSupported = function () {
    return !0;
  };
  qp.prototype.T = function () {
    var a = Wk[this.endpoint](void 0);
    return $b(a, "https://")
      ? a.substring(8)
      : $b(a, "http://")
      ? a.substring(7)
      : a;
  };
  var rp = function (a, b) {
    this.methodName = a;
    this.T = b;
  };
  rp.prototype.sendRequest = function (a, b, c) {
    if (this.isSupported())
      if ((c == null ? void 0 : c.body) === void 0 || this.H())
        try {
          this.K(a, b, c);
        } catch (d) {
          a.rd(d);
        }
      else
        a.rd(
          "Request method " +
            this.methodName +
            " does not support a request body."
        );
    else a.rd("Request method " + this.methodName + " is not supported.");
  };
  var sp = function () {
    rp.call(this, "ImagePixel", 3);
  };
  ta(sp, rp);
  sp.prototype.isSupported = function () {
    return !0;
  };
  sp.prototype.H = function () {
    return !1;
  };
  sp.prototype.K = function (a, b, c) {
    hd(
      b,
      function () {
        a.ef();
      },
      function () {
        a.onFailure(void 0);
      },
      c == null ? void 0 : c.We
    );
  };
  var tp = function () {
    rp.call(this, "SendBeacon", 1);
  };
  ta(tp, rp);
  tp.prototype.isSupported = function () {
    return td();
  };
  tp.prototype.H = function () {
    return !0;
  };
  tp.prototype.K = function (a, b, c) {
    sd(b, c == null ? void 0 : c.body) ? a.ef() : a.rd(void 0);
  };
  var up = function () {
    rp.call(this, "Fetch", 1);
  };
  ta(up, rp);
  up.prototype.isSupported = function () {
    return Gb(A.fetch);
  };
  up.prototype.H = function () {
    return !0;
  };
  up.prototype.K = function (a, b, c) {
    A.fetch(b, c == null ? void 0 : c.yb)
      .then(function (d) {
        if (d.ok) a.Yd(d);
        else if (d.status === 0) a.ef();
        else a.onFailure("Fetch failed with status code " + d.status + ".");
      })
      .catch(function (d) {
        a.rd(d);
      });
  };
  var vp = new sp(),
    wp = new tp(),
    xp = new up();
  var yp = function () {};
  yp.prototype.H = function () {
    return [];
  };
  function Mp(a, b) {
    if (b != null && b !== "") {
      var c = b === !0 ? "1" : b === !1 ? "0" : encodeURIComponent(String(b));
      if ($b(a, "_&")) return { key: a.substring(2), value: c };
      var d = Lp[a];
      if (d !== null)
        return d
          ? { key: d, value: c }
          : { key: Kb(b) ? "epn." + a : "ep." + a, value: c };
    }
  }
  function Np(a) {
    a = a === void 0 ? [] : a;
    return jj(a).join("~");
  }
  var Op = function () {
      this.K = {};
      this.H = {};
      this.P = {};
      this.T = new Set();
    },
    Pp = function (a, b, c, d) {
      var e = Ei;
      if (e.studies[c]) {
        var f = e.studies[c],
          g = f.experimentId,
          h = f.probability;
        if (!(b.studies || {})[c]) {
          var k = b.studies || {};
          k[c] = !0;
          b.studies = k;
          if (!e.studies[c].active)
            if (e.studies[c].probability > 0.5) Hi(b, g, c);
            else if (!(h <= 0 || h > 1)) {
              var m = void 0;
              if (d) {
                var p = Bi(d + "~" + c);
                if (p === "e2") m = -1;
                else {
                  var q = new Uint8Array(p),
                    r = BigInt(0),
                    t = n(q),
                    u = t.next();
                  try {
                    for (; !u.done; u = t.next())
                      r = (r << BigInt(8)) | BigInt(u.value);
                  } finally {
                    z(t, u);
                  }
                  m = Number(r % BigInt(Number.MAX_SAFE_INTEGER));
                }
              }
              Fi.Zj(b, c, m);
            }
        }
      }
      if (!a.K[c]) {
        var v = Mi(b, c);
        v && ij.H.K.add(v);
      }
    },
    Qp = function () {
      return vk(qk.ba.hp, {});
    },
    Vp = function (a, b) {
      var c = Rp;
      Pp(c, Qp(), a, b);
      Sp(c, a) ? Oi(Pi, a) : Tp(c, a) ? Pi.K.add(a) : Up(c, a) && Pi.H.add(a);
    },
    Sp = function (a, b) {
      var c;
      if (!(c = !!a.P[b])) {
        var d = Qp();
        c = Ji(d, b);
      }
      return c || Ji(a.H, b);
    },
    Tp = function (a, b) {
      var c = Qp();
      return Ki(c, b) || Ki(a.H, b);
    },
    Up = function (a, b) {
      var c = Qp();
      return Li(c, b) || Li(a.H, b);
    },
    Wp = function (a, b) {
      var c = Qp();
      return Mi(c, b) || Mi(a.H, b);
    },
    Xp = function (a, b, c) {
      if (a.K[b]) {
        var d = Wp(a, b);
        if (d)
          if (c) {
            var e = S(c, L.J.uh) || [];
            e.includes(d) || e.push(d);
            T(c, L.J.uh, e);
          } else a.T.add(d);
      }
    },
    Rp;
  function Yp() {
    if (!Rp) {
      var a = (Rp = new Op()),
        b,
        c,
        d =
          ((b = A) == null
            ? void 0
            : (c = b.location) == null
            ? void 0
            : c.hash) || "";
      if (
        d[0] === "#" &&
        d[1] === "_" &&
        d[2] === "t" &&
        d[3] === "e" &&
        d[4] === "="
      ) {
        var e = d.substring(5);
        if (e) {
          var f = n(e.split("~")),
            g = f.next();
          try {
            for (; !g.done; g = f.next()) {
              var h = g.value.split(":"),
                k = Number(h[0]);
              if (k)
                if (h.length > 1) {
                  var m = Number(h[1]);
                  if (m) {
                    var p = Qp();
                    Hi(p, m, k);
                    p.studies = p.studies || {};
                    p.studies[k] = !0;
                    Hi(a.H, m, k);
                    a.H.studies = a.H.studies || {};
                    a.H.studies[k] = !0;
                  }
                } else (a.P[k] = !0), Oi(Pi, k);
            }
          } finally {
            z(f, g);
          }
        }
      }
      var q = [],
        r = n(Mf(56) || []),
        t = r.next();
      try {
        for (; !t.done; t = r.next()) {
          var u = t.value,
            v = {
              studyId: u[1],
              active: !!u[2],
              probability: u[3] || 0,
              experimentId: u[4] || 0,
              controlId: u[5] || 0,
              controlId2: u[6] || 0,
            },
            x = 0;
          switch (u[7]) {
            case 2:
              x = 1;
              break;
            case 3:
              x = 2;
              break;
            case 1:
            case 4:
            case 5:
            case 6:
            case 0:
              x = 0;
          }
          var y;
          a: switch (v.studyId) {
            case 613:
            case 567:
            case 612:
              y = !0;
              break a;
            default:
              y = !1;
          }
          var B = ma(Object, "assign").call(Object, {}, v, {
            zm: x,
            focused: y,
          });
          (B.active ||
            (B.probability > 0.5 && B.experimentId) ||
            (B.experimentId && B.controlId)) &&
            q.push(B);
        }
      } finally {
        z(r, t);
      }
      var E = n(q),
        F = E.next();
      try {
        for (; !F.done; F = E.next()) {
          var G = a,
            I = F.value,
            J = I,
            M = (I = G.P[J.studyId]
              ? ma(Object, "assign").call(Object, {}, J, { active: !0 })
              : J),
            U = Ei;
          (M.controlId2 && M.probability <= 0.25) ||
            (M = ma(Object, "assign").call(Object, {}, M, { controlId2: 0 }));
          U.studies[M.studyId] = M;
          I.focused && (G.K[I.studyId] = !0);
          if (I.zm === 1) {
            var W = G,
              fa = I.studyId;
            Pp(W, Qp(), fa);
            Sp(W, fa)
              ? Oi(Pi, fa)
              : Tp(W, fa)
              ? Pi.K.add(fa)
              : Up(W, fa) && Pi.H.add(fa);
          } else if (I.zm === 0) {
            var da = G,
              ea = I.studyId;
            Pp(da, da.H, ea);
            Sp(da, ea)
              ? Oi(Pi, ea)
              : Tp(da, ea)
              ? Pi.K.add(ea)
              : Up(da, ea) && Pi.H.add(ea);
          }
        }
      } finally {
        z(E, F);
      }
    }
  }
  function Zp(a) {
    Yp();
    var b = Rp,
      c = Sp(b, 567);
    Xp(b, 567, a);
    return c;
  }
  function $p(a) {
    Yp();
    var b = Rp,
      c = Sp(b, a);
    Xp(b, a);
    return c;
  }
  function aq(a) {
    Yp();
    var b = Rp,
      c = new Set(b.T);
    if (a) {
      var d = S(a, L.J.uh) || [],
        e = n(d),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) c.add(f.value);
      } finally {
        z(e, f);
      }
      var g = S(a, L.J.Eh) || [],
        h = n(g),
        k = h.next();
      try {
        for (; !k.done; k = h.next()) {
          var m = Wp(b, k.value);
          m && c.delete(m);
        }
      } finally {
        z(h, k);
      }
    }
    return Np([].concat(w(c)));
  }
  function bq() {
    Yp();
    var a;
    var b = Rp;
    try {
      a = !!Wp(b, 567);
    } catch (c) {
      a = !1;
    }
    return a;
  }
  var cq = Object.freeze([K.D.ia, K.D.ka]);
  function dq(a) {
    var b = a.location.href;
    if (a === a.top) return { url: b, wr: !0 };
    var c = !1,
      d = a.document;
    d && d.referrer && ((b = d.referrer), a.parent === a.top && (c = !0));
    var e = a.location.ancestorOrigins;
    if (e) {
      var f = e[e.length - 1],
        g;
      f &&
        ((g = b) == null ? void 0 : g.indexOf(f)) === -1 &&
        ((c = !1), (b = f));
    }
    return { url: b, wr: c };
  }
  function eq(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Hl(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function fq() {
    for (var a = A, b = a; a && a !== a.parent; )
      (a = a.parent), eq(a) && (b = a);
    return b;
  }
  function gq(a, b) {
    var c = function () {};
    c.prototype = a.prototype;
    var d = new c();
    a.apply(d, Array.prototype.slice.call(arguments, 1));
    return d;
  }
  function hq(a) {
    var b = a;
    return function () {
      if (b) {
        var c = b;
        b = null;
        c();
      }
    };
  }
  function iq(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function jq(a) {
    var b = a.split(/[?#]/),
      c = /[?]/.test(a) ? "?" + b[1] : "";
    return {
      hk: b[0],
      params: c,
      fragment: /[#]/.test(a) ? "#" + (c ? b[2] : b[1]) : "",
    };
  }
  function kq(a) {
    var b = Qa.apply(1, arguments);
    if (b.length === 0) return sc(a[0]);
    for (var c = a[0], d = 0; d < b.length; d++)
      c += encodeURIComponent(b[d]) + a[d + 1];
    return sc(c);
  }
  function lq(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (k) {
              return e(k, h);
            })
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return sc(a + b + c);
  }
  function mq(a, b) {
    var c = jq(tc(a).toString()),
      d = c.hk.slice(-1) === "/" ? "" : "/",
      e = c.hk + d + encodeURIComponent(b);
    return sc(e + c.params + c.fragment);
  }
  var nq = function (a, b) {
      for (var c = a, d = 0; d < 50; ++d) {
        var e;
        try {
          e = !(!c.frames || !c.frames[b]);
        } catch (h) {
          e = !1;
        }
        if (e) return c;
        var f;
        a: {
          try {
            var g = c.parent;
            if (g && g !== c) {
              f = g;
              break a;
            }
          } catch (h) {}
          f = null;
        }
        if (!(c = f)) break;
      }
      return null;
    },
    oq = function (a) {
      var b = A;
      if (b.top == b) return 0;
      if (a === void 0 ? 0 : a) {
        var c = b.location.ancestorOrigins;
        if (c) return c[c.length - 1] == b.location.origin ? 1 : 2;
      }
      return eq(b.top) ? 1 : 2;
    },
    pq = function (a) {
      a = a === void 0 ? document : a;
      return a.createElement("img");
    };
  function qq(a) {
    for (
      var b = [],
        c = C.cookie.split(";"),
        d = new RegExp(
          "^\\s*" + (a || "_gac") + "_(UA-\\d+-\\d+)=\\s*(.+?)\\s*$"
        ),
        e = 0;
      e < c.length;
      e++
    ) {
      var f = c[e].match(d);
      f &&
        b.push({
          lf: f[1],
          value: f[2],
          timestamp: Number(f[2].split(".")[1]) || 0,
        });
    }
    b.sort(function (g, h) {
      return h.timestamp - g.timestamp;
    });
    return b;
  }
  function rq(a, b) {
    var c = qq(a),
      d = {};
    if (!c || !c.length) return d;
    for (var e = 0; e < c.length; e++) {
      var f = c[e].value.split(".");
      if (
        !(f[0] !== "1" || (b && f.length < 3) || (!b && f.length !== 3)) &&
        Number(f[1])
      ) {
        d[c[e].lf] || (d[c[e].lf] = []);
        var g = { version: f[0], timestamp: Number(f[1]) * 1e3, gclid: f[2] };
        b && f.length > 3 && (g.labels = f.slice(3));
        d[c[e].lf].push(g);
      }
    }
    return d;
  }
  function sq(a) {
    return a.origin !== "null";
  }
  var tq = {},
    uq =
      ((tq.k = { ma: /^[\w-]+$/ }),
      (tq.b = { ma: /^[\w-]+$/, Xj: !0 }),
      (tq.i = { ma: /^[1-9]\d*$/ }),
      (tq.h = { ma: /^\d+$/ }),
      (tq.t = { ma: /^[1-9]\d*$/ }),
      (tq.d = { ma: /^[A-Za-z0-9_-]+$/ }),
      (tq.j = { ma: /^\d+$/ }),
      (tq.u = { ma: /^[1-9]\d*$/ }),
      (tq.l = { ma: /^[01]$/ }),
      (tq.o = { ma: /^[1-9]\d*$/ }),
      (tq.g = { ma: /^[01]$/ }),
      (tq.s = { ma: /^.+$/ }),
      (tq.m = { ma: /^[01]$/ }),
      tq);
  var vq = {},
    zq =
      ((vq[5] = { versions: { 2: wq }, Jj: "2", Jh: ["k", "i", "b", "u"] }),
      (vq[4] = {
        versions: { 2: wq, GCL: xq },
        Jj: "2",
        Jh: ["k", "i", "b", "m"],
      }),
      (vq[2] = {
        versions: { GS2: wq, GS1: yq },
        Jj: "GS2",
        Jh: "sogtjlhd".split(""),
      }),
      vq);
  function Aq(a, b, c) {
    var d = zq[b];
    if (d) {
      var e = a.split(".")[0];
      c == null || c(e);
      if (e) {
        var f = d.versions[e];
        if (f) return f(a, b);
      }
    }
  }
  function wq(a, b) {
    var c = a.split(".");
    if (c.length === 3) {
      var d = c[2];
      if (d.indexOf("$") === -1 && d.indexOf("%24") !== -1)
        try {
          d = decodeURIComponent(d);
        } catch (t) {}
      var e = {},
        f = zq[b];
      if (f) {
        var g = f.Jh,
          h = n(d.split("$")),
          k = h.next();
        try {
          for (; !k.done; k = h.next()) {
            var m = k.value,
              p = m[0];
            if (g.indexOf(p) !== -1)
              try {
                var q = decodeURIComponent(m.substring(1)),
                  r = uq[p];
                r && (r.Xj ? ((e[p] = e[p] || []), e[p].push(q)) : (e[p] = q));
              } catch (t) {}
          }
        } finally {
          z(h, k);
        }
        return e;
      }
    }
  }
  function Bq(a, b, c) {
    var d = zq[b];
    if (d) return [d.Jj, c || "1", Cq(a, b)].join(".");
  }
  function Cq(a, b) {
    var c = zq[b];
    if (c) {
      var d = [],
        e = n(c.Jh),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value,
            h = uq[g];
          if (h) {
            var k = a[g];
            if (k !== void 0)
              if (h.Xj && Array.isArray(k)) {
                var m = n(k),
                  p = m.next();
                try {
                  for (; !p.done; p = m.next())
                    d.push(encodeURIComponent("" + g + p.value));
                } finally {
                  z(m, p);
                }
              } else d.push(encodeURIComponent("" + g + k));
          }
        }
      } finally {
        z(e, f);
      }
      return d.join("$");
    }
  }
  function xq(a) {
    var b = a.split(".");
    b.shift();
    var c = b.shift(),
      d = b.shift(),
      e = {};
    return (e.k = d), (e.i = c), (e.b = b), e;
  }
  function yq(a) {
    var b = a.split(".").slice(2);
    if (!(b.length < 5 || b.length > 7)) {
      var c = {};
      return (
        (c.s = b[0]),
        (c.o = b[1]),
        (c.g = b[2]),
        (c.t = b[3]),
        (c.j = b[4]),
        (c.l = b[5]),
        (c.h = b[6]),
        c
      );
    }
  }
  function Dq(a, b, c, d) {
    var e;
    return (e = Eq(
      function (f) {
        return f === a;
      },
      b,
      c,
      d
    )[a]) != null
      ? e
      : [];
  }
  function Eq(a, b, c, d) {
    var e;
    if (Fq(d)) {
      for (
        var f = {}, g = String(b || Gq()).split(";"), h = 0;
        h < g.length;
        h++
      ) {
        var k = g[h].split("="),
          m = k[0].trim();
        if (m && a(m)) {
          var p = k.slice(1).join("=").trim();
          p && c && (p = decodeURIComponent(p));
          var q = void 0,
            r = void 0;
          ((q = f)[(r = m)] || (q[r] = [])).push(p);
        }
      }
      e = f;
    } else e = {};
    return e;
  }
  function Hq(a, b, c, d, e) {
    if (Fq(e)) {
      var f = Iq(a, d, e);
      if (f.length === 1) return f[0];
      if (f.length !== 0) {
        f = Jq(
          f,
          function (g) {
            return g.Aq;
          },
          b
        );
        if (f.length === 1) return f[0];
        f = Jq(
          f,
          function (g) {
            return g.Mr;
          },
          c
        );
        return f[0];
      }
    }
  }
  function Kq(a, b, c, d) {
    var e = Gq(),
      f = A;
    sq(f) && (f.document.cookie = a);
    var g = Gq();
    return e !== g || (c !== void 0 && Dq(b, g, !1, d).indexOf(c) >= 0);
  }
  function Lq(a, b, c, d) {
    function e(x, y, B) {
      if (B == null) return delete h[y], x;
      h[y] = B;
      return x + "; " + y + "=" + B;
    }
    function f(x, y) {
      if (y == null) return x;
      h[y] = !0;
      return x + "; " + y;
    }
    if (!Fq(c.Hc)) return 2;
    var g;
    b == null
      ? (g = a + "=deleted; expires=" + new Date(0).toUTCString())
      : (c.encode && (b = encodeURIComponent(b)),
        (b = Mq(b)),
        (g = a + "=" + b));
    var h = {};
    g = e(g, "path", c.path);
    var k;
    c.expires instanceof Date
      ? (k = c.expires.toUTCString())
      : c.expires != null && (k = "" + c.expires);
    g = e(g, "expires", k);
    g = e(g, "max-age", c.Dr);
    g = e(g, "samesite", c.ds);
    c.secure && (g = f(g, "secure"));
    var m = c.domain;
    if (m && m.toLowerCase() === "auto") {
      for (var p = Nq(), q = void 0, r = !1, t = 0; t < p.length; ++t) {
        var u = p[t] !== "none" ? p[t] : void 0,
          v = e(g, "domain", u);
        v = f(v, c.flags);
        try {
          d && d(a, h);
        } catch (x) {
          q = x;
          continue;
        }
        r = !0;
        if (!Oq(u, c.path) && Kq(v, a, b, c.Hc)) return 0;
      }
      if (q && !r) throw q;
      return 1;
    }
    m && m.toLowerCase() !== "none" && (g = e(g, "domain", m));
    g = f(g, c.flags);
    d && d(a, h);
    return Oq(m, c.path) ? 1 : Kq(g, a, b, c.Hc) ? 0 : 1;
  }
  function Pq(a, b, c) {
    c.path == null && (c.path = "/");
    c.domain || (c.domain = "auto");
    return Lq(a, b, c);
  }
  function Jq(a, b, c) {
    for (var d = [], e = [], f, g = 0; g < a.length; g++) {
      var h = a[g],
        k = b(h);
      k === c
        ? d.push(h)
        : f === void 0 || k < f
        ? ((e = [h]), (f = k))
        : k === f && e.push(h);
    }
    return d.length > 0 ? d : e;
  }
  function Iq(a, b, c) {
    for (var d = [], e = Dq(a, void 0, void 0, c), f = 0; f < e.length; f++) {
      var g = e[f].split("."),
        h = g.shift();
      if (!b || !h || b.indexOf(h) !== -1) {
        var k = g.shift();
        if (k) {
          var m = k.split("-");
          d.push({
            rq: e[f],
            sq: g.join("."),
            Aq: Number(m[0]) || 1,
            Mr: Number(m[1]) || 1,
          });
        }
      }
    }
    return d;
  }
  function Mq(a) {
    a && a.length > 1200 && (a = a.substring(0, 1200));
    return a;
  }
  var Qq = /^(www\.)?google(\.com?)?(\.[a-z]{2})?$/,
    Rq = /(^|\.)doubleclick\.net$/i;
  function Oq(a, b) {
    return (
      a !== void 0 &&
      (Rq.test(A.document.location.hostname) || (b === "/" && Qq.test(a)))
    );
  }
  function Sq(a) {
    if (!a) return 1;
    var b = a;
    Mh(3) && a === "none" && (b = A.document.location.hostname);
    b = b.indexOf(".") === 0 ? b.substring(1) : b;
    return b.split(".").length;
  }
  function Tq(a) {
    if (!a || a === "/") return 1;
    a[0] !== "/" && (a = "/" + a);
    a[a.length - 1] !== "/" && (a += "/");
    return a.split("/").length - 1;
  }
  function Uq(a, b) {
    var c = "" + Sq(a),
      d = Tq(b);
    d > 1 && (c += "-" + d);
    return c;
  }
  var Gq = function () {
      var a = A;
      return sq(a) ? a.document.cookie : "";
    },
    Fq = function (a) {
      return a && Mh(4)
        ? (Array.isArray(a) ? a : [a]).every(function (b) {
            return Qm(b) && Om(b);
          })
        : !0;
    },
    Nq = function () {
      var a = [],
        b = A.document.location.hostname.split(".");
      if (b.length === 4) {
        var c = b[b.length - 1];
        if (Number(c).toString() === c) return ["none"];
      }
      for (var d = b.length - 2; d >= 0; d--) a.push(b.slice(d).join("."));
      var e = A.document.location.hostname;
      Rq.test(e) || Qq.test(e) || a.push("none");
      return a;
    };
  function Vq(a, b, c, d) {
    var e,
      f = Number(a.pd != null ? a.pd : void 0);
    f !== 0 && (e = new Date((b || Wb()) + 1e3 * (f || 7776e3)));
    return {
      path: a.path,
      domain: a.domain,
      flags: a.flags,
      encode: !!c,
      expires: e,
      Hc: d,
    };
  }
  var Wq = new Map([
    [5, "ad_storage"],
    [4, ["ad_storage", "ad_user_data"]],
    [2, "analytics_storage"],
  ]);
  function Xq(a, b, c) {
    if (zq[b]) {
      var d = [],
        e = Dq(a, void 0, void 0, Wq.get(b)),
        f = n(e),
        g = f.next();
      try {
        for (; !g.done; g = f.next()) {
          var h = Aq(g.value, b, c);
          h && d.push(Yq(h));
        }
      } finally {
        z(f, g);
      }
      return d;
    }
  }
  function Zq(a) {
    var b = $q;
    if (zq[2]) {
      var c = {},
        d = Eq(a, void 0, void 0, Wq.get(2)),
        e = Object.keys(d).sort(),
        f = n(e),
        g = f.next();
      try {
        for (; !g.done; g = f.next()) {
          var h = g.value,
            k = n(d[h]),
            m = k.next();
          try {
            for (; !m.done; m = k.next()) {
              var p = Aq(m.value, 2, b);
              p && (c[h] || (c[h] = []), c[h].push(Yq(p)));
            }
          } finally {
            z(k, m);
          }
        }
      } finally {
        z(f, g);
      }
      return c;
    }
  }
  function ar(a, b, c, d, e) {
    d = d || {};
    var f = Uq(d.domain, d.path),
      g = Bq(b, c, f);
    if (!g) return 1;
    var h = Vq(d, e, void 0, Wq.get(c));
    return Pq(a, g, h);
  }
  function br(a, b) {
    var c = b.ma;
    return typeof c === "function" ? c(a) : c.test(a);
  }
  function Yq(a) {
    var b = n(Object.keys(a)),
      c = b.next();
    try {
      for (var d = {}; !c.done; d = { ug: void 0 }, c = b.next()) {
        var e = c.value,
          f = a[e];
        d.ug = uq[e];
        d.ug
          ? d.ug.Xj
            ? Array.isArray(f)
              ? (a[e] = f.filter(
                  (function (g) {
                    return function (h) {
                      return br(h, g.ug);
                    };
                  })(d)
                ))
              : (a[e] = void 0)
            : (typeof f === "string" && br(f, d.ug)) || (a[e] = void 0)
          : (a[e] = void 0);
      }
    } finally {
      z(b, c);
    }
    return a;
  }
  var cr;
  function dr() {
    function a(g) {
      c(g.target || g.srcElement || {});
    }
    function b(g) {
      d(g.target || g.srcElement || {});
    }
    var c = er,
      d = fr,
      e = gr();
    if (!e.init) {
      id(C, "mousedown", a);
      id(C, "keyup", a);
      id(C, "submit", b);
      var f = HTMLFormElement.prototype.submit;
      HTMLFormElement.prototype.submit = function () {
        d(this);
        f.call(this);
      };
      e.init = !0;
    }
  }
  function hr(a, b, c, d, e) {
    var f = {
      callback: a,
      domains: b,
      fragment: c === 2,
      placement: c,
      forms: d,
      sameHost: e,
    };
    gr().decorators.push(f);
  }
  function ir(a, b, c) {
    for (var d = gr().decorators, e = {}, f = 0; f < d.length; ++f) {
      var g = d[f],
        h;
      if ((h = !c || g.forms))
        a: {
          var k = g.domains,
            m = a,
            p = !!g.sameHost;
          if (k && (p || m !== C.location.hostname))
            for (var q = 0; q < k.length; q++)
              if (k[q] instanceof RegExp) {
                if (k[q].test(m)) {
                  h = !0;
                  break a;
                }
              } else if (m.indexOf(k[q]) >= 0 || (p && k[q].indexOf(m) >= 0)) {
                h = !0;
                break a;
              }
          h = !1;
        }
      if (h) {
        var r = g.placement;
        r === void 0 && (r = g.fragment ? 2 : 1);
        r === b && Yb(e, g.callback());
      }
    }
    return e;
  }
  function gr() {
    var a = Vc("google_tag_data", {}),
      b = a.gl;
    (b && b.decorators) || ((b = { decorators: [] }), (a.gl = b));
    return b;
  }
  var jr = /(.*?)\*(.*?)\*(.*)/,
    kr = /^https?:\/\/([^\/]*?)\.?cdn\.ampproject\.org\/?(.*)/,
    lr = /^(?:www\.|m\.|amp\.)+/,
    mr = /([^?#]+)(\?[^#]*)?(#.*)?/;
  function nr(a) {
    var b = mr.exec(a);
    if (b) return { Pj: b[1], query: b[2], fragment: b[3] };
  }
  function or(a) {
    return new RegExp("(.*?)(^|&)" + a + "=([^&]*)&?(.*)");
  }
  function pr(a, b) {
    b = b === void 0 ? 0 : b;
    var c = Wb(),
      d = [
        Qc.userAgent,
        new Date().getTimezoneOffset(),
        Qc.userLanguage || Qc.language,
        Math.floor(c / 60 / 1e3) - b,
        a,
      ].join("*"),
      e;
    if (!(e = cr)) {
      for (var f = Array(256), g = 0; g < 256; g++) {
        for (var h = g, k = 0; k < 8; k++)
          h = h & 1 ? (h >>> 1) ^ 3988292384 : h >>> 1;
        f[g] = h;
      }
      e = f;
    }
    cr = e;
    for (var m = 4294967295, p = 0; p < d.length; p++)
      m = (m >>> 8) ^ cr[(m ^ d.charCodeAt(p)) & 255];
    return ((m ^ -1) >>> 0).toString(36);
  }
  function qr(a) {
    return function (b) {
      var c = Fj(A.location.href),
        d = c.search.replace("?", ""),
        e = wj(d, "_gl", !1, !0) || "";
      b.query = rr(e) || {};
      var f = zj(c, "fragment"),
        g;
      var h = -1;
      if ($b(f, "_gl=")) h = 4;
      else {
        var k = f.indexOf("&_gl=");
        k > 0 && (h = k + 3 + 2);
      }
      if (h < 0) g = void 0;
      else {
        var m = f.indexOf("&", h);
        g = m < 0 ? f.substring(h) : f.substring(h, m);
      }
      b.fragment = rr(g || "") || {};
      a && sr(c, d, f);
    };
  }
  function tr(a, b) {
    var c = or(a).exec(b),
      d = b;
    if (c) {
      var e = c[2],
        f = c[4];
      d = c[1];
      f && (d = d + e + f);
    }
    return d;
  }
  function sr(a, b, c) {
    function d(g, h) {
      var k = tr("_gl", g);
      k.length && (k = h + k);
      return k;
    }
    if (Pc && Pc.replaceState) {
      var e = or("_gl");
      if (e.test(b) || e.test(c)) {
        var f = zj(a, "path");
        b = d(b, "?");
        c = d(c, "#");
        Pc.replaceState({}, "", "" + f + b + c);
      }
    }
  }
  function ur(a, b) {
    var c = qr(!!b),
      d = gr();
    d.data || ((d.data = { query: {}, fragment: {} }), c(d.data));
    var e = {},
      f = d.data;
    f && (Yb(e, f.query), a && Yb(e, f.fragment));
    return e;
  }
  var rr = function (a) {
    try {
      var b = vr(a, 3);
      if (b !== void 0) {
        for (
          var c = {}, d = b ? b.split("*") : [], e = 0;
          e + 1 < d.length;
          e += 2
        ) {
          var f = d[e],
            g = tb(d[e + 1]);
          c[f] = g;
        }
        wb("TAGGING", 6);
        return c;
      }
    } catch (h) {
      wb("TAGGING", 8);
    }
  };
  function vr(a, b) {
    if (a) {
      var c;
      a: {
        for (var d = a, e = 0; e < 3; ++e) {
          var f = jr.exec(d);
          if (f) {
            c = f;
            break a;
          }
          d = yj(d) || "";
        }
        c = void 0;
      }
      var g = c;
      if (g && g[1] === "1") {
        var h = g[3],
          k;
        a: {
          for (var m = g[2], p = 0; p < b; ++p)
            if (m === pr(h, p)) {
              k = !0;
              break a;
            }
          k = !1;
        }
        if (k) return h;
        wb("TAGGING", 7);
      }
    }
  }
  function wr(a, b, c, d, e) {
    function f(p) {
      p = tr(a, p);
      var q = p.charAt(p.length - 1);
      p && q !== "&" && (p += "&");
      return p + m;
    }
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var g = nr(c);
    if (!g) return "";
    var h = g.query || "",
      k = g.fragment || "",
      m = a + "=" + b;
    d
      ? (k.substring(1).length !== 0 && e) || (k = "#" + f(k.substring(1)))
      : (h = "?" + f(h.substring(1)));
    return "" + g.Pj + h + k;
  }
  function xr(a, b) {
    function c(m, p, q) {
      var r;
      a: {
        for (var t in m)
          if (m.hasOwnProperty(t)) {
            r = !0;
            break a;
          }
        r = !1;
      }
      if (r) {
        var u,
          v = [],
          x;
        for (x in m)
          if (m.hasOwnProperty(x)) {
            var y = m[x];
            y !== void 0 &&
              y === y &&
              y !== null &&
              y.toString() !== "[object Object]" &&
              (v.push(x), v.push(sb(String(y))));
          }
        var B = v.join("*");
        u = ["1", pr(B), B].join("*");
        d ? (Mh(1) || !p) && yr("_gl", u, a, p, q) : zr("_gl", u, a, p, q);
      }
    }
    var d = (a.tagName || "").toUpperCase() === "FORM",
      e = ir(b, 1, d),
      f = ir(b, 2, d),
      g = ir(b, 4, d),
      h = ir(b, 3, d);
    c(e, !1, !1);
    c(f, !0, !1);
    Mh(1) && c(g, !0, !0);
    for (var k in h) h.hasOwnProperty(k) && Ar(k, h[k], a);
  }
  function Ar(a, b, c) {
    c.tagName.toLowerCase() === "a"
      ? zr(a, b, c)
      : c.tagName.toLowerCase() === "form" && yr(a, b, c);
  }
  function zr(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    var f;
    if ((f = c.href)) {
      var g;
      if (!(g = d)) {
        var h = A.location.href,
          k = nr(c.href),
          m = nr(h);
        g = !(k && m && k.Pj === m.Pj && k.query === m.query && k.fragment);
      }
      f = g;
    }
    if (f) {
      var p = wr(a, b, c.href, d, e);
      Ec.test(p) && (c.href = p);
    }
  }
  function yr(a, b, c, d, e) {
    d = d === void 0 ? !1 : d;
    e = e === void 0 ? !1 : e;
    if (c) {
      var f = c.getAttribute("action") || "";
      if (f) {
        var g = (c.method || "").toLowerCase();
        if (g !== "get" || d) {
          if (g === "get" || g === "post") {
            var h = wr(a, b, f, d, e);
            Ec.test(h) && (c.action = h);
          }
        } else {
          for (var k = c.childNodes || [], m = !1, p = 0; p < k.length; p++) {
            var q = k[p];
            if (q.name === a) {
              q.setAttribute("value", b);
              m = !0;
              break;
            }
          }
          if (!m) {
            var r = C.createElement("input");
            r.setAttribute("type", "hidden");
            r.setAttribute("name", a);
            r.setAttribute("value", b);
            c.appendChild(r);
          }
        }
      }
    }
  }
  function er(a) {
    try {
      var b;
      a: {
        for (var c = a, d = 100; c && d > 0; ) {
          if (c.href && c.nodeName.match(/^a(?:rea)?$/i)) {
            b = c;
            break a;
          }
          c = c.parentNode;
          d--;
        }
        b = null;
      }
      var e = b;
      if (e) {
        var f = e.protocol;
        (f !== "http:" && f !== "https:") || xr(e, e.hostname);
      }
    } catch (g) {}
  }
  function fr(a) {
    try {
      var b = a.getAttribute("action");
      if (b) {
        var c = zj(Fj(b), "host");
        xr(a, c);
      }
    } catch (d) {}
  }
  function Br(a, b, c, d) {
    dr();
    var e = c === "fragment" ? 2 : 1;
    d = !!d;
    hr(a, b, e, d, !1);
    e === 2 && wb("TAGGING", 23);
    d && wb("TAGGING", 24);
  }
  function Cr(a, b) {
    dr();
    hr(a, [Bj(A.location, "host", !0)], b, !0, !0);
  }
  function Dr() {
    var a = C.location.hostname,
      b = kr.exec(C.referrer);
    if (!b) return !1;
    var c = b[2],
      d = b[1],
      e = "";
    if (c) {
      var f = c.split("/"),
        g = f[1];
      e = g === "s" ? yj(f[2]) || "" : yj(g) || "";
    } else if (d) {
      if (d.indexOf("xn--") === 0) return !1;
      e = d.replace(/-/g, ".").replace(/\.\./g, "-");
    }
    var h = a.replace(lr, ""),
      k = e.replace(lr, "");
    return h === k || ac(h, "." + k);
  }
  function Er(a, b) {
    return a === !1 ? !1 : a || b || Dr();
  }
  var Fr = function (a) {
    a = a === void 0 ? 0 : a;
    this.value = 0;
    this.value = a;
  };
  Fr.prototype.set = function (a) {
    return (this.value |= 1 << a);
  };
  var Gr = function (a, b) {
    b <= 0 || (a.value |= 1 << (b - 1));
  };
  l = Fr.prototype;
  l.get = function () {
    return this.value;
  };
  l.isSet = function (a) {
    return (this.value & (1 << a)) !== 0;
  };
  l.clear = function (a) {
    this.value &= ~(1 << a);
  };
  l.clearAll = function () {
    this.value = 0;
  };
  l.equals = function (a) {
    return this.value === a.value;
  };
  function Hr(a) {
    if (a)
      try {
        return new Uint8Array(
          atob(a.replace(/-/g, "+").replace(/_/g, "/"))
            .split("")
            .map(function (b) {
              return b.charCodeAt(0);
            })
        );
      } catch (b) {}
  }
  function Ir(a, b) {
    var c = 0,
      d = 0,
      e,
      f = b;
    do {
      if (f >= a.length) return;
      e = a[f++];
      c |= (e & 127) << d;
      d += 7;
    } while (e & 128);
    return [c, f];
  }
  function Jr() {
    var a = String,
      b = A.location.hostname,
      c = A.location.pathname,
      d = (b = jc(b));
    d.split(".").length > 2 &&
      (d = d.replace(/^(www[0-9]*|web|ftp|wap|home|m|w|amp|mobile)\./, ""));
    b = d;
    c = jc(c);
    var e = c.split(";")[0];
    e = e.replace(/\/(ar|slp|web|index)?\/?$/, "");
    return a(dg(("" + b + e).toLowerCase()));
  }
  var Kr = ["ad_storage", "ad_user_data"];
  function Lr(a, b) {
    if (!a) return wb("TAGGING", 32), 10;
    if (b === null || b === void 0 || b === "") return wb("TAGGING", 33), 11;
    var c = Mr(!1);
    if (c.error !== 0) return wb("TAGGING", 34), c.error;
    if (!c.value) return wb("TAGGING", 35), 2;
    c.value[a] = b;
    var d = Nr(c);
    d !== 0 && wb("TAGGING", 36);
    return d;
  }
  function Or(a) {
    if (!a) return wb("TAGGING", 27), { error: 10 };
    var b = Mr();
    if (b.error !== 0) return wb("TAGGING", 29), b;
    if (!b.value) return wb("TAGGING", 30), { error: 2 };
    if (!(a in b.value)) return wb("TAGGING", 31), { value: void 0, error: 15 };
    var c = b.value[a];
    return c === null || c === void 0 || c === ""
      ? (wb("TAGGING", 28), { value: void 0, error: 11 })
      : { value: c, error: 0 };
  }
  function Pr(a) {
    if (a) {
      var b = Mr(!1);
      b.error !== 0
        ? wb("TAGGING", 38)
        : b.value
        ? a in b.value
          ? (delete b.value[a], Nr(b) !== 0 && wb("TAGGING", 41))
          : wb("TAGGING", 40)
        : wb("TAGGING", 39);
    } else wb("TAGGING", 37);
  }
  function Mr(a) {
    a = a === void 0 ? !0 : a;
    if (!Om(Kr)) return wb("TAGGING", 43), { error: 3 };
    try {
      if (!A.localStorage) return wb("TAGGING", 44), { error: 1 };
    } catch (f) {
      return wb("TAGGING", 45), { error: 14 };
    }
    var b = { schema: "gcl", version: 1 },
      c = void 0;
    try {
      c = A.localStorage.getItem("_gcl_ls");
    } catch (f) {
      return wb("TAGGING", 46), { error: 13 };
    }
    try {
      if (c) {
        var d = JSON.parse(c);
        if (d && typeof d === "object") b = d;
        else return wb("TAGGING", 47), { error: 12 };
      }
    } catch (f) {
      return wb("TAGGING", 48), { error: 8 };
    }
    if (b.schema !== "gcl") return wb("TAGGING", 49), { error: 4 };
    if (b.version !== 1) return wb("TAGGING", 50), { error: 5 };
    try {
      var e = Qr(b);
      a && e && Nr({ value: b, error: 0 });
    } catch (f) {
      return wb("TAGGING", 48), { error: 8 };
    }
    return { value: b, error: 0 };
  }
  function Qr(a) {
    if (!a || typeof a !== "object") return !1;
    if ("expires" in a && "value" in a) {
      var b;
      typeof a.expires === "number"
        ? (b = a.expires)
        : (b = typeof a.expires === "string" ? Number(a.expires) : NaN);
      if (isNaN(b) || !(Date.now() <= b))
        return (a.value = null), (a.error = 9), wb("TAGGING", 54), !0;
    } else {
      var c = !1,
        d = n(Object.keys(a)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) c = Qr(a[e.value]) || c;
      } finally {
        z(d, e);
      }
      return c;
    }
    return !1;
  }
  function Nr(a) {
    if (a.error) return a.error;
    if (!a.value) return wb("TAGGING", 42), 2;
    var b = a.value,
      c;
    try {
      c = JSON.stringify(b);
    } catch (d) {
      return wb("TAGGING", 52), 6;
    }
    try {
      A.localStorage.setItem("_gcl_ls", c);
    } catch (d) {
      return wb("TAGGING", 53), 7;
    }
    return 0;
  }
  var Rr = {},
    Sr =
      ((Rr.gclid = !0),
      (Rr.dclid = !0),
      (Rr.gbraid = !0),
      (Rr.wbraid = !0),
      Rr),
    Tr = /^\w+$/,
    Ur = /^[\w-]+$/,
    Vr = {},
    Wr = ((Vr.aw = "FPGCLAW"), Vr),
    Xr = {},
    Yr =
      ((Xr.ag = "_ag"),
      (Xr.gb = "_gb"),
      (Xr.aw = "_aw"),
      (Xr.dc = "_dc"),
      (Xr.gf = "_gf"),
      (Xr.ha = "_ha"),
      (Xr.gp = "_gp"),
      (Xr.gs = "_gs"),
      Xr),
    Zr = /^(?:www\.)?google(?:\.com?)?(?:\.[a-z]{2}t?)?$/,
    $r = /^www\.googleadservices\.com$/;
  function as() {
    return ["ad_storage", "ad_user_data"];
  }
  function bs(a) {
    return !Mh(4) || Om(a);
  }
  function cs(a, b) {
    function c() {
      var d = bs(b);
      d && a();
      return d;
    }
    Um(function () {
      c() || Vm(c, b);
    }, b);
  }
  function ds(a) {
    return es(a).map(function (b) {
      return b.gclid;
    });
  }
  function gs(a) {
    return hs(a)
      .filter(function (b) {
        return b.gclid;
      })
      .map(function (b) {
        return b.gclid;
      });
  }
  function hs(a, b) {
    b = b === void 0 ? !1 : b;
    var c = is(a.prefix),
      d = js("gb", c),
      e = js("ag", c);
    if (!e || !d) return [];
    var f = function (k) {
        return function (m) {
          m.sg = k;
          return m;
        };
      },
      g = es(d, b).map(f("gb")),
      h = ks(e).map(f("ag"));
    return g.concat(h).sort(function (k, m) {
      return m.timestamp - k.timestamp;
    });
  }
  function ls(a, b, c, d, e) {
    var f = Mb(a, function (g) {
      return g.gclid === b;
    });
    f
      ? (f.timestamp < c && ((f.timestamp = c), (f.od = e)),
        (f.labels = ms(f.labels || [], d || [])))
      : a.push({ version: "2", gclid: b, timestamp: c, labels: d, od: e });
  }
  function ns(a) {
    var b = Xq(a, 5) || [],
      c = [],
      d = n(b),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = e.value,
          g = f,
          h = ps(f);
        h && ls(c, g.k, h, g.b || [], f.u);
      }
    } finally {
      z(d, e);
    }
    return c.sort(function (k, m) {
      return m.timestamp - k.timestamp;
    });
  }
  function es(a, b) {
    b = b === void 0 ? !1 : b;
    var c = [];
    qs(c, a, 1);
    if (b)
      if (ac(a, "_aw")) {
        var d = rs();
        d && ((d.od = void 0), (d.qa = d.qa || [2]), ss(c, d));
        qs(c, "gcl_aw", 2);
      } else ac(a, "_gb") && qs(c, "gcl_gb", 2);
    c.sort(function (e, f) {
      return f.timestamp - e.timestamp;
    });
    return ts(c);
  }
  function us(a, b) {
    var c = [],
      d = n(a),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = e.value;
        c.includes(f) || c.push(f);
      }
    } finally {
      z(d, e);
    }
    var g = n(b),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = h.value;
        c.includes(k) || c.push(k);
      }
    } finally {
      z(g, h);
    }
    return c;
  }
  function ss(a, b, c) {
    c = c === void 0 ? !1 : c;
    var d,
      e,
      f = n(a),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = g.value;
        if (h.gclid === b.gclid) {
          d = h;
          break;
        }
        h.oa && b.oa && h.oa.equals(b.oa) && (e = h);
      }
    } finally {
      z(f, g);
    }
    if (d) {
      var k = d,
        m,
        p,
        q = (m = d.oa) != null ? m : new Fr(),
        r = (p = b.oa) != null ? p : new Fr();
      q.value |= r.value;
      k.oa = q;
      d.timestamp < b.timestamp && ((d.timestamp = b.timestamp), (d.od = b.od));
      d.labels = us(d.labels || [], b.labels || []);
      d.qa = us(d.qa || [], b.qa || []);
    } else c && e ? ma(Object, "assign").call(Object, e, b) : a.push(b);
  }
  function vs(a) {
    if (!a) return new Fr();
    var b = new Fr();
    if (a === 1) return Gr(b, 2), Gr(b, 3), b;
    Gr(b, a);
    return b;
  }
  function rs() {
    var a = Or("gclid");
    if (!a || a.error || !a.value || typeof a.value !== "object") return null;
    var b = a.value;
    try {
      if (!("value" in b && b.value) || typeof b.value !== "object")
        return null;
      var c = b.value,
        d = c.value;
      if (!d || !d.match(Ur)) return null;
      var e = c.linkDecorationSource,
        f = c.linkDecorationSources,
        g = new Fr();
      typeof e === "number"
        ? (g = vs(e))
        : typeof f === "number" && (g.value = f);
      return {
        version: "",
        gclid: d,
        timestamp: Number(c.creationTimeMs) || 0,
        labels: [],
        oa: g,
        qa: [2],
      };
    } catch (h) {
      return null;
    }
  }
  function ws(a) {
    var b = Or(a);
    if (b.error !== 0) return null;
    try {
      return b.value.reduce(function (c, d) {
        if (!d.value || typeof d.value !== "object") return c;
        var e = d.value,
          f = e.value;
        if (!f || !f.match(Ur)) return c;
        var g = new Fr(),
          h = e.linkDecorationSources;
        typeof h === "number" && (g.value = h);
        var k;
        c.push({
          version: "",
          gclid: f,
          timestamp: Number(e.creationTimeMs) || 0,
          expires: Number(d.expires) || 0,
          labels: (k = e.labels) != null ? k : [],
          oa: g,
          qa: [2],
        });
        return c;
      }, []);
    } catch (c) {
      return null;
    }
  }
  function qs(a, b, c) {
    if (c === 1) {
      var d = Dq(b, C.cookie, void 0, as()),
        e = n(d),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = xs(f.value.split(".")),
            h =
              g.length === 0
                ? null
                : {
                    version: g[0],
                    gclid: g[2],
                    timestamp: (Number(g[1]) || 0) * 1e3,
                    labels: g.slice(3),
                  };
          h != null &&
            ((h.od = void 0), (h.oa = new Fr()), (h.qa = [c]), ss(a, h));
        }
      } finally {
        z(e, f);
      }
    } else if (c === 2) {
      var k = ws(b);
      if (k) {
        var m = n(k),
          p = m.next();
        try {
          for (; !p.done; p = m.next()) {
            var q = p.value;
            q.od = void 0;
            ss(a, q);
          }
        } finally {
          z(m, p);
        }
      }
    }
  }
  function ys(a) {
    var b = es(a),
      c = ws("gcl_dc");
    if (c) {
      var d = n(c),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = e.value;
          f.od = void 0;
          f.qa = f.qa || [2];
          ss(b, f);
        }
      } finally {
        z(d, e);
      }
    }
    b.sort(function (g, h) {
      var k = g.qa && g.qa.includes(1),
        m = h.qa && h.qa.includes(1);
      return k && !m ? -1 : !k && m ? 1 : h.timestamp - g.timestamp;
    });
    return ts(b);
  }
  function ks(a) {
    return ns(a).map(function (b) {
      b.oa = new Fr();
      b.qa = [1];
      return b;
    });
  }
  function ms(a, b) {
    if (!a.length) return b;
    if (!b.length) return a;
    var c = {};
    return a.concat(b).filter(function (d) {
      return c.hasOwnProperty(d) ? !1 : (c[d] = !0);
    });
  }
  function is(a) {
    return a && typeof a === "string" && a.match(Tr) ? a : "_gcl";
  }
  function zs(a, b) {
    if (a) {
      var c = { value: a, oa: new Fr() };
      Gr(c.oa, b);
      return c;
    }
  }
  function As(a, b, c) {
    var d = Fj(a),
      e = zj(d, "query", !1, void 0, "gclsrc"),
      f = zs(zj(d, "query", !1, void 0, "gclid"), c ? 4 : 2);
    if (b && (!f || !e)) {
      var g = d.hash.replace("#", "");
      f || (f = zs(wj(g, "gclid", !1), 3));
      e || (e = wj(g, "gclsrc", !1));
    }
    return !f || (e !== void 0 && e !== "aw" && e !== "aw.ds") ? [] : [f];
  }
  function Bs(a, b) {
    var c = Fj(a),
      d = zj(c, "query", !1, void 0, "gclid"),
      e = zj(c, "query", !1, void 0, "gclsrc"),
      f = zj(c, "query", !1, void 0, "wbraid");
    f = hc(f);
    var g = zj(c, "query", !1, void 0, "gbraid"),
      h = zj(c, "query", !1, void 0, "gad_source"),
      k = zj(c, "query", !1, void 0, "dclid");
    if (b && !(d && e && f && g)) {
      var m = c.hash.replace("#", "");
      d = d || wj(m, "gclid", !1);
      e = e || wj(m, "gclsrc", !1);
      f = f || wj(m, "wbraid", !1);
      g = g || wj(m, "gbraid", !1);
      h = h || wj(m, "gad_source", !1);
    }
    return Cs(d, e, k, f, g, h);
  }
  function Ds(a, b, c) {
    var d = Fj(a),
      e = zj(d, "query", !1, void 0, "gclsrc"),
      f = zs(zj(d, "query", !1, void 0, "gclid"), c ? 4 : 2),
      g = zs(zj(d, "query", !1, void 0, "dclid"), c ? 4 : 2);
    if (b && (!e || !f)) {
      var h = d.hash.replace("#", "");
      f || (f = zs(wj(h, "gclid", !1), 3));
      e || (e = wj(h, "gclsrc", !1));
    }
    return f && e && (e === "aw.ds" || e === "3p.ds" || e === "ds")
      ? [f]
      : g
      ? [g]
      : [];
  }
  function Es() {
    return Bs(A.location.href, !0);
  }
  function Cs(a, b, c, d, e, f) {
    var g = {},
      h = function (k, m) {
        g[m] || (g[m] = []);
        g[m].push(k);
      };
    g.gclid = a;
    g.gclsrc = b;
    g.dclid = c;
    if (a !== void 0 && a.match(Ur))
      switch (b) {
        case void 0:
          h(a, "aw");
          break;
        case "aw.ds":
          h(a, "aw");
          h(a, "dc");
          break;
        case "ds":
          h(a, "dc");
          break;
        case "3p.ds":
          h(a, "dc");
          break;
        case "gf":
          h(a, "gf");
          break;
        case "ha":
          h(a, "ha");
      }
    c && h(c, "dc");
    d !== void 0 && Ur.test(d) && ((g.wbraid = d), h(d, "gb"));
    e !== void 0 && Ur.test(e) && ((g.gbraid = e), h(e, "ag"));
    f !== void 0 && Ur.test(f) && ((g.gad_source = f), h(f, "gs"));
    return g;
  }
  function Fs() {
    var a = Es(),
      b = !0,
      c = n(Object.keys(a)),
      d = c.next();
    try {
      for (; !d.done; d = c.next())
        if (a[d.value] !== void 0) {
          b = !1;
          break;
        }
    } finally {
      z(c, d);
    }
    b && ((a = Bs(A.document.referrer, !1)), (a.gad_source = void 0));
    return a;
  }
  function Gs(a) {
    var b = Fs();
    Hs(b, !1, a);
  }
  function Is(a) {
    var b = As(A.location.href, !0, !1);
    b.length || (b = As(A.document.referrer, !1, !0));
    a = a || {};
    Js(a);
    if (b.length) {
      var c = b[0],
        d = Wb(),
        e = Vq(a, d, !0),
        f = as(),
        g = function () {
          bs(f) &&
            e.expires !== void 0 &&
            Lr("gclid", {
              value: {
                value: c.value,
                creationTimeMs: d,
                linkDecorationSources: c.oa.get(),
              },
              expires: Number(e.expires),
            });
        };
      Um(function () {
        g();
        bs(f) || Vm(g, f);
      }, f);
    }
  }
  function Js(a) {
    var b = C.referrer ? zj(Fj(C.referrer), "host") : "";
    if (Zr.test(b) || $r.test(b) || Ks()) {
      var c;
      a: {
        var d = Fj(A.location.href),
          e = xj(zj(d, "query")),
          f = n(Object.keys(e)),
          g = f.next();
        try {
          for (; !g.done; g = f.next()) {
            var h = g.value;
            if (!Sr[h]) {
              var k = e[h][0] || "",
                m;
              if (!k || k.length < 50 || k.length > 200) m = !1;
              else {
                var p = Hr(k),
                  q;
                if (p)
                  c: {
                    var r = void 0,
                      t = p;
                    if (t && t.length !== 0) {
                      var u = 0;
                      try {
                        for (var v = 10; u < t.length && !(v-- <= 0); ) {
                          r = Ir(t, u);
                          if (r === void 0) break;
                          var x = n(r),
                            y = x.next().value,
                            B = x.next().value,
                            E = y,
                            F = B,
                            G = E & 7;
                          if (E >> 3 === 16382) {
                            if (G !== 0) break;
                            var I = Ir(t, F);
                            if (I === void 0) break;
                            q = n(I).next().value === 1;
                            break c;
                          }
                          var J;
                          d: {
                            var M = void 0,
                              U = t,
                              W = F;
                            switch (G) {
                              case 0:
                                J = (M = Ir(U, W)) == null ? void 0 : M[1];
                                break d;
                              case 1:
                                J = W + 8;
                                break d;
                              case 2:
                                var fa = Ir(U, W);
                                if (fa === void 0) break;
                                var da = n(fa),
                                  ea = da.next().value;
                                J = da.next().value + ea;
                                break d;
                              case 5:
                                J = W + 4;
                                break d;
                            }
                            J = void 0;
                          }
                          if (J === void 0 || J > t.length || J <= u) break;
                          u = J;
                        }
                      } catch (va) {}
                    }
                    q = !1;
                  }
                else q = !1;
                m = q;
              }
              if (m) {
                c = k;
                break a;
              }
            }
          }
        } finally {
          z(f, g);
        }
        c = void 0;
      }
      var ja = c;
      ja && Ls("gcl_aw", ja, 7, a);
    }
  }
  function Ls(a, b, c, d) {
    Ms(a, [{ version: "", gclid: b, timestamp: Wb(), oa: vs(c) }], d);
  }
  function Ms(a, b, c) {
    c = c || {};
    var d = as(),
      e = function () {
        if (bs(d) && b.length > 0) {
          var f = ws(a) || [];
          b.forEach(function (g) {
            var h = Vq(c, g.timestamp, !0);
            h.expires !== void 0 &&
              ss(
                f,
                {
                  version: "",
                  gclid: g.gclid,
                  timestamp: g.timestamp,
                  expires: Number(h.expires),
                  oa: g.oa,
                  labels: g.labels,
                },
                !0
              );
          });
          f.length &&
            Lr(
              a,
              f.map(function (g) {
                var h = {
                    value: g.gclid,
                    creationTimeMs: g.timestamp,
                    linkDecorationSources: g.oa ? g.oa.get() : 0,
                  },
                  k;
                if ((k = g.labels) == null ? 0 : k.length) h.labels = g.labels;
                return { value: h, expires: Number(g.expires) };
              })
            );
        }
      };
    Um(function () {
      bs(d) ? e() : Vm(e, d);
    }, d);
  }
  function Hs(a, b, c, d, e) {
    c = c || {};
    e = e || [];
    var f = is(c.prefix),
      g = d || Wb(),
      h = Math.round(g / 1e3),
      k = as(),
      m = !1,
      p = !1,
      q = Mh(5),
      r = function () {
        if (bs(k)) {
          var t = Vq(c, g, !0);
          t.Hc = k;
          var u = function (U, W) {
              var fa = js(U, f);
              fa && (Pq(fa, W, t), U !== "gb" && (m = !0));
            },
            v = function (U) {
              var W = ["GCL", h, U];
              e.length > 0 && W.push(e.join("."));
              return W.join(".");
            },
            x = n(["aw", "dc", "gf", "ha", "gp"]),
            y = x.next();
          try {
            for (; !y.done; y = x.next()) {
              var B = y.value;
              a[B] && u(B, v(a[B][0]));
            }
          } finally {
            z(x, y);
          }
          if ((!m || q) && a.gb) {
            var E = a.gb[0],
              F = js("gb", f);
            (!b &&
              es(F).some(function (U) {
                return U.gclid === E && U.labels && U.labels.length > 0;
              })) ||
              u("gb", v(E));
          }
        }
        if (!p && a.gbraid && bs("ad_storage") && ((p = !0), !m || q)) {
          var G = a.gbraid,
            I = js("ag", f);
          if (
            b ||
            !ks(I).some(function (U) {
              return U.gclid === G && U.labels && U.labels.length > 0;
            })
          ) {
            var J = {},
              M = ((J.k = G), (J.i = "" + h), (J.b = e), J);
            ar(I, M, 5, c, g);
          }
        }
        Ns(a, f, g, c);
      };
    Um(function () {
      r();
      bs(k) || Vm(r, k);
    }, k);
  }
  function Ns(a, b, c, d) {
    if (a.gad_source !== void 0 && bs("ad_storage")) {
      var e = zd();
      if (e !== "r" && e !== "h") {
        var f = a.gad_source,
          g = js("gs", b);
        if (g) {
          var h = yd() || 0,
            k = Math.floor((Wb() - h) / 1e3),
            m,
            p = Jr(),
            q = {};
          m = ((q.k = f), (q.i = "" + k), (q.u = p), q);
          ar(g, m, 5, d, c);
        }
      }
    }
  }
  function Os(a, b, c) {
    for (var d = Xq(b, c), e = 0; e < d.length; ++e)
      if (ps(d[e]) > a) return !0;
    return !1;
  }
  function Ps(a) {
    var b = Qs,
      c = Rs(a.prefix);
    cs(function () {
      var d = is(a.prefix),
        e = n(b),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value,
            h = c[g];
          if (h) {
            var k = Math.min(Ss(h), Wb()),
              m = Vq(a, k, !0);
            m.Hc = as();
            var p = js(g, d);
            p && Pq(p, h, m);
          }
        }
      } finally {
        z(e, f);
      }
      var q = ur(!0);
      Hs(Cs(q.gclid, q.gclsrc), !1, a);
    }, as());
  }
  function Rs(a) {
    var b = ur(!0),
      c = is(a),
      d = {},
      e;
    for (e in Yr)
      if (Yr.hasOwnProperty(e)) {
        var f = e,
          g = js(f, c);
        if (g !== void 0) {
          var h = b[g];
          if (h) {
            var k = Ss(h),
              m = Math.min(k, Wb()) || Wb(),
              p;
            a: {
              for (
                var q = Dq(g, C.cookie, void 0, as()), r = 0;
                r < q.length;
                ++r
              )
                if (Ss(q[r]) > m) {
                  p = !0;
                  break a;
                }
              p = !1;
            }
            p || (d[f] = h);
          }
        }
      }
    return d;
  }
  function Ts(a) {
    var b = ["ag"],
      c = ur(!0),
      d = is(a.prefix);
    cs(
      function () {
        for (var e = 0; e < b.length; ++e) {
          var f = js(b[e], d);
          if (f) {
            var g = c[f];
            if (g) {
              var h = Aq(g, 5);
              if (h) {
                var k = ps(h);
                k || (k = Wb());
                if (Os(k, f, 5)) break;
                h.i = "" + Math.round(k / 1e3);
                ar(f, h, 5, a, k);
              }
            }
          }
        }
      },
      ["ad_storage"]
    );
  }
  function js(a, b) {
    var c = Yr[a];
    if (c !== void 0) return b + c;
  }
  function Ss(a) {
    return xs(a.split(".")).length !== 0
      ? (Number(a.split(".")[1]) || 0) * 1e3
      : 0;
  }
  function ps(a) {
    return a ? (Number(a.i) || 0) * 1e3 : 0;
  }
  function xs(a) {
    return a.length < 3 ||
      (a[0] !== "GCL" && a[0] !== "1") ||
      !/^\d+$/.test(a[1]) ||
      !Ur.test(a[2])
      ? []
      : a;
  }
  function Us(a, b, c, d) {
    var e = Qs;
    if (Array.isArray(a) && sq(A)) {
      var f = is(d),
        g = function () {
          for (var h = {}, k = 0; k < e.length; ++k) {
            var m = js(e[k], f);
            if (m) {
              var p = Dq(m, C.cookie, void 0, as());
              p.length && (h[m] = p.sort()[p.length - 1]);
            }
          }
          return h;
        };
      cs(function () {
        Br(g, a, b, c);
      }, as());
    }
  }
  function Vs(a, b, c) {
    var d = Qs;
    if (Mh(8) && Array.isArray(a) && sq(A)) {
      var e = function () {
        for (var f = {}, g = 0; g < d.length; ++g) {
          var h = Wr[d[g]];
          if (h) {
            var k = Dq(h, C.cookie, void 0, as());
            if (k.length) {
              var m = void 0,
                p = 0,
                q = n(k),
                r = q.next();
              try {
                for (; !r.done; r = q.next()) {
                  var t = r.value,
                    u = Aq(t, 4);
                  if (u && (u.m === "1" || Mh(9))) {
                    var v = ps(u);
                    v >= p && ((p = v), (m = t));
                  }
                }
              } finally {
                z(q, r);
              }
              m && (f[h] = m);
            }
          }
        }
        return f;
      };
      cs(function () {
        Br(e, a, b, c);
      }, as());
    }
  }
  function Ws(a, b, c, d) {
    if (Array.isArray(a) && sq(A)) {
      var e = ["ag"],
        f = is(d),
        g = function () {
          for (var h = {}, k = 0; k < e.length; ++k) {
            var m = js(e[k], f);
            if (!m) return {};
            var p = Xq(m, 5);
            if (p.length) {
              var q = p.sort(function (r, t) {
                return ps(t) - ps(r);
              })[0];
              h[m] = Bq(q, 5);
            }
          }
          return h;
        };
      cs(
        function () {
          Br(g, a, b, c);
        },
        ["ad_storage"]
      );
    }
  }
  function ts(a) {
    return a.filter(function (b) {
      return Ur.test(b.gclid);
    });
  }
  function Xs(a, b) {
    if (sq(A)) {
      for (var c = is(b.prefix), d = {}, e = 0; e < a.length; e++)
        Yr[a[e]] && (d[a[e]] = Yr[a[e]]);
      cs(function () {
        var f = n(Object.entries(d)),
          g = f.next();
        try {
          for (; !g.done; g = f.next()) {
            var h = n(g.value),
              k = h.next().value,
              m = h.next().value,
              p = k,
              q = Dq(c + m, C.cookie, void 0, as());
            q.sort(function (y, B) {
              return Ss(B) - Ss(y);
            });
            if (q.length) {
              var r = q[0],
                t = Ss(r),
                u = xs(r.split(".")).length !== 0 ? r.split(".").slice(3) : [],
                v = {},
                x;
              x = xs(r.split(".")).length !== 0 ? r.split(".")[2] : void 0;
              v[p] = [x];
              Hs(v, !0, b, t, u);
            }
          }
        } finally {
          z(f, g);
        }
      }, as());
    }
  }
  function Ys(a) {
    var b = ["ag"],
      c = ["gbraid"];
    cs(
      function () {
        for (var d = is(a.prefix), e = 0; e < b.length; ++e) {
          var f = js(b[e], d);
          if (!f) break;
          var g = Xq(f, 5);
          if (g.length) {
            var h = g.sort(function (q, r) {
                return ps(r) - ps(q);
              })[0],
              k = ps(h),
              m = h.b,
              p = {};
            p[c[e]] = h.k;
            Hs(p, !0, a, k, m);
          }
        }
      },
      ["ad_storage"]
    );
  }
  function Zs(a, b) {
    for (var c = 0; c < b.length; ++c) if (a[b[c]]) return !0;
    return !1;
  }
  function $s(a) {
    function b(h, k, m) {
      m && (h[k] = m);
    }
    if (Sm()) {
      var c = Es(),
        d;
      a.includes("gad_source") &&
        (d = c.gad_source !== void 0 ? c.gad_source : ur(!1)._gs);
      if (Zs(c, a) || d) {
        var e = {};
        b(e, "gclid", c.gclid);
        b(e, "dclid", c.dclid);
        b(e, "gclsrc", c.gclsrc);
        b(e, "wbraid", c.wbraid);
        b(e, "gbraid", c.gbraid);
        Cr(function () {
          return e;
        }, 3);
        var f = {},
          g = ((f._up = "1"), f);
        b(g, "_gs", d);
        Cr(function () {
          return g;
        }, 1);
      }
    }
  }
  function Ks() {
    var a = Fj(A.location.href);
    return zj(a, "query", !1, void 0, "gad_source");
  }
  function at(a) {
    if (!Mh(1)) return null;
    var b = ur(!0).gad_source;
    if (b != null) return (A.location.hash = ""), b;
    if (Mh(2)) {
      b = Ks();
      if (b != null) return b;
      var c = Es();
      if (Zs(c, a)) return "0";
    }
    return null;
  }
  function bt(a) {
    var b = at(a);
    b != null &&
      Cr(function () {
        var c = {};
        return (c.gad_source = b), c;
      }, 4);
  }
  function ct(a, b, c) {
    var d = [];
    if (b.length === 0) return d;
    for (var e = {}, f = 0; f < b.length; f++) {
      var g = b[f],
        h = g.sg ? g.sg : "gcl";
      if ((g.labels || []).indexOf(c) === -1) {
        a.push(0);
        var k = !1,
          m = void 0;
        if ((m = g.qa) == null ? 0 : m.includes(2)) k = !0;
        var p = void 0;
        ((p = g.qa) == null ? 0 : p.includes(1)) &&
          !e[h] &&
          ((k = !0), (e[h] = !0));
        k && d.push(g);
      } else {
        a.push(1);
        var q = void 0;
        if ((q = g.qa) == null ? 0 : q.includes(1)) e[h] = !0;
      }
    }
    return d;
  }
  function dt(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    var f = [];
    c = c || {};
    if (!bs(as())) return f;
    var g = es(a, e),
      h = ct(f, g, b);
    if (h.length && !d) {
      var k = [],
        m = !1,
        p = n(h),
        q = p.next();
      try {
        for (; !q.done; q = p.next()) {
          var r = q.value,
            t = r,
            u = t.version,
            v = t.gclid,
            x = t.timestamp,
            y = t.qa,
            B = (t.labels || []).concat([b]),
            E = void 0;
          if (((E = y) == null ? 0 : E.includes(1)) && !m) {
            var F = [u, Math.round(x / 1e3), v].concat(B).join("."),
              G = Vq(c, x, !0);
            G.Hc = as();
            Pq(a, F, G);
            m = !0;
          }
          var I = void 0;
          e &&
            ((I = y) == null ? 0 : I.includes(2)) &&
            k.push(ma(Object, "assign").call(Object, {}, r, { labels: B }));
        }
      } finally {
        z(p, q);
      }
      k.length && Ms("gcl_gb", k, c);
    }
    return f;
  }
  function et(a, b, c) {
    c = c === void 0 ? !1 : c;
    var d = [];
    b = b || {};
    var e = hs(b, c),
      f = ct(d, e, a);
    if (f.length) {
      var g = [],
        h = {},
        k = n(f),
        m = k.next();
      try {
        for (; !m.done; m = k.next()) {
          var p = m.value,
            q = is(b.prefix),
            r = js(p.sg, q);
          if (!r) return d;
          var t = p,
            u = t.version,
            v = t.gclid,
            x = t.timestamp,
            y = t.qa,
            B = Math.round(x / 1e3),
            E = ms(t.labels || [], [a]),
            F = void 0;
          if ((F = y) == null ? 0 : F.includes(1))
            if (p.sg === "ag" && !h.ag) {
              var G = {},
                I = ((G.k = v), (G.i = "" + B), (G.b = E), G);
              ar(r, I, 5, b, x);
              h.ag = !0;
            } else if (p.sg === "gb" && !h.gb) {
              var J = [u, B, v].concat(E).join("."),
                M = Vq(b, x, !0);
              M.Hc = as();
              Pq(r, J, M);
              h.gb = !0;
            }
          var U = void 0;
          c &&
            ((U = y) == null ? 0 : U.includes(2)) &&
            g.push(ma(Object, "assign").call(Object, {}, p, { labels: E }));
        }
      } finally {
        z(k, m);
      }
      g.length && Ms("gcl_gb", g, b);
    }
    return d;
  }
  function ft(a, b) {
    var c = is(b),
      d = js(a, c);
    if (!d) return 0;
    var e;
    e = a === "ag" ? ks(d) : es(d);
    for (var f = 0, g = 0; g < e.length; g++) f = Math.max(f, e[g].timestamp);
    return f;
  }
  function gt(a) {
    var b = 0,
      c = n(Object.keys(a)),
      d = c.next();
    try {
      for (; !d.done; d = c.next())
        for (var e = a[d.value], f = 0; f < e.length; f++)
          b = Math.max(b, Number(e[f].timestamp));
    } finally {
      z(c, d);
    }
    return b;
  }
  function ht(a) {
    var b = Math.max(ft("aw", a), gt(bs(as()) ? rq() : {})),
      c = Math.max(ft("gb", a), gt(bs(as()) ? rq("_gac_gb", !0) : {}));
    c = Math.max(c, ft("ag", a));
    return c > b;
  }
  function it(a) {
    var b,
      c = A,
      d = [];
    try {
      c.navigation && c.navigation.entries && (d = c.navigation.entries());
    } catch (t) {}
    b = d;
    for (var e = b.length - 1; e >= 0; e--) {
      var f = b[e] && b[e].url,
        g;
      if (f)
        a: {
          try {
            var h = new URL(f).searchParams,
              k = {},
              m = h.get("gclid");
            if (m) {
              k.gclid = m;
              var p = h.get("gclsrc");
              p && (k.xj = p);
            }
            var q = h.get("dclid");
            q && (k.mu = q);
            g = k;
            break a;
          } catch (t) {}
          g = void 0;
        }
      else g = void 0;
      var r = g;
      if (r && a(r)) return r;
    }
    return {};
  }
  function jt() {
    return it(function (a) {
      return !!a.gclid;
    });
  }
  var kt = RegExp(
      "^UA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*(?:%3BUA-\\d+-\\d+%3A[\\w-]+(?:%2C[\\w-]+)*)*$"
    ),
    lt = /^~?[\w-]+(?:\.~?[\w-]+)*$/,
    mt = /^\d+\.fls\.doubleclick\.net$/,
    nt = /;gac=([^;?]+)/,
    ot = /;gacgb=([^;?]+)/;
  function pt(a, b, c) {
    if (mt.test(a.location.host)) {
      var d = a.location.href.match(c);
      return d && d.length === 2 && d[1].match(kt) ? yj(d[1]) || "" : "";
    }
    var e = [],
      f = n(Object.keys(b)),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        for (var h = g.value, k = [], m = b[h], p = 0; p < m.length; p++)
          k.push(m[p].gclid);
        e.push(h + ":" + k.join(","));
      }
    } finally {
      z(f, g);
    }
    return e.length > 0 ? e.join(";") : "";
  }
  function qt(a, b, c) {
    var d = bs(as()) ? rq("_gac_gb", !0) : {},
      e = [],
      f = !1,
      g = n(Object.keys(d)),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = h.value,
          m = dt("_gac_gb_" + k, a, b, c);
        f =
          f ||
          (m.length !== 0 &&
            m.some(function (p) {
              return p === 1;
            }));
        e.push(k + ":" + m.join(","));
      }
    } finally {
      z(g, h);
    }
    return { Hq: f ? e.join(";") : "", Gq: pt(C, d, ot) };
  }
  function rt(a, b) {
    var c = a.location.href.match(new RegExp(";" + b + "=([^;?]+)"));
    return c && c.length === 2 && c[1].match(lt) ? c[1] : void 0;
  }
  function st(a) {
    var b = {},
      c,
      d,
      e;
    mt.test(C.location.host) &&
      ((c = rt(C, "gclgs")), (d = rt(C, "gclst")), (e = rt(C, "gcllp")));
    if (c && d && e) (b.yg = c), (b.Nh = d), (b.Mh = e);
    else {
      var f = Wb(),
        g = ns((a || "_gcl") + "_gs"),
        h = g.map(function (p) {
          return p.gclid;
        }),
        k = g.map(function (p) {
          return f - p.timestamp;
        }),
        m = g.map(function (p) {
          return p.od;
        });
      h.length > 0 &&
        k.length > 0 &&
        m.length > 0 &&
        ((b.yg = h.join(".")), (b.Nh = k.join(".")), (b.Mh = m.join(".")));
    }
    return b;
  }
  function tt(a, b) {
    var c = a.split("."),
      d = b ? b.split(".") : [],
      e = d.length === c.length ? d : void 0;
    return c.map(function (f, g) {
      var h = { gclid: f };
      if (e) {
        var k = e[g].split("_");
        if (k.length === 2) {
          h.oa = new Fr(Number(k[0]));
          var m;
          var p = Number(k[1]);
          if (p === 0) m = [0];
          else {
            var q = [];
            p & 1 && q.push(1);
            p & 2 && q.push(2);
            p & 4 && q.push(3);
            p & 8 && q.push(4);
            p & 16 && q.push(5);
            m = q;
          }
          h.qa = m;
        }
      }
      return h;
    });
  }
  function ut(a, b, c, d, e) {
    e = e === void 0 ? !1 : e;
    if (mt.test(a.location.host)) {
      var f = rt(a, d);
      if (f) {
        if (Mh(10)) {
          var g = rt(a, d + "_src");
          return tt(f, g);
        }
        if (e) {
          var h = new Fr();
          Gr(h, 2);
          Gr(h, 3);
          return f.split(".").map(function (t) {
            return { gclid: t, oa: h, qa: [1] };
          });
        }
        return f.split(".").map(function (t) {
          return { gclid: t, oa: new Fr(), qa: [1] };
        });
      }
    } else {
      if (c === "gclid") {
        var k = es((b || "_gcl") + "_aw", e),
          m = Number(Lh[1] === void 0 ? 0 : Lh[1]),
          p = n(vt()),
          q = p.next();
        try {
          for (; !q.done; q = p.next()) {
            var r = q.value;
            r.timestamp > m && ss(k, r);
          }
        } finally {
          z(p, q);
        }
        return k;
      }
      if (c === "wbraid") return es((b || "_gcl") + "_gb", e);
      if (c === "braids") return hs({ prefix: b }, e);
    }
    return [];
  }
  function vt() {
    return (Xq(Wr.aw, 4) || [])
      .filter(function (a) {
        return a.m === "1";
      })
      .map(function (a) {
        return { gclid: a.k, timestamp: Number(a.i), version: "", qa: [5] };
      });
  }
  function wt(a) {
    var b = 0,
      c = n(a),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = d.value;
        e > 0 && (b |= 1 << (e - 1));
      }
    } finally {
      z(c, d);
    }
    return b.toString();
  }
  function xt(a) {
    return mt.test(C.location.host) ? !(rt(C, "gclaw") || rt(C, "gac")) : ht(a);
  }
  function zt(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e;
    e = c
      ? et(a, b, d)
      : dt(((b && b.prefix) || "_gcl") + "_gb", a, b, void 0, d);
    return e.length === 0 ||
      e.every(function (f) {
        return f === 0;
      })
      ? ""
      : e.join(".");
  }
  function Lt(a, b, c) {
    var d = Qi(a, K.D.Sa);
    if (d && typeof d === "object") {
      var e = n(Object.keys(d)),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value,
            h = d[g];
          if (h !== void 0) {
            h === null && (h = "");
            var k = "gap." + g,
              m = String(h);
            c ? c(k, m) : (b[k] = m);
          }
        }
      } finally {
        z(e, f);
      }
    }
  }
  function Mt() {}
  function Nt(a, b) {
    try {
      b = b || 0;
      if (a === void 0 || a === null) return "" + a;
      if (Hb(a)) return '"' + a + '"';
      if (Gb(a)) return "[function]";
      if (Array.isArray(a) || Qb(a)) {
        if (b > 3) return "[...]";
        for (var c = [], d = 0; d < a.length; d++) c.push(Nt(a[d], b + 1));
        return "[" + c.join(", ") + "]";
      }
      if (a.constructor === Object) {
        if (b > 3) return "{...}";
        var e = [],
          f;
        for (f in a) a.hasOwnProperty(f) && e.push(f + ": " + Nt(a[f], b + 1));
        return "{" + e.join(", ") + "}";
      }
      return "" + a;
    } catch (g) {
      return "[object]";
    }
  }
  var Ot = !1,
    Pt = [];
  function Qt() {
    if (!Ot) {
      Ot = !0;
      for (var a = Pt.length - 1; a >= 0; a--) Pt[a]();
      Pt = [];
    }
  }
  function Rt(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function St(a, b, c) {
    return typeof a.addEventListener === "function"
      ? (a.addEventListener(b, c, !1), !0)
      : !1;
  }
  function Tt(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function Ut(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = pq(a.document);
    if (c) {
      var f = function () {
        if (c) {
          var g = a.google_image_requests,
            h = Mc(g, e);
          h >= 0 && Array.prototype.splice.call(g, h, 1);
        }
        Tt(e, "load", f);
        Tt(e, "error", f);
      };
      St(e, "load", f);
      St(e, "error", f);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function Vt(a) {
    var b;
    b = b === void 0 ? !1 : b;
    var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=tcfe";
    iq(a, function (d, e) {
      if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d));
    });
    Wt(c, b);
  }
  function Wt(a, b) {
    var c = window,
      d;
    b = b === void 0 ? !1 : b;
    d = d === void 0 ? !1 : d;
    if (c.fetch) {
      var e = {
        keepalive: !0,
        credentials: "include",
        redirect: "follow",
        method: "get",
        mode: "no-cors",
      };
      d &&
        ((e.mode = "cors"),
        "setAttributionReporting" in XMLHttpRequest.prototype
          ? (e.attributionReporting = {
              eventSourceEligible: "true",
              triggerEligible: "false",
            })
          : (e.headers = { "Attribution-Reporting-Eligible": "event-source" }));
      c.fetch(a, e);
    } else Ut(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d);
  }
  function Xt() {
    this.da = this.da;
    this.T = this.T;
  }
  Xt.prototype.da = !1;
  Xt.prototype.dispose = function () {
    this.da || ((this.da = !0), this.P());
  };
  Xt.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  Xt.prototype.addOnDisposeCallback = function (a, b) {
    this.da
      ? b !== void 0
        ? a.call(b)
        : a()
      : (this.T || (this.T = []), b && (a = a.bind(b)), this.T.push(a));
  };
  Xt.prototype.P = function () {
    if (this.T) for (; this.T.length; ) this.T.shift()();
  };
  function Yt(a) {
    a.addtlConsent === void 0 ||
      wf(a.addtlConsent) ||
      (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || xf(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !wf(a.tcString)) ||
      (a.listenerId !== void 0 && !vf(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  var Zt = function (a, b) {
    b = b === void 0 ? {} : b;
    Xt.call(this);
    this.H = null;
    this.ja = {};
    this.Aa = 0;
    this.Z = null;
    this.K = a;
    var c;
    this.timeoutMs = (c = b.timeoutMs) != null ? c : 500;
    var d;
    this.pj = (d = b.pj) != null ? d : !1;
  };
  ta(Zt, Xt);
  Zt.prototype.P = function () {
    this.ja = {};
    this.Z && (Tt(this.K, "message", this.Z), delete this.Z);
    delete this.ja;
    delete this.K;
    delete this.H;
    Xt.prototype.P.call(this);
  };
  var au = function (a) {
    return typeof a.K.__tcfapi === "function" || $t(a) != null;
  };
  Zt.prototype.addEventListener = function (a) {
    var b = this,
      c = { internalBlockOnErrors: this.pj },
      d = hq(function () {
        a(c);
      }),
      e = 0;
    this.timeoutMs !== -1 &&
      (e = setTimeout(function () {
        c.tcString = "tcunavailable";
        c.internalErrorState = 1;
        d();
      }, this.timeoutMs));
    var f = function (g, h) {
      clearTimeout(e);
      g
        ? ((c = g),
          (c.internalErrorState = Yt(c)),
          (c.internalBlockOnErrors = b.pj),
          (h && c.internalErrorState === 0) ||
            ((c.tcString = "tcunavailable"), h || (c.internalErrorState = 3)))
        : ((c.tcString = "tcunavailable"), (c.internalErrorState = 3));
      a(c);
    };
    try {
      bu(this, "addEventListener", f);
    } catch (g) {
      (c.tcString = "tcunavailable"),
        (c.internalErrorState = 3),
        e && (clearTimeout(e), (e = 0)),
        d();
    }
  };
  Zt.prototype.removeEventListener = function (a) {
    a && a.listenerId && bu(this, "removeEventListener", null, a.listenerId);
  };
  var du = function (a, b, c) {
      var d;
      d = d === void 0 ? "755" : d;
      var e;
      a: {
        if (a.publisher && a.publisher.restrictions) {
          var f = a.publisher.restrictions[b];
          if (f !== void 0) {
            e = f[d === void 0 ? "755" : d];
            break a;
          }
        }
        e = void 0;
      }
      var g = e;
      if (g === 0) return !1;
      var h = c;
      c === 2
        ? ((h = 0), g === 2 && (h = 1))
        : c === 3 && ((h = 1), g === 1 && (h = 0));
      var k;
      if (h === 0)
        if (a.purpose && a.vendor) {
          var m = cu(a.vendor.consents, d === void 0 ? "755" : d);
          k =
            m && b === "1" && a.purposeOneTreatment && a.publisherCC === "CH"
              ? !0
              : m && cu(a.purpose.consents, b);
        } else k = !0;
      else
        k =
          h === 1
            ? a.purpose && a.vendor
              ? cu(a.purpose.legitimateInterests, b) &&
                cu(a.vendor.legitimateInterests, d === void 0 ? "755" : d)
              : !0
            : !0;
      return k;
    },
    cu = function (a, b) {
      return !(!a || !a[b]);
    },
    bu = function (a, b, c, d) {
      c || (c = function () {});
      var e = a.K;
      if (typeof e.__tcfapi === "function") {
        var f = e.__tcfapi;
        f(b, 2, c, d);
      } else if ($t(a)) {
        eu(a);
        var g = ++a.Aa;
        a.ja[g] = c;
        if (a.H) {
          var h = {};
          a.H.postMessage(
            ((h.__tcfapiCall = {
              command: b,
              version: 2,
              callId: g,
              parameter: d,
            }),
            h),
            "*"
          );
        }
      } else c({}, !1);
    },
    $t = function (a) {
      if (a.H) return a.H;
      a.H = nq(a.K, "__tcfapiLocator");
      return a.H;
    },
    eu = function (a) {
      if (!a.Z) {
        var b = function (c) {
          if (c.source === a.H)
            try {
              var d;
              d = (wf(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
              a.ja[d.callId](d.returnValue, d.success);
            } catch (e) {}
        };
        a.Z = b;
        St(a.K, "message", b);
      }
    },
    fu = function (a) {
      if (a.gdprApplies === !1) return !0;
      a.internalErrorState === void 0 && (a.internalErrorState = Yt(a));
      return a.cmpStatus === "error" || a.internalErrorState !== 0
        ? a.internalBlockOnErrors
          ? (Vt({ e: String(a.internalErrorState) }), !1)
          : !0
        : a.cmpStatus === "loaded" &&
            (a.eventStatus === "tcloaded" ||
              a.eventStatus === "useractioncomplete");
    };
  var gu = { 1: 0, 3: 0, 4: 0, 7: 3, 9: 3, 10: 3 };
  function hu() {
    return fo("tcf", function () {
      return {};
    });
  }
  var iu = function () {
    return new Zt(A, { timeoutMs: -1 });
  };
  function ju() {
    var a = hu(),
      b = iu();
    au(b) && !ku() && !lu() && R(124);
    if (!a.active && au(b)) {
      ku() &&
        ((a.active = !0),
        (a.purposes = {}),
        (a.cmpId = 0),
        (a.tcfPolicyVersion = 0),
        (Fm().active = !0),
        (a.tcString = "tcunavailable"));
      np();
      try {
        b.addEventListener(function (c) {
          if (c.internalErrorState !== 0)
            mu(a), op([K.D.ia, K.D.Ra, K.D.ka]), (Fm().active = !0);
          else if (
            ((a.gdprApplies = c.gdprApplies),
            (a.cmpId = c.cmpId),
            (a.enableAdvertiserConsentMode = c.enableAdvertiserConsentMode),
            lu() && (a.active = !0),
            !nu(c) || ku() || lu())
          ) {
            a.tcfPolicyVersion = c.tcfPolicyVersion;
            var d;
            if (c.gdprApplies === !1) {
              var e = {},
                f;
              for (f in gu) gu.hasOwnProperty(f) && (e[f] = !0);
              d = e;
              b.removeEventListener(c);
            } else if (nu(c)) {
              var g = {},
                h;
              for (h in gu)
                if (gu.hasOwnProperty(h))
                  if (h === "1") {
                    var k,
                      m = c,
                      p = { Kq: !0 };
                    p = p === void 0 ? {} : p;
                    k = fu(m)
                      ? m.gdprApplies === !1
                        ? !0
                        : m.tcString === "tcunavailable"
                        ? !p.idpcApplies
                        : (p.idpcApplies || m.gdprApplies !== void 0 || p.Kq) &&
                          (p.idpcApplies ||
                            (wf(m.tcString) && m.tcString.length))
                        ? du(m, "1", 0)
                        : !0
                      : !1;
                    g["1"] = k;
                  } else g[h] = du(c, h, gu[h]);
              d = g;
            }
            if (d) {
              a.tcString = c.tcString || "tcempty";
              a.purposes = d;
              var q = {},
                r = ((q[K.D.ia] = a.purposes["1"] ? "granted" : "denied"), q);
              a.gdprApplies !== !0
                ? (op([K.D.ia, K.D.Ra, K.D.ka]), (Fm().active = !0))
                : ((r[K.D.Ra] =
                    a.purposes["3"] && a.purposes["4"] ? "granted" : "denied"),
                  typeof a.tcfPolicyVersion === "number" &&
                  a.tcfPolicyVersion >= 4
                    ? (r[K.D.ka] =
                        a.purposes["1"] && a.purposes["7"]
                          ? "granted"
                          : "denied")
                    : op([K.D.ka]),
                  gp(
                    r,
                    { eventId: 0 },
                    {
                      gdprApplies: a ? a.gdprApplies : void 0,
                      tcString: ou() || "",
                    }
                  ));
            }
          } else op([K.D.ia, K.D.Ra, K.D.ka]);
        });
      } catch (c) {
        mu(a), op([K.D.ia, K.D.Ra, K.D.ka]), (Fm().active = !0);
      }
    }
  }
  function mu(a) {
    a.type = "e";
    a.tcString = "tcunavailable";
  }
  function nu(a) {
    return (
      a.eventStatus === "tcloaded" ||
      a.eventStatus === "useractioncomplete" ||
      a.eventStatus === "cmpuishown"
    );
  }
  function ku() {
    return A.gtag_enable_tcf_support === !0;
  }
  function lu() {
    return hu().enableAdvertiserConsentMode === !0;
  }
  function ou() {
    var a = hu();
    if (a.active) return a.tcString;
  }
  function pu() {
    var a = hu();
    if (a.active && a.gdprApplies !== void 0) return a.gdprApplies ? "1" : "0";
  }
  function qu(a) {
    if (!gu.hasOwnProperty(String(a))) return !0;
    var b = hu();
    return b.active && b.purposes ? !!b.purposes[String(a)] : !0;
  }
  var ru = [K.D.ia, K.D.ua, K.D.ka, K.D.Ra],
    su = {},
    tu = ((su[K.D.ia] = 1), (su[K.D.ua] = 2), su);
  function uu(a) {
    if (a === void 0) return 0;
    switch (Q(a, K.D.sc)) {
      case void 0:
        return 1;
      case !1:
        return 3;
      default:
        return 2;
    }
  }
  function vu() {
    return (
      (P(624) ? Lf(16).split("~") : Lf(17).split("~")).indexOf(Gk()) !== -1 &&
      (Qc == null ? void 0 : Qc.globalPrivacyControl) === !0
    );
  }
  function wu(a) {
    if (vu()) return !1;
    var b = uu(a);
    if (b === 3) return !1;
    switch (Pm(K.D.Ra)) {
      case 1:
      case 3:
        return !0;
      case 2:
        return !1;
      case 4:
        return b === 2;
      case 0:
        return !0;
      default:
        return !1;
    }
  }
  function xu() {
    return Sm() || !Om(K.D.ia) || !Om(K.D.ua);
  }
  function yu() {
    var a = {},
      b;
    for (b in tu) tu.hasOwnProperty(b) && (a[tu[b]] = Pm(b));
    return "G1" + zf(a[1] || 0) + zf(a[2] || 0);
  }
  var zu = {},
    Au =
      ((zu[K.D.ia] = 0),
      (zu[K.D.ua] = 1),
      (zu[K.D.ka] = 2),
      (zu[K.D.Ra] = 3),
      zu);
  function Bu(a) {
    switch (a) {
      case void 0:
        return 1;
      case !0:
        return 3;
      case !1:
        return 2;
      default:
        return 0;
    }
  }
  function Cu(a) {
    for (var b = "1", c = 0; c < ru.length; c++) {
      var d = b,
        e,
        f = ru[c],
        g = Nm.delegatedConsentTypes[f];
      e = g === void 0 ? 0 : Au.hasOwnProperty(g) ? 12 | Au[g] : 8;
      var h = Fm();
      h.accessedAny = !0;
      var k = h.entries[f] || {};
      e = (e << 2) | Bu(k.implicit);
      b =
        d +
        ("" +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            e
          ] +
          "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
            (Bu(k.declare) << 4) | (Bu(k.default) << 2) | Bu(k.update)
          ]);
    }
    var m = b,
      p = (vu() ? 1 : 0) << 3,
      q = (Sm() ? 1 : 0) << 2,
      r = uu(a);
    b =
      m +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        p | q | r
      ];
    return (b +=
      "" +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (Nm.containerScopedDefaults.ad_storage << 4) |
          (Nm.containerScopedDefaults.analytics_storage << 2) |
          Nm.containerScopedDefaults.ad_user_data
      ] +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        ((Nm.usedContainerScopedDefaults ? 1 : 0) << 2) |
          Nm.containerScopedDefaults.ad_personalization
      ]);
  }
  function Du() {
    return Om(K.D.ka) ? "a" : "-";
  }
  function Eu() {
    return Ik() || ((ku() || lu()) && pu() === "1") ? "1" : "0";
  }
  function Fu() {
    return (Ik() ? !0 : !(!ku() && !lu()) && pu() === "1") || !Om(K.D.ka);
  }
  function Gu() {
    var a = "0",
      b = "0",
      c;
    var d = hu();
    c = d.active ? d.cmpId : void 0;
    typeof c === "number" &&
      c >= 0 &&
      c <= 4095 &&
      ((a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        (c >> 6) & 63
      ]),
      (b = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        c & 63
      ]));
    var e = "0",
      f;
    var g = hu();
    f = g.active ? g.tcfPolicyVersion : void 0;
    typeof f === "number" &&
      f >= 0 &&
      f <= 63 &&
      (e = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[
        f
      ]);
    var h = 0;
    Ik() && (h |= 1);
    pu() === "1" && (h |= 2);
    ku() && (h |= 4);
    var k;
    var m = hu();
    k =
      m.enableAdvertiserConsentMode !== void 0
        ? m.enableAdvertiserConsentMode
          ? "1"
          : "0"
        : void 0;
    k === "1" && (h |= 8);
    Fm().waitPeriodTimedOut && (h |= 16);
    return (
      "1" +
      a +
      b +
      e +
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_"[h]
    );
  }
  var Hu = { UA: 1, AW: 2, DC: 3, G: 4, GF: 5, GT: 12, GTM: 14, HA: 6, MC: 7 };
  function Iu() {
    if (!Uc) return 0;
    var a = Fj(Uc),
      b = a.hostname.toLowerCase();
    if (/(^|\.)googletagmanager\.com$/.test(b)) return 1;
    var c = A.location,
      d = c.hostname.toLowerCase();
    if (c.protocol.toLowerCase() === a.protocol.toLowerCase() && d === b)
      return 4;
    if (d === b) return 3;
    var e = b.split("."),
      f = d.split("."),
      g = /\.(co|com|org|net|gov|edu|ac|ne|or|go)\.[a-z]{2}$/.test(b) ? 3 : 2;
    if (e.length >= g && f.length >= g) {
      var h = e.slice(-g).join("."),
        k = f.slice(-g).join(".");
      if (h === k) return 3;
    }
    return 2;
  }
  function Ju() {
    var a = H(69);
    if (a)
      switch (a) {
        case "1":
          return 3;
        case "2":
          return 4;
        case "@@SGTM_SIG@@":
          return 2;
        default:
          return 1;
      }
  }
  function Ku(a) {
    a = a === void 0 ? {} : a;
    var b = H(5).split("-")[0].toUpperCase(),
      c,
      d = (c = a.Uh) != null ? c : Iu(),
      e,
      f = (e = a.xn) != null ? e : Ju(),
      g,
      h = {
        ctid: H(5),
        releaseExperiment: Jf(15),
        runtimeVersion: H(14),
        zr: If(7) ? 2 : 1,
        xs: a.sd,
        canonicalId: H(6),
        Yr: (g = rm()) == null ? void 0 : g.canonicalContainerId,
        ys: a.jf === void 0 ? void 0 : a.jf ? 10 : 12,
        Uh: d,
        xn: f,
      };
    h.canonicalId !== a.Sb && (h.Sb = a.Sb);
    var k = om();
    h.Kr = k ? k.canonicalContainerId : void 0;
    If(45) ? ((h.bi = Hu[b]), h.bi || (h.bi = 0)) : (h.bi = rj ? 13 : 10);
    If(47) ? ((h.Kj = 0), (h.jq = 2)) : If(50) ? (h.Kj = 1) : (h.Kj = 3);
    var m = ma(Object, "assign").call(Object, {}, a, { Uh: d }),
      p = { 6: !1 };
    Jf(54) === 2 ? (p[7] = !0) : Jf(54) === 1 && (p[2] = !0);
    var q = m.Uh;
    q !== void 0 && q !== 0 && (p[8] = q !== 1);
    var r;
    p[9] = (r = m.bf) != null ? r : !1;
    var t = xm(),
      u;
    p[10] =
      (u = t == null ? void 0 : t.fromContainerExecution) != null ? u : !1;
    h.qq = p;
    return Df(h, a.om);
  }
  function Mu(a, b) {
    var c = Vi(b, { Xe: !1 });
    return Wk[a](void 0) + "?" + c;
  }
  var V = {
    W: {
      nk: "call_conversion",
      qk: "common_aw",
      ra: "conversion",
      To: "floodlight",
      bd: "ga_conversion",
      xa: "page_view",
      Ob: "remarketing",
      Hb: "user_data_lead",
      ob: "user_data_web",
    },
  };
  function Nu() {
    return P(550) && $p(613);
  }
  function Ou(a, b) {
    a ? a.then(b) : b(void 0);
  }
  function Pu(a) {
    return Promise.allSettled(a).then(function (b) {
      return b
        .filter(function (c) {
          return c.status === "fulfilled";
        })
        .map(function (c) {
          return c.value;
        });
    });
  }
  function Qu() {
    var a, b;
    return {
      promise: new Promise(function (c, d) {
        a = c;
        b = d;
      }),
      resolve: a,
      reject: b,
    };
  }
  function Ru(a, b, c, d, e, f) {
    var g = c.slice(),
      h;
    d == null || (h = d.su) == null || h.call(d, a, b, c, e);
    var k = Qu(),
      m = k.promise,
      p = k.resolve,
      q = [],
      r = function () {
        p(q);
        var u;
        d == null || (u = d.Hr) == null || u.call(d, a, b, c, e, q);
      },
      t = function () {
        var u = g.shift();
        u
          ? u.method.isSupported()
            ? Su(a, b, u.endpoint, d, q, u.method, e, f, t, r)
            : t()
          : r();
      };
    t();
    return m;
  }
  function Su(a, b, c, d, e, f, g, h, k, m) {
    var p = c.T(a),
      q = { service: b, endpoint: c, isPrimary: g, oc: void 0, Yj: f, Vr: {} },
      r = !1,
      t = function (B, E) {
        if (r) R(187);
        else if (((r = !0), !u)) {
          var F = E || {},
            G = F.body,
            I = F.yb,
            J = F.We;
          E = Object.freeze(
            ma(Object, "assign").call(
              Object,
              {},
              G ? { body: G } : {},
              I ? { yb: I } : {},
              J ? { We: J } : {}
            )
          );
          if (G && !f.H()) x(), k();
          else {
            var M = Tu(B, c.parameterEncoding),
              U = p[0] === "/" ? "" + p + M : "https://" + p + M;
            q.oc = U;
            q.Vr = E;
            var W;
            d == null ||
              (W = d.Ir) == null ||
              W.call(d, a, ma(Object, "assign").call(Object, {}, q));
            var fa = {
              destinationId: a.target.destinationId,
              endpoint: c.endpoint,
              eventId: a.M.eventId,
              priorityId: a.M.priorityId,
            };
            f.T === void 0 ||
              (c.da !== 2 && (c.da !== 1 || e.length)) ||
              kl.register(fa, f.T, U);
            var da = function (ja, va) {
                x();
                if (q.status !== void 0) return R(192), !1;
                q.status = ja;
                e.push(q);
                var Ga;
                d == null ||
                  (Ga = d.gn) == null ||
                  Ga.call(d, a, ma(Object, "assign").call(Object, {}, q), va);
                return !0;
              },
              ea = {
                rn: fa,
                rd: function () {
                  da(2) && k();
                },
                onFailure: function () {
                  da(3) && k();
                },
                Yd: function (ja) {
                  da(ja.status === 0 ? 1 : ja.ok ? 0 : 3, ja) && m();
                },
                ef: function () {
                  da(1) && m();
                },
              };
            Uu(c, a, U, M, G);
            f.sendRequest(
              ea,
              U,
              ma(Object, "assign").call(
                Object,
                {},
                G && { body: G },
                I && { yb: I },
                J && { We: J }
              )
            );
          }
        }
      },
      u = !1,
      v,
      x = function () {
        v !== void 0 && (A.clearTimeout(v), (v = void 0));
      };
    P(574) &&
      (v = A.setTimeout(function () {
        v = void 0;
        u = !0;
        if (q.status === void 0) {
          q.status = 4;
          q.oc === void 0 && (q.oc = "[failed to build] " + p);
          e.push(q);
          var B;
          d == null ||
            (B = d.gn) == null ||
            B.call(d, a, ma(Object, "assign").call(Object, {}, q), void 0);
          k();
        }
      }, 5e3));
    var y = { nd: p, method: f, xu: e, isPrimary: g, ws: h };
    try {
      c.H(a, y, t);
    } catch (B) {
      x(), R(188), k();
    }
  }
  function Uu(a, b, c, d, e) {
    if (a.Aa) {
      var f = b.target.destinationId,
        g = a.endpoint;
      if (g === 45 || g === 46 || g === 69 || g === 58 || g === 57) {
        var h = /[?&]tids=([^&]+)/.exec(d);
        f = h ? decodeURIComponent(h[1]).split("~") : [f];
      }
      Yo({
        targetId: f,
        request: ma(Object, "assign").call(
          Object,
          {},
          {
            url: c,
            parameterEncoding: a.parameterEncoding,
            endpoint: a.endpoint,
          },
          e ? { postBody: e } : {}
        ),
        xb: { eventId: b.M.eventId, priorityId: b.M.priorityId },
        tm: { eventId: S(b, L.J.Rg), priorityId: S(b, L.J.Sg) },
      });
    }
  }
  function Tu(a, b) {
    if (!a) return "";
    if (b !== 4) {
      if (a === "?") return "";
      if (a[0] !== "?") return "?".concat(a);
    }
    return a;
  }
  function Vu(a, b, c, d, e) {
    var f;
    e == null || (f = e.tu) == null || f.call(e, a, b);
    if (!c.length) {
      var g;
      e == null || (g = e.Jr) == null || g.call(e, a, b, []);
      return Promise.resolve([]);
    }
    var h = [],
      k = { service: b, Wj: c, Sj: d };
    h.push(Ru(a, b, c, e, !0, k));
    var m = n(d),
      p = m.next();
    try {
      for (; !p.done; p = m.next()) h.push(Ru(a, b, p.value, e, !1, k));
    } finally {
      z(m, p);
    }
    return Pu(h).then(function (q) {
      var r = [],
        t = n(q),
        u = t.next();
      try {
        for (; !u.done; u = t.next()) r.push.apply(r, w(u.value));
      } finally {
        z(t, u);
      }
      var v;
      e == null || (v = e.Jr) == null || v.call(e, a, b, r);
      return r;
    });
  }
  function Wu(a, b) {
    var c = Qa.apply(2, arguments),
      d;
    b == null || (d = b.uu) == null || d.call(b, a, c);
    var e = [],
      f = n(c),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) e.push(Xu(a, g.value));
    } finally {
      z(f, g);
    }
    var h = [],
      k = n(e),
      m = k.next();
    try {
      for (; !m.done; m = k.next()) {
        var p = m.value;
        h.push(Vu(a, p.service, p.Wj, p.Sj, b));
      }
    } finally {
      z(k, m);
    }
    Pu(h).then(function (q) {
      var r = [],
        t = n(q),
        u = t.next();
      try {
        for (; !u.done; u = t.next()) r.push.apply(r, w(u.value));
      } finally {
        z(t, u);
      }
      var v;
      b == null || (v = b.Gr) == null || v.call(b, a, c, r);
    });
  }
  function Xu(a, b) {
    var c = function (f) {
        return (
          f.method.isSupported() && f.endpoint.isSupported(a) && f.endpoint.K(a)
        );
      },
      d = (b.K(a) || []).filter(c),
      e = [];
    d.length &&
      (e = (b.H(a) || [])
        .map(function (f) {
          return f.filter(c);
        })
        .filter(function (f) {
          return f.length > 0;
        }));
    return { service: b, Wj: d, Sj: e };
  }
  function cv(a, b) {
    if (b) {
      var c = n(Object.entries(b)),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = n(d.value),
            f = e.next().value,
            g = e.next().value;
          typeof g !== "object" && g !== void 0 && (a["1p." + f] = String(g));
        }
      } finally {
        z(c, d);
      }
    }
  }
  var nv = { Hg: "value", pb: "conversionCount", Ig: 1 },
    ov = { Hg: "timeouts", pb: "timeouts", Ig: 0 },
    pv = { Hg: "eopCount", pb: "endOfPageCount", Ig: 0 },
    qv = { Hg: "errors", pb: "errors", Ig: 0 },
    rv = [nv, ov, qv, pv];
  function sv(a, b) {
    b = b === void 0 ? 1 : b;
    if (!tv(a)) return {};
    var c = uv(rv),
      d = c[a.pb];
    if (d === void 0 || d === -1) return c;
    var e = {},
      f = ma(Object, "assign").call(Object, {}, c, ((e[a.pb] = d + b), e));
    return vv(f) ? f : c;
  }
  function uv(a) {
    var b;
    a: {
      var c = Or("gcl_ctr");
      if (c.error === 0 && c.value && typeof c.value === "object") {
        var d = c.value;
        try {
          b = "value" in d && typeof d.value === "object" ? d.value : void 0;
          break a;
        } catch (p) {}
      }
      b = void 0;
    }
    var e = b,
      f = {},
      g = n(a),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = h.value;
        if (e && tv(k)) {
          var m = e[k.Hg];
          m === void 0 || Number.isNaN(m)
            ? (f[k.pb] = -1)
            : (f[k.pb] = Number(m));
        } else f[k.pb] = -1;
      }
    } finally {
      z(g, h);
    }
    return f;
  }
  function vv(a, b) {
    b = b || {};
    var c = Wb(),
      d = Vq(b, c, !0),
      e = {},
      f = n(rv),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = g.value,
          k = a[h.pb];
        k !== void 0 && k !== -1 && (e[h.Hg] = k);
      }
    } finally {
      z(f, g);
    }
    e.creationTimeMs = c;
    return Lr("gcl_ctr", { value: e, expires: Number(d.expires) }) === 0;
  }
  function tv(a) {
    return Om(["ad_storage", "ad_user_data"]) ? !a.Ur || Mh(a.Ur) : !1;
  }
  function wv(a) {
    return Om(["ad_storage", "ad_user_data"]) ? !a.kr || Mh(a.kr) : !1;
  }
  function xv() {
    if (yv()) {
      var a = Or("last_convs");
      if (a.error === 0 && a.value && typeof a.value === "object") {
        var b = a.value;
        if (b.value && Array.isArray(b.value)) {
          var c = b.value;
          if (!(c.length > 1)) {
            var d = [],
              e = n(c),
              f = e.next();
            try {
              for (; !f.done; f = e.next()) {
                var g = f.value;
                if (
                  typeof g !== "object" ||
                  g === null ||
                  typeof g.random !== "number" ||
                  typeof g.label !== "string" ||
                  g.label.length > 200
                )
                  return;
                d.push({ random: g.random, label: g.label });
              }
            } finally {
              z(e, f);
            }
            return d;
          }
        }
      }
    }
  }
  function zv(a, b) {
    if (
      !(!yv() || a.length > 1 || (a.length === 1 && a[0].label.length > 200))
    ) {
      b = b || {};
      var c = Vq(b);
      Lr("last_convs", { value: a, expires: Number(c.expires) });
    }
  }
  function yv() {
    return Om(["ad_storage", "ad_user_data"]) && Mh(6);
  }
  function Av(a) {
    var b = Math.round(Math.random() * 2147483647);
    return a ? String(b ^ (dg(a) & 2147483647)) : String(b);
  }
  function Bv(a) {
    return [Av(a), Math.round(Wb() / 1e3)].join(".");
  }
  function Cv(a, b, c, d, e) {
    var f = Sq(b),
      g;
    return (g = Hq(a, f, Tq(c), d, e)) == null ? void 0 : g.sq;
  }
  var Dv = ["1"],
    Ev = {},
    Fv = {};
  function Gv(a) {
    return Fv[Hv(a)];
  }
  function Iv(a, b) {
    b = b === void 0 ? !0 : b;
    var c = Hv(a.prefix);
    if (Ev[c]) Jv(a), Kv(a);
    else if (Lv(c, a.path, a.domain)) {
      var d = Gv(a.prefix) || { id: void 0, nc: void 0 };
      b && Mv(a, d);
      Jv(a);
      Kv(a);
    } else {
      var e = Hj("auiddc");
      if (e) wb("TAGGING", 17), (Ev[c] = e);
      else if (b) {
        var f = Hv(a.prefix),
          g = Bv();
        Nv(f, g, a);
        Lv(c, a.path, a.domain);
        Jv(a, !0);
        Kv(a, !0);
      }
    }
  }
  function Jv(a, b) {
    (b === void 0 ? 0 : b) && tv(nv) && Pr("gcl_ctr");
    if (wv(nv) && uv([nv])[nv.pb] === -1) {
      var c = {},
        d = ((c[nv.pb] = 0), c),
        e = n(rv),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value;
          g !== nv && wv(g) && (d[g.pb] = 0);
        }
      } finally {
        z(e, f);
      }
      vv(d, a);
    }
  }
  function Kv(a, b) {
    (b === void 0 ? 0 : b) && yv() && Pr("last_convs");
    !Om(["ad_storage", "ad_user_data"]) || !Mh(7) || xv() || zv([], a);
  }
  function Mv(a, b) {
    var c = Hv(a.prefix),
      d = Ev[c];
    if (d) {
      var e = d.split(".");
      if (e.length === 2) {
        var f = Number(e[1]) || 0;
        if (f) {
          var g = d;
          if (Mh(11) && b.Xh) {
            var h = b.nc ? b.nc : Math.floor(Wb() / 1e3),
              k = b.Gc ? b.Gc : Math.floor(Wb() / 1e3);
            g =
              d + "." + (b.sessionId || "-.-") + "." + h + "." + b.Xh + "." + k;
          } else if (b.sessionId) {
            var m = b.nc ? b.nc : Math.floor(Wb() / 1e3);
            g = d + "." + b.sessionId + "." + m;
          }
          Nv(c, g, a, f * 1e3);
        }
      }
    }
  }
  function Nv(a, b, c, d) {
    var e;
    e = ["1", Uq(c.domain, c.path), b].join(".");
    var f = Vq(c, d);
    f.Hc = Ov();
    Pq(a, e, f);
  }
  function Lv(a, b, c) {
    var d = Cv(a, b, c, Dv, Ov());
    if (!d) return !1;
    Pv(a, d);
    return !0;
  }
  function Pv(a, b) {
    var c = b.split(".");
    if (c.length === 3)
      Fv[a] = { sessionId: c[0] + "." + c[1], nc: Number(c[2]) || 0, Gc: 0 };
    else if (
      c.length >= 2 &&
      ((Ev[a] = c[0] + "." + c[1]), c.shift(), c.shift(), c.length >= 3)
    ) {
      var d = {
        sessionId: c[0] === "-" ? void 0 : c[0] + "." + c[1],
        nc: Number(c[2]) || 0,
        Gc: 0,
      };
      if (Mh(11) && c.length >= 6) {
        var e = c[3] + "." + c[4],
          f = Number(c[5]) || 0;
        e && f !== 0 && ((d.Xh = e), (d.Gc = f));
      }
      Fv[a] = d;
    }
  }
  function Hv(a) {
    return (a || "_gcl") + "_au";
  }
  function Qv(a) {
    function b() {
      Om(c) && a();
    }
    var c = Ov();
    Um(function () {
      b();
      Om(c) || Vm(b, c);
    }, c);
  }
  function Rv(a) {
    var b = ur(!0),
      c = Hv(a.prefix);
    Qv(function () {
      var d = b[c];
      if (d) {
        Pv(c, d);
        var e = Number(Ev[c].split(".")[1]) * 1e3;
        if (e) {
          wb("TAGGING", 16);
          var f = Vq(a, e);
          f.Hc = Ov();
          var g = ["1", Uq(a.domain, a.path), d].join(".");
          Pq(c, g, f);
        }
      }
    });
  }
  function Sv(a, b, c, d, e) {
    e = e || {};
    var f = function () {
      var g = {},
        h = Cv(a, e.path, e.domain, Dv, Ov());
      h && (g[a] = h);
      return g;
    };
    Qv(function () {
      Br(f, b, c, d);
    });
  }
  function Ov() {
    return ["ad_storage", "ad_user_data"];
  }
  var Wv = void 0;
  function Xv() {
    if (!Wv) {
      var a = vk(qk.ba.Kn, new Map());
      Wv = new eg(a);
    }
    return Wv;
  }
  var Yv =
      "email email_address sha256_email_address phone_number sha256_phone_number first_name last_name".split(
        " "
      ),
    Zv =
      "first_name sha256_first_name last_name sha256_last_name street sha256_street city region country postal_code".split(
        " "
      );
  function $v(a, b) {
    if (!b._tag_metadata) {
      for (var c = {}, d = 0, e = 0; e < a.length; e++)
        d += aw(a[e], b, c) ? 1 : 0;
      d > 0 && (b._tag_metadata = c);
    }
  }
  function aw(a, b, c) {
    var d = b[a];
    if (d === void 0 || d === null) return !1;
    Array.isArray(d)
      ? (c[a] = d.map(function () {
          return { mode: "c" };
        }))
      : (c[a] = { mode: "c" });
    return !0;
  }
  function bw(a) {
    if (a) {
      $v(Yv, a);
      for (var b = Lb(a.address), c = 0; c < b.length; c++) {
        var d = b[c];
        d && $v(Zv, d);
      }
      var e = a.home_address;
      e && $v(Zv, e);
    }
  }
  function cw(a, b, c) {
    function d(h, k) {
      for (var m = String(k).substring(0, 100); m.length > 0; )
        try {
          e.push("" + h + encodeURIComponent(m));
          return;
        } catch (p) {
          if (p instanceof URIError && m.length > 0) m = m.slice(0, -1);
          else throw p;
        }
      e.push("" + h);
    }
    if (!c) return "";
    var e = [];
    d("i", String(a));
    d("f", b);
    c.mode && d("m", c.mode);
    c.isPreHashed && d("p", "1");
    c.rawLength && d("r", String(c.rawLength));
    c.normalizedLength && d("n", String(c.normalizedLength));
    c.location && d("l", c.location);
    if (c.selector) {
      var f = c.selector.substring(0, 100),
        g = "";
      try {
        g = mc(c.selector.substring(0, 71), 95);
      } catch (h) {}
      g ? e.push("s!b64!" + g) : d("s", f);
    }
    c.testReason &&
      c.testReason.length &&
      d(
        "t",
        c.testReason
          .slice()
          .sort(function (h, k) {
            return h - k;
          })
          .join("!")
      );
    return e.join(".");
  }
  var dw = /^[0-9A-Za-z_-]{43}$/;
  function ew(a) {
    return dw.test(a) || xi.test(a);
  }
  var Ww = Object.freeze({
    cache: "no-store",
    credentials: "include",
    method: "GET",
    keepalive: !0,
    redirect: "follow",
  });
  function Xw(a, b, c, d, e, f) {
    if (!Gb(A.fetch)) return f == null || f(void 0, void 0), !1;
    var g = ma(Object, "assign").call(Object, {}, Ww);
    b && ((g.body = b), (g.method = "POST"));
    ma(Object, "assign").call(Object, g, d);
    A.fetch(a, g)
      .then(function (h) {
        if (h.ok) {
          if (h.body) {
            var k = h.body.getReader(),
              m = new TextDecoder();
            return new Promise(function (p) {
              function q() {
                k.read()
                  .then(function (r) {
                    var t;
                    t = r.done;
                    var u = m.decode(r.value, { stream: !t });
                    u = c.T + u;
                    for (var v = u.indexOf("\n\n"); v !== -1; ) {
                      var x = Og,
                        y;
                      a: {
                        var B = n(u.substring(0, v).split("\n")),
                          E = B.next().value,
                          F = B.next().value;
                        if ($b(E, "event: message") && $b(F, "data: ")) {
                          var G = F.substring(6);
                          try {
                            y = JSON.parse(G);
                            break a;
                          } catch (I) {}
                        }
                        y = void 0;
                      }
                      x(c, y);
                      u = u.substring(v + 2);
                      v = u.indexOf("\n\n");
                    }
                    c.T = u;
                    t ? (e == null || e(h), p()) : q();
                  })
                  .catch(function () {
                    e == null || e(h);
                    p();
                  });
              }
              q();
            });
          }
          e == null || e(h);
        } else f == null || f(h, void 0);
      })
      .catch(function (h) {
        f == null || f(void 0, h);
      });
    return !0;
  }
  var Yw = function (a) {
    rp.call(this, "FetchRichResponse", 1);
    this.P = a;
  };
  ta(Yw, rp);
  Yw.prototype.isSupported = function () {
    return Gb(A.fetch);
  };
  Yw.prototype.H = function () {
    return !0;
  };
  Yw.prototype.K = function (a, b, c) {
    Xw(
      b,
      c == null ? void 0 : c.body,
      this.P,
      c == null ? void 0 : c.yb,
      a.Yd,
      function (d, e) {
        a.onFailure(e);
      }
    );
  };
  var fx = Object.freeze({ attributionsrc: "" }),
    gx = Object.freeze({ eventSourceEligible: !1, triggerEligible: !0 });
  function hx() {
    var a = XMLHttpRequest.prototype;
    return a && Gb(a.setAttributionReporting);
  }
  var lx = function () {
      var a = 5;
      kx.Dn > 0 && (a = kx.Dn);
      this.H = a;
      this.count = 0;
      this.K = [];
    },
    mx = function (a) {
      if (a.count < a.H) return !1;
      var b = a.count % a.H;
      return Wb() - a.K[b] < 1e3;
    },
    nx = function (a) {
      var b = a.count++ % a.H;
      a.K[b] = Wb();
    };
  var kx = { Dn: Nf(3, 0) },
    rx = function () {
      var a = this;
      this.Ia = [];
      this.ja = [];
      this.H = void 0;
      this.Z = {};
      this.K = void 0;
      this.Aa = new lx();
      this.Pb = 1e3;
      this.T = this.P = !1;
      this.da = Nb();
      ox(this, function () {
        return px(a);
      });
      qx(this, function () {
        return px(a);
      });
      ld(function () {
        a.da = Nb();
      }, 864e5);
    },
    ox = function (a, b) {
      a.Ia.push(b);
    },
    qx = function (a, b) {
      a.ja.push(b);
    },
    sx = function (a, b, c) {
      var d = a.H;
      if (d === void 0)
        if (c) d = mo();
        else return "";
      var e = { id: H(5) },
        f = n(a.Ia),
        g = f.next();
      try {
        for (; !g.done; g = f.next()) {
          var h = g.value,
            k = h({ eventId: d, fe: !!b }),
            m = n(k),
            p = m.next();
          try {
            for (; !p.done; p = m.next()) {
              var q = n(p.value),
                r = q.next().value,
                t = q.next().value;
              e[r] = t;
            }
          } finally {
            z(m, p);
          }
        }
      } finally {
        z(f, g);
      }
      e.z = 0;
      return Wk[56](void 0) + "?" + Vi(e, { Ve: !0, Xe: !1 });
    },
    tx = function (a) {
      if (
        Zi(14) &&
        (a.K && (A.clearTimeout(a.K), (a.K = void 0)), a.H !== void 0 && a.T)
      ) {
        var b = cn(3);
        if (Ym(b))
          a.P ||
            ((a.P = !0),
            $m(b, function () {
              return void tx(a);
            }));
        else if (a.Z[a.H] || mx(a.Aa) || a.Pb-- <= 0) R(1), (a.Z[a.H] = !0);
        else {
          nx(a.Aa);
          var c = sx(a, !0);
          Wl({ destinationId: H(5), endpoint: 56, eventId: a.H }, c);
          a.T = !1;
          a.P = !1;
        }
      }
    },
    ux = function (a) {
      a.K ||
        (a.K = A.setTimeout(function () {
          return void tx(a);
        }, 500));
    },
    wx = function (a) {
      var b = vx;
      b.Z[a] ||
        (a !== b.H && (tx(b), (b.H = a)),
        (b.T = !0),
        ux(b),
        sx(b).length >= 2022 && tx(b));
    },
    px = function (a) {
      var b = [
          ["v", "3"],
          ["t", "t"],
          ["pid", String(a.da)],
        ],
        c = Ku();
      c && b.push(["gtm", c]);
      return b;
    },
    vx;
  function xx(a) {
    yx();
    ox(vx, a);
  }
  function zx() {
    var a = Ax;
    yx();
    qx(vx, a);
  }
  function Bx() {
    var a;
    a = a === void 0 ? !1 : a;
    yx();
    var b = a,
      c = vx;
    b = b === void 0 ? !1 : b;
    if (gl.P && Zi(14)) {
      var d = sx(c, !0, !0);
      b
        ? Ul({ destinationId: H(5), endpoint: 56, eventId: c.H }, d)
        : Wl({ destinationId: H(5), endpoint: 56, eventId: c.H }, d);
    }
  }
  function yx() {
    vx || (vx = new rx());
  }
  var Cx = {
      read_event_data: "e",
      read_container_data: "c",
      configure_google_tags: "t",
    },
    Dx = Object.keys(Cx),
    Ex = function () {
      this.H = !1;
    };
  Ex.prototype.Zh = function (a, b) {
    if (!this.H && P(610)) {
      var c = Cx[a];
      if (c) {
        this.H = !0;
        var d = [
          ["pf", c],
          ["pfs", b],
        ];
        d = d === void 0 ? [] : d;
        yx();
        var e = d,
          f = vx;
        e = e === void 0 ? [] : e;
        if (P(610)) {
          var g,
            h = e;
          h = h === void 0 ? [] : h;
          var k = { id: H(5) },
            m = n(f.ja),
            p = m.next();
          try {
            for (; !p.done; p = m.next()) {
              var q = p.value,
                r = void 0,
                t = n(q({ eventId: (r = f.H) != null ? r : 0, fe: !0 })),
                u = t.next();
              try {
                for (; !u.done; u = t.next()) {
                  var v = n(u.value),
                    x = v.next().value,
                    y = v.next().value;
                  k[x] = y;
                }
              } finally {
                z(t, u);
              }
            }
          } finally {
            z(m, p);
          }
          var B = n(h),
            E = B.next();
          try {
            for (; !E.done; E = B.next()) {
              var F = n(E.value),
                G = F.next().value,
                I = F.next().value;
              k[G] = I;
            }
          } finally {
            z(B, E);
          }
          k.z = 0;
          g = Wk[56](void 0) + "?" + Vi(k, { Ve: !0, Xe: !1 });
          Wl({ destinationId: H(5), endpoint: 56, eventId: f.H }, g);
        }
      }
    }
  };
  var Fx;
  var Gx;
  function Hx(a) {
    return P(610)
      ? function (b) {
          var c = Qa.apply(1, arguments);
          try {
            Gx.Z.apply(Gx, [a, b].concat(w(c)));
          } catch (d) {
            throw (Fx || (Fx = new Ex()), Fx.Zh(b, "p"), d);
          }
        }
      : function (b) {
          Gx.Z.apply(Gx, [a, b].concat(w(Qa.apply(1, arguments))));
        };
  }
  function Ix(a) {
    Gx.ja.apply(Gx, [a].concat(w(Qa.apply(1, arguments))));
  }
  function Jx(a, b) {
    var c;
    (c = Gx) == null || Zf(c.H, a, b);
  }
  var Kx = za(["/"]),
    Lx = function (a) {
      this.H = a;
      this.failureType = void 0;
    };
  Lx.prototype.Mm = function (a, b, c) {
    try {
      var d = this.H.active;
      d
        ? (d.postMessage({ type: 1, command: a }), b({ data: "" }))
        : c({ failureType: 13, data: "" });
    } catch (e) {
      c({ failureType: 11, data: e.message });
    }
  };
  var Mx = function (a, b) {
    this.failureType = a;
    this.H = b;
  };
  Mx.prototype.Mm = function (a, b, c) {
    c({
      failureType: this.failureType,
      data: "f" + this.failureType + ("t" + (new Date().getTime() - this.H)),
    });
  };
  var Px = function (a) {
      var b = this;
      this.initTime = new Date().getTime();
      this.H = new Mx(15, this.initTime);
      var c = new Promise(function (e) {
          A.setTimeout(function () {
            e();
          }, 20);
        }),
        d = Nx(a)
          .then(function (e) {
            b.H = new Lx(e);
            Ox(b, e);
          })
          .catch(function () {
            b.H = new Mx(4, b.initTime);
          });
      this.K = Promise.race([c, d]);
    },
    Ox = function (a, b) {
      var c = function (d) {
        d &&
          d.addEventListener("statechange", function () {
            if (d.state === "redundant") {
              var e = b.active;
              (e && e.state !== "redundant") || (a.H = new Mx(10, a.initTime));
            }
          });
      };
      c(b.active);
      c(b.waiting);
      c(b.installing);
      b.addEventListener("updatefound", function () {
        c(b.installing);
      });
    };
  Px.prototype.delegate = function (a, b, c) {
    var d = this;
    this.K.then(function () {
      d.H.Mm(a, b, c);
    });
  };
  Px.prototype.getState = function () {
    return 2;
  };
  var Nx = function (a) {
    var b,
      c = Lf(11);
    c = Lf(10);
    b = c;
    var d = {
      scope:
        (ac(a.href, "/") ? a.href.slice(0, -1) : a.href) + "/_/service_worker",
    };
    b && (d.updateViaCache = "all");
    var e,
      f = Qx(a, b),
      g = new Map([["path", a.pathname]]),
      h = jq(tc(f).toString());
    e = lq(h.hk, h.params, h.fragment, g);
    var k = Rc(),
      m = tc(e);
    try {
      return k.register(m, d);
    } catch (p) {
      try {
        return k.register(m.toString(), d);
      } catch (q) {
        return Promise.reject(q);
      }
    }
  };
  function Qx(a, b) {
    var c = kq(Kx),
      d = a.pathname.split("/").filter(function (h) {
        return h.length > 0;
      }),
      e = [].concat(w(d), ["_", "service_worker", b, "sw.js"]),
      f = n(e),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) c = mq(c, g.value);
    } finally {
      z(f, g);
    }
    return c;
  }
  function Rx(a) {
    var b = uk(qk.ba.Dh),
      c = b == null ? void 0 : b[a];
    c || a !== "lite" || (c = b == null ? void 0 : b.full);
    return c;
  }
  var Sx = function (a, b, c) {
    var d = Rx("full");
    d ? d.delegate(a, b, c) : c({ failureType: 16 });
  };
  function Tx(a, b, c, d, e, f) {
    Sx(
      {
        commandType: 0,
        params: {
          url: a,
          method: 1,
          templates: b,
          body: "",
          processResponse: !1,
          encryptionKeyString: e,
          soReferrer: A.location.href,
          collectEncryptionMetrics: f,
        },
      },
      c,
      function (g) {
        d(g.failureType, g.data);
      }
    );
  }
  var jy = function () {
    Ng.apply(this, arguments);
  };
  ta(jy, Ng);
  jy.prototype.K = function (a, b) {
    hd(a, void 0, Pg(this, b), b.attribution_reporting && hx() ? fx : {});
  };
  jy.prototype.H = function (a, b) {
    var c = b.attribution_reporting && hx() ? { attributionReporting: gx } : {},
      d = Pg(this, b);
    b.process_response
      ? Xw(a, void 0, this, c, void 0, d)
      : vd(a, void 0, c, void 0, d);
  };
  var uy = function (a, b) {
      this.H = a;
      this.timeoutMs = b;
      this.Ab = void 0;
    },
    vy = function (a) {
      a.Ab ||
        (a.Ab = setTimeout(function () {
          a.H();
          a.Ab = void 0;
        }, a.timeoutMs));
    },
    wy = function (a) {
      a.Ab && (clearTimeout(a.Ab), (a.Ab = void 0));
    };
  var xy = function () {
      var a = Nf(66, 0);
      this.K = [];
      this.T = a;
      this.H = $a();
    },
    zy = function (a) {
      var b = yy;
      b.K.push(a);
      b.P ||
        ((b.P = function () {
          var c = n(b.K),
            d = c.next();
          try {
            for (; !d.done; d = c.next()) {
              var e = d.value;
              try {
                e();
              } catch (k) {}
            }
          } finally {
            z(c, d);
          }
          var f = n(b.H.values()),
            g = f.next();
          try {
            for (; !g.done; g = f.next()) {
              var h = void 0;
              (h = g.value.gk) == null || wy(h);
            }
          } finally {
            z(f, g);
          }
          b.H.clear();
        }),
        id(A, "pagehide", b.P));
    },
    Ay = function (a) {
      var b = a.match(Ml)[3] || null,
        c = (b ? decodeURI(b) : b) || "",
        d = Pl(a, "label") || "",
        e = Pl(a, "random") || "";
      return c + ":" + Ll(d) + ":" + Ll(e);
    };
  xy.prototype.addRequest = function (a, b, c) {
    var d = Ay(a);
    if (!(this.H.has(d) || this.H.size >= this.T)) {
      var e = {};
      b && b > 0 && c && (e.gk = new uy(c, b));
      this.H.set(d, e);
      var f;
      (f = e.gk) == null || vy(f);
    }
  };
  var Tl = function (a, b) {
    var c = Ay(b),
      d,
      e;
    (d = a.H.get(c)) == null || (e = d.gk) == null || wy(e);
    a.H.delete(c);
  };
  xy.prototype.getSize = function () {
    return this.H.size;
  };
  var Ty = {
    X: {
      kp: 0,
      kk: 1,
      Ug: 2,
      vk: 3,
      gi: 4,
      sk: 5,
      uk: 6,
      wk: 7,
      hi: 8,
      Fl: 9,
      El: 10,
      Mi: 11,
      Gl: 12,
      th: 13,
      Il: 14,
      Yi: 15,
      fp: 16,
      gd: 17,
      fj: 18,
      gj: 19,
      ij: 20,
      hm: 21,
      jj: 22,
    },
  };
  Ty.X[Ty.X.kp] = "RESERVED_ZERO";
  Ty.X[Ty.X.kk] = "ADS_CONVERSION_HIT";
  Ty.X[Ty.X.Ug] = "CONTAINER_EXECUTE_START";
  Ty.X[Ty.X.vk] = "CONTAINER_SETUP_END";
  Ty.X[Ty.X.gi] = "CONTAINER_SETUP_START";
  Ty.X[Ty.X.sk] = "CONTAINER_BLOCKING_END";
  Ty.X[Ty.X.uk] = "CONTAINER_EXECUTE_END";
  Ty.X[Ty.X.wk] = "CONTAINER_YIELD_END";
  Ty.X[Ty.X.hi] = "CONTAINER_YIELD_START";
  Ty.X[Ty.X.Fl] = "EVENT_EXECUTE_END";
  Ty.X[Ty.X.El] = "EVENT_EVALUATION_END";
  Ty.X[Ty.X.Mi] = "EVENT_EVALUATION_START";
  Ty.X[Ty.X.Gl] = "EVENT_SETUP_END";
  Ty.X[Ty.X.th] = "EVENT_SETUP_START";
  Ty.X[Ty.X.Il] = "GA4_CONVERSION_HIT";
  Ty.X[Ty.X.Yi] = "PAGE_LOAD";
  Ty.X[Ty.X.fp] = "PAGEVIEW";
  Ty.X[Ty.X.gd] = "SNIPPET_LOAD";
  Ty.X[Ty.X.fj] = "TAG_CALLBACK_ERROR";
  Ty.X[Ty.X.gj] = "TAG_CALLBACK_FAILURE";
  Ty.X[Ty.X.ij] = "TAG_CALLBACK_SUCCESS";
  Ty.X[Ty.X.hm] = "TAG_EXECUTE_END";
  Ty.X[Ty.X.jj] = "TAG_EXECUTE_START";
  var Uy = {};
  Uy.X = Ty.X;
  var Vy = {
      Xt: "L",
      np: "S",
      iu: "Y",
      Ns: "B",
      ot: "E",
      Tt: "I",
      eu: "TC",
      Bt: "HTC",
      rt: "F",
      St: "C",
    },
    Wy = { np: "S", kt: "V", Us: "E", du: "tag" },
    Xy = {},
    Yy = ((Xy[Uy.X.gj] = "6"), (Xy[Uy.X.ij] = "5"), (Xy[Uy.X.fj] = "7"), Xy);
  function Zy(a) {
    var b = H(5),
      c = Number(a.eventId),
      d = Number(a.tagId);
    return (
      ($b(b, "GTM-") ? b : "GTM-" + b) +
      ":" +
      (Kb(c) ? c + ":" : "") +
      (Kb(d) ? d + ":" : "") +
      a.stage
    );
  }
  function $y() {
    var a = Ad();
    return !!(
      a &&
      a.mark instanceof Function &&
      a.measure instanceof Function &&
      a.clearMeasures instanceof Function &&
      a.clearMarks instanceof Function
    );
  }
  var az = function () {
    this.H = {};
  };
  az.prototype.mark = function (a, b) {
    if ($y()) {
      var c = Zy(a),
        d,
        e;
      if ((d = (e = Ad()) == null ? void 0 : e.mark(c, b)))
        return (this.H[c] = d);
    }
  };
  var bz;
  function cz() {
    bz || (bz = new az());
    return bz;
  }
  function dz(a) {
    var b = cz(),
      c = Zy(a);
    return b.H[c];
  }
  function ez(a, b) {
    return cz().mark(a, b);
  }
  function fz(a, b) {
    if ($y()) {
      a.entry = Zy(a);
      var c = ma(Object, "assign").call(Object, {}, a);
      c.stage = b;
      delete c.sent;
      var d = dz(b === Uy.X.gd ? { stage: Uy.X.gd } : c),
        e = dz(a);
      if (d && e && !(d.startTime > e.startTime)) {
        c.stage = b + ":" + a.stage;
        var f = Zy(c),
          g = { start: d.name, end: e.name },
          h,
          k;
        return (k = (h = Ad()) == null ? void 0 : h.measure(f, g)) == null
          ? void 0
          : k.duration;
      }
    }
  }
  function gz() {
    function a(c, d) {
      var e = yb(vb[d] || []);
      e && b.push([c, e]);
    }
    var b = [];
    a("u", "GTM");
    a("ut", "TAGGING");
    a("h", "HEALTH");
    return b;
  }
  var hz = "https://" + H(21),
    iz = function () {
      this.P = !1;
      this.T = [];
      this.Z = [];
      this.H = { TC: 0, HTC: 0 };
      this.K = {};
    },
    jz = function (a, b, c, d) {
      a.K[b] || (a.K[b] = {});
      a.K[b][c] = d;
    },
    mz = function (a) {
      var b = "",
        c = "",
        d = kz();
      Kb(d) && (a.H.I = Math.floor(d));
      c = lz(a.H, Vy).toString();
      var e = n(Object.keys(a.K)),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value,
            h = a.K[g].name,
            k = "",
            m = lz(a.K[g], Wy);
          m && ((k = h + "." + m.toString()), (b += "~" + k));
        }
      } finally {
        z(e, f);
      }
      var p = "~AWCT" + a.T.join("."),
        q = "~GA" + a.Z.join("."),
        r =
          "&ccid=" +
          mm().toString() +
          "&cid=" +
          H(5).toString() +
          "&l=" +
          c +
          b +
          (a.T.length ? p : "") +
          (a.Z.length ? q : "");
      if (P(214)) {
        var t,
          u =
            (t = Ad()) == null
              ? void 0
              : t
                  .getEntriesByName(Uc)
                  .map(function (v) {
                    return String(v.duration);
                  })
                  .join(".");
        u && (r += "~SS" + u);
      }
      return r;
    },
    nz = function (a, b) {
      if (!b.stage || a.P || !$y() || dz(b)) return !1;
      var c,
        d = (c = Ad()) == null ? void 0 : c.timeOrigin;
      if (!Kb(d)) a.P = !0;
      else if (Kb(Zi(11)) && !dz({ stage: Uy.X.gd }) && !a.P && $y())
        try {
          var e = Number(Zi(11));
          ez({ stage: Uy.X.gd }, { startTime: Math.max(e - d, 0) });
          ez({ stage: Uy.X.Yi }, { startTime: 0 });
          var f = fz({ stage: Uy.X.gd }, Uy.X.Yi);
          f && (a.H.L = Math.floor(f));
        } catch (g) {
          a.P = !0;
        }
      if (a.P) return !1;
      try {
        if (!ez(b)) return !1;
      } catch (g) {
        return (a.P = !0), !1;
      }
      return !0;
    },
    oz = function (a, b, c) {
      if (nz(a, b))
        try {
          var d = fz(b, c);
          if (d) return Math.floor(d);
        } catch (e) {
          a.P = !0;
        }
    },
    qz = function () {
      var a = pz();
      nz(a, { stage: Uy.X.gi });
    },
    rz = function () {
      var a = pz(),
        b = oz(a, { stage: Uy.X.vk }, Uy.X.gi);
      b !== void 0 && (a.H.S = b);
    },
    sz = function () {
      var a = pz();
      nz(a, { stage: Uy.X.hi });
    },
    tz = function (a, b) {
      var c = pz();
      nz(c, { stage: Uy.X.th, eventId: a });
      (c.K[a] && c.K[a].name) || jz(c, a, "name", $b(b, "gtm.") ? b : "*");
    },
    uz = function (a) {
      var b = pz(),
        c = oz(b, { stage: Uy.X.Gl, eventId: a }, Uy.X.th);
      c !== void 0 && jz(b, a, "S", c);
    },
    wz = function (a, b) {
      var c = pz(),
        d = oz(c, { stage: Uy.X.Fl, eventId: a }, Uy.X.th);
      d !== void 0 && jz(c, a, "E", d);
      if (b === "gtm.load") {
        var e = oz(c, { stage: Uy.X.uk }, Uy.X.Ug);
        e !== void 0 && (c.H.E = e);
        $m(cn(3), function () {
          if (!c.P && $y() && H(5)) {
            var f = vz();
            f !== void 0 && (c.H.F = Math.floor(f));
            try {
              var g = gz({ eventId: 0, fe: !1 }),
                h = [],
                k = n(g),
                m = k.next();
              try {
                for (; !m.done; m = k.next()) {
                  var p = n(m.value),
                    q = p.next().value,
                    r = p.next().value;
                  h.push("&" + q + "=" + r);
                }
              } finally {
                z(k, m);
              }
              var t = aq(),
                u = [
                  [
                    Uj(hz),
                    "/a?v=3&t=l",
                    "&pid=" + Nb().toString(),
                    "&rv=" + H(14),
                    t ? "&tag_exp=" + t : "",
                    h.join(""),
                  ].join(""),
                  "&gtm=",
                  Ku(),
                  mz(c),
                ].join("");
              if (u.length > 2022) {
                var v = Math.max(
                  u.lastIndexOf(".TS", 2022),
                  u.lastIndexOf("~", 2022)
                );
                u = u.slice(0, v);
              }
              Wl({ destinationId: H(5), endpoint: 56 }, u);
            } catch (x) {}
          }
        });
      }
    },
    xz;
  function pz() {
    xz || (xz = new iz());
    return xz;
  }
  function kz() {
    try {
      var a;
      return ((a = Ad()) == null ? void 0 : a.getEntriesByType("navigation")[0])
        .domInteractive;
    } catch (b) {}
  }
  function lz(a, b) {
    return Object.keys(b)
      .map(function (c) {
        return b[c];
      })
      .filter(function (c) {
        return a[c] !== void 0;
      })
      .map(function (c) {
        return ("" + (c === "tag" ? "" : c)).concat(a[c].toString());
      })
      .join(".");
  }
  function yz(a) {
    var b = pz(),
      c = oz(b, { stage: Uy.X.Il, eventId: a }, Uy.X.gd);
    c !== void 0 && b.Z.push(c);
  }
  function zz(a) {
    var b = pz(),
      c = oz(b, { stage: Uy.X.kk, eventId: a }, Uy.X.gd);
    c !== void 0 && b.T.push(c);
  }
  function Az(a) {
    var b = pz();
    nz(b, { stage: Uy.X.Mi, eventId: a });
  }
  function Bz(a) {
    var b = pz(),
      c = oz(b, { stage: Uy.X.El, eventId: a }, Uy.X.Mi);
    c !== void 0 && jz(b, a, "V", c);
  }
  function vz() {
    try {
      var a, b;
      return (b =
        (a = Ad()) == null
          ? void 0
          : a.getEntriesByType("paint").find(function (c) {
              return c.name === "first-contentful-paint";
            })) == null
        ? void 0
        : b.startTime;
    } catch (c) {}
  }
  function Cz(a, b) {
    var c = pz();
    nz(c, { stage: Uy.X.jj, eventId: a.id, tagId: Number(b.tag_id) });
  }
  function Dz(a, b, c) {
    var d = pz(),
      e = el(b),
      f = Number(b.tag_id),
      g = oz(d, { stage: c, eventId: a.id, tagId: f }, Uy.X.jj);
    if (g !== void 0 && d.K[a.id]) {
      var h = d.K[a.id].tag || "",
        k,
        m = (k = Yy[c]) != null ? k : "1",
        p = new RegExp("TS\\d" + e + ".TI" + f),
        q = "TS" + m + e + ".TI" + f + ".TE" + g;
      h.search(p) >= 0
        ? m !== "1" &&
          jz(d, a.id, "tag", h.replace(p, q.replace(".TE" + g, "")))
        : (jz(d, a.id, "tag", (h ? h + "." : "") + q),
          e === "html" && (d.H.HTC += 1),
          (d.H.TC += 1));
    }
  }
  var Iz = { Xi: { Hn: "1", So: "2", jp: "3" } };
  var Nz, Oz;
  function Pz(a, b) {
    var c = a["function"];
    if (!c) throw Error("Error: No function name given for function call.");
    var d = Oz[c],
      e = {},
      f;
    for (f in a)
      a.hasOwnProperty(f) &&
        ($b(f, "vtp_")
          ? (e[d !== void 0 ? f : f.substring(4)] = a[f])
          : f === "generated_tagging_metadata".toString() &&
            (e[d !== void 0 ? "vtp_gtmGeneratedTaggingMetadata" : f] = a[f]));
    If(61) && d && (e.vtp_extraExperimentIds = !0);
    d && ((e.vtp_gtmEntityIndex = b.index), (e.vtp_gtmEntityName = b.name));
    return d !== void 0 ? d(e) : Nz(c, e, b);
  }
  var Qz = function (a, b, c, d, e, f, g, h, k, m, p, q, r) {
    this.eventId = a;
    this.priorityId = b;
    this.priorityQueue = c;
    this.Ja = d;
    this.Wa = e;
    this.fb = f;
    this.Dc = g;
    this.vg = h;
    this.ib = k;
    this.eventMetadata = m;
    this.onSuccess = p;
    this.onFailure = q;
    this.isGtmEvent = r;
  };
  Qz.prototype.copy = function (a) {
    a = a === void 0 ? {} : a;
    var b,
      c,
      d,
      e,
      f,
      g,
      h,
      k,
      m,
      p,
      q,
      r,
      t,
      u,
      v,
      x,
      y,
      B,
      E,
      F,
      G,
      I,
      J,
      M,
      U,
      W;
    return new Qz(
      (u = (b = a) == null ? void 0 : b.eventId) != null ? u : this.eventId,
      (v = (c = a) == null ? void 0 : c.priorityId) != null
        ? v
        : this.priorityId,
      (x = (d = a) == null ? void 0 : d.priorityQueue) != null
        ? x
        : this.priorityQueue,
      (y = (e = a) == null ? void 0 : e.Ja) != null ? y : this.Ja,
      (B = (f = a) == null ? void 0 : f.Wa) != null ? B : this.Wa,
      (E = (g = a) == null ? void 0 : g.fb) != null ? E : this.fb,
      (F = (h = a) == null ? void 0 : h.Dc) != null ? F : this.Dc,
      (G = (k = a) == null ? void 0 : k.vg) != null ? G : this.vg,
      (I = (m = a) == null ? void 0 : m.ib) != null ? I : this.ib,
      (J = (p = a) == null ? void 0 : p.eventMetadata) != null
        ? J
        : this.eventMetadata,
      (M = (q = a) == null ? void 0 : q.onSuccess) != null ? M : this.onSuccess,
      (U = (r = a) == null ? void 0 : r.onFailure) != null ? U : this.onFailure,
      (W = (t = a) == null ? void 0 : t.isGtmEvent) != null
        ? W
        : this.isGtmEvent
    );
  };
  var Rz = function (a, b) {
      var c = [];
      switch (b) {
        case 3:
          c.push(a.Ja);
          c.push(a.Wa);
          c.push(a.fb);
          c.push(a.Dc);
          c.push(a.ib);
          break;
        case 2:
          c.push(a.Ja);
          break;
        case 1:
          c.push(a.Wa);
          c.push(a.fb);
          c.push(a.Dc);
          c.push(a.ib);
          break;
        case 4:
          c.push(a.Ja), c.push(a.Wa), c.push(a.fb), c.push(a.Dc);
      }
      return c;
    },
    Q = function (a, b, c, d) {
      var e = n(Rz(a, d === void 0 ? 3 : d)),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value;
          if (g[b] !== void 0) return g[b];
        }
      } finally {
        z(e, f);
      }
      return c;
    },
    Sz = function (a) {
      var b = {},
        c = Rz(a, 4),
        d = n(c),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = Object.keys(e.value),
            g = n(f),
            h = g.next();
          try {
            for (; !h.done; h = g.next()) b[h.value] = 1;
          } finally {
            z(g, h);
          }
        }
      } finally {
        z(d, e);
      }
      return Object.keys(b);
    };
  Qz.prototype.getMergedValues = function (a, b, c) {
    b = b === void 0 ? 3 : b;
    var d = {},
      e = !1,
      f = function (m) {
        if (Db(m)) {
          var p = n(Object.entries(m)),
            q = p.next();
          try {
            for (; !q.done; q = p.next()) {
              var r = n(q.value),
                t = r.next().value,
                u = r.next().value,
                v = t,
                x = u;
              e = !0;
              d[v] = x;
            }
          } finally {
            z(p, q);
          }
        }
      };
    c && f(c);
    var g = Rz(this, b);
    g.reverse();
    var h = n(g),
      k = h.next();
    try {
      for (; !k.done; k = h.next()) f(k.value[a]);
    } finally {
      z(h, k);
    }
    return e ? d : void 0;
  };
  var Tz = function (a, b, c) {
      this.eventId = a;
      this.priorityId = b;
      this.priorityQueue = c;
      this.Ja = {};
      this.Wa = {};
      this.fb = {};
      this.Dc = {};
      this.vg = {};
      this.ib = {};
      this.eventMetadata = {};
      this.isGtmEvent = !1;
      this.onSuccess = function () {};
      this.onFailure = function () {};
    },
    Uz = function (a, b) {
      a.Ja = b;
      return a;
    },
    Vz = function (a, b) {
      a.Wa = b;
      return a;
    },
    Wz = function (a, b) {
      a.fb = b;
      return a;
    },
    Xz = function (a, b) {
      a.Dc = b;
      return a;
    },
    Yz = function (a, b) {
      a.vg = b;
      return a;
    },
    Zz = function (a, b) {
      a.ib = b;
      return a;
    },
    $z = function (a, b) {
      a.eventMetadata = b || {};
      return a;
    },
    aA = function (a, b) {
      a.onSuccess = b;
      return a;
    },
    bA = function (a, b) {
      a.onFailure = b;
      return a;
    },
    cA = function (a, b) {
      a.isGtmEvent = b;
      return a;
    },
    dA = function (a) {
      return new Qz(
        a.eventId,
        a.priorityId,
        a.priorityQueue,
        a.Ja,
        a.Wa,
        a.fb,
        a.Dc,
        a.vg,
        a.ib,
        a.eventMetadata,
        a.onSuccess,
        a.onFailure,
        a.isGtmEvent
      );
    },
    eA = ["__proto__", "constructor", "prototype"];
  function fA(a) {
    return a.split(".").some(function (b) {
      return eA.indexOf(b) !== -1;
    });
  }
  var gA = ["event", "gtm.uniqueEventId", "gtm.priorityId"],
    jA = function () {
      var a = this;
      this.K = new Pb();
      this.H = {};
      this.T = {};
      this.P = {};
      this.Z = {
        name: H(19),
        set: function (b, c) {
          Eb(cc(b, c), a.H);
          P(660) && hA(a, b, c);
          iA(a);
        },
        get: function (b) {
          return a.get(b, 2);
        },
        reset: function () {
          a.K = new Pb();
          a.H = {};
          a.T = {};
          iA(a);
        },
      };
    };
  jA.prototype.get = function (a, b) {
    return b != 2 ? this.K.get(a) : kA(this, a);
  };
  var kA = function (a, b, c) {
      var d = b.split(".");
      c = c || [];
      for (var e = a.H, f = 0; f < d.length; f++) {
        if (e === null) return !1;
        if (e === void 0) break;
        e = e[d[f]];
        if (c.indexOf(e) !== -1) return;
      }
      return e;
    },
    hA = function (a, b, c) {
      var d;
      if (!(d = a.P.hasOwnProperty(b)))
        a: {
          var e = n(gA),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) {
              var g = f.value;
              if (b === g || $b(b, g + ".")) {
                d = !0;
                break a;
              }
            }
          } finally {
            z(e, f);
          }
          d = !1;
        }
      d || fA(b) || (Eb(cc(b), a.T), Eb(cc(b, c), a.T));
    };
  jA.prototype.set = function (a, b) {
    this.P.hasOwnProperty(a) ||
      (this.K.set(a, b), Eb(cc(a, b), this.H), iA(this));
  };
  var mA = function () {
      for (
        var a = [
            "gtm.allowlist",
            "gtm.blocklist",
            "gtm.whitelist",
            "gtm.blacklist",
            "tagTypeBlacklist",
          ],
          b = lA,
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c],
          e = b.get(d, 1);
        if (Array.isArray(e) || Db(e)) e = Eb(e, null);
        b.P[d] = e;
      }
    },
    iA = function (a, b) {
      var c = n(Object.entries(a.P)),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = n(d.value),
            f = e.next().value,
            g = e.next().value,
            h = f,
            k = g;
          a.K.set(h, k);
          Eb(cc(h), a.H);
          Eb(cc(h, k), a.H);
          b && delete a.P[h];
        }
      } finally {
        z(c, d);
      }
    },
    lA = new jA(),
    nA = lA.Z;
  function oA(a, b) {
    return lA.get(a, b);
  }
  function pA(a, b) {
    var c = b === void 0 ? 2 : b,
      d = lA,
      e,
      f = (c === void 0 ? 2 : c) !== 1 ? kA(d, a) : d.K.get(a);
    Ab(f) === "array" || Ab(f) === "object" ? (e = Eb(f, null)) : (e = f);
    return e;
  }
  var qA = new RegExp(
      /^(.*\.)?(google|youtube|blogger|withgoogle)(\.com?)?(\.[a-z]{2})?\.?$/
    ),
    rA = {
      cl: ["ecl"],
      customPixels: ["nonGooglePixels"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: [
        "customScripts",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      customScripts: [
        "html",
        "customPixels",
        "nonGooglePixels",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGooglePixels: [],
      nonGoogleScripts: ["nonGooglePixels"],
      nonGoogleIframes: ["nonGooglePixels"],
    },
    sA = {
      cl: ["ecl"],
      customPixels: ["customScripts", "html"],
      ecl: ["cl"],
      ehl: ["hl"],
      gaawc: ["googtag"],
      hl: ["ehl"],
      html: ["customScripts"],
      customScripts: ["html"],
      nonGooglePixels: [
        "customPixels",
        "customScripts",
        "html",
        "nonGoogleScripts",
        "nonGoogleIframes",
      ],
      nonGoogleScripts: ["customScripts", "html"],
      nonGoogleIframes: ["customScripts", "html", "nonGoogleScripts"],
    },
    tA =
      "google customPixels customScripts html nonGooglePixels nonGoogleScripts nonGoogleIframes".split(
        " "
      );
  function uA() {
    var a = oA("gtm.allowlist") || oA("gtm.whitelist");
    a && R(9);
    If(62) && (a = void 0);
    vA() &&
      (If(62)
        ? (R(116), $b(H(5), "GTM-") && R(199))
        : (R(117),
          !P(647) &&
            If(48) &&
            ((a = []),
            window.console &&
              window.console.log &&
              window.console.log("GTM blocked. See go/13687728."))));
    var b = a && Zb(Tb(a), rA),
      c = oA("gtm.blocklist") || oA("gtm.blacklist");
    c || ((c = oA("tagTypeBlacklist")) && R(3));
    c ? R(8) : (c = []);
    vA() &&
      ((c = Tb(c)),
      c.push("nonGooglePixels", "nonGoogleScripts", "sandboxedScripts"));
    Tb(c).indexOf("google") >= 0 && R(2);
    var d = c && Zb(Tb(c), sA),
      e = {};
    return function (f) {
      var g = f && f["function"];
      if (!g || typeof g !== "string") return !0;
      g = g.replace(/^_*/, "");
      if (e[g] !== void 0) return e[g];
      var h =
          $i(21, function () {
            return {};
          })[g] || [],
        k = !0;
      a && (k = k && wA(g, h, b));
      var m = !1;
      c && (m = xA(g, h, d));
      var p = !k || m;
      !p &&
        (h.indexOf("sandboxedScripts") === -1 ||
        (b && b.indexOf("sandboxedScripts") !== -1)
          ? 0
          : Ob(d, tA)) &&
        (p = !0);
      return (e[g] = p);
    };
  }
  function wA(a, b, c) {
    if (c.indexOf(a) < 0)
      if (b && b.length > 0)
        for (var d = 0; d < b.length; d++) {
          if (c.indexOf(b[d]) < 0) return R(11), !1;
        }
      else return !1;
    return !0;
  }
  function xA(a, b, c) {
    var d = c.indexOf(a) >= 0;
    if (d) return d;
    var e = Ob(c, b || []);
    e && R(10);
    return e;
  }
  function vA() {
    return qA.test(A.location && A.location.hostname);
  }
  var zA = function () {
      var a = yA,
        b = H(5).indexOf("GTM-") === 0 && If(62);
      P(639) && !a.K && b && vA() && ((a.K = !0), R(201));
      if (P(585) && gl.K) {
        var c = H(5).indexOf("OPT-") === 0,
          d,
          e = ((d = xm()) == null ? void 0 : d.source) === 1;
        vA() || (b && !e) || a.H || c || ((a.H = !0), gj("abl", "1"), kn());
      }
    },
    yA = new (function () {
      this.K = this.H = !1;
    })();
  var AA = function (a, b, c, d) {
    this.H = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.name = String(this.H.instance_name || "");
  };
  AA.prototype.evaluate = function (a, b) {
    if (!b[this.index] && !a.Cj(this.H)) {
      b[this.index] = !0;
      this.H["disabled_in_google_mode".toString()] && zA();
      var c = this.name,
        d;
      try {
        var e = {},
          f;
        for (f in this.H)
          this.H.hasOwnProperty(f) &&
            (e[f] = zo(this.H[f], a, this.tags, this.macros, b));
        e.vtp_gtmEventId = a.id;
        a.priorityId && (e.vtp_gtmPriorityId = a.priorityId);
        var g = (d = Pz(e, { event: a, index: this.index, type: 2, name: c }));
        e.convert_case_to &&
          typeof g === "string" &&
          (g = e.convert_case_to === 1 ? g.toLowerCase() : g.toUpperCase());
        e.hasOwnProperty("convert_to_number") &&
          (g =
            e.convert_to_number === 1
              ? Wf(g, "PERIOD")
              : e.convert_to_number === 2
              ? Wf(g, "COMMA")
              : Wf(g, "AUTOMATIC"));
        e.hasOwnProperty("convert_null_to") &&
          g === null &&
          (g = e.convert_null_to);
        e.hasOwnProperty("convert_undefined_to") &&
          g === void 0 &&
          (g = e.convert_undefined_to);
        e.hasOwnProperty("convert_to_boolean") && (g = Sb(g));
        e.hasOwnProperty("convert_true_to") &&
          g === !0 &&
          (g = e.convert_true_to);
        e.hasOwnProperty("convert_false_to") &&
          g === !1 &&
          (g = e.convert_false_to);
        d = g;
      } catch (h) {
        a.Tm && a.Tm(h, Number(this.index), c), (d = !1);
      }
      b[this.index] = !1;
      return d;
    }
  };
  AA.prototype.zg = function () {
    return ma(Object, "assign").call(Object, {}, this.H);
  };
  var BA = function (a, b, c) {
    this.H = a;
    this.tags = b;
    this.macros = c;
  };
  BA.prototype.evaluate = function (a, b) {
    try {
      var c = {},
        d = n(Object.keys(this.H)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = e.value;
          c[f] =
            f === "function"
              ? this.H[f]
              : zo(this.H[f], a, this.tags, this.macros, b);
        }
      } finally {
        z(d, e);
      }
      return xo(c);
    } catch (g) {
      JSON.stringify(this.H);
    }
    return 2;
  };
  BA.prototype.zg = function () {
    return ma(Object, "assign").call(Object, {}, this.H);
  };
  var CA = function (a, b) {
    this.index = b;
    this.P = [];
    this.Z = [];
    this.K = [];
    this.H = [];
    this.name = "";
    this.T = !1;
    var c = n(a),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = n(d.value),
          f = e.next().value,
          g = xa(e),
          h = f,
          k = g;
        h === "if"
          ? (this.P = k)
          : h === "unless"
          ? (this.Z = k)
          : h === "add"
          ? (this.K = k)
          : h === "block"
          ? (this.H = k)
          : h === "ruleName"
          ? (this.name = k[0])
          : h === "matchSystemEvents" && (this.T = !0);
      }
    } finally {
      z(c, d);
    }
  };
  CA.prototype.evaluate = function (a, b) {
    var c;
    c = P(676) && a.isSystemEvent && !this.T ? 4 : DA(this, b);
    var d = [],
      e = [];
    c === 1
      ? (d.push.apply(d, w(this.K)), e.push.apply(e, w(this.H)))
      : c === 3 && e.push.apply(e, w(this.H));
    if (If(71)) {
      var f;
      switch (c) {
        case 1:
          f = !0;
          break;
        case 2:
          f = !1;
          break;
        case 3:
          f = null;
          break;
        case 4:
          f = !1;
          break;
        default:
          f = null;
      }
      a.bs[String(this.index)] = { wu: f, result: c };
    }
    return { firingTags: d, blockingTags: e };
  };
  var DA = function (a, b) {
    var c = n(a.P),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = b(d.value);
        if (e === 0) return 2;
        if (e === 2) return 3;
      }
    } finally {
      z(c, d);
    }
    var f = n(a.Z),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = b(g.value);
        if (h === 2) return 3;
        if (h === 1) return 2;
      }
    } finally {
      z(f, g);
    }
    return 1;
  };
  CA.prototype.getName = function () {
    return this.name;
  };
  var EA = function (a, b, c, d) {
    this.Ha = a;
    this.index = b;
    this.tags = c;
    this.macros = d;
    this.R = String(this.Ha["function"]);
    this.name = String(this.Ha.instance_name || "");
    this.tagId = Number(this.Ha.tag_id);
  };
  EA.prototype.evaluate = function (a, b, c) {
    c = c === void 0 ? {} : c;
    var d,
      e = c;
    e = e === void 0 ? {} : e;
    var f = {},
      g;
    for (g in this.Ha)
      this.Ha.hasOwnProperty(g) &&
        (f[g] = zo(this.Ha[g], a, this.tags, this.macros, []));
    d = ma(Object, "assign").call(Object, {}, f, e);
    d.vtp_gtmTagId = this.tagId;
    this.Ha["disabled_in_google_mode".toString()] && zA();
    Pz(d, { event: a, index: this.index, type: 1, name: this.name });
  };
  EA.prototype.zg = function () {
    return ma(Object, "assign").call(Object, {}, this.Ha);
  };
  var FA = function (a, b) {
      if (a.Ha.setup_tags) return zo(a.Ha.setup_tags, b, a.tags, a.macros, []);
    },
    GA = function (a, b) {
      if (a.Ha.teardown_tags)
        return zo(a.Ha.teardown_tags, b, a.tags, a.macros, []);
    },
    HA = function (a, b) {
      var c = a.Ha.consent;
      if (c) return zo(c, b, a.tags, a.macros, []);
    };
  EA.prototype.getMetadata = function (a) {
    return zo(this.Ha.metadata, a, this.tags, this.macros, []);
  };
  EA.prototype.getName = function () {
    return this.name;
  };
  var IA = function () {
    this.macros = [];
    this.rules = [];
    this.predicates = [];
    this.tags = [];
    this.dk = [];
  };
  IA.prototype.getRules = function () {
    return this.rules;
  };
  var JA = new IA();
  var KA = !1;
  var LA = new Set(
      "dest_aw dest_ga dest_mc dest_dc __dest_aw __dest_ga __dest_mc __dest_dc".split(
        " "
      )
    ),
    MA,
    NA = new Map();
  function OA(a) {
    var b = NA.get(a);
    b === void 0 && ((b = Ym(cn(3))), NA.set(a, b));
    var c;
    if (
      !(c =
        b ||
        Ro() ||
        KA ||
        If(66) ||
        !km().includes(a) ||
        PA(a) === 3 ||
        a.indexOf("UA-") === 0)
    ) {
      if (MA === void 0)
        a: {
          for (var d = JA.tags, e = 0; e < d.length; e++) {
            var f = d[e];
            if (f && LA.has(f.R)) {
              MA = !0;
              break a;
            }
          }
          MA = !1;
        }
      c = !MA;
    }
    return c || Kf(67).includes("120213116") || !Kf(67).includes("121049589")
      ? !1
      : $p(612);
  }
  function QA(a, b) {
    vk(qk.ba.lg, {})[a] = b;
    yk(qk.ba.lg);
  }
  function RA() {
    var a = H(5);
    QA(a, 2);
  }
  function PA(a) {
    var b;
    return (b = uk(qk.ba.lg)) == null ? void 0 : b[a];
  }
  function SA(a, b) {
    var c = PA(a);
    if (c === 2 || c === 3) b();
    else {
      c !== 1 && QA(a, 1);
      var d;
      d = wk(qk.ba.lg, function (e, f) {
        var g = f == null ? void 0 : f[a];
        if (g === 2 || g === 3) d !== void 0 && xk(qk.ba.lg, d), b();
      });
    }
  }
  function TA(a, b, c) {
    var d = fd(),
      e;
    if (d === 1)
      a: {
        var f = H(3);
        f = f.toLowerCase();
        for (
          var g = "https://" + f,
            h = "http://" + f,
            k = 1,
            m = C.getElementsByTagName("script"),
            p = 0;
          p < m.length && p < 100;
          p++
        ) {
          var q = m[p].src;
          if (q) {
            q = q.toLowerCase();
            if (q.indexOf(h) === 0) {
              e = 3;
              break a;
            }
            k === 1 && q.indexOf(g) === 0 && (k = 2);
          }
        }
        e = k;
      }
    else e = d;
    return (e === 2 || "http:" !== A.location.protocol ? a : b) + c;
  }
  var UA = function () {
      var a = this;
      this.K = {};
      this.H = {};
      xx(function (b) {
        var c = [],
          d;
        for (d in a.K)
          Object.prototype.hasOwnProperty.call(a.K, d) &&
            c.push(d + "~" + a.K[d]);
        var e = [],
          f;
        for (f in a.H)
          Object.prototype.hasOwnProperty.call(a.H, f) &&
            e.push(f + "~" + a.H[f]);
        b.fe && ((a.K = {}), (a.H = {}));
        var g = [];
        c.length > 0 && g.push(["bcs", c.join(".")]);
        e.length > 0 && g.push(["bet", e.join(".")]);
        return g;
      });
    },
    VA;
  function WA() {
    VA || (VA = new UA());
  }
  function XA(a, b, c, d, e) {
    if (!wm(a)) {
      d.loadExperiments = kj();
      zm(a, d, e);
      var f = YA(a),
        g = function () {
          gm().container[a] && (gm().container[a].state = 3);
          ZA();
        },
        h = { destinationId: a, endpoint: 0 };
      if (Lj()) {
        var k = Mj(),
          m = k + "/" + $A(f, a);
        Yl(h, m, void 0, function () {
          aB(a, m, k + "/" + f, h, g);
        });
      } else {
        var p = $b(a, "GTM-"),
          q = Sj(),
          r = c ? "/gtag/js" : "/gtm.js",
          t = bB(b, r + f, a);
        if (!t) {
          var u = H(3) + r;
          if (q && Uc && p) {
            u = Uc.replace(/^(?:https?:\/\/)?/i, "").split(/[?#]/)[0];
            var v = cB(r + f, a);
            u = v ? u.replace(/\/[^/]*$/, "/") + v : u + f;
          } else u += f;
          t = TA("https://", "http://", u);
        }
        Yl(h, t, void 0, g);
      }
    }
  }
  function ZA() {
    if (!Cm()) {
      var a = Object,
        b = a.entries,
        c = {},
        d = gm().destination;
      if (d) {
        var e = n(Object.entries(d)),
          f = e.next();
        try {
          for (; !f.done; f = e.next()) {
            var g = n(f.value),
              h = g.next().value,
              k = g.next().value,
              m = h,
              p = k,
              q = void 0;
            ((q = p) == null ? void 0 : q.state) === 0 && (c[m] = p);
          }
        } finally {
          z(e, f);
        }
      }
      var r = n(Object.entries(gm().destinationArray)),
        t = r.next();
      try {
        for (; !t.done; t = r.next()) {
          var u = n(t.value),
            v = u.next().value,
            x = u.next().value,
            y = v,
            B = x[0],
            E = void 0;
          ((E = B) == null ? void 0 : E.state) === 0 && (c[y] = B);
        }
      } finally {
        z(r, t);
      }
      var F = n(b.call(a, c)),
        G = F.next();
      try {
        for (; !G.done; G = F.next()) {
          var I = n(G.value),
            J = I.next().value,
            M = I.next().value;
          dB(J, M.transportUrl, M.context);
          R(92);
        }
      } finally {
        z(F, G);
      }
    }
  }
  function dB(a, b, c, d, e, f) {
    if ((e = e === void 0 ? !1 : e) || !ym(a))
      if ((c.loadExperiments || (c.loadExperiments = kj()), !e && Cm()))
        Bm(a, b, c, d);
      else {
        e || Am(a, c, d);
        var g = { destinationId: a, endpoint: 0 };
        if (Lj()) {
          var h = Mj(),
            k = "gtd" + YA(a, { isDestination: !0, Sm: e }),
            m = h + "/" + $A(k, a);
          Yl(g, m, void 0, function () {
            aB(a, m, h + "/" + k, g, f);
          });
        } else {
          var p = "/gtag/destination" + YA(a, { isDestination: !0, Sm: e }),
            q = bB(b, p, a);
          q || (q = TA("https://", "http://", H(3) + p));
          Yl(g, q, void 0, f);
        }
      }
  }
  function aB(a, b, c, d, e) {
    WA();
    var f = VA;
    if (gl.P) {
      var g = A.performance,
        h = -1;
      if (g && g.getEntriesByType) {
        var k = Fj(b).href,
          m = g.getEntriesByName(k).pop();
        if (!m)
          for (
            var p = g.getEntriesByType("resource"), q = 0;
            q < p.length;
            q++
          ) {
            var r = p[q];
            if (r.name && r.name.indexOf(b) !== -1) {
              m = r;
              break;
            }
          }
        m && m.responseStatus !== void 0 && (h = m.responseStatus);
      }
      f.K[a] = h;
    }
    R(190);
    var t = uk(qk.ba.aj) || {};
    t[a] = !0;
    tk(qk.ba.aj, t);
    var u = c + (c.indexOf("?") === -1 ? "?f=1" : "&f=1");
    e ? Yl(d, u, void 0, e) : Yl(d, u);
  }
  function YA(a, b) {
    var c = (b = b === void 0 ? {} : b),
      d = c.isDestination,
      e = d === void 0 ? !1 : d,
      f = c.Sm,
      g = f === void 0 ? !1 : f,
      h = $b(a, "GTM-"),
      k = H(19),
      m = Sj(),
      p = h && If(62) ? "true" : void 0,
      q,
      r = { releaseExperiment: Jf(15), runtimeVersion: H(14) };
    q = Df(r);
    var t = {
        id: a,
        l: k !== "dataLayer" ? k : void 0,
        cx: !h || e ? "c" : void 0,
        google_only: p,
        gtm: q,
        sign: m ? oj.dj : void 0,
        load_study: e && OA(a) && g ? 1 : void 0,
      },
      u = Jf(54);
    if (u === 1) {
      t.fps = "fc";
      var v = H(60);
      v && (t.gdev = v);
    } else u === 2 && (t.fps = "fe");
    return "?" + Vi(t);
  }
  function $A(a, b) {
    return Mj() ? (H(58) ? cB(a, b) || a : (R(182), a)) : a;
  }
  function cB(a, b) {
    var c = H(58),
      d = Mj();
    if (c && d)
      try {
        var e = Wb(),
          f = Ff(a, c),
          g = Wb() - e;
        WA();
        var h = VA;
        gl.P && (h.H[b] = g);
        return f;
      } catch (k) {
        R(183);
      }
  }
  function bB(a, b, c) {
    if (Pj() && a) {
      var d = cB(b, c);
      d && (b = Mj() + "/" + d);
      return Nj(a, b);
    }
  }
  function eB(a) {
    var b = [],
      c = [],
      d = fB(a),
      e = n(JA.getRules()),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) {
        for (
          var g = f.value.evaluate(a, d),
            h = g.firingTags,
            k = g.blockingTags,
            m = 0;
          m < h.length;
          m++
        )
          b[h[m]] = !0;
        for (var p = 0; p < k.length; p++) c[k[p]] = !0;
      }
    } finally {
      z(e, f);
    }
    for (var q = [], r = 0; r < JA.tags.length; r++)
      b[r] && !c[r] && (q[r] = !0);
    return q;
  }
  function fB(a) {
    var b = [];
    return function (c) {
      b[c] === void 0 && (b[c] = JA.predicates[c].evaluate(a, []));
      return b[c];
    };
  }
  var gB = function () {
    this.K = 0;
    this.H = {};
  };
  gB.prototype.addListener = function (a, b, c) {
    var d = ++this.K;
    this.H[a] = this.H[a] || {};
    this.H[a][String(d)] = { listener: b, nf: c };
    return d;
  };
  gB.prototype.removeListener = function (a, b) {
    var c = this.H[a],
      d = String(b);
    if (!c || !c[d]) return !1;
    delete c[d];
    return !0;
  };
  function hB(a, b, c) {
    return {
      entityType: a,
      indexInOriginContainer: b,
      nameInOriginContainer: c,
      originContainerId: H(5),
      originCId: mm(),
    };
  }
  function iB(a, b) {
    if (data.entities) {
      var c = data.entities[a];
      if (c) return c[b];
    }
  }
  function jB() {
    return A[kB()];
  }
  function kB() {
    return A.GoogleAnalyticsObject || "ga";
  }
  var nB = new (function () {
    this.H = {};
  })();
  function oB() {
    a: {
      var a = H(5);
    }
  }
  function pB(a, b) {
    return function () {
      var c = jB(),
        d = c && c.getByName && c.getByName(a);
      if (d) {
        var e = d.get("sendHitTask");
        d.set("sendHitTask", function (f) {
          var g = f.get("hitPayload"),
            h = f.get("hitCallback"),
            k = g.indexOf("&tid=" + b) < 0;
          k &&
            (f.set(
              "hitPayload",
              g.replace(/&tid=UA-[0-9]+-[0-9]+/, "&tid=" + b),
              !0
            ),
            f.set("hitCallback", void 0, !0));
          e(f);
          k &&
            (f.set("hitPayload", g, !0),
            f.set("hitCallback", h, !0),
            f.set("_x_19", void 0, !0),
            e(f));
        });
      }
    };
  }
  function qB(a, b) {
    var c = {};
    if (!b) return rB(a, c), c;
    var d = a.eventModel;
    Db(d) && rB(d, c);
    rB(a, c, "eventModel");
    return c;
  }
  function rB(a, b, c) {
    var d = n(Object.entries(a)),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = n(e.value),
          g = f.next().value,
          h = f.next().value,
          k = g,
          m = h;
        k === c || fA(k) || Eb(cc(k, m), b);
      }
    } finally {
      z(d, e);
    }
  }
  var uB = ["es", "1"],
    vB = function () {
      var a = this;
      this.eventData = {};
      this.H = {};
      xx(function (b) {
        var c;
        var d = b.eventId,
          e = b.fe;
        if (a.eventData[d]) {
          var f = [];
          a.H[d] || f.push(uB);
          f.push.apply(f, w(a.eventData[d]));
          e && (a.H[d] = !0);
          c = f;
        } else c = [];
        return c;
      });
    },
    wB;
  function xB(a, b) {
    var c;
    if ((c = wB) != null && gl.P) {
      var d = c.eventData,
        e;
      e = b.match(/^(gtm|gtag)\./) ? encodeURIComponent(b) : "*";
      d[a] = [
        ["e", e],
        ["eid", String(a)],
      ];
      yx();
      wx(a);
    }
  }
  var yB = function () {
      var a = this;
      this.H = {};
      this.K = {};
      xx(function (b) {
        var c = b.eventId,
          d = b.fe,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["tr", f.join(".")]);
        var g = a.K[c] || [];
        g.length && e.push(["ti", g.join(".")]);
        d && (delete a.H[c], delete a.K[c]);
        return e;
      });
    },
    zB;
  function AB(a, b, c) {
    zB || (zB = new yB());
    var d = zB;
    if (gl.P && b) {
      var e = el(b),
        f = c + e;
      d.H[a] = d.H[a] || [];
      d.H[a].push(f);
      var g = b["function"];
      if (!g) throw Error("Error: No function name given for function call.");
      var h = (Oz[g] ? "1" : "2") + e;
      d.K[a] = d.K[a] || [];
      d.K[a].push(h);
      yx();
      wx(a);
    }
  }
  function BB(a, b, c) {
    c = c === void 0 ? !1 : c;
    CB().addRestriction(0, a, b, c);
  }
  function DB() {
    var a = mm();
    return CB().getRestrictions(0, a);
  }
  function EB(a, b, c) {
    c = c === void 0 ? !1 : c;
    CB().addRestriction(1, a, b, c);
  }
  function FB() {
    var a = mm();
    return CB().getRestrictions(1, a);
  }
  var GB = function () {
      this.container = {};
      this.H = {};
    },
    HB = function (a, b) {
      var c = a.container[b];
      c ||
        ((c = {
          _entity: { internal: [], external: [] },
          _event: { internal: [], external: [] },
        }),
        (a.container[b] = c));
      return c;
    };
  GB.prototype.addRestriction = function (a, b, c, d) {
    d = d === void 0 ? !1 : d;
    if (!d || !this.H[b]) {
      var e = HB(this, b);
      a === 0
        ? d
          ? e._entity.external.push(c)
          : e._entity.internal.push(c)
        : a === 1 &&
          (d ? e._event.external.push(c) : e._event.internal.push(c));
    }
  };
  GB.prototype.getRestrictions = function (a, b) {
    var c = HB(this, b);
    if (a === 0) {
      var d, e;
      return [].concat(
        w(
          (c == null
            ? void 0
            : (d = c._entity) == null
            ? void 0
            : d.internal) || []
        ),
        w(
          (c == null
            ? void 0
            : (e = c._entity) == null
            ? void 0
            : e.external) || []
        )
      );
    }
    if (a === 1) {
      var f, g;
      return [].concat(
        w(
          (c == null ? void 0 : (f = c._event) == null ? void 0 : f.internal) ||
            []
        ),
        w(
          (c == null ? void 0 : (g = c._event) == null ? void 0 : g.external) ||
            []
        )
      );
    }
    return [];
  };
  GB.prototype.getExternalRestrictions = function (a, b) {
    var c = HB(this, b),
      d,
      e;
    return a === 0
      ? (c == null ? void 0 : (d = c._entity) == null ? void 0 : d.external) ||
          []
      : (c == null ? void 0 : (e = c._event) == null ? void 0 : e.external) ||
          [];
  };
  GB.prototype.removeExternalRestrictions = function (a) {
    var b = HB(this, a);
    b._event && (b._event.external = []);
    b._entity && (b._entity.external = []);
    this.H[a] = !0;
  };
  function CB() {
    return fo("r", function () {
      return new GB();
    });
  }
  function IB(a, b, c, d) {
    var e = JA.tags[a],
      f = JB(a, b, c, d);
    if (!f) return null;
    var g = FA(e, c);
    if (g && g.length) {
      var h = g[0];
      f = IB(
        h.index,
        {
          onSuccess: f,
          onFailure: h.Fm === 1 ? b.terminate : f,
          terminate: b.terminate,
        },
        c,
        d
      );
    }
    return f;
  }
  function JB(a, b, c, d) {
    function e() {
      function y() {
        pk(3);
        var M = Wb() - J;
        hB(1, a, f.getName());
        AB(c.id, g, "7");
        Do(c.kd, F, "exception", M);
        gl.H && Dz(c, g, Uy.X.fj);
        G || ((G = !0), k());
      }
      if (f.Ha.malware_disabled) k();
      else {
        var B = HA(f, c);
        if (B != null)
          for (var E = 0; E < B.length; E++)
            if (!hp(B[E])) {
              k();
              return;
            }
        var F = Co(c.kd, f.R, f.tagId, f.getMetadata(c)),
          G = !1,
          I = {
            vtp_gtmOnSuccess: function () {
              if (!G) {
                G = !0;
                var M = Wb() - J;
                AB(c.id, g, "5");
                Do(c.kd, F, "success", M);
                gl.H && Dz(c, g, Uy.X.ij);
                h();
              }
            },
            vtp_gtmOnFailure: function () {
              if (!G) {
                G = !0;
                var M = Wb() - J;
                AB(c.id, g, "6");
                Do(c.kd, F, "failure", M);
                gl.H && Dz(c, g, Uy.X.gj);
                k();
              }
            },
          };
        I.vtp_gtmEventId = c.id;
        c.priorityId && (I.vtp_gtmPriorityId = c.priorityId);
        Mt({ tagName: f.getName() });
        AB(c.id, g, "1");
        gl.H && Cz(c, g);
        var J = Wb();
        try {
          f.evaluate(c, d, I);
        } catch (M) {
          y(M);
        }
        gl.H && Dz(c, g, Uy.X.hm);
      }
    }
    var f = JA.tags[a],
      g = f.zg(),
      h = b.onSuccess,
      k = b.onFailure,
      m = b.terminate;
    if (c.Cj(g)) return Mt({ tagName: f.getName() }), null;
    var p = GA(f, c);
    if (p && p.length) {
      var q = p[0],
        r = IB(q.index, { onSuccess: h, onFailure: k, terminate: m }, c, d);
      if (!r) return null;
      h = r;
      k = q.Fm === 2 ? m : r;
    }
    if (f.Ha.once_per_load || f.Ha.once_per_event) {
      var t = f.Ha.once_per_load ? JA.dk : c.dk,
        u = h,
        v = k;
      if (!t[a]) {
        var x = KB(a, t, Xb(e));
        h = x.onSuccess;
        k = x.onFailure;
      }
      return function () {
        t[a](u, v);
      };
    }
    return e;
  }
  function KB(a, b, c) {
    var d = [],
      e = [];
    b[a] = LB(d, e, c);
    return {
      onSuccess: function () {
        b[a] = MB;
        for (var f = 0; f < d.length; f++) d[f]();
      },
      onFailure: function () {
        b[a] = NB;
        for (var f = 0; f < e.length; f++) e[f]();
      },
    };
  }
  function LB(a, b, c) {
    return function (d, e) {
      a.push(d);
      b.push(e);
      c();
    };
  }
  function MB(a) {
    a();
  }
  function NB(a, b) {
    b();
  }
  var QB = function (a, b) {
    for (var c = [], d = 0; d < JA.tags.length; d++)
      if (a[d]) {
        var e = JA.tags[d];
        var f = Fo(b.kd);
        try {
          var g = IB(d, { onSuccess: f, onFailure: f, terminate: f }, b, d);
          if (g) {
            var h = Oz[e.R];
            c.push({
              An: d,
              priorityOverride:
                (h ? h.priorityOverride || 0 : 0) || iB(e.R, 1) || 0,
              execute: g,
            });
          } else OB(d, b), f();
        } catch (m) {
          e.getName(), f();
        }
      }
    c.sort(PB);
    for (var k = 0; k < c.length; k++) c[k].execute();
    return c.length > 0;
  };
  function RB(a, b) {
    if (!SB) return !1;
    var c = a["gtm.triggers"] && String(a["gtm.triggers"]);
    var d = a.event,
      e = c ? String(c).split(",") : [],
      f = SB,
      g = [];
    if (f.H[d]) {
      var h = n(Object.values(f.H[d])),
        k = h.next();
      try {
        for (; !k.done; k = h.next()) {
          var m = k.value;
          g.indexOf(m.listener) < 0 &&
            (m.nf === void 0 || e.indexOf(m.nf) >= 0) &&
            g.push(m.listener);
        }
      } finally {
        z(h, k);
      }
    }
    if (!g.length) return !1;
    for (var p = 0; p < g.length; ++p) {
      var q = Fo(b);
      try {
        g[p](a, q);
      } catch (r) {
        q();
      }
    }
    return !0;
  }
  function PB(a, b) {
    var c,
      d = b.priorityOverride,
      e = a.priorityOverride;
    c = d > e ? 1 : d < e ? -1 : 0;
    var f;
    if (c !== 0) f = c;
    else {
      var g = a.An,
        h = b.An;
      f = g > h ? 1 : g < h ? -1 : 0;
    }
    return f;
  }
  function OB(a, b) {
    if (gl.P) {
      var c = function (d) {
        var e = b.Cj(JA.tags[d].zg()) ? "3" : "4",
          f = FA(JA.tags[d], b);
        f && f.length && c(f[0].index);
        AB(b.id, JA.tags[d].zg(), e);
        var g = GA(JA.tags[d], b);
        g && g.length && c(g[0].index);
      };
      c(a);
    }
  }
  var SB;
  function TB() {
    SB || (SB = new gB());
    return SB;
  }
  function UB(a, b) {
    var c = a["gtm.uniqueEventId"],
      d = a["gtm.priorityId"],
      e = a["gtm.priorityQueue"],
      f = a.event;
    gl.H && tz(c, f);
    if (f === "gtm.js") {
      if (Zi(10)) return { bk: !1 };
      Yi(10, !0);
    }
    var g = !1,
      h = FB(),
      k = Eb(a, null);
    if (
      !h.every(function (y) {
        return y({ originalEventData: k });
      })
    ) {
      if (f !== "gtm.js" && f !== "gtm.init" && f !== "gtm.init_consent")
        return { bk: !1 };
      g = !0;
    }
    xB(c, f);
    var m = a.eventCallback,
      p = a.eventTimeout,
      q,
      r = dA(
        Xz(
          Uz(new Tz(c, d), qB(k, (q = b.isGtagCommand) != null ? q : !1)),
          Eb(lA.T, null)
        )
      ),
      t = {
        id: c,
        priorityId: d,
        priorityQueue: e,
        name: f,
        Cj: VB(k, g),
        dk: [],
        Tm: function (y, B, E) {
          R(6);
          pk(4);
          hB(2, B, E);
        },
        Ih: WB(),
        kd: new Bo(function () {
          gl.H && wz(c, f);
          m && m.apply(m, Array.prototype.slice.call(arguments, 0));
        }, p),
        originalEventData: k,
        M: r,
        originalSendTo: b.originalSendTo,
        bs: {},
        isSystemEvent: !!b.isSystemEvent,
      };
    gl.H && Az(t.id);
    var u = eB(t);
    gl.H && Bz(t.id);
    JA.getRules();
    g && (u = XB(u));
    gl.H && uz(c);
    var v = QB(u, t),
      x = RB(a, t.kd);
    Go(t.kd);
    (f !== "gtm.js" && f !== "gtm.sync") || oB();
    return { bk: YB(u, v) || x, M: r };
  }
  function WB() {
    var a = {};
    a.event = pA("event", 1);
    a.ecommerce = pA("ecommerce", 1);
    a.gtm = pA("gtm");
    a.eventModel = pA("eventModel");
    return a;
  }
  function VB(a, b) {
    var c = uA();
    return function (d) {
      var e = c(d);
      if (e) return !0;
      var f = d && d["function"];
      if (!f || typeof f !== "string") return !0;
      f = f.replace(/^_*/, "");
      var g = DB(),
        h = a;
      b &&
        ((h = Eb(a, null)), (h["gtm.uniqueEventId"] = Number.MAX_SAFE_INTEGER));
      var k = !1,
        m =
          $i(21, function () {
            return {};
          })[f] || [],
        p = n(g),
        q = p.next();
      try {
        for (; !q.done; q = p.next()) {
          var r = q.value;
          try {
            r({ entityId: f, securityGroups: m, originalEventData: h }) ||
              (k = !0);
          } catch (t) {
            k = !0;
          }
        }
      } finally {
        z(p, q);
      }
      return k || e;
    };
  }
  function XB(a) {
    for (var b = [], c = 0; c < a.length; c++)
      if (a[c]) {
        var d = JA.tags[c].R;
        if (pj[d] || JA.tags[c].Ha.original_activity_id !== void 0 || iB(d, 2))
          b[c] = !0;
      }
    return b;
  }
  function YB(a, b) {
    if (!b) return b;
    for (var c = 0; c < a.length; c++)
      if (a[c] && JA.tags[c] && !qj[JA.tags[c].R]) return !0;
    return !1;
  }
  var ZB = Nf(61, 1e3),
    $B = Nf(68, 2e3),
    jp = ["ad_storage", "analytics_storage"];
  function aC(a, b) {
    if (a) {
      var c = fo("gth", function () {
          return {};
        }),
        d;
      a !== 2 ||
        ((d = bC()) == null ? void 0 : d.status) !== 3 ||
        (b !== void 0 && b <= $B) ||
        ((a = 3), (c.dl = b ? Math.floor(b / 1e3) : void 0));
      c.s = a;
      cC(c);
    }
  }
  function cC(a) {
    if (a.s) {
      var b = function () {
        var c = { status: a.s, expires: Date.now() + 864e5 };
        a.dl !== void 0 && (c.delay = a.dl);
        Lr("gtg_load_status", c);
      };
      mp(function () {
        if (ip()) b();
        else {
          var c = Xb(b),
            d = n(jp),
            e = d.next();
          try {
            for (; !e.done; e = d.next()) Vm(c, e.value);
          } finally {
            z(d, e);
          }
        }
      }, jp);
    }
  }
  function dC() {
    var a = eC(!0);
    return a ? (fC(a.status, a.delay), !1) : !0;
  }
  function eC(a) {
    a = a === void 0 ? !1 : a;
    if (Pj()) {
      var b = Or("gtg_load_status"),
        c = b.value,
        d =
          a &&
          Kb(c == null ? void 0 : c.expires) &&
          (c == null ? void 0 : c.expires) < Date.now() + 36e5;
      if (b.error === 0 && Kb(c == null ? void 0 : c.status) && !d) {
        var e = { status: c.status };
        (c == null ? void 0 : c.delay) !== void 0 && (e.delay = c.delay);
        return e;
      }
      return bC();
    }
  }
  function fC(a, b) {
    var c = fo("gth", function () {
      return {};
    });
    c.s = a;
    b !== void 0 && (c.dl = b);
  }
  function bC() {
    var a = ho("gth");
    if (a != null && a.s) {
      var b = { status: a.s };
      a.dl !== void 0 && (b.delay = a.dl);
      return b;
    }
  }
  function gC() {
    var a;
    ((a = bC()) == null ? void 0 : a.status) === 1 && aC(3);
  }
  function hC() {
    if (dC()) {
      var a = Date.now();
      io("gth", {
        l: function () {
          aC(2, Date.now() - a);
        },
        s: 1,
      });
      var b = H(5),
        c = $b(b, "GTM-") ? "/gtm.js" : "/gtag/js",
        d = "https://" + H(3) + c + "?id=" + b + "&gtg_health=1";
      dd(d, gC, gC);
      A.setTimeout(gC, ZB);
    }
  }
  function iC() {
    TB().addListener("gtm.init", function (a, b) {
      Yi(14, !0);
      P(556) && Pj() && !If(45) && (Xm.H[3] = 2);
      if (Pj()) {
        var c = cn(3);
        Ym(c) ? $m(c, hC) : hC();
      }
      kn(!1, !0);
      b();
    });
  }
  function jC() {
    if (ho("pscdl") !== void 0)
      uk(qk.ba.Vg) === void 0 && tk(qk.ba.Vg, ho("pscdl"));
    else {
      var a = function (c) {
          io("pscdl", c);
          tk(qk.ba.Vg, c);
        },
        b = function () {
          a("error");
        };
      try {
        Qc.cookieDeprecationLabel
          ? (a("pending"),
            Qc.cookieDeprecationLabel.getValue().then(a).catch(b))
          : a("noapi");
      } catch (c) {
        b(c);
      }
    }
  }
  var lC = function () {
    var a = this;
    this.ready = !1;
    this.H = 0;
    this.listeners = [];
    var b = A;
    if (
      (C.readyState === "interactive" && !C.createEventObject) ||
      C.readyState === "complete"
    )
      this.onReady();
    else {
      id(C, "DOMContentLoaded", function (d) {
        return void a.onReady(d);
      });
      id(C, "readystatechange", function (d) {
        return void a.onReady(d);
      });
      if (C.createEventObject && C.documentElement.doScroll) {
        var c = !0;
        try {
          c = !b.frameElement;
        } catch (d) {}
        c && kC(this);
      }
      id(b, "load", function (d) {
        return void a.onReady(d);
      });
    }
  };
  lC.prototype.isReady = function () {
    return this.ready;
  };
  lC.prototype.onReady = function (a) {
    if (!this.ready) {
      var b = C.createEventObject,
        c = C.readyState === "complete",
        d = C.readyState === "interactive";
      if (!a || a.type !== "readystatechange" || c || (!b && d)) {
        this.ready = !0;
        for (var e = 0; e < this.listeners.length; e++) kd(this.listeners[e]);
      }
      this.listeners.push = function () {
        for (var f = Qa.apply(0, arguments), g = 0; g < f.length; g++) kd(f[g]);
        return 0;
      };
    }
  };
  var kC = function (a) {
      if (!a.ready && a.H < 140) {
        a.H++;
        try {
          var b, c;
          (c = (b = C.documentElement).doScroll) == null || c.call(b, "left");
          a.onReady();
        } catch (d) {
          A.setTimeout(function () {
            return void kC(a);
          }, 50);
        }
      }
    },
    mC;
  function nC() {
    mC || (mC = new lC());
  }
  function oC() {
    nC();
    var a;
    return (a = mC) == null ? void 0 : a.isReady();
  }
  function pC(a) {
    nC();
    var b;
    (b = mC) != null && (b.ready ? kd(a) : b.listeners.push(a));
  }
  var rC = function (a, b, c) {
      var d = qC,
        e;
      if ((e = d.H) == null || !e.Eq) {
        var f = Object.keys(b).length > 0 ? 2 : 1,
          g,
          h,
          k =
            (c == null
              ? void 0
              : (h = c.originatingEntity) == null
              ? void 0
              : h.originContainerId) || "";
        g = k ? ($b(k, "GTM-") ? 3 : 2) : 1;
        if (!a) d.H = { type: f, source: g, params: b };
        else if (d.H) {
          R(184);
          var m = !1;
          d.H.source === g ||
            (d.H.source !== 3 && g !== 3) ||
            (gj("idcs", "1"), (m = !0));
          (d.H.type !== 2 && f !== 2) || R(186);
          var p;
          if ((p = d.H.type === 2 && f === 2))
            a: {
              var q = d.H.params,
                r = Object.keys(q),
                t = Object.keys(b);
              if (r.length !== t.length) p = !0;
              else {
                var u = n(r),
                  v = u.next();
                try {
                  for (; !v.done; v = u.next()) {
                    var x = v.value;
                    if (!b.hasOwnProperty(x) || q[x] !== b[x]) {
                      p = !0;
                      break a;
                    }
                  }
                } finally {
                  z(u, v);
                }
                p = !1;
              }
            }
          p && (gj("idcc", "1"), (m = !0));
          m && (kn(), (d.H.Eq = !0));
        }
      }
    },
    qC = new (function () {
      this.H = void 0;
    })();
  var tC = function (a) {
      var b = sC;
      (!gl.K || $b(H(5), "GTM-") ? 0 : a === void 0) &&
        b.H === 0 &&
        (gj("mcc", "1"), (b.H = 1));
    },
    sC = new (function () {
      var a = this;
      this.H = 0;
      gj("ncc", function () {
        if (If(45) && a.H !== 2) return "1";
      });
    })();
  var uC = {},
    vC =
      ((uC[K.D.li] = 1),
      (uC[K.D.Zb] = 2),
      (uC[K.D.bc] = 2),
      (uC[K.D.lb] = 3),
      (uC[K.D.Ad] = 4),
      (uC[K.D.ji] = 5),
      (uC[K.D.uc] = 6),
      (uC[K.D.Ya] = 6),
      (uC[K.D.sb] = 6),
      (uC[K.D.zd] = 6),
      (uC[K.D.Mb] = 6),
      (uC[K.D.Cb] = 6),
      (uC[K.D.tb] = 7),
      (uC[K.D.ub] = 9),
      (uC[K.D.Xg] = 10),
      (uC[K.D.Qc] = 11),
      uC),
    wC = {},
    xC =
      ((wC.unknown = 13),
      (wC.standard = 14),
      (wC.unique = 15),
      (wC.per_session = 16),
      (wC.transactions = 17),
      (wC.items_sold = 18),
      wC);
  var yC = function (a, b, c) {
      c = c === void 0 ? !1 : c;
      wb("GTAG_EVENT_FEATURE_CHANNEL", b);
      c && (a.H[b] = !0);
    },
    zC = new (function () {
      this.H = [];
    })();
  function AC(a) {
    yC(zC, a, !1);
  }
  function BC(a, b) {
    var c = b === void 0 ? !1 : b,
      d = zC;
    c = c === void 0 ? !1 : c;
    var e = Object.keys(a),
      f = n(Object.keys(vC)),
      g = f.next();
    try {
      for (; !g.done; g = f.next()) {
        var h = g.value;
        e.includes(h) && yC(d, vC[h], c);
      }
    } finally {
      z(f, g);
    }
  }
  var CC = /^(?:AW|DC|G|GF|GT|HA|MC|S|UA)$/,
    DC = /\s/;
  function EC(a, b) {
    if (Hb(a)) {
      a = Ub(a);
      var c = a.indexOf("-");
      if (!(c < 0)) {
        var d = a.substring(0, c);
        if (CC.test(d)) {
          var e = a.substring(c + 1),
            f;
          if (b) {
            var g = function (m) {
              var p = m.indexOf("/");
              return p < 0 ? [m] : [m.substring(0, p), m.substring(p + 1)];
            };
            f = g(e);
            if (d === "DC" && f.length === 2) {
              var h = g(f[1]);
              h.length === 2 && ((f[1] = h[0]), f.push(h[1]));
            }
          } else {
            f = e.split("/");
            for (var k = 0; k < f.length; k++)
              if (!f[k] || (DC.test(f[k]) && (d !== "AW" || k !== 1))) return;
          }
          return {
            id: a,
            prefix: d,
            destinationId: d + "-" + f[0],
            ids: f,
            mc: function () {
              return this.id !== this.destinationId;
            },
          };
        }
      }
    }
  }
  function FC(a, b) {
    for (var c = {}, d = 0; d < a.length; ++d) {
      var e = EC(a[d], b);
      e && (c[e.id] = e);
    }
    var f = [],
      g;
    for (g in c)
      if (c.hasOwnProperty(g)) {
        var h = c[g];
        h.prefix === "AW" && h.ids[GC[1]] && f.push(h.destinationId);
      }
    for (var k = 0; k < f.length; ++k) delete c[f[k]];
    var m = [],
      p = n(Object.keys(c)),
      q = p.next();
    try {
      for (; !q.done; q = p.next()) m.push(c[q.value]);
    } finally {
      z(p, q);
    }
    return m;
  }
  var HC = {},
    GC =
      ((HC[0] = 0),
      (HC[1] = 1),
      (HC[2] = 2),
      (HC[3] = 0),
      (HC[4] = 1),
      (HC[5] = 0),
      (HC[6] = 0),
      (HC[7] = 0),
      HC);
  var IC = { initialized: 11, complete: 12, interactive: 13 },
    JC = {},
    KC = Object.freeze(((JC[K.D.yc] = !0), JC)),
    LC = function () {
      this.T = Nf(34, 500);
      this.H = {};
      this.P = {};
      this.K = void 0;
    },
    MC = function (a, b, c) {
      if (c.length && gl.K) {
        var d;
        (d = a.H)[b] != null || (d[b] = []);
        var e;
        (e = a.P)[b] != null || (e[b] = []);
        var f = c.filter(function (g) {
          return !a.P[b].includes(g);
        });
        a.H[b].push.apply(a.H[b], w(f));
        a.P[b].push.apply(a.P[b], w(f));
        !a.K &&
          f.length > 0 &&
          (ej(cj, "tdc", !0),
          (a.K = A.setTimeout(function () {
            kn();
            a.H = {};
            a.K = void 0;
          }, a.T)));
      }
    };
  LC.prototype.bind = function () {
    var a = this;
    gj(
      "tdc",
      function () {
        a.K && (A.clearTimeout(a.K), (a.K = void 0));
        var b = [],
          c;
        for (c in a.H)
          a.H.hasOwnProperty(c) && b.push(c + "*" + a.H[c].join("."));
        return b.length ? b.join("!") : void 0;
      },
      !1
    );
  };
  var NC = function (a, b) {
      var c = {},
        d;
      for (d in b) b.hasOwnProperty(d) && (c[d] = !0);
      for (var e in a) a.hasOwnProperty(e) && (c[e] = !0);
      return c;
    },
    OC = function (a, b, c, d, e) {
      d = d === void 0 ? {} : d;
      e = e === void 0 ? "" : e;
      if (b === c) return [];
      var f = function (t, u) {
          var v;
          Ab(u) === "object" ? (v = u[t]) : Ab(u) === "array" && (v = u[t]);
          return v === void 0 ? KC[t] : v;
        },
        g = NC(b, c),
        h;
      for (h in g)
        if (g.hasOwnProperty(h) && h !== K.D.Yb) {
          var k = (e ? e + "." : "") + h,
            m = f(h, b),
            p = f(h, c),
            q = Ab(m) === "object" || Ab(m) === "array",
            r = Ab(p) === "object" || Ab(p) === "array";
          if (q && r) OC(a, m, p, d, k);
          else if (q || r || m !== p) d[k] = !0;
        }
      return Object.keys(d);
    },
    PC = new LC();
  var QC = function (a, b, c, d, e) {
      this.K = b;
      this.H = c;
      this.args = d;
      this.messageContext = e;
      this.type = a;
    },
    RC = function () {
      this.Wa = {};
      this.ib = {};
      this.K = {};
      this.P = null;
      this.fb = {};
      this.H = !1;
      this.status = 1;
    };
  function SC(a, b) {
    return arguments.length === 1 ? TC("set", a) : TC("set", a, b);
  }
  function UC(a, b) {
    return arguments.length === 1 ? TC("config", a) : TC("config", a, b);
  }
  function VC(a, b, c) {
    c = c || {};
    c[K.D.Yb] = a;
    return TC("event", b, c);
  }
  function TC() {
    return arguments;
  }
  function WC(a, b) {
    var c = n(Object.keys(a)),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = d.value,
          f;
        if ((f = e.charAt(0) === "_")) {
          var g;
          a: switch (e) {
            case K.D.Wb:
            case K.D.Hf:
            case K.D.kh:
              g = !0;
              break a;
            default:
              g = !1;
          }
          f = !g;
        }
        f && (b && b(e), delete a[e]);
      }
    } finally {
      z(c, d);
    }
  }
  var XC = [
      K.D.ya,
      K.D.Ea,
      K.D.Eb,
      K.D.Ke,
      K.D.mb,
      K.D.xc,
      K.D.nb,
      K.D.yc,
      K.D.Ta,
      K.D.Za,
      K.D.Ka,
      K.D.La,
      K.D.zc,
      K.D.cg,
      K.D.Zb,
      K.D.bc,
      K.D.Bb,
      K.D.ac,
      K.D.Qf,
      K.D.Ed,
      K.D.Be,
      K.D.xe,
      K.D.ye,
      K.D.ze,
      K.D.Ae,
      K.D.Ce,
      K.D.De,
      K.D.rh,
      K.D.Vc,
      K.D.sc,
      K.D.ub,
      K.D.lb,
      K.D.vc,
      K.D.Kd,
      K.D.Ad,
      K.D.Zc,
      K.D.Cd,
      K.D.Tc,
      K.D.te,
      K.D.Ub,
      K.D.Db,
      K.D.Nb,
      K.D.we,
      K.D.ue,
      K.D.ve,
      K.D.ah,
      K.D.sb,
      K.D.Ya,
      K.D.tb,
      K.D.Cb,
      K.D.Mb,
      K.D.uc,
    ],
    YC = {},
    ZC = ma(Object, "assign").call(
      Object,
      {},
      KC,
      ((YC[K.D.Ub] = !0),
      (YC[K.D.uc] = !0),
      (YC[K.D.Nb] = !1),
      (YC[K.D.lb] = !1),
      (YC[K.D.sb] = "auto"),
      (YC[K.D.Mb] = "/"),
      (YC[K.D.Ya] = ""),
      (YC[K.D.Cb] = ""),
      YC)
    ),
    $C = /^u([1-9]\d?|100)$/;
  function aD() {
    return Qa.apply(0, arguments).find(function (a) {
      return a !== void 0;
    });
  }
  function bD(a, b, c, d, e) {
    var f = b[a];
    if (
      f !== void 0 &&
      !d.some(function (k) {
        return k[a] !== void 0;
      })
    ) {
      var g = aD(c[a], e[a]),
        h = aD(g, ZC[a]);
      if (h === void 0) return f === null ? void 0 : 1;
      if ((f === null || typeof f !== "object") && f !== h)
        return g === void 0 ? 2 : 3;
    }
  }
  var cD = [
      [1, "dlpa"],
      [2, "dlpd"],
      [3, "dlpo"],
    ],
    dD = function () {
      var a = this;
      this.K = [];
      var b = {};
      this.P = ((b[1] = []), (b[2] = []), (b[3] = []), b);
      this.H = new Set();
      xx(function () {
        var c;
        var d = yb(a.K);
        if (d) {
          var e = [["dlp", d]],
            f = n(cD),
            g = f.next();
          try {
            for (; !g.done; g = f.next()) {
              var h = n(g.value),
                k = h.next().value,
                m = h.next().value,
                p = yb(a.P[k]);
              p && e.push([m, p]);
            }
          } finally {
            z(f, g);
          }
          c = e;
        } else c = [];
        return c;
      });
    },
    eD = function (a, b, c, d, e, f, g) {
      var h = function (r) {
          if (!a.H.has(r) && (r !== K.D.yc || b === K.D.sa))
            return bD(r, d, e, f, g);
        },
        k = function (r, t) {
          r !== void 0 && ((a.K[t] = !0), (a.P[r][t] = !0));
        };
      XC.forEach(function (r, t) {
        k(h(r), t + 1);
      });
      if (c === "DC") {
        var m = n(Object.keys(d)),
          p = m.next();
        try {
          for (; !p.done; p = m.next()) {
            var q = p.value;
            $C.test(q) && k(h(q), 0);
          }
        } finally {
          z(m, p);
        }
      }
    },
    fD;
  function gD(a, b, c, d, e, f) {
    if (gl.P) {
      hD();
      var g;
      (g = fD) == null || eD(g, a, b, c, d, e, f);
    }
  }
  function hD() {
    P(669) && (fD || (fD = new dD()));
  }
  var iD = function () {
      var a = this;
      this.H = {};
      xx(function (b) {
        var c = b.eventId,
          d = b.fe,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["epr", f.join(".")]);
        d && delete a.H[c];
        return e;
      });
    },
    kD = function (a, b, c) {
      var d = jD;
      if (gl.P && a !== void 0) {
        var e = c + b;
        d.H[a] = d.H[a] || [];
        d.H[a].push(e);
        yx();
        wx(a);
      }
    },
    jD;
  function lD() {
    jD || (jD = new iD());
  }
  var mD = function () {
      this.destinations = {};
      this.global = {};
      this.commands = [];
      this.H = [];
    },
    nD = function (a, b) {
      return (a.destinations[b.destinationId] =
        a.destinations[b.destinationId] || new RC());
    },
    oD = function (a) {
      for (var b = {}, c = 1; c < a.commands.length; c++) {
        var d = a.commands[c];
        if (d.type === "set") {
          var e = n(Object.entries(d.args[0])),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) {
              var g = n(f.value),
                h = g.next().value,
                k = g.next().value;
              Eb(cc(h, k), b);
            }
          } finally {
            z(e, f);
          }
        }
      }
      return b;
    },
    pD = function (a, b, c, d) {
      if (d.H) {
        var e = nD(a, d.H),
          f = e.P;
        if (f) {
          var g = Eb(c, null),
            h = Eb(e.Wa[d.H.destinationId], null),
            k = Eb(e.fb, null),
            m = Eb(e.ib, null),
            p = Eb(a.global, null),
            q = {};
          if (gl.P) {
            try {
              q = Eb(lA.H, null);
            } catch (y) {
              R(72);
            }
            P(669) && gD(b, d.H.prefix, q, p, [g, h, k, oD(a)], m);
          }
          var r = d.H.prefix,
            t = function (y) {
              var B = d.messageContext.eventId;
              lD();
              kD(B, r, y);
            },
            u = dA(
              cA(
                bA(
                  aA(
                    $z(
                      Yz(
                        Xz(
                          Zz(
                            Wz(
                              Vz(
                                Uz(
                                  new Tz(
                                    d.messageContext.eventId,
                                    d.messageContext.priorityId,
                                    d.messageContext.priorityQueue
                                  ),
                                  g
                                ),
                                h
                              ),
                              k
                            ),
                            m
                          ),
                          p
                        ),
                        q
                      ),
                      ma(Object, "assign").call(
                        Object,
                        {},
                        d.messageContext.eventMetadata
                      )
                    ),
                    function () {
                      if (t) {
                        var y = t;
                        t = void 0;
                        y("2");
                        if (d.messageContext.onSuccess)
                          d.messageContext.onSuccess();
                      }
                    }
                  ),
                  function () {
                    if (t) {
                      var y = t;
                      t = void 0;
                      y("3");
                      if (d.messageContext.onFailure)
                        d.messageContext.onFailure();
                    }
                  }
                ),
                !!d.messageContext.isGtmEvent
              )
            ),
            v = function () {
              try {
                if (d.H && PA(d.H.destinationId) === 3 && (Yp(), Wp(Rp, 612))) {
                  var y = u.eventMetadata[L.J.Eh] || [];
                  y.includes(612) || y.push(612);
                  u.eventMetadata[L.J.Eh] = y;
                }
                var B = d.messageContext.eventId;
                lD();
                kD(B, r, "1");
                var E = d.H.id,
                  F = PC;
                if (gl.K && b === K.D.sa) {
                  var G,
                    I = (G = EC(E)) == null ? void 0 : G.ids;
                  if (!(I && I.length > 1)) {
                    var J = u.Ja[K.D.Yb];
                    if (!J || J === E) {
                      var M,
                        U = Vc("google_tag_data", {});
                      U.td || (U.td = {});
                      M = U.td;
                      var W = Eb(u.Dc, null);
                      Eb(u.Ja, W);
                      var fa = [],
                        da;
                      for (da in M)
                        M.hasOwnProperty(da) &&
                          OC(F, M[da], W).length &&
                          fa.push(da);
                      fa.length &&
                        (MC(F, E, fa), wb("TAGGING", IC[C.readyState] || 14));
                      M[E] = W;
                    }
                  }
                }
                f(d.H.id, b, d.K, u);
              } catch (ja) {
                var ea = d.messageContext.eventId;
                lD();
                kD(ea, r, "4");
              }
            };
          if (b === "gtag.get") v();
          else {
            var x = function () {
              $m(e.T, v);
            };
            OA(d.H.destinationId)
              ? (PA(d.H.destinationId) ||
                  dB(
                    d.H.destinationId,
                    Tj(u),
                    {
                      source: 3,
                      fromContainerExecution:
                        d.messageContext.fromContainerExecution,
                    },
                    void 0,
                    !0,
                    function () {
                      QA(d.H.destinationId, 3);
                    }
                  ),
                SA(d.H.destinationId, x))
              : x();
          }
        }
      }
    },
    qD = function (a, b) {
      if (b.type !== "require") {
        var c = void 0;
        b.type === "event" && (c = b.args[1]);
        if (b.H)
          for (var d = nD(a, b.H).K[b.type] || [], e = 0; e < d.length; e++)
            d[e](c);
        else
          for (var f in a.destinations)
            if (a.destinations.hasOwnProperty(f)) {
              var g = a.destinations[f];
              if (g && g.K)
                for (var h = g.K[b.type] || [], k = 0; k < h.length; k++)
                  h[k](c);
            }
      }
    };
  mD.prototype.register = function (a, b, c, d) {
    var e = nD(this, a);
    e.status !== 3 &&
      ((e.P = b),
      (e.status = 3),
      (e.T = cn(c)),
      rD(this, a, d || {}),
      this.flush());
  };
  mD.prototype.push = function (a, b, c, d) {
    c !== void 0 &&
      (nD(this, c).status === 1 &&
        ((nD(this, c).status = 2), this.push("require", [{}], c, {})),
      nD(this, c).H && (d.deferrable = !1),
      d.eventMetadata || (d.eventMetadata = {}),
      d.eventMetadata[L.J.ng] || (d.eventMetadata[L.J.ng] = [c.destinationId]),
      d.eventMetadata[L.J.bj] || (d.eventMetadata[L.J.bj] = [c.id]));
    var e = Wb();
    this.commands.push(new QC(a, e, c, b, d));
    d.deferrable || this.flush();
  };
  mD.prototype.flush = function (a) {
    for (var b = !1, c = {}; this.commands.length; c = { Dm: void 0 }) {
      var d = this.commands[0],
        e = d.H;
      if (d.messageContext.deferrable)
        !e || nD(this, e).H
          ? ((d.messageContext.deferrable = !1), this.commands.push(d))
          : this.H.push(d),
          this.commands.shift();
      else {
        switch (d.type) {
          case "require":
            if (nD(this, e).status !== 3 && !a) {
              b &&
                (this.commands.push.apply(this.commands, this.H),
                (this.H = []));
              return;
            }
            break;
          case "set":
            var f = d.args[0];
            WC(f);
            sD(f);
            var g = n(Object.entries(f)),
              h = g.next();
            try {
              for (; !h.done; h = g.next()) {
                var k = n(h.value),
                  m = k.next().value,
                  p = k.next().value;
                Eb(cc(m, p), this.global);
              }
            } finally {
              z(g, h);
            }
            BC(f, !0);
            break;
          case "event":
            c.Dm = d.args[1];
            var q = tD(
                d.args[0],
                (function () {
                  return function () {};
                })(c)
              ),
              r = q[K.D.Yb];
            (r && r !== e.id) || BC(q);
            pD(this, c.Dm, q, d);
            break;
          case "get":
            var t = {},
              u = ((t[K.D.Jf] = d.args[0]), (t[K.D.If] = d.args[1]), t);
            pD(this, K.D.Kb, u, d);
            break;
          case "container_config":
            var v = nD(this, e),
              x = tD(d.args[0], function () {});
            BC(x, !0);
            v.H = !0;
            Eb(x, v.fb);
            b = !0;
            break;
          case "destination_config":
            var y = nD(this, e),
              B = tD(d.args[0], function () {});
            BC(B, !0);
            y.Wa[e.id] || (y.Wa[e.id] = {});
            y.H = !0;
            Eb(B, y.Wa[e.id]);
            b = !0;
            break;
          case "reset_container_config":
            nD(this, e).fb = {};
            break;
          case "reset_target_config":
            nD(this, e).Wa[e.id] = {};
        }
        this.commands.shift();
        qD(this, d);
      }
    }
    b && (this.commands.push.apply(this.commands, this.H), (this.H = []));
    b && this.flush();
  };
  var rD = function (a, b, c) {
    var d = Eb(c, null);
    Eb(nD(a, b).ib, d);
    nD(a, b).ib = d;
  };
  function tD(a, b) {
    var c = {},
      d = n(Object.entries(a)),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = n(e.value),
          g = f.next().value,
          h = f.next().value;
        Eb(cc(g, h), c);
      }
    } finally {
      z(d, e);
    }
    WC(c, b);
    sD(c);
    return c;
  }
  function sD(a) {
    if (vA()) {
      var b = !1,
        c = n(new Set([K.D.bc, K.D.Zb])),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = d.value;
          a[e] !== void 0 && ((b = !0), delete a[e]);
        }
      } finally {
        z(c, d);
      }
      b &&
        !$i(18, function () {
          return !1;
        }) &&
        (Yi(18, !0),
        window.console &&
          window.console.log &&
          window.console.log(
            "Google Tag Manager: Server-side GTM parameters (transport_url/server_container_url) are not permitted on this domain and have been ignored."
          ),
        R(197));
    }
  }
  var uD = function () {
      this.H = new mD();
      this.K = !1;
    },
    vD = function (a, b, c, d, e) {
      var f = EC(d, e.isGtmEvent);
      f && (a.K && (e.deferrable = !0), a.H.push("event", [c, b], f, e));
    };
  uD.prototype.flush = function () {
    this.H.flush();
  };
  var wD;
  function xD() {
    wD || (wD = new uD());
    return wD;
  }
  function yD(a, b, c, d) {
    var e = xD(),
      f = EC(c, d.isGtmEvent);
    f && e.H.push("get", [a, b], f, d);
  }
  function zD(a, b, c) {
    var d = xD(),
      e = EC(a, c.isGtmEvent);
    e && d.H.push("container_config", [b], e, c);
  }
  function AD(a, b, c) {
    var d = xD(),
      e = EC(a, c.isGtmEvent);
    e && d.H.push("destination_config", [b], e, c);
  }
  function BD(a) {
    var b = xD(),
      c = EC(a, !0);
    c && b.H.push("reset_container_config", [], c, {});
  }
  function CD(a) {
    var b = xD(),
      c = EC(a, !0);
    c && b.H.push("reset_target_config", [], c, {});
  }
  function DD(a) {
    var b = xD(),
      c = EC(a, !0);
    return c ? nD(b.H, c).ib : {};
  }
  function ED(a) {
    return xD().H.global[a];
  }
  function FD(a) {
    var b = xD(),
      c = EC(a, !0);
    return c ? nD(b.H, c).H : !1;
  }
  function GD(a, b) {
    a.hasOwnProperty("gtm.uniqueEventId") ||
      Object.defineProperty(a, "gtm.uniqueEventId", { value: mo() });
    b.eventId = a["gtm.uniqueEventId"];
    b.priorityId = a["gtm.priorityId"];
    return { eventId: b.eventId, priorityId: b.priorityId };
  }
  function HD(a) {
    var b = n([K.D.Zb, K.D.bc]),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = c.value,
          e = (a && a[d]) || ED(d);
        if (e) return e;
      }
    } finally {
      z(b, c);
    }
  }
  function ID(a) {
    return !(
      !a.isGtmEvent ||
      (a.eventMetadata &&
        a.eventMetadata[L.J.Ac] &&
        a.eventMetadata[L.J.Gb] !== mm())
    );
  }
  var JD = new (function () {
    this.H = !1;
  })();
  var KD = function () {
    this.messages = [];
    this.listeners = [];
    this.H = Nf(71, 20);
  };
  KD.prototype.enqueue = function (a, b, c) {
    var d = this.messages.length + 1,
      e = c.priorityQueue ? [].concat(w(c.priorityQueue), [d]) : [d];
    if (Nu() && e.length > this.H) R(200);
    else {
      a["gtm.uniqueEventId"] = b;
      a["gtm.priorityId"] = d;
      a["gtm.priorityQueue"] = e;
      var f = ma(Object, "assign").call(Object, {}, c, {
          eventId: b,
          priorityId: d,
          fromContainerExecution: !0,
          priorityQueue: e,
        }),
        g = {
          message: a,
          notBeforeEventId: b,
          priorityId: d,
          messageContext: f,
        };
      this.messages.push(g);
      for (var h = 0; h < this.listeners.length; h++)
        try {
          this.listeners[h](g);
        } catch (k) {}
    }
  };
  KD.prototype.listen = function (a) {
    this.listeners.push(a);
  };
  KD.prototype.get = function () {
    for (var a = {}, b = 0; b < this.messages.length; b++) {
      var c = this.messages[b],
        d = a[c.notBeforeEventId];
      d || ((d = []), (a[c.notBeforeEventId] = d));
      d.push(c);
    }
    return a;
  };
  KD.prototype.prune = function (a) {
    for (var b = [], c = [], d = 0; d < this.messages.length; d++) {
      var e = this.messages[d];
      e.notBeforeEventId === a ? b.push(e) : c.push(e);
    }
    this.messages = c;
    return b;
  };
  function LD(a, b, c) {
    c.eventMetadata = c.eventMetadata || {};
    c.eventMetadata[L.J.Gb] = Nu() ? mm() : H(6);
    MD().enqueue(a, b, c);
  }
  function MD() {
    return fo("mb", function () {
      return new KD();
    });
  }
  var OD = function (a, b) {
      var c = ND;
      b = String(b).split(",");
      for (var d = 0; d < b.length; d++) {
        var e = c.P[b[d]] || [];
        c.P[b[d]] = e;
        e.indexOf(a) < 0 && e.push(a);
      }
    },
    PD = function (a, b) {
      var c = ND;
      b = String(b).split(",");
      for (var d = 0; d < b.length; d++) {
        var e = c.K[b[d]] || [];
        c.K[b[d]] = e;
        e.indexOf(a) < 0 && e.push(a);
      }
    },
    QD = function (a, b) {
      for (
        var c = ND, d = [], e = [], f = {}, g = 0;
        g < a.length;
        f = { Uj: void 0, Aj: void 0, Bj: void 0 }, g++
      ) {
        var h = a[g];
        if (h.indexOf("-") >= 0) {
          if (((f.Uj = EC(h, b)), f.Uj)) {
            var k = km();
            Mb(
              k,
              (function (x) {
                return function (y) {
                  return x.Uj.destinationId === y;
                };
              })(f)
            )
              ? d.push(h)
              : e.push(h);
          }
        } else {
          if (Nu()) {
            var m = c.K[h] || [];
            f.Bj = {};
            m.forEach(
              (function (x) {
                return function (y) {
                  x.Bj[y] = !0;
                };
              })(f)
            );
            for (var p = km(), q = 0; q < p.length; q++)
              f.Bj[p[q]] && d.push(p[q]);
          } else {
            var r = c.H[h] || [];
            f.Aj = {};
            r.forEach(
              (function (x) {
                return function (y) {
                  x.Aj[y] = !0;
                };
              })(f)
            );
            for (var t = nm(), u = 0; u < t.length; u++)
              if (f.Aj[t[u]]) {
                d = d.concat(km());
                break;
              }
          }
          var v = c.P[h] || [];
          v.length && (d = d.concat(v));
        }
      }
      return { Mj: d, Er: e };
    },
    RD = function (a) {
      var b = n(Object.values(ND.K)),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) {
          var d = c.value,
            e = d.indexOf(a);
          e >= 0 && d.splice(e, 1);
        }
      } finally {
        z(b, c);
      }
    },
    SD = function (a) {
      var b = n(Object.values(ND.P)),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) {
          var d = c.value,
            e = d.indexOf(a);
          e >= 0 && d.splice(e, 1);
        }
      } finally {
        z(b, c);
      }
    },
    ND = new (function () {
      this.H = {};
      this.P = {};
      this.K = {};
    })();
  function TD(a, b, c) {
    var d = Eb(a, null);
    d.eventId = void 0;
    d.inheritParentConfig = void 0;
    Object.keys(b).some(function (f) {
      return b[f] !== void 0;
    }) && R(136);
    var e = Eb(b, null);
    Eb(c, e);
    LD(UC(nm()[0], e), a.eventId, d);
  }
  function UD(a, b, c, d) {
    var e = {},
      f =
        ((e[K.D.Vb] = K.D.sa),
        (e["gtm.configContainerId"] = a.id),
        (e["gtm.configParameters"] = b),
        (e["gtm.uniqueEventId"] = d.eventId),
        e);
    d.priorityId && (f["gtm.priorityId"] = d.priorityId);
    c.priorityQueue && (f["gtm.priorityQueue"] = c.priorityQueue);
    c.noTargetGroup &&
      ((c.eventMetadata = c.eventMetadata || {}),
      (c.eventMetadata[L.J.ep] = !0));
    c.eventMetadata && (f["gtm.eventMetadata"] = c.eventMetadata);
    a.mc() &&
      ((f["gtm.configContainerId"] = nm()[0]),
      (f["gtm.originalConfigTargetId"] = a.id));
    return f;
  }
  function VD(a, b, c) {
    if (If(11) && !c && !a[K.D.Ld]) {
      var d = $i(2, function () {
        return !1;
      });
      Yi(2, !0);
      rC(d, a, b);
      if (d) return !0;
    }
    return !1;
  }
  function WD(a, b) {
    var c = {},
      d = ((c.event = a), c);
    b &&
      ((d.eventModel = Eb(b, null)),
      b[K.D.Ff] && (d.eventCallback = b[K.D.Ff]),
      b[K.D.hh] && (d.eventTimeout = b[K.D.hh]));
    return d;
  }
  function XD(a, b) {
    var c = YD(a);
    c === void 0 && (c = "default");
    if (Hb(c) || Array.isArray(c)) {
      var d;
      b.isGtmEvent
        ? (d = Hb(c) ? [c] : c)
        : (d = c.toString().replace(/\s+/g, "").split(","));
      var e = QD(d, b.isGtmEvent),
        f = e.Mj,
        g = e.Er;
      if (g.length)
        for (var h = HD(a), k = 0; k < g.length; k++) {
          var m = EC(g[k], b.isGtmEvent);
          if (m) {
            var p = m.destinationId,
              q = void 0;
            ((q = fm(m.destinationId)) == null ? void 0 : q.state) === 0 ||
              dB(p, h, {
                source: 3,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        }
      var r = f.concat(g);
      return { Mj: FC(f, b.isGtmEvent), gq: FC(r, b.isGtmEvent) };
    }
    Nt(c);
  }
  function YD(a) {
    var b = a && a[K.D.Yb];
    return b !== void 0 ? b : oA(K.D.Yb, 2);
  }
  function ZD(a) {
    var b = YD(a);
    if (b !== void 0) return String(b);
  }
  function $D(a, b) {
    return !(
      !P(667) ||
      !Zi(36) ||
      b.fromContainerExecution ||
      b.noGtmEvent ||
      (a && a[K.D.wc])
    );
  }
  var aE = {},
    bE =
      ((aE.config = function (a, b) {
        var c = GD(a, b),
          d;
        a: {
          if (a.length < 2 || !Hb(a[1])) Nt(a);
          else {
            var e = {};
            if (a.length > 2) {
              if ((a[2] !== void 0 && !Db(a[2])) || a.length > 3) {
                Nt(a);
                d = void 0;
                break a;
              }
              e = a[2];
            }
            var f = EC(a[1], b.isGtmEvent);
            if (f) {
              d = { target: f, params: e };
              break a;
            }
          }
          d = void 0;
        }
        var g = d;
        if (g) {
          var h = g.target,
            k = g.params,
            m;
          a: {
            if (!If(7)) {
              var p = pm(qm());
              if (Dm(p)) {
                var q = p.parent,
                  r = q.isDestination;
                m = { Lr: pm(q), Ar: r };
                break a;
              }
            }
            m = void 0;
          }
          var t = m,
            u = t == null ? void 0 : t.Lr,
            v = t == null ? void 0 : t.Ar;
          xB(c.eventId, "gtag.config");
          var x,
            y = h.destinationId;
          if (h.mc() ? km().indexOf(y) !== -1 : nm().indexOf(y) !== -1)
            a: {
              if (u && (R(128), v && R(130), b.inheritParentConfig)) {
                var B;
                var E = Zi(5);
                if (E) TD(b, E, k), (B = !1);
                else {
                  var F = Zi(4);
                  (!k[K.D.Ld] && (Nu() || If(11)) && F) || Yi(4, Eb(k, null));
                  B = !0;
                }
                B && u.containers && u.containers.join(",");
                x = void 0;
                break a;
              }
              var G = !If(45),
                I = !$b(h.id, "GTM-");
              G &&
                I &&
                (Object.keys(k).length === 0 ? AC(26) : AC(27),
                Sm() && AC(28),
                Zi(23) && AC(29));
              var J = sC;
              gl.K && (J.H === 1 && (cj.H.mcc = !1), (J.H = 2));
              if (Nu() || !VD(k, b, h.mc())) {
                JD.H || R(43);
                if (!Nu()) {
                  if (!b.noTargetGroup) {
                    var M = h.id;
                    if (h.mc()) SD(M), OD(M, k[K.D.Xb] || "default");
                    else {
                      var U = n(Object.values(ND.H)),
                        W = U.next();
                      try {
                        for (; !W.done; W = U.next()) {
                          var fa = W.value,
                            da = fa.indexOf(M);
                          da >= 0 && fa.splice(da, 1);
                        }
                      } finally {
                        z(U, W);
                      }
                      var ea = k[K.D.Xb] || "default",
                        ja = ND;
                      ea = ea.toString().split(",");
                      for (var va = 0; va < ea.length; va++) {
                        var Ga = ja.H[ea[va]] || [];
                        ja.H[ea[va]] = Ga;
                        Ga.indexOf(M) < 0 && Ga.push(M);
                      }
                    }
                  }
                  delete k[K.D.Xb];
                }
                var wa = b.eventMetadata || {};
                wa.hasOwnProperty(L.J.dd) ||
                  (wa[L.J.dd] = !b.fromContainerExecution);
                b.eventMetadata = wa;
                delete k[K.D.Ff];
                if (Nu()) {
                  b.isSystemEvent = !0;
                  x = UD(h, k, b, c);
                  break a;
                }
                var La = !!k[K.D.Ld];
                delete k[K.D.Ld];
                var db = km(),
                  Cb = BD,
                  Ka = zD;
                h.mc() && ((db = [h.id]), (Cb = CD), (Ka = AD));
                for (var Ua = 0; Ua < db.length; Ua++) {
                  La || Cb(db[Ua]);
                  var kb = FD(db[Ua]);
                  Ka(db[Ua], Eb(k, null), Eb(b, null));
                  if (!kb || !La) {
                    var Ib = K.D.sa,
                      ub = Eb(k, null),
                      Jb = db[Ua],
                      $c = Eb(b, null);
                    vD(xD(), Ib, ub, Jb, $c);
                  }
                }
              }
              x = void 0;
            }
          else
            a: {
              if (!b.inheritParentConfig && !k[K.D.Wc]) {
                var rf = HD(k),
                  Xd = h.destinationId;
                if (h.mc())
                  dB(Xd, rf, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  });
                else if (u !== void 0 && u.containers.indexOf(Xd) !== -1) {
                  var zh = Zi(4),
                    Ah = Zi(5);
                  zh ? TD(b, k, zh) : Ah || Yi(5, Eb(k, null));
                } else if (
                  (XA(Xd, rf, !0, {
                    source: 2,
                    fromContainerExecution: b.fromContainerExecution,
                  }),
                  Nu())
                ) {
                  b.isSystemEvent = !0;
                  x = UD(h, k, b, c);
                  break a;
                }
              }
              x = void 0;
            }
          return x;
        }
      }),
      (aE.consent = function (a, b) {
        if (a.length !== 3) Nt(a);
        else {
          R(39);
          var c = GD(a, b),
            d = a[1],
            e = {},
            f = Fn(a[2]),
            g;
          for (g in f)
            if (f.hasOwnProperty(g)) {
              var h = f[g];
              e[g] =
                g === K.D.Tg
                  ? Array.isArray(h)
                    ? NaN
                    : Number(h)
                  : g === K.D.rc
                  ? (Array.isArray(h) ? h : [h]).map(Gn)
                  : Hn(h);
            }
          b.fromContainerExecution ||
            (e[K.D.ka] && R(139), e[K.D.Ra] && R(140));
          if (d === "default") fp(e);
          else if (d === "update") gp(e, c);
          else if (d === "declare" && b.fromContainerExecution) {
            var k = n(e[K.D.rc] || [""]),
              m = k.next();
            try {
              for (; !m.done; m = k.next()) {
                var p = m.value,
                  q = n(Object.entries(e)),
                  r = q.next();
                try {
                  for (; !r.done; r = q.next()) {
                    var t = n(r.value),
                      u = t.next().value,
                      v = t.next().value,
                      x = u;
                    if (x !== K.D.rc) {
                      var y = x,
                        B = Gn(v),
                        E = Fk(),
                        F = Gk();
                      Lm = !0;
                      Km && wb("TAGGING", 20);
                      Fm().declare(y, B, p, E, F);
                    }
                  }
                } finally {
                  z(q, r);
                }
              }
            } finally {
              z(k, m);
            }
          }
        }
      }),
      (aE.container_config = function (a, b) {
        if (ID(b))
          if (a.length === 3 && Hb(a[1]) && Db(a[2])) {
            var c = a[2],
              d = EC(a[1], !0);
            d && zD(d.destinationId, c, Eb(b, null));
          } else Nt(a);
      }),
      (aE.destination_config = function (a, b) {
        if (ID(b))
          if (a.length === 3 && Hb(a[1]) && Db(a[2])) {
            var c = a[2],
              d = EC(a[1], !0);
            if (d) {
              if (Nu()) {
                if (!b.noTargetGroup) {
                  var e = d.id;
                  d.mc()
                    ? (SD(e), OD(e, c[K.D.Xb] || "default"))
                    : (RD(e), PD(e, c[K.D.Xb] || "default"));
                }
                delete c[K.D.Xb];
              }
              AD(d.id, c, Eb(b, null));
            }
          } else Nt(a);
      }),
      (aE.event = function (a, b) {
        var c = a[1];
        if (a.length < 2 || !Hb(c)) Nt(a);
        else {
          var d = void 0;
          if (a.length > 2) {
            if ((!Db(a[2]) && a[2] !== void 0) || a.length > 3) {
              Nt(a);
              return;
            }
            d = a[2];
          }
          var e = WD(c, d),
            f = GD(a, b),
            g = f.eventId,
            h = f.priorityId;
          e["gtm.uniqueEventId"] = g;
          h && (e["gtm.priorityId"] = h);
          b.priorityQueue && (e["gtm.priorityQueue"] = b.priorityQueue);
          P(668) && (b.originalSendTo = ZD(d));
          if (c === "optimize.callback")
            return (e.eventModel = e.eventModel || {}), e;
          var k = XD(d, b);
          if (k) {
            var m = k.Mj,
              p = k.gq,
              q = p.map(function (M) {
                return M.id;
              }),
              r = p.map(function (M) {
                return M.destinationId;
              }),
              t = m.map(function (M) {
                return M.id;
              }),
              u = n(km()),
              v = u.next();
            try {
              for (; !v.done; v = u.next()) {
                var x = v.value;
                r.indexOf(x) < 0 && t.push(x);
              }
            } finally {
              z(u, v);
            }
            xB(g, c);
            var y = $D(d, b) ? [] : t,
              B = n(y),
              E = B.next();
            try {
              for (; !E.done; E = B.next()) {
                var F = E.value,
                  G = Eb(b, null),
                  I = Eb(d, null);
                delete I[K.D.Ff];
                var J = G.eventMetadata || {};
                J.hasOwnProperty(L.J.dd) ||
                  (J[L.J.dd] = !G.fromContainerExecution);
                J[L.J.bj] = q.slice();
                J[L.J.ng] = r.slice();
                G.eventMetadata = J;
                vD(xD(), c, I, F, G);
              }
            } finally {
              z(B, E);
            }
            e.eventModel = e.eventModel || {};
            q.length > 0
              ? (e.eventModel[K.D.Yb] = q.join(","))
              : delete e.eventModel[K.D.Yb];
            JD.H || R(43);
            b.noGtmEvent === void 0 &&
              b.eventMetadata &&
              b.eventMetadata[L.J.gm] &&
              (b.noGtmEvent = !0);
            e.eventModel[K.D.wc] && (b.noGtmEvent = !0);
            return b.noGtmEvent ? void 0 : e;
          }
        }
      }),
      (aE.get = function (a, b) {
        R(53);
        if (a.length === 4 && Hb(a[1]) && Hb(a[2]) && Gb(a[3])) {
          var c = EC(a[1], b.isGtmEvent),
            d = String(a[2]),
            e = a[3];
          if (c) {
            JD.H || R(43);
            var f = HD();
            if (
              Mb(km(), function (h) {
                return c.destinationId === h;
              })
            ) {
              GD(a, b);
              var g = {};
              Eb(((g[K.D.Jf] = d), (g[K.D.If] = e), g), null);
              yD(
                d,
                function (h) {
                  kd(function () {
                    e(h);
                  });
                },
                c.id,
                b
              );
            } else
              dB(c.destinationId, f, {
                source: 4,
                fromContainerExecution: b.fromContainerExecution,
              });
          }
        } else Nt(a);
      }),
      (aE.js = function (a, b) {
        var c;
        if (a.length === 2 && a[1].getTime) {
          JD.H = !0;
          var d = GD(a, b),
            e = d.eventId,
            f = d.priorityId,
            g = {};
          c =
            ((g.event = "gtm.js"),
            (g["gtm.start"] = a[1].getTime()),
            (g["gtm.uniqueEventId"] = e),
            (g["gtm.priorityId"] = f),
            g);
        } else Nt(a), (c = void 0);
        return c;
      }),
      (aE.policy = function (a) {
        if (a.length === 3 && Hb(a[1]) && Gb(a[2])) {
          Jx(a[1], a[2]);
          R(74);
          if (a[1] === "all") {
            R(75);
            var b = !1;
            try {
              b = a[2](H(5), "unknown", {});
            } catch (k) {}
            b || R(76);
          }
          if (P(610)) {
            var c = a[1] === "all";
            if (Dx.includes(a[1]) || c) {
              var d = c ? "a" : "i",
                e = n(c ? Dx : [a[1]]),
                f = e.next();
              try {
                for (; !f.done; f = e.next()) {
                  var g = f.value,
                    h = !1;
                  try {
                    h = a[2](H(5), g, {});
                  } catch (k) {}
                  h || (Fx || (Fx = new Ex()), Fx.Zh(g, d));
                }
              } finally {
                z(e, f);
              }
            }
          }
        } else Nt(a), R(73);
      }),
      (aE.reset_target_config = function (a, b) {
        if (ID(b))
          if (a.length === 2 && Hb(a[1])) {
            var c = EC(a[1], !0);
            c && CD(c.id);
          } else Nt(a);
      }),
      (aE.set = function (a, b) {
        var c = void 0;
        a.length === 2 && Db(a[1])
          ? (c = Eb(a[1], null))
          : a.length === 3 && Hb(a[1])
          ? ((c = {}),
            Db(a[2]) || Array.isArray(a[2])
              ? (c[a[1]] = Eb(a[2], null))
              : (c[a[1]] = a[2]))
          : Nt(a);
        if (c) {
          Yi(23, !0);
          var d = GD(a, b),
            e = d.eventId,
            f = d.priorityId;
          Eb(c, null);
          H(5);
          var g = Eb(c, null);
          xD().H.push("set", [g], void 0, b);
          c["gtm.uniqueEventId"] = e;
          f && (c["gtm.priorityId"] = f);
          delete c.event;
          b.overwriteModelFields = !0;
          return c;
        }
      }),
      aE),
    cE = {},
    dE = ((cE.policy = !0), cE);
  var fE = function (a) {
    if (eE(a)) return a;
    this.value = a;
  };
  fE.prototype.getUntrustedMessageValue = function () {
    return this.value;
  };
  var eE = function (a) {
    return !a || Ab(a) !== "object" || Db(a)
      ? !1
      : "getUntrustedMessageValue" in a;
  };
  fE.prototype.getUntrustedMessageValue = fE.prototype.getUntrustedMessageValue;
  function FE(a) {}
  var GE = function () {
    var a = this;
    this.loaded = !1;
    this.listeners = [];
    if (C.readyState === "complete") this.onLoad();
    else
      id(A, "load", function () {
        return void a.onLoad();
      });
  };
  GE.prototype.onLoad = function () {
    if (!this.loaded) {
      this.loaded = !0;
      for (var a = 0; a < this.listeners.length; a++) kd(this.listeners[a]);
    }
  };
  var IE = function (a) {
      var b = HE;
      b.loaded ? kd(a) : b.listeners.push(a);
    },
    HE = new GE();
  var JE = function () {
      this.Z = 0;
      this.K = {};
      this.H = [];
      this.P = [];
      this.da = this.T = this.ja = !1;
    },
    LE = function (a, b, c) {
      var d = KE;
      a.eventCallback = b;
      c && (a.eventTimeout = c);
      return d.push(a);
    },
    ME = function (a, b) {
      if (!Kb(b) || b < 0) b = 0;
      var c = lo(),
        d = 0,
        e = !1,
        f = void 0;
      f = A.setTimeout(function () {
        e || ((e = !0), a());
        f = void 0;
      }, b);
      return function () {
        var g = c ? c.subscribers : 1;
        ++d === g &&
          (f && (A.clearTimeout(f), (f = void 0)), e || (a(), (e = !0)));
      };
    },
    OE = function (a) {
      var b;
      if (a.P.length) b = a.P.shift();
      else if (a.H.length) b = a.H.shift();
      else return;
      var c;
      var d = b;
      if (a.ja || !NE(d.message)) c = d;
      else {
        a.ja = !0;
        var e = d.message["gtm.uniqueEventId"],
          f,
          g;
        typeof e === "number"
          ? ((f = e - 2), (g = e - 1))
          : ((f = mo()), (g = mo()), (d.message["gtm.uniqueEventId"] = mo()));
        var h = {},
          k = {
            message:
              ((h.event = "gtm.init_consent"), (h["gtm.uniqueEventId"] = f), h),
            messageContext: { eventId: f },
          },
          m = {},
          p = {
            message: ((m.event = "gtm.init"), (m["gtm.uniqueEventId"] = g), m),
            messageContext: { eventId: g },
          };
        a.H.unshift(p, d);
        c = k;
      }
      return c;
    },
    RE = function (a) {
      a.da || R(196);
      for (var b = !1, c; !a.T && (c = OE(a)); ) {
        a.T = !0;
        var d = lA;
        delete d.H.eventModel;
        iA(d);
        var e = c,
          f = e.message,
          g = e.messageContext;
        if (f == null) a.T = !1;
        else {
          g.fromContainerExecution && mA();
          try {
            if (Gb(f))
              try {
                f.call(nA);
              } catch (La) {}
            else if (Array.isArray(f)) {
              if (Hb(f[0])) {
                var h = f[0].split("."),
                  k = h.pop(),
                  m = f.slice(1),
                  p = oA(h.join("."), 2);
                if (p != null)
                  try {
                    p[k].apply(p, m);
                  } catch (La) {}
              }
            } else {
              var q = void 0,
                r = Qb(f);
              if (r)
                a: {
                  if (f.length)
                    if (Hb(f[0])) {
                      var t = bE[f[0]];
                      if (t)
                        if (g.fromContainerExecution && dE[f[0]]) Nt(f);
                        else {
                          q = t(f, g);
                          break a;
                        }
                      else Nt(f);
                    } else Nt(f);
                  q = void 0;
                }
              else if (((q = f), P(669))) {
                var u = void 0,
                  v = f,
                  x = !!f.event;
                if (gl.P && (hD(), (u = fD) != null)) {
                  var y = void 0,
                    B = u,
                    E = x,
                    F = n(Object.keys(v)),
                    G = F.next();
                  try {
                    for (; !G.done; G = F.next())
                      (y = G.value.split(".")[0]),
                        E ? B.H.add(y) : B.H.delete(y);
                  } finally {
                    z(F, G);
                  }
                }
              }
              if (q) {
                var I;
                var J = void 0,
                  M = q,
                  U = ma(Object, "assign").call(Object, {}, g, {
                    isGtagCommand: r,
                  }),
                  W = M._clear || U.overwriteModelFields,
                  fa = n(Object.keys(M)),
                  da = fa.next();
                try {
                  for (; !da.done; da = fa.next())
                    (J = da.value),
                      J !== "_clear" &&
                        (W && lA.set(J, void 0),
                        lA.set(J, M[J]),
                        P(660) && !M.event && hA(lA, J, M[J]));
                } finally {
                  z(fa, da);
                }
                P(592) && FE(M);
                Zi(11) || Yi(11, M["gtm.start"]);
                var ea = M["gtm.uniqueEventId"];
                M.event
                  ? (typeof ea !== "number" &&
                      ((ea = mo()),
                      (M["gtm.uniqueEventId"] = ea),
                      lA.set("gtm.uniqueEventId", ea)),
                    (I = UB(M, U).bk))
                  : (I = !1);
                b = I || b;
              }
            }
          } finally {
            g.fromContainerExecution && iA(lA, !0);
            var ja = f["gtm.uniqueEventId"];
            if (typeof ja === "number") {
              for (
                var va = a, Ga = va.K[String(ja)] || [], wa = 0;
                wa < Ga.length;
                wa++
              )
                va.P.push(PE(Ga[wa]));
              Ga.length && va.P.sort(QE);
              delete va.K[String(ja)];
              ja > a.Z && (a.Z = ja);
            }
            a.T = !1;
          }
        }
      }
      return !b;
    },
    SE = function () {
      var a = KE;
      a.da && R(195);
      a.da = !0;
      if (gl.H) {
        var b = !If(51),
          c = pz();
        nz(c, { stage: Uy.X.Ug });
        if (b) {
          var d = oz(c, { stage: Uy.X.wk }, Uy.X.hi);
          d !== void 0 && (c.H.Y = d);
        }
        var e = a.H.length;
        pz().H.C = e;
      }
      RE(a);
      if (gl.H) {
        var f = pz(),
          g = oz(f, { stage: Uy.X.sk }, Uy.X.Ug);
        g !== void 0 && (f.H.B = g);
      }
      try {
        var h = A[H(19)],
          k = H(5),
          m = h.hide;
        if (m && m[k] !== void 0 && m.end) {
          m[k] = !1;
          var p = !0,
            q;
          for (q in m)
            if (m.hasOwnProperty(q) && m[q] === !0) {
              p = !1;
              break;
            }
          p && (m.end(), (m.end = null));
        }
      } catch (r) {
        H(5), H(5);
      }
    },
    TE = function (a, b) {
      if (a.Z < b.notBeforeEventId) {
        var c = String(b.notBeforeEventId);
        a.K[c] = a.K[c] || [];
        a.K[c].push(b);
      } else
        a.P.push(PE(b)),
          a.P.sort(QE),
          md(function () {
            a.T || RE(a);
          });
    };
  JE.prototype.bind = function () {
    function a(h) {
      var k = {};
      if (eE(h)) {
        var m = h;
        h = eE(m) ? m.getUntrustedMessageValue() : void 0;
        k.fromContainerExecution = !0;
      }
      return { message: h, messageContext: k };
    }
    var b = this,
      c = Vc(H(19), []),
      d = ko();
    d.pruned === !0 && R(83);
    this.K = MD().get();
    MD().listen(function (h) {
      TE(b, h);
    });
    d.subscribers = (d.subscribers || 0) + 1;
    var e = c.push,
      f = this;
    c.push = function () {
      var h;
      go();
      if (eo.H.SANDBOXED_JS_SEMAPHORE > 0) {
        h = [];
        for (var k = 0; k < arguments.length; k++) h[k] = new fE(arguments[k]);
      } else h = [].slice.call(arguments, 0);
      var m = h.map(function (t) {
        return a(t);
      });
      f.H.push.apply(f.H, m);
      var p = e.apply(c, h),
        q = Math.max(100, Nf(1, 300));
      if (this.length > q)
        for (R(4), d.pruned = !0; this.length > q; ) this.shift();
      var r = typeof p !== "boolean" || p;
      return RE(f) && r;
    };
    var g = c.slice(0).map(function (h) {
      return a(h);
    });
    this.H.push.apply(this.H, g);
    If(51) || (gl.H && sz(), kd(UE));
    pC(function () {
      if (!d.gtmDom) {
        d.gtmDom = !0;
        var h = {};
        c.push(((h.event = "gtm.dom"), h));
      }
    });
    IE(function () {
      if (!d.gtmLoad) {
        d.gtmLoad = !0;
        var h = {};
        c.push(((h.event = "gtm.load"), h));
      }
    });
  };
  JE.prototype.push = function (a) {
    return A[H(19)].push(a);
  };
  var KE = new JE();
  function QE(a, b) {
    var c = a.messageContext,
      d = b.messageContext;
    if (c.eventId !== d.eventId) return c.eventId - d.eventId;
    var e, f, g;
    a: {
      for (
        var h = (e = c.priorityQueue) != null ? e : [c.priorityId],
          k = (f = d.priorityQueue) != null ? f : [d.priorityId],
          m = Math.min(h.length, k.length),
          p = 0;
        p < m;
        p++
      )
        if (h[p] !== k[p]) {
          g = h[p] - k[p];
          break a;
        }
      g = h.length - k.length;
    }
    return g;
  }
  function NE(a) {
    if (a == null || typeof a !== "object") return !1;
    if (a.event) return !0;
    if (Qb(a)) {
      var b = a[0];
      if (b === "config" || b === "event" || b === "js" || b === "get")
        return !0;
    }
    return !1;
  }
  function PE(a) {
    return { message: a.message, messageContext: a.messageContext };
  }
  function VE(a, b, c) {
    return LE(a, b, c);
  }
  function WE(a, b) {
    return ME(a, b);
  }
  function UE() {
    SE();
  }
  function XE(a) {
    return KE.push(a);
  }
  var YE = function () {};
  YE.prototype.bind = function () {
    var a,
      b = Fj(A.location.href);
    (a = b.hostname + b.pathname) && gj("dl", encodeURIComponent(a));
    var c;
    var d = H(5);
    if (d) {
      var e = If(7) ? 1 : 0,
        f = xm(),
        g = f && f.fromContainerExecution ? 1 : 0,
        h = (f && f.source) || 0,
        k = H(6);
      c = d + ";" + k + ";" + g + ";" + h + ";" + e;
    } else c = void 0;
    var m = c;
    m && gj("tdp", m);
    var p = oq(!0);
    p !== void 0 && gj("frm", String(p));
  };
  var ZE = new YE();
  var $E = function () {
      this.H = Yk();
      this.K = void 0;
    },
    aF = function (a, b) {
      return $k(a, function (c) {
        return c.jb > 0 ? (b ? c.jb + "_" + Xk(c) : String(c.jb)) : void 0;
      });
    };
  $E.prototype.bind = function () {
    var a = this;
    if (Ro() || gl.K)
      gj(
        "csp",
        function () {
          var b = aF(a.H, !0);
          al(a.H);
          return b;
        },
        !1
      ),
        gj(
          "mde",
          function () {
            var b = dl.H,
              c = aF(b, !1);
            al(b);
            return c;
          },
          !1
        ),
        A.addEventListener("securitypolicyviolation", function (b) {
          if (b.disposition === "enforce") {
            R(179);
            var c = nl(b.effectiveDirective);
            if (c) {
              var d;
              a: {
                var e = b.blockedURI,
                  f = kl;
                if (gl.K && e) {
                  var g = jl(c, e);
                  if (g) {
                    var h;
                    d = (h = ll(f, c)) == null ? void 0 : h[g];
                    break a;
                  }
                }
                d = void 0;
              }
              var k = d;
              if (k) {
                var m;
                a: {
                  try {
                    var p = new URL(b.blockedURI),
                      q = p.pathname.indexOf(";");
                    m =
                      q >= 0
                        ? p.origin + p.pathname.substring(0, q)
                        : p.origin + p.pathname;
                    break a;
                  } catch (F) {}
                  m = void 0;
                }
                var r = m;
                if (r) {
                  var t = n(k),
                    u = t.next();
                  try {
                    for (; !u.done; u = t.next()) {
                      var v = u.value;
                      if (!v.qn) {
                        v.qn = !0;
                        var x = {
                          eventId: v.eventId,
                          priorityId: v.priorityId,
                        };
                        if (Ro()) {
                          var y = x,
                            B = {
                              type: 1,
                              blockedUrl: r,
                              endpoint: v.endpoint,
                              violation: b.effectiveDirective,
                            };
                          if (Ro()) {
                            var E = Xo("TAG_DIAGNOSTICS", {
                              eventId: y == null ? void 0 : y.eventId,
                              priorityId: y == null ? void 0 : y.priorityId,
                            });
                            E.tagDiagnostics = B;
                            Qo(E);
                          }
                        }
                        bF(a, v.destinationId, v.endpoint, c);
                      }
                    }
                  } finally {
                    z(t, u);
                  }
                  ml(c, b.blockedURI);
                }
              }
            }
          }
        });
  };
  var bF = function (a, b, c, d) {
      bl(a.H, b, c, 1, d);
      ej(cj, "csp", !0);
      ej(cj, "mde", !0);
      c !== 61 &&
        c !== 56 &&
        a.K === void 0 &&
        (a.K = A.setTimeout(function () {
          a.H.jb > 0 && kn(!1);
          a.K = void 0;
        }, 500));
    },
    cF = new $E();
  var dF = function () {
    this.sequenceNumber = 0;
  };
  dF.prototype.bind = function () {
    var a = this;
    eF(this);
    If(65) && gj("mtbl", "1");
    gj("v", "3");
    gj("t", "t");
    gj("pid", function () {
      return String(uk(qk.ba.Wg));
    });
    gj("gtm", function () {
      return Ku();
    });
    gj("seq", function () {
      return String(++a.sequenceNumber);
    });
    gj("exp", function () {
      return aq();
    });
  };
  var eF = function (a) {
      if (uk(qk.ba.Wg) === void 0) {
        var b = function () {
          tk(qk.ba.Wg, Nb());
          a.sequenceNumber = 0;
        };
        b();
        ld(b, 864e5);
      } else
        wk(qk.ba.Wg, function () {
          a.sequenceNumber = 0;
        });
      a.sequenceNumber = 0;
    },
    fF = new dF();
  function gF(a) {
    return function () {
      return A[a];
    };
  }
  var hF = {},
    iF =
      ((hF[14] = function () {
        var a;
        return (a = A.crypto) == null ? void 0 : a.getRandomValues;
      }),
      (hF[15] = function () {
        var a, b;
        return (a = A.crypto) == null
          ? void 0
          : (b = a.subtle) == null
          ? void 0
          : b.digest;
      }),
      (hF[1] = gF("fetch")),
      (hF[6] = gF("Map")),
      (hF[2] = function () {
        return Math.random;
      }),
      (hF[8] = function () {
        return ma(Object, "assign");
      }),
      (hF[9] = function () {
        return Object.entries;
      }),
      (hF[10] = function () {
        return Object.fromEntries;
      }),
      (hF[5] = gF("Promise")),
      (hF[16] = gF("queueMicrotask")),
      (hF[13] = gF("RegExp")),
      (hF[17] = gF("requestIdleCallback")),
      (hF[3] = function () {
        return Qc.sendBeacon;
      }),
      (hF[7] = gF("Set")),
      (hF[12] = function () {
        return String.prototype.endsWith;
      }),
      (hF[11] = function () {
        return String.prototype.startsWith;
      }),
      (hF[4] = gF("XMLHttpRequest")),
      hF),
    jF = {},
    kF = ((jF[15] = !0), jF);
  var lF = /^(https?:)?\/\//;
  function GF() {}
  function HF() {
    var a = !1,
      b = function () {
        !a && vA() && (a = !0);
      };
    If(62) &&
      (Jx("detect_link_click_events", function (c, d, e) {
        var f;
        return ((f = e.options) == null ? void 0 : f.waitForTags) === !0
          ? (b(), !1)
          : !0;
      }),
      Jx("detect_form_submit_events", function (c, d, e) {
        var f;
        return ((f = e.options) == null ? void 0 : f.waitForTags) === !0
          ? (b(), !1)
          : !0;
      }),
      Jx("detect_youtube_activity_events", function (c, d, e) {
        var f;
        return ((f = e.options) == null ? void 0 : f.fixMissingApi) === !0
          ? (b(), !1)
          : !0;
      }));
  }
  var IF = function () {
    this.H = this.gppString = void 0;
  };
  IF.prototype.reset = function () {
    this.H = this.gppString = void 0;
  };
  var JF = new IF();
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  Rt({
    Mt: 0,
    Lt: 1,
    It: 2,
    Dt: 3,
    Jt: 4,
    Et: 5,
    Kt: 6,
    Gt: 7,
    Ht: 8,
    Ct: 9,
    Ft: 10,
    Nt: 11,
  }).map(function (a) {
    return Number(a);
  });
  Rt({ Pt: 0, Qt: 1, Ot: 2 }).map(function (a) {
    return Number(a);
  });
  var KF = function (a, b, c, d) {
    Xt.call(this);
    this.Sd = b;
    this.jd = c;
    this.Pb = d;
    this.Ia = new Map();
    this.Td = 0;
    this.ja = new Map();
    this.Aa = new Map();
    this.Z = void 0;
    this.K = a;
  };
  ta(KF, Xt);
  KF.prototype.P = function () {
    delete this.H;
    this.Ia.clear();
    this.ja.clear();
    this.Aa.clear();
    this.Z && (Tt(this.K, "message", this.Z), delete this.Z);
    delete this.K;
    delete this.Pb;
    Xt.prototype.P.call(this);
  };
  var LF = function (a) {
      if (a.H) return a.H;
      a.jd && a.jd(a.K) ? (a.H = a.K) : (a.H = nq(a.K, a.Sd));
      var b;
      return (b = a.H) != null ? b : null;
    },
    NF = function (a, b, c) {
      if (LF(a))
        if (a.H === a.K) {
          var d = a.Ia.get(b);
          d && d(a.H, c);
        } else {
          var e = a.ja.get(b);
          if (e && e.Lj) {
            MF(a);
            var f = ++a.Td;
            a.Aa.set(f, {
              Yd: e.Yd,
              zq: e.Um(c),
              persistent: b === "addEventListener",
            });
            a.H.postMessage(e.Lj(c, f), "*");
          }
        }
    },
    MF = function (a) {
      a.Z ||
        ((a.Z = function (b) {
          if (b.source === a.H)
            try {
              var c;
              c = a.Pb ? a.Pb(b) : void 0;
              if (c) {
                var d = c.Or,
                  e = a.Aa.get(d);
                if (e) {
                  e.persistent || a.Aa.delete(d);
                  var f;
                  (f = e.Yd) == null || f.call(e, e.zq, c.payload);
                }
              }
            } catch (g) {}
        }),
        St(a.K, "message", a.Z));
    };
  var OF = function (a, b) {
      var c = b.listener,
        d = (0, a.__gpp)("addEventListener", c);
      d && c(d, !0);
    },
    PF = function (a, b) {
      (0, a.__gpp)("removeEventListener", b.listener, b.listenerId);
    },
    QF = {
      Um: function (a) {
        return a.listener;
      },
      Lj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "addEventListener",
            version: "1.1",
          }),
          c
        );
      },
      Yd: function (a, b) {
        var c = b.__gppReturn;
        a(c.returnValue, c.success);
      },
    },
    RF = {
      Um: function (a) {
        return a.listener;
      },
      Lj: function (a, b) {
        var c = {};
        return (
          (c.__gppCall = {
            callId: b,
            command: "removeEventListener",
            version: "1.1",
            parameter: a.listenerId,
          }),
          c
        );
      },
      Yd: function (a, b) {
        var c = b.__gppReturn,
          d = c.returnValue.data;
        a == null || a(d, c.success);
      },
    };
  function SF(a) {
    var b = {};
    wf(a.data) ? (b = JSON.parse(a.data)) : (b = a.data);
    return { payload: b, Or: b.__gppReturn.callId };
  }
  var TF = function (a, b) {
    var c;
    c = (b === void 0 ? {} : b).timeoutMs;
    Xt.call(this);
    this.caller = new KF(
      a,
      "__gppLocator",
      function (d) {
        return typeof d.__gpp === "function";
      },
      SF
    );
    this.caller.Ia.set("addEventListener", OF);
    this.caller.ja.set("addEventListener", QF);
    this.caller.Ia.set("removeEventListener", PF);
    this.caller.ja.set("removeEventListener", RF);
    this.timeoutMs = c != null ? c : 500;
  };
  ta(TF, Xt);
  TF.prototype.P = function () {
    this.caller.dispose();
    Xt.prototype.P.call(this);
  };
  TF.prototype.addEventListener = function (a) {
    var b = this,
      c = hq(function () {
        a(UF, !0);
      }),
      d =
        this.timeoutMs === -1
          ? void 0
          : setTimeout(function () {
              c();
            }, this.timeoutMs);
    NF(this.caller, "addEventListener", {
      listener: function (e, f) {
        clearTimeout(d);
        try {
          var g;
          var h;
          ((h = e.pingData) == null ? void 0 : h.gppVersion) === void 0 ||
          e.pingData.gppVersion === "1" ||
          e.pingData.gppVersion === "1.0"
            ? (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 1,
                  gppString: "GPP_ERROR_STRING_IS_DEPRECATED_SPEC",
                  applicableSections: [-1],
                },
              }))
            : Array.isArray(e.pingData.applicableSections)
            ? (g = e)
            : (b.removeEventListener(e.listenerId),
              (g = {
                eventName: "signalStatus",
                data: "ready",
                pingData: {
                  internalErrorState: 2,
                  gppString:
                    "GPP_ERROR_STRING_EXPECTED_APPLICATION_SECTION_ARRAY",
                  applicableSections: [-1],
                },
              }));
          a(g, f);
        } catch (k) {
          if (e == null ? 0 : e.listenerId)
            try {
              b.removeEventListener(e.listenerId);
            } catch (m) {
              a(VF, !0);
              return;
            }
          a(WF, !0);
        }
      },
    });
  };
  TF.prototype.removeEventListener = function (a) {
    NF(this.caller, "removeEventListener", {
      listener: function () {},
      listenerId: a,
    });
  };
  var WF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        internalErrorState: 2,
        gppString: "GPP_ERROR_STRING_UNAVAILABLE",
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    UF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_LISTENER_REGISTRATION_TIMEOUT",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    },
    VF = {
      eventName: "signalStatus",
      data: "ready",
      pingData: {
        gppString: "GPP_ERROR_STRING_REMOVE_EVENT_LISTENER_ERROR",
        internalErrorState: 2,
        applicableSections: [-1],
      },
      listenerId: -1,
    };
  function XF(a) {
    var b;
    if (!(b = a.pingData.signalStatus === "ready")) {
      var c = a.pingData.applicableSections;
      b = !c || (c.length === 1 && c[0] === -1);
    }
    if (b) {
      JF.gppString = a.pingData.gppString;
      var d = a.pingData.applicableSections.join(",");
      JF.H = d;
    }
  }
  function YF() {
    try {
      var a = new TF(A, { timeoutMs: -1 });
      LF(a.caller) && a.addEventListener(XF);
    } catch (b) {}
  }
  function Ax() {
    var a = [
        ["cv", H(1)],
        ["rv", H(14)],
        [
          "tc",
          JA.tags.filter(function (d) {
            return d;
          }).length,
        ],
      ],
      b = Jf(15);
    b && a.push(["x", b]);
    var c = aq();
    c && a.push(["tag_exp", c]);
    return a;
  }
  var aG = function () {
      var a = this;
      this.H = {};
      this.K = {};
      xx(function (b) {
        var c = b.eventId,
          d = b.fe,
          e = [],
          f = a.H[c] || [];
        f.length && e.push(["hf", f.join(".")]);
        var g = a.K[c] || [];
        g.length && e.push(["ht", g.join(".")]);
        d && (delete a.H[c], delete a.K[c]);
        return e;
      });
    },
    bG = function () {
      var a = 0;
      return function (b) {
        switch (b) {
          case 1:
            a |= 1;
            break;
          case 2:
            a |= 2;
            break;
          case 3:
            a |= 4;
        }
        return a;
      };
    },
    cG;
  function dG() {
    return !1;
  }
  function eG() {
    var a = {};
    return function (b, c, d) {};
  }
  function fG(a, b) {
    var c = b.event,
      d = { gtm: c.Ih.gtm, ecommerce: c.Ih.ecommerce };
    return ma(Object, "assign").call(
      Object,
      {},
      {
        eventId: c.id,
        priorityId: c.priorityId,
        priorityQueue: c.priorityQueue,
        qm: Hx(a),
        pg: function (e) {
          c.kd.pg(e);
        },
        Ih: d,
        originalEventData: c.originalEventData,
        M: c.M,
        originalSendTo: c.originalSendTo,
        Dq: { index: b.index, type: b.type, name: b.name },
        Zh: !!iB(a, 3),
        Qb: function () {
          return a;
        },
      },
      gG()
    );
  }
  function gG() {
    if (!dG()) return { rb: void 0, log: function () {} };
    var a = eG(),
      b,
      c;
    return {
      rb: {
        ek: [],
        rg: {},
        kc: function (d, e, f) {
          e === 1 && (b = d);
          e === 7 && (c = f);
          a(d, e, f);
        },
        Vh: Uh(),
      },
      log: function (d) {
        var e = Qa.apply(1, arguments);
        b && a(b, 4, { level: d, source: c, message: e });
      },
    };
  }
  function hG(a) {
    if (!a) return {};
    var b = a.Dq;
    return hB(b.type, b.index, b.name);
  }
  function iG(a) {
    if (!a) return {};
    var b = { originatingEntity: hG(a) };
    a.priorityQueue && (b.priorityQueue = a.priorityQueue);
    return b;
  }
  function jG() {
    var a = kG;
    return function (b, c, d) {
      lG(c);
      var e = ph(b) ? void 0 : 1,
        f = new nb(),
        g = n(Object.entries(c)),
        h = g.next();
      try {
        for (; !h.done; h = g.next()) {
          var k = n(h.value),
            m = k.next().value,
            p = k.next().value,
            q = m,
            r = p,
            t = Vd(r, void 0, e);
          t === void 0 && r !== void 0 && R(44);
          f.set(q, t);
        }
      } finally {
        z(g, h);
      }
      a.Rb(Rf());
      var u = fG(b, d);
      var v;
      v = sf(a.H.Zo(u, [b, f]));
      a.Rb();
      v instanceof Va && (v.type === "return" ? (v = v.data) : (v = void 0));
      return D(v, void 0, e);
    };
  }
  function lG(a) {
    var b = a.gtmOnSuccess,
      c = a.gtmOnFailure;
    Gb(b) &&
      (a.gtmOnSuccess = function () {
        kd(b);
      });
    Gb(c) &&
      (a.gtmOnFailure = function () {
        kd(c);
      });
  }
  function pG() {
    var a;
    a = a === void 0 ? document : a;
    var b;
    return !(
      (b = a.featurePolicy) == null ||
      !b.allowedFeatures().includes("attribution-reporting")
    );
  }
  function sG(a) {
    return !!a && $b(a, "S-");
  }
  function tG(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    var e = fq(),
      f = dq(e);
    if (f.url)
      if (d) {
        var g = c(f.url);
        b !== g && X(a, K.D.Me, g);
      } else {
        var h = f.url;
        b !== h && X(a, K.D.Me, c(h));
      }
  }
  function uG() {
    var a = A.screen;
    return { width: a ? a.width : 0, height: a ? a.height : 0 };
  }
  function vG(a) {
    if (C.hidden) return !0;
    var b = a.getBoundingClientRect();
    if (b.top === b.bottom || b.left === b.right || !A.getComputedStyle)
      return !0;
    var c = A.getComputedStyle(a, null);
    if (c.visibility === "hidden") return !0;
    for (var d = a, e = c; d; ) {
      if (e.display === "none") return !0;
      var f = e.opacity,
        g = e.filter;
      if (g) {
        var h = g.indexOf("opacity(");
        h >= 0 &&
          ((g = g.substring(h + 8, g.indexOf(")", h))),
          g.charAt(g.length - 1) === "%" && (g = g.substring(0, g.length - 1)),
          (f = String(Math.min(Number(g), Number(f)))));
      }
      if (f !== void 0 && Number(f) <= 0) return !0;
      (d = d.parentElement) && (e = A.getComputedStyle(d, null));
    }
    return !1;
  }
  var WG =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function XG(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function YG(a) {
    var b, c;
    return (c = (b = a.google_tag_data) == null ? void 0 : b.uach_promise) !=
      null
      ? c
      : null;
  }
  function ZG(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
        ? void 0
        : c.getHighEntropyValues) === "function"
    );
  }
  function $G(a) {
    if (!ZG(a)) return null;
    var b = XG(a);
    if (b.uach_promise) return b.uach_promise;
    var c = a.navigator.userAgentData
      .getHighEntropyValues(WG)
      .then(function (d) {
        b.uach != null || (b.uach = d);
        return d;
      });
    return (b.uach_promise = c);
  }
  var mH = new Map([["aw", 4]]);
  function nH(a) {
    var b = Wr[a],
      c = mH.get(a);
    return c
      ? (Xq(b, c) || []).some(function (d) {
          return d.m === "0" || d.m === void 0;
        })
      : !1;
  }
  function oH(a, b) {
    if (P(495)) {
      var c = new Map(),
        d = n(mH),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = n(e.value),
            g = f.next().value,
            h = f.next().value,
            k = g,
            m = h,
            p = a[k],
            q = Array.isArray(p) ? p[0] : p;
          if (q !== void 0) {
            var r = {},
              t =
                ((r.k = q),
                (r.i = String(Math.floor(Date.now() / 1e3))),
                (r.b = []),
                (r.m = "1"),
                r),
              u = Bq(t, m);
            u && (nH(k) || c.set(k, u));
          }
        }
      } finally {
        z(d, e);
      }
      if (c.size) {
        var v,
          x =
            b.domain && b.domain !== "auto"
              ? b.domain
              : "auto:" + A.location.hostname,
          y = {},
          B = ((y.p = b.path || "/"), (y.ce = b.lu), (y.d = x), y),
          E = n(c),
          F = E.next();
        try {
          for (; !F.done; F = E.next()) {
            var G = n(F.value),
              I = G.next().value,
              J = G.next().value;
            B[I] = J;
          }
        } finally {
          z(E, F);
        }
        v = "_/set_cookie?" + Vi(B);
        var M,
          U = H(58);
        M = Ff(v, U);
        var W = Mj() + "/" + M;
        vd(W);
      }
    }
  }
  function pH(a) {
    return "CWVWebViewMessage" in a;
  }
  function qH(a) {
    var b = A,
      c = b.webkit;
    delete b.webkit;
    a(b.webkit);
    b.webkit = c;
  }
  function rH(a, b) {
    var c = { action: "gcl_setup" };
    if (pH(a.messageHandlers))
      return (
        a.messageHandlers.CWVWebViewMessage.postMessage({
          command: b,
          payload: c,
        }),
        !0
      );
    var d = a.messageHandlers[b];
    return d ? (d.postMessage(c), !0) : !1;
  }
  var sH = {},
    tH = ((sH.awb = { notFound: 178 }), (sH.ytb = { notFound: 194 }), sH);
  function uH(a) {
    var b,
      c = (b = tH[a]) == null ? void 0 : b.notFound;
    c && R(c);
  }
  function vH(a) {
    if (!uk(qk.ba.Vl) && "webkit" in A && A.webkit.messageHandlers) {
      var b = function () {
        try {
          qH(function (c) {
            if (c) {
              var d;
              d =
                pH(c.messageHandlers) || "awb" in c.messageHandlers
                  ? { command: "awb", source: 5 }
                  : pH(c.messageHandlers) || "ytb" in c.messageHandlers
                  ? { command: "ytb", source: 8 }
                  : void 0;
              d &&
                (tk(qk.ba.Vl, function (e) {
                  var f = d.source;
                  e.gclid && Ls("gcl_aw", e.gclid, f, a);
                  e.wbraid && Ls("gcl_gb", e.wbraid, f, a);
                }),
                rH(c, d.command) || uH(d.command));
            }
          });
        } catch (c) {
          R(193);
        }
      };
      Um(function () {
        bs(cq) ? b() : Vm(b, cq);
      }, cq);
    }
  }
  var wH = [
    "https://www.google.com",
    "https://www.youtube.com",
    "https://m.youtube.com",
  ];
  function xH(a) {
    return a.data.action !== "gcl_transfer"
      ? (R(173), !0)
      : a.data.gadSource
      ? a.data.gclid
        ? !1
        : (R(181), !0)
      : (R(180), !0);
  }
  function yH(a, b) {
    if (!a || P(a)) {
      if (uk(qk.ba.Re)) return R(176), qk.ba.Re;
      if (uk(qk.ba.Xl)) return R(170), qk.ba.Re;
      var c = fq();
      if (!c) R(171);
      else if (c.opener) {
        var d = function (g) {
          if (!wH.includes(g.origin)) R(172);
          else if (!xH(g)) {
            var h = { gadSource: g.data.gadSource };
            h.gclid = g.data.gclid;
            tk(qk.ba.Re, h);
            b && g.data.gclid && Ls("gcl_aw", String(g.data.gclid), 6, b);
            var k;
            (k = g.stopImmediatePropagation) == null || k.call(g);
            Tt(c, "message", d);
          }
        };
        if (St(c, "message", d)) {
          tk(qk.ba.Xl, !0);
          var e = n(wH),
            f = e.next();
          try {
            for (; !f.done; f = e.next())
              c.opener.postMessage({ action: "gcl_setup" }, f.value);
          } finally {
            z(e, f);
          }
          R(174);
          return qk.ba.Re;
        }
        R(175);
      }
    }
  }
  function HH(a, b) {
    b = b === void 0 ? !0 : b;
    var c = yb(vb.GTAG_EVENT_FEATURE_CHANNEL || []);
    if (c && (X(a, K.D.Nf, c), b)) {
      var d = zC.H.slice();
      vb.GTAG_EVENT_FEATURE_CHANNEL = d;
    }
  }
  function MH() {
    var a = A.__uspapi;
    if (Gb(a)) {
      var b = "";
      try {
        a("getUSPData", 1, function (c, d) {
          if (d && c) {
            var e = c.uspString;
            e && RegExp("^[\\da-zA-Z-]{1,20}$").test(e) && (b = e);
          }
        });
      } catch (c) {}
      return b;
    }
  }
  function PH() {
    return Math.floor(Math.random() * 20);
  }
  var QH = [K.D.ri].map(function (a) {
    return a.slice(2);
  });
  function TH(a) {}
  TH.U = "internal.addAdsClickIds";
  function UH(a, b) {
    var c = this;
  }
  UH.publicName = "addConsentListener";
  var VH = !1;
  function WH(a) {
    for (var b = 0; b < a.length; ++b)
      if (VH)
        try {
          a[b]();
        } catch (c) {
          R(77);
        }
      else a[b]();
  }
  function XH(a, b, c) {
    var d = this,
      e;
    return e;
  }
  XH.U = "internal.addDataLayerEventListener";
  function YH(a, b, c) {}
  YH.publicName = "addDocumentEventListener";
  function ZH(a, b, c, d) {}
  ZH.publicName = "addElementEventListener";
  function $H(a) {
    return a.V.hb();
  }
  function aI(a) {}
  aI.publicName = "addEventCallback";
  function lI(a) {
    if (a.form) {
      var b;
      return ((b = a.form) == null ? 0 : b.tagName)
        ? a.form
        : C.getElementById(a.form);
    }
    return qd(a, ["form"], 100);
  }
  function oI(a) {}
  oI.U = "internal.addFormAbandonmentListener";
  function pI(a, b, c, d) {}
  pI.U = "internal.addFormData";
  function uI(a) {}
  uI.U = "internal.addGaSendListener";
  function CI(a) {
    var b = ho("zones");
    return b
      ? b.getIsAllowedFn(nm(), a)
      : function () {
          return !0;
        };
  }
  function DI() {
    var a = ho("zones");
    a && a.unregisterChild(nm());
  }
  function EI() {
    EB(mm(), function (a) {
      var b = a.originalEventData["gtm.uniqueEventId"],
        c = ho("zones");
      return c ? c.isActive(nm(), b) : !0;
    });
    BB(mm(), function (a) {
      var b, c;
      b = a.entityId;
      c = a.securityGroups;
      return CI(Number(a.originalEventData["gtm.uniqueEventId"]))(b, c);
    });
  }
  var FI = function (a, b) {
    this.tagId = a;
    this.canonicalId = b;
  };
  function GI(a, b) {
    var c = this;
    return a;
  }
  GI.U = "internal.loadGoogleTag";
  function HI(a) {
    return new Nd("", function (b) {
      var c = this.evaluate(b);
      if (c instanceof Nd)
        return new Nd("", function () {
          var d = Qa.apply(0, arguments),
            e = this,
            f = ma(Object, "assign").call(Object, {}, Eb($H(this), null), {
              eventId: a.eventId,
              priorityId: a.priorityId,
              originalEventData: a.originalEventData,
              originalSendTo: void 0,
            }),
            g = d.map(function (k) {
              return e.evaluate(k);
            }),
            h = this.V.wb();
          h.de(f);
          return c.Ic.apply(c, [h].concat(w(g)));
        });
    });
  }
  function II(a, b, c) {
    var d = this;
  }
  II.U = "internal.addGoogleTagRestriction";
  function PI(a, b) {}
  PI.U = "internal.addHistoryChangeListener";
  function QI(a, b, c) {}
  QI.publicName = "addWindowEventListener";
  function RI(a, b) {
    return !0;
  }
  RI.publicName = "aliasInWindow";
  function SI(a, b, c) {}
  SI.U = "internal.appendRemoteConfigParameter";
  function TI(a) {
    var b;
    return b;
  }
  TI.publicName = "callInWindow";
  function UI(a) {}
  UI.publicName = "callLater";
  function VI(a) {}
  VI.U = "callOnDomReady";
  function WI(a) {}
  WI.U = "callOnWindowLoad";
  function ZI(a, b) {
    return c;
  }
  ZI.U = "internal.claimDestination";
  function rJ(a) {
    var b = Wb(),
      c;
    return c;
  }
  rJ.U = "internal.compileFormMetadata";
  function sJ(a, b) {
    var c;
    return c;
  }
  sJ.U = "internal.computeGtmParameter";
  function tJ(a, b) {
    var c = this;
  }
  tJ.U = "internal.consentScheduleFirstTry";
  function uJ(a, b) {
    var c = this;
  }
  uJ.U = "internal.consentScheduleRetry";
  var vJ = { setItem: function (a, b) {}, U: "internal.containerStorage" };
  function wJ(a) {
    var b;
    return b;
  }
  wJ.U = "internal.copyFromCrossContainerData";
  function xJ(a, b) {
    var c;
    if (!ah(a) || (!fh(b) && b !== null && !Wg(b)))
      throw N(this.getName(), ["string", "number|undefined"], arguments);
    O(this, "read_data_layer", a);
    b = b || 2;
    if (b === 3 && P(660)) {
      var d = [A, C],
        e,
        f;
      if ((e = $H(this).M) == null) f = void 0;
      else
        a: {
          var g = a;
          if (!fA(g)) {
            var h = g.split("."),
              k = h[0],
              m = n(Rz(e, 4)),
              p = m.next();
            try {
              for (; !p.done; p = m.next()) {
                var q = p.value;
                if (
                  Object.prototype.hasOwnProperty.call(q, k) &&
                  q[k] !== void 0
                ) {
                  b: {
                    var r = q[k],
                      t = h.slice(1);
                    if (d.indexOf(r) === -1) {
                      var u = r,
                        v = n(t),
                        x = v.next();
                      try {
                        for (; !x.done; x = v.next()) {
                          if (u == null) {
                            f = void 0;
                            break b;
                          }
                          u = u[x.value];
                          if (d.indexOf(u) !== -1) {
                            f = void 0;
                            break b;
                          }
                        }
                      } finally {
                        z(v, x);
                      }
                      f = u;
                    } else f = void 0;
                  }
                  break a;
                }
              }
            } finally {
              z(m, p);
            }
          }
          f = void 0;
        }
      c = f;
    } else {
      var y;
      b !== 2 ? (y = oA(a, 1)) : (y = kA(lA, a, [A, C]));
      c = y;
    }
    var B = Vd(c, this.V, ph($H(this).Qb()) ? 2 : 1);
    B === void 0 && c !== void 0 && R(45);
    return B;
  }
  xJ.publicName = "copyFromDataLayer";
  function yJ(a) {
    var b = void 0;
    return b;
  }
  yJ.U = "internal.copyFromDataLayerCache";
  function zJ(a) {
    var b;
    return b;
  }
  zJ.publicName = "copyFromWindow";
  function AJ(a) {
    var b = void 0;
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    O(this, "unsafe_access_globals", a);
    var c = a.split(".");
    b = A[c.shift()];
    for (var d = 0; d < c.length; d++) b = b && b[c[d]];
    return Vd(b, this.V, 1);
  }
  AJ.U = "internal.copyKeyFromWindow";
  var BJ = function (a) {
    return a === 1 && Xm.H[a] === 1 && !hp(K.D.ia);
  };
  var CJ = function () {
      return "0";
    },
    DJ = function (a) {
      return typeof a !== "string"
        ? ""
        : Gj(a, ["gclid", "dclid", "wbraid", "_gl"], "0");
    };
  var EJ = {},
    FJ = {},
    GJ = {},
    HJ = {},
    IJ = {},
    JJ = {},
    KJ = {},
    LJ = {},
    MJ = {},
    NJ = {},
    OJ = {},
    PJ = {},
    QJ = {},
    RJ = {},
    SJ = {},
    TJ = {},
    UJ = {},
    VJ = {},
    WJ = {},
    XJ = {},
    YJ = {},
    ZJ = {},
    $J = {},
    aK = {},
    bK = {},
    cK =
      ((bK[K.D.nb] = ((EJ[2] = [BJ]), EJ)),
      (bK[K.D.Rf] = ((FJ[2] = [BJ]), FJ)),
      (bK[K.D.Ci] = ((GJ[2] = [BJ]), GJ)),
      (bK[K.D.tl] = ((HJ[2] = [BJ]), HJ)),
      (bK[K.D.wl] = ((IJ[2] = [BJ]), IJ)),
      (bK[K.D.xl] = ((JJ[2] = [BJ]), JJ)),
      (bK[K.D.yl] = ((KJ[2] = [BJ]), KJ)),
      (bK[K.D.zl] = ((LJ[2] = [BJ]), LJ)),
      (bK[K.D.sh] = ((MJ[2] = [BJ]), MJ)),
      (bK[K.D.Sf] = ((NJ[2] = [BJ]), NJ)),
      (bK[K.D.Tf] = ((OJ[2] = [BJ]), OJ)),
      (bK[K.D.Uf] = ((PJ[2] = [BJ]), PJ)),
      (bK[K.D.Vf] = ((QJ[2] = [BJ]), QJ)),
      (bK[K.D.Wf] = ((RJ[2] = [BJ]), RJ)),
      (bK[K.D.Xf] = ((SJ[2] = [BJ]), SJ)),
      (bK[K.D.Yf] = ((TJ[2] = [BJ]), TJ)),
      (bK[K.D.Zf] = ((UJ[2] = [BJ]), UJ)),
      (bK[K.D.Xa] = ((VJ[1] = [BJ]), VJ)),
      (bK[K.D.xd] = ((WJ[1] = [BJ]), WJ)),
      (bK[K.D.Bd] = ((XJ[1] = [BJ]), XJ)),
      (bK[K.D.se] = ((YJ[1] = [BJ]), YJ)),
      (bK[K.D.Sc] = ((ZJ[1] = [BJ]), ZJ)),
      (bK[K.D.ya] = (($J[1] = [BJ]), $J)),
      (bK[K.D.Ea] = ((aK[1] = [BJ]), aK)),
      bK),
    dK = {},
    eK =
      ((dK[K.D.Xa] = CJ),
      (dK[K.D.xd] = CJ),
      (dK[K.D.Bd] = CJ),
      (dK[K.D.se] = CJ),
      (dK[K.D.Sc] = function (a) {
        if (!Db(a)) return {};
        var b = Eb(a, null);
        delete b.match_id;
        return b;
      }),
      (dK[K.D.ya] = DJ),
      (dK[K.D.Ea] = DJ),
      dK),
    fK = {},
    gK = {},
    hK = ((gK[L.J.Ua] = ((fK[2] = [BJ]), fK)), gK),
    iK = {};
  var jK = function (a, b, c, d) {
    this.H = a;
    this.P = b;
    this.T = c;
    this.Z = d;
  };
  jK.prototype.getValue = function (a) {
    a = a === void 0 ? 0 : a;
    if (
      !this.P.some(function (b) {
        return b(a);
      })
    )
      return this.T.some(function (b) {
        return b(a);
      })
        ? this.Z(this.H)
        : this.H;
  };
  jK.prototype.K = function () {
    return Ab(this.H) === "array" || Db(this.H) ? Eb(this.H, null) : this.H;
  };
  var kK = function () {},
    lK = function (a, b) {
      this.conditions = a;
      this.H = b;
    },
    mK = function (a, b, c) {
      var d,
        e = ((d = a.conditions[b]) == null ? void 0 : d[2]) || [],
        f,
        g = ((f = a.conditions[b]) == null ? void 0 : f[1]) || [];
      return new jK(c, e, g, a.H[b] || kK);
    },
    nK,
    oK;
  var pK = function (a) {
      a.H = !0;
      if (If(52)) {
        var b;
        a.settings = (b = data.productSettings) != null ? b : {};
        data.productSettings = void 0;
      }
    },
    rK = function (a) {
      var b = qK;
      b.H || pK(b);
      return b.settings[a];
    },
    qK = new (function () {
      this.settings = {};
      this.H = !1;
    })();
  var sK = function (a, b, c) {
      this.eventName = b;
      this.M = c;
      this.H = {};
      this.isAborted = !1;
      this.target = a;
      this.metadata = {};
      var d = c.eventMetadata || {},
        e = n(Object.keys(d)),
        f = e.next();
      try {
        for (; !f.done; f = e.next()) {
          var g = f.value;
          T(this, g, d[g]);
        }
      } finally {
        z(e, f);
      }
    },
    Qi = function (a, b) {
      var c, d;
      return (c = a.H[b]) == null
        ? void 0
        : (d = c.getValue) == null
        ? void 0
        : d.call(c, S(a, L.J.og));
    },
    X = function (a, b, c) {
      var d = a.H,
        e;
      c === void 0
        ? (e = void 0)
        : (nK != null || (nK = new lK(cK, eK)), (e = mK(nK, b, c)));
      d[b] = e;
    };
  sK.prototype.mergeHitDataForKey = function (a, b) {
    var c, d, e;
    c =
      (d = this.H[a]) == null ? void 0 : (e = d.K) == null ? void 0 : e.call(d);
    if (!c) return X(this, a, b), !0;
    if (!Db(c)) return !1;
    X(this, a, ma(Object, "assign").call(Object, c, b));
    return !0;
  };
  var tK = function (a, b) {
    b = b === void 0 ? {} : b;
    var c = n(Object.keys(a.H)),
      d = c.next();
    try {
      for (; !d.done; d = c.next()) {
        var e = d.value,
          f = void 0,
          g = void 0,
          h = void 0;
        b[e] =
          (f = a.H[e]) == null
            ? void 0
            : (h = (g = f).K) == null
            ? void 0
            : h.call(g);
      }
    } finally {
      z(c, d);
    }
    return b;
  };
  sK.prototype.copyToHitData = function (a, b, c) {
    var d = Q(this.M, a);
    d === void 0 && (d = b);
    if (Hb(d) && c !== void 0)
      try {
        d = c(d);
      } catch (e) {}
    d !== void 0 && X(this, a, d);
  };
  var S = function (a, b) {
      var c = a.metadata[b];
      if (b === L.J.og) {
        var d;
        return c == null ? void 0 : (d = c.K) == null ? void 0 : d.call(c);
      }
      var e;
      return c == null
        ? void 0
        : (e = c.getValue) == null
        ? void 0
        : e.call(c, S(a, L.J.og));
    },
    T = function (a, b, c) {
      var d = a.metadata,
        e;
      c === void 0
        ? (e = c)
        : (oK != null || (oK = new lK(hK, iK)), (e = mK(oK, b, c)));
      d[b] = e;
    },
    uK = function (a, b) {
      b = b === void 0 ? {} : b;
      var c = n(Object.keys(a.metadata)),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = d.value,
            f = void 0,
            g = void 0,
            h = void 0;
          b[e] =
            (f = a.metadata[e]) == null
              ? void 0
              : (h = (g = f).K) == null
              ? void 0
              : h.call(g);
        }
      } finally {
        z(c, d);
      }
      return b;
    },
    my = function (a, b, c) {
      var d = rK(a.target.destinationId);
      return d && d[b] !== void 0 ? d[b] : c;
    };
  sK.prototype.copy = function (a) {
    var b = new sK(
        (a == null ? void 0 : a.target) || this.target,
        (a == null ? void 0 : a.eventName) || this.eventName,
        (a == null ? void 0 : a.M) || this.M
      ),
      c = tK(this),
      d = n(Object.keys(c)),
      e = d.next();
    try {
      for (; !e.done; e = d.next()) {
        var f = e.value;
        X(b, f, c[f]);
      }
    } finally {
      z(d, e);
    }
    var g = uK(this),
      h = n(Object.keys(g)),
      k = h.next();
    try {
      for (; !k.done; k = h.next()) {
        var m = k.value;
        T(b, m, g[m]);
      }
    } finally {
      z(h, k);
    }
    b.isAborted = this.isAborted;
    return b;
  };
  var vK = function (a) {
    var b = a.M,
      c = b.eventId,
      d = b.priorityId;
    return d ? c + "_" + d : String(c);
  };
  sK.prototype.accept = function () {
    var a = vk(qk.ba.Li, {}),
      b = vK(this),
      c = this.target.destinationId;
    a[b] || (a[b] = {});
    a[b][c] = mm();
    yk(qk.ba.Li);
  };
  sK.prototype.canBeAccepted = function (a) {
    var b = uk(qk.ba.Li);
    if (!b) return !0;
    var c = b[vK(this)];
    if (!c) return !0;
    var d = c[a != null ? a : this.target.destinationId];
    return d === void 0 || d === mm();
  };
  function wK(a) {
    return {
      getDestinationId: function () {
        return a.target.destinationId;
      },
      getEventName: function () {
        return a.eventName;
      },
      setEventName: function (b) {
        a.eventName = b;
      },
      getHitData: function (b) {
        return Qi(a, b);
      },
      setHitData: function (b, c) {
        X(a, b, c);
      },
      setHitDataIfNotDefined: function (b, c) {
        Qi(a, b) === void 0 && X(a, b, c);
      },
      copyToHitData: function (b, c) {
        a.copyToHitData(b, c);
      },
      getMetadata: function (b) {
        return S(a, b);
      },
      setMetadata: function (b, c) {
        T(a, b, c);
      },
      isAborted: function () {
        return a.isAborted;
      },
      abort: function () {
        a.isAborted = !0;
      },
      getFromEventContext: function (b) {
        return Q(a.M, b);
      },
      zb: function () {
        return a;
      },
      getHitKeys: function () {
        return Object.keys(a.H);
      },
      getMergedValues: function (b) {
        return a.M.getMergedValues(b, 3);
      },
      mergeHitDataForKey: function (b, c) {
        return Db(c) ? a.mergeHitDataForKey(b, c) : !1;
      },
      accept: function () {
        a.accept();
      },
      canBeAccepted: function (b) {
        return a.canBeAccepted(b);
      },
    };
  }
  function xK(a, b) {
    var c;
    return c;
  }
  xK.U = "internal.copyPreHit";
  function yK(a, b) {
    var c = null;
    return Vd(c, this.V, 2);
  }
  yK.publicName = "createArgumentsQueue";
  function zK(a) {
    return Vd(
      function (c) {
        var d = jB();
        if (typeof c === "function")
          d(function () {
            c(function (f, g, h) {
              var k = jB(),
                m = k && k.getByName && k.getByName(f);
              return new A.gaplugins.Linker(m).decorate(g, h);
            });
          });
        else if (Array.isArray(c)) {
          var e = String(c[0]).split(".");
          b[e.length === 1 ? e[0] : e[1]] && d.apply(null, c);
        } else if (c === "isLoaded") return !!d.loaded;
      },
      this.V,
      1
    );
  }
  zK.U = "internal.createGaCommandQueue";
  function AK(a) {
    return Vd(
      function () {
        if (!Gb(e.push))
          throw Error("Object at " + a + " in window is not an array.");
        e.push.apply(e, Array.prototype.slice.call(arguments, 0));
      },
      this.V,
      ph($H(this).Qb()) ? 2 : 1
    );
  }
  AK.publicName = "createQueue";
  function BK(a, b) {
    var c = null;
    if (!ah(a) || !bh(b))
      throw N(this.getName(), ["string", "string|undefined"], arguments);
    try {
      var d = (b || "")
        .split("")
        .filter(function (e) {
          return "ig".indexOf(e) >= 0;
        })
        .join("");
      c = new Sd(new RegExp(a, d));
    } catch (e) {}
    return c;
  }
  BK.U = "internal.createRegex";
  function CK(a) {}
  CK.U = "internal.declareConsentState";
  function DK(a) {
    var b = "";
    return b;
  }
  DK.U = "internal.decodeUrlHtmlEntities";
  function EK(a, b, c) {
    var d;
    return d;
  }
  EK.U = "internal.decorateUrlWithGaCookies";
  function FK() {}
  FK.U = "internal.deferCustomEvents";
  function GK(a, b) {
    try {
      return a.closest(b);
    } catch (c) {
      return null;
    }
  }
  function nL(a) {
    var b;
    return b;
  }
  nL.U = "internal.detectUserProvidedData";
  var sL = function () {
    this.H = new Set();
    this.K = this.ja = this.Z = this.da = this.P = this.T = !1;
  };
  sL.prototype.subscribe = function (a) {
    var b = this;
    tL(this, a);
    this.H.add(a);
    return function () {
      b.H.delete(a);
    };
  };
  var tL = function (a, b) {
      var c = A;
      b.onFocus &&
        !a.T &&
        ((a.T = !0),
        id(c, "focus", function () {
          var d = [].concat(w(a.H)),
            e = n(d),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) {
              var g = void 0,
                h = void 0;
              (h = (g = f.value).onFocus) == null || h.call(g);
            }
          } finally {
            z(e, f);
          }
        }));
      b.onBlur &&
        !a.P &&
        ((a.P = !0),
        id(c, "blur", function () {
          var d = [].concat(w(a.H)),
            e = n(d),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) {
              var g = void 0,
                h = void 0;
              (h = (g = f.value).onBlur) == null || h.call(g);
            }
          } finally {
            z(e, f);
          }
        }));
      (!b.bn && !b.Wh) ||
        a.da ||
        ((a.da = !0),
        id(c, "pageshow", function (d) {
          var e = !(!d || !d.persisted),
            f = [].concat(w(a.H)),
            g = n(f),
            h = g.next();
          try {
            for (; !h.done; h = g.next()) {
              var k = h.value,
                m = void 0,
                p = void 0;
              (p = (m = k).bn) == null || p.call(m, e);
              if (e) {
                var q = void 0,
                  r = void 0;
                (r = (q = k).Wh) == null || r.call(q);
              }
            }
          } finally {
            z(g, h);
          }
        }));
      (!b.Oj && !b.Fr) ||
        a.Z ||
        ((a.Z = !0),
        id(c, "pagehide", function (d) {
          var e = !(!d || !d.persisted),
            f = [].concat(w(a.H)),
            g = n(f),
            h = g.next();
          try {
            for (; !h.done; h = g.next()) {
              var k = h.value,
                m = void 0,
                p = void 0;
              (p = (m = k).Oj) == null || p.call(m, e);
              if (e) {
                var q = void 0,
                  r = void 0;
                (r = (q = k).Fr) == null || r.call(q);
              }
            }
          } finally {
            z(g, h);
          }
        }));
      b.hn &&
        !a.ja &&
        ((a.ja = !0),
        id(C, "visibilitychange", function () {
          var d = !C.hidden,
            e = [].concat(w(a.H)),
            f = n(e),
            g = f.next();
          try {
            for (; !g.done; g = f.next()) {
              var h = void 0,
                k = void 0;
              (k = (h = g.value).hn) == null || k.call(h, d);
            }
          } finally {
            z(f, g);
          }
        }));
      b.Xm &&
        !a.K &&
        ((a.K = !0),
        id(c, "beforeunload", function () {
          var d = [].concat(w(a.H)),
            e = n(d),
            f = e.next();
          try {
            for (; !f.done; f = e.next()) {
              var g = void 0,
                h = void 0;
              (h = (g = f.value).Xm) == null || h.call(g);
            }
          } finally {
            z(e, f);
          }
        }));
    },
    uL = new sL();
  function vL(a, b) {
    var c = this;
    return d;
  }
  vL.U = "internal.enableAutoEventOnBfcacheRestore";
  function yL(a, b) {
    return f;
  }
  yL.U = "internal.enableAutoEventOnClick";
  function FL(a, b) {
    return p;
  }
  FL.U = "internal.enableAutoEventOnElementVisibility";
  function GL() {}
  GL.U = "internal.enableAutoEventOnError";
  function LL(a, b) {
    var c = this;
    return d;
  }
  LL.U = "internal.enableAutoEventOnFormInteraction";
  function QL(a, b) {
    var c = this;
    return f;
  }
  QL.U = "internal.enableAutoEventOnFormSubmit";
  function VL() {
    var a = this;
  }
  VL.U = "internal.enableAutoEventOnGaSend";
  function bM(a, b) {
    var c = this;
    return f;
  }
  bM.U = "internal.enableAutoEventOnHistoryChange";
  var cM = ["http://", "https://", "javascript:", "file://"];
  function gM(a, b) {
    var c = this;
    return h;
  }
  gM.U = "internal.enableAutoEventOnLinkClick";
  function rM(a, b) {
    var c = this;
    return g;
  }
  rM.U = "internal.enableAutoEventOnScroll";
  function sM(a) {
    return function () {
      if (a.limit && a.Nj >= a.limit) a.Qh && A.clearInterval(a.Qh);
      else {
        a.Nj++;
        var b = Wb();
        XE({
          event: a.eventName,
          "gtm.timerId": a.Qh,
          "gtm.timerEventNumber": a.Nj,
          "gtm.timerInterval": a.interval,
          "gtm.timerLimit": a.limit,
          "gtm.timerStartTime": a.yn,
          "gtm.timerCurrentTime": b,
          "gtm.timerElapsedTime": b - a.yn,
          "gtm.triggers": a.Gs,
        });
      }
    };
  }
  function tM(a, b) {
    return f;
  }
  tM.U = "internal.enableAutoEventOnTimer";
  var Jc = za(["data-gtm-yt-inspected-"]),
    vM = ["www.youtube.com", "www.youtube-nocookie.com"],
    wM;
  function GM(a, b) {
    var c = this;
    return e;
  }
  GM.U = "internal.enableAutoEventOnYouTubeActivity";
  function HM(a, b) {
    if (!ah(a) || !Vg(b))
      throw N(this.getName(), ["string", "Object|undefined"], arguments);
    var c = b ? D(b) : {};
    c.regexCache = $i(20, function () {
      return new Map();
    });
    return uh(a, c);
  }
  HM.U = "internal.evaluateBooleanExpression";
  function IM(a) {
    var b = !1;
    return b;
  }
  IM.U = "internal.evaluateMatchingRules";
  function MM(a, b) {
    var c = Array.isArray(a) ? a : [a],
      d = Lb(b),
      e = n(c),
      f = e.next();
    try {
      for (; !f.done; f = e.next()) {
        var g = f.value;
        if (g && typeof g === "object") {
          g.testReason || (g.testReason = []);
          var h = n(d),
            k = h.next();
          try {
            for (; !k.done; k = h.next()) {
              var m = k.value;
              g.testReason.indexOf(m) === -1 && g.testReason.push(m);
            }
          } finally {
            z(h, k);
          }
        }
      }
    } finally {
      z(e, f);
    }
  }
  function NM(a, b) {
    if (a) {
      var c = a._tag_metadata;
      if (c) {
        var d = n(Object.keys(c)),
          e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            var f = c[e.value];
            f && MM(f, b);
          }
        } finally {
          z(d, e);
        }
      }
    }
  }
  function OM(a, b) {
    if (a && typeof a === "object" && b) {
      var c = a._tag_metadata,
        d = n(Object.keys(b)),
        e = d.next();
      try {
        for (; !e.done; e = d.next()) {
          var f = e.value,
            g = b[f];
          if (g)
            if (f === "address" || f === "home_address") {
              var h = Lb(f === "address" ? a.address : a.home_address),
                k = n(Object.keys(g)),
                m = k.next();
              try {
                for (; !m.done; m = k.next()) {
                  var p = m.value,
                    q = h[Number(p)];
                  q && NM(q, g[Number(p)]);
                }
              } finally {
                z(k, m);
              }
            } else if (c) {
              var r = c[f];
              if (r) {
                var t = n(Object.keys(g)),
                  u = t.next();
                try {
                  for (; !u.done; u = t.next()) {
                    var v = u.value;
                    if (Array.isArray(r) || Number(v) === 0) {
                      var x = Array.isArray(r) ? r[Number(v)] : r;
                      x && MM(x, g[Number(v)]);
                    }
                  }
                } finally {
                  z(t, u);
                }
              }
            }
        }
      } finally {
        z(d, e);
      }
    }
  }
  var PM = {},
    QM = {},
    RM = {},
    SM = {},
    TM = {},
    UM =
      ((TM[28] = ((PM[1] = 1), (PM[2] = 3), (PM[3] = 3), (PM[4] = 3), PM)),
      (TM[29] = ((QM[1] = 1), (QM[2] = 3), (QM[3] = 3), (QM[4] = 3), QM)),
      (TM[31] = ((RM[1] = 1), (RM[2] = 3), (RM[3] = 3), (RM[4] = 3), RM)),
      (TM[32] = ((SM[1] = 1), (SM[2] = 2), (SM[3] = 2), (SM[4] = 2), SM)),
      TM),
    VM = {},
    WM = ((VM[1] = 1), (VM[2] = 3), (VM[3] = 2), (VM[4] = 2), VM);
  function XM(a, b) {
    if (a && typeof a === "object") {
      var c = a._tag_metadata;
      if (c) {
        var d;
        if (P(586)) {
          var e = {};
          d = ma(Object, "assign").call(Object, {}, UM, ((e[31] = WM), e));
        } else d = UM;
        var f = d,
          g = n(Object.keys(c)),
          h = g.next();
        try {
          for (; !h.done; h = g.next()) {
            var k = void 0,
              m = a,
              p = h.value,
              q = b,
              r = m._tag_metadata;
            if (r) {
              var t = r[p];
              if (t) {
                for (
                  var u = Lb(t), v = m[p], x = Lb(v), y = [], B = [], E = 0;
                  E < u.length;
                  E++
                ) {
                  k = u[E];
                  var F;
                  a: {
                    var G = k,
                      I = q;
                    if (G && G.testReason) {
                      var J = n(G.testReason),
                        M = J.next();
                      try {
                        for (; !M.done; M = J.next()) {
                          var U = f[M.value];
                          if ((U ? U[I] || 1 : 1) === 3) {
                            F = !0;
                            break a;
                          }
                        }
                      } finally {
                        z(J, M);
                      }
                    }
                    F = !1;
                  }
                  if (!F) {
                    var W = void 0,
                      fa = k,
                      da = q;
                    if (fa && fa.testReason) {
                      var ea = [],
                        ja = n(fa.testReason),
                        va = ja.next();
                      try {
                        for (; !va.done; va = ja.next()) {
                          W = va.value;
                          var Ga = f[W];
                          (Ga ? Ga[da] || 1 : 1) === 1 && ea.push(W);
                        }
                      } finally {
                        z(ja, va);
                      }
                      ea.length ? (fa.testReason = ea) : delete fa.testReason;
                    }
                    y.push(k);
                    E < x.length && B.push(x[E]);
                  }
                }
                if (y.length !== u.length) {
                  for (var wa = u.length; wa < x.length; wa++) B.push(x[wa]);
                  B.length
                    ? ((m[p] = Array.isArray(v) ? B : B[0]),
                      (r[p] = Array.isArray(t) ? y : y[0]))
                    : (delete m[p], delete r[p]);
                }
              }
            }
          }
        } finally {
          z(g, h);
        }
        Object.keys(c).length || delete a._tag_metadata;
      }
    }
  }
  function YM(a) {
    var b = n(Object.keys(a)),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) if (c.value !== "_tag_metadata") return !1;
    } finally {
      z(b, c);
    }
    return !0;
  }
  function ZM(a, b, c) {
    if (!a || typeof a !== "object") return a;
    var d = JSON.parse(JSON.stringify(a));
    b && OM(d, b);
    XM(d, c);
    var e = Lb(d.address).filter(function (m) {
        return !!m;
      }),
      f = [],
      g = n(e),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = h.value;
        XM(k, c);
        YM(k) || f.push(k);
      }
    } finally {
      z(g, h);
    }
    f.length !== e.length &&
      (f.length
        ? (d.address = Array.isArray(d.address) ? f : f[0])
        : delete d.address);
    return d;
  }
  function gN() {
    return qu(7) && qu(9) && qu(10);
  }
  var mN = function (a, b) {
      a &&
        (lN("sid", a.targetId, b),
        lN("cc", a.clientCount, b),
        lN("tl", a.totalLifeMs, b),
        lN("hc", a.heartbeatCount, b),
        lN("cl", a.clientLifeMs, b));
    },
    lN = function (a, b, c) {
      b != null && c.push(a + "=" + b);
    },
    nN = function () {
      var a = C.referrer;
      if (a) {
        var b;
        return zj(Fj(a), "host") ===
          ((b = A.location) == null ? void 0 : b.host)
          ? 1
          : 2;
      }
      return 0;
    },
    pN = function () {
      this.ja = oN;
      this.P = 0;
      this.Aa = Nf(57, 5);
      this.T = Nf(58, 50);
      this.da = Nb();
      this.Ia = "https://" + H(21) + "/a?";
    };
  pN.prototype.K = function (a, b, c, d) {
    var e = nN(),
      f,
      g = [];
    f =
      A === A.top && e !== 0 && b
        ? (b == null ? void 0 : b.clientCount) > 1
          ? e === 2
            ? 1
            : 2
          : e === 2
          ? 0
          : 3
        : 4;
    a && lN("si", a.Dg, g);
    lN("m", 0, g);
    lN("iss", f, g);
    lN("if", c, g);
    mN(b, g);
    d && lN("fm", encodeURIComponent(d.substring(0, this.T)), g);
    this.Z(g);
  };
  pN.prototype.H = function (a, b, c, d, e) {
    var f = [];
    lN("m", 1, f);
    lN("s", a, f);
    lN("po", nN(), f);
    b && (lN("st", b.state, f), lN("si", b.Dg, f), lN("sm", b.Pg, f));
    mN(c, f);
    lN("c", d, f);
    e && lN("fm", encodeURIComponent(e.substring(0, this.T)), f);
    this.Z(f);
  };
  pN.prototype.Z = function (a) {
    a = a === void 0 ? [] : a;
    !gl.P ||
      this.P >= this.Aa ||
      (lN("pid", this.da, a),
      lN("bc", ++this.P, a),
      a.unshift("ctid=" + H(5) + "&t=s"),
      this.ja("" + this.Ia + a.join("&")));
  };
  function qN(a) {
    return (a.performance && a.performance.now()) || Date.now();
  }
  var rN = function (a, b) {
    var c = A,
      d = Nf(53, 500),
      e = Nf(54, 5e3),
      f = Nf(8, 20),
      g = Nf(55, 5e3),
      h;
    var k = function (m, p, q) {
      q =
        q === void 0
          ? {
              onInit: function () {},
              dn: function () {},
              Ym: function () {},
              onFailure: function () {},
            }
          : q;
      this.sj = m;
      this.global = p;
      this.K = q;
      this.Z = this.da = this.heartbeatCount = this.Hh = 0;
      this.Pb = !1;
      this.H = {};
      this.id = String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
      this.state = 0;
      this.Dg = qN(this.global);
      this.Pg = qN(this.global);
      this.T = 10;
    };
    k.prototype.init = function () {
      this.P(1);
      this.ja();
    };
    k.prototype.getState = function () {
      return {
        state: this.state,
        Dg: Math.round(qN(this.global) - this.Dg),
        Pg: Math.round(qN(this.global) - this.Pg),
      };
    };
    k.prototype.P = function (m) {
      this.state !== m && ((this.state = m), (this.Pg = qN(this.global)));
    };
    k.prototype.Sd = function () {
      return String(this.Hh++);
    };
    k.prototype.ja = function () {
      var m = this;
      this.heartbeatCount++;
      this.addRequest(
        {
          type: 0,
          clientId: this.id,
          requestId: this.Sd(),
          maxDelay: this.jd(),
        },
        function (p) {
          if (p.type === 0) {
            var q;
            if (((q = p.failure) == null ? void 0 : q.failureType) != null)
              if (
                (p.stats && (m.stats = p.stats), m.Z++, p.isDead || m.Z > f)
              ) {
                var r = p.isDead && p.failure.failureType;
                m.T = r || 10;
                m.P(4);
                m.Fh();
                var t, u;
                (u = (t = m.K).Ym) == null ||
                  u.call(t, { failureType: r || 10, data: p.failure.data });
              } else m.P(3), m.Td();
            else {
              if (m.heartbeatCount > p.stats.heartbeatCount + f) {
                m.heartbeatCount = p.stats.heartbeatCount;
                var v, x;
                (x = (v = m.K).onFailure) == null ||
                  x.call(v, { failureType: 13 });
              }
              m.stats = p.stats;
              var y = m.state;
              m.P(2);
              if (y !== 2)
                if (m.Pb) {
                  var B, E;
                  (E = (B = m.K).dn) == null || E.call(B);
                } else {
                  m.Pb = !0;
                  var F, G;
                  (G = (F = m.K).onInit) == null || G.call(F);
                }
              m.Z = 0;
              m.wj();
              m.Td();
            }
          }
        }
      );
    };
    k.prototype.jd = function () {
      return this.state === 2 ? e : d;
    };
    k.prototype.Td = function () {
      var m = this,
        p = qN(this.global) - this.da;
      this.global.setTimeout(function () {
        m.ja();
      }, Math.max(0, this.jd() - p));
    };
    k.prototype.aq = function (m, p, q) {
      var r = this;
      this.addRequest(
        { type: 1, clientId: this.id, requestId: this.Sd(), command: m },
        function (t) {
          if (t.type === 1)
            if (t.result) p(t.result);
            else {
              var u,
                v,
                x,
                y = {
                  failureType:
                    (x = (u = t.failure) == null ? void 0 : u.failureType) !=
                    null
                      ? x
                      : 12,
                  data: (v = t.failure) == null ? void 0 : v.data,
                },
                B,
                E;
              (E = (B = r.K).onFailure) == null || E.call(B, y);
              q(y);
            }
        }
      );
    };
    k.prototype.addRequest = function (m, p) {
      var q = this;
      if (this.state === 4) (m.failure = { failureType: this.T }), p(m);
      else {
        var r = this.state !== 2 && m.type !== 0,
          t = m.requestId,
          u,
          v = this.global.setTimeout(
            function () {
              var y = q.H[t];
              y && (pk(6), q.Ia(y, 7));
            },
            (u = m.maxDelay) != null ? u : g
          ),
          x = { request: m, tn: p, nn: r, Cr: v };
        this.H[t] = x;
        r || this.sendRequest(x);
      }
    };
    k.prototype.sendRequest = function (m) {
      this.da = qN(this.global);
      m.nn = !1;
      this.sj(m.request);
    };
    k.prototype.wj = function () {
      var m = n(Object.keys(this.H)),
        p = m.next();
      try {
        for (; !p.done; p = m.next()) {
          var q = this.H[p.value];
          q.nn && this.sendRequest(q);
        }
      } finally {
        z(m, p);
      }
    };
    k.prototype.Fh = function () {
      var m = n(Object.keys(this.H)),
        p = m.next();
      try {
        for (; !p.done; p = m.next()) this.Ia(this.H[p.value], this.T);
      } finally {
        z(m, p);
      }
    };
    k.prototype.Ia = function (m, p) {
      this.Aa(m);
      var q = m.request;
      q.failure = { failureType: p };
      m.tn(q);
    };
    k.prototype.Aa = function (m) {
      delete this.H[m.request.requestId];
      this.global.clearTimeout(m.Cr);
    };
    k.prototype.Tq = function (m) {
      this.da = qN(this.global);
      var p = this.H[m.requestId];
      if (p) this.Aa(p), p.tn(m);
      else {
        var q, r;
        (r = (q = this.K).onFailure) == null || r.call(q, { failureType: 14 });
      }
    };
    h = new k(a, c, b);
    return h;
  };
  var sN = function () {
      return $i(22, function () {
        return new pN();
      });
    },
    oN = function (a) {
      $m(cn(3), function () {
        hd(a);
      });
    },
    tN = function (a) {
      var b = A.location.origin;
      if (!b) return null;
      Lj() && !a && (a = "" + b + Mj() + "/_/service_worker");
      var c = a,
        d,
        e = Lf(11);
      e = Lf(10);
      d = e;
      c
        ? (c.charAt(c.length - 1) !== "/" && (c += "/"), (a = c + d))
        : (a =
            "https://www.googletagmanager.com/static/service_worker/" +
            d +
            "/");
      var f;
      try {
        f = new URL(a);
      } catch (g) {
        return null;
      }
      return f.protocol !== "https:" ? null : f;
    },
    uN = function (a) {
      var b = uk(qk.ba.Dh);
      return b && b[a];
    },
    vN = function (a) {
      var b = this;
      this.K = sN();
      this.Z = this.T = !1;
      this.da = null;
      this.initTime = Math.round(Wb());
      this.H = 15;
      this.P = this.wq(a);
      A.setTimeout(function () {
        b.initialize();
      }, 1e3);
      kd(function () {
        b.jr(a);
      });
    };
  l = vN.prototype;
  l.delegate = function (a, b, c) {
    this.getState() !== 2
      ? (this.K.H(
          this.H,
          {
            state: this.getState(),
            Dg: this.initTime,
            Pg: Math.round(Wb()) - this.initTime,
          },
          void 0,
          a.commandType
        ),
        c({ failureType: this.H }))
      : this.P.aq(a, b, c);
  };
  l.getState = function () {
    return this.P.getState().state;
  };
  l.jr = function (a) {
    var b = A.location.origin,
      c = this,
      d = gd();
    try {
      var e = d.contentDocument.createElement("iframe"),
        f = a.pathname,
        g = f[f.length - 1] === "/" ? a.toString() : a.toString() + "/",
        h = { origin: b };
      if (a.origin !== "https://www.googletagmanager.com") {
        h["1p"] = 1;
        var k = f.substring(0, f.indexOf("/_/service_worker"));
        k && (h.path = k);
      }
      gd(g + "sw_iframe.html?" + Vi(h), void 0, void 0, void 0, e);
      var m = function () {
        d.contentDocument.body.appendChild(e);
        e.addEventListener("load", function () {
          c.da = e.contentWindow;
          d.contentWindow.addEventListener("message", function (p) {
            p.origin === a.origin && c.P.Tq(p.data);
          });
          c.initialize();
        });
      };
      d.contentDocument.readyState === "complete"
        ? m()
        : d.contentWindow.addEventListener("load", function () {
            m();
          });
    } catch (p) {
      d.parentElement.removeChild(d),
        (this.H = 11),
        this.K.K(void 0, void 0, this.H, p.toString());
    }
  };
  l.wq = function (a) {
    var b = this,
      c = rN(
        function (d) {
          var e;
          (e = b.da) == null || e.postMessage(d, a.origin);
        },
        {
          onInit: function () {
            b.T = !0;
            b.K.K(c.getState(), c.stats);
          },
          dn: function () {},
          Ym: function (d) {
            b.T
              ? ((b.H = (d == null ? void 0 : d.failureType) || 10),
                b.K.H(
                  b.H,
                  c.getState(),
                  c.stats,
                  void 0,
                  d == null ? void 0 : d.data
                ))
              : ((b.H = (d == null ? void 0 : d.failureType) || 4),
                b.K.K(c.getState(), c.stats, b.H, d == null ? void 0 : d.data));
          },
          onFailure: function (d) {
            b.H = d.failureType;
            b.K.H(b.H, c.getState(), c.stats, d.command, d.data);
          },
        }
      );
    return c;
  };
  l.initialize = function () {
    this.Z || this.P.init();
    this.Z = !0;
  };
  var wN = function (a, b, c, d) {
    var e;
    if ((e = uN(a)) == null || !e.delegate) {
      var f = Rc() ? 16 : 6;
      sN().H(f, void 0, void 0, b.commandType);
      d({ failureType: f });
      return;
    }
    uN(a).delegate(b, c, d);
  };
  function xN(a, b, c, d) {
    var e = tN(a);
    if (e === null) {
      d("_is_sw=f" + (Rc() ? 16 : 6) + "te");
      return;
    }
    var f = b ? 1 : 0,
      g = Math.round(Wb()),
      h,
      k = (h = uN(e.origin)) == null ? void 0 : h.initTime,
      m = k ? g - k : void 0,
      p = {
        commandType: 0,
        params: {
          url: a,
          method: f,
          templates: c,
          body: b || "",
          processResponse: !0,
          sinceInit: m,
          attributionReporting: !0,
          referer: A.location.href,
          strict: !0,
          allowObfuscation: P(634),
        },
      };
    wN(
      e.origin,
      p,
      function () {},
      function (q) {
        var r = "_is_sw=f" + q.failureType,
          t,
          u = (t = uN(e.origin)) == null ? void 0 : t.getState();
        u !== void 0 && (r += "s" + u);
        d(m ? r + ("t" + m) : r + "te");
      }
    );
  }
  function yN(a) {
    if (If(47) && my(a, "ccd_add_1p_data", !1) && Lj()) {
      var b = a.M,
        c;
      if ((c = Rc()))
        a: {
          try {
            Ix("internal_sw_allowed");
          } catch (m) {
            c = !1;
            break a;
          }
          c = !0;
        }
      if (c) {
        var d = Tj(b),
          e = Lj() ? Mj() : void 0,
          f;
        f = e ? { path: e, Hm: "full" } : d ? { path: d, Hm: "lite" } : void 0;
        if (f) {
          var g = f.Hm,
            h = new URL(f.path, A.location.origin);
          if (h.origin === A.location.origin && Rx(g) === void 0) {
            var k = vk(qk.ba.Dh, {});
            k[g] || (k[g] = new Px(h));
          }
        }
      }
    }
  }
  function BN(a) {
    T(a, L.J.Oa, !0);
    T(a, L.J.Fb, Wb());
    T(a, L.J.fm, a.M.eventMetadata[L.J.Oa]);
  }
  var TN = new (function () {
    this.H = {};
  })();
  function VN(a) {
    var b = eC(!1);
    if (b != null && b.status) {
      var c = { gtb: b.status };
      b.delay && (c.gtbd = b.delay);
      a.mergeHitDataForKey(K.D.Sa, c);
      X(a, K.D.fg, b.status);
    }
  }
  function WN(a, b) {
    b = b === void 0 ? !1 : b;
    var c = S(a, L.J.ng),
      d = my(a, "custom_event_accept_rules", !1) && !b;
    if (c) {
      var e = c.indexOf(a.target.destinationId) >= 0,
        f = !0;
      S(a, L.J.Ac) && (f = S(a, L.J.Gb) === mm());
      e && f ? T(a, L.J.ei, !0) : (T(a, L.J.ei, !1), d || (a.isAborted = !0));
      if (a.canBeAccepted()) {
        var g = lm().indexOf(a.target.destinationId) >= 0,
          h = !1;
        if (!g) {
          var k,
            m =
              (k = fm(a.target.destinationId)) == null
                ? void 0
                : k.canonicalContainerId;
          m && (h = mm() === m);
        }
        g || h ? S(a, L.J.ei) && a.accept() : (a.isAborted = !0);
      } else a.isAborted = !0;
    }
  }
  function dO() {
    return fo("dedupe_gclid", function () {
      return Bv();
    });
  }
  var eO = /^(www\.)?google(\.com?)?(\.[a-z]{2}t?)?$/,
    fO = /^www.googleadservices.com$/;
  function gO(a) {
    a || (a = hO());
    return a.Hs
      ? !1
      : !!(
          a.Vq ||
          a.Wq ||
          a.Zq ||
          a.Xq ||
          a.xg ||
          a.Lh ||
          a.Jq ||
          a.xj === "aw.ds" ||
          a.Nq
        );
  }
  function hO() {
    var a = {},
      b = ur(!0);
    a.Hs = !!b._up;
    var c = Es(),
      d = Dt();
    a.Vq = c.aw !== void 0;
    a.Wq = c.dc !== void 0;
    a.Zq = c.wbraid !== void 0;
    a.Xq = c.gbraid !== void 0;
    a.xj = typeof c.gclsrc === "string" ? c.gclsrc : void 0;
    a.xg = d.xg;
    a.Lh = d.Lh;
    var e = C.referrer ? zj(Fj(C.referrer), "host") : "";
    a.Nq = eO.test(e);
    a.Jq = fO.test(e);
    return a;
  }
  function lO(a) {
    if (gl.K)
      if (((nn.H = !0), a.eventName === K.D.sa)) qn(a.M, a.target.id);
      else {
        S(a, L.J.Lc) || (nn.K[a.target.id] = !0);
        var b = S(a, L.J.Gb);
        tC(b);
      }
  }
  function nO(a, b) {
    return (
      Lr("gsid_dc", {
        value: { joinId: a, lastJoinedTimeMs: b },
        expires: b + 3e5,
      }) === 0
    );
  }
  var pO = { Uo: { Ps: "cd", In: "ce", Qs: "cf", Rs: "cpf", Ss: "cu" } };
  function nQ(a, b, c, d) {}
  nQ.U = "internal.executeEventProcessor";
  function oQ(a) {
    var b;
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    O(this, "unsafe_run_arbitrary_javascript");
    try {
      If(71) && (a = "(function(dataLayer) {return " + a + "})([]);");
      var c = A.google_tag_manager;
      c && typeof c.e === "function" && (b = c.e(a));
    } catch (d) {}
    return Vd(b, this.V, 1);
  }
  oQ.U = "internal.executeJavascriptString";
  function pQ(a) {
    var b;
    return b;
  }
  function qQ(a) {
    var b = "";
    return b;
  }
  qQ.U = "internal.generateClientId";
  function rQ(a) {
    var b = {};
    return Vd(b);
  }
  rQ.U = "internal.getAdsCookieWritingOptions";
  function sQ(a, b) {
    var c = !1;
    return c;
  }
  sQ.U = "internal.getAllowAdPersonalization";
  function tQ(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    return c;
  }
  tQ.U = "internal.getAuid";
  function uQ() {
    var a = [];
    return Vd(a);
  }
  uQ.U = "internal.getContainerIds";
  function vQ() {
    var a = new nb();
    return a;
  }
  vQ.publicName = "getContainerVersion";
  function wQ(a, b) {
    b = b === void 0 ? !0 : b;
    var c;
    if (!ah(a) || !eh(b))
      throw N(this.getName(), ["string", "boolean|undefined"], arguments);
    O(this, "get_cookies", a);
    c = Vd(Dq(a, void 0, !!b), this.V);
    return c;
  }
  wQ.publicName = "getCookieValues";
  function xQ() {
    var a = "";
    return a;
  }
  xQ.U = "internal.getCorePlatformServicesParam";
  function yQ() {
    return Fk();
  }
  yQ.U = "internal.getCountryCode";
  function zQ() {
    var a = [];
    return Vd(a);
  }
  zQ.U = "internal.getDestinationIds";
  function AQ(a) {
    var b = new nb();
    return b;
  }
  AQ.U = "internal.getDeveloperIds";
  function BQ(a) {
    var b;
    return b;
  }
  BQ.U = "internal.getEcsidCookieValue";
  function CQ(a, b) {
    var c = null;
    return c;
  }
  CQ.U = "internal.getElementAttribute";
  function DQ(a) {
    var b = null;
    return b;
  }
  DQ.U = "internal.getElementById";
  function EQ(a) {
    var b = "";
    return b;
  }
  EQ.U = "internal.getElementInnerText";
  function FQ(a) {
    var b = null;
    return b;
  }
  FQ.U = "internal.getElementParent";
  function GQ(a) {
    var b = null;
    return b;
  }
  GQ.U = "internal.getElementPreviousSibling";
  function HQ(a, b) {
    var c = null;
    return Vd(c);
  }
  HQ.U = "internal.getElementProperty";
  function IQ(a) {
    var b;
    return b;
  }
  IQ.U = "internal.getElementValue";
  function JQ(a) {
    var b = 0;
    return b;
  }
  JQ.U = "internal.getElementVisibilityRatio";
  function KQ(a) {
    var b = null;
    return b;
  }
  KQ.U = "internal.getElementsByCssSelector";
  function LQ(a) {
    var b;
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    O(this, "read_event_data", a);
    var c;
    a: {
      var d = a,
        e = $H(this).originalEventData;
      if (e) {
        for (
          var f = e, g = {}, h = {}, k = {}, m = [], p = d.split("\\\\"), q = 0;
          q < p.length;
          q++
        ) {
          for (var r = p[q].split("\\."), t = 0; t < r.length; t++) {
            for (var u = r[t].split("."), v = 0; v < u.length; v++)
              m.push(u[v]), v !== u.length - 1 && m.push(k);
            t !== r.length - 1 && m.push(h);
          }
          q !== p.length - 1 && m.push(g);
        }
        var x = [],
          y = "",
          B = n(m),
          E = B.next();
        try {
          for (; !E.done; E = B.next()) {
            var F = E.value;
            F === k
              ? (x.push(y), (y = ""))
              : (y = F === g ? y + "\\" : F === h ? y + "." : y + F);
          }
        } finally {
          z(B, E);
        }
        y && x.push(y);
        var G = n(x),
          I = G.next();
        try {
          for (; !I.done; I = G.next()) {
            if (f == null) {
              c = void 0;
              break a;
            }
            f = f[I.value];
          }
        } finally {
          z(G, I);
        }
        c = f;
      } else c = void 0;
    }
    b = Vd(c, this.V, 1);
    return b;
  }
  LQ.U = "internal.getEventData";
  function MQ(a) {
    var b = null;
    return b;
  }
  MQ.U = "internal.getFirstElementByCssSelector";
  function NQ() {
    var a;
    return a;
  }
  NQ.U = "internal.getGsaExperimentId";
  function OQ() {
    return new Sd(oo);
  }
  OQ.U = "internal.getHtmlId";
  function PQ() {
    var a;
    return a;
  }
  PQ.U = "internal.getIframingState";
  function QQ(a, b) {
    var c = {};
    return Vd(c);
  }
  QQ.U = "internal.getLinkerValueFromLocation";
  function RQ() {
    var a = new nb();
    return a;
  }
  RQ.U = "internal.getPrivacyStrings";
  function SQ(a, b) {
    var c;
    return c;
  }
  SQ.U = "internal.getProductSettingsParameter";
  function TQ(a, b) {
    var c;
    return c;
  }
  TQ.publicName = "getQueryParameters";
  function UQ(a, b) {
    var c;
    return c;
  }
  UQ.publicName = "getReferrerQueryParameters";
  function VQ(a) {
    var b = "";
    if (!bh(a)) throw N(this.getName(), ["string|undefined"], arguments);
    O(this, "get_referrer", a);
    b = Bj(Fj(C.referrer), a);
    return b;
  }
  VQ.publicName = "getReferrerUrl";
  function WQ() {
    return Gk();
  }
  WQ.U = "internal.getRegionCode";
  function XQ(a, b) {
    var c;
    return c;
  }
  XQ.U = "internal.getRemoteConfigParameter";
  function YQ(a, b) {
    var c = null;
    return c;
  }
  YQ.U = "internal.getScopedElementsByCssSelector";
  function ZQ() {
    var a = new nb();
    a.set("width", 0);
    a.set("height", 0);
    return a;
  }
  ZQ.U = "internal.getScreenDimensions";
  function $Q() {
    var a = void 0;
    return a;
  }
  $Q.U = "internal.getSendTo";
  function aR() {
    var a = "";
    return a;
  }
  aR.U = "internal.getTopSameDomainUrl";
  function bR() {
    var a = "";
    return a;
  }
  bR.U = "internal.getTopWindowUrl";
  function cR(a) {
    var b = "";
    if (!bh(a)) throw N(this.getName(), ["string|undefined"], arguments);
    O(this, "get_url", a);
    b = zj(Fj(A.location.href), a);
    return b;
  }
  cR.publicName = "getUrl";
  function dR() {
    O(this, "get_user_agent");
    return Qc.userAgent;
  }
  dR.publicName = "getUserAgent";
  dR.U = "internal.getUserAgent";
  function eR() {
    var a;
    return a ? Vd(cH(a)) : a;
  }
  eR.U = "internal.getUserAgentClientHints";
  function hR() {
    var a = A;
    return (a.gaGlobal = a.gaGlobal || {});
  }
  function iR(a, b) {
    var c = hR();
    if (c.vid === void 0 || (b && !c.from_cookie))
      (c.vid = a), (c.from_cookie = b);
  }
  function LR(a) {
    (Qj(kN(a)) || Lj()) && X(a, K.D.Bl, Gk() || Fk());
    !Qj(kN(a)) && Lj() && ((P(677) && Kk()) || X(a, K.D.Ri, "::"));
  }
  function MR(a) {
    Lj() && (Qj(kN(a)) || Kk() || X(a, K.D.Yk, !0));
  }
  function RR() {
    var a = Mj();
    return !!a && a !== "/";
  }
  function SR(a, b, c, d, e) {
    var f;
    if (wd() || td()) {
      var g = Fj(a);
      f =
        d &&
        ac(g.pathname, "/g/collect") &&
        (e ? P(634) : P(546) && If(50) && RR())
          ? 2
          : (
              d || e || !Lj() || !RR() || Kk()
                ? 0
                : ac(g.pathname, "/ga/g/c") || ac(g.pathname, "/ag/g/c")
            )
          ? 1
          : 0;
    } else f = 0;
    switch (f) {
      case 2:
        var h = ac(a, "/g/collect") ? a.substring(0, a.length - 10) : a,
          k = e ? "/" : TR(),
          m = h + k,
          p = UR("/g/collect", b, c);
        return { nd: m, Jg: "", body: p, Th: !0 };
      case 1:
        var q;
        if (P(547)) {
          var r = TR(),
            t = a.indexOf(r),
            u = a.substring(0, t) + r,
            v = UR(a.substring(t + r.length - 1), b, c);
          q = { nd: u, Jg: "", body: v, Th: !0 };
        } else q = { nd: a, Jg: b, body: c, Th: !1 };
        return q;
      default:
        return { nd: a, Jg: b, body: c, Th: !1 };
    }
  }
  function TR() {
    var a = Mj();
    if (!a) return "";
    $b(a, "/") || (a = "/" + a);
    ac(a, "/") || (a += "/");
    return a;
  }
  function UR(a, b, c) {
    var d = [a];
    b && d.push("?", b);
    c && d.push("\r\n", c);
    return d.join("");
  }
  var AS = function (a) {
    for (
      var b = {}, c = String(zS.cookie).split(";"), d = 0;
      d < c.length;
      d++
    ) {
      var e = c[d].split("="),
        f = e[0].trim();
      if (f && a(f)) {
        var g = e.slice(1).join("=").trim();
        g && (g = decodeURIComponent(g));
        var h = void 0,
          k = void 0;
        ((h = b)[(k = f)] || (h[k] = [])).push(g);
      }
    }
    return b;
  };
  var BS = window,
    zS = document,
    CS = function (a) {
      var b = BS._gaUserPrefs;
      if (
        (b && b.ioo && b.ioo()) ||
        zS.documentElement.hasAttribute("data-google-analytics-opt-out") ||
        (a && BS["ga-disable-" + a] === !0)
      )
        return !0;
      try {
        var c = BS.external;
        if (c && c._gaUserPrefs && c._gaUserPrefs == "oo") return !0;
      } catch (f) {}
      for (
        var d =
            AS(function (f) {
              return f === "AMP_TOKEN";
            }).AMP_TOKEN || [],
          e = 0;
        e < d.length;
        e++
      )
        if (d[e] == "$OPT_OUT") return !0;
      return !!zS.getElementById("__gaOptOutExtension");
    };
  function kT(a) {
    a.copyToHitData(K.D.nb);
    var b = Q(a.M, K.D.cg);
    b && (WC(b, function () {}), X(a, K.D.cg, b));
  }
  function nT(a) {
    var b = function (c) {
      return !!c && c.conversion;
    };
    T(a, L.J.gg, b(iN(a)));
    S(a, L.J.hg) && T(a, L.J.Pl, b(iN(a, "first_visit")));
    S(a, L.J.Pe) && T(a, L.J.Sl, b(iN(a, "session_start")));
  }
  var AT =
    "gclid dclid gclsrc wbraid gbraid gad_source gad_campaignid utm_source utm_medium utm_campaign utm_term utm_content utm_id".split(
      " "
    );
  var CT = [K.D.ua, K.D.ia],
    DT = [K.D.ua, K.D.ia, K.D.ka];
  function ET(a) {
    var b,
      c = P(506) && !my(a, "ccd_ga_ads_ids_opt_out", !1),
      d = !!my(a, "google_ng", !1),
      e = hp(c ? (d ? DT : cq) : CT),
      f;
    f = my(a, K.D.Kf, Q(a.M, K.D.Kf)) || !!my(a, "google_ng", !1);
    b = {
      df: c,
      qr: d,
      sn: e,
      cf: f,
      Fg: !!my(a, "ga4_ads_linked", !1),
      Rh: Hk(),
      qj: !gN(),
      rr: Qj(kN(a)),
      nr: !!S(a, L.J.Nd),
      ur: !!S(a, L.J.Pe),
      Yq: !!Q(a.M, K.D.Sk),
      yr: !!S(a, L.J.Vi),
      qg: Q(a.M, K.D.Qc),
      hq: Q(a.M, K.D.Qc, void 0, 4),
      vr: !!S(a, L.J.ig),
    };
    T(a, L.J.Ti, b.cf);
    T(a, L.J.Si, FT(b));
    b.df && !b.cf && b.Fg && FT(b) && X(a, "_&ibt", "1");
    FT(b) && b.sn && (b.df ? b.qg !== !1 || b.Fg : 1) && T(a, L.J.bm, !0);
    b.qr && !b.Rh && X(a, K.D.Gd, 1);
    (b.df ? b.qg : b.hq) === !1 && X(a, "_&ngs", "1");
    T(a, L.J.Te, GT(b) && (b.ur || b.Yq));
    T(a, L.J.mg, GT(b) && b.yr && !b.Rh);
  }
  function FT(a) {
    return a.df
      ? (a.Fg || a.cf) && !a.Rh && !a.qj
      : a.cf && a.qg !== !1 && !a.qj && !a.Rh;
  }
  function GT(a) {
    if (a.vr) return !1;
    if (a.df) {
      if (!a.cf && !a.Fg) return !1;
    } else if (!a.cf) return !1;
    return !(
      a.rr ||
      a.nr ||
      a.qj ||
      (a.df ? a.qg === !1 && !a.Fg : a.qg === !1) ||
      !a.sn
    );
  }
  function TT(a) {}
  function UT(a) {
    var b = function () {};
    return b;
  }
  function VT(a, b) {}
  function WT(a, b) {
    var c = km();
    c && c.indexOf(b) > -1 && (a[L.J.Ac] = !0);
  }
  function ZT(a, b, c) {
    var d = this;
  }
  ZT.U = "internal.gtagConfig";
  function $T(a, b, c, d) {
    var e = this;
  }
  $T.U = "internal.gtagDestinationConfig";
  function bU(a, b) {}
  bU.publicName = "gtagSet";
  function cU() {
    var a = {};
    return a;
  }
  function dU(a) {}
  dU.U = "internal.initializeServiceWorker";
  function eU(a, b) {}
  eU.publicName = "injectHiddenIframe";
  function fU(a, b, c, d, e) {
    if (!((ah(a) || $g(a)) && Xg(b) && Xg(c) && eh(d) && eh(e)))
      throw N(
        this.getName(),
        [
          "string|OpaqueValue",
          "function",
          "function",
          "boolean|undefined",
          "boolean|undefined",
        ],
        arguments
      );
    var f = $H(this),
      g = bG();
    d && g(3);
    e && (g(1), g(2));
    var h = f.eventId,
      k = f.Qb(),
      m = g(void 0);
    cG || (cG = new aG());
    var p = cG;
    if (gl.P) {
      var q = String(m) + k;
      p.H[h] = p.H[h] || [];
      p.H[h].push(q);
      p.K[h] = p.K[h] || [];
      p.K[h].push("p" + k);
    }
    if (d && e)
      throw Error("useIframe and supportDocumentWrite cannot both be true.");
    O(this, "unsafe_inject_arbitrary_html", d, e);
    var r = D(b, this.V),
      t = D(c, this.V),
      u = D(a, this.V, 1);
    gU(u, r, t, !!d, !!e, f);
  }
  var hU = function (a, b, c, d) {
      return function () {
        try {
          if (b.length > 0) {
            var e = b.shift(),
              f = hU(a, b, c, d),
              g = e;
            if (
              String(g.nodeName).toUpperCase() === "SCRIPT" &&
              g.type === "text/gtmscript"
            ) {
              var h = g.text || g.textContent || g.innerHTML || "",
                k = g.getAttribute("data-gtmsrc"),
                m = g.charset || "";
              k
                ? dd(k, f, d, { async: !1, id: e.id, text: h, charset: m }, a)
                : ((g = C.createElement("script")),
                  (g.async = !1),
                  (g.type = "text/javascript"),
                  (g.id = e.id),
                  (g.text = h),
                  (g.charset = m),
                  f && (g.onload = f),
                  a.insertBefore(g, null));
              k || f();
            } else if (
              e.innerHTML &&
              e.innerHTML.toLowerCase().indexOf("<script") >= 0
            ) {
              for (var p = []; e.firstChild; )
                p.push(e.removeChild(e.firstChild));
              a.insertBefore(e, null);
              hU(e, p, f, d)();
            } else a.insertBefore(e, null), f();
          } else c();
        } catch (q) {
          d();
        }
      };
    },
    gU = function (a, b, c, d, e, f) {
      if (C.body) {
        var g = ro(a, b, c);
        a = g.er;
        b = g.onSuccess;
        if (d) {
        } else e ? iU(a, b, c) : hU(C.body, pd(a), b, c)();
      } else
        A.setTimeout(function () {
          gU(a, b, c, d, e, f);
        });
    };
  var iU = function (a, b, c) {
    var d = function () {
      var e = google_tag_manager_external.postscribe.getPostscribe(),
        f = { done: b },
        g = document.createElement("div");
      g.style.display = "none";
      g.style.visibility = "hidden";
      C.body.appendChild(g);
      try {
        e(g, a, f);
      } catch (h) {
        c();
      }
    };
    oC() ? d() : pC(d);
  };
  fU.U = "internal.injectHtml";
  var kU = { dl: 1, id: 1 };
  function lU(a, b, c, d) {}
  lU.publicName = "injectScript";
  function mU() {
    var a = Ck,
      b = !1;
    return b;
  }
  mU.U = "internal.isAutoPiiEligible";
  function nU(a) {
    var b = !0;
    return b;
  }
  nU.publicName = "isConsentGranted";
  function oU(a) {
    var b = !1;
    return b;
  }
  oU.U = "internal.isDebugMode";
  function pU(a) {
    var b = !1;
    return b;
  }
  pU.U = "internal.isDestinationInitialized";
  function qU() {
    return Ik();
  }
  qU.U = "internal.isDmaRegion";
  function rU() {
    return oC();
  }
  rU.U = "internal.isDomReady";
  function sU(a) {
    var b = !1;
    return b;
  }
  sU.U = "internal.isEntityInfrastructure";
  function tU(a) {
    var b = !1;
    return b;
  }
  tU.U = "internal.isFeatureEnabled";
  function uU() {
    var a = !1;
    return a;
  }
  uU.U = "internal.isFpfe";
  function vU() {
    var a = !1;
    return a;
  }
  vU.U = "internal.isGcpBrowser";
  function wU() {
    var a = !1;
    return a;
  }
  wU.U = "internal.isLandingPage";
  function xU() {
    var a = !1;
    return a;
  }
  xU.U = "internal.isM3blOrTtvDisabled";
  function yU() {
    var a = !1;
    return a;
  }
  yU.U = "internal.isOgt";
  function zU() {
    var a;
    return a;
  }
  zU.U = "internal.isSafariPcmEligibleBrowser";
  function AU() {
    var a = Gh(function (b) {
      $H(this).log("error", b);
    });
    a.publicName = "JSON";
    return a;
  }
  function BU(a) {
    var b = void 0;
    if (!ah(a)) throw N(this.getName(), ["string"], arguments);
    b = Fj(a);
    return Vd(b);
  }
  BU.U = "internal.legacyParseUrl";
  function CU() {
    return !1;
  }
  var DU = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {
      return !1;
    },
    removeItem: function (a) {},
  };
  function EU() {}
  EU.publicName = "logToConsole";
  function FU(a, b) {}
  FU.U = "internal.mergeRemoteConfig";
  function GU(a, b, c) {
    c = c === void 0 ? !0 : c;
    var d = [];
    if (!ah(a) || !ah(b) || !dh(c))
      throw N(
        this.getName(),
        ["string", "string", "boolean|undefined"],
        arguments
      );
    d = Dq(b, a, !!c);
    return Vd(d);
  }
  GU.U = "internal.parseCookieValuesFromString";
  function HU(a) {
    var b = void 0;
    if (typeof a !== "string") return;
    a && $b(a, "//") && (a = C.location.protocol + a);
    if (typeof URL === "function") {
      var c;
      a: {
        var d;
        try {
          d = new URL(a);
        } catch (x) {
          c = void 0;
          break a;
        }
        for (
          var e = {}, f = Array.from(d.searchParams), g = 0;
          g < f.length;
          g++
        ) {
          var h = f[g][0],
            k = f[g][1];
          e.hasOwnProperty(h)
            ? typeof e[h] === "string"
              ? (e[h] = [e[h], k])
              : e[h].push(k)
            : (e[h] = k);
        }
        c = {
          href: d.href,
          origin: d.origin,
          protocol: d.protocol,
          username: d.username,
          password: d.password,
          host: d.host,
          hostname: d.hostname,
          port: d.port,
          pathname: d.pathname,
          search: d.search,
          searchParams: e,
          hash: d.hash,
        };
      }
      return Vd(c);
    }
    var m;
    try {
      m = Fj(a);
    } catch (x) {
      return;
    }
    if (!m.protocol || !m.host) return;
    var p = {};
    if (m.search)
      for (
        var q = m.search.replace("?", "").split("&"), r = 0;
        r < q.length;
        r++
      ) {
        var t = q[r].split("="),
          u = t[0],
          v = yj(t.splice(1).join("=")) || "";
        v = v.replace(/\+/g, " ");
        p.hasOwnProperty(u)
          ? typeof p[u] === "string"
            ? (p[u] = [p[u], v])
            : p[u].push(v)
          : (p[u] = v);
      }
    m.searchParams = p;
    m.origin = m.protocol + "//" + m.host;
    m.username = "";
    m.password = "";
    b = Vd(m);
    return b;
  }
  HU.publicName = "parseUrl";
  function IU(a) {}
  IU.U = "internal.processAsNewEvent";
  function JU(a, b, c) {
    var d;
    return d;
  }
  JU.U = "internal.pushToDataLayer";
  function KU(a) {
    var b = Qa.apply(1, arguments),
      c = !1;
    return c;
  }
  KU.publicName = "queryPermission";
  function LU(a) {
    var b = this;
  }
  LU.U = "internal.queueAdsTransmission";
  function MU(a) {
    var b = void 0;
    return b;
  }
  MU.publicName = "readAnalyticsStorage";
  function NU() {
    var a = "";
    return a;
  }
  NU.publicName = "readCharacterSet";
  function OU() {
    return H(19);
  }
  OU.U = "internal.readDataLayerName";
  function PU() {
    var a = "";
    return a;
  }
  PU.publicName = "readTitle";
  function QU(a, b) {
    var c = this;
  }
  QU.U = "internal.registerCcdCallback";
  function RU(a, b) {
    return !0;
  }
  RU.U = "internal.registerDestination";
  var SU = ["event"];
  function TU(a, b, c) {}
  TU.U = "internal.registerGtagCommandListener";
  function UU(a, b) {
    var c = !1;
    return c;
  }
  UU.U = "internal.removeDataLayerEventListener";
  function VU(a, b) {}
  VU.U = "internal.removeFormData";
  function WU() {}
  WU.publicName = "resetDataLayer";
  function XU(a, b, c) {
    var d = void 0;
    return d;
  }
  XU.U = "internal.scrubUrlParams";
  function YU(a) {}
  YU.U = "internal.sendAdsHit";
  function ZU(a, b, c, d) {}
  ZU.U = "internal.sendGtagEvent";
  function $U(a, b, c) {}
  $U.publicName = "sendPixel";
  function aV(a, b) {}
  aV.U = "internal.setAnchorHref";
  function bV(a) {}
  bV.U = "internal.setContainerConsentDefaults";
  function cV(a, b, c, d) {
    var e = this;
    d = d === void 0 ? !0 : d;
    var f = !1;
    return f;
  }
  cV.publicName = "setCookie";
  function dV(a) {}
  dV.U = "internal.setCorePlatformServices";
  function eV(a, b) {}
  eV.U = "internal.setDataLayerValue";
  function fV(a) {}
  fV.publicName = "setDefaultConsentState";
  function gV(a, b) {}
  gV.U = "internal.setDelegatedConsentType";
  function hV(a, b) {}
  hV.U = "internal.setFormAction";
  function iV(a, b, c) {
    c = c === void 0 ? !1 : c;
  }
  iV.U = "internal.setInCrossContainerData";
  function jV(a, b, c) {
    return !1;
  }
  jV.publicName = "setInWindow";
  function kV(a, b, c) {}
  kV.U = "internal.setProductSettingsParameter";
  function lV(a, b, c) {}
  lV.U = "internal.setRemoteConfigParameter";
  function mV(a, b) {}
  mV.U = "internal.setTransmissionMode";
  function nV(a, b, c, d) {
    var e = this;
  }
  nV.publicName = "sha256";
  function oV(a, b, c) {}
  oV.U = "internal.sortRemoteConfigParameters";
  function pV(a) {}
  pV.U = "internal.storeAdsBraidLabels";
  function qV(a, b) {
    var c = void 0;
    return c;
  }
  qV.U = "internal.subscribeToCrossContainerData";
  var rV = {
    getItem: function (a) {
      var b = null;
      return b;
    },
    setItem: function (a, b) {},
    removeItem: function (a) {},
    clear: function () {},
    publicName: "templateStorage",
  };
  function sV(a, b) {
    var c = !1;
    return c;
  }
  sV.U = "internal.testRegex";
  function tV(a) {
    var b;
    return b;
  }
  function uV(a, b) {}
  uV.U = "internal.trackUsage";
  function vV(a, b) {
    var c;
    return c;
  }
  vV.U = "internal.unsubscribeFromCrossContainerData";
  function wV(a) {}
  wV.publicName = "updateConsentState";
  function xV(a) {
    var b = !1;
    return b;
  }
  xV.U = "internal.userDataNeedsEncryption";
  var yV = function () {
      this.H = new $h();
    },
    AV = function () {
      var a = zV;
      return function (b) {
        var c;
        var d = a.H;
        if (d.contains(b)) c = d.get(b, this);
        else {
          var e;
          if ((e = d.H.hasOwnProperty(b))) {
            var f = this.V.hb();
            if (f) {
              var g = !1,
                h = f.Qb();
              if (h) {
                ph(h) || (g = !0);
              }
              e = g;
            } else e = !0;
          }
          if (e) {
            var k = d.H.hasOwnProperty(b) ? d.H[b] : void 0;
            c = k;
          } else throw Error(b + " is not a valid API name.");
        }
        return c;
      };
    },
    zV;
  function BV(a, b, c) {
    zV || (zV = new yV());
    zV.H.add(a, b, c);
  }
  function CV(a, b) {
    zV || (zV = new yV());
    var c = zV.H;
    if (c.H.hasOwnProperty(a))
      throw Error(
        "Attempting to add a private function which already exists: " + a + "."
      );
    if (c.contains(a))
      throw Error(
        "Attempting to add a private function with an existing API name: " +
          a +
          "."
      );
    c.H[a] = Gb(b) ? ih(a, b) : jh(a, b);
  }
  function DV(a, b) {
    function c(d) {
      if (!Ug(d)) throw N(this.getName(), ["Object"], arguments);
      var e = D(d, this.V, 1).zb();
      a(e);
    }
    c.U = "internal." + b;
    return c;
  }
  function EV() {
    var a = function (c) {
        return void CV(c.U, c);
      },
      b = function (c) {
        return void BV(c.publicName, c);
      };
    b(UH);
    b(aI);
    b(RI);
    b(TI);
    b(UI);
    b(xJ);
    b(zJ);
    b(yK);
    b(AU());
    b(AK);
    b(vQ);
    b(wQ);
    b(TQ);
    b(UQ);
    b(VQ);
    b(cR);
    b(dR);
    b(bU);
    b(eU);
    b(lU);
    b(nU);
    b(EU);
    b(HU);
    b(KU);
    b(MU);
    b(NU);
    b(PU);
    b($U);
    b(cV);
    b(fV);
    b(jV);
    b(nV);
    b(rV);
    b(wV);
    BV("Math", nh());
    BV("Object", Yh);
    BV("TestHelper", bi());
    BV("assertApi", kh);
    BV("assertThat", lh);
    BV("decodeUri", qh);
    BV("decodeUriComponent", rh);
    BV("encodeUri", sh);
    BV("encodeUriComponent", th);
    BV("fail", Bh);
    BV("generateRandom", Dh);
    BV("getTimestamp", Eh);
    BV("getTimestampMillis", Eh);
    BV("getType", Fh);
    BV("makeInteger", Hh);
    BV("makeNumber", Ih);
    BV("makeString", Jh);
    BV("makeTableMap", Th);
    BV("mock", Wh);
    BV("mockObject", Xh);
    BV("fromBase64", pQ, !("atob" in A));
    BV("localStorage", DU, !CU());
    BV("toBase64", tV, !("btoa" in A));
    a(TH);
    a(XH);
    a(pI);
    a(uI);
    a(II);
    a(PI);
    a(SI);
    a(VI);
    a(WI);
    a(ZI);
    a(rJ);
    a(sJ);
    a(tJ);
    a(uJ);
    a(wJ);
    a(yJ);
    a(AJ);
    a(xK);
    a(zK);
    a(BK);
    a(CK);
    a(DK);
    a(EK);
    a(FK);
    a(nL);
    a(vL);
    a(yL);
    a(FL);
    a(GL);
    a(LL);
    a(QL);
    a(VL);
    a(bM);
    a(gM);
    a(rM);
    a(tM);
    a(GM);
    a(HM);
    a(IM);
    a(nQ);
    a(oQ);
    a(qQ);
    a(rQ);
    a(sQ);
    a(tQ);
    a(uQ);
    a(xQ);
    a(yQ);
    a(zQ);
    a(AQ);
    a(BQ);
    a(CQ);
    a(DQ);
    a(EQ);
    a(FQ);
    a(GQ);
    a(HQ);
    a(IQ);
    a(JQ);
    a(KQ);
    a(LQ);
    a(MQ);
    a(NQ);
    a(OQ);
    a(PQ);
    a(QQ);
    a(RQ);
    a(SQ);
    a(WQ);
    a(XQ);
    a(YQ);
    a(ZQ);
    a(aR);
    a(bR);
    a(eR);
    a(ZT);
    a($T);
    a(dU);
    a(fU);
    a(mU);
    a(oU);
    a(pU);
    a(qU);
    a(rU);
    a(sU);
    a(tU);
    a(uU);
    a(vU);
    a(wU);
    a(xU);
    a(yU);
    a(zU);
    a(BU);
    a(GI);
    a(FU);
    a(GU);
    a(IU);
    a(JU);
    a(LU);
    a(OU);
    a(QU);
    a(RU);
    a(TU);
    a(UU);
    a(VU);
    a(XU);
    a(YU);
    a(ZU);
    a(aV);
    a(bV);
    a(dV);
    a(eV);
    a(gV);
    a(hV);
    a(iV);
    a(kV);
    a(lV);
    a(mV);
    a(oV);
    a(pV);
    a(qV);
    a(sV);
    a(uV);
    a(vV);
    a(xV);
    CV("internal.IframingStateSchema", cU());
    CV("internal.quickHash", Ch);
    P(667) && a(vJ);
    P(668) && a($Q);

    zV || (zV = new yV());
    return AV();
  }
  var kG;
  function FV() {
    kG.ud(function (a, b, c) {
      go();
      var d = eo;
      d.H.SANDBOXED_JS_SEMAPHORE = d.H.SANDBOXED_JS_SEMAPHORE || 0;
      d.H.SANDBOXED_JS_SEMAPHORE++;
      try {
        return a.apply(b, c);
      } finally {
        go(), eo.H.SANDBOXED_JS_SEMAPHORE--;
      }
    });
  }
  function GV(a) {
    if (a && a.length)
      for (
        var b = $i(21, function () {
            return {};
          }),
          c = 0;
        c < a.length;
        c++
      ) {
        var d = a[c].replace(/^_*/, "");
        b[d] = ["sandboxedScripts"];
      }
  }
  function HV(a) {
    if (a) {
      var b = $i(21, function () {
          return {};
        }),
        c = n(Object.entries(a)),
        d = c.next();
      try {
        for (; !d.done; d = c.next()) {
          var e = n(d.value),
            f = e.next().value,
            g = e.next().value,
            h = f,
            k = n(g),
            m = k.next();
          try {
            for (; !m.done; m = k.next()) {
              var p = m.value.replace(/^_*/, "");
              b[p] = b[p] || [];
              b[p].push(h);
            }
          } finally {
            z(k, m);
          }
        }
      } finally {
        z(c, d);
      }
    }
  }
  function IV(a) {
    LD(SC("developer_id." + a, !0), 0, {});
  }
  function Y(a) {
    return window.encodeURIComponent(a);
  }
  function JV(a) {
    hd(a, void 0, void 0);
  }
  function KV(a) {
    var b = ["veinteractive.com", "ve-interactive.cn"];
    if (!a) return !1;
    var c = zj(Fj(a), "host");
    if (!c) return !1;
    for (var d = 0; b && d < b.length; d++) {
      var e = b[d] && b[d].toLowerCase();
      if (e) {
        var f = c.length - e.length;
        f > 0 && e.charAt(0) !== "." && (f--, (e = "." + e));
        if (f >= 0 && c.indexOf(e, f) === f) return !0;
      }
    }
    return !1;
  }
  function LV(a, b, c) {
    for (var d = {}, e = !1, f = 0; a && f < a.length; f++)
      a[f] &&
        a[f].hasOwnProperty(b) &&
        a[f].hasOwnProperty(c) &&
        ((d[a[f][b]] = a[f][c]), (e = !0));
    return e ? d : null;
  }
  function MV(a, b) {
    var c = {};
    if (a) for (var d in a) a.hasOwnProperty(d) && (c[d] = a[d]);
    if (b) {
      var e = LV(b, "parameter", "parameterValue");
      e && (c = Eb(e, c || null));
    }
    return c;
  }
  function NV(a, b, c) {
    return a === void 0 || a === c ? b : a;
  }
  function OV(a) {
    var b = A;
    return yj(b.escape(b.atob(a)));
  }
  function PV() {
    try {
      if (!P(498)) return [];
      var a = uk(qk.ba.Wl);
      if (Array.isArray(a)) return a;
      var b = [],
        c;
      a: {
        try {
          c = !!C.querySelector('script[data-requiremodule^="mage/"]');
          break a;
        } catch (u) {}
        c = !1;
      }
      c && b.push(1);
      var d;
      a: {
        try {
          var e = OV("YXNzZXRzLnNxdWFyZXNwYWNlLmNvbS8=");
          d = e ? !!C.querySelector('script[src^="//' + e + '"]') : !1;
          break a;
        } catch (u) {}
        d = !1;
      }
      d && b.push(2);
      var f;
      a: {
        try {
          f = !!C.querySelector(
            'script[src*="woocommerce"],link[href*="woocommerce"],[class|="woocommerce"]'
          );
          break a;
        } catch (u) {}
        f = !1;
      }
      f && b.push(4);
      var g;
      a: {
        try {
          var h,
            k = ((h = C.location) == null ? void 0 : h.hostname) || "",
            m,
            p = ((m = C.location) == null ? void 0 : m.origin) || "",
            q = OV("LndvcmRwcmVzcy5jb20="),
            r = OV("Ly9zLncub3Jn");
          g =
            q && r
              ? ac(k, q) ||
                !!C.querySelector(
                  '[src^="' +
                    p +
                    '/wp-content"],meta[name="generator"][content^="WordPress "],link[rel="dns-prefetch"][href="' +
                    (r + '"]')
                )
              : !1;
          break a;
        } catch (u) {}
        g = !1;
      }
      g && b.push(5);
      var t;
      a: {
        try {
          t = !!C.querySelector(
            '[class*="woocommerce"],meta[name="generator"][content^="WooCommerce "]'
          );
          break a;
        } catch (u) {}
        t = !1;
      }
      t && b.push(3);
      oC() && tk(qk.ba.Wl, b);
      return b;
    } catch (u) {}
    return [];
  }
  function QV(a, b, c) {
    return dd(a, b, c, void 0);
  }
  function RV(a, b) {
    A[a] = b;
  }
  function SV(a, b, c) {
    var d = A;
    b && (d[a] === void 0 || (c && !d[a])) && (d[a] = b);
    return d[a];
  }
  var TV = {},
    UV = V.W;
  var Z = { securityGroups: {} };

  (Z.securityGroups.access_globals = ["google"]),
    (function () {
      function a(b, c, d) {
        var e = { key: d, read: !1, write: !1, execute: !1 };
        switch (c) {
          case "read":
            e.read = !0;
            break;
          case "write":
            e.write = !0;
            break;
          case "readwrite":
            e.read = e.write = !0;
            break;
          case "execute":
            e.execute = !0;
            break;
          default:
            throw Error("Invalid " + b + " request " + c);
        }
        return e;
      }
      (function (b) {
        Z.__access_globals = b;
        Z.__access_globals.R = "access_globals";
        Z.__access_globals.isVendorTemplate = !0;
        Z.__access_globals.priorityOverride = 0;
        Z.__access_globals.isInfrastructure = !1;
        Z.__access_globals["6"] = !1;
      })(function (b) {
        for (
          var c = b.vtp_keys || [],
            d = b.vtp_createPermissionError,
            e = [],
            f = [],
            g = [],
            h = 0;
          h < c.length;
          h++
        ) {
          var k = c[h],
            m = k.key;
          k.read && e.push(m);
          k.write && f.push(m);
          k.execute && g.push(m);
        }
        return {
          assert: function (p, q, r) {
            if (!Hb(r)) throw d(p, {}, "Key must be a string.");
            if (q === "read") {
              if (e.indexOf(r) > -1) return;
            } else if (q === "write") {
              if (f.indexOf(r) > -1) return;
            } else if (q === "readwrite") {
              if (f.indexOf(r) > -1 && e.indexOf(r) > -1) return;
            } else if (q === "execute") {
              if (g.indexOf(r) > -1) return;
            } else
              throw d(
                p,
                {},
                "Operation must be either 'read', 'write', or 'execute', was " +
                  q
              );
            throw d(
              p,
              {},
              "Prohibited " + q + " on global variable: " + r + "."
            );
          },
          aa: a,
        };
      });
    })();
  (Z.securityGroups.get_referrer = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_referrer = b;
        Z.__get_referrer.R = "get_referrer";
        Z.__get_referrer.isVendorTemplate = !0;
        Z.__get_referrer.priorityOverride = 0;
        Z.__get_referrer.isInfrastructure = !1;
        Z.__get_referrer["6"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Hb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!Hb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          aa: a,
        };
      });
    })();
  (Z.securityGroups.read_event_data = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_event_data = b;
        Z.__read_event_data.R = "read_event_data";
        Z.__read_event_data.isVendorTemplate = !0;
        Z.__read_event_data.priorityOverride = 0;
        Z.__read_event_data.isInfrastructure = !1;
        Z.__read_event_data["6"] = !1;
      })(function (b) {
        var c = b.vtp_eventDataAccess,
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (g != null && !Hb(g))
              throw e(f, { key: g }, "Key must be a string.");
            if (c !== "any") {
              try {
                if (c === "specific" && g != null && tg(g, d)) return;
              } catch (h) {
                throw e(f, { key: g }, "Invalid key filter.");
              }
              throw e(f, { key: g }, "Prohibited read from event data.");
            }
          },
          aa: a,
        };
      });
    })();

  (Z.securityGroups.read_data_layer = ["google"]),
    (function () {
      function a(b, c) {
        return { key: c };
      }
      (function (b) {
        Z.__read_data_layer = b;
        Z.__read_data_layer.R = "read_data_layer";
        Z.__read_data_layer.isVendorTemplate = !0;
        Z.__read_data_layer.priorityOverride = 0;
        Z.__read_data_layer.isInfrastructure = !1;
        Z.__read_data_layer["6"] = !1;
      })(function (b) {
        var c = b.vtp_allowedKeys || "specific",
          d = b.vtp_keyPatterns || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Hb(g)) throw e(f, {}, "Keys must be strings.");
            if (c !== "any") {
              try {
                if (tg(g, d)) return;
              } catch (h) {
                throw e(f, {}, "Invalid key filter.");
              }
              throw e(
                f,
                {},
                "Prohibited read from data layer variable: " + g + "."
              );
            }
          },
          aa: a,
        };
      });
    })();
  (Z.securityGroups.unsafe_access_globals = ["google"]),
    (function () {
      function a(c, d) {
        c("access_globals", "readwrite", d);
      }
      function b(c, d) {
        return { key: d };
      }
      (function (c) {
        Z.__unsafe_access_globals = c;
        Z.__unsafe_access_globals.R = "unsafe_access_globals";
        Z.__unsafe_access_globals.isVendorTemplate = !0;
        Z.__unsafe_access_globals.priorityOverride = 0;
        Z.__unsafe_access_globals.isInfrastructure = !1;
        Z.__unsafe_access_globals["6"] = !1;
      })(function (c) {
        var d = c.vtp_createPermissionError;
        return {
          assert: function (e, f) {
            if (!Hb(f)) throw d(e, {}, "Wrong key type. Must be string.");
          },
          aa: b,
          cq: a,
        };
      });
    })();

  (Z.securityGroups.get_url = ["google"]),
    (function () {
      function a(b, c, d) {
        return { component: c, queryKey: d };
      }
      (function (b) {
        Z.__get_url = b;
        Z.__get_url.R = "get_url";
        Z.__get_url.isVendorTemplate = !0;
        Z.__get_url.priorityOverride = 0;
        Z.__get_url.isInfrastructure = !1;
        Z.__get_url["6"] = !1;
      })(function (b) {
        var c = b.vtp_urlParts === "any" ? null : [];
        c &&
          (b.vtp_protocol && c.push("protocol"),
          b.vtp_host && c.push("host"),
          b.vtp_port && c.push("port"),
          b.vtp_path && c.push("path"),
          b.vtp_extension && c.push("extension"),
          b.vtp_query && c.push("query"),
          b.vtp_fragment && c.push("fragment"));
        var d =
            c && b.vtp_queriesAllowed !== "any" ? b.vtp_queryKeys || [] : null,
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g, h) {
            if (g) {
              if (!Hb(g)) throw e(f, {}, "URL component must be a string.");
              if (c && c.indexOf(g) < 0)
                throw e(f, {}, "Prohibited URL component: " + g);
              if (g === "query" && d) {
                if (!h)
                  throw e(
                    f,
                    {},
                    "Prohibited from getting entire URL query when query keys are specified."
                  );
                if (!Hb(h)) throw e(f, {}, "Query key must be a string.");
                if (d.indexOf(h) < 0)
                  throw e(f, {}, "Prohibited query key: " + h);
              }
            } else if (c)
              throw e(
                f,
                {},
                "Prohibited from getting entire URL when components are specified."
              );
          },
          aa: a,
        };
      });
    })();

  (Z.securityGroups.unsafe_run_arbitrary_javascript = ["google"]),
    (function () {
      function a() {
        return {};
      }
      (function (b) {
        Z.__unsafe_run_arbitrary_javascript = b;
        Z.__unsafe_run_arbitrary_javascript.R =
          "unsafe_run_arbitrary_javascript";
        Z.__unsafe_run_arbitrary_javascript.isVendorTemplate = !0;
        Z.__unsafe_run_arbitrary_javascript.priorityOverride = 0;
        Z.__unsafe_run_arbitrary_javascript.isInfrastructure = !1;
        Z.__unsafe_run_arbitrary_javascript["6"] = !1;
      })(function () {
        return { assert: function () {}, aa: a };
      });
    })();

  (Z.securityGroups.unsafe_inject_arbitrary_html = ["google"]),
    (function () {
      function a(b, c, d) {
        return { useIframe: c, supportDocumentWrite: d };
      }
      (function (b) {
        Z.__unsafe_inject_arbitrary_html = b;
        Z.__unsafe_inject_arbitrary_html.R = "unsafe_inject_arbitrary_html";
        Z.__unsafe_inject_arbitrary_html.isVendorTemplate = !0;
        Z.__unsafe_inject_arbitrary_html.priorityOverride = 0;
        Z.__unsafe_inject_arbitrary_html.isInfrastructure = !1;
        Z.__unsafe_inject_arbitrary_html["6"] = !1;
      })(function (b) {
        var c = b.vtp_createPermissionError;
        return {
          assert: function (d, e, f) {
            if (e && f)
              throw c(
                d,
                {},
                "Only one of useIframe and supportDocumentWrite can be true."
              );
            if (e !== void 0 && typeof e !== "boolean")
              throw c(d, {}, "useIframe must be a boolean.");
            if (f !== void 0 && typeof f !== "boolean")
              throw c(d, {}, "supportDocumentWrite must be a boolean.");
          },
          aa: a,
        };
      });
    })();

  (Z.securityGroups.get_cookies = ["google"]),
    (function () {
      function a(b, c) {
        return { name: c };
      }
      (function (b) {
        Z.__get_cookies = b;
        Z.__get_cookies.R = "get_cookies";
        Z.__get_cookies.isVendorTemplate = !0;
        Z.__get_cookies.priorityOverride = 0;
        Z.__get_cookies.isInfrastructure = !1;
        Z.__get_cookies["6"] = !1;
      })(function (b) {
        var c = b.vtp_cookieAccess || "specific",
          d = b.vtp_cookieNames || [],
          e = b.vtp_createPermissionError;
        return {
          assert: function (f, g) {
            if (!Hb(g)) throw e(f, {}, "Cookie name must be a string.");
            if (c !== "any" && !(c === "specific" && d.indexOf(g) >= 0))
              throw e(f, {}, 'Access to cookie "' + g + '" is prohibited.');
          },
          aa: a,
        };
      });
    })();
  function VV() {
    var a = {},
      b = {
        dataLayer: nA,
        callback: function (c) {
          a.hasOwnProperty(c) && Gb(a[c]) && a[c]();
          delete a[c];
        },
        bootstrap: 0,
      };
    (b.onHtmlSuccess = to(!0)), (b.onHtmlFailure = to(!1));
    return b;
  }
  function WV() {
    var a = VV();
    jo(a);
    tm();
    ZA();
    var b = $i(21, function () {
      return {};
    });
    Yb(b, Z.securityGroups);
    var c = pm(qm()),
      d,
      e = c == null ? void 0 : (d = c.context) == null ? void 0 : d.source;
    Wo(e, c == null ? void 0 : c.parent);
    (e !== 2 && e !== 4 && e !== 3) || R(142);
    Yj() && R(202);
    Zj() && R(203);
    vo || (vo = new uo()), qo || (qo = new so());
    return a;
  }
  function XV() {
    var a = H(60);
    if (a)
      for (var b = a.split("."), c = 0; c < b.length; c++) {
        var d = b[c],
          e = TN;
        d && (e.H[d] = !0);
      }
  }
  function YV() {
    Yp();
    go();
    for (
      var a = data.resource || {}, b = JA, c = a.macros || [], d = 0;
      d < c.length;
      d++
    )
      b.macros.push(new AA(c[d], d, b.tags, b.macros));
    for (var e = a.tags || [], f = 0; f < e.length; f++)
      b.tags.push(new EA(e[f], f, b.tags, b.macros));
    for (var g = a.predicates || [], h = 0; h < g.length; h++)
      b.predicates.push(new BA(g[h], b.tags, b.macros));
    for (var k = a.rules || [], m = 0; m < k.length; m++)
      b.rules.push(new CA(k[m], m));
    Oz = Z;
    var p = data.permissions || {},
      q = Z;
    Gx = new bg(H(5), p, q);
    var r = data.sandboxed_scripts,
      t = data.security_groups,
      u = data.runtime || [],
      v = data.runtime_lines;
    kG = new qf();
    FV();
    Nz = jG();
    var x = kG,
      y = EV(),
      B = new Od("require", y);
    B.Va();
    x.H.H.set("require", B);
    gb.set("require", B);
    for (var E = 0; E < u.length; E++) {
      var F = u[E];
      if (!Array.isArray(F) || F.length < 3) {
        if (F.length === 0) continue;
        break;
      }
      v && v[E] && v[E].length && Pf(F, v[E]);
      try {
        kG.execute(F);
      } catch (ZV) {}
    }
    GV(r);
    HV(t);
    var G = WV();
    HF();
    Ck.bind();
    if (!rj) {
      var I = Ik() ? pp(Lf(5)) : pp(Lf(4)),
        J = n(ep),
        M = J.next();
      try {
        for (; !M.done; M = J.next()) {
          var U = M.value,
            W = U,
            fa = I[U] ? "granted" : "denied";
          Fm().implicit(W, fa);
        }
      } finally {
        z(J, M);
      }
    }
    KE.bind();
    nC();
    iC();
    P(610) && (yx(), xx(Ax), zx());
    gl.P &&
      (P(610) || (yx(), xx(Ax), zx()),
      WA(),
      hD(),
      (wB = new vB()),
      xx(gz),
      lD(),
      cG || (cG = new aG()),
      zB || (zB = new yB()));
    if (gl.K) {
      fF.bind();
      PC.bind();
      ZE.bind();
      var da = rm();
      if (da) {
        var ea;
        a: {
          var ja,
            va = (ja = da.scriptElement) == null ? void 0 : ja.src;
          if (va) {
            var Ga;
            try {
              var wa;
              Ga =
                (wa = Ad()) == null ? void 0 : wa.getEntriesByType("resource");
            } catch (ZV) {}
            if (Ga) {
              var La = -1,
                db = n(Ga),
                Cb = db.next();
              try {
                for (; !Cb.done; Cb = db.next()) {
                  var Ka = Cb.value;
                  if (
                    Ka.initiatorType === "script" &&
                    ((La += 1), Ka.name.replace(lF, "") === va.replace(lF, ""))
                  ) {
                    ea = La;
                    break a;
                  }
                }
              } finally {
                z(db, Cb);
              }
              R(146);
            } else R(145);
          }
          ea = void 0;
        }
        var Ua = ea;
        Ua !== void 0 &&
          (da.canonicalContainerId &&
            gj("rtg", String(da.canonicalContainerId)),
          gj("slo", String(Ua)),
          gj("hlo", da.htmlLoadOrder || "-1"),
          gj("lst", String(da.loadScriptType || "0")));
      } else R(144);
      var kb;
      var Ib = om();
      if (Ib)
        if (Ib.canonicalContainerId) kb = Ib.canonicalContainerId;
        else {
          var ub,
            Jb =
              Ib.scriptContainerId ||
              ((ub = Ib.destinations) == null ? void 0 : ub[0]);
          kb = Jb ? "_" + Jb : void 0;
        }
      else kb = void 0;
      var $c = kb;
      $c && gj("pcid", $c);
      gj("bt", String(If(47) ? 2 : If(50) ? 1 : 0));
      gj("ct", String(If(47) ? 0 : If(50) ? 1 : 3));
      cF.bind();
      var rf = [],
        Xd = [],
        zh = n(Object.keys(iF)),
        Ah = zh.next();
      try {
        for (; !Ah.done; Ah = zh.next()) {
          var Hm = Ah.value;
          if (window.isSecureContext || !kF[Hm]) {
            var ZF = iF[Hm]();
            if (Gb(ZF)) {
              var $F = Function.prototype.toString.call(ZF);
              ac($F, "{ [native code] }") ||
                ac($F, "{\n    [native code]\n}") ||
                Xd.push(Hm);
            } else rf.push(Hm);
          }
        }
      } finally {
        z(zh, Ah);
      }
      rf.length > 0 && gj("jsm", rf.join("~"));
      Xd.length > 0 && gj("jsp", Xd.join("~"));
    }
    google_tag_manager_external.postscribe.installPostscribe();
    GF();
    pk(1);
    EI();
    return G;
  }
  function Bk() {
    try {
      if (!Wj() && (If(47) || !Em()))
        if (If(70)) RA();
        else {
          If(64) && ij.H.K.add(118517917);
          mj();
          nj(ij.H, Kf(67));
          lj(ij.H, H(72));
          gl.H && qz();
          Kh[4] = !0;
          var a = fo("debugGroupId", function () {
            return String(Math.floor(Number.MAX_SAFE_INTEGER * Math.random()));
          });
          dp(a);
          Qt();
          YF();
          ju();
          jC();
          if (um()) {
            H(5);
            Mt({ ctid: H(5) });
            DI();
            CB().removeExternalRestrictions(mm());
          } else {
            YV().bootstrap = Wb();
            If(51) && SE();
            gl.H && rz();
            typeof A.name === "string" &&
            $b(A.name, "web-pixel-sandbox-CUSTOM") &&
            Bd()
              ? IV("dMDg0Yz")
              : A.Shopify && (IV("dN2ZkMj"), Bd() && IV("dNTU0Yz"));
            XV();
          }
        }
    } catch (b) {
      pk(5), Bx();
    }
  }
  (function (a) {
    function b() {
      g = C.documentElement.getAttribute("data-tag-assistant-present");
      Io(g) && (f = e.Hl);
    }
    function c() {
      f && Uc ? ((KA = !0), d(f)) : a();
    }
    if (If(70)) a();
    else {
      var d = function (q) {
          var r = "GTM",
            t = "GTM";
          If(45) && ((r = "OGT"), (t = "GTAG"));
          var u = H(23),
            v = A[u];
          v ||
            ((v = []),
            (A[u] = v),
            dd(
              "https://" +
                H(3) +
                "/debug/bootstrap?id=" +
                H(5) +
                "&src=" +
                t +
                "&cond=" +
                String(q) +
                "&gtm=" +
                Ku()
            ));
          var x = {
              messageType: "CONTAINER_STARTING",
              data: {
                scriptSource: Uc,
                containerProduct: r,
                debug: !1,
                id: H(5),
                targetRef: {
                  ctid: H(5),
                  isDestination: jm(),
                  canonicalId: H(6),
                },
                aliases: nm(),
                destinations: km(),
              },
            },
            y = x.data;
          y.resume = function () {
            a();
          };
          y.resumeWithMemos = function () {
            Uo(1);
            a();
          };
          If(2) && (x.data.initialPublish = !0);
          v.push(x);
        },
        e = { Wo: 1, Kl: 2, Yl: 3, xk: 4, Hl: 5 };
      e[e.Wo] = "GTM_DEBUG_LEGACY_PARAM";
      e[e.Kl] = "GTM_DEBUG_PARAM";
      e[e.Yl] = "REFERRER";
      e[e.xk] = "COOKIE";
      e[e.Hl] = "EXTENSION_PARAM";
      var f = void 0,
        g = void 0,
        h = zj(A.location, "query", !1, void 0, "gtm_debug");
      Io(h) && (f = e.Kl);
      if (!f && C.referrer) {
        var k = Fj(C.referrer);
        Bj(k, "host") === H(24) && (f = e.Yl);
      }
      if (!f) {
        var m = Dq("__TAG_ASSISTANT");
        m.length && m[0].length && (f = e.xk);
      }
      f || b();
      if (!f && Ho(g)) {
        var p = !1;
        id(
          C,
          "TADebugSignal",
          function () {
            p || ((p = !0), b(), c());
          },
          !1
        );
        A.setTimeout(function () {
          p || ((p = !0), b(), c());
        }, 200);
      } else c();
    }
  })(function () {
    !If(47) || Ak()["0"] ? Bk() : Ek();
  });
})();
