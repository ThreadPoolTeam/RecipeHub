var e = function () {};
export { e as t };
