import { t as e } from "./rolldown-runtime-C0FnF6B9.js";
import { n as t, t as n } from "./dist-Cmw-iXzl.js";
import { n as r, t as i } from "./dist-CZ_f6czE.js";
var a = e((e, t) => {
    t.exports = TypeError;
  }),
  o = e((e, t) => {
    t.exports = Object;
  }),
  s = e((e, t) => {
    t.exports = Error;
  }),
  c = e((e, t) => {
    t.exports = EvalError;
  }),
  l = e((e, t) => {
    t.exports = RangeError;
  }),
  u = e((e, t) => {
    t.exports = ReferenceError;
  }),
  d = e((e, t) => {
    t.exports = SyntaxError;
  }),
  f = e((e, t) => {
    t.exports = URIError;
  }),
  p = e((e, t) => {
    t.exports = Math.abs;
  }),
  m = e((e, t) => {
    t.exports = Math.floor;
  }),
  h = e((e, t) => {
    t.exports = Math.max;
  }),
  g = e((e, t) => {
    t.exports = Math.min;
  }),
  _ = e((e, t) => {
    t.exports = Math.pow;
  }),
  v = e((e, t) => {
    t.exports = Math.round;
  }),
  y = e((e, t) => {
    t.exports =
      Number.isNaN ||
      function (e) {
        return e !== e;
      };
  }),
  b = e((e, t) => {
    var n = y();
    t.exports = function (e) {
      return n(e) || e === 0 ? e : e < 0 ? -1 : 1;
    };
  }),
  x = e((e, t) => {
    t.exports = Object.getOwnPropertyDescriptor;
  }),
  S = e((e, t) => {
    var n = x();
    if (n)
      try {
        n([], `length`);
      } catch {
        n = null;
      }
    t.exports = n;
  }),
  C = e((e, t) => {
    var n = Object.defineProperty || !1;
    if (n)
      try {
        n({}, `a`, { value: 1 });
      } catch {
        n = !1;
      }
    t.exports = n;
  }),
  w = e((e, t) => {
    t.exports = function () {
      if (
        typeof Symbol != `function` ||
        typeof Object.getOwnPropertySymbols != `function`
      )
        return !1;
      if (typeof Symbol.iterator == `symbol`) return !0;
      var e = {},
        t = Symbol(`test`),
        n = Object(t);
      if (
        typeof t == `string` ||
        Object.prototype.toString.call(t) !== `[object Symbol]` ||
        Object.prototype.toString.call(n) !== `[object Symbol]`
      )
        return !1;
      var r = 42;
      for (var i in ((e[t] = r), e)) return !1;
      if (
        (typeof Object.keys == `function` && Object.keys(e).length !== 0) ||
        (typeof Object.getOwnPropertyNames == `function` &&
          Object.getOwnPropertyNames(e).length !== 0)
      )
        return !1;
      var a = Object.getOwnPropertySymbols(e);
      if (
        a.length !== 1 ||
        a[0] !== t ||
        !Object.prototype.propertyIsEnumerable.call(e, t)
      )
        return !1;
      if (typeof Object.getOwnPropertyDescriptor == `function`) {
        var o = Object.getOwnPropertyDescriptor(e, t);
        if (o.value !== r || o.enumerable !== !0) return !1;
      }
      return !0;
    };
  }),
  T = e((e, t) => {
    var n = typeof Symbol < `u` && Symbol,
      r = w();
    t.exports = function () {
      return typeof n != `function` ||
        typeof Symbol != `function` ||
        typeof n(`foo`) != `symbol` ||
        typeof Symbol(`bar`) != `symbol`
        ? !1
        : r();
    };
  }),
  E = e((e, t) => {
    t.exports = (typeof Reflect < `u` && Reflect.getPrototypeOf) || null;
  }),
  D = e((e, t) => {
    t.exports = o().getPrototypeOf || null;
  }),
  O = e((e, t) => {
    var n = Object.prototype.toString,
      r = Math.max,
      i = `[object Function]`,
      a = function (e, t) {
        for (var n = [], r = 0; r < e.length; r += 1) n[r] = e[r];
        for (var i = 0; i < t.length; i += 1) n[i + e.length] = t[i];
        return n;
      },
      o = function (e, t) {
        for (var n = [], r = t || 0, i = 0; r < e.length; r += 1, i += 1)
          n[i] = e[r];
        return n;
      },
      s = function (e, t) {
        for (var n = ``, r = 0; r < e.length; r += 1)
          (n += e[r]), r + 1 < e.length && (n += t);
        return n;
      };
    t.exports = function (e) {
      var t = this;
      if (typeof t != `function` || n.apply(t) !== i)
        throw TypeError(`Function.prototype.bind called on incompatible ` + t);
      for (
        var c = o(arguments, 1),
          l,
          u = function () {
            if (this instanceof l) {
              var n = t.apply(this, a(c, arguments));
              return Object(n) === n ? n : this;
            }
            return t.apply(e, a(c, arguments));
          },
          d = r(0, t.length - c.length),
          f = [],
          p = 0;
        p < d;
        p++
      )
        f[p] = `$` + p;
      if (
        ((l = Function(
          `binder`,
          `return function (` +
            s(f, `,`) +
            `){ return binder.apply(this,arguments); }`
        )(u)),
        t.prototype)
      ) {
        var m = function () {};
        (m.prototype = t.prototype),
          (l.prototype = new m()),
          (m.prototype = null);
      }
      return l;
    };
  }),
  k = e((e, t) => {
    var n = O();
    t.exports = Function.prototype.bind || n;
  }),
  A = e((e, t) => {
    t.exports = Function.prototype.call;
  }),
  j = e((e, t) => {
    t.exports = Function.prototype.apply;
  }),
  M = e((e, t) => {
    t.exports = typeof Reflect < `u` && Reflect && Reflect.apply;
  }),
  N = e((e, t) => {
    var n = k(),
      r = j(),
      i = A();
    t.exports = M() || n.call(i, r);
  }),
  P = e((e, t) => {
    var n = k(),
      r = a(),
      i = A(),
      o = N();
    t.exports = function (e) {
      if (e.length < 1 || typeof e[0] != `function`)
        throw new r(`a function is required`);
      return o(n, i, e);
    };
  }),
  F = e((e, t) => {
    var n = P(),
      r = S(),
      i;
    try {
      i = [].__proto__ === Array.prototype;
    } catch (e) {
      if (
        !e ||
        typeof e != `object` ||
        !(`code` in e) ||
        e.code !== `ERR_PROTO_ACCESS`
      )
        throw e;
    }
    var a = !!i && r && r(Object.prototype, `__proto__`),
      o = Object,
      s = o.getPrototypeOf;
    t.exports =
      a && typeof a.get == `function`
        ? n([a.get])
        : typeof s == `function` &&
          function (e) {
            return s(e == null ? e : o(e));
          };
  }),
  I = e((e, t) => {
    var n = E(),
      r = D(),
      i = F();
    t.exports = n
      ? function (e) {
          return n(e);
        }
      : r
      ? function (e) {
          if (!e || (typeof e != `object` && typeof e != `function`))
            throw TypeError(`getProto: not an object`);
          return r(e);
        }
      : i
      ? function (e) {
          return i(e);
        }
      : null;
  }),
  L = e((e, t) => {
    var n = Function.prototype.call,
      r = Object.prototype.hasOwnProperty;
    t.exports = k().call(n, r);
  }),
  R = e((e, t) => {
    var n,
      r = o(),
      i = s(),
      y = c(),
      x = l(),
      w = u(),
      O = d(),
      M = a(),
      N = f(),
      P = p(),
      F = m(),
      R = h(),
      z = g(),
      B = _(),
      ee = v(),
      V = b(),
      H = Function,
      te = function (e) {
        try {
          return H(`"use strict"; return (` + e + `).constructor;`)();
        } catch {}
      },
      U = S(),
      ne = C(),
      W = function () {
        throw new M();
      },
      re = U
        ? (function () {
            try {
              return arguments.callee, W;
            } catch {
              try {
                return U(arguments, `callee`).get;
              } catch {
                return W;
              }
            }
          })()
        : W,
      G = T()(),
      K = I(),
      q = D(),
      J = E(),
      Y = j(),
      X = A(),
      Z = {},
      ie = typeof Uint8Array > `u` || !K ? n : K(Uint8Array),
      Q = {
        __proto__: null,
        "%AggregateError%": typeof AggregateError > `u` ? n : AggregateError,
        "%Array%": Array,
        "%ArrayBuffer%": typeof ArrayBuffer > `u` ? n : ArrayBuffer,
        "%ArrayIteratorPrototype%": G && K ? K([][Symbol.iterator]()) : n,
        "%AsyncFromSyncIteratorPrototype%": n,
        "%AsyncFunction%": Z,
        "%AsyncGenerator%": Z,
        "%AsyncGeneratorFunction%": Z,
        "%AsyncIteratorPrototype%": Z,
        "%Atomics%": typeof Atomics > `u` ? n : Atomics,
        "%BigInt%": typeof BigInt > `u` ? n : BigInt,
        "%BigInt64Array%": typeof BigInt64Array > `u` ? n : BigInt64Array,
        "%BigUint64Array%": typeof BigUint64Array > `u` ? n : BigUint64Array,
        "%Boolean%": Boolean,
        "%DataView%": typeof DataView > `u` ? n : DataView,
        "%Date%": Date,
        "%decodeURI%": decodeURI,
        "%decodeURIComponent%": decodeURIComponent,
        "%encodeURI%": encodeURI,
        "%encodeURIComponent%": encodeURIComponent,
        "%Error%": i,
        "%eval%": eval,
        "%EvalError%": y,
        "%Float16Array%": typeof Float16Array > `u` ? n : Float16Array,
        "%Float32Array%": typeof Float32Array > `u` ? n : Float32Array,
        "%Float64Array%": typeof Float64Array > `u` ? n : Float64Array,
        "%FinalizationRegistry%":
          typeof FinalizationRegistry > `u` ? n : FinalizationRegistry,
        "%Function%": H,
        "%GeneratorFunction%": Z,
        "%Int8Array%": typeof Int8Array > `u` ? n : Int8Array,
        "%Int16Array%": typeof Int16Array > `u` ? n : Int16Array,
        "%Int32Array%": typeof Int32Array > `u` ? n : Int32Array,
        "%isFinite%": isFinite,
        "%isNaN%": isNaN,
        "%IteratorPrototype%": G && K ? K(K([][Symbol.iterator]())) : n,
        "%JSON%": typeof JSON == `object` ? JSON : n,
        "%Map%": typeof Map > `u` ? n : Map,
        "%MapIteratorPrototype%":
          typeof Map > `u` || !G || !K ? n : K(new Map()[Symbol.iterator]()),
        "%Math%": Math,
        "%Number%": Number,
        "%Object%": r,
        "%Object.getOwnPropertyDescriptor%": U,
        "%parseFloat%": parseFloat,
        "%parseInt%": parseInt,
        "%Promise%": typeof Promise > `u` ? n : Promise,
        "%Proxy%": typeof Proxy > `u` ? n : Proxy,
        "%RangeError%": x,
        "%ReferenceError%": w,
        "%Reflect%": typeof Reflect > `u` ? n : Reflect,
        "%RegExp%": RegExp,
        "%Set%": typeof Set > `u` ? n : Set,
        "%SetIteratorPrototype%":
          typeof Set > `u` || !G || !K ? n : K(new Set()[Symbol.iterator]()),
        "%SharedArrayBuffer%":
          typeof SharedArrayBuffer > `u` ? n : SharedArrayBuffer,
        "%String%": String,
        "%StringIteratorPrototype%": G && K ? K(``[Symbol.iterator]()) : n,
        "%Symbol%": G ? Symbol : n,
        "%SyntaxError%": O,
        "%ThrowTypeError%": re,
        "%TypedArray%": ie,
        "%TypeError%": M,
        "%Uint8Array%": typeof Uint8Array > `u` ? n : Uint8Array,
        "%Uint8ClampedArray%":
          typeof Uint8ClampedArray > `u` ? n : Uint8ClampedArray,
        "%Uint16Array%": typeof Uint16Array > `u` ? n : Uint16Array,
        "%Uint32Array%": typeof Uint32Array > `u` ? n : Uint32Array,
        "%URIError%": N,
        "%WeakMap%": typeof WeakMap > `u` ? n : WeakMap,
        "%WeakRef%": typeof WeakRef > `u` ? n : WeakRef,
        "%WeakSet%": typeof WeakSet > `u` ? n : WeakSet,
        "%Function.prototype.call%": X,
        "%Function.prototype.apply%": Y,
        "%Object.defineProperty%": ne,
        "%Object.getPrototypeOf%": q,
        "%Math.abs%": P,
        "%Math.floor%": F,
        "%Math.max%": R,
        "%Math.min%": z,
        "%Math.pow%": B,
        "%Math.round%": ee,
        "%Math.sign%": V,
        "%Reflect.getPrototypeOf%": J,
      };
    if (K)
      try {
        null.error;
      } catch (e) {
        Q[`%Error.prototype%`] = K(K(e));
      }
    var ae = function e(t) {
        var n;
        if (t === `%AsyncFunction%`) n = te(`async function () {}`);
        else if (t === `%GeneratorFunction%`) n = te(`function* () {}`);
        else if (t === `%AsyncGeneratorFunction%`)
          n = te(`async function* () {}`);
        else if (t === `%AsyncGenerator%`) {
          var r = e(`%AsyncGeneratorFunction%`);
          r && (n = r.prototype);
        } else if (t === `%AsyncIteratorPrototype%`) {
          var i = e(`%AsyncGenerator%`);
          i && K && (n = K(i.prototype));
        }
        return (Q[t] = n), n;
      },
      oe = {
        __proto__: null,
        "%ArrayBufferPrototype%": [`ArrayBuffer`, `prototype`],
        "%ArrayPrototype%": [`Array`, `prototype`],
        "%ArrayProto_entries%": [`Array`, `prototype`, `entries`],
        "%ArrayProto_forEach%": [`Array`, `prototype`, `forEach`],
        "%ArrayProto_keys%": [`Array`, `prototype`, `keys`],
        "%ArrayProto_values%": [`Array`, `prototype`, `values`],
        "%AsyncFunctionPrototype%": [`AsyncFunction`, `prototype`],
        "%AsyncGenerator%": [`AsyncGeneratorFunction`, `prototype`],
        "%AsyncGeneratorPrototype%": [
          `AsyncGeneratorFunction`,
          `prototype`,
          `prototype`,
        ],
        "%BooleanPrototype%": [`Boolean`, `prototype`],
        "%DataViewPrototype%": [`DataView`, `prototype`],
        "%DatePrototype%": [`Date`, `prototype`],
        "%ErrorPrototype%": [`Error`, `prototype`],
        "%EvalErrorPrototype%": [`EvalError`, `prototype`],
        "%Float32ArrayPrototype%": [`Float32Array`, `prototype`],
        "%Float64ArrayPrototype%": [`Float64Array`, `prototype`],
        "%FunctionPrototype%": [`Function`, `prototype`],
        "%Generator%": [`GeneratorFunction`, `prototype`],
        "%GeneratorPrototype%": [`GeneratorFunction`, `prototype`, `prototype`],
        "%Int8ArrayPrototype%": [`Int8Array`, `prototype`],
        "%Int16ArrayPrototype%": [`Int16Array`, `prototype`],
        "%Int32ArrayPrototype%": [`Int32Array`, `prototype`],
        "%JSONParse%": [`JSON`, `parse`],
        "%JSONStringify%": [`JSON`, `stringify`],
        "%MapPrototype%": [`Map`, `prototype`],
        "%NumberPrototype%": [`Number`, `prototype`],
        "%ObjectPrototype%": [`Object`, `prototype`],
        "%ObjProto_toString%": [`Object`, `prototype`, `toString`],
        "%ObjProto_valueOf%": [`Object`, `prototype`, `valueOf`],
        "%PromisePrototype%": [`Promise`, `prototype`],
        "%PromiseProto_then%": [`Promise`, `prototype`, `then`],
        "%Promise_all%": [`Promise`, `all`],
        "%Promise_reject%": [`Promise`, `reject`],
        "%Promise_resolve%": [`Promise`, `resolve`],
        "%RangeErrorPrototype%": [`RangeError`, `prototype`],
        "%ReferenceErrorPrototype%": [`ReferenceError`, `prototype`],
        "%RegExpPrototype%": [`RegExp`, `prototype`],
        "%SetPrototype%": [`Set`, `prototype`],
        "%SharedArrayBufferPrototype%": [`SharedArrayBuffer`, `prototype`],
        "%StringPrototype%": [`String`, `prototype`],
        "%SymbolPrototype%": [`Symbol`, `prototype`],
        "%SyntaxErrorPrototype%": [`SyntaxError`, `prototype`],
        "%TypedArrayPrototype%": [`TypedArray`, `prototype`],
        "%TypeErrorPrototype%": [`TypeError`, `prototype`],
        "%Uint8ArrayPrototype%": [`Uint8Array`, `prototype`],
        "%Uint8ClampedArrayPrototype%": [`Uint8ClampedArray`, `prototype`],
        "%Uint16ArrayPrototype%": [`Uint16Array`, `prototype`],
        "%Uint32ArrayPrototype%": [`Uint32Array`, `prototype`],
        "%URIErrorPrototype%": [`URIError`, `prototype`],
        "%WeakMapPrototype%": [`WeakMap`, `prototype`],
        "%WeakSetPrototype%": [`WeakSet`, `prototype`],
      },
      $ = k(),
      se = L(),
      ce = $.call(X, Array.prototype.concat),
      le = $.call(Y, Array.prototype.splice),
      ue = $.call(X, String.prototype.replace),
      de = $.call(X, String.prototype.slice),
      fe = $.call(X, RegExp.prototype.exec),
      pe =
        /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,
      me = /\\(\\)?/g,
      he = function (e) {
        var t = de(e, 0, 1),
          n = de(e, -1);
        if (t === `%` && n !== `%`)
          throw new O("invalid intrinsic syntax, expected closing `%`");
        if (n === `%` && t !== `%`)
          throw new O("invalid intrinsic syntax, expected opening `%`");
        var r = [];
        return (
          ue(e, pe, function (e, t, n, i) {
            r[r.length] = n ? ue(i, me, `$1`) : t || e;
          }),
          r
        );
      },
      ge = function (e, t) {
        var n = e,
          r;
        if ((se(oe, n) && ((r = oe[n]), (n = `%` + r[0] + `%`)), se(Q, n))) {
          var i = Q[n];
          if ((i === Z && (i = ae(n)), i === void 0 && !t))
            throw new M(
              `intrinsic ` +
                e +
                ` exists, but is not available. Please file an issue!`
            );
          return { alias: r, name: n, value: i };
        }
        throw new O(`intrinsic ` + e + ` does not exist!`);
      };
    t.exports = function (e, t) {
      if (typeof e != `string` || e.length === 0)
        throw new M(`intrinsic name must be a non-empty string`);
      if (arguments.length > 1 && typeof t != `boolean`)
        throw new M(`"allowMissing" argument must be a boolean`);
      if (fe(/^%?[^%]*%?$/, e) === null)
        throw new O(
          "`%` may not be present anywhere but at the beginning and end of the intrinsic name"
        );
      var n = he(e),
        r = n.length > 0 ? n[0] : ``,
        i = ge(`%` + r + `%`, t),
        a = i.name,
        o = i.value,
        s = !1,
        c = i.alias;
      c && ((r = c[0]), le(n, ce([0, 1], c)));
      for (var l = 1, u = !0; l < n.length; l += 1) {
        var d = n[l],
          f = de(d, 0, 1),
          p = de(d, -1);
        if (
          (f === `"` ||
            f === `'` ||
            f === "`" ||
            p === `"` ||
            p === `'` ||
            p === "`") &&
          f !== p
        )
          throw new O(`property names with quotes must have matching quotes`);
        if (
          ((d === `constructor` || !u) && (s = !0),
          (r += `.` + d),
          (a = `%` + r + `%`),
          se(Q, a))
        )
          o = Q[a];
        else if (o != null) {
          if (!(d in o)) {
            if (!t)
              throw new M(
                `base intrinsic for ` +
                  e +
                  ` exists, but the property is not available.`
              );
            return;
          }
          if (U && l + 1 >= n.length) {
            var m = U(o, d);
            (u = !!m),
              (o =
                u && `get` in m && !(`originalValue` in m.get) ? m.get : o[d]);
          } else (u = se(o, d)), (o = o[d]);
          u && !s && (Q[a] = o);
        }
      }
      return o;
    };
  }),
  z = e((e, t) => {
    var n = R(),
      r = P(),
      i = r([n(`%String.prototype.indexOf%`)]);
    t.exports = function (e, t) {
      var a = n(e, !!t);
      return typeof a == `function` && i(e, `.prototype.`) > -1 ? r([a]) : a;
    };
  }),
  B = e((e, t) => {
    var n = w();
    t.exports = function () {
      return n() && !!Symbol.toStringTag;
    };
  }),
  ee = e((e, t) => {
    var n = B()(),
      r = z()(`Object.prototype.toString`),
      i = function (e) {
        return n && e && typeof e == `object` && Symbol.toStringTag in e
          ? !1
          : r(e) === `[object Arguments]`;
      },
      a = function (e) {
        return i(e)
          ? !0
          : typeof e == `object` &&
              !!e &&
              `length` in e &&
              typeof e.length == `number` &&
              e.length >= 0 &&
              r(e) !== `[object Array]` &&
              `callee` in e &&
              r(e.callee) === `[object Function]`;
      },
      o = (function () {
        return i(arguments);
      })();
    (i.isLegacyArguments = a), (t.exports = o ? i : a);
  }),
  V = e((e, t) => {
    var n = z(),
      r = B()(),
      i = L(),
      a = S(),
      o;
    if (r) {
      var s = n(`RegExp.prototype.exec`),
        c = {},
        l = function () {
          throw c;
        },
        u = { toString: l, valueOf: l };
      typeof Symbol.toPrimitive == `symbol` && (u[Symbol.toPrimitive] = l),
        (o = function (e) {
          if (!e || typeof e != `object`) return !1;
          var t = a(e, `lastIndex`);
          if (!(t && i(t, `value`))) return !1;
          try {
            s(e, u);
          } catch (e) {
            return e === c;
          }
        });
    } else {
      var d = n(`Object.prototype.toString`),
        f = `[object RegExp]`;
      o = function (e) {
        return !e || (typeof e != `object` && typeof e != `function`)
          ? !1
          : d(e) === f;
      };
    }
    t.exports = o;
  }),
  H = e((e, t) => {
    var n = z(),
      r = V(),
      i = n(`RegExp.prototype.exec`),
      o = a();
    t.exports = function (e) {
      if (!r(e)) throw new o("`regex` must be a RegExp");
      return function (t) {
        return i(e, t) !== null;
      };
    };
  }),
  te = e((e, t) => {
    var n = z(),
      r = H()(/^\s*(?:function)?\*/),
      i = B()(),
      a = I(),
      o = n(`Object.prototype.toString`),
      s = n(`Function.prototype.toString`),
      c = function () {
        if (!i) return !1;
        try {
          return Function(`return function*() {}`)();
        } catch {}
      },
      l;
    t.exports = function (e) {
      if (typeof e != `function`) return !1;
      if (r(s(e))) return !0;
      if (!i) return o(e) === `[object GeneratorFunction]`;
      if (!a) return !1;
      if (l === void 0) {
        var t = c();
        l = t ? a(t) : !1;
      }
      return a(e) === l;
    };
  }),
  U = e((e, t) => {
    var n = Function.prototype.toString,
      r = typeof Reflect == `object` && Reflect !== null && Reflect.apply,
      i,
      a;
    if (typeof r == `function` && typeof Object.defineProperty == `function`)
      try {
        (i = Object.defineProperty({}, "length", {
          get: function () {
            throw a;
          },
        })),
          (a = {}),
          r(
            function () {
              throw 42;
            },
            null,
            i
          );
      } catch (e) {
        e !== a && (r = null);
      }
    else r = null;
    var o = /^\s*class\b/,
      s = function (e) {
        try {
          var t = n.call(e);
          return o.test(t);
        } catch {
          return !1;
        }
      },
      c = function (e) {
        try {
          return !s(e) && (n.call(e), !0);
        } catch {
          return !1;
        }
      },
      l = Object.prototype.toString,
      u = `[object Object]`,
      d = `[object Function]`,
      f = `[object GeneratorFunction]`,
      p = `[object HTMLAllCollection]`,
      m = `[object HTML document.all class]`,
      h = `[object HTMLCollection]`,
      g = typeof Symbol == `function` && !!Symbol.toStringTag,
      _ = !(0 in [,]),
      v = function () {
        return !1;
      };
    if (typeof document == `object`) {
      var y = document.all;
      l.call(y) === l.call(document.all) &&
        (v = function (e) {
          if ((_ || !e) && (e === void 0 || typeof e == `object`))
            try {
              var t = l.call(e);
              return (
                (t === p || t === m || t === h || t === u) && e(``) == null
              );
            } catch {}
          return !1;
        });
    }
    t.exports = r
      ? function (e) {
          if (v(e)) return !0;
          if (!e || (typeof e != `function` && typeof e != `object`)) return !1;
          try {
            r(e, null, i);
          } catch (e) {
            if (e !== a) return !1;
          }
          return !s(e) && c(e);
        }
      : function (e) {
          if (v(e)) return !0;
          if (!e || (typeof e != `function` && typeof e != `object`)) return !1;
          if (g) return c(e);
          if (s(e)) return !1;
          var t = l.call(e);
          return t !== d && t !== f && !/^\[object HTML/.test(t) ? !1 : c(e);
        };
  }),
  ne = e((e, t) => {
    var n = U(),
      r = Object.prototype.toString,
      i = Object.prototype.hasOwnProperty,
      a = function (e, t, n) {
        for (var r = 0, a = e.length; r < a; r++)
          i.call(e, r) && (n == null ? t(e[r], r, e) : t.call(n, e[r], r, e));
      },
      o = function (e, t, n) {
        for (var r = 0, i = e.length; r < i; r++)
          n == null ? t(e.charAt(r), r, e) : t.call(n, e.charAt(r), r, e);
      },
      s = function (e, t, n) {
        for (var r in e)
          i.call(e, r) && (n == null ? t(e[r], r, e) : t.call(n, e[r], r, e));
      };
    function c(e) {
      return r.call(e) === `[object Array]`;
    }
    t.exports = function (e, t, r) {
      if (!n(t)) throw TypeError(`iterator must be a function`);
      var i;
      arguments.length >= 3 && (i = r),
        c(e) ? a(e, t, i) : typeof e == `string` ? o(e, t, i) : s(e, t, i);
    };
  }),
  W = e((e, t) => {
    t.exports = [
      `Float16Array`,
      `Float32Array`,
      `Float64Array`,
      `Int8Array`,
      `Int16Array`,
      `Int32Array`,
      `Uint8Array`,
      `Uint8ClampedArray`,
      `Uint16Array`,
      `Uint32Array`,
      `BigInt64Array`,
      `BigUint64Array`,
    ];
  }),
  re = e((e, r) => {
    t();
    var i = W(),
      a = typeof globalThis > `u` ? n : globalThis;
    r.exports = function () {
      for (var e = [], t = 0; t < i.length; t++)
        typeof a[i[t]] == `function` && (e[e.length] = i[t]);
      return e;
    };
  }),
  G = e((e, t) => {
    var n = C(),
      r = d(),
      i = a(),
      o = S();
    t.exports = function (e, t, a) {
      if (!e || (typeof e != `object` && typeof e != `function`))
        throw new i("`obj` must be an object or a function`");
      if (typeof t != `string` && typeof t != `symbol`)
        throw new i("`property` must be a string or a symbol`");
      if (
        arguments.length > 3 &&
        typeof arguments[3] != `boolean` &&
        arguments[3] !== null
      )
        throw new i("`nonEnumerable`, if provided, must be a boolean or null");
      if (
        arguments.length > 4 &&
        typeof arguments[4] != `boolean` &&
        arguments[4] !== null
      )
        throw new i("`nonWritable`, if provided, must be a boolean or null");
      if (
        arguments.length > 5 &&
        typeof arguments[5] != `boolean` &&
        arguments[5] !== null
      )
        throw new i(
          "`nonConfigurable`, if provided, must be a boolean or null"
        );
      if (arguments.length > 6 && typeof arguments[6] != `boolean`)
        throw new i("`loose`, if provided, must be a boolean");
      var s = arguments.length > 3 ? arguments[3] : null,
        c = arguments.length > 4 ? arguments[4] : null,
        l = arguments.length > 5 ? arguments[5] : null,
        u = arguments.length > 6 && arguments[6],
        d = !!o && o(e, t);
      if (n)
        n(e, t, {
          configurable: l === null && d ? d.configurable : !l,
          enumerable: s === null && d ? d.enumerable : !s,
          value: a,
          writable: c === null && d ? d.writable : !c,
        });
      else if (u || (!s && !c && !l)) e[t] = a;
      else
        throw new r(
          `This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.`
        );
    };
  }),
  K = e((e, t) => {
    var n = C(),
      r = function () {
        return !!n;
      };
    (r.hasArrayLengthDefineBug = function () {
      if (!n) return null;
      try {
        return n([], `length`, { value: 1 }).length !== 1;
      } catch {
        return !0;
      }
    }),
      (t.exports = r);
  }),
  q = e((e, t) => {
    var n = R(),
      r = G(),
      i = K()(),
      o = S(),
      s = a(),
      c = n(`%Math.floor%`);
    t.exports = function (e, t) {
      if (typeof e != `function`) throw new s("`fn` is not a function");
      if (typeof t != `number` || t < 0 || t > 4294967295 || c(t) !== t)
        throw new s("`length` must be a positive 32-bit integer");
      var n = arguments.length > 2 && !!arguments[2],
        a = !0,
        l = !0;
      if (`length` in e && o) {
        var u = o(e, `length`);
        u && !u.configurable && (a = !1), u && !u.writable && (l = !1);
      }
      return (
        (a || l || !n) && (i ? r(e, `length`, t, !0, !0) : r(e, `length`, t)), e
      );
    };
  }),
  J = e((e, t) => {
    var n = k(),
      r = j(),
      i = N();
    t.exports = function () {
      return i(n, r, arguments);
    };
  }),
  Y = e((e, t) => {
    var n = q(),
      r = C(),
      i = P(),
      a = J();
    (t.exports = function (e) {
      var t = i(arguments),
        r = e.length - (arguments.length - 1);
      return n(t, 1 + (r > 0 ? r : 0), !0);
    }),
      r ? r(t.exports, `apply`, { value: a }) : (t.exports.apply = a);
  }),
  X = e((e, r) => {
    t();
    var i = ne(),
      a = re(),
      o = Y(),
      s = z(),
      c = S(),
      l = I(),
      u = s(`Object.prototype.toString`),
      d = B()(),
      f = typeof globalThis > `u` ? n : globalThis,
      p = a(),
      m = s(`String.prototype.slice`),
      h =
        s(`Array.prototype.indexOf`, !0) ||
        function (e, t) {
          for (var n = 0; n < e.length; n += 1) if (e[n] === t) return n;
          return -1;
        },
      g = { __proto__: null };
    d && c && l
      ? i(p, function (e) {
          var t = new f[e]();
          if (Symbol.toStringTag in t && l) {
            var n = l(t),
              r = c(n, Symbol.toStringTag);
            !r && n && (r = c(l(n), Symbol.toStringTag)),
              (g[`$` + e] = o(r.get));
          }
        })
      : i(p, function (e) {
          var t = new f[e](),
            n = t.slice || t.set;
          n && (g[`$` + e] = o(n));
        });
    var _ = function (e) {
        var t = !1;
        return (
          i(g, function (n, r) {
            if (!t)
              try {
                `$` + n(e) === r && (t = m(r, 1));
              } catch {}
          }),
          t
        );
      },
      v = function (e) {
        var t = !1;
        return (
          i(g, function (n, r) {
            if (!t)
              try {
                n(e), (t = m(r, 1));
              } catch {}
          }),
          t
        );
      };
    r.exports = function (e) {
      if (!e || typeof e != `object`) return !1;
      if (!d) {
        var t = m(u(e), 8, -1);
        return h(p, t) > -1 ? t : t === `Object` && v(e);
      }
      return c ? _(e) : null;
    };
  }),
  Z = e((e, t) => {
    var n = X();
    t.exports = function (e) {
      return !!n(e);
    };
  }),
  ie = e((e) => {
    var t = ee(),
      n = te(),
      r = X(),
      i = Z();
    function a(e) {
      return e.call.bind(e);
    }
    var o = typeof BigInt < `u`,
      s = typeof Symbol < `u`,
      c = a(Object.prototype.toString),
      l = a(Number.prototype.valueOf),
      u = a(String.prototype.valueOf),
      d = a(Boolean.prototype.valueOf);
    if (o) var f = a(BigInt.prototype.valueOf);
    if (s) var p = a(Symbol.prototype.valueOf);
    function m(e, t) {
      if (typeof e != `object`) return !1;
      try {
        return t(e), !0;
      } catch {
        return !1;
      }
    }
    (e.isArgumentsObject = t),
      (e.isGeneratorFunction = n),
      (e.isTypedArray = i);
    function h(e) {
      return (
        (typeof Promise < `u` && e instanceof Promise) ||
        (typeof e == `object` &&
          !!e &&
          typeof e.then == `function` &&
          typeof e.catch == `function`)
      );
    }
    e.isPromise = h;
    function g(e) {
      return typeof ArrayBuffer < `u` && ArrayBuffer.isView
        ? ArrayBuffer.isView(e)
        : i(e) || z(e);
    }
    e.isArrayBufferView = g;
    function _(e) {
      return r(e) === `Uint8Array`;
    }
    e.isUint8Array = _;
    function v(e) {
      return r(e) === `Uint8ClampedArray`;
    }
    e.isUint8ClampedArray = v;
    function y(e) {
      return r(e) === `Uint16Array`;
    }
    e.isUint16Array = y;
    function b(e) {
      return r(e) === `Uint32Array`;
    }
    e.isUint32Array = b;
    function x(e) {
      return r(e) === `Int8Array`;
    }
    e.isInt8Array = x;
    function S(e) {
      return r(e) === `Int16Array`;
    }
    e.isInt16Array = S;
    function C(e) {
      return r(e) === `Int32Array`;
    }
    e.isInt32Array = C;
    function w(e) {
      return r(e) === `Float32Array`;
    }
    e.isFloat32Array = w;
    function T(e) {
      return r(e) === `Float64Array`;
    }
    e.isFloat64Array = T;
    function E(e) {
      return r(e) === `BigInt64Array`;
    }
    e.isBigInt64Array = E;
    function D(e) {
      return r(e) === `BigUint64Array`;
    }
    e.isBigUint64Array = D;
    function O(e) {
      return c(e) === `[object Map]`;
    }
    O.working = typeof Map < `u` && O(new Map());
    function k(e) {
      return typeof Map > `u` ? !1 : O.working ? O(e) : e instanceof Map;
    }
    e.isMap = k;
    function A(e) {
      return c(e) === `[object Set]`;
    }
    A.working = typeof Set < `u` && A(new Set());
    function j(e) {
      return typeof Set > `u` ? !1 : A.working ? A(e) : e instanceof Set;
    }
    e.isSet = j;
    function M(e) {
      return c(e) === `[object WeakMap]`;
    }
    M.working = typeof WeakMap < `u` && M(new WeakMap());
    function N(e) {
      return typeof WeakMap > `u`
        ? !1
        : M.working
        ? M(e)
        : e instanceof WeakMap;
    }
    e.isWeakMap = N;
    function P(e) {
      return c(e) === `[object WeakSet]`;
    }
    P.working = typeof WeakSet < `u` && P(new WeakSet());
    function F(e) {
      return P(e);
    }
    e.isWeakSet = F;
    function I(e) {
      return c(e) === `[object ArrayBuffer]`;
    }
    I.working = typeof ArrayBuffer < `u` && I(new ArrayBuffer());
    function L(e) {
      return typeof ArrayBuffer > `u`
        ? !1
        : I.working
        ? I(e)
        : e instanceof ArrayBuffer;
    }
    e.isArrayBuffer = L;
    function R(e) {
      return c(e) === `[object DataView]`;
    }
    R.working =
      typeof ArrayBuffer < `u` &&
      typeof DataView < `u` &&
      R(new DataView(new ArrayBuffer(1), 0, 1));
    function z(e) {
      return typeof DataView > `u`
        ? !1
        : R.working
        ? R(e)
        : e instanceof DataView;
    }
    e.isDataView = z;
    var B = typeof SharedArrayBuffer < `u` ? SharedArrayBuffer : void 0;
    function V(e) {
      return c(e) === `[object SharedArrayBuffer]`;
    }
    function H(e) {
      return (
        B !== void 0 &&
        (V.working === void 0 && (V.working = V(new B())),
        V.working ? V(e) : e instanceof B)
      );
    }
    e.isSharedArrayBuffer = H;
    function U(e) {
      return c(e) === `[object AsyncFunction]`;
    }
    e.isAsyncFunction = U;
    function ne(e) {
      return c(e) === `[object Map Iterator]`;
    }
    e.isMapIterator = ne;
    function W(e) {
      return c(e) === `[object Set Iterator]`;
    }
    e.isSetIterator = W;
    function re(e) {
      return c(e) === `[object Generator]`;
    }
    e.isGeneratorObject = re;
    function G(e) {
      return c(e) === `[object WebAssembly.Module]`;
    }
    e.isWebAssemblyCompiledModule = G;
    function K(e) {
      return m(e, l);
    }
    e.isNumberObject = K;
    function q(e) {
      return m(e, u);
    }
    e.isStringObject = q;
    function J(e) {
      return m(e, d);
    }
    e.isBooleanObject = J;
    function Y(e) {
      return o && m(e, f);
    }
    e.isBigIntObject = Y;
    function ie(e) {
      return s && m(e, p);
    }
    e.isSymbolObject = ie;
    function Q(e) {
      return K(e) || q(e) || J(e) || Y(e) || ie(e);
    }
    e.isBoxedPrimitive = Q;
    function ae(e) {
      return typeof Uint8Array < `u` && (L(e) || H(e));
    }
    (e.isAnyArrayBuffer = ae),
      [`isProxy`, `isExternal`, `isModuleNamespaceObject`].forEach(function (
        t
      ) {
        Object.defineProperty(e, t, {
          enumerable: !1,
          value: function () {
            throw Error(t + ` is not supported in userland`);
          },
        });
      });
  }),
  Q = e((e, t) => {
    t.exports = function (e) {
      return (
        e &&
        typeof e == `object` &&
        typeof e.copy == `function` &&
        typeof e.fill == `function` &&
        typeof e.readUInt8 == `function`
      );
    };
  }),
  ae = e((e, t) => {
    t.exports =
      typeof Object.create == `function`
        ? function (e, t) {
            t &&
              ((e.super_ = t),
              (e.prototype = Object.create(t.prototype, {
                constructor: {
                  value: e,
                  enumerable: !1,
                  writable: !0,
                  configurable: !0,
                },
              })));
          }
        : function (e, t) {
            if (t) {
              e.super_ = t;
              var n = function () {};
              (n.prototype = t.prototype),
                (e.prototype = new n()),
                (e.prototype.constructor = e);
            }
          };
  }),
  oe = e((e) => {
    i();
    var t =
        Object.getOwnPropertyDescriptors ||
        function (e) {
          for (var t = Object.keys(e), n = {}, r = 0; r < t.length; r++)
            n[t[r]] = Object.getOwnPropertyDescriptor(e, t[r]);
          return n;
        },
      n = /%[sdj%]/g;
    (e.format = function (e) {
      if (!C(e)) {
        for (var t = [], r = 0; r < arguments.length; r++)
          t.push(c(arguments[r]));
        return t.join(` `);
      }
      for (
        var r = 1,
          i = arguments,
          a = i.length,
          o = String(e).replace(n, function (e) {
            if (e === `%%`) return `%`;
            if (r >= a) return e;
            switch (e) {
              case `%s`:
                return String(i[r++]);
              case `%d`:
                return Number(i[r++]);
              case `%j`:
                try {
                  return JSON.stringify(i[r++]);
                } catch {
                  return `[Circular]`;
                }
              default:
                return e;
            }
          }),
          s = i[r];
        r < a;
        s = i[++r]
      )
        b(s) || !D(s) ? (o += ` ` + s) : (o += ` ` + c(s));
      return o;
    }),
      (e.deprecate = function (t, n) {
        if (r !== void 0 && r.noDeprecation === !0) return t;
        if (r === void 0)
          return function () {
            return e.deprecate(t, n).apply(this, arguments);
          };
        var i = !1;
        function a() {
          if (!i) {
            if (r.throwDeprecation) throw Error(n);
            r.traceDeprecation ? console.trace(n) : console.error(n), (i = !0);
          }
          return t.apply(this, arguments);
        }
        return a;
      });
    var a = {},
      o = /^$/;
    if ({}.NODE_DEBUG) {
      var s = {}.NODE_DEBUG;
      (s = s
        .replace(/[|\\{}()[\]^$+?.]/g, `\\$&`)
        .replace(/\*/g, `.*`)
        .replace(/,/g, `$|^`)
        .toUpperCase()),
        (o = RegExp(`^` + s + `$`, `i`));
    }
    e.debuglog = function (t) {
      if (((t = t.toUpperCase()), !a[t])) {
        if (o.test(t)) {
          var n = r.pid;
          a[t] = function () {
            var r = e.format.apply(e, arguments);
            console.error(`%s %d: %s`, t, n, r);
          };
        } else a[t] = function () {};
      }
      return a[t];
    };
    function c(t, n) {
      var r = { seen: [], stylize: u };
      return (
        arguments.length >= 3 && (r.depth = arguments[2]),
        arguments.length >= 4 && (r.colors = arguments[3]),
        y(n) ? (r.showHidden = n) : n && e._extend(r, n),
        T(r.showHidden) && (r.showHidden = !1),
        T(r.depth) && (r.depth = 2),
        T(r.colors) && (r.colors = !1),
        T(r.customInspect) && (r.customInspect = !0),
        r.colors && (r.stylize = l),
        f(r, t, r.depth)
      );
    }
    (e.inspect = c),
      (c.colors = {
        bold: [1, 22],
        italic: [3, 23],
        underline: [4, 24],
        inverse: [7, 27],
        white: [37, 39],
        grey: [90, 39],
        black: [30, 39],
        blue: [34, 39],
        cyan: [36, 39],
        green: [32, 39],
        magenta: [35, 39],
        red: [31, 39],
        yellow: [33, 39],
      }),
      (c.styles = {
        special: `cyan`,
        number: `yellow`,
        boolean: `yellow`,
        undefined: `grey`,
        null: `bold`,
        string: `green`,
        date: `magenta`,
        regexp: `red`,
      });
    function l(e, t) {
      var n = c.styles[t];
      return n
        ? `\x1B[` + c.colors[n][0] + `m` + e + `\x1B[` + c.colors[n][1] + `m`
        : e;
    }
    function u(e, t) {
      return e;
    }
    function d(e) {
      var t = {};
      return (
        e.forEach(function (e, n) {
          t[e] = !0;
        }),
        t
      );
    }
    function f(t, n, r) {
      if (
        t.customInspect &&
        n &&
        A(n.inspect) &&
        n.inspect !== e.inspect &&
        !(n.constructor && n.constructor.prototype === n)
      ) {
        var i = n.inspect(r, t);
        return C(i) || (i = f(t, i, r)), i;
      }
      var a = p(t, n);
      if (a) return a;
      var o = Object.keys(n),
        s = d(o);
      if (
        (t.showHidden && (o = Object.getOwnPropertyNames(n)),
        k(n) && (o.indexOf(`message`) >= 0 || o.indexOf(`description`) >= 0))
      )
        return m(n);
      if (o.length === 0) {
        if (A(n)) {
          var c = n.name ? `: ` + n.name : ``;
          return t.stylize(`[Function` + c + `]`, `special`);
        }
        if (E(n)) return t.stylize(RegExp.prototype.toString.call(n), `regexp`);
        if (O(n)) return t.stylize(Date.prototype.toString.call(n), `date`);
        if (k(n)) return m(n);
      }
      var l = ``,
        u = !1,
        y = [`{`, `}`];
      if (
        (v(n) && ((u = !0), (y = [`[`, `]`])),
        A(n) && (l = ` [Function` + (n.name ? `: ` + n.name : ``) + `]`),
        E(n) && (l = ` ` + RegExp.prototype.toString.call(n)),
        O(n) && (l = ` ` + Date.prototype.toUTCString.call(n)),
        k(n) && (l = ` ` + m(n)),
        o.length === 0 && (!u || n.length == 0))
      )
        return y[0] + l + y[1];
      if (r < 0)
        return E(n)
          ? t.stylize(RegExp.prototype.toString.call(n), `regexp`)
          : t.stylize(`[Object]`, `special`);
      t.seen.push(n);
      var b = u
        ? h(t, n, r, s, o)
        : o.map(function (e) {
            return g(t, n, r, s, e, u);
          });
      return t.seen.pop(), _(b, l, y);
    }
    function p(e, t) {
      if (T(t)) return e.stylize(`undefined`, `undefined`);
      if (C(t)) {
        var n =
          `'` +
          JSON.stringify(t)
            .replace(/^"|"$/g, ``)
            .replace(/'/g, `\\'`)
            .replace(/\\"/g, `"`) +
          `'`;
        return e.stylize(n, `string`);
      }
      if (S(t)) return e.stylize(`` + t, `number`);
      if (y(t)) return e.stylize(`` + t, `boolean`);
      if (b(t)) return e.stylize(`null`, `null`);
    }
    function m(e) {
      return `[` + Error.prototype.toString.call(e) + `]`;
    }
    function h(e, t, n, r, i) {
      for (var a = [], o = 0, s = t.length; o < s; ++o)
        I(t, String(o)) ? a.push(g(e, t, n, r, String(o), !0)) : a.push(``);
      return (
        i.forEach(function (i) {
          i.match(/^\d+$/) || a.push(g(e, t, n, r, i, !0));
        }),
        a
      );
    }
    function g(e, t, n, r, i, a) {
      var o,
        s,
        c = Object.getOwnPropertyDescriptor(t, i) || { value: t[i] };
      if (
        (c.get
          ? (s = c.set
              ? e.stylize(`[Getter/Setter]`, `special`)
              : e.stylize(`[Getter]`, `special`))
          : c.set && (s = e.stylize(`[Setter]`, `special`)),
        I(r, i) || (o = `[` + i + `]`),
        s ||
          (e.seen.indexOf(c.value) < 0
            ? ((s = b(n) ? f(e, c.value, null) : f(e, c.value, n - 1)),
              s.indexOf(`
`) > -1 &&
                (s = a
                  ? s
                      .split(
                        `
`
                      )
                      .map(function (e) {
                        return `  ` + e;
                      })
                      .join(
                        `
`
                      )
                      .slice(2)
                  : `
` +
                    s
                      .split(
                        `
`
                      )
                      .map(function (e) {
                        return `   ` + e;
                      }).join(`
`)))
            : (s = e.stylize(`[Circular]`, `special`))),
        T(o))
      ) {
        if (a && i.match(/^\d+$/)) return s;
        (o = JSON.stringify(`` + i)),
          o.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)
            ? ((o = o.slice(1, -1)), (o = e.stylize(o, `name`)))
            : ((o = o
                .replace(/'/g, `\\'`)
                .replace(/\\"/g, `"`)
                .replace(/(^"|"$)/g, `'`)),
              (o = e.stylize(o, `string`)));
      }
      return o + `: ` + s;
    }
    function _(e, t, n) {
      var r = 0;
      return e.reduce(function (e, t) {
        return (
          r++,
          t.indexOf(`
`) >= 0 && r++,
          e + t.replace(/\u001b\[\d\d?m/g, ``).length + 1
        );
      }, 0) > 60
        ? n[0] +
            (t === ``
              ? ``
              : t +
                `
 `) +
            ` ` +
            e.join(`,
  `) +
            ` ` +
            n[1]
        : n[0] + t + ` ` + e.join(`, `) + ` ` + n[1];
    }
    e.types = ie();
    function v(e) {
      return Array.isArray(e);
    }
    e.isArray = v;
    function y(e) {
      return typeof e == `boolean`;
    }
    e.isBoolean = y;
    function b(e) {
      return e === null;
    }
    e.isNull = b;
    function x(e) {
      return e == null;
    }
    e.isNullOrUndefined = x;
    function S(e) {
      return typeof e == `number`;
    }
    e.isNumber = S;
    function C(e) {
      return typeof e == `string`;
    }
    e.isString = C;
    function w(e) {
      return typeof e == `symbol`;
    }
    e.isSymbol = w;
    function T(e) {
      return e === void 0;
    }
    e.isUndefined = T;
    function E(e) {
      return D(e) && M(e) === `[object RegExp]`;
    }
    (e.isRegExp = E), (e.types.isRegExp = E);
    function D(e) {
      return typeof e == `object` && !!e;
    }
    e.isObject = D;
    function O(e) {
      return D(e) && M(e) === `[object Date]`;
    }
    (e.isDate = O), (e.types.isDate = O);
    function k(e) {
      return D(e) && (M(e) === `[object Error]` || e instanceof Error);
    }
    (e.isError = k), (e.types.isNativeError = k);
    function A(e) {
      return typeof e == `function`;
    }
    e.isFunction = A;
    function j(e) {
      return (
        e === null ||
        typeof e == `boolean` ||
        typeof e == `number` ||
        typeof e == `string` ||
        typeof e == `symbol` ||
        e === void 0
      );
    }
    (e.isPrimitive = j), (e.isBuffer = Q());
    function M(e) {
      return Object.prototype.toString.call(e);
    }
    function N(e) {
      return e < 10 ? `0` + e.toString(10) : e.toString(10);
    }
    var P = [
      `Jan`,
      `Feb`,
      `Mar`,
      `Apr`,
      `May`,
      `Jun`,
      `Jul`,
      `Aug`,
      `Sep`,
      `Oct`,
      `Nov`,
      `Dec`,
    ];
    function F() {
      var e = new Date(),
        t = [N(e.getHours()), N(e.getMinutes()), N(e.getSeconds())].join(`:`);
      return [e.getDate(), P[e.getMonth()], t].join(` `);
    }
    (e.log = function () {
      console.log(`%s - %s`, F(), e.format.apply(e, arguments));
    }),
      (e.inherits = ae()),
      (e._extend = function (e, t) {
        if (!t || !D(t)) return e;
        for (var n = Object.keys(t), r = n.length; r--; ) e[n[r]] = t[n[r]];
        return e;
      });
    function I(e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }
    var L = typeof Symbol < `u` ? Symbol(`util.promisify.custom`) : void 0;
    (e.promisify = function (e) {
      if (typeof e != `function`)
        throw TypeError(`The "original" argument must be of type Function`);
      if (L && e[L]) {
        var n = e[L];
        if (typeof n != `function`)
          throw TypeError(
            `The "util.promisify.custom" argument must be of type Function`
          );
        return (
          Object.defineProperty(n, L, {
            value: n,
            enumerable: !1,
            writable: !1,
            configurable: !0,
          }),
          n
        );
      }
      function n() {
        for (
          var t,
            n,
            r = new Promise(function (e, r) {
              (t = e), (n = r);
            }),
            i = [],
            a = 0;
          a < arguments.length;
          a++
        )
          i.push(arguments[a]);
        i.push(function (e, r) {
          e ? n(e) : t(r);
        });
        try {
          e.apply(this, i);
        } catch (e) {
          n(e);
        }
        return r;
      }
      return (
        Object.setPrototypeOf(n, Object.getPrototypeOf(e)),
        L &&
          Object.defineProperty(n, L, {
            value: n,
            enumerable: !1,
            writable: !1,
            configurable: !0,
          }),
        Object.defineProperties(n, t(e))
      );
    }),
      (e.promisify.custom = L);
    function R(e, t) {
      if (!e) {
        var n = Error(`Promise was rejected with a falsy value`);
        (n.reason = e), (e = n);
      }
      return t(e);
    }
    function z(e) {
      if (typeof e != `function`)
        throw TypeError(`The "original" argument must be of type Function`);
      function n() {
        for (var t = [], n = 0; n < arguments.length; n++) t.push(arguments[n]);
        var i = t.pop();
        if (typeof i != `function`)
          throw TypeError(`The last argument must be of type Function`);
        var a = this,
          o = function () {
            return i.apply(a, arguments);
          };
        e.apply(this, t).then(
          function (e) {
            r.nextTick(o.bind(null, null, e));
          },
          function (e) {
            r.nextTick(R.bind(null, e, o));
          }
        );
      }
      return (
        Object.setPrototypeOf(n, Object.getPrototypeOf(e)),
        Object.defineProperties(n, t(e)),
        n
      );
    }
    e.callbackify = z;
  });
export {
  K as a,
  R as c,
  a as d,
  Y as i,
  w as l,
  ae as n,
  G as o,
  Z as r,
  z as s,
  oe as t,
  o as u,
};
