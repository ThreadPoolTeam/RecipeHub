import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { J as n, _ as r } from "./Compact-CRRKXVA1.js";
import { t as i } from "./useForceUpdate-C1dOModk.js";
var a = e(t()),
  o = (e, t) => {
    (e == null ? void 0 : e.addEventListener) === void 0
      ? (e == null ? void 0 : e.addListener) !== void 0 && e.addListener(t)
      : e.addEventListener(`change`, t);
  },
  s = (e, t) => {
    (e == null ? void 0 : e.removeEventListener) === void 0
      ? (e == null ? void 0 : e.removeListener) !== void 0 &&
        e.removeListener(t)
      : e.removeEventListener(`change`, t);
  },
  c = [`xxl`, `xl`, `lg`, `md`, `sm`, `xs`],
  l = (e) => ({
    xs: `(max-width: ${e.screenXSMax}px)`,
    sm: `(min-width: ${e.screenSM}px)`,
    md: `(min-width: ${e.screenMD}px)`,
    lg: `(min-width: ${e.screenLG}px)`,
    xl: `(min-width: ${e.screenXL}px)`,
    xxl: `(min-width: ${e.screenXXL}px)`,
  }),
  u = (e) => {
    let t = e,
      n = [].concat(c).reverse();
    return (
      n.forEach((e, r) => {
        let i = e.toUpperCase(),
          a = `screen${i}Min`,
          o = `screen${i}`;
        if (!(t[a] <= t[o]))
          throw Error(`${a}<=${o} fails : !(${t[a]}<=${t[o]})`);
        if (r < n.length - 1) {
          let e = `screen${i}Max`;
          if (!(t[o] <= t[e]))
            throw Error(`${o}<=${e} fails : !(${t[o]}<=${t[e]})`);
          let a = `screen${n[r + 1].toUpperCase()}Min`;
          if (!(t[e] <= t[a]))
            throw Error(`${e}<=${a} fails : !(${t[e]}<=${t[a]})`);
        }
      }),
      e
    );
  },
  d = () => {
    let [, e] = r(),
      t = l(u(e));
    return a.useMemo(() => {
      let e = new Map(),
        n = -1,
        r = {};
      return {
        responsiveMap: t,
        matchHandlers: {},
        dispatch(t) {
          return (r = t), e.forEach((e) => e(r)), e.size >= 1;
        },
        subscribe(t) {
          return e.size || this.register(), (n += 1), e.set(n, t), t(r), n;
        },
        unsubscribe(t) {
          e.delete(t), e.size || this.unregister();
        },
        register() {
          Object.entries(t).forEach(([e, t]) => {
            let n = ({ matches: t }) => {
                this.dispatch(Object.assign(Object.assign({}, r), { [e]: t }));
              },
              i = window.matchMedia(t);
            o(i, n), (this.matchHandlers[t] = { mql: i, listener: n }), n(i);
          });
        },
        unregister() {
          Object.values(t).forEach((e) => {
            let t = this.matchHandlers[e];
            s(t == null ? void 0 : t.mql, t == null ? void 0 : t.listener);
          }),
            e.clear();
        },
      };
    }, [e]);
  };
function f(e = !0, t = {}) {
  let r = (0, a.useRef)(t),
    o = i(),
    s = d();
  return (
    n(() => {
      let t = s.subscribe((t) => {
        (r.current = t), e && o();
      });
      return () => s.unsubscribe(t);
    }, []),
    r.current
  );
}
export { c as n, f as t };
