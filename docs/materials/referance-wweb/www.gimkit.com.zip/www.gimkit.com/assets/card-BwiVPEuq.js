import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  E as n,
  Ut as r,
  X as i,
  a,
  b as o,
  g as s,
  l as c,
  m as l,
  s as u,
} from "./Compact-CRRKXVA1.js";
import { i as d } from "./color-Dzrzfp-h.js";
import { a as f } from "./modal-Ch5Fwjpt.js";
import { t as p } from "./useVariants-Bm4HVCER.js";
import { t as m } from "./tabs-Db8OwWAd.js";
var h = e(t()),
  g = e(r()),
  _ = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  v = (e) => {
    var { prefixCls: t, className: r, hoverable: i = !0 } = e,
      a = _(e, [`prefixCls`, `className`, `hoverable`]);
    let { getPrefixCls: o } = h.useContext(n),
      s = o(`card`, t),
      c = (0, g.default)(`${s}-grid`, r, { [`${s}-grid-hoverable`]: i });
    return h.createElement(`div`, Object.assign({}, a, { className: c }));
  },
  y = (e) => {
    let {
      antCls: t,
      componentCls: n,
      headerHeight: r,
      headerPadding: a,
      tabsMarginBottom: o,
    } = e;
    return Object.assign(
      Object.assign(
        {
          display: `flex`,
          justifyContent: `center`,
          flexDirection: `column`,
          minHeight: r,
          marginBottom: -1,
          padding: `0 ${i(a)}`,
          color: e.colorTextHeading,
          fontWeight: e.fontWeightStrong,
          fontSize: e.headerFontSize,
          background: e.headerBg,
          borderBottom: `${i(e.lineWidth)} ${e.lineType} ${
            e.colorBorderSecondary
          }`,
          borderRadius: `${i(e.borderRadiusLG)} ${i(e.borderRadiusLG)} 0 0`,
        },
        c()
      ),
      {
        "&-wrapper": { width: `100%`, display: `flex`, alignItems: `center` },
        "&-title": Object.assign(
          Object.assign({ display: `inline-block`, flex: 1 }, s),
          {
            [`
          > ${n}-typography,
          > ${n}-typography-edit-content
        `]: { insetInlineStart: 0, marginTop: 0, marginBottom: 0 },
          }
        ),
        [`${t}-tabs-top`]: {
          clear: `both`,
          marginBottom: o,
          color: e.colorText,
          fontWeight: `normal`,
          fontSize: e.fontSize,
          "&-bar": {
            borderBottom: `${i(e.lineWidth)} ${e.lineType} ${
              e.colorBorderSecondary
            }`,
          },
        },
      }
    );
  },
  b = (e) => {
    let {
      cardPaddingBase: t,
      colorBorderSecondary: n,
      cardShadow: r,
      lineWidth: a,
    } = e;
    return {
      width: `33.33%`,
      padding: t,
      border: 0,
      borderRadius: 0,
      boxShadow: `
      ${i(a)} 0 0 0 ${n},
      0 ${i(a)} 0 0 ${n},
      ${i(a)} ${i(a)} 0 0 ${n},
      ${i(a)} 0 0 0 ${n} inset,
      0 ${i(a)} 0 0 ${n} inset;
    `,
      transition: `all ${e.motionDurationMid}`,
      "&-hoverable:hover": { position: `relative`, zIndex: 1, boxShadow: r },
    };
  },
  x = (e) => {
    let {
      componentCls: t,
      iconCls: n,
      actionsLiMargin: r,
      cardActionsIconSize: a,
      colorBorderSecondary: o,
      actionsBg: s,
    } = e;
    return Object.assign(
      Object.assign(
        {
          margin: 0,
          padding: 0,
          listStyle: `none`,
          background: s,
          borderTop: `${i(e.lineWidth)} ${e.lineType} ${o}`,
          display: `flex`,
          borderRadius: `0 0 ${i(e.borderRadiusLG)} ${i(e.borderRadiusLG)}`,
        },
        c()
      ),
      {
        "& > li": {
          margin: r,
          color: e.colorTextDescription,
          textAlign: `center`,
          "> span": {
            position: `relative`,
            display: `block`,
            minWidth: e.calc(e.cardActionsIconSize).mul(2).equal(),
            fontSize: e.fontSize,
            lineHeight: e.lineHeight,
            cursor: `pointer`,
            "&:hover": {
              color: e.colorPrimary,
              transition: `color ${e.motionDurationMid}`,
            },
            [`a:not(${t}-btn), > ${n}`]: {
              display: `inline-block`,
              width: `100%`,
              color: e.colorIcon,
              lineHeight: i(e.fontHeight),
              transition: `color ${e.motionDurationMid}`,
              "&:hover": { color: e.colorPrimary },
            },
            [`> ${n}`]: {
              fontSize: a,
              lineHeight: i(e.calc(a).mul(e.lineHeight).equal()),
            },
          },
          "&:not(:last-child)": {
            borderInlineEnd: `${i(e.lineWidth)} ${e.lineType} ${o}`,
          },
        },
      }
    );
  },
  S = (e) =>
    Object.assign(
      Object.assign(
        {
          margin: `${i(e.calc(e.marginXXS).mul(-1).equal())} 0`,
          display: `flex`,
        },
        c()
      ),
      {
        "&-avatar": { paddingInlineEnd: e.padding },
        "&-detail": {
          overflow: `hidden`,
          flex: 1,
          "> div:not(:last-child)": { marginBottom: e.marginXS },
        },
        "&-title": Object.assign(
          {
            color: e.colorTextHeading,
            fontWeight: e.fontWeightStrong,
            fontSize: e.fontSizeLG,
          },
          s
        ),
        "&-description": { color: e.colorTextDescription },
      }
    ),
  C = (e) => {
    let {
      componentCls: t,
      colorFillAlter: n,
      headerPadding: r,
      bodyPadding: a,
    } = e;
    return {
      [`${t}-head`]: {
        padding: `0 ${i(r)}`,
        background: n,
        "&-title": { fontSize: e.fontSize },
      },
      [`${t}-body`]: { padding: `${i(e.padding)} ${i(a)}` },
    };
  },
  w = (e) => {
    let { componentCls: t } = e;
    return { overflow: `hidden`, [`${t}-body`]: { userSelect: `none` } };
  },
  T = (e) => {
    let {
      componentCls: t,
      cardShadow: n,
      cardHeadPadding: r,
      colorBorderSecondary: a,
      boxShadowTertiary: o,
      bodyPadding: s,
      extraColor: u,
    } = e;
    return {
      [t]: Object.assign(Object.assign({}, l(e)), {
        position: `relative`,
        background: e.colorBgContainer,
        borderRadius: e.borderRadiusLG,
        [`&:not(${t}-bordered)`]: { boxShadow: o },
        [`${t}-head`]: y(e),
        [`${t}-extra`]: {
          marginInlineStart: `auto`,
          color: u,
          fontWeight: `normal`,
          fontSize: e.fontSize,
        },
        [`${t}-body`]: Object.assign(
          {
            padding: s,
            borderRadius: `0 0 ${i(e.borderRadiusLG)} ${i(e.borderRadiusLG)}`,
          },
          c()
        ),
        [`${t}-grid`]: b(e),
        [`${t}-cover`]: {
          "> *": {
            display: `block`,
            width: `100%`,
            borderRadius: `${i(e.borderRadiusLG)} ${i(e.borderRadiusLG)} 0 0`,
          },
        },
        [`${t}-actions`]: x(e),
        [`${t}-meta`]: S(e),
      }),
      [`${t}-bordered`]: {
        border: `${i(e.lineWidth)} ${e.lineType} ${a}`,
        [`${t}-cover`]: {
          marginTop: -1,
          marginInlineStart: -1,
          marginInlineEnd: -1,
        },
      },
      [`${t}-hoverable`]: {
        cursor: `pointer`,
        transition: `box-shadow ${e.motionDurationMid}, border-color ${e.motionDurationMid}`,
        "&:hover": { borderColor: `transparent`, boxShadow: n },
      },
      [`${t}-contain-grid`]: {
        borderRadius: `${i(e.borderRadiusLG)} ${i(e.borderRadiusLG)} 0 0 `,
        [`${t}-body`]: { display: `flex`, flexWrap: `wrap` },
        [`&:not(${t}-loading) ${t}-body`]: {
          marginBlockStart: e.calc(e.lineWidth).mul(-1).equal(),
          marginInlineStart: e.calc(e.lineWidth).mul(-1).equal(),
          padding: 0,
        },
      },
      [`${t}-contain-tabs`]: {
        [`> div${t}-head`]: {
          minHeight: 0,
          [`${t}-head-title, ${t}-extra`]: { paddingTop: r },
        },
      },
      [`${t}-type-inner`]: C(e),
      [`${t}-loading`]: w(e),
      [`${t}-rtl`]: { direction: `rtl` },
    };
  },
  E = (e) => {
    let {
      componentCls: t,
      bodyPaddingSM: n,
      headerPaddingSM: r,
      headerHeightSM: a,
      headerFontSizeSM: o,
    } = e;
    return {
      [`${t}-small`]: {
        [`> ${t}-head`]: {
          minHeight: a,
          padding: `0 ${i(r)}`,
          fontSize: o,
          [`> ${t}-head-wrapper`]: {
            [`> ${t}-extra`]: { fontSize: e.fontSize },
          },
        },
        [`> ${t}-body`]: { padding: n },
      },
      [`${t}-small${t}-contain-tabs`]: {
        [`> ${t}-head`]: {
          [`${t}-head-title, ${t}-extra`]: {
            paddingTop: 0,
            display: `flex`,
            alignItems: `center`,
          },
        },
      },
    };
  },
  D = u(
    `Card`,
    (e) => {
      let t = o(e, {
        cardShadow: e.boxShadowCard,
        cardHeadPadding: e.padding,
        cardPaddingBase: e.paddingLG,
        cardActionsIconSize: e.fontSize,
      });
      return [T(t), E(t)];
    },
    (e) => ({
      headerBg: `transparent`,
      headerFontSize: e.fontSizeLG,
      headerFontSizeSM: e.fontSize,
      headerHeight: e.fontSizeLG * e.lineHeightLG + e.padding * 2,
      headerHeightSM: e.fontSize * e.lineHeight + e.paddingXS * 2,
      actionsBg: e.colorBgContainer,
      actionsLiMargin: `${e.paddingSM}px 0`,
      tabsMarginBottom: -e.padding - e.lineWidth,
      extraColor: e.colorText,
      bodyPaddingSM: 12,
      headerPaddingSM: 12,
      bodyPadding: e.bodyPadding ?? e.paddingLG,
      headerPadding: e.headerPadding ?? e.paddingLG,
    })
  ),
  O = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  ee = (e) => {
    let { actionClasses: t, actions: n = [], actionStyle: r } = e;
    return h.createElement(
      `ul`,
      { className: t, style: r },
      n.map((e, t) => {
        let r = `action-${t}`;
        return h.createElement(
          `li`,
          { style: { width: `${100 / n.length}%` }, key: r },
          h.createElement(`span`, null, e)
        );
      })
    );
  },
  k = h.forwardRef((e, t) => {
    let {
        prefixCls: r,
        className: i,
        rootClassName: o,
        style: s,
        extra: c,
        headStyle: l = {},
        bodyStyle: u = {},
        title: _,
        loading: y,
        bordered: b,
        variant: x,
        size: S,
        type: C,
        cover: w,
        actions: T,
        tabList: E,
        children: k,
        activeTabKey: A,
        defaultActiveTabKey: j,
        tabBarExtraContent: M,
        hoverable: te,
        tabProps: N = {},
        classNames: P,
        styles: F,
      } = e,
      I = O(e, [
        `prefixCls`,
        `className`,
        `rootClassName`,
        `style`,
        `extra`,
        `headStyle`,
        `bodyStyle`,
        `title`,
        `loading`,
        `bordered`,
        `variant`,
        `size`,
        `type`,
        `cover`,
        `actions`,
        `tabList`,
        `children`,
        `activeTabKey`,
        `defaultActiveTabKey`,
        `tabBarExtraContent`,
        `hoverable`,
        `tabProps`,
        `classNames`,
        `styles`,
      ]),
      { getPrefixCls: L, direction: ne, card: R } = h.useContext(n),
      [re] = p(`card`, x, b),
      z = (t) => {
        var n;
        (n = e.onTabChange) == null || n.call(e, t);
      },
      B = (e) => {
        var t;
        return (0, g.default)(
          (t = R == null ? void 0 : R.classNames) == null ? void 0 : t[e],
          P == null ? void 0 : P[e]
        );
      },
      V = (e) => {
        var t;
        return Object.assign(
          Object.assign(
            {},
            (t = R == null ? void 0 : R.styles) == null ? void 0 : t[e]
          ),
          F == null ? void 0 : F[e]
        );
      },
      H = h.useMemo(() => {
        let e = !1;
        return (
          h.Children.forEach(k, (t) => {
            (t == null ? void 0 : t.type) === v && (e = !0);
          }),
          e
        );
      }, [k]),
      U = L(`card`, r),
      [W, G, K] = D(U),
      q = h.createElement(
        f,
        { loading: !0, active: !0, paragraph: { rows: 4 }, title: !1 },
        k
      ),
      J = A !== void 0,
      Y = Object.assign(Object.assign({}, N), {
        [J ? `activeKey` : `defaultActiveKey`]: J ? A : j,
        tabBarExtraContent: M,
      }),
      X,
      Z = a(S),
      ie = !Z || Z === "default" ? `large` : Z,
      Q = E
        ? h.createElement(
            m,
            Object.assign({ size: ie }, Y, {
              className: `${U}-head-tabs`,
              onChange: z,
              items: E.map((e) => {
                var { tab: t } = e,
                  n = O(e, [`tab`]);
                return Object.assign({ label: t }, n);
              }),
            })
          )
        : null;
    if (_ || c || Q) {
      let e = (0, g.default)(`${U}-head`, B(`header`)),
        t = (0, g.default)(`${U}-head-title`, B(`title`)),
        n = (0, g.default)(`${U}-extra`, B(`extra`)),
        r = Object.assign(Object.assign({}, l), V(`header`));
      X = h.createElement(
        `div`,
        { className: e, style: r },
        h.createElement(
          `div`,
          { className: `${U}-head-wrapper` },
          _ && h.createElement(`div`, { className: t, style: V(`title`) }, _),
          c && h.createElement(`div`, { className: n, style: V(`extra`) }, c)
        ),
        Q
      );
    }
    let $ = (0, g.default)(`${U}-cover`, B(`cover`)),
      ae = w
        ? h.createElement(`div`, { className: $, style: V(`cover`) }, w)
        : null,
      oe = (0, g.default)(`${U}-body`, B(`body`)),
      se = Object.assign(Object.assign({}, u), V(`body`)),
      ce = h.createElement(`div`, { className: oe, style: se }, y ? q : k),
      le = (0, g.default)(`${U}-actions`, B(`actions`)),
      ue =
        T != null && T.length
          ? h.createElement(ee, {
              actionClasses: le,
              actionStyle: V(`actions`),
              actions: T,
            })
          : null,
      de = d(I, [`onTabChange`]),
      fe = (0, g.default)(
        U,
        R == null ? void 0 : R.className,
        {
          [`${U}-loading`]: y,
          [`${U}-bordered`]: re !== `borderless`,
          [`${U}-hoverable`]: te,
          [`${U}-contain-grid`]: H,
          [`${U}-contain-tabs`]: E == null ? void 0 : E.length,
          [`${U}-${Z}`]: Z,
          [`${U}-type-${C}`]: !!C,
          [`${U}-rtl`]: ne === `rtl`,
        },
        i,
        o,
        G,
        K
      ),
      pe = Object.assign(Object.assign({}, R == null ? void 0 : R.style), s);
    return W(
      h.createElement(
        `div`,
        Object.assign({ ref: t }, de, { className: fe, style: pe }),
        X,
        ae,
        ce,
        ue
      )
    );
  }),
  A = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  j = (e) => {
    let { prefixCls: t, className: r, avatar: i, title: a, description: o } = e,
      s = A(e, [`prefixCls`, `className`, `avatar`, `title`, `description`]),
      { getPrefixCls: c } = h.useContext(n),
      l = c(`card`, t),
      u = (0, g.default)(`${l}-meta`, r),
      d = i
        ? h.createElement(`div`, { className: `${l}-meta-avatar` }, i)
        : null,
      f = a
        ? h.createElement(`div`, { className: `${l}-meta-title` }, a)
        : null,
      p = o
        ? h.createElement(`div`, { className: `${l}-meta-description` }, o)
        : null,
      m =
        f || p
          ? h.createElement(`div`, { className: `${l}-meta-detail` }, f, p)
          : null;
    return h.createElement(`div`, Object.assign({}, s, { className: u }), d, m);
  },
  M = k;
(M.Grid = v), (M.Meta = j);
export { M as t };
