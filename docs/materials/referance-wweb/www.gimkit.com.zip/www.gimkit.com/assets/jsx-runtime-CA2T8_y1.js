import { t as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
var n = e((e) => {
    var n = t(),
      r = Symbol.for(`react.element`),
      i = Symbol.for(`react.fragment`),
      a = Object.prototype.hasOwnProperty,
      o =
        n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
      s = { key: !0, ref: !0, __self: !0, __source: !0 };
    function c(e, t, n) {
      var i,
        c = {},
        l = null,
        u = null;
      for (i in (n !== void 0 && (l = `` + n),
      t.key !== void 0 && (l = `` + t.key),
      t.ref !== void 0 && (u = t.ref),
      t))
        a.call(t, i) && !s.hasOwnProperty(i) && (c[i] = t[i]);
      if (e && e.defaultProps)
        for (i in ((t = e.defaultProps), t)) c[i] === void 0 && (c[i] = t[i]);
      return {
        $$typeof: r,
        type: e,
        key: l,
        ref: u,
        props: c,
        _owner: o.current,
      };
    }
    (e.Fragment = i), (e.jsx = c), (e.jsxs = c);
  }),
  r = e((e, t) => {
    t.exports = n();
  });
export { r as t };
