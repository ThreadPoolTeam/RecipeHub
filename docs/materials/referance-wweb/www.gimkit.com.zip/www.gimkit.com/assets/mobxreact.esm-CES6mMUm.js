import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { l as n } from "./assertThisInitialized-DqpgQyeg.js";
import {
  a as r,
  d as i,
  f as a,
  l as o,
  n as s,
  o as c,
  p as l,
  r as u,
  s as d,
  u as ee,
} from "./decorate-DQbPZ5_K.js";
var f = e(t());
if (!f.useState)
  throw Error(`mobx-react-lite requires React with Hooks support`);
if (!a)
  throw Error(
    `mobx-react-lite@3 requires mobx at least version 6 to be available`
  );
var p = e(n());
function m(e) {
  e();
}
function te(e) {
  e || (e = m), o({ reactionScheduler: e });
}
function h(e) {
  return i(e);
}
var ne = 1e4,
  re = 1e4,
  ie = (function () {
    function e(e) {
      var t = this;
      Object.defineProperty(this, "finalize", {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e,
      }),
        Object.defineProperty(this, "registrations", {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: new Map(),
        }),
        Object.defineProperty(this, "sweepTimeout", {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: void 0,
        }),
        Object.defineProperty(this, "sweep", {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: function (e) {
            e === void 0 && (e = ne),
              clearTimeout(t.sweepTimeout),
              (t.sweepTimeout = void 0);
            var n = Date.now();
            t.registrations.forEach(function (r, i) {
              n - r.registeredAt >= e &&
                (t.finalize(r.value), t.registrations.delete(i));
            }),
              t.registrations.size > 0 && t.scheduleSweep();
          },
        }),
        Object.defineProperty(this, "finalizeAllImmediately", {
          enumerable: !0,
          configurable: !0,
          writable: !0,
          value: function () {
            t.sweep(0);
          },
        });
    }
    return (
      Object.defineProperty(e.prototype, "register", {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        value: function (e, t, n) {
          this.registrations.set(n, { value: t, registeredAt: Date.now() }),
            this.scheduleSweep();
        },
      }),
      Object.defineProperty(e.prototype, "unregister", {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        value: function (e) {
          this.registrations.delete(e);
        },
      }),
      Object.defineProperty(e.prototype, "scheduleSweep", {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        value: function () {
          this.sweepTimeout === void 0 &&
            (this.sweepTimeout = setTimeout(this.sweep, re));
        },
      }),
      e
    );
  })(),
  g = new (typeof FinalizationRegistry < `u` ? FinalizationRegistry : ie)(
    function (e) {
      var t;
      (t = e.reaction) == null || t.dispose(), (e.reaction = null);
    }
  ),
  _ = !1;
function v() {
  return _;
}
var y = function (e, t) {
  var n = typeof Symbol == `function` && e[Symbol.iterator];
  if (!n) return e;
  var r = n.call(e),
    i,
    a = [],
    o;
  try {
    for (; (t === void 0 || t-- > 0) && !(i = r.next()).done; ) a.push(i.value);
  } catch (e) {
    o = { error: e };
  } finally {
    try {
      i && !i.done && (n = r.return) && n.call(r);
    } finally {
      if (o) throw o.error;
    }
  }
  return a;
};
function b(e) {
  return `observer${e}`;
}
var ae = (function () {
  function e() {}
  return e;
})();
function x() {
  return new ae();
}
function oe(e, t) {
  if ((t === void 0 && (t = `observed`), v())) return e();
  var n = y(f.useState(x), 1)[0],
    r = y(f.useState(), 2)[1],
    i = function () {
      return r([]);
    },
    a = f.useRef(null);
  a.current ||
    (a.current = { reaction: null, mounted: !1, changedBeforeMount: !1 });
  var o = a.current;
  o.reaction ||
    ((o.reaction = new u(b(t), function () {
      o.mounted ? i() : (o.changedBeforeMount = !0);
    })),
    g.register(n, o, o)),
    f.useDebugValue(o.reaction, h),
    f.useEffect(function () {
      return (
        g.unregister(o),
        (o.mounted = !0),
        o.reaction
          ? o.changedBeforeMount && ((o.changedBeforeMount = !1), i())
          : ((o.reaction = new u(b(t), function () {
              i();
            })),
            i()),
        function () {
          o.reaction.dispose(),
            (o.reaction = null),
            (o.mounted = !1),
            (o.changedBeforeMount = !1);
        }
      );
    }, []);
  var s, c;
  if (
    (o.reaction.track(function () {
      try {
        s = e();
      } catch (e) {
        c = e;
      }
    }),
    c)
  )
    throw c;
  return s;
}
var S = typeof Symbol == `function` && Symbol.for,
  C = S
    ? Symbol.for(`react.forward_ref`)
    : typeof f.forwardRef == `function` &&
      (0, f.forwardRef)(function (e) {
        return null;
      }).$$typeof,
  w = S
    ? Symbol.for(`react.memo`)
    : typeof f.memo == `function` &&
      (0, f.memo)(function (e) {
        return null;
      }).$$typeof;
function T(e, t) {
  if (w && e.$$typeof === w)
    throw Error(
      "[mobx-react-lite] You are trying to use `observer` on a function component wrapped in either another `observer` or `React.memo`. The observer already applies 'React.memo' for you."
    );
  if (v()) return e;
  var n = (t == null ? void 0 : t.forwardRef) ?? !1,
    r = e,
    i = e.displayName || e.name;
  if (
    C &&
    e.$$typeof === C &&
    ((n = !0), (r = e.render), typeof r != `function`)
  )
    throw Error(
      "[mobx-react-lite] `render` property of ForwardRef was not a function"
    );
  var a = function (e, t) {
    return oe(function () {
      return r(e, t);
    }, i);
  };
  return (
    i !== `` && (a.displayName = i),
    e.contextTypes && (a.contextTypes = e.contextTypes),
    n && (a = (0, f.forwardRef)(a)),
    (a = (0, f.memo)(a)),
    D(e, a),
    a
  );
}
var E = { $$typeof: !0, render: !0, compare: !0, type: !0, displayName: !0 };
function D(e, t) {
  Object.keys(e).forEach(function (n) {
    E[n] || Object.defineProperty(t, n, Object.getOwnPropertyDescriptor(e, n));
  });
}
function se(e, t) {
  return (0, f.useState)(function () {
    return l(e(), t, { autoBind: !0 });
  })[0];
}
te(p.unstable_batchedUpdates), g.finalizeAllImmediately;
var O = 0;
function k(e) {
  if (typeof Symbol == `function`) return Symbol(e);
  var t = `__$mobx-react ` + e + ` (` + O + `)`;
  return O++, t;
}
var A = {};
function j(e) {
  return A[e] || (A[e] = k(e)), A[e];
}
function M(e, t) {
  if (N(e, t)) return !0;
  if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
  var n = Object.keys(e),
    r = Object.keys(t);
  if (n.length !== r.length) return !1;
  for (var i = 0; i < n.length; i++)
    if (!Object.hasOwnProperty.call(t, n[i]) || !N(e[n[i]], t[n[i]])) return !1;
  return !0;
}
function N(e, t) {
  return e === t ? e !== 0 || 1 / e == 1 / t : e !== e && t !== t;
}
var ce = {
  $$typeof: 1,
  render: 1,
  compare: 1,
  type: 1,
  childContextTypes: 1,
  contextType: 1,
  contextTypes: 1,
  defaultProps: 1,
  getDefaultProps: 1,
  getDerivedStateFromError: 1,
  getDerivedStateFromProps: 1,
  mixins: 1,
  displayName: 1,
  propTypes: 1,
};
function le(e, t) {
  var n = Object.getOwnPropertyNames(Object.getPrototypeOf(e));
  Object.getOwnPropertyNames(e).forEach(function (r) {
    !ce[r] &&
      n.indexOf(r) === -1 &&
      Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(e, r));
  });
}
function P(e, t, n) {
  Object.hasOwnProperty.call(e, t)
    ? (e[t] = n)
    : Object.defineProperty(e, t, {
        enumerable: !1,
        configurable: !0,
        writable: !0,
        value: n,
      });
}
var F = j(`patchMixins`),
  I = j(`patchedDefinition`);
function ue(e, t) {
  var n = (e[F] = e[F] || {}),
    r = (n[t] = n[t] || {});
  return (r.locks = r.locks || 0), (r.methods = r.methods || []), r;
}
function L(e, t) {
  var n = this,
    r = [...arguments].slice(2);
  t.locks++;
  try {
    var i;
    return e != null && (i = e.apply(this, r)), i;
  } finally {
    t.locks--,
      t.locks === 0 &&
        t.methods.forEach(function (e) {
          e.apply(n, r);
        });
  }
}
function R(e, t) {
  return function () {
    var n = [...arguments];
    L.call.apply(L, [this, e, t].concat(n));
  };
}
function z(e, t, n) {
  var r = ue(e, t);
  r.methods.indexOf(n) < 0 && r.methods.push(n);
  var i = Object.getOwnPropertyDescriptor(e, t);
  if (!(i && i[I])) {
    var a = e[t],
      o = B(e, t, i ? i.enumerable : void 0, r, a);
    Object.defineProperty(e, t, o);
  }
}
function B(e, t, n, r, i) {
  var a,
    o = R(i, r);
  return (
    (a = {}),
    (a[I] = !0),
    (a.get = function () {
      return o;
    }),
    (a.set = function (i) {
      if (this === e) o = R(i, r);
      else {
        var a = B(this, t, n, r, i);
        Object.defineProperty(this, t, a);
      }
    }),
    (a.configurable = !0),
    (a.enumerable = n),
    a
  );
}
var V = s || `$mobx`,
  H = j(`isMobXReactObserver`),
  U = j(`isUnmounted`),
  W = j(`skipRender`),
  G = j(`isForcingUpdate`);
function de(e) {
  var t = e.prototype;
  if (e[H]) {
    var n = K(t);
    console.warn(
      `The provided component class (` +
        n +
        `)
                has already been declared as an observer component.`
    );
  } else e[H] = !0;
  if (t.componentWillReact)
    throw Error(
      `The componentWillReact life-cycle event is no longer supported`
    );
  if (e.__proto__ !== f.PureComponent) {
    if (!t.shouldComponentUpdate) t.shouldComponentUpdate = q;
    else if (t.shouldComponentUpdate !== q)
      throw Error(
        `It is not allowed to use shouldComponentUpdate in observer based components.`
      );
  }
  J(t, `props`), J(t, `state`), e.contextType && J(t, `context`);
  var r = t.render;
  if (typeof r != `function`) {
    var i = K(t);
    throw Error(
      `[mobx-react] class component (` +
        i +
        ") is missing `render` method.\n`observer` requires `render` being a function defined on prototype.\n`render = () => {}` or `render = function() {}` is not supported."
    );
  }
  return (
    (t.render = function () {
      return (this.render = v() ? r : fe.call(this, r)), this.render();
    }),
    z(t, `componentDidMount`, function () {
      (this[U] = !1),
        this.render[V] || f.Component.prototype.forceUpdate.call(this);
    }),
    z(t, `componentWillUnmount`, function () {
      if (!v()) {
        var e = this.render[V];
        if (e) e.dispose(), (this.render[V] = null);
        else {
          var t = K(this);
          console.warn(
            `The reactive render of an observer class component (` +
              t +
              `)
                was overridden after MobX attached. This may result in a memory leak if the
                overridden reactive render was not properly disposed.`
          );
        }
        this[U] = !0;
      }
    }),
    e
  );
}
function K(e) {
  return (
    e.displayName ||
    e.name ||
    (e.constructor && (e.constructor.displayName || e.constructor.name)) ||
    `<component>`
  );
}
function fe(e) {
  var t = this;
  P(this, W, !1), P(this, G, !1);
  var n = K(this),
    i = e.bind(this),
    a = !1,
    o = function () {
      var e = new u(n + `.render()`, function () {
        if (!a && ((a = !0), t[U] !== !0)) {
          var n = !0;
          try {
            P(t, G, !0),
              t[W] || f.Component.prototype.forceUpdate.call(t),
              (n = !1);
          } finally {
            P(t, G, !1), n && (e.dispose(), (t.render[V] = null));
          }
        }
      });
      return (e.reactComponent = t), e;
    };
  function s() {
    a = !1;
    var e = s[V] ?? (s[V] = o()),
      t = void 0,
      n = void 0;
    if (
      (e.track(function () {
        try {
          n = r(!1, i);
        } catch (e) {
          t = e;
        }
      }),
      t)
    )
      throw t;
    return n;
  }
  return s;
}
function q(e, t) {
  return (
    v() &&
      console.warn(
        `[mobx-react] It seems that a re-rendering of a React component is triggered while in static (server-side) mode. Please make sure components are rendered only once server-side.`
      ),
    this.state !== t || !M(this.props, e)
  );
}
function J(e, t) {
  var n = j(`reactProp_` + t + `_valueHolder`),
    r = j(`reactProp_` + t + `_atomHolder`);
  function i() {
    return this[r] || P(this, r, ee(`reactive ` + t)), this[r];
  }
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !0,
    get: function () {
      var e = !1;
      return (
        d && c && (e = d(!0)),
        i.call(this).reportObserved(),
        d && c && c(e),
        this[n]
      );
    },
    set: function (e) {
      !this[G] && !M(this[n], e)
        ? (P(this, n, e),
          P(this, W, !0),
          i.call(this).reportChanged(),
          P(this, W, !1))
        : P(this, n, e);
    },
  });
}
function Y(e) {
  return (
    e.isMobxInjector === !0 &&
      console.warn(
        "Mobx observer: You are trying to use `observer` on a component that already has `inject`. Please apply `observer` before applying `inject`"
      ),
    Object.prototype.isPrototypeOf.call(f.Component, e) ||
    Object.prototype.isPrototypeOf.call(f.PureComponent, e)
      ? de(e)
      : T(e)
  );
}
function X() {
  return (
    (X =
      Object.assign ||
      function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          for (var r in n)
            Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
        }
        return e;
      }),
    X.apply(this, arguments)
  );
}
function pe(e, t) {
  if (e == null) return {};
  for (var n = {}, r = Object.keys(e), i, a = 0; a < r.length; a++)
    (i = r[a]), !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n;
}
var me = [`children`],
  Z = f.createContext({});
function Q(e) {
  var t = e.children,
    n = pe(e, me),
    r = f.useContext(Z),
    i = f.useRef(X({}, r, n)).current;
  return f.createElement(Z.Provider, { value: i }, t);
}
Q.displayName = `MobXProvider`;
function $(e, t, n, r) {
  var i = f.forwardRef(function (n, r) {
    var i = X({}, n),
      a = f.useContext(Z);
    return (
      Object.assign(i, e(a || {}, i) || {}),
      r && (i.ref = r),
      f.createElement(t, i)
    );
  });
  return (
    r && (i = Y(i)),
    (i.isMobxInjector = !0),
    le(t, i),
    (i.wrappedComponent = t),
    (i.displayName = he(t, n)),
    i
  );
}
function he(e, t) {
  var n,
    r =
      e.displayName ||
      e.name ||
      (e.constructor && e.constructor.name) ||
      `Component`;
  return (n = t ? `inject-with-` + t + `(` + r + `)` : `inject(` + r + `)`), n;
}
function ge(e) {
  return function (t, n) {
    return (
      e.forEach(function (e) {
        if (!(e in n)) {
          if (!(e in t))
            throw Error(
              `MobX injector: Store '` +
                e +
                `' is not available! Make sure it is provided by some Provider`
            );
          n[e] = t[e];
        }
      }),
      n
    );
  };
}
function _e() {
  var e = [...arguments];
  if (typeof arguments[0] == `function`) {
    var t = arguments[0];
    return function (e) {
      return $(t, e, t.name, !0);
    };
  }
  return function (t) {
    return $(ge(e), t, e.join(`-`), !1);
  };
}
if (!f.Component) throw Error(`mobx-react requires React to be available`);
if (!l) throw Error(`mobx-react requires mobx to be available`);
export { T as a, se as i, _e as n, Y as r, Q as t };
