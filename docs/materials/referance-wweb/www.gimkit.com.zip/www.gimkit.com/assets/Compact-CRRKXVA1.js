import { n as e, o as t, t as n } from "./rolldown-runtime-C0FnF6B9.js";
import { t as r } from "./react-IpA8Qn9U.js";
import {
  a as i,
  c as a,
  i as o,
  n as s,
  o as c,
  r as l,
  s as u,
  t as d,
} from "./assertThisInitialized-DqpgQyeg.js";
var f = n((e, t) => {
  (function () {
    var e = {}.hasOwnProperty;
    function n() {
      for (var e = ``, t = 0; t < arguments.length; t++) {
        var n = arguments[t];
        n && (e = i(e, r(n)));
      }
      return e;
    }
    function r(t) {
      if (typeof t == `string` || typeof t == `number`) return t;
      if (typeof t != `object`) return ``;
      if (Array.isArray(t)) return n.apply(null, t);
      if (
        t.toString !== Object.prototype.toString &&
        !t.toString.toString().includes(`[native code]`)
      )
        return t.toString();
      var r = ``;
      for (var a in t) e.call(t, a) && t[a] && (r = i(r, a));
      return r;
    }
    function i(e, t) {
      return t ? (e ? e + ` ` + t : e + t) : e;
    }
    t !== void 0 && t.exports
      ? ((n.default = n), (t.exports = n))
      : typeof define == `function` &&
        typeof define.amd == `object` &&
        define.amd
      ? define(`classnames`, [], function () {
          return n;
        })
      : (window.classNames = n);
  })();
});
function p(e) {
  "@babel/helpers - typeof";
  return (
    (p =
      typeof Symbol == `function` && typeof Symbol.iterator == `symbol`
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              typeof Symbol == `function` &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? `symbol`
              : typeof e;
          }),
    p(e)
  );
}
var m = e(() => {}),
  h = t(r());
a(), m();
var g = Symbol.for(`react.element`),
  _ = Symbol.for(`react.transitional.element`),
  v = Symbol.for(`react.fragment`);
function y(e) {
  return (
    e &&
    p(e) === `object` &&
    (e.$$typeof === g || e.$$typeof === _) &&
    e.type === v
  );
}
var b = t(f());
function x(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    n = [];
  return (
    h.Children.forEach(e, function (e) {
      (e != null || t.keepEmpty) &&
        (Array.isArray(e)
          ? (n = n.concat(x(e)))
          : y(e) && e.props
          ? (n = n.concat(x(e.props.children, t)))
          : n.push(e));
    }),
    n
  );
}
var S = {},
  C = [],
  w = function (e) {
    C.push(e);
  };
function T(e, t) {}
function ee(e, t) {}
function te() {
  S = {};
}
function ne(e, t, n) {
  !t && !S[n] && (e(!1, n), (S[n] = !0));
}
function E(e, t) {
  ne(T, e, t);
}
function re(e, t) {
  ne(ee, e, t);
}
(E.preMessage = w), (E.resetWarned = te), (E.noteOnce = re);
function ie(e, t) {
  if (p(e) != `object` || !e) return e;
  var n = e[Symbol.toPrimitive];
  if (n !== void 0) {
    var r = n.call(e, t || `default`);
    if (p(r) != `object`) return r;
    throw TypeError(`@@toPrimitive must return a primitive value.`);
  }
  return (t === `string` ? String : Number)(e);
}
var ae = e(() => {
  m();
});
function oe(e) {
  var t = ie(e, `string`);
  return p(t) == `symbol` ? t : t + ``;
}
var se = e(() => {
  m(), ae();
});
function D(e, t, n) {
  return (
    (t = oe(t)) in e
      ? Object.defineProperty(e, t, {
          value: n,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = n),
    e
  );
}
var O = e(() => {
  se();
});
O();
function ce(e, t) {
  var n = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(e);
    t &&
      (r = r.filter(function (t) {
        return Object.getOwnPropertyDescriptor(e, t).enumerable;
      })),
      n.push.apply(n, r);
  }
  return n;
}
function k(e) {
  for (var t = 1; t < arguments.length; t++) {
    var n = arguments[t] == null ? {} : arguments[t];
    t % 2
      ? ce(Object(n), !0).forEach(function (t) {
          D(e, t, n[t]);
        })
      : Object.getOwnPropertyDescriptors
      ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n))
      : ce(Object(n)).forEach(function (t) {
          Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
  }
  return e;
}
var le = n((e) => {
    var t = Symbol.for(`react.element`),
      n = Symbol.for(`react.portal`),
      r = Symbol.for(`react.fragment`),
      i = Symbol.for(`react.strict_mode`),
      a = Symbol.for(`react.profiler`),
      o = Symbol.for(`react.provider`),
      s = Symbol.for(`react.context`),
      c = Symbol.for(`react.server_context`),
      l = Symbol.for(`react.forward_ref`),
      u = Symbol.for(`react.suspense`),
      d = Symbol.for(`react.suspense_list`),
      f = Symbol.for(`react.memo`),
      p = Symbol.for(`react.lazy`);
    function m(e) {
      if (typeof e == `object` && e) {
        var m = e.$$typeof;
        switch (m) {
          case t:
            switch (((e = e.type), e)) {
              case r:
              case a:
              case i:
              case u:
              case d:
                return e;
              default:
                switch (((e = e && e.$$typeof), e)) {
                  case c:
                  case s:
                  case l:
                  case p:
                  case f:
                  case o:
                    return e;
                  default:
                    return m;
                }
            }
          case n:
            return m;
        }
      }
    }
    (e.ForwardRef = l),
      (e.isMemo = function (e) {
        return m(e) === f;
      });
  }),
  ue = n((e, t) => {
    t.exports = le();
  });
function de(e, t, n) {
  var r = h.useRef({});
  return (
    (!(`value` in r.current) || n(r.current.condition, t)) &&
      ((r.current.value = e()), (r.current.condition = t)),
    r.current.value
  );
}
m();
var fe = ue(),
  pe = Number(h.version.split(`.`)[0]),
  me = function (e, t) {
    typeof e == `function`
      ? e(t)
      : p(e) === `object` && e && `current` in e && (e.current = t);
  },
  he = function () {
    var e = [...arguments],
      t = e.filter(Boolean);
    return t.length <= 1
      ? t[0]
      : function (t) {
          e.forEach(function (e) {
            me(e, t);
          });
        };
  },
  ge = function () {
    var e = [...arguments];
    return de(
      function () {
        return he.apply(void 0, e);
      },
      e,
      function (e, t) {
        return (
          e.length !== t.length ||
          e.every(function (e, n) {
            return e !== t[n];
          })
        );
      }
    );
  },
  _e = function (e) {
    var t, n;
    if (!e) return !1;
    if (ve(e) && pe >= 19) return !0;
    var r = (0, fe.isMemo)(e) ? e.type.type : e.type;
    return !(
      (typeof r == `function` &&
        !((t = r.prototype) != null && t.render) &&
        r.$$typeof !== fe.ForwardRef) ||
      (typeof e == `function` &&
        !((n = e.prototype) != null && n.render) &&
        e.$$typeof !== fe.ForwardRef)
    );
  };
function ve(e) {
  return (0, h.isValidElement)(e) && !y(e);
}
var ye = function (e) {
    return ve(e) && _e(e);
  },
  be = function (e) {
    if (e && ve(e)) {
      var t = e;
      return t.props.propertyIsEnumerable(`ref`) ? t.props.ref : t.ref;
    }
    return null;
  };
function A(e, t) {
  if (!(e instanceof t)) throw TypeError(`Cannot call a class as a function`);
}
var j = e(() => {});
function xe(e, t) {
  for (var n = 0; n < t.length; n++) {
    var r = t[n];
    (r.enumerable = r.enumerable || !1),
      (r.configurable = !0),
      `value` in r && (r.writable = !0),
      Object.defineProperty(e, oe(r.key), r);
  }
}
function M(e, t, n) {
  return (
    t && xe(e.prototype, t),
    n && xe(e, n),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    e
  );
}
var N = e(() => {
  se();
});
j(), N(), c();
function Se(e, t) {
  if (typeof t != `function` && t !== null)
    throw TypeError(`Super expression must either be null or a function`);
  (e.prototype = Object.create(t && t.prototype, {
    constructor: { value: e, writable: !0, configurable: !0 },
  })),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    t && i(e, t);
}
m(), s();
function Ce(e, t) {
  if (t && (p(t) == `object` || typeof t == `function`)) return t;
  if (t !== void 0)
    throw TypeError(`Derived constructors may only return object or undefined`);
  return d(e);
}
function we(e) {
  var t = l();
  return function () {
    var n,
      r = o(e);
    if (t) {
      var i = o(this).constructor;
      n = Reflect.construct(r, arguments, i);
    } else n = r.apply(this, arguments);
    return Ce(this, n);
  };
}
function Te(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var n = 0, r = Array(t); n < t; n++) r[n] = e[n];
  return r;
}
var Ee = e(() => {});
function De(e) {
  if (Array.isArray(e)) return Te(e);
}
var Oe = e(() => {
  Ee();
});
function ke(e) {
  if (
    (typeof Symbol < `u` && e[Symbol.iterator] != null) ||
    e[`@@iterator`] != null
  )
    return Array.from(e);
}
var Ae = e(() => {});
function je(e, t) {
  if (e) {
    if (typeof e == `string`) return Te(e, t);
    var n = {}.toString.call(e).slice(8, -1);
    return (
      n === `Object` && e.constructor && (n = e.constructor.name),
      n === `Map` || n === `Set`
        ? Array.from(e)
        : n === `Arguments` ||
          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
        ? Te(e, t)
        : void 0
    );
  }
}
var Me = e(() => {
  Ee();
});
function Ne() {
  throw TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
var Pe = e(() => {});
function P(e) {
  return De(e) || ke(e) || je(e) || Ne();
}
var Fe = e(() => {
  Oe(), Ae(), Me(), Pe();
});
function Ie(e) {
  if (Array.isArray(e)) return e;
}
var Le = e(() => {});
function Re(e, t) {
  var n =
    e == null
      ? null
      : (typeof Symbol < `u` && e[Symbol.iterator]) || e[`@@iterator`];
  if (n != null) {
    var r,
      i,
      a,
      o,
      s = [],
      c = !0,
      l = !1;
    try {
      if (((a = (n = n.call(e)).next), t === 0)) {
        if (Object(n) !== n) return;
        c = !1;
      } else
        for (
          ;
          !(c = (r = a.call(n)).done) && (s.push(r.value), s.length !== t);
          c = !0
        );
    } catch (e) {
      (l = !0), (i = e);
    } finally {
      try {
        if (!c && n.return != null && ((o = n.return()), Object(o) !== o))
          return;
      } finally {
        if (l) throw i;
      }
    }
    return s;
  }
}
var ze = e(() => {});
function Be() {
  throw TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
var Ve = e(() => {});
function F(e, t) {
  return Ie(e) || Re(e, t) || je(e, t) || Be();
}
var I = e(() => {
  Le(), ze(), Me(), Ve();
});
Fe(), I();
function He(e) {
  for (var t = 0, n, r = 0, i = e.length; i >= 4; ++r, i -= 4)
    (n =
      (e.charCodeAt(r) & 255) |
      ((e.charCodeAt(++r) & 255) << 8) |
      ((e.charCodeAt(++r) & 255) << 16) |
      ((e.charCodeAt(++r) & 255) << 24)),
      (n = (n & 65535) * 1540483477 + (((n >>> 16) * 59797) << 16)),
      (n ^= n >>> 24),
      (t =
        ((n & 65535) * 1540483477 + (((n >>> 16) * 59797) << 16)) ^
        ((t & 65535) * 1540483477 + (((t >>> 16) * 59797) << 16)));
  switch (i) {
    case 3:
      t ^= (e.charCodeAt(r + 2) & 255) << 16;
    case 2:
      t ^= (e.charCodeAt(r + 1) & 255) << 8;
    case 1:
      (t ^= e.charCodeAt(r) & 255),
        (t = (t & 65535) * 1540483477 + (((t >>> 16) * 59797) << 16));
  }
  return (
    (t ^= t >>> 13),
    (t = (t & 65535) * 1540483477 + (((t >>> 16) * 59797) << 16)),
    ((t ^ (t >>> 15)) >>> 0).toString(36)
  );
}
function Ue() {
  return !!(
    typeof window < `u` &&
    window.document &&
    window.document.createElement
  );
}
function We(e, t) {
  if (!e) return !1;
  if (e.contains) return e.contains(t);
  for (var n = t; n; ) {
    if (n === e) return !0;
    n = n.parentNode;
  }
  return !1;
}
var Ge = `data-rc-order`,
  Ke = `data-rc-priority`,
  qe = `rc-util-key`,
  Je = new Map();
function Ye() {
  var e = (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {})
    .mark;
  return e ? (e.startsWith(`data-`) ? e : `data-${e}`) : qe;
}
function Xe(e) {
  return e.attachTo
    ? e.attachTo
    : document.querySelector(`head`) || document.body;
}
function Ze(e) {
  return e === `queue` ? `prependQueue` : e ? `prepend` : `append`;
}
function Qe(e) {
  return Array.from((Je.get(e) || e).children).filter(function (e) {
    return e.tagName === `STYLE`;
  });
}
function $e(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  if (!Ue()) return null;
  var n = t.csp,
    r = t.prepend,
    i = t.priority,
    a = i === void 0 ? 0 : i,
    o = Ze(r),
    s = o === `prependQueue`,
    c = document.createElement(`style`);
  c.setAttribute(Ge, o),
    s && a && c.setAttribute(Ke, `${a}`),
    n != null && n.nonce && (c.nonce = n == null ? void 0 : n.nonce),
    (c.innerHTML = e);
  var l = Xe(t),
    u = l.firstChild;
  if (r) {
    if (s) {
      var d = (t.styles || Qe(l)).filter(function (e) {
        return [`prepend`, `prependQueue`].includes(e.getAttribute(Ge))
          ? a >= Number(e.getAttribute(Ke) || 0)
          : !1;
      });
      if (d.length) return l.insertBefore(c, d[d.length - 1].nextSibling), c;
    }
    l.insertBefore(c, u);
  } else l.appendChild(c);
  return c;
}
function et(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    n = Xe(t);
  return (t.styles || Qe(n)).find(function (n) {
    return n.getAttribute(Ye(t)) === e;
  });
}
function tt(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    n = et(e, t);
  n && Xe(t).removeChild(n);
}
function nt(e, t) {
  var n = Je.get(e);
  if (!n || !We(document, n)) {
    var r = $e(``, t),
      i = r.parentNode;
    Je.set(e, i), e.removeChild(r);
  }
}
function L(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
    r = Xe(n),
    i = Qe(r),
    a = k(k({}, n), {}, { styles: i });
  nt(r, a);
  var o = et(t, a);
  if (o) {
    var s, c;
    if (
      (s = a.csp) != null &&
      s.nonce &&
      o.nonce !== ((c = a.csp) == null ? void 0 : c.nonce)
    ) {
      var l;
      o.nonce = (l = a.csp) == null ? void 0 : l.nonce;
    }
    return o.innerHTML !== e && (o.innerHTML = e), o;
  }
  var u = $e(e, a);
  return u.setAttribute(Ye(a), t), u;
}
function rt(e, t) {
  if (e == null) return {};
  var n = {};
  for (var r in e)
    if ({}.hasOwnProperty.call(e, r)) {
      if (t.indexOf(r) !== -1) continue;
      n[r] = e[r];
    }
  return n;
}
var it = e(() => {});
function at(e, t) {
  if (e == null) return {};
  var n,
    r,
    i = rt(e, t);
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (r = 0; r < a.length; r++)
      (n = a[r]),
        t.indexOf(n) === -1 &&
          {}.propertyIsEnumerable.call(e, n) &&
          (i[n] = e[n]);
  }
  return i;
}
var ot = e(() => {
  it();
});
ot(), m();
function st(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2],
    r = new Set();
  function i(e, t) {
    var a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1,
      o = r.has(e);
    if ((E(!o, `Warning: There may be circular references`), o)) return !1;
    if (e === t) return !0;
    if (n && a > 1) return !1;
    r.add(e);
    var s = a + 1;
    if (Array.isArray(e)) {
      if (!Array.isArray(t) || e.length !== t.length) return !1;
      for (var c = 0; c < e.length; c++) if (!i(e[c], t[c], s)) return !1;
      return !0;
    }
    if (e && t && p(e) === `object` && p(t) === `object`) {
      var l = Object.keys(e);
      return (
        l.length === Object.keys(t).length &&
        l.every(function (n) {
          return i(e[n], t[n], s);
        })
      );
    }
    return !1;
  }
  return i(e, t);
}
O();
var ct = `%`;
function lt(e) {
  return e.join(ct);
}
var ut = (function () {
    function e(t) {
      A(this, e),
        D(this, `instanceId`, void 0),
        D(this, `cache`, new Map()),
        D(this, `extracted`, new Set()),
        (this.instanceId = t);
    }
    return (
      M(e, [
        {
          key: `get`,
          value: function (e) {
            return this.opGet(lt(e));
          },
        },
        {
          key: `opGet`,
          value: function (e) {
            return this.cache.get(e) || null;
          },
        },
        {
          key: `update`,
          value: function (e, t) {
            return this.opUpdate(lt(e), t);
          },
        },
        {
          key: `opUpdate`,
          value: function (e, t) {
            var n = t(this.cache.get(e));
            n === null ? this.cache.delete(e) : this.cache.set(e, n);
          },
        },
      ]),
      e
    );
  })(),
  dt = [`children`],
  R = `data-token-hash`,
  z = `data-css-hash`,
  ft = `__cssinjs_instance__`;
function pt() {
  var e = Math.random().toString(12).slice(2);
  if (typeof document < `u` && document.head && document.body) {
    var t = document.body.querySelectorAll(`style[data-css-hash]`) || [],
      n = document.head.firstChild;
    Array.from(t).forEach(function (t) {
      (t[ft] = t.__cssinjs_instance__ || e),
        t.__cssinjs_instance__ === e && document.head.insertBefore(t, n);
    });
    var r = {};
    Array.from(document.querySelectorAll(`style[${z}]`)).forEach(function (t) {
      var n = t.getAttribute(z);
      if (r[n]) {
        if (t.__cssinjs_instance__ === e) {
          var i;
          (i = t.parentNode) == null || i.removeChild(t);
        }
      } else r[n] = !0;
    });
  }
  return new ut(e);
}
var B = h.createContext({ hashPriority: `low`, cache: pt(), defaultCache: !0 }),
  mt = function (e) {
    var t = e.children,
      n = at(e, dt),
      r = h.useContext(B),
      i = de(
        function () {
          var e = k({}, r);
          Object.keys(n).forEach(function (t) {
            var r = n[t];
            n[t] !== void 0 && (e[t] = r);
          });
          var t = n.cache;
          return (
            (e.cache = e.cache || pt()),
            (e.defaultCache = !t && r.defaultCache),
            e
          );
        },
        [r, n],
        function (e, t) {
          return !st(e[0], t[0], !0) || !st(e[1], t[1], !0);
        }
      );
    return h.createElement(B.Provider, { value: i }, t);
  };
j(), N(), O();
function ht(e, t) {
  if (e.length !== t.length) return !1;
  for (var n = 0; n < e.length; n++) if (e[n] !== t[n]) return !1;
  return !0;
}
var gt = (function () {
  function e() {
    A(this, e),
      D(this, `cache`, void 0),
      D(this, `keys`, void 0),
      D(this, `cacheCallTimes`, void 0),
      (this.cache = new Map()),
      (this.keys = []),
      (this.cacheCallTimes = 0);
  }
  return (
    M(e, [
      {
        key: `size`,
        value: function () {
          return this.keys.length;
        },
      },
      {
        key: `internalGet`,
        value: function (e) {
          var t,
            n,
            r = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
            i = { map: this.cache };
          return (
            e.forEach(function (e) {
              if (!i) i = void 0;
              else {
                var t;
                i = (t = i) == null || (t = t.map) == null ? void 0 : t.get(e);
              }
            }),
            (t = i) != null &&
              t.value &&
              r &&
              (i.value[1] = this.cacheCallTimes++),
            (n = i) == null ? void 0 : n.value
          );
        },
      },
      {
        key: `get`,
        value: function (e) {
          var t;
          return (t = this.internalGet(e, !0)) == null ? void 0 : t[0];
        },
      },
      {
        key: `has`,
        value: function (e) {
          return !!this.internalGet(e);
        },
      },
      {
        key: `set`,
        value: function (t, n) {
          var r = this;
          if (!this.has(t)) {
            if (this.size() + 1 > e.MAX_CACHE_SIZE + e.MAX_CACHE_OFFSET) {
              var i = F(
                this.keys.reduce(
                  function (e, t) {
                    var n = F(e, 2)[1];
                    return r.internalGet(t)[1] < n
                      ? [t, r.internalGet(t)[1]]
                      : e;
                  },
                  [this.keys[0], this.cacheCallTimes]
                ),
                1
              )[0];
              this.delete(i);
            }
            this.keys.push(t);
          }
          var a = this.cache;
          t.forEach(function (e, i) {
            if (i === t.length - 1)
              a.set(e, { value: [n, r.cacheCallTimes++] });
            else {
              var o = a.get(e);
              o ? o.map || (o.map = new Map()) : a.set(e, { map: new Map() }),
                (a = a.get(e).map);
            }
          });
        },
      },
      {
        key: `deleteByPath`,
        value: function (e, t) {
          var n = e.get(t[0]);
          if (t.length === 1) {
            var r;
            return (
              n.map ? e.set(t[0], { map: n.map }) : e.delete(t[0]),
              (r = n.value) == null ? void 0 : r[0]
            );
          }
          var i = this.deleteByPath(n.map, t.slice(1));
          return (!n.map || n.map.size === 0) && !n.value && e.delete(t[0]), i;
        },
      },
      {
        key: `delete`,
        value: function (e) {
          if (this.has(e))
            return (
              (this.keys = this.keys.filter(function (t) {
                return !ht(t, e);
              })),
              this.deleteByPath(this.cache, e)
            );
        },
      },
    ]),
    e
  );
})();
D(gt, `MAX_CACHE_SIZE`, 20), D(gt, `MAX_CACHE_OFFSET`, 5), j(), N(), O();
var _t = 0,
  vt = (function () {
    function e(t) {
      A(this, e),
        D(this, `derivatives`, void 0),
        D(this, `id`, void 0),
        (this.derivatives = Array.isArray(t) ? t : [t]),
        (this.id = _t),
        t.length === 0 && t.length,
        (_t += 1);
    }
    return (
      M(e, [
        {
          key: `getDerivativeToken`,
          value: function (e) {
            return this.derivatives.reduce(function (t, n) {
              return n(e, t);
            }, void 0);
          },
        },
      ]),
      e
    );
  })(),
  yt = new gt();
function bt(e) {
  var t = Array.isArray(e) ? e : [e];
  return yt.has(t) || yt.set(t, new vt(t)), yt.get(t);
}
O(), m();
var xt = new WeakMap(),
  St = {};
function Ct(e, t) {
  for (var n = xt, r = 0; r < t.length; r += 1) {
    var i = t[r];
    n.has(i) || n.set(i, new WeakMap()), (n = n.get(i));
  }
  return n.has(St) || n.set(St, e()), n.get(St);
}
var wt = new WeakMap();
function Tt(e) {
  var t = wt.get(e) || ``;
  return (
    t ||
      (Object.keys(e).forEach(function (n) {
        var r = e[n];
        (t += n),
          r instanceof vt
            ? (t += r.id)
            : r && p(r) === `object`
            ? (t += Tt(r))
            : (t += r);
      }),
      (t = He(t)),
      wt.set(e, t)),
    t
  );
}
function Et(e, t) {
  return He(`${t}_${Tt(e)}`);
}
`random-${Date.now()}-${Math.random()}`.replace(/\./g, ``);
var Dt = Ue();
function Ot(e) {
  return typeof e == `number` ? `${e}px` : e;
}
function kt(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
  if (arguments.length > 4 && arguments[4] !== void 0 && arguments[4]) return e;
  var i = k(k({}, r), {}, D(D({}, R, t), z, n));
  return `<style ${Object.keys(i)
    .map(function (e) {
      var t = i[e];
      return t ? `${e}="${t}"` : null;
    })
    .filter(function (e) {
      return e;
    })
    .join(` `)}>${e}</style>`;
}
I();
var At = function (e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ``;
    return `--${t ? `${t}-` : ``}${e}`
      .replace(/([a-z0-9])([A-Z])/g, `$1-$2`)
      .replace(/([A-Z]+)([A-Z][a-z0-9]+)/g, `$1-$2`)
      .replace(/([a-z])([A-Z0-9])/g, `$1-$2`)
      .toLowerCase();
  },
  jt = function (e, t, n) {
    return Object.keys(e).length
      ? `.${t}${n != null && n.scope ? `.${n.scope}` : ``}{${Object.entries(e)
          .map(function (e) {
            var t = F(e, 2);
            return `${t[0]}:${t[1]};`;
          })
          .join(``)}}`
      : ``;
  },
  Mt = function (e, t, n) {
    var r = {},
      i = {};
    return (
      Object.entries(e).forEach(function (e) {
        var t,
          a,
          o = F(e, 2),
          s = o[0],
          c = o[1];
        if (n != null && (t = n.preserve) != null && t[s]) i[s] = c;
        else if (
          (typeof c == `string` || typeof c == `number`) &&
          !(n != null && (a = n.ignore) != null && a[s])
        ) {
          var l,
            u = At(s, n == null ? void 0 : n.prefix);
          (r[u] =
            typeof c == `number` &&
            !(n != null && (l = n.unitless) != null && l[s])
              ? `${c}px`
              : String(c)),
            (i[s] = `var(${u})`);
        }
      }),
      [i, jt(r, t, { scope: n == null ? void 0 : n.scope })]
    );
  },
  Nt = Ue() ? h.useLayoutEffect : h.useEffect,
  Pt = function (e, t) {
    var n = h.useRef(!0);
    Nt(function () {
      return e(n.current);
    }, t),
      Nt(function () {
        return (
          (n.current = !1),
          function () {
            n.current = !0;
          }
        );
      }, []);
  },
  Ft = function (e, t) {
    Pt(function (t) {
      if (!t) return e();
    }, t);
  },
  It = k({}, h).useInsertionEffect,
  Lt = It
    ? function (e, t, n) {
        return It(function () {
          return e(), t();
        }, n);
      }
    : function (e, t, n) {
        h.useMemo(e, n),
          Pt(function () {
            return t(!0);
          }, n);
      },
  Rt =
    k({}, h).useInsertionEffect === void 0
      ? function () {
          return function (e) {
            e();
          };
        }
      : function (e) {
          var t = [],
            n = !1;
          function r(e) {
            n || t.push(e);
          }
          return (
            h.useEffect(function () {
              return (
                (n = !1),
                function () {
                  (n = !0),
                    t.length &&
                      t.forEach(function (e) {
                        return e();
                      });
                }
              );
            }, e),
            r
          );
        };
I();
function zt(e, t, n, r, i) {
  var a = h.useContext(B).cache,
    o = lt([e].concat(P(t))),
    s = Rt([o]),
    c = function (e) {
      a.opUpdate(o, function (t) {
        var r = F(t || [void 0, void 0], 2),
          i = r[0],
          a = [i === void 0 ? 0 : i, r[1] || n()];
        return e ? e(a) : a;
      });
    };
  h.useMemo(
    function () {
      c();
    },
    [o]
  );
  var l = a.opGet(o)[1];
  return (
    Lt(
      function () {
        i == null || i(l);
      },
      function (e) {
        return (
          c(function (t) {
            var n = F(t, 2),
              r = n[0],
              a = n[1];
            return e && r === 0 && (i == null || i(l)), [r + 1, a];
          }),
          function () {
            a.opUpdate(o, function (t) {
              var n = F(t || [], 2),
                i = n[0],
                c = i === void 0 ? 0 : i,
                l = n[1];
              return c - 1 == 0
                ? (s(function () {
                    (e || !a.opGet(o)) && (r == null || r(l, !1));
                  }),
                  null)
                : [c - 1, l];
            });
          }
        );
      },
      [o]
    ),
    l
  );
}
I(), Fe();
var Bt = {},
  Vt = `css`,
  V = new Map();
function Ht(e) {
  V.set(e, (V.get(e) || 0) + 1);
}
function Ut(e, t) {
  typeof document < `u` &&
    document.querySelectorAll(`style[${R}="${e}"]`).forEach(function (e) {
      if (e.__cssinjs_instance__ === t) {
        var n;
        (n = e.parentNode) == null || n.removeChild(e);
      }
    });
}
var Wt = 0;
function Gt(e, t) {
  V.set(e, (V.get(e) || 0) - 1);
  var n = new Set();
  V.forEach(function (e, t) {
    e <= 0 && n.add(t);
  }),
    V.size - n.size > Wt &&
      n.forEach(function (e) {
        Ut(e, t), V.delete(e);
      });
}
var Kt = function (e, t, n, r) {
    var i = k(k({}, n.getDerivativeToken(e)), t);
    return r && (i = r(i)), i;
  },
  qt = `token`;
function Jt(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
    r = (0, h.useContext)(B),
    i = r.cache.instanceId,
    a = r.container,
    o = n.salt,
    s = o === void 0 ? `` : o,
    c = n.override,
    l = c === void 0 ? Bt : c,
    u = n.formatToken,
    d = n.getComputedToken,
    f = n.cssVar,
    p = Ct(function () {
      return Object.assign.apply(Object, [{}].concat(P(t)));
    }, t),
    m = Tt(p),
    g = Tt(l),
    _ = f ? Tt(f) : ``;
  return zt(
    qt,
    [s, e.id, m, g, _],
    function () {
      var t = d ? d(p, l, e) : Kt(p, l, e, u),
        n = k({}, t),
        r = ``;
      if (f) {
        var i = F(
          Mt(t, f.key, {
            prefix: f.prefix,
            ignore: f.ignore,
            unitless: f.unitless,
            preserve: f.preserve,
          }),
          2
        );
        (t = i[0]), (r = i[1]);
      }
      var a = Et(t, s);
      (t._tokenKey = a), (n._tokenKey = Et(n, s));
      var o = (f == null ? void 0 : f.key) ?? a;
      (t._themeKey = o), Ht(o);
      var c = `${Vt}-${He(a)}`;
      return (t._hashId = c), [t, c, n, r, (f == null ? void 0 : f.key) || ``];
    },
    function (e) {
      Gt(e[0]._themeKey, i);
    },
    function (e) {
      var t = F(e, 4),
        n = t[0],
        r = t[3];
      if (f && r) {
        var o = L(r, He(`css-variables-${n._themeKey}`), {
          mark: z,
          prepend: `queue`,
          attachTo: a,
          priority: -999,
        });
        (o[ft] = i), o.setAttribute(R, n._themeKey);
      }
    }
  );
}
var Yt = function (e, t, n) {
    var r = F(e, 5),
      i = r[2],
      a = r[3],
      o = r[4],
      s = (n || {}).plain;
    if (!a) return null;
    var c = i._tokenKey,
      l = -999;
    return [
      l,
      c,
      kt(
        a,
        o,
        c,
        { "data-rc-order": `prependQueue`, "data-rc-priority": `${l}` },
        s
      ),
    ];
  },
  Xt = {
    animationIterationCount: 1,
    borderImageOutset: 1,
    borderImageSlice: 1,
    borderImageWidth: 1,
    boxFlex: 1,
    boxFlexGroup: 1,
    boxOrdinalGroup: 1,
    columnCount: 1,
    columns: 1,
    flex: 1,
    flexGrow: 1,
    flexPositive: 1,
    flexShrink: 1,
    flexNegative: 1,
    flexOrder: 1,
    gridRow: 1,
    gridRowEnd: 1,
    gridRowSpan: 1,
    gridRowStart: 1,
    gridColumn: 1,
    gridColumnEnd: 1,
    gridColumnSpan: 1,
    gridColumnStart: 1,
    msGridRow: 1,
    msGridRowSpan: 1,
    msGridColumn: 1,
    msGridColumnSpan: 1,
    fontWeight: 1,
    lineHeight: 1,
    opacity: 1,
    order: 1,
    orphans: 1,
    tabSize: 1,
    widows: 1,
    zIndex: 1,
    zoom: 1,
    WebkitLineClamp: 1,
    fillOpacity: 1,
    floodOpacity: 1,
    stopOpacity: 1,
    strokeDasharray: 1,
    strokeDashoffset: 1,
    strokeMiterlimit: 1,
    strokeOpacity: 1,
    strokeWidth: 1,
  },
  Zt = `comm`,
  Qt = `rule`,
  $t = `decl`,
  en = `@import`,
  tn = `@namespace`,
  nn = `@keyframes`,
  rn = `@layer`,
  an = Math.abs,
  on = String.fromCharCode;
function sn(e) {
  return e.trim();
}
function cn(e, t, n) {
  return e.replace(t, n);
}
function ln(e, t, n) {
  return e.indexOf(t, n);
}
function H(e, t) {
  return e.charCodeAt(t) | 0;
}
function U(e, t, n) {
  return e.slice(t, n);
}
function W(e) {
  return e.length;
}
function un(e) {
  return e.length;
}
function dn(e, t) {
  return t.push(e), e;
}
var fn = 1,
  pn = 1,
  mn = 0,
  G = 0,
  K = 0,
  hn = ``;
function gn(e, t, n, r, i, a, o, s) {
  return {
    value: e,
    root: t,
    parent: n,
    type: r,
    props: i,
    children: a,
    line: fn,
    column: pn,
    length: o,
    return: ``,
    siblings: s,
  };
}
function _n() {
  return K;
}
function vn() {
  return (K = G > 0 ? H(hn, --G) : 0), pn--, K === 10 && ((pn = 1), fn--), K;
}
function q() {
  return (K = G < mn ? H(hn, G++) : 0), pn++, K === 10 && ((pn = 1), fn++), K;
}
function J() {
  return H(hn, G);
}
function yn() {
  return G;
}
function bn(e, t) {
  return U(hn, e, t);
}
function xn(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function Sn(e) {
  return (fn = pn = 1), (mn = W((hn = e))), (G = 0), [];
}
function Cn(e) {
  return (hn = ``), e;
}
function wn(e) {
  return sn(bn(G - 1, Dn(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function Tn(e) {
  for (; (K = J()) && K < 33; ) q();
  return xn(e) > 2 || xn(K) > 3 ? `` : ` `;
}
function En(e, t) {
  for (
    ;
    --t &&
    q() &&
    !(K < 48 || K > 102 || (K > 57 && K < 65) || (K > 70 && K < 97));

  );
  return bn(e, yn() + (t < 6 && J() == 32 && q() == 32));
}
function Dn(e) {
  for (; q(); )
    switch (K) {
      case e:
        return G;
      case 34:
      case 39:
        e !== 34 && e !== 39 && Dn(K);
        break;
      case 40:
        e === 41 && Dn(e);
        break;
      case 92:
        q();
    }
  return G;
}
function On(e, t) {
  for (; q() && e + K !== 57 && (e + K !== 84 || J() !== 47); );
  return `/*` + bn(t, G - 1) + `*` + on(e === 47 ? e : q());
}
function kn(e) {
  for (; !xn(J()); ) q();
  return bn(e, G);
}
function An(e) {
  return Cn(jn(``, null, null, null, [``], (e = Sn(e)), 0, [0], e));
}
function jn(e, t, n, r, i, a, o, s, c) {
  for (
    var l = 0,
      u = 0,
      d = o,
      f = 0,
      p = 0,
      m = 0,
      h = 1,
      g = 1,
      _ = 1,
      v = 0,
      y = ``,
      b = i,
      x = a,
      S = r,
      C = y;
    g;

  )
    switch (((m = v), (v = q()))) {
      case 40:
        if (m != 108 && H(C, d - 1) == 58) {
          ln((C += cn(wn(v), `&`, `&\f`)), `&\f`, an(l ? s[l - 1] : 0)) != -1 &&
            (_ = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        C += wn(v);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        C += Tn(m);
        break;
      case 92:
        C += En(yn() - 1, 7);
        continue;
      case 47:
        switch (J()) {
          case 42:
          case 47:
            dn(Nn(On(q(), yn()), t, n, c), c),
              (xn(m || 1) == 5 || xn(J() || 1) == 5) &&
                W(C) &&
                U(C, -1, void 0) !== ` ` &&
                (C += ` `);
            break;
          default:
            C += `/`;
        }
        break;
      case 123 * h:
        s[l++] = W(C) * _;
      case 125 * h:
      case 59:
      case 0:
        switch (v) {
          case 0:
          case 125:
            g = 0;
          case 59 + u:
            _ == -1 && (C = cn(C, /\f/g, ``)),
              p > 0 &&
                (W(C) - d || (h === 0 && m === 47)) &&
                dn(
                  p > 32
                    ? Pn(C + `;`, r, n, d - 1, c)
                    : Pn(cn(C, ` `, ``) + `;`, r, n, d - 2, c),
                  c
                );
            break;
          case 59:
            C += `;`;
          default:
            if (
              (dn(
                (S = Mn(C, t, n, l, u, i, s, y, (b = []), (x = []), d, a)),
                a
              ),
              v === 123)
            ) {
              if (u === 0) jn(C, t, S, S, b, a, d, s, x);
              else {
                switch (f) {
                  case 99:
                    if (H(C, 3) === 110) break;
                  case 108:
                    if (H(C, 2) === 97) break;
                  default:
                    u = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                u
                  ? jn(
                      e,
                      S,
                      S,
                      r && dn(Mn(e, S, S, 0, 0, i, s, y, i, (b = []), d, x), x),
                      i,
                      x,
                      d,
                      s,
                      r ? b : x
                    )
                  : jn(C, S, S, S, [``], x, 0, s, x);
              }
            }
        }
        (l = u = p = 0), (h = _ = 1), (y = C = ``), (d = o);
        break;
      case 58:
        (d = 1 + W(C)), (p = m);
      default:
        if (h < 1) {
          if (v == 123) --h;
          else if (v == 125 && h++ == 0 && vn() == 125) continue;
        }
        switch (((C += on(v)), v * h)) {
          case 38:
            _ = u > 0 ? 1 : ((C += `\f`), -1);
            break;
          case 44:
            (s[l++] = (W(C) - 1) * _), (_ = 1);
            break;
          case 64:
            J() === 45 && (C += wn(q())),
              (f = J()),
              (u = d = W((y = C += kn(yn())))),
              v++;
            break;
          case 45:
            m === 45 && W(C) == 2 && (h = 0);
        }
    }
  return a;
}
function Mn(e, t, n, r, i, a, o, s, c, l, u, d) {
  for (
    var f = i - 1, p = i === 0 ? a : [``], m = un(p), h = 0, g = 0, _ = 0;
    h < r;
    ++h
  )
    for (var v = 0, y = U(e, f + 1, (f = an((g = o[h])))), b = e; v < m; ++v)
      (b = sn(g > 0 ? p[v] + ` ` + y : cn(y, /&\f/g, p[v]))) && (c[_++] = b);
  return gn(e, t, n, i === 0 ? Qt : s, c, l, u, d);
}
function Nn(e, t, n, r) {
  return gn(e, t, n, Zt, on(_n()), U(e, 2, -2), 0, r);
}
function Pn(e, t, n, r, i) {
  return gn(e, t, n, $t, U(e, 0, r), U(e, r + 1, -1), r, i);
}
function Fn(e, t) {
  for (var n = ``, r = 0; r < e.length; r++) n += t(e[r], r, e, t) || ``;
  return n;
}
function In(e, t, n, r) {
  switch (e.type) {
    case rn:
      if (e.children.length) break;
    case en:
    case tn:
    case $t:
      return (e.return = e.return || e.value);
    case Zt:
      return ``;
    case nn:
      return (e.return = e.value + `{` + Fn(e.children, r) + `}`);
    case Qt:
      if (!W((e.value = e.props.join(`,`)))) return ``;
  }
  return W((n = Fn(e.children, r))) ? (e.return = e.value + `{` + n + `}`) : ``;
}
I();
var Ln = `data-ant-cssinjs-cache-path`,
  Rn = `_FILE_STYLE__`,
  Y,
  zn = !0;
function Bn() {
  if (!Y && ((Y = {}), Ue())) {
    var e = document.createElement(`div`);
    (e.className = Ln),
      (e.style.position = `fixed`),
      (e.style.visibility = `hidden`),
      (e.style.top = `-9999px`),
      document.body.appendChild(e);
    var t = getComputedStyle(e).content || ``;
    (t = t.replace(/^"/, ``).replace(/"$/, ``)),
      t.split(`;`).forEach(function (e) {
        var t = F(e.split(`:`), 2),
          n = t[0],
          r = t[1];
        Y[n] = r;
      });
    var n = document.querySelector(`style[${Ln}]`);
    if (n) {
      var r;
      (zn = !1), (r = n.parentNode) == null || r.removeChild(n);
    }
    document.body.removeChild(e);
  }
}
function Vn(e) {
  return Bn(), !!Y[e];
}
function Hn(e) {
  var t = Y[e],
    n = null;
  if (t && Ue()) {
    if (zn) n = Rn;
    else {
      var r = document.querySelector(`style[${z}="${Y[e]}"]`);
      r ? (n = r.innerHTML) : delete Y[e];
    }
  }
  return [n, t];
}
O(), I(), Fe(), m();
var Un = `_skip_check_`,
  Wn = `_multi_value_`;
function Gn(e) {
  return Fn(An(e), In).replace(/\{%%%\:[^;];}/g, `;`);
}
function Kn(e) {
  return p(e) === `object` && e && (Un in e || Wn in e);
}
function qn(e, t, n) {
  if (!t) return e;
  var r = `.${t}`,
    i = n === `low` ? `:where(${r})` : r;
  return e
    .split(`,`)
    .map(function (e) {
      var t,
        n = e.trim().split(/\s+/),
        r = n[0] || ``,
        a = ((t = r.match(/^\w+/)) == null ? void 0 : t[0]) || ``;
      return (
        (r = `${a}${i}${r.slice(a.length)}`),
        [r].concat(P(n.slice(1))).join(` `)
      );
    })
    .join(`,`);
}
var Jn = function e(t) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    r =
      arguments.length > 2 && arguments[2] !== void 0
        ? arguments[2]
        : { root: !0, parentSelectors: [] },
    i = r.root,
    a = r.injectHash,
    o = r.parentSelectors,
    s = n.hashId,
    c = n.layer;
  n.path;
  var l = n.hashPriority,
    u = n.transformers,
    d = u === void 0 ? [] : u;
  n.linters;
  var f = ``,
    m = {};
  function h(t) {
    var r = t.getName(s);
    if (!m[r]) {
      var i = F(e(t.style, n, { root: !1, parentSelectors: o }), 1)[0];
      m[r] = `@keyframes ${t.getName(s)}${i}`;
    }
  }
  function g(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [];
    return (
      e.forEach(function (e) {
        Array.isArray(e) ? g(e, t) : e && t.push(e);
      }),
      t
    );
  }
  return (
    g(Array.isArray(t) ? t : [t]).forEach(function (t) {
      var r = typeof t == `string` && !i ? {} : t;
      if (typeof r == `string`)
        f += `${r}
`;
      else if (r._keyframe) h(r);
      else {
        var c = d.reduce(function (e, t) {
          var n;
          return (
            (t == null || (n = t.visit) == null ? void 0 : n.call(t, e)) || e
          );
        }, r);
        Object.keys(c).forEach(function (t) {
          var r = c[t];
          if (
            p(r) === `object` &&
            r &&
            (t !== `animationName` || !r._keyframe) &&
            !Kn(r)
          ) {
            var u = !1,
              d = t.trim(),
              g = !1;
            (i || a) && s
              ? d.startsWith(`@`)
                ? (u = !0)
                : (d = qn(d === `&` ? `` : t, s, l))
              : i && !s && (d === `&` || d === ``) && ((d = ``), (g = !0));
            var _ = F(
                e(r, n, {
                  root: g,
                  injectHash: u,
                  parentSelectors: [].concat(P(o), [d]),
                }),
                2
              ),
              v = _[0],
              y = _[1];
            (m = k(k({}, m), y)), (f += `${d}${v}`);
          } else {
            function e(e, t) {
              var n = e.replace(/[A-Z]/g, function (e) {
                  return `-${e.toLowerCase()}`;
                }),
                r = t;
              !Xt[e] && typeof r == `number` && r !== 0 && (r = `${r}px`),
                e === `animationName` &&
                  t != null &&
                  t._keyframe &&
                  (h(t), (r = t.getName(s))),
                (f += `${n}:${r};`);
            }
            var b = (r == null ? void 0 : r.value) ?? r;
            p(r) === `object` && r != null && r[Wn] && Array.isArray(b)
              ? b.forEach(function (n) {
                  e(t, n);
                })
              : e(t, b);
          }
        });
      }
    }),
    i
      ? c &&
        (f && (f = `@layer ${c.name} {${f}}`),
        c.dependencies &&
          (m[`@layer ${c.name}`] = c.dependencies.map(function (e) {
            return `@layer ${e}, ${c.name};`;
          }).join(`
`)))
      : (f = `{${f}}`),
    [f, m]
  );
};
function Yn(e, t) {
  return He(`${e.join(`%`)}${t}`);
}
function Xn() {
  return null;
}
var Zn = `style`;
function Qn(e, t) {
  var n = e.token,
    r = e.path,
    i = e.hashId,
    a = e.layer,
    o = e.nonce,
    s = e.clientOnly,
    c = e.order,
    l = c === void 0 ? 0 : c,
    d = h.useContext(B),
    f = d.autoClear;
  d.mock;
  var p = d.defaultCache,
    m = d.hashPriority,
    g = d.container,
    _ = d.ssrInline,
    v = d.transformers,
    y = d.linters,
    b = d.cache,
    x = d.layer,
    S = n._tokenKey,
    C = [S];
  x && C.push(`layer`), C.push.apply(C, P(r));
  var w = Dt,
    T = F(
      zt(
        Zn,
        C,
        function () {
          var e = C.join(`|`);
          if (Vn(e)) {
            var n = F(Hn(e), 2),
              o = n[0],
              c = n[1];
            if (o) return [o, S, c, {}, s, l];
          }
          var u = F(
              Jn(t(), {
                hashId: i,
                hashPriority: m,
                layer: x ? a : void 0,
                path: r.join(`-`),
                transformers: v,
                linters: y,
              }),
              2
            ),
            d = u[0],
            f = u[1],
            p = Gn(d);
          return [p, S, Yn(C, p), f, s, l];
        },
        function (e, t) {
          var n = F(e, 3)[2];
          (t || f) && Dt && tt(n, { mark: z, attachTo: g });
        },
        function (e) {
          var t = F(e, 4),
            n = t[0];
          t[1];
          var r = t[2],
            i = t[3];
          if (w && n !== `_FILE_STYLE__`) {
            var a = {
                mark: z,
                prepend: !x && `queue`,
                attachTo: g,
                priority: l,
              },
              s = typeof o == `function` ? o() : o;
            s && (a.csp = { nonce: s });
            var c = [],
              u = [];
            Object.keys(i).forEach(function (e) {
              e.startsWith(`@layer`) ? c.push(e) : u.push(e);
            }),
              c.forEach(function (e) {
                L(Gn(i[e]), `_layer-${e}`, k(k({}, a), {}, { prepend: !0 }));
              });
            var d = L(n, r, a);
            (d[ft] = b.instanceId),
              d.setAttribute(R, S),
              u.forEach(function (e) {
                L(Gn(i[e]), `_effect-${e}`, a);
              });
          }
        }
      ),
      3
    ),
    ee = T[0],
    te = T[1],
    ne = T[2];
  return function (e) {
    var t =
      !_ || w || !p
        ? h.createElement(Xn, null)
        : h.createElement(
            `style`,
            u({}, D(D({}, R, te), z, ne), {
              dangerouslySetInnerHTML: { __html: ee },
            })
          );
    return h.createElement(h.Fragment, null, t, e);
  };
}
var $n = function (e, t, n) {
  var r = F(e, 6),
    i = r[0],
    a = r[1],
    o = r[2],
    s = r[3],
    c = r[4],
    l = r[5],
    u = (n || {}).plain;
  if (c) return null;
  var d = i,
    f = { "data-rc-order": `prependQueue`, "data-rc-priority": `${l}` };
  return (
    (d = kt(i, a, o, f, u)),
    s &&
      Object.keys(s).forEach(function (e) {
        if (!t[e]) {
          t[e] = !0;
          var n = kt(Gn(s[e]), a, `_effect-${e}`, f, u);
          e.startsWith(`@layer`) ? (d = n + d) : (d += n);
        }
      }),
    [l, o, d]
  );
};
I(), Fe();
var er = `cssVar`,
  tr = function (e, t) {
    var n = e.key,
      r = e.prefix,
      i = e.unitless,
      a = e.ignore,
      o = e.token,
      s = e.scope,
      c = s === void 0 ? `` : s,
      l = (0, h.useContext)(B),
      u = l.cache.instanceId,
      d = l.container,
      f = o._tokenKey,
      p = [].concat(P(e.path), [n, c, f]);
    return zt(
      er,
      p,
      function () {
        var e = F(
            Mt(t(), n, { prefix: r, unitless: i, ignore: a, scope: c }),
            2
          ),
          o = e[0],
          s = e[1];
        return [o, s, Yn(p, s), n];
      },
      function (e) {
        var t = F(e, 3)[2];
        Dt && tt(t, { mark: z, attachTo: d });
      },
      function (e) {
        var t = F(e, 3),
          r = t[1],
          i = t[2];
        if (r) {
          var a = L(r, i, {
            mark: z,
            prepend: `queue`,
            attachTo: d,
            priority: -999,
          });
          (a[ft] = u), a.setAttribute(R, n);
        }
      }
    );
  };
O(),
  D(D(D({}, Zn, $n), qt, Yt), er, function (e, t, n) {
    var r = F(e, 4),
      i = r[1],
      a = r[2],
      o = r[3],
      s = (n || {}).plain;
    if (!i) return null;
    var c = -999;
    return [
      c,
      a,
      kt(
        i,
        o,
        a,
        { "data-rc-order": `prependQueue`, "data-rc-priority": `${c}` },
        s
      ),
    ];
  }),
  I();
function nr(e) {
  if (typeof e == `number`) return [[e], !1];
  var t = String(e).trim(),
    n = t.match(/(.*)(!important)/),
    r = (n ? n[1] : t).trim().split(/\s+/),
    i = [],
    a = 0;
  return [
    r.reduce(function (e, t) {
      if (t.includes(`(`) || t.includes(`)`)) {
        var n = t.split(`(`).length - 1,
          r = t.split(`)`).length - 1;
        a += n - r;
      }
      return a >= 0 && i.push(t), a === 0 && (e.push(i.join(` `)), (i = [])), e;
    }, []),
    !!n,
  ];
}
function rr(e) {
  return (e.notSplit = !0), e;
}
var ir = {
  inset: [`top`, `right`, `bottom`, `left`],
  insetBlock: [`top`, `bottom`],
  insetBlockStart: [`top`],
  insetBlockEnd: [`bottom`],
  insetInline: [`left`, `right`],
  insetInlineStart: [`left`],
  insetInlineEnd: [`right`],
  marginBlock: [`marginTop`, `marginBottom`],
  marginBlockStart: [`marginTop`],
  marginBlockEnd: [`marginBottom`],
  marginInline: [`marginLeft`, `marginRight`],
  marginInlineStart: [`marginLeft`],
  marginInlineEnd: [`marginRight`],
  paddingBlock: [`paddingTop`, `paddingBottom`],
  paddingBlockStart: [`paddingTop`],
  paddingBlockEnd: [`paddingBottom`],
  paddingInline: [`paddingLeft`, `paddingRight`],
  paddingInlineStart: [`paddingLeft`],
  paddingInlineEnd: [`paddingRight`],
  borderBlock: rr([`borderTop`, `borderBottom`]),
  borderBlockStart: rr([`borderTop`]),
  borderBlockEnd: rr([`borderBottom`]),
  borderInline: rr([`borderLeft`, `borderRight`]),
  borderInlineStart: rr([`borderLeft`]),
  borderInlineEnd: rr([`borderRight`]),
  borderBlockWidth: [`borderTopWidth`, `borderBottomWidth`],
  borderBlockStartWidth: [`borderTopWidth`],
  borderBlockEndWidth: [`borderBottomWidth`],
  borderInlineWidth: [`borderLeftWidth`, `borderRightWidth`],
  borderInlineStartWidth: [`borderLeftWidth`],
  borderInlineEndWidth: [`borderRightWidth`],
  borderBlockStyle: [`borderTopStyle`, `borderBottomStyle`],
  borderBlockStartStyle: [`borderTopStyle`],
  borderBlockEndStyle: [`borderBottomStyle`],
  borderInlineStyle: [`borderLeftStyle`, `borderRightStyle`],
  borderInlineStartStyle: [`borderLeftStyle`],
  borderInlineEndStyle: [`borderRightStyle`],
  borderBlockColor: [`borderTopColor`, `borderBottomColor`],
  borderBlockStartColor: [`borderTopColor`],
  borderBlockEndColor: [`borderBottomColor`],
  borderInlineColor: [`borderLeftColor`, `borderRightColor`],
  borderInlineStartColor: [`borderLeftColor`],
  borderInlineEndColor: [`borderRightColor`],
  borderStartStartRadius: [`borderTopLeftRadius`],
  borderStartEndRadius: [`borderTopRightRadius`],
  borderEndStartRadius: [`borderBottomLeftRadius`],
  borderEndEndRadius: [`borderBottomRightRadius`],
};
function ar(e, t) {
  var n = e;
  return t && (n = `${n} !important`), { _skip_check_: !0, value: n };
}
var or = {
    visit: function (e) {
      var t = {};
      return (
        Object.keys(e).forEach(function (n) {
          var r = e[n],
            i = ir[n];
          if (i && (typeof r == `number` || typeof r == `string`)) {
            var a = F(nr(r), 2),
              o = a[0],
              s = a[1];
            i.length && i.notSplit
              ? i.forEach(function (e) {
                  t[e] = ar(r, s);
                })
              : i.length === 1
              ? (t[i[0]] = ar(o[0], s))
              : i.length === 2
              ? i.forEach(function (e, n) {
                  t[e] = ar(o[n] ?? o[0], s);
                })
              : i.length === 4
              ? i.forEach(function (e, n) {
                  t[e] = ar(o[n] ?? o[n - 2] ?? o[0], s);
                })
              : (t[n] = r);
          } else t[n] = r;
        }),
        t
      );
    },
  },
  sr = {
    blue: `#1677FF`,
    purple: `#722ED1`,
    cyan: `#13C2C2`,
    green: `#52C41A`,
    magenta: `#EB2F96`,
    pink: `#EB2F96`,
    red: `#F5222D`,
    orange: `#FA8C16`,
    yellow: `#FADB14`,
    volcano: `#FA541C`,
    geekblue: `#2F54EB`,
    gold: `#FAAD14`,
    lime: `#A0D911`,
  },
  cr = Object.assign(Object.assign({}, sr), {
    colorPrimary: `#1677ff`,
    colorSuccess: `#52c41a`,
    colorWarning: `#faad14`,
    colorError: `#ff4d4f`,
    colorInfo: `#1677ff`,
    colorLink: ``,
    colorTextBase: ``,
    colorBgBase: ``,
    fontFamily: `-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial,
'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol',
'Noto Color Emoji'`,
    fontFamilyCode: `'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, Courier, monospace`,
    fontSize: 14,
    lineWidth: 1,
    lineType: `solid`,
    motionUnit: 0.1,
    motionBase: 0,
    motionEaseOutCirc: `cubic-bezier(0.08, 0.82, 0.17, 1)`,
    motionEaseInOutCirc: `cubic-bezier(0.78, 0.14, 0.15, 0.86)`,
    motionEaseOut: `cubic-bezier(0.215, 0.61, 0.355, 1)`,
    motionEaseInOut: `cubic-bezier(0.645, 0.045, 0.355, 1)`,
    motionEaseOutBack: `cubic-bezier(0.12, 0.4, 0.29, 1.46)`,
    motionEaseInBack: `cubic-bezier(0.71, -0.46, 0.88, 0.6)`,
    motionEaseInQuint: `cubic-bezier(0.755, 0.05, 0.855, 0.06)`,
    motionEaseOutQuint: `cubic-bezier(0.23, 1, 0.32, 1)`,
    borderRadius: 6,
    sizeUnit: 4,
    sizeStep: 4,
    sizePopupArrow: 16,
    controlHeight: 32,
    zIndexBase: 0,
    zIndexPopupBase: 1e3,
    opacityImage: 1,
    wireframe: !1,
    motion: !0,
  });
O();
var X = Math.round;
function lr(e, t) {
  let n =
      e
        .replace(/^[^(]*\((.*)/, `$1`)
        .replace(/\).*/, ``)
        .match(/\d*\.?\d+%?/g) || [],
    r = n.map((e) => parseFloat(e));
  for (let e = 0; e < 3; e += 1) r[e] = t(r[e] || 0, n[e] || ``, e);
  return (r[3] = n[3] ? (n[3].includes(`%`) ? r[3] / 100 : r[3]) : 1), r;
}
var ur = (e, t, n) => (n === 0 ? e : e / 100);
function dr(e, t) {
  let n = t || 255;
  return e > n ? n : e < 0 ? 0 : e;
}
var Z = class e {
    constructor(t) {
      D(this, `isValid`, !0),
        D(this, `r`, 0),
        D(this, `g`, 0),
        D(this, `b`, 0),
        D(this, `a`, 1),
        D(this, `_h`, void 0),
        D(this, `_s`, void 0),
        D(this, `_l`, void 0),
        D(this, `_v`, void 0),
        D(this, `_max`, void 0),
        D(this, `_min`, void 0),
        D(this, `_brightness`, void 0);
      function n(e) {
        return e[0] in t && e[1] in t && e[2] in t;
      }
      if (t) {
        if (typeof t == `string`) {
          let e = t.trim();
          function n(t) {
            return e.startsWith(t);
          }
          /^#?[A-F\d]{3,8}$/i.test(e)
            ? this.fromHexString(e)
            : n(`rgb`)
            ? this.fromRgbString(e)
            : n(`hsl`)
            ? this.fromHslString(e)
            : (n(`hsv`) || n(`hsb`)) && this.fromHsvString(e);
        } else if (t instanceof e)
          (this.r = t.r),
            (this.g = t.g),
            (this.b = t.b),
            (this.a = t.a),
            (this._h = t._h),
            (this._s = t._s),
            (this._l = t._l),
            (this._v = t._v);
        else if (n(`rgb`))
          (this.r = dr(t.r)),
            (this.g = dr(t.g)),
            (this.b = dr(t.b)),
            (this.a = typeof t.a == `number` ? dr(t.a, 1) : 1);
        else if (n(`hsl`)) this.fromHsl(t);
        else if (n(`hsv`)) this.fromHsv(t);
        else
          throw Error(
            `@ant-design/fast-color: unsupported input ` + JSON.stringify(t)
          );
      }
    }
    setR(e) {
      return this._sc(`r`, e);
    }
    setG(e) {
      return this._sc(`g`, e);
    }
    setB(e) {
      return this._sc(`b`, e);
    }
    setA(e) {
      return this._sc(`a`, e, 1);
    }
    setHue(e) {
      let t = this.toHsv();
      return (t.h = e), this._c(t);
    }
    getLuminance() {
      function e(e) {
        let t = e / 255;
        return t <= 0.03928 ? t / 12.92 : ((t + 0.055) / 1.055) ** 2.4;
      }
      let t = e(this.r),
        n = e(this.g),
        r = e(this.b);
      return 0.2126 * t + 0.7152 * n + 0.0722 * r;
    }
    getHue() {
      if (this._h === void 0) {
        let e = this.getMax() - this.getMin();
        this._h =
          e === 0
            ? 0
            : X(
                60 *
                  (this.r === this.getMax()
                    ? (this.g - this.b) / e + (this.g < this.b ? 6 : 0)
                    : this.g === this.getMax()
                    ? (this.b - this.r) / e + 2
                    : (this.r - this.g) / e + 4)
              );
      }
      return this._h;
    }
    getSaturation() {
      if (this._s === void 0) {
        let e = this.getMax() - this.getMin();
        this._s = e === 0 ? 0 : e / this.getMax();
      }
      return this._s;
    }
    getLightness() {
      return (
        this._l === void 0 && (this._l = (this.getMax() + this.getMin()) / 510),
        this._l
      );
    }
    getValue() {
      return this._v === void 0 && (this._v = this.getMax() / 255), this._v;
    }
    getBrightness() {
      return (
        this._brightness === void 0 &&
          (this._brightness =
            (this.r * 299 + this.g * 587 + this.b * 114) / 1e3),
        this._brightness
      );
    }
    darken(e = 10) {
      let t = this.getHue(),
        n = this.getSaturation(),
        r = this.getLightness() - e / 100;
      return r < 0 && (r = 0), this._c({ h: t, s: n, l: r, a: this.a });
    }
    lighten(e = 10) {
      let t = this.getHue(),
        n = this.getSaturation(),
        r = this.getLightness() + e / 100;
      return r > 1 && (r = 1), this._c({ h: t, s: n, l: r, a: this.a });
    }
    mix(e, t = 50) {
      let n = this._c(e),
        r = t / 100,
        i = (e) => (n[e] - this[e]) * r + this[e],
        a = {
          r: X(i(`r`)),
          g: X(i(`g`)),
          b: X(i(`b`)),
          a: X(i(`a`) * 100) / 100,
        };
      return this._c(a);
    }
    tint(e = 10) {
      return this.mix({ r: 255, g: 255, b: 255, a: 1 }, e);
    }
    shade(e = 10) {
      return this.mix({ r: 0, g: 0, b: 0, a: 1 }, e);
    }
    onBackground(e) {
      let t = this._c(e),
        n = this.a + t.a * (1 - this.a),
        r = (e) => X((this[e] * this.a + t[e] * t.a * (1 - this.a)) / n);
      return this._c({ r: r(`r`), g: r(`g`), b: r(`b`), a: n });
    }
    isDark() {
      return this.getBrightness() < 128;
    }
    isLight() {
      return this.getBrightness() >= 128;
    }
    equals(e) {
      return (
        this.r === e.r && this.g === e.g && this.b === e.b && this.a === e.a
      );
    }
    clone() {
      return this._c(this);
    }
    toHexString() {
      let e = `#`,
        t = (this.r || 0).toString(16);
      e += t.length === 2 ? t : `0` + t;
      let n = (this.g || 0).toString(16);
      e += n.length === 2 ? n : `0` + n;
      let r = (this.b || 0).toString(16);
      if (
        ((e += r.length === 2 ? r : `0` + r),
        typeof this.a == `number` && this.a >= 0 && this.a < 1)
      ) {
        let t = X(this.a * 255).toString(16);
        e += t.length === 2 ? t : `0` + t;
      }
      return e;
    }
    toHsl() {
      return {
        h: this.getHue(),
        s: this.getSaturation(),
        l: this.getLightness(),
        a: this.a,
      };
    }
    toHslString() {
      let e = this.getHue(),
        t = X(this.getSaturation() * 100),
        n = X(this.getLightness() * 100);
      return this.a === 1
        ? `hsl(${e},${t}%,${n}%)`
        : `hsla(${e},${t}%,${n}%,${this.a})`;
    }
    toHsv() {
      return {
        h: this.getHue(),
        s: this.getSaturation(),
        v: this.getValue(),
        a: this.a,
      };
    }
    toRgb() {
      return { r: this.r, g: this.g, b: this.b, a: this.a };
    }
    toRgbString() {
      return this.a === 1
        ? `rgb(${this.r},${this.g},${this.b})`
        : `rgba(${this.r},${this.g},${this.b},${this.a})`;
    }
    toString() {
      return this.toRgbString();
    }
    _sc(e, t, n) {
      let r = this.clone();
      return (r[e] = dr(t, n)), r;
    }
    _c(e) {
      return new this.constructor(e);
    }
    getMax() {
      return (
        this._max === void 0 && (this._max = Math.max(this.r, this.g, this.b)),
        this._max
      );
    }
    getMin() {
      return (
        this._min === void 0 && (this._min = Math.min(this.r, this.g, this.b)),
        this._min
      );
    }
    fromHexString(e) {
      let t = e.replace(`#`, ``);
      function n(e, n) {
        return parseInt(t[e] + t[n || e], 16);
      }
      t.length < 6
        ? ((this.r = n(0)),
          (this.g = n(1)),
          (this.b = n(2)),
          (this.a = t[3] ? n(3) / 255 : 1))
        : ((this.r = n(0, 1)),
          (this.g = n(2, 3)),
          (this.b = n(4, 5)),
          (this.a = t[6] ? n(6, 7) / 255 : 1));
    }
    fromHsl({ h: e, s: t, l: n, a: r }) {
      if (
        ((this._h = e % 360),
        (this._s = t),
        (this._l = n),
        (this.a = typeof r == `number` ? r : 1),
        t <= 0)
      ) {
        let e = X(n * 255);
        (this.r = e), (this.g = e), (this.b = e);
      }
      let i = 0,
        a = 0,
        o = 0,
        s = e / 60,
        c = (1 - Math.abs(2 * n - 1)) * t,
        l = c * (1 - Math.abs((s % 2) - 1));
      s >= 0 && s < 1
        ? ((i = c), (a = l))
        : s >= 1 && s < 2
        ? ((i = l), (a = c))
        : s >= 2 && s < 3
        ? ((a = c), (o = l))
        : s >= 3 && s < 4
        ? ((a = l), (o = c))
        : s >= 4 && s < 5
        ? ((i = l), (o = c))
        : s >= 5 && s < 6 && ((i = c), (o = l));
      let u = n - c / 2;
      (this.r = X((i + u) * 255)),
        (this.g = X((a + u) * 255)),
        (this.b = X((o + u) * 255));
    }
    fromHsv({ h: e, s: t, v: n, a: r }) {
      (this._h = e % 360),
        (this._s = t),
        (this._v = n),
        (this.a = typeof r == `number` ? r : 1);
      let i = X(n * 255);
      if (((this.r = i), (this.g = i), (this.b = i), t <= 0)) return;
      let a = e / 60,
        o = Math.floor(a),
        s = a - o,
        c = X(n * (1 - t) * 255),
        l = X(n * (1 - t * s) * 255),
        u = X(n * (1 - t * (1 - s)) * 255);
      switch (o) {
        case 0:
          (this.g = u), (this.b = c);
          break;
        case 1:
          (this.r = l), (this.b = c);
          break;
        case 2:
          (this.r = c), (this.b = u);
          break;
        case 3:
          (this.r = c), (this.g = l);
          break;
        case 4:
          (this.r = u), (this.g = c);
          break;
        default:
          (this.g = c), (this.b = l);
      }
    }
    fromHsvString(e) {
      let t = lr(e, ur);
      this.fromHsv({ h: t[0], s: t[1], v: t[2], a: t[3] });
    }
    fromHslString(e) {
      let t = lr(e, ur);
      this.fromHsl({ h: t[0], s: t[1], l: t[2], a: t[3] });
    }
    fromRgbString(e) {
      let t = lr(e, (e, t) => (t.includes(`%`) ? X((e / 100) * 255) : e));
      (this.r = t[0]), (this.g = t[1]), (this.b = t[2]), (this.a = t[3]);
    }
  },
  fr = 2,
  pr = 0.16,
  mr = 0.05,
  hr = 0.05,
  gr = 0.15,
  _r = 5,
  vr = 4,
  yr = [
    { index: 7, amount: 15 },
    { index: 6, amount: 25 },
    { index: 5, amount: 30 },
    { index: 5, amount: 45 },
    { index: 5, amount: 65 },
    { index: 5, amount: 85 },
    { index: 4, amount: 90 },
    { index: 3, amount: 95 },
    { index: 2, amount: 97 },
    { index: 1, amount: 98 },
  ];
function br(e, t, n) {
  var r =
    Math.round(e.h) >= 60 && Math.round(e.h) <= 240
      ? n
        ? Math.round(e.h) - fr * t
        : Math.round(e.h) + fr * t
      : n
      ? Math.round(e.h) + fr * t
      : Math.round(e.h) - fr * t;
  return r < 0 ? (r += 360) : r >= 360 && (r -= 360), r;
}
function xr(e, t, n) {
  if (e.h === 0 && e.s === 0) return e.s;
  var r = n ? e.s - pr * t : t === vr ? e.s + pr : e.s + mr * t;
  return (
    r > 1 && (r = 1),
    n && t === _r && r > 0.1 && (r = 0.1),
    r < 0.06 && (r = 0.06),
    Math.round(r * 100) / 100
  );
}
function Sr(e, t, n) {
  var r = n ? e.v + hr * t : e.v - gr * t;
  return (r = Math.max(0, Math.min(1, r))), Math.round(r * 100) / 100;
}
function Cr(e) {
  for (
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
      n = [],
      r = new Z(e),
      i = r.toHsv(),
      a = _r;
    a > 0;
    --a
  ) {
    var o = new Z({ h: br(i, a, !0), s: xr(i, a, !0), v: Sr(i, a, !0) });
    n.push(o);
  }
  n.push(r);
  for (var s = 1; s <= vr; s += 1) {
    var c = new Z({ h: br(i, s), s: xr(i, s), v: Sr(i, s) });
    n.push(c);
  }
  return t.theme === `dark`
    ? yr.map(function (e) {
        var r = e.index,
          i = e.amount;
        return new Z(t.backgroundColor || `#141414`).mix(n[r], i).toHexString();
      })
    : n.map(function (e) {
        return e.toHexString();
      });
}
var wr = {
    red: `#F5222D`,
    volcano: `#FA541C`,
    orange: `#FA8C16`,
    gold: `#FAAD14`,
    yellow: `#FADB14`,
    lime: `#A0D911`,
    green: `#52C41A`,
    cyan: `#13C2C2`,
    blue: `#1677FF`,
    geekblue: `#2F54EB`,
    purple: `#722ED1`,
    magenta: `#EB2F96`,
    grey: `#666666`,
  },
  Tr = [
    `#fff1f0`,
    `#ffccc7`,
    `#ffa39e`,
    `#ff7875`,
    `#ff4d4f`,
    `#f5222d`,
    `#cf1322`,
    `#a8071a`,
    `#820014`,
    `#5c0011`,
  ];
Tr.primary = Tr[5];
var Er = [
  `#fff2e8`,
  `#ffd8bf`,
  `#ffbb96`,
  `#ff9c6e`,
  `#ff7a45`,
  `#fa541c`,
  `#d4380d`,
  `#ad2102`,
  `#871400`,
  `#610b00`,
];
Er.primary = Er[5];
var Dr = [
  `#fff7e6`,
  `#ffe7ba`,
  `#ffd591`,
  `#ffc069`,
  `#ffa940`,
  `#fa8c16`,
  `#d46b08`,
  `#ad4e00`,
  `#873800`,
  `#612500`,
];
Dr.primary = Dr[5];
var Or = [
  `#fffbe6`,
  `#fff1b8`,
  `#ffe58f`,
  `#ffd666`,
  `#ffc53d`,
  `#faad14`,
  `#d48806`,
  `#ad6800`,
  `#874d00`,
  `#613400`,
];
Or.primary = Or[5];
var kr = [
  `#feffe6`,
  `#ffffb8`,
  `#fffb8f`,
  `#fff566`,
  `#ffec3d`,
  `#fadb14`,
  `#d4b106`,
  `#ad8b00`,
  `#876800`,
  `#614700`,
];
kr.primary = kr[5];
var Ar = [
  `#fcffe6`,
  `#f4ffb8`,
  `#eaff8f`,
  `#d3f261`,
  `#bae637`,
  `#a0d911`,
  `#7cb305`,
  `#5b8c00`,
  `#3f6600`,
  `#254000`,
];
Ar.primary = Ar[5];
var jr = [
  `#f6ffed`,
  `#d9f7be`,
  `#b7eb8f`,
  `#95de64`,
  `#73d13d`,
  `#52c41a`,
  `#389e0d`,
  `#237804`,
  `#135200`,
  `#092b00`,
];
jr.primary = jr[5];
var Mr = [
  `#e6fffb`,
  `#b5f5ec`,
  `#87e8de`,
  `#5cdbd3`,
  `#36cfc9`,
  `#13c2c2`,
  `#08979c`,
  `#006d75`,
  `#00474f`,
  `#002329`,
];
Mr.primary = Mr[5];
var Nr = [
  `#e6f4ff`,
  `#bae0ff`,
  `#91caff`,
  `#69b1ff`,
  `#4096ff`,
  `#1677ff`,
  `#0958d9`,
  `#003eb3`,
  `#002c8c`,
  `#001d66`,
];
Nr.primary = Nr[5];
var Pr = [
  `#f0f5ff`,
  `#d6e4ff`,
  `#adc6ff`,
  `#85a5ff`,
  `#597ef7`,
  `#2f54eb`,
  `#1d39c4`,
  `#10239e`,
  `#061178`,
  `#030852`,
];
Pr.primary = Pr[5];
var Fr = [
  `#f9f0ff`,
  `#efdbff`,
  `#d3adf7`,
  `#b37feb`,
  `#9254de`,
  `#722ed1`,
  `#531dab`,
  `#391085`,
  `#22075e`,
  `#120338`,
];
Fr.primary = Fr[5];
var Ir = [
  `#fff0f6`,
  `#ffd6e7`,
  `#ffadd2`,
  `#ff85c0`,
  `#f759ab`,
  `#eb2f96`,
  `#c41d7f`,
  `#9e1068`,
  `#780650`,
  `#520339`,
];
Ir.primary = Ir[5];
var Lr = [
  `#a6a6a6`,
  `#999999`,
  `#8c8c8c`,
  `#808080`,
  `#737373`,
  `#666666`,
  `#404040`,
  `#1a1a1a`,
  `#000000`,
  `#000000`,
];
Lr.primary = Lr[5];
var Rr = {
    red: Tr,
    volcano: Er,
    orange: Dr,
    gold: Or,
    yellow: kr,
    lime: Ar,
    green: jr,
    cyan: Mr,
    blue: Nr,
    geekblue: Pr,
    purple: Fr,
    magenta: Ir,
    grey: Lr,
  },
  zr = [
    `#2a1215`,
    `#431418`,
    `#58181c`,
    `#791a1f`,
    `#a61d24`,
    `#d32029`,
    `#e84749`,
    `#f37370`,
    `#f89f9a`,
    `#fac8c3`,
  ];
zr.primary = zr[5];
var Br = [
  `#2b1611`,
  `#441d12`,
  `#592716`,
  `#7c3118`,
  `#aa3e19`,
  `#d84a1b`,
  `#e87040`,
  `#f3956a`,
  `#f8b692`,
  `#fad4bc`,
];
Br.primary = Br[5];
var Vr = [
  `#2b1d11`,
  `#442a11`,
  `#593815`,
  `#7c4a15`,
  `#aa6215`,
  `#d87a16`,
  `#e89a3c`,
  `#f3b765`,
  `#f8cf8d`,
  `#fae3b7`,
];
Vr.primary = Vr[5];
var Hr = [
  `#2b2111`,
  `#443111`,
  `#594214`,
  `#7c5914`,
  `#aa7714`,
  `#d89614`,
  `#e8b339`,
  `#f3cc62`,
  `#f8df8b`,
  `#faedb5`,
];
Hr.primary = Hr[5];
var Ur = [
  `#2b2611`,
  `#443b11`,
  `#595014`,
  `#7c6e14`,
  `#aa9514`,
  `#d8bd14`,
  `#e8d639`,
  `#f3ea62`,
  `#f8f48b`,
  `#fafab5`,
];
Ur.primary = Ur[5];
var Wr = [
  `#1f2611`,
  `#2e3c10`,
  `#3e4f13`,
  `#536d13`,
  `#6f9412`,
  `#8bbb11`,
  `#a9d134`,
  `#c9e75d`,
  `#e4f88b`,
  `#f0fab5`,
];
Wr.primary = Wr[5];
var Gr = [
  `#162312`,
  `#1d3712`,
  `#274916`,
  `#306317`,
  `#3c8618`,
  `#49aa19`,
  `#6abe39`,
  `#8fd460`,
  `#b2e58b`,
  `#d5f2bb`,
];
Gr.primary = Gr[5];
var Kr = [
  `#112123`,
  `#113536`,
  `#144848`,
  `#146262`,
  `#138585`,
  `#13a8a8`,
  `#33bcb7`,
  `#58d1c9`,
  `#84e2d8`,
  `#b2f1e8`,
];
Kr.primary = Kr[5];
var qr = [
  `#111a2c`,
  `#112545`,
  `#15325b`,
  `#15417e`,
  `#1554ad`,
  `#1668dc`,
  `#3c89e8`,
  `#65a9f3`,
  `#8dc5f8`,
  `#b7dcfa`,
];
qr.primary = qr[5];
var Jr = [
  `#131629`,
  `#161d40`,
  `#1c2755`,
  `#203175`,
  `#263ea0`,
  `#2b4acb`,
  `#5273e0`,
  `#7f9ef3`,
  `#a8c1f8`,
  `#d2e0fa`,
];
Jr.primary = Jr[5];
var Yr = [
  `#1a1325`,
  `#24163a`,
  `#301c4d`,
  `#3e2069`,
  `#51258f`,
  `#642ab5`,
  `#854eca`,
  `#ab7ae0`,
  `#cda8f0`,
  `#ebd7fa`,
];
Yr.primary = Yr[5];
var Xr = [
  `#291321`,
  `#40162f`,
  `#551c3b`,
  `#75204f`,
  `#a02669`,
  `#cb2b83`,
  `#e0529c`,
  `#f37fb7`,
  `#f8a8cc`,
  `#fad2e3`,
];
Xr.primary = Xr[5];
var Zr = [
  `#151515`,
  `#1f1f1f`,
  `#2d2d2d`,
  `#393939`,
  `#494949`,
  `#5a5a5a`,
  `#6a6a6a`,
  `#7b7b7b`,
  `#888888`,
  `#969696`,
];
Zr.primary = Zr[5];
function Qr(e, { generateColorPalettes: t, generateNeutralColorPalettes: n }) {
  let {
      colorSuccess: r,
      colorWarning: i,
      colorError: a,
      colorInfo: o,
      colorPrimary: s,
      colorBgBase: c,
      colorTextBase: l,
    } = e,
    u = t(s),
    d = t(r),
    f = t(i),
    p = t(a),
    m = t(o),
    h = n(c, l),
    g = t(e.colorLink || e.colorInfo),
    _ = new Z(p[1]).mix(new Z(p[3]), 50).toHexString();
  return Object.assign(Object.assign({}, h), {
    colorPrimaryBg: u[1],
    colorPrimaryBgHover: u[2],
    colorPrimaryBorder: u[3],
    colorPrimaryBorderHover: u[4],
    colorPrimaryHover: u[5],
    colorPrimary: u[6],
    colorPrimaryActive: u[7],
    colorPrimaryTextHover: u[8],
    colorPrimaryText: u[9],
    colorPrimaryTextActive: u[10],
    colorSuccessBg: d[1],
    colorSuccessBgHover: d[2],
    colorSuccessBorder: d[3],
    colorSuccessBorderHover: d[4],
    colorSuccessHover: d[4],
    colorSuccess: d[6],
    colorSuccessActive: d[7],
    colorSuccessTextHover: d[8],
    colorSuccessText: d[9],
    colorSuccessTextActive: d[10],
    colorErrorBg: p[1],
    colorErrorBgHover: p[2],
    colorErrorBgFilledHover: _,
    colorErrorBgActive: p[3],
    colorErrorBorder: p[3],
    colorErrorBorderHover: p[4],
    colorErrorHover: p[5],
    colorError: p[6],
    colorErrorActive: p[7],
    colorErrorTextHover: p[8],
    colorErrorText: p[9],
    colorErrorTextActive: p[10],
    colorWarningBg: f[1],
    colorWarningBgHover: f[2],
    colorWarningBorder: f[3],
    colorWarningBorderHover: f[4],
    colorWarningHover: f[4],
    colorWarning: f[6],
    colorWarningActive: f[7],
    colorWarningTextHover: f[8],
    colorWarningText: f[9],
    colorWarningTextActive: f[10],
    colorInfoBg: m[1],
    colorInfoBgHover: m[2],
    colorInfoBorder: m[3],
    colorInfoBorderHover: m[4],
    colorInfoHover: m[4],
    colorInfo: m[6],
    colorInfoActive: m[7],
    colorInfoTextHover: m[8],
    colorInfoText: m[9],
    colorInfoTextActive: m[10],
    colorLinkHover: g[4],
    colorLink: g[6],
    colorLinkActive: g[7],
    colorBgMask: new Z(`#000`).setA(0.45).toRgbString(),
    colorWhite: `#fff`,
  });
}
var $r = (e) => {
  let t = e,
    n = e,
    r = e,
    i = e;
  return (
    e < 6 && e >= 5
      ? (t = e + 1)
      : e < 16 && e >= 6
      ? (t = e + 2)
      : e >= 16 && (t = 16),
    e < 7 && e >= 5
      ? (n = 4)
      : e < 8 && e >= 7
      ? (n = 5)
      : e < 14 && e >= 8
      ? (n = 6)
      : e < 16 && e >= 14
      ? (n = 7)
      : e >= 16 && (n = 8),
    e < 6 && e >= 2 ? (r = 1) : e >= 6 && (r = 2),
    e > 4 && e < 8 ? (i = 4) : e >= 8 && (i = 6),
    {
      borderRadius: e,
      borderRadiusXS: r,
      borderRadiusSM: n,
      borderRadiusLG: t,
      borderRadiusOuter: i,
    }
  );
};
function ei(e) {
  let { motionUnit: t, motionBase: n, borderRadius: r, lineWidth: i } = e;
  return Object.assign(
    {
      motionDurationFast: `${(n + t).toFixed(1)}s`,
      motionDurationMid: `${(n + t * 2).toFixed(1)}s`,
      motionDurationSlow: `${(n + t * 3).toFixed(1)}s`,
      lineWidthBold: i + 1,
    },
    $r(r)
  );
}
var ti = (e) => {
  let { controlHeight: t } = e;
  return {
    controlHeightSM: t * 0.75,
    controlHeightXS: t * 0.5,
    controlHeightLG: t * 1.25,
  };
};
function ni(e) {
  return (e + 8) / e;
}
function ri(e) {
  let t = Array.from({ length: 10 }).map((t, n) => {
    let r = n - 1,
      i = e * Math.E ** (r / 5);
    return Math.floor((n > 1 ? Math.floor(i) : Math.ceil(i)) / 2) * 2;
  });
  return (t[1] = e), t.map((e) => ({ size: e, lineHeight: ni(e) }));
}
var ii = (e) => {
  let t = ri(e),
    n = t.map((e) => e.size),
    r = t.map((e) => e.lineHeight),
    i = n[1],
    a = n[0],
    o = n[2],
    s = r[1],
    c = r[0],
    l = r[2];
  return {
    fontSizeSM: a,
    fontSize: i,
    fontSizeLG: o,
    fontSizeXL: n[3],
    fontSizeHeading1: n[6],
    fontSizeHeading2: n[5],
    fontSizeHeading3: n[4],
    fontSizeHeading4: n[3],
    fontSizeHeading5: n[2],
    lineHeight: s,
    lineHeightLG: l,
    lineHeightSM: c,
    fontHeight: Math.round(s * i),
    fontHeightLG: Math.round(l * o),
    fontHeightSM: Math.round(c * a),
    lineHeightHeading1: r[6],
    lineHeightHeading2: r[5],
    lineHeightHeading3: r[4],
    lineHeightHeading4: r[3],
    lineHeightHeading5: r[2],
  };
};
function ai(e) {
  let { sizeUnit: t, sizeStep: n } = e;
  return {
    sizeXXL: t * (n + 8),
    sizeXL: t * (n + 4),
    sizeLG: t * (n + 2),
    sizeMD: t * (n + 1),
    sizeMS: t * n,
    size: t * n,
    sizeSM: t * (n - 1),
    sizeXS: t * (n - 2),
    sizeXXS: t * (n - 3),
  };
}
var Q = (e, t) => new Z(e).setA(t).toRgbString(),
  oi = (e, t) => new Z(e).darken(t).toHexString(),
  si = (e) => {
    let t = Cr(e);
    return {
      1: t[0],
      2: t[1],
      3: t[2],
      4: t[3],
      5: t[4],
      6: t[5],
      7: t[6],
      8: t[4],
      9: t[5],
      10: t[6],
    };
  },
  ci = (e, t) => {
    let n = e || `#fff`,
      r = t || `#000`;
    return {
      colorBgBase: n,
      colorTextBase: r,
      colorText: Q(r, 0.88),
      colorTextSecondary: Q(r, 0.65),
      colorTextTertiary: Q(r, 0.45),
      colorTextQuaternary: Q(r, 0.25),
      colorFill: Q(r, 0.15),
      colorFillSecondary: Q(r, 0.06),
      colorFillTertiary: Q(r, 0.04),
      colorFillQuaternary: Q(r, 0.02),
      colorBgSolid: Q(r, 1),
      colorBgSolidHover: Q(r, 0.75),
      colorBgSolidActive: Q(r, 0.95),
      colorBgLayout: oi(n, 4),
      colorBgContainer: oi(n, 0),
      colorBgElevated: oi(n, 0),
      colorBgSpotlight: Q(r, 0.85),
      colorBgBlur: `transparent`,
      colorBorder: oi(n, 15),
      colorBorderSecondary: oi(n, 6),
    };
  };
function li(e) {
  (wr.pink = wr.magenta), (Rr.pink = Rr.magenta);
  let t = Object.keys(sr)
    .map((t) => {
      let n = e[t] === wr[t] ? Rr[t] : Cr(e[t]);
      return Array.from({ length: 10 }, () => 1).reduce(
        (e, r, i) => (
          (e[`${t}-${i + 1}`] = n[i]), (e[`${t}${i + 1}`] = n[i]), e
        ),
        {}
      );
    })
    .reduce((e, t) => ((e = Object.assign(Object.assign({}, e), t)), e), {});
  return Object.assign(
    Object.assign(
      Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(Object.assign({}, e), t),
            Qr(e, {
              generateColorPalettes: si,
              generateNeutralColorPalettes: ci,
            })
          ),
          ii(e.fontSize)
        ),
        ai(e)
      ),
      ti(e)
    ),
    ei(e)
  );
}
var ui = bt(li),
  di = { token: cr, override: { override: cr }, hashed: !0 },
  fi = h.createContext(di),
  pi = `anticon`,
  mi = [`outlined`, `borderless`, `filled`, `underlined`],
  $ = h.createContext({
    getPrefixCls: (e, t) => t || (e ? `ant-${e}` : `ant`),
    iconPrefixCls: pi,
  }),
  { Consumer: hi } = $,
  gi = {};
function _i(e) {
  let t = h.useContext($),
    { getPrefixCls: n, direction: r, getPopupContainer: i } = t,
    a = t[e];
  return Object.assign(Object.assign({ classNames: gi, styles: gi }, a), {
    getPrefixCls: n,
    direction: r,
    getPopupContainer: i,
  });
}
var vi = h.createContext(void 0),
  yi = ({ children: e, size: t }) => {
    let n = h.useContext(vi);
    return h.createElement(vi.Provider, { value: t || n }, e);
  };
N(), j();
var bi = M(function e() {
  A(this, e);
});
m(), j(), N(), s(), O();
var xi = `CALC_UNIT`,
  Si = new RegExp(xi, `g`);
function Ci(e) {
  return typeof e == `number` ? `${e}${xi}` : e;
}
var wi = (function (e) {
  Se(n, e);
  var t = we(n);
  function n(e, r) {
    var i;
    A(this, n),
      (i = t.call(this)),
      D(d(i), `result`, ``),
      D(d(i), `unitlessCssVar`, void 0),
      D(d(i), `lowPriority`, void 0);
    var a = p(e);
    return (
      (i.unitlessCssVar = r),
      e instanceof n
        ? (i.result = `(${e.result})`)
        : a === `number`
        ? (i.result = Ci(e))
        : a === `string` && (i.result = e),
      i
    );
  }
  return (
    M(n, [
      {
        key: `add`,
        value: function (e) {
          return (
            e instanceof n
              ? (this.result = `${this.result} + ${e.getResult()}`)
              : (typeof e == `number` || typeof e == `string`) &&
                (this.result = `${this.result} + ${Ci(e)}`),
            (this.lowPriority = !0),
            this
          );
        },
      },
      {
        key: `sub`,
        value: function (e) {
          return (
            e instanceof n
              ? (this.result = `${this.result} - ${e.getResult()}`)
              : (typeof e == `number` || typeof e == `string`) &&
                (this.result = `${this.result} - ${Ci(e)}`),
            (this.lowPriority = !0),
            this
          );
        },
      },
      {
        key: `mul`,
        value: function (e) {
          return (
            this.lowPriority && (this.result = `(${this.result})`),
            e instanceof n
              ? (this.result = `${this.result} * ${e.getResult(!0)}`)
              : (typeof e == `number` || typeof e == `string`) &&
                (this.result = `${this.result} * ${e}`),
            (this.lowPriority = !1),
            this
          );
        },
      },
      {
        key: `div`,
        value: function (e) {
          return (
            this.lowPriority && (this.result = `(${this.result})`),
            e instanceof n
              ? (this.result = `${this.result} / ${e.getResult(!0)}`)
              : (typeof e == `number` || typeof e == `string`) &&
                (this.result = `${this.result} / ${e}`),
            (this.lowPriority = !1),
            this
          );
        },
      },
      {
        key: `getResult`,
        value: function (e) {
          return this.lowPriority || e ? `(${this.result})` : this.result;
        },
      },
      {
        key: `equal`,
        value: function (e) {
          var t = this,
            n = (e || {}).unit,
            r = !0;
          return (
            typeof n == `boolean`
              ? (r = n)
              : Array.from(this.unitlessCssVar).some(function (e) {
                  return t.result.includes(e);
                }) && (r = !1),
            (this.result = this.result.replace(Si, r ? `px` : ``)),
            this.lowPriority === void 0 ? this.result : `calc(${this.result})`
          );
        },
      },
    ]),
    n
  );
})(bi);
j(), N(), s(), O();
var Ti = (function (e) {
    Se(n, e);
    var t = we(n);
    function n(e) {
      var r;
      return (
        A(this, n),
        (r = t.call(this)),
        D(d(r), `result`, 0),
        e instanceof n
          ? (r.result = e.result)
          : typeof e == `number` && (r.result = e),
        r
      );
    }
    return (
      M(n, [
        {
          key: `add`,
          value: function (e) {
            return (
              e instanceof n
                ? (this.result += e.result)
                : typeof e == `number` && (this.result += e),
              this
            );
          },
        },
        {
          key: `sub`,
          value: function (e) {
            return (
              e instanceof n
                ? (this.result -= e.result)
                : typeof e == `number` && (this.result -= e),
              this
            );
          },
        },
        {
          key: `mul`,
          value: function (e) {
            return (
              e instanceof n
                ? (this.result *= e.result)
                : typeof e == `number` && (this.result *= e),
              this
            );
          },
        },
        {
          key: `div`,
          value: function (e) {
            return (
              e instanceof n
                ? (this.result /= e.result)
                : typeof e == `number` && (this.result /= e),
              this
            );
          },
        },
        {
          key: `equal`,
          value: function () {
            return this.result;
          },
        },
      ]),
      n
    );
  })(bi),
  Ei = function (e, t) {
    var n = e === `css` ? wi : Ti;
    return function (e) {
      return new n(e, t);
    };
  },
  Di = function (e, t) {
    return `${[
      t,
      e
        .replace(/([A-Z]+)([A-Z][a-z]+)/g, `$1-$2`)
        .replace(/([a-z])([A-Z])/g, `$1-$2`),
    ]
      .filter(Boolean)
      .join(`-`)}`;
  };
function Oi(e) {
  var t = h.useRef();
  return (
    (t.current = e),
    h.useCallback(function () {
      var e,
        n = [...arguments];
      return (e = t.current) == null ? void 0 : e.call.apply(e, [t].concat(n));
    }, [])
  );
}
I();
function ki(e) {
  var t = h.useRef(!1),
    n = F(h.useState(e), 2),
    r = n[0],
    i = n[1];
  h.useEffect(function () {
    return (
      (t.current = !1),
      function () {
        t.current = !0;
      }
    );
  }, []);
  function a(e, n) {
    (n && t.current) || i(e);
  }
  return [r, a];
}
I();
function Ai(e) {
  return e !== void 0;
}
function ji(e, t) {
  var n = t || {},
    r = n.defaultValue,
    i = n.value,
    a = n.onChange,
    o = n.postState,
    s = F(
      ki(function () {
        return Ai(i)
          ? i
          : Ai(r)
          ? typeof r == `function`
            ? r()
            : r
          : typeof e == `function`
          ? e()
          : e;
      }),
      2
    ),
    c = s[0],
    l = s[1],
    u = i === void 0 ? c : i,
    d = o ? o(u) : u,
    f = Oi(a),
    p = F(ki([u]), 2),
    m = p[0],
    h = p[1];
  return (
    Ft(
      function () {
        var e = m[0];
        c !== e && f(c, e);
      },
      [m]
    ),
    Ft(
      function () {
        Ai(i) || l(i);
      },
      [i]
    ),
    [
      d,
      Oi(function (e, t) {
        l(e, t), h([u], t);
      }),
    ]
  );
}
I();
function Mi(e, t, n, r) {
  var i = k({}, t[e]);
  r != null &&
    r.deprecatedTokens &&
    r.deprecatedTokens.forEach(function (e) {
      var t = F(e, 2),
        n = t[0],
        r = t[1];
      ((i != null && i[n]) || (i != null && i[r])) &&
        (i[r] ?? (i[r] = i == null ? void 0 : i[n]));
    });
  var a = k(k({}, n), i);
  return (
    Object.keys(a).forEach(function (e) {
      a[e] === t[e] && delete a[e];
    }),
    a
  );
}
m();
var Ni = typeof CSSINJS_STATISTIC < `u`,
  Pi = !0;
function Fi() {
  var e = [...arguments];
  if (!Ni) return Object.assign.apply(Object, [{}].concat(e));
  Pi = !1;
  var t = {};
  return (
    e.forEach(function (e) {
      p(e) === `object` &&
        Object.keys(e).forEach(function (n) {
          Object.defineProperty(t, n, {
            configurable: !0,
            enumerable: !0,
            get: function () {
              return e[n];
            },
          });
        });
    }),
    (Pi = !0),
    t
  );
}
var Ii = {};
function Li() {}
var Ri = function (e) {
  var t,
    n = e,
    r = Li;
  return (
    Ni &&
      typeof Proxy < `u` &&
      ((t = new Set()),
      (n = new Proxy(e, {
        get: function (e, n) {
          if (Pi) {
            var r;
            (r = t) == null || r.add(n);
          }
          return e[n];
        },
      })),
      (r = function (e, n) {
        var r;
        Ii[e] = {
          global: Array.from(t),
          component: k(k({}, (r = Ii[e]) == null ? void 0 : r.component), n),
        };
      })),
    { token: n, keys: t, flush: r }
  );
};
function zi(e, t, n) {
  return typeof n == `function` ? n(Fi(t, t[e] ?? {})) : n ?? {};
}
function Bi(e) {
  return e === `js`
    ? { max: Math.max, min: Math.min }
    : {
        max: function () {
          return `max(${[...arguments]
            .map(function (e) {
              return Ot(e);
            })
            .join(`,`)})`;
        },
        min: function () {
          return `min(${[...arguments]
            .map(function (e) {
              return Ot(e);
            })
            .join(`,`)})`;
        },
      };
}
m(), j(), N(), O();
var Vi = 6e5,
  Hi = new ((function () {
    function e() {
      A(this, e),
        D(this, `map`, new Map()),
        D(this, `objectIDMap`, new WeakMap()),
        D(this, `nextID`, 0),
        D(this, `lastAccessBeat`, new Map()),
        D(this, `accessBeat`, 0);
    }
    return (
      M(e, [
        {
          key: `set`,
          value: function (e, t) {
            this.clear();
            var n = this.getCompositeKey(e);
            this.map.set(n, t), this.lastAccessBeat.set(n, Date.now());
          },
        },
        {
          key: `get`,
          value: function (e) {
            var t = this.getCompositeKey(e),
              n = this.map.get(t);
            return (
              this.lastAccessBeat.set(t, Date.now()), (this.accessBeat += 1), n
            );
          },
        },
        {
          key: `getCompositeKey`,
          value: function (e) {
            var t = this;
            return e
              .map(function (e) {
                return e && p(e) === `object`
                  ? `obj_${t.getObjectID(e)}`
                  : `${p(e)}_${e}`;
              })
              .join(`|`);
          },
        },
        {
          key: `getObjectID`,
          value: function (e) {
            if (this.objectIDMap.has(e)) return this.objectIDMap.get(e);
            var t = this.nextID;
            return this.objectIDMap.set(e, t), (this.nextID += 1), t;
          },
        },
        {
          key: `clear`,
          value: function () {
            var e = this;
            if (this.accessBeat > 1e4) {
              var t = Date.now();
              this.lastAccessBeat.forEach(function (n, r) {
                t - n > Vi && (e.map.delete(r), e.lastAccessBeat.delete(r));
              }),
                (this.accessBeat = 0);
            }
          },
        },
      ]),
      e
    );
  })())();
function Ui(e, t) {
  return h.useMemo(function () {
    var n = Hi.get(t);
    if (n) return n;
    var r = e();
    return Hi.set(t, r), r;
  }, t);
}
var Wi = function () {
  return {};
};
m(), I(), O();
function Gi(e) {
  var t = e.useCSP,
    n = t === void 0 ? Wi : t,
    r = e.useToken,
    i = e.usePrefix,
    a = e.getResetStyles,
    o = e.getCommonStyle,
    s = e.getCompUnitless;
  function c(e, t, n, r) {
    var i = Array.isArray(e) ? e[0] : e;
    function a(e) {
      return `${String(i)}${e.slice(0, 1).toUpperCase()}${e.slice(1)}`;
    }
    var o = (r == null ? void 0 : r.unitless) || {},
      c = k(
        k({}, typeof s == `function` ? s(e) : {}),
        {},
        D({}, a(`zIndexPopup`), !0)
      );
    Object.keys(o).forEach(function (e) {
      c[a(e)] = o[e];
    });
    var d = k(k({}, r), {}, { unitless: c, prefixToken: a }),
      f = u(e, t, n, d),
      p = l(i, n, d);
    return function (e) {
      var t =
          arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e,
        n = F(f(e, t), 2)[1],
        r = F(p(t), 2);
      return [r[0], n, r[1]];
    };
  }
  function l(e, t, n) {
    var i = n.unitless,
      a = n.injectStyle,
      o = a === void 0 || a,
      s = n.prefixToken,
      c = n.ignore,
      l = function (a) {
        var o = a.rootCls,
          l = a.cssVar,
          u = l === void 0 ? {} : l,
          d = r().realToken;
        return (
          tr(
            {
              path: [e],
              prefix: u.prefix,
              key: u.key,
              unitless: i,
              ignore: c,
              token: d,
              scope: o,
            },
            function () {
              var r = zi(e, d, t),
                i = Mi(e, d, r, {
                  deprecatedTokens: n == null ? void 0 : n.deprecatedTokens,
                });
              return (
                Object.keys(r).forEach(function (e) {
                  (i[s(e)] = i[e]), delete i[e];
                }),
                i
              );
            }
          ),
          null
        );
      };
    return function (t) {
      var n = r().cssVar;
      return [
        function (r) {
          return o && n
            ? h.createElement(
                h.Fragment,
                null,
                h.createElement(l, { rootCls: t, cssVar: n, component: e }),
                r
              )
            : r;
        },
        n == null ? void 0 : n.key,
      ];
    };
  }
  function u(t, s, c) {
    var l = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {},
      u = Array.isArray(t) ? t : [t, t],
      d = F(u, 1)[0],
      f = u.join(`-`),
      m = e.layer || { name: `antd` };
    return function (e) {
      var t =
          arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : e,
        u = r(),
        h = u.theme,
        g = u.realToken,
        _ = u.hashId,
        v = u.token,
        y = u.cssVar,
        b = i(),
        x = b.rootPrefixCls,
        S = b.iconPrefixCls,
        C = n(),
        w = y ? `css` : `js`,
        T = Ui(
          function () {
            var e = new Set();
            return (
              y &&
                Object.keys(l.unitless || {}).forEach(function (t) {
                  e.add(At(t, y.prefix)), e.add(At(t, Di(d, y.prefix)));
                }),
              Ei(w, e)
            );
          },
          [w, d, y == null ? void 0 : y.prefix]
        ),
        ee = Bi(w),
        te = ee.max,
        ne = ee.min,
        E = {
          theme: h,
          token: v,
          hashId: _,
          nonce: function () {
            return C.nonce;
          },
          clientOnly: l.clientOnly,
          layer: m,
          order: l.order || -999,
        };
      return (
        typeof a == `function` &&
          Qn(
            k(k({}, E), {}, { clientOnly: !1, path: [`Shared`, x] }),
            function () {
              return a(v, {
                prefix: { rootPrefixCls: x, iconPrefixCls: S },
                csp: C,
              });
            }
          ),
        [
          Qn(k(k({}, E), {}, { path: [f, e, S] }), function () {
            if (l.injectStyle === !1) return [];
            var n = Ri(v),
              r = n.token,
              i = n.flush,
              a = zi(d, g, c),
              u = `.${e}`,
              f = Mi(d, g, a, { deprecatedTokens: l.deprecatedTokens });
            y &&
              a &&
              p(a) === `object` &&
              Object.keys(a).forEach(function (e) {
                a[e] = `var(${At(e, Di(d, y.prefix))})`;
              });
            var m = Fi(
                r,
                {
                  componentCls: u,
                  prefixCls: e,
                  iconCls: `.${S}`,
                  antCls: `.${x}`,
                  calc: T,
                  max: te,
                  min: ne,
                },
                y ? a : f
              ),
              h = s(m, {
                hashId: _,
                prefixCls: e,
                rootPrefixCls: x,
                iconPrefixCls: S,
              });
            i(d, f);
            var b = typeof o == `function` ? o(m, e, t, l.resetFont) : null;
            return [l.resetStyle === !1 ? null : b, h];
          }),
          _,
        ]
      );
    };
  }
  function d(e, t, n) {
    var r = u(
      e,
      t,
      n,
      k(
        { resetStyle: !1, order: -998 },
        arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}
      )
    );
    return function (e) {
      var t = e.prefixCls,
        n = e.rootCls;
      return r(t, n === void 0 ? t : n), null;
    };
  }
  return {
    genStyleHooks: c,
    genSubStyleComponent: d,
    genComponentStyleHook: u,
  };
}
var Ki = `5.27.1`;
function qi(e) {
  return e >= 0 && e <= 255;
}
function Ji(e, t) {
  let { r: n, g: r, b: i, a } = new Z(e).toRgb();
  if (a < 1) return e;
  let { r: o, g: s, b: c } = new Z(t).toRgb();
  for (let e = 0.01; e <= 1; e += 0.01) {
    let t = Math.round((n - o * (1 - e)) / e),
      a = Math.round((r - s * (1 - e)) / e),
      l = Math.round((i - c * (1 - e)) / e);
    if (qi(t) && qi(a) && qi(l))
      return new Z({
        r: t,
        g: a,
        b: l,
        a: Math.round(e * 100) / 100,
      }).toRgbString();
  }
  return new Z({ r: n, g: r, b: i, a: 1 }).toRgbString();
}
var Yi = function (e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) &&
      t.indexOf(r) < 0 &&
      (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == `function`)
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
        (n[r[i]] = e[r[i]]);
  return n;
};
function Xi(e) {
  let { override: t } = e,
    n = Yi(e, [`override`]),
    r = Object.assign({}, t);
  Object.keys(cr).forEach((e) => {
    delete r[e];
  });
  let i = Object.assign(Object.assign({}, n), r),
    a = 1200,
    o = 1600;
  return (
    i.motion === !1 &&
      ((i.motionDurationFast = `0s`),
      (i.motionDurationMid = `0s`),
      (i.motionDurationSlow = `0s`)),
    Object.assign(
      Object.assign(Object.assign({}, i), {
        colorFillContent: i.colorFillSecondary,
        colorFillContentHover: i.colorFill,
        colorFillAlter: i.colorFillQuaternary,
        colorBgContainerDisabled: i.colorFillTertiary,
        colorBorderBg: i.colorBgContainer,
        colorSplit: Ji(i.colorBorderSecondary, i.colorBgContainer),
        colorTextPlaceholder: i.colorTextQuaternary,
        colorTextDisabled: i.colorTextQuaternary,
        colorTextHeading: i.colorText,
        colorTextLabel: i.colorTextSecondary,
        colorTextDescription: i.colorTextTertiary,
        colorTextLightSolid: i.colorWhite,
        colorHighlight: i.colorError,
        colorBgTextHover: i.colorFillSecondary,
        colorBgTextActive: i.colorFill,
        colorIcon: i.colorTextTertiary,
        colorIconHover: i.colorText,
        colorErrorOutline: Ji(i.colorErrorBg, i.colorBgContainer),
        colorWarningOutline: Ji(i.colorWarningBg, i.colorBgContainer),
        fontSizeIcon: i.fontSizeSM,
        lineWidthFocus: i.lineWidth * 3,
        lineWidth: i.lineWidth,
        controlOutlineWidth: i.lineWidth * 2,
        controlInteractiveSize: i.controlHeight / 2,
        controlItemBgHover: i.colorFillTertiary,
        controlItemBgActive: i.colorPrimaryBg,
        controlItemBgActiveHover: i.colorPrimaryBgHover,
        controlItemBgActiveDisabled: i.colorFill,
        controlTmpOutline: i.colorFillQuaternary,
        controlOutline: Ji(i.colorPrimaryBg, i.colorBgContainer),
        lineType: i.lineType,
        borderRadius: i.borderRadius,
        borderRadiusXS: i.borderRadiusXS,
        borderRadiusSM: i.borderRadiusSM,
        borderRadiusLG: i.borderRadiusLG,
        fontWeightStrong: 600,
        opacityLoading: 0.65,
        linkDecoration: `none`,
        linkHoverDecoration: `none`,
        linkFocusDecoration: `none`,
        controlPaddingHorizontal: 12,
        controlPaddingHorizontalSM: 8,
        paddingXXS: i.sizeXXS,
        paddingXS: i.sizeXS,
        paddingSM: i.sizeSM,
        padding: i.size,
        paddingMD: i.sizeMD,
        paddingLG: i.sizeLG,
        paddingXL: i.sizeXL,
        paddingContentHorizontalLG: i.sizeLG,
        paddingContentVerticalLG: i.sizeMS,
        paddingContentHorizontal: i.sizeMS,
        paddingContentVertical: i.sizeSM,
        paddingContentHorizontalSM: i.size,
        paddingContentVerticalSM: i.sizeXS,
        marginXXS: i.sizeXXS,
        marginXS: i.sizeXS,
        marginSM: i.sizeSM,
        margin: i.size,
        marginMD: i.sizeMD,
        marginLG: i.sizeLG,
        marginXL: i.sizeXL,
        marginXXL: i.sizeXXL,
        boxShadow: `
      0 6px 16px 0 rgba(0, 0, 0, 0.08),
      0 3px 6px -4px rgba(0, 0, 0, 0.12),
      0 9px 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowSecondary: `
      0 6px 16px 0 rgba(0, 0, 0, 0.08),
      0 3px 6px -4px rgba(0, 0, 0, 0.12),
      0 9px 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowTertiary: `
      0 1px 2px 0 rgba(0, 0, 0, 0.03),
      0 1px 6px -1px rgba(0, 0, 0, 0.02),
      0 2px 4px 0 rgba(0, 0, 0, 0.02)
    `,
        screenXS: 480,
        screenXSMin: 480,
        screenXSMax: 575,
        screenSM: 576,
        screenSMMin: 576,
        screenSMMax: 767,
        screenMD: 768,
        screenMDMin: 768,
        screenMDMax: 991,
        screenLG: 992,
        screenLGMin: 992,
        screenLGMax: 1199,
        screenXL: a,
        screenXLMin: a,
        screenXLMax: 1599,
        screenXXL: o,
        screenXXLMin: o,
        boxShadowPopoverArrow: `2px 2px 5px rgba(0, 0, 0, 0.05)`,
        boxShadowCard: `
      0 1px 2px -2px ${new Z(`rgba(0, 0, 0, 0.16)`).toRgbString()},
      0 3px 6px 0 ${new Z(`rgba(0, 0, 0, 0.12)`).toRgbString()},
      0 5px 12px 4px ${new Z(`rgba(0, 0, 0, 0.09)`).toRgbString()}
    `,
        boxShadowDrawerRight: `
      -6px 0 16px 0 rgba(0, 0, 0, 0.08),
      -3px 0 6px -4px rgba(0, 0, 0, 0.12),
      -9px 0 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowDrawerLeft: `
      6px 0 16px 0 rgba(0, 0, 0, 0.08),
      3px 0 6px -4px rgba(0, 0, 0, 0.12),
      9px 0 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowDrawerUp: `
      0 6px 16px 0 rgba(0, 0, 0, 0.08),
      0 3px 6px -4px rgba(0, 0, 0, 0.12),
      0 9px 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowDrawerDown: `
      0 -6px 16px 0 rgba(0, 0, 0, 0.08),
      0 -3px 6px -4px rgba(0, 0, 0, 0.12),
      0 -9px 28px 8px rgba(0, 0, 0, 0.05)
    `,
        boxShadowTabsOverflowLeft: `inset 10px 0 8px -8px rgba(0, 0, 0, 0.08)`,
        boxShadowTabsOverflowRight: `inset -10px 0 8px -8px rgba(0, 0, 0, 0.08)`,
        boxShadowTabsOverflowTop: `inset 0 10px 8px -8px rgba(0, 0, 0, 0.08)`,
        boxShadowTabsOverflowBottom: `inset 0 -10px 8px -8px rgba(0, 0, 0, 0.08)`,
      }),
      r
    )
  );
}
var Zi = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Qi = {
    lineHeight: !0,
    lineHeightSM: !0,
    lineHeightLG: !0,
    lineHeightHeading1: !0,
    lineHeightHeading2: !0,
    lineHeightHeading3: !0,
    lineHeightHeading4: !0,
    lineHeightHeading5: !0,
    opacityLoading: !0,
    fontWeightStrong: !0,
    zIndexPopupBase: !0,
    zIndexBase: !0,
    opacityImage: !0,
  },
  $i = { motionBase: !0, motionUnit: !0 },
  ea = {
    screenXS: !0,
    screenXSMin: !0,
    screenXSMax: !0,
    screenSM: !0,
    screenSMMin: !0,
    screenSMMax: !0,
    screenMD: !0,
    screenMDMin: !0,
    screenMDMax: !0,
    screenLG: !0,
    screenLGMin: !0,
    screenLGMax: !0,
    screenXL: !0,
    screenXLMin: !0,
    screenXLMax: !0,
    screenXXL: !0,
    screenXXLMin: !0,
  },
  ta = (e, t, n) => {
    let r = n.getDerivativeToken(e),
      { override: i } = t,
      a = Zi(t, [`override`]),
      o = Object.assign(Object.assign({}, r), { override: i });
    return (
      (o = Xi(o)),
      a &&
        Object.entries(a).forEach(([e, t]) => {
          let { theme: n } = t,
            r = Zi(t, [`theme`]),
            i = r;
          n &&
            (i = ta(
              Object.assign(Object.assign({}, o), r),
              { override: r },
              n
            )),
            (o[e] = i);
        }),
      o
    );
  };
function na() {
  let {
      token: e,
      hashed: t,
      theme: n,
      override: r,
      cssVar: i,
    } = h.useContext(fi),
    a = `${Ki}-${t || ``}`,
    o = n || ui,
    [s, c, l] = Jt(o, [cr, e], {
      salt: a,
      override: r,
      getComputedToken: ta,
      formatToken: Xi,
      cssVar: i && {
        prefix: i.prefix,
        key: i.key,
        unitless: Qi,
        ignore: $i,
        preserve: ea,
      },
    });
  return [o, l, t ? c : ``, s, i];
}
var ra = { overflow: `hidden`, whiteSpace: `nowrap`, textOverflow: `ellipsis` },
  ia = (e, t = !1) => ({
    boxSizing: `border-box`,
    margin: 0,
    padding: 0,
    color: e.colorText,
    fontSize: e.fontSize,
    lineHeight: e.lineHeight,
    listStyle: `none`,
    fontFamily: t ? `inherit` : e.fontFamily,
  }),
  aa = () => ({
    display: `inline-flex`,
    alignItems: `center`,
    color: `inherit`,
    fontStyle: `normal`,
    lineHeight: 0,
    textAlign: `center`,
    textTransform: `none`,
    verticalAlign: `-0.125em`,
    textRendering: `optimizeLegibility`,
    "-webkit-font-smoothing": `antialiased`,
    "-moz-osx-font-smoothing": `grayscale`,
    "> *": { lineHeight: 1 },
    svg: { display: `inline-block` },
  }),
  oa = () => ({
    "&::before": { display: `table`, content: `""` },
    "&::after": { display: `table`, clear: `both`, content: `""` },
  }),
  sa = (e) => ({
    a: {
      color: e.colorLink,
      textDecoration: e.linkDecoration,
      backgroundColor: `transparent`,
      outline: `none`,
      cursor: `pointer`,
      transition: `color ${e.motionDurationSlow}`,
      "-webkit-text-decoration-skip": `objects`,
      "&:hover": { color: e.colorLinkHover },
      "&:active": { color: e.colorLinkActive },
      "&:active, &:hover": {
        textDecoration: e.linkHoverDecoration,
        outline: 0,
      },
      "&:focus": { textDecoration: e.linkFocusDecoration, outline: 0 },
      "&[disabled]": { color: e.colorTextDisabled, cursor: `not-allowed` },
    },
  }),
  ca = (e, t, n, r) => {
    let i = `[class^="${t}"], [class*=" ${t}"]`,
      a = n ? `.${n}` : i,
      o = {
        boxSizing: `border-box`,
        "&::before, &::after": { boxSizing: `border-box` },
      },
      s = {};
    return (
      r !== !1 && (s = { fontFamily: e.fontFamily, fontSize: e.fontSize }),
      { [a]: Object.assign(Object.assign(Object.assign({}, s), o), { [i]: o }) }
    );
  },
  la = (e, t) => ({
    outline: `${Ot(e.lineWidthFocus)} solid ${e.colorPrimaryBorder}`,
    outlineOffset: t ?? 1,
    transition: `outline-offset 0s, outline 0s`,
  }),
  ua = (e, t) => ({ "&:focus-visible": la(e, t) }),
  da = (e) => ({
    [`.${e}`]: Object.assign(Object.assign({}, aa()), {
      [`.${e} .${e}-icon`]: { display: `block` },
    }),
  }),
  fa = (e) =>
    Object.assign(
      Object.assign(
        {
          color: e.colorLink,
          textDecoration: e.linkDecoration,
          outline: `none`,
          cursor: `pointer`,
          transition: `all ${e.motionDurationSlow}`,
          border: 0,
          padding: 0,
          background: `none`,
          userSelect: `none`,
        },
        ua(e)
      ),
      {
        "&:focus, &:hover": { color: e.colorLinkHover },
        "&:active": { color: e.colorLinkActive },
      }
    ),
  {
    genStyleHooks: pa,
    genComponentStyleHook: ma,
    genSubStyleComponent: ha,
  } = Gi({
    usePrefix: () => {
      let { getPrefixCls: e, iconPrefixCls: t } = (0, h.useContext)($);
      return { rootPrefixCls: e(), iconPrefixCls: t };
    },
    useToken: () => {
      let [e, t, n, r, i] = na();
      return { theme: e, realToken: t, hashId: n, token: r, cssVar: i };
    },
    useCSP: () => {
      let { csp: e } = (0, h.useContext)($);
      return e ?? {};
    },
    getResetStyles: (e, t) => {
      let n = sa(e);
      return [
        n,
        { "&": n },
        da((t == null ? void 0 : t.prefix.iconPrefixCls) ?? pi),
      ];
    },
    getCommonStyle: ca,
    getCompUnitless: () => Qi,
  }),
  ga = (e) => {
    let t = h.useContext(vi);
    return h.useMemo(
      () =>
        e
          ? typeof e == `string`
            ? e ?? t
            : typeof e == `function`
            ? e(t)
            : t
          : t,
      [e, t]
    );
  },
  _a = (e) => {
    let { componentCls: t } = e;
    return {
      [t]: {
        "&-block": { display: `flex`, width: `100%` },
        "&-vertical": { flexDirection: `column` },
      },
    };
  },
  va = (e) => {
    let { componentCls: t, antCls: n } = e;
    return {
      [t]: {
        display: `inline-flex`,
        "&-rtl": { direction: `rtl` },
        "&-vertical": { flexDirection: `column` },
        "&-align": {
          flexDirection: `column`,
          "&-center": { alignItems: `center` },
          "&-start": { alignItems: `flex-start` },
          "&-end": { alignItems: `flex-end` },
          "&-baseline": { alignItems: `baseline` },
        },
        [`${t}-item:empty`]: { display: `none` },
        [`${t}-item > ${n}-badge-not-a-wrapper:only-child`]: {
          display: `block`,
        },
      },
    };
  },
  ya = (e) => {
    let { componentCls: t } = e;
    return {
      [t]: {
        "&-gap-row-small": { rowGap: e.spaceGapSmallSize },
        "&-gap-row-middle": { rowGap: e.spaceGapMiddleSize },
        "&-gap-row-large": { rowGap: e.spaceGapLargeSize },
        "&-gap-col-small": { columnGap: e.spaceGapSmallSize },
        "&-gap-col-middle": { columnGap: e.spaceGapMiddleSize },
        "&-gap-col-large": { columnGap: e.spaceGapLargeSize },
      },
    };
  },
  ba = pa(
    `Space`,
    (e) => {
      let t = Fi(e, {
        spaceGapSmallSize: e.paddingXS,
        spaceGapMiddleSize: e.padding,
        spaceGapLargeSize: e.paddingLG,
      });
      return [va(t), ya(t), _a(t)];
    },
    () => ({}),
    { resetStyle: !1 }
  ),
  xa = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Sa = h.createContext(null),
  Ca = (e, t) => {
    let n = h.useContext(Sa),
      r = h.useMemo(() => {
        if (!n) return ``;
        let { compactDirection: r, isFirstItem: i, isLastItem: a } = n,
          o = r === `vertical` ? `-vertical-` : `-`;
        return (0, b.default)(`${e}-compact${o}item`, {
          [`${e}-compact${o}first-item`]: i,
          [`${e}-compact${o}last-item`]: a,
          [`${e}-compact${o}item-rtl`]: t === `rtl`,
        });
      }, [e, t, n]);
    return {
      compactSize: n == null ? void 0 : n.compactSize,
      compactDirection: n == null ? void 0 : n.compactDirection,
      compactItemClassnames: r,
    };
  },
  wa = (e) => {
    let { children: t } = e;
    return h.createElement(Sa.Provider, { value: null }, t);
  },
  Ta = (e) => {
    let { children: t } = e,
      n = xa(e, [`children`]);
    return h.createElement(Sa.Provider, { value: h.useMemo(() => n, [n]) }, t);
  },
  Ea = (e) => {
    let { getPrefixCls: t, direction: n } = h.useContext($),
      {
        size: r,
        direction: i,
        block: a,
        prefixCls: o,
        className: s,
        rootClassName: c,
        children: l,
      } = e,
      u = xa(e, [
        `size`,
        `direction`,
        `block`,
        `prefixCls`,
        `className`,
        `rootClassName`,
        `children`,
      ]),
      d = ga((e) => r ?? e),
      f = t(`space-compact`, o),
      [p, m] = ba(f),
      g = (0, b.default)(
        f,
        m,
        {
          [`${f}-rtl`]: n === `rtl`,
          [`${f}-block`]: a,
          [`${f}-vertical`]: i === `vertical`,
        },
        s,
        c
      ),
      _ = h.useContext(Sa),
      v = x(l),
      y = h.useMemo(
        () =>
          v.map((e, t) => {
            let n = (e == null ? void 0 : e.key) || `${f}-item-${t}`;
            return h.createElement(
              Ta,
              {
                key: n,
                compactSize: d,
                compactDirection: i,
                isFirstItem:
                  t === 0 && (!_ || (_ == null ? void 0 : _.isFirstItem)),
                isLastItem:
                  t === v.length - 1 &&
                  (!_ || (_ == null ? void 0 : _.isLastItem)),
              },
              e
            );
          }),
        [r, v, _]
      );
    return v.length === 0
      ? null
      : p(h.createElement(`div`, Object.assign({ className: g }, u), y));
  };
export {
  mt as $,
  fi as A,
  be as At,
  wr as B,
  x as Bt,
  Oi as C,
  Se as Ct,
  mi as D,
  j as Dt,
  $ as E,
  A as Et,
  ni as F,
  k as Ft,
  or as G,
  Z as H,
  m as Ht,
  ti as I,
  D as It,
  Pt as J,
  Qn as K,
  Qr as L,
  O as Lt,
  ui as M,
  _e as Mt,
  li as N,
  ge as Nt,
  pi as O,
  he as Ot,
  ii as P,
  de as Pt,
  B as Q,
  Nr as R,
  T as Rt,
  ki as S,
  Ce as St,
  yi as T,
  N as Tt,
  sr as U,
  f as Ut,
  Cr as V,
  p as Vt,
  cr as W,
  Ot as X,
  Ft as Y,
  bt as Z,
  na as _,
  je as _t,
  ga as a,
  tt as at,
  Fi as b,
  Ae as bt,
  ha as c,
  Ue as ct,
  ua as d,
  Be as dt,
  st as et,
  da as f,
  Ve as ft,
  ra as g,
  Fe as gt,
  aa as h,
  P as ht,
  ba as i,
  it,
  di as j,
  ye as jt,
  _i as k,
  me as kt,
  oa as l,
  F as lt,
  ia as m,
  Le as mt,
  wa as n,
  ot as nt,
  ma as o,
  L as ot,
  fa as p,
  Ie as pt,
  Kt as q,
  Ca as r,
  rt,
  pa as s,
  We as st,
  Ea as t,
  at as tt,
  la as u,
  I as ut,
  Xi as v,
  Me as vt,
  vi as w,
  M as wt,
  ji as x,
  we as xt,
  Ji as y,
  ke as yt,
  Or as z,
  E as zt,
};
