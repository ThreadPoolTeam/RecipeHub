import { t as e } from "./Names-cLrBZ1-_.js";
var t = { name: e.areaName, iconImage: `/client/img/header/rewards.svg` };
export { t };
