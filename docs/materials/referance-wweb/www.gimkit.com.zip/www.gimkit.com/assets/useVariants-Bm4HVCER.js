import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { D as n, E as r } from "./Compact-CRRKXVA1.js";
import { c as i } from "./ContextIsolator-D7w7V6rn.js";
var a = e(t()),
  o = (e, t, o = void 0) => {
    let { variant: s, [e]: c } = a.useContext(r),
      l = a.useContext(i),
      u = c == null ? void 0 : c.variant,
      d;
    d =
      t === void 0 ? (o === !1 ? `borderless` : l ?? u ?? s ?? `outlined`) : t;
    let f = n.includes(d);
    return [d, f];
  };
export { o as t };
