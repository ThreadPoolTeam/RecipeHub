import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import {
  C as i,
  E as a,
  Ft as o,
  Ht as s,
  It as c,
  J as l,
  Lt as u,
  Ot as d,
  Ut as f,
  Vt as p,
  X as m,
  a as h,
  b as g,
  gt as _,
  ht as v,
  k as y,
  l as b,
  lt as x,
  m as S,
  nt as C,
  r as w,
  s as T,
  tt as E,
  ut as D,
  x as O,
} from "./Compact-CRRKXVA1.js";
import { h as k, i as A, s as j, v as M } from "./color-Dzrzfp-h.js";
import { t as ee } from "./es-sgMnT67r.js";
import { r as N, t as P } from "./compact-item-BOjQ1zv3.js";
import { r as F, t as I } from "./ContextIsolator-D7w7V6rn.js";
import { n as L, t as R } from "./useCSSVarCls-7-ltqzGc.js";
import { t as z } from "./pickAttrs-DgAKW8il.js";
import { t as B } from "./button-Cpfts2Ff.js";
import { t as V } from "./useVariants-Bm4HVCER.js";
var H = e(t());
n(), s(), u(), _(), D(), C();
var U = e(f());
function te(e, t, n) {
  return (0, U.default)({
    [`${e}-status-success`]: t === `success`,
    [`${e}-status-warning`]: t === `warning`,
    [`${e}-status-error`]: t === `error`,
    [`${e}-status-validating`]: t === `validating`,
    [`${e}-has-feedback`]: n,
  });
}
var W = (e, t) => t || e,
  ne = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M909.6 854.5L649.9 594.8C690.2 542.7 712 479 712 412c0-80.2-31.3-155.4-87.9-212.1-56.6-56.7-132-87.9-212.1-87.9s-155.5 31.3-212.1 87.9C143.2 256.5 112 331.8 112 412c0 80.1 31.3 155.5 87.9 212.1C256.5 680.8 331.8 712 412 712c67 0 130.6-21.8 182.7-62l259.7 259.6a8.2 8.2 0 0011.6 0l43.6-43.5a8.2 8.2 0 000-11.6zM570.4 570.4C528 612.7 471.8 636 412 636s-116-23.3-158.4-65.6C211.3 528 188 471.8 188 412s23.3-116.1 65.6-158.4C296 211.3 352.2 188 412 188s116.1 23.2 158.4 65.6S636 352.2 636 412s-23.3 116.1-65.6 158.4z`,
          },
        },
      ],
    },
    name: `search`,
    theme: `outlined`,
  },
  G = H.forwardRef(function (e, t) {
    return H.createElement(N, r({}, e, { ref: t, icon: ne }));
  });
function K(e) {
  return g(e, { inputAffixPadding: e.paddingXXS });
}
var re = (e) => {
    let {
        controlHeight: t,
        fontSize: n,
        lineHeight: r,
        lineWidth: i,
        controlHeightSM: a,
        controlHeightLG: o,
        fontSizeLG: s,
        lineHeightLG: c,
        paddingSM: l,
        controlPaddingHorizontalSM: u,
        controlPaddingHorizontal: d,
        colorFillAlter: f,
        colorPrimaryHover: p,
        colorPrimary: m,
        controlOutlineWidth: h,
        controlOutline: g,
        colorErrorOutline: _,
        colorWarningOutline: v,
        colorBgContainer: y,
        inputFontSize: b,
        inputFontSizeLG: x,
        inputFontSizeSM: S,
      } = e,
      C = b || n,
      w = S || C,
      T = x || s,
      E = Math.round(((t - C * r) / 2) * 10) / 10 - i,
      D = Math.round(((a - w * r) / 2) * 10) / 10 - i,
      O = Math.ceil(((o - T * c) / 2) * 10) / 10 - i;
    return {
      paddingBlock: Math.max(E, 0),
      paddingBlockSM: Math.max(D, 0),
      paddingBlockLG: Math.max(O, 0),
      paddingInline: l - i,
      paddingInlineSM: u - i,
      paddingInlineLG: d - i,
      addonBg: f,
      activeBorderColor: m,
      hoverBorderColor: p,
      activeShadow: `0 0 0 ${h}px ${g}`,
      errorActiveShadow: `0 0 0 ${h}px ${_}`,
      warningActiveShadow: `0 0 0 ${h}px ${v}`,
      hoverBg: y,
      activeBg: y,
      inputFontSize: C,
      inputFontSizeLG: T,
      inputFontSizeSM: w,
    };
  },
  q = (e) => ({ borderColor: e.hoverBorderColor, backgroundColor: e.hoverBg }),
  J = (e) => ({
    color: e.colorTextDisabled,
    backgroundColor: e.colorBgContainerDisabled,
    borderColor: e.colorBorder,
    boxShadow: `none`,
    cursor: `not-allowed`,
    opacity: 1,
    "input[disabled], textarea[disabled]": { cursor: `not-allowed` },
    "&:hover:not([disabled])": Object.assign(
      {},
      q(
        g(e, {
          hoverBorderColor: e.colorBorder,
          hoverBg: e.colorBgContainerDisabled,
        })
      )
    ),
  }),
  Y = (e, t) => ({
    background: e.colorBgContainer,
    borderWidth: e.lineWidth,
    borderStyle: e.lineType,
    borderColor: t.borderColor,
    "&:hover": { borderColor: t.hoverBorderColor, backgroundColor: e.hoverBg },
    "&:focus, &:focus-within": {
      borderColor: t.activeBorderColor,
      boxShadow: t.activeShadow,
      outline: 0,
      backgroundColor: e.activeBg,
    },
  }),
  X = (e, t) => ({
    [`&${e.componentCls}-status-${t.status}:not(${e.componentCls}-disabled)`]:
      Object.assign(Object.assign({}, Y(e, t)), {
        [`${e.componentCls}-prefix, ${e.componentCls}-suffix`]: {
          color: t.affixColor,
        },
      }),
    [`&${e.componentCls}-status-${t.status}${e.componentCls}-disabled`]: {
      borderColor: t.borderColor,
    },
  }),
  Z = (e, t) => ({
    "&-outlined": Object.assign(
      Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              {},
              Y(e, {
                borderColor: e.colorBorder,
                hoverBorderColor: e.hoverBorderColor,
                activeBorderColor: e.activeBorderColor,
                activeShadow: e.activeShadow,
              })
            ),
            {
              [`&${e.componentCls}-disabled, &[disabled]`]: Object.assign(
                {},
                J(e)
              ),
            }
          ),
          X(e, {
            status: `error`,
            borderColor: e.colorError,
            hoverBorderColor: e.colorErrorBorderHover,
            activeBorderColor: e.colorError,
            activeShadow: e.errorActiveShadow,
            affixColor: e.colorError,
          })
        ),
        X(e, {
          status: `warning`,
          borderColor: e.colorWarning,
          hoverBorderColor: e.colorWarningBorderHover,
          activeBorderColor: e.colorWarning,
          activeShadow: e.warningActiveShadow,
          affixColor: e.colorWarning,
        })
      ),
      t
    ),
  }),
  ie = (e, t) => ({
    [`&${e.componentCls}-group-wrapper-status-${t.status}`]: {
      [`${e.componentCls}-group-addon`]: {
        borderColor: t.addonBorderColor,
        color: t.addonColor,
      },
    },
  }),
  ae = (e) => ({
    "&-outlined": Object.assign(
      Object.assign(
        Object.assign(
          {
            [`${e.componentCls}-group`]: {
              "&-addon": {
                background: e.addonBg,
                border: `${m(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
              },
              "&-addon:first-child": { borderInlineEnd: 0 },
              "&-addon:last-child": { borderInlineStart: 0 },
            },
          },
          ie(e, {
            status: `error`,
            addonBorderColor: e.colorError,
            addonColor: e.colorErrorText,
          })
        ),
        ie(e, {
          status: `warning`,
          addonBorderColor: e.colorWarning,
          addonColor: e.colorWarningText,
        })
      ),
      {
        [`&${e.componentCls}-group-wrapper-disabled`]: {
          [`${e.componentCls}-group-addon`]: Object.assign({}, J(e)),
        },
      }
    ),
  }),
  oe = (e, t) => {
    let { componentCls: n } = e;
    return {
      "&-borderless": Object.assign(
        {
          background: `transparent`,
          border: `none`,
          "&:focus, &:focus-within": { outline: `none` },
          [`&${n}-disabled, &[disabled]`]: {
            color: e.colorTextDisabled,
            cursor: `not-allowed`,
          },
          [`&${n}-status-error`]: {
            "&, & input, & textarea": { color: e.colorError },
          },
          [`&${n}-status-warning`]: {
            "&, & input, & textarea": { color: e.colorWarning },
          },
        },
        t
      ),
    };
  },
  se = (e, t) => ({
    background: t.bg,
    borderWidth: e.lineWidth,
    borderStyle: e.lineType,
    borderColor: `transparent`,
    "input&, & input, textarea&, & textarea": {
      color: (t == null ? void 0 : t.inputColor) ?? `unset`,
    },
    "&:hover": { background: t.hoverBg },
    "&:focus, &:focus-within": {
      outline: 0,
      borderColor: t.activeBorderColor,
      backgroundColor: e.activeBg,
    },
  }),
  Q = (e, t) => ({
    [`&${e.componentCls}-status-${t.status}:not(${e.componentCls}-disabled)`]:
      Object.assign(Object.assign({}, se(e, t)), {
        [`${e.componentCls}-prefix, ${e.componentCls}-suffix`]: {
          color: t.affixColor,
        },
      }),
  }),
  ce = (e, t) => ({
    "&-filled": Object.assign(
      Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              {},
              se(e, {
                bg: e.colorFillTertiary,
                hoverBg: e.colorFillSecondary,
                activeBorderColor: e.activeBorderColor,
              })
            ),
            {
              [`&${e.componentCls}-disabled, &[disabled]`]: Object.assign(
                {},
                J(e)
              ),
            }
          ),
          Q(e, {
            status: `error`,
            bg: e.colorErrorBg,
            hoverBg: e.colorErrorBgHover,
            activeBorderColor: e.colorError,
            inputColor: e.colorErrorText,
            affixColor: e.colorError,
          })
        ),
        Q(e, {
          status: `warning`,
          bg: e.colorWarningBg,
          hoverBg: e.colorWarningBgHover,
          activeBorderColor: e.colorWarning,
          inputColor: e.colorWarningText,
          affixColor: e.colorWarning,
        })
      ),
      t
    ),
  }),
  le = (e, t) => ({
    [`&${e.componentCls}-group-wrapper-status-${t.status}`]: {
      [`${e.componentCls}-group-addon`]: {
        background: t.addonBg,
        color: t.addonColor,
      },
    },
  }),
  ue = (e) => ({
    "&-filled": Object.assign(
      Object.assign(
        Object.assign(
          {
            [`${e.componentCls}-group-addon`]: {
              background: e.colorFillTertiary,
              "&:last-child": { position: `static` },
            },
          },
          le(e, {
            status: `error`,
            addonBg: e.colorErrorBg,
            addonColor: e.colorErrorText,
          })
        ),
        le(e, {
          status: `warning`,
          addonBg: e.colorWarningBg,
          addonColor: e.colorWarningText,
        })
      ),
      {
        [`&${e.componentCls}-group-wrapper-disabled`]: {
          [`${e.componentCls}-group`]: {
            "&-addon": {
              background: e.colorFillTertiary,
              color: e.colorTextDisabled,
            },
            "&-addon:first-child": {
              borderInlineStart: `${m(e.lineWidth)} ${e.lineType} ${
                e.colorBorder
              }`,
              borderTop: `${m(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
              borderBottom: `${m(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
            },
            "&-addon:last-child": {
              borderInlineEnd: `${m(e.lineWidth)} ${e.lineType} ${
                e.colorBorder
              }`,
              borderTop: `${m(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
              borderBottom: `${m(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
            },
          },
        },
      }
    ),
  }),
  de = (e, t) => ({
    background: e.colorBgContainer,
    borderWidth: `${m(e.lineWidth)} 0`,
    borderStyle: `${e.lineType} none`,
    borderColor: `transparent transparent ${t.borderColor} transparent`,
    borderRadius: 0,
    "&:hover": {
      borderColor: `transparent transparent ${t.borderColor} transparent`,
      backgroundColor: e.hoverBg,
    },
    "&:focus, &:focus-within": {
      borderColor: `transparent transparent ${t.activeBorderColor} transparent`,
      outline: 0,
      backgroundColor: e.activeBg,
    },
  }),
  fe = (e, t) => ({
    [`&${e.componentCls}-status-${t.status}:not(${e.componentCls}-disabled)`]:
      Object.assign(Object.assign({}, de(e, t)), {
        [`${e.componentCls}-prefix, ${e.componentCls}-suffix`]: {
          color: t.affixColor,
        },
      }),
    [`&${e.componentCls}-status-${t.status}${e.componentCls}-disabled`]: {
      borderColor: `transparent transparent ${t.borderColor} transparent`,
    },
  }),
  pe = (e, t) => ({
    "&-underlined": Object.assign(
      Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              {},
              de(e, {
                borderColor: e.colorBorder,
                hoverBorderColor: e.hoverBorderColor,
                activeBorderColor: e.activeBorderColor,
                activeShadow: e.activeShadow,
              })
            ),
            {
              [`&${e.componentCls}-disabled, &[disabled]`]: {
                color: e.colorTextDisabled,
                boxShadow: `none`,
                cursor: `not-allowed`,
                "&:hover": {
                  borderColor: `transparent transparent ${e.colorBorder} transparent`,
                },
              },
              "input[disabled], textarea[disabled]": { cursor: `not-allowed` },
            }
          ),
          fe(e, {
            status: `error`,
            borderColor: e.colorError,
            hoverBorderColor: e.colorErrorBorderHover,
            activeBorderColor: e.colorError,
            activeShadow: e.errorActiveShadow,
            affixColor: e.colorError,
          })
        ),
        fe(e, {
          status: `warning`,
          borderColor: e.colorWarning,
          hoverBorderColor: e.colorWarningBorderHover,
          activeBorderColor: e.colorWarning,
          activeShadow: e.warningActiveShadow,
          affixColor: e.colorWarning,
        })
      ),
      t
    ),
  }),
  me = (e) => ({
    "&::-moz-placeholder": { opacity: 1 },
    "&::placeholder": { color: e, userSelect: `none` },
    "&:placeholder-shown": { textOverflow: `ellipsis` },
  }),
  he = (e) => {
    let {
      paddingBlockLG: t,
      lineHeightLG: n,
      borderRadiusLG: r,
      paddingInlineLG: i,
    } = e;
    return {
      padding: `${m(t)} ${m(i)}`,
      fontSize: e.inputFontSizeLG,
      lineHeight: n,
      borderRadius: r,
    };
  },
  ge = (e) => ({
    padding: `${m(e.paddingBlockSM)} ${m(e.paddingInlineSM)}`,
    fontSize: e.inputFontSizeSM,
    borderRadius: e.borderRadiusSM,
  }),
  _e = (e) =>
    Object.assign(
      Object.assign(
        {
          position: `relative`,
          display: `inline-block`,
          width: `100%`,
          minWidth: 0,
          padding: `${m(e.paddingBlock)} ${m(e.paddingInline)}`,
          color: e.colorText,
          fontSize: e.inputFontSize,
          lineHeight: e.lineHeight,
          borderRadius: e.borderRadius,
          transition: `all ${e.motionDurationMid}`,
        },
        me(e.colorTextPlaceholder)
      ),
      {
        "&-lg": Object.assign({}, he(e)),
        "&-sm": Object.assign({}, ge(e)),
        "&-rtl, &-textarea-rtl": { direction: `rtl` },
      }
    ),
  ve = (e) => {
    let { componentCls: t, antCls: n } = e;
    return {
      position: `relative`,
      display: `table`,
      width: `100%`,
      borderCollapse: `separate`,
      borderSpacing: 0,
      "&[class*='col-']": {
        paddingInlineEnd: e.paddingXS,
        "&:last-child": { paddingInlineEnd: 0 },
      },
      [`&-lg ${t}, &-lg > ${t}-group-addon`]: Object.assign({}, he(e)),
      [`&-sm ${t}, &-sm > ${t}-group-addon`]: Object.assign({}, ge(e)),
      [`&-lg ${n}-select-single ${n}-select-selector`]: {
        height: e.controlHeightLG,
      },
      [`&-sm ${n}-select-single ${n}-select-selector`]: {
        height: e.controlHeightSM,
      },
      [`> ${t}`]: {
        display: `table-cell`,
        "&:not(:first-child):not(:last-child)": { borderRadius: 0 },
      },
      [`${t}-group`]: {
        "&-addon, &-wrap": {
          display: `table-cell`,
          width: 1,
          whiteSpace: `nowrap`,
          verticalAlign: `middle`,
          "&:not(:first-child):not(:last-child)": { borderRadius: 0 },
        },
        "&-wrap > *": { display: `block !important` },
        "&-addon": {
          position: `relative`,
          padding: `0 ${m(e.paddingInline)}`,
          color: e.colorText,
          fontWeight: `normal`,
          fontSize: e.inputFontSize,
          textAlign: `center`,
          borderRadius: e.borderRadius,
          transition: `all ${e.motionDurationSlow}`,
          lineHeight: 1,
          [`${n}-select`]: {
            margin: `${m(e.calc(e.paddingBlock).add(1).mul(-1).equal())} ${m(
              e.calc(e.paddingInline).mul(-1).equal()
            )}`,
            [`&${n}-select-single:not(${n}-select-customize-input):not(${n}-pagination-size-changer)`]:
              {
                [`${n}-select-selector`]: {
                  backgroundColor: `inherit`,
                  border: `${m(e.lineWidth)} ${e.lineType} transparent`,
                  boxShadow: `none`,
                },
              },
          },
          [`${n}-cascader-picker`]: {
            margin: `-9px ${m(e.calc(e.paddingInline).mul(-1).equal())}`,
            backgroundColor: `transparent`,
            [`${n}-cascader-input`]: {
              textAlign: `start`,
              border: 0,
              boxShadow: `none`,
            },
          },
        },
      },
      [t]: {
        width: `100%`,
        marginBottom: 0,
        textAlign: `inherit`,
        "&:focus": { zIndex: 1, borderInlineEndWidth: 1 },
        "&:hover": {
          zIndex: 1,
          borderInlineEndWidth: 1,
          [`${t}-search-with-button &`]: { zIndex: 0 },
        },
      },
      [`> ${t}:first-child, ${t}-group-addon:first-child`]: {
        borderStartEndRadius: 0,
        borderEndEndRadius: 0,
        [`${n}-select ${n}-select-selector`]: {
          borderStartEndRadius: 0,
          borderEndEndRadius: 0,
        },
      },
      [`> ${t}-affix-wrapper`]: {
        [`&:not(:first-child) ${t}`]: {
          borderStartStartRadius: 0,
          borderEndStartRadius: 0,
        },
        [`&:not(:last-child) ${t}`]: {
          borderStartEndRadius: 0,
          borderEndEndRadius: 0,
        },
      },
      [`> ${t}:last-child, ${t}-group-addon:last-child`]: {
        borderStartStartRadius: 0,
        borderEndStartRadius: 0,
        [`${n}-select ${n}-select-selector`]: {
          borderStartStartRadius: 0,
          borderEndStartRadius: 0,
        },
      },
      [`${t}-affix-wrapper`]: {
        "&:not(:last-child)": {
          borderStartEndRadius: 0,
          borderEndEndRadius: 0,
          [`${t}-search &`]: {
            borderStartStartRadius: e.borderRadius,
            borderEndStartRadius: e.borderRadius,
          },
        },
        [`&:not(:first-child), ${t}-search &:not(:first-child)`]: {
          borderStartStartRadius: 0,
          borderEndStartRadius: 0,
        },
      },
      [`&${t}-group-compact`]: Object.assign(
        Object.assign({ display: `block` }, b()),
        {
          [`${t}-group-addon, ${t}-group-wrap, > ${t}`]: {
            "&:not(:first-child):not(:last-child)": {
              borderInlineEndWidth: e.lineWidth,
              "&:hover, &:focus": { zIndex: 1 },
            },
          },
          "& > *": {
            display: `inline-flex`,
            float: `none`,
            verticalAlign: `top`,
            borderRadius: 0,
          },
          [`
        & > ${t}-affix-wrapper,
        & > ${t}-number-affix-wrapper,
        & > ${n}-picker-range
      `]: { display: `inline-flex` },
          "& > *:not(:last-child)": {
            marginInlineEnd: e.calc(e.lineWidth).mul(-1).equal(),
            borderInlineEndWidth: e.lineWidth,
          },
          [t]: { float: `none` },
          [`& > ${n}-select > ${n}-select-selector,
      & > ${n}-select-auto-complete ${t},
      & > ${n}-cascader-picker ${t},
      & > ${t}-group-wrapper ${t}`]: {
            borderInlineEndWidth: e.lineWidth,
            borderRadius: 0,
            "&:hover, &:focus": { zIndex: 1 },
          },
          [`& > ${n}-select-focused`]: { zIndex: 1 },
          [`& > ${n}-select > ${n}-select-arrow`]: { zIndex: 1 },
          [`& > *:first-child,
      & > ${n}-select:first-child > ${n}-select-selector,
      & > ${n}-select-auto-complete:first-child ${t},
      & > ${n}-cascader-picker:first-child ${t}`]: {
            borderStartStartRadius: e.borderRadius,
            borderEndStartRadius: e.borderRadius,
          },
          [`& > *:last-child,
      & > ${n}-select:last-child > ${n}-select-selector,
      & > ${n}-cascader-picker:last-child ${t},
      & > ${n}-cascader-picker-focused:last-child ${t}`]: {
            borderInlineEndWidth: e.lineWidth,
            borderStartEndRadius: e.borderRadius,
            borderEndEndRadius: e.borderRadius,
          },
          [`& > ${n}-select-auto-complete ${t}`]: { verticalAlign: `top` },
          [`${t}-group-wrapper + ${t}-group-wrapper`]: {
            marginInlineStart: e.calc(e.lineWidth).mul(-1).equal(),
            [`${t}-affix-wrapper`]: { borderRadius: 0 },
          },
          [`${t}-group-wrapper:not(:last-child)`]: {
            [`&${t}-search > ${t}-group`]: {
              [`& > ${t}-group-addon > ${t}-search-button`]: {
                borderRadius: 0,
              },
              [`& > ${t}`]: {
                borderStartStartRadius: e.borderRadius,
                borderStartEndRadius: 0,
                borderEndEndRadius: 0,
                borderEndStartRadius: e.borderRadius,
              },
            },
          },
        }
      ),
    };
  },
  ye = (e) => {
    let { componentCls: t, controlHeightSM: n, lineWidth: r, calc: i } = e,
      a = i(n).sub(i(r).mul(2)).sub(16).div(2).equal();
    return {
      [t]: Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(Object.assign({}, S(e)), _e(e)),
                Z(e)
              ),
              ce(e)
            ),
            oe(e)
          ),
          pe(e)
        ),
        {
          '&[type="color"]': {
            height: e.controlHeight,
            [`&${t}-lg`]: { height: e.controlHeightLG },
            [`&${t}-sm`]: { height: n, paddingTop: a, paddingBottom: a },
          },
          '&[type="search"]::-webkit-search-cancel-button, &[type="search"]::-webkit-search-decoration':
            { appearance: `none` },
        }
      ),
    };
  },
  be = (e) => {
    let { componentCls: t } = e;
    return {
      [`${t}-clear-icon`]: {
        margin: 0,
        padding: 0,
        lineHeight: 0,
        color: e.colorTextQuaternary,
        fontSize: e.fontSizeIcon,
        verticalAlign: -1,
        cursor: `pointer`,
        transition: `color ${e.motionDurationSlow}`,
        border: `none`,
        outline: `none`,
        backgroundColor: `transparent`,
        "&:hover": { color: e.colorIcon },
        "&:active": { color: e.colorText },
        "&-hidden": { visibility: `hidden` },
        "&-has-suffix": { margin: `0 ${m(e.inputAffixPadding)}` },
      },
    };
  },
  xe = (e) => {
    let {
        componentCls: t,
        inputAffixPadding: n,
        colorTextDescription: r,
        motionDurationSlow: i,
        colorIcon: a,
        colorIconHover: o,
        iconCls: s,
      } = e,
      c = `${t}-affix-wrapper`,
      l = `${t}-affix-wrapper-disabled`;
    return {
      [c]: Object.assign(
        Object.assign(
          Object.assign(Object.assign({}, _e(e)), {
            display: `inline-flex`,
            [`&:not(${t}-disabled):hover`]: {
              zIndex: 1,
              [`${t}-search-with-button &`]: { zIndex: 0 },
            },
            "&-focused, &:focus": { zIndex: 1 },
            [`> input${t}`]: { padding: 0 },
            [`> input${t}, > textarea${t}`]: {
              fontSize: `inherit`,
              border: `none`,
              borderRadius: 0,
              outline: `none`,
              background: `transparent`,
              color: `inherit`,
              "&::-ms-reveal": { display: `none` },
              "&:focus": { boxShadow: `none !important` },
            },
            "&::before": {
              display: `inline-block`,
              width: 0,
              visibility: `hidden`,
              content: `"\\a0"`,
            },
            [t]: {
              "&-prefix, &-suffix": {
                display: `flex`,
                flex: `none`,
                alignItems: `center`,
                "> *:not(:last-child)": { marginInlineEnd: e.paddingXS },
              },
              "&-show-count-suffix": { color: r, direction: `ltr` },
              "&-show-count-has-suffix": { marginInlineEnd: e.paddingXXS },
              "&-prefix": { marginInlineEnd: n },
              "&-suffix": { marginInlineStart: n },
            },
          }),
          be(e)
        ),
        {
          [`${s}${t}-password-icon`]: {
            color: a,
            cursor: `pointer`,
            transition: `all ${i}`,
            "&:hover": { color: o },
          },
        }
      ),
      [`${t}-underlined`]: { borderRadius: 0 },
      [l]: {
        [`${s}${t}-password-icon`]: {
          color: a,
          cursor: `not-allowed`,
          "&:hover": { color: a },
        },
      },
    };
  },
  Se = (e) => {
    let { componentCls: t, borderRadiusLG: n, borderRadiusSM: r } = e;
    return {
      [`${t}-group`]: Object.assign(
        Object.assign(Object.assign({}, S(e)), ve(e)),
        {
          "&-rtl": { direction: `rtl` },
          "&-wrapper": Object.assign(
            Object.assign(
              Object.assign(
                {
                  display: `inline-block`,
                  width: `100%`,
                  textAlign: `start`,
                  verticalAlign: `top`,
                  "&-rtl": { direction: `rtl` },
                  "&-lg": {
                    [`${t}-group-addon`]: {
                      borderRadius: n,
                      fontSize: e.inputFontSizeLG,
                    },
                  },
                  "&-sm": { [`${t}-group-addon`]: { borderRadius: r } },
                },
                ae(e)
              ),
              ue(e)
            ),
            {
              [`&:not(${t}-compact-first-item):not(${t}-compact-last-item)${t}-compact-item`]:
                { [`${t}, ${t}-group-addon`]: { borderRadius: 0 } },
              [`&:not(${t}-compact-last-item)${t}-compact-first-item`]: {
                [`${t}, ${t}-group-addon`]: {
                  borderStartEndRadius: 0,
                  borderEndEndRadius: 0,
                },
              },
              [`&:not(${t}-compact-first-item)${t}-compact-last-item`]: {
                [`${t}, ${t}-group-addon`]: {
                  borderStartStartRadius: 0,
                  borderEndStartRadius: 0,
                },
              },
              [`&:not(${t}-compact-last-item)${t}-compact-item`]: {
                [`${t}-affix-wrapper`]: {
                  borderStartEndRadius: 0,
                  borderEndEndRadius: 0,
                },
              },
              [`&:not(${t}-compact-first-item)${t}-compact-item`]: {
                [`${t}-affix-wrapper`]: {
                  borderStartStartRadius: 0,
                  borderEndStartRadius: 0,
                },
              },
            }
          ),
        }
      ),
    };
  },
  Ce = (e) => {
    let { componentCls: t, antCls: n } = e,
      r = `${t}-search`;
    return {
      [r]: {
        [t]: {
          "&:hover, &:focus": {
            [`+ ${t}-group-addon ${r}-button:not(${n}-btn-color-primary):not(${n}-btn-variant-text)`]:
              { borderInlineStartColor: e.colorPrimaryHover },
          },
        },
        [`${t}-affix-wrapper`]: { height: e.controlHeight, borderRadius: 0 },
        [`${t}-lg`]: { lineHeight: e.calc(e.lineHeightLG).sub(2e-4).equal() },
        [`> ${t}-group`]: {
          [`> ${t}-group-addon:last-child`]: {
            insetInlineStart: -1,
            padding: 0,
            border: 0,
            [`${r}-button`]: {
              marginInlineEnd: -1,
              borderStartStartRadius: 0,
              borderEndStartRadius: 0,
              boxShadow: `none`,
            },
            [`${r}-button:not(${n}-btn-color-primary)`]: {
              color: e.colorTextDescription,
              "&:hover": { color: e.colorPrimaryHover },
              "&:active": { color: e.colorPrimaryActive },
              [`&${n}-btn-loading::before`]: { inset: 0 },
            },
          },
        },
        [`${r}-button`]: {
          height: e.controlHeight,
          "&:hover, &:focus": { zIndex: 1 },
        },
        "&-large": {
          [`${t}-affix-wrapper, ${r}-button`]: { height: e.controlHeightLG },
        },
        "&-small": {
          [`${t}-affix-wrapper, ${r}-button`]: { height: e.controlHeightSM },
        },
        "&-rtl": { direction: `rtl` },
        [`&${t}-compact-item`]: {
          [`&:not(${t}-compact-last-item)`]: {
            [`${t}-group-addon`]: {
              [`${t}-search-button`]: {
                marginInlineEnd: e.calc(e.lineWidth).mul(-1).equal(),
                borderRadius: 0,
              },
            },
          },
          [`&:not(${t}-compact-first-item)`]: {
            [`${t},${t}-affix-wrapper`]: { borderRadius: 0 },
          },
          [`> ${t}-group-addon ${t}-search-button,
        > ${t},
        ${t}-affix-wrapper`]: { "&:hover, &:focus, &:active": { zIndex: 2 } },
          [`> ${t}-affix-wrapper-focused`]: { zIndex: 2 },
        },
      },
    };
  },
  we = (e) => {
    let { componentCls: t } = e;
    return {
      [`${t}-out-of-range`]: {
        [`&, & input, & textarea, ${t}-show-count-suffix, ${t}-data-count`]: {
          color: e.colorError,
        },
      },
    };
  },
  Te = T(
    [`Input`, `Shared`],
    (e) => {
      let t = g(e, K(e));
      return [ye(t), xe(t)];
    },
    re,
    { resetFont: !1 }
  ),
  Ee = T(
    [`Input`, `Component`],
    (e) => {
      let t = g(e, K(e));
      return [Se(t), Ce(t), we(t), P(t)];
    },
    re,
    { resetFont: !1 }
  );
function De(e) {
  return !!(e.addonBefore || e.addonAfter);
}
function Oe(e) {
  return !!(e.prefix || e.suffix || e.allowClear);
}
function ke(e, t, n) {
  var r = t.cloneNode(!0),
    i = Object.create(e, { target: { value: r }, currentTarget: { value: r } });
  return (
    (r.value = n),
    typeof t.selectionStart == `number` &&
      typeof t.selectionEnd == `number` &&
      ((r.selectionStart = t.selectionStart),
      (r.selectionEnd = t.selectionEnd)),
    (r.setSelectionRange = function () {
      t.setSelectionRange.apply(t, arguments);
    }),
    i
  );
}
function Ae(e, t, n, r) {
  if (n) {
    var i = t;
    t.type === `click`
      ? ((i = ke(t, e, ``)), n(i))
      : (e.type !== `file` && r !== void 0 && (i = ke(t, e, r)), n(i));
  }
}
function je(e, t) {
  if (e) {
    e.focus(t);
    var n = (t || {}).cursor;
    if (n) {
      var r = e.value.length;
      switch (n) {
        case `start`:
          e.setSelectionRange(0, 0);
          break;
        case `end`:
          e.setSelectionRange(r, r);
          break;
        default:
          e.setSelectionRange(0, r);
      }
    }
  }
}
n();
var Me = H.forwardRef(function (e, t) {
  var n,
    i,
    a,
    s = e.inputElement,
    l = e.children,
    u = e.prefixCls,
    d = e.prefix,
    f = e.suffix,
    m = e.addonBefore,
    h = e.addonAfter,
    g = e.className,
    _ = e.style,
    v = e.disabled,
    y = e.readOnly,
    b = e.focused,
    x = e.triggerFocus,
    S = e.allowClear,
    C = e.value,
    w = e.handleReset,
    T = e.hidden,
    E = e.classes,
    D = e.classNames,
    O = e.dataAttrs,
    k = e.styles,
    A = e.components,
    j = e.onClear,
    M = l ?? s,
    ee = (A == null ? void 0 : A.affixWrapper) || `span`,
    N = (A == null ? void 0 : A.groupWrapper) || `span`,
    P = (A == null ? void 0 : A.wrapper) || `span`,
    F = (A == null ? void 0 : A.groupAddon) || `span`,
    I = (0, H.useRef)(null),
    L = function (e) {
      var t;
      (t = I.current) != null && t.contains(e.target) && (x == null || x());
    },
    R = Oe(e),
    z = (0, H.cloneElement)(M, {
      value: C,
      className:
        (0, U.default)(
          (n = M.props) == null ? void 0 : n.className,
          !R && (D == null ? void 0 : D.variant)
        ) || null,
    }),
    B = (0, H.useRef)(null);
  if (
    (H.useImperativeHandle(t, function () {
      return { nativeElement: B.current || I.current };
    }),
    R)
  ) {
    var V = null;
    if (S) {
      var te = !v && !y && C,
        W = `${u}-clear-icon`,
        ne = p(S) === `object` && S != null && S.clearIcon ? S.clearIcon : `✖`;
      V = H.createElement(
        `button`,
        {
          type: `button`,
          tabIndex: -1,
          onClick: function (e) {
            w == null || w(e), j == null || j();
          },
          onMouseDown: function (e) {
            return e.preventDefault();
          },
          className: (0, U.default)(
            W,
            c(c({}, `${W}-hidden`, !te), `${W}-has-suffix`, !!f)
          ),
        },
        ne
      );
    }
    var G = `${u}-affix-wrapper`,
      K = (0, U.default)(
        G,
        c(
          c(
            c(
              c(c({}, `${u}-disabled`, v), `${G}-disabled`, v),
              `${G}-focused`,
              b
            ),
            `${G}-readonly`,
            y
          ),
          `${G}-input-with-clear-btn`,
          f && S && C
        ),
        E == null ? void 0 : E.affixWrapper,
        D == null ? void 0 : D.affixWrapper,
        D == null ? void 0 : D.variant
      ),
      re =
        (f || S) &&
        H.createElement(
          `span`,
          {
            className: (0, U.default)(
              `${u}-suffix`,
              D == null ? void 0 : D.suffix
            ),
            style: k == null ? void 0 : k.suffix,
          },
          V,
          f
        );
    z = H.createElement(
      ee,
      r(
        {
          className: K,
          style: k == null ? void 0 : k.affixWrapper,
          onClick: L,
        },
        O == null ? void 0 : O.affixWrapper,
        { ref: I }
      ),
      d &&
        H.createElement(
          `span`,
          {
            className: (0, U.default)(
              `${u}-prefix`,
              D == null ? void 0 : D.prefix
            ),
            style: k == null ? void 0 : k.prefix,
          },
          d
        ),
      z,
      re
    );
  }
  if (De(e)) {
    var q = `${u}-group`,
      J = `${q}-addon`,
      Y = `${q}-wrapper`,
      X = (0, U.default)(
        `${u}-wrapper`,
        q,
        E == null ? void 0 : E.wrapper,
        D == null ? void 0 : D.wrapper
      ),
      Z = (0, U.default)(
        Y,
        c({}, `${Y}-disabled`, v),
        E == null ? void 0 : E.group,
        D == null ? void 0 : D.groupWrapper
      );
    z = H.createElement(
      N,
      { className: Z, ref: B },
      H.createElement(
        P,
        { className: X },
        m && H.createElement(F, { className: J }, m),
        z,
        h && H.createElement(F, { className: J }, h)
      )
    );
  }
  return H.cloneElement(z, {
    className:
      (0, U.default)((i = z.props) == null ? void 0 : i.className, g) || null,
    style: o(o({}, (a = z.props) == null ? void 0 : a.style), _),
    hidden: T,
  });
});
s();
var Ne = [`show`];
function Pe(e, t) {
  return H.useMemo(
    function () {
      var n = {};
      t && (n.show = p(t) === `object` && t.formatter ? t.formatter : !!t),
        (n = o(o({}, n), e));
      var r = n,
        i = r.show,
        a = E(r, Ne);
      return o(
        o({}, a),
        {},
        {
          show: !!i,
          showFormatter: typeof i == `function` ? i : void 0,
          strategy:
            a.strategy ||
            function (e) {
              return e.length;
            },
        }
      );
    },
    [e, t]
  );
}
n(), u(), C();
var Fe = [
    `autoComplete`,
    `onChange`,
    `onFocus`,
    `onBlur`,
    `onPressEnter`,
    `onKeyDown`,
    `onKeyUp`,
    `prefixCls`,
    `disabled`,
    `htmlSize`,
    `className`,
    `maxLength`,
    `suffix`,
    `showCount`,
    `count`,
    `type`,
    `classes`,
    `classNames`,
    `styles`,
    `onCompositionStart`,
    `onCompositionEnd`,
  ],
  Ie = (0, H.forwardRef)(function (e, t) {
    var n = e.autoComplete,
      i = e.onChange,
      a = e.onFocus,
      s = e.onBlur,
      l = e.onPressEnter,
      u = e.onKeyDown,
      d = e.onKeyUp,
      f = e.prefixCls,
      p = f === void 0 ? `rc-input` : f,
      m = e.disabled,
      h = e.htmlSize,
      g = e.className,
      _ = e.maxLength,
      y = e.suffix,
      b = e.showCount,
      S = e.count,
      C = e.type,
      w = C === void 0 ? `text` : C,
      T = e.classes,
      D = e.classNames,
      k = e.styles,
      j = e.onCompositionStart,
      M = e.onCompositionEnd,
      ee = E(e, Fe),
      N = (0, H.useState)(!1),
      P = x(N, 2),
      F = P[0],
      I = P[1],
      L = (0, H.useRef)(!1),
      R = (0, H.useRef)(!1),
      z = (0, H.useRef)(null),
      B = (0, H.useRef)(null),
      V = function (e) {
        z.current && je(z.current, e);
      },
      te = O(e.defaultValue, { value: e.value }),
      W = x(te, 2),
      ne = W[0],
      G = W[1],
      K = ne == null ? `` : String(ne),
      re = (0, H.useState)(null),
      q = x(re, 2),
      J = q[0],
      Y = q[1],
      X = Pe(S, b),
      Z = X.max || _,
      ie = X.strategy(K),
      ae = !!Z && ie > Z;
    (0, H.useImperativeHandle)(t, function () {
      var e;
      return {
        focus: V,
        blur: function () {
          var e;
          (e = z.current) == null || e.blur();
        },
        setSelectionRange: function (e, t, n) {
          var r;
          (r = z.current) == null || r.setSelectionRange(e, t, n);
        },
        select: function () {
          var e;
          (e = z.current) == null || e.select();
        },
        input: z.current,
        nativeElement:
          ((e = B.current) == null ? void 0 : e.nativeElement) || z.current,
      };
    }),
      (0, H.useEffect)(
        function () {
          R.current && (R.current = !1),
            I(function (e) {
              return e && m ? !1 : e;
            });
        },
        [m]
      );
    var oe = function (e, t, n) {
      var r = t;
      if (!L.current && X.exceedFormatter && X.max && X.strategy(t) > X.max) {
        if (((r = X.exceedFormatter(t, { max: X.max })), t !== r)) {
          var a, o;
          Y([
            ((a = z.current) == null ? void 0 : a.selectionStart) || 0,
            ((o = z.current) == null ? void 0 : o.selectionEnd) || 0,
          ]);
        }
      } else if (n.source === `compositionEnd`) return;
      G(r), z.current && Ae(z.current, e, i, r);
    };
    (0, H.useEffect)(
      function () {
        if (J) {
          var e;
          (e = z.current) == null || e.setSelectionRange.apply(e, v(J));
        }
      },
      [J]
    );
    var se = function (e) {
        oe(e, e.target.value, { source: `change` });
      },
      Q = function (e) {
        (L.current = !1),
          oe(e, e.currentTarget.value, { source: `compositionEnd` }),
          M == null || M(e);
      },
      ce = function (e) {
        l && e.key === `Enter` && !R.current && ((R.current = !0), l(e)),
          u == null || u(e);
      },
      le = function (e) {
        e.key === `Enter` && (R.current = !1), d == null || d(e);
      },
      ue = function (e) {
        I(!0), a == null || a(e);
      },
      de = function (e) {
        R.current && (R.current = !1), I(!1), s == null || s(e);
      },
      fe = function (e) {
        G(``), V(), z.current && Ae(z.current, e, i);
      },
      pe = ae && `${p}-out-of-range`;
    return H.createElement(
      Me,
      r({}, ee, {
        prefixCls: p,
        className: (0, U.default)(g, pe),
        handleReset: fe,
        value: K,
        focused: F,
        triggerFocus: V,
        suffix: (function () {
          var e = Number(Z) > 0;
          if (y || X.show) {
            var t = X.showFormatter
              ? X.showFormatter({ value: K, count: ie, maxLength: Z })
              : `${ie}${e ? ` / ${Z}` : ``}`;
            return H.createElement(
              H.Fragment,
              null,
              X.show &&
                H.createElement(
                  `span`,
                  {
                    className: (0, U.default)(
                      `${p}-show-count-suffix`,
                      c({}, `${p}-show-count-has-suffix`, !!y),
                      D == null ? void 0 : D.count
                    ),
                    style: o({}, k == null ? void 0 : k.count),
                  },
                  t
                ),
              y
            );
          }
          return null;
        })(),
        disabled: m,
        classes: T,
        classNames: D,
        styles: k,
        ref: B,
      }),
      (function () {
        var t = A(e, [
          `prefixCls`,
          `onPressEnter`,
          `addonBefore`,
          `addonAfter`,
          `prefix`,
          `suffix`,
          `allowClear`,
          `defaultValue`,
          `showCount`,
          `count`,
          `classes`,
          `htmlSize`,
          `styles`,
          `classNames`,
          `onClear`,
        ]);
        return H.createElement(
          `input`,
          r({ autoComplete: n }, t, {
            onChange: se,
            onFocus: ue,
            onBlur: de,
            onKeyDown: ce,
            onKeyUp: le,
            className: (0, U.default)(
              p,
              c({}, `${p}-disabled`, m),
              D == null ? void 0 : D.input
            ),
            style: k == null ? void 0 : k.input,
            ref: z,
            size: h,
            type: w,
            onCompositionStart: function (e) {
              (L.current = !0), j == null || j(e);
            },
            onCompositionEnd: Q,
          })
        );
      })()
    );
  }),
  Le = (e) => {
    let t;
    return (
      typeof e == `object` && e && e.clearIcon
        ? (t = e)
        : e && (t = { clearIcon: H.createElement(L, null) }),
      t
    );
  };
function Re(e, t) {
  let n = (0, H.useRef)([]),
    r = () => {
      n.current.push(
        setTimeout(() => {
          var t, n, r, i;
          (t = e.current) != null &&
            t.input &&
            ((n = e.current) == null
              ? void 0
              : n.input.getAttribute(`type`)) === `password` &&
            (r = e.current) != null &&
            r.input.hasAttribute(`value`) &&
            ((i = e.current) == null || i.input.removeAttribute(`value`));
        })
      );
    };
  return (
    (0, H.useEffect)(
      () => (
        t && r(),
        () =>
          n.current.forEach((e) => {
            e && clearTimeout(e);
          })
      ),
      []
    ),
    r
  );
}
function ze(e) {
  return !!(e.prefix || e.suffix || e.allowClear || e.showCount);
}
var Be = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Ve = (0, H.forwardRef)((e, t) => {
    let {
        prefixCls: n,
        bordered: r = !0,
        status: i,
        size: a,
        disabled: o,
        onBlur: s,
        onFocus: c,
        suffix: l,
        allowClear: u,
        addonAfter: f,
        addonBefore: p,
        className: m,
        style: g,
        styles: _,
        rootClassName: v,
        onChange: b,
        classNames: x,
        variant: S,
      } = e,
      C = Be(e, [
        `prefixCls`,
        `bordered`,
        `status`,
        `size`,
        `disabled`,
        `onBlur`,
        `onFocus`,
        `suffix`,
        `allowClear`,
        `addonAfter`,
        `addonBefore`,
        `className`,
        `style`,
        `styles`,
        `rootClassName`,
        `onChange`,
        `classNames`,
        `variant`,
      ]),
      {
        getPrefixCls: T,
        direction: E,
        allowClear: D,
        autoComplete: O,
        className: A,
        style: j,
        classNames: M,
        styles: ee,
      } = y(`input`),
      N = T(`input`, n),
      P = (0, H.useRef)(null),
      L = R(N),
      [z, B, ne] = Te(N, v),
      [G] = Ee(N, L),
      { compactSize: K, compactItemClassnames: re } = w(N, E),
      q = h((e) => a ?? K ?? e),
      J = H.useContext(k),
      Y = o ?? J,
      { status: X, hasFeedback: Z, feedbackIcon: ie } = (0, H.useContext)(F),
      ae = W(X, i),
      oe = ze(e) || !!Z;
    (0, H.useRef)(oe);
    let se = Re(P, !0),
      Q = (e) => {
        se(), s == null || s(e);
      },
      ce = (e) => {
        se(), c == null || c(e);
      },
      le = (e) => {
        se(), b == null || b(e);
      },
      ue = (Z || l) && H.createElement(H.Fragment, null, l, Z && ie),
      de = Le(u ?? D),
      [fe, pe] = V(`input`, S, r);
    return z(
      G(
        H.createElement(
          Ie,
          Object.assign({ ref: d(t, P), prefixCls: N, autoComplete: O }, C, {
            disabled: Y,
            onBlur: Q,
            onFocus: ce,
            style: Object.assign(Object.assign({}, j), g),
            styles: Object.assign(Object.assign({}, ee), _),
            suffix: ue,
            allowClear: de,
            className: (0, U.default)(m, v, ne, L, re, A),
            onChange: le,
            addonBefore: p && H.createElement(I, { form: !0, space: !0 }, p),
            addonAfter: f && H.createElement(I, { form: !0, space: !0 }, f),
            classNames: Object.assign(Object.assign(Object.assign({}, x), M), {
              input: (0, U.default)(
                {
                  [`${N}-sm`]: q === `small`,
                  [`${N}-lg`]: q === `large`,
                  [`${N}-rtl`]: E === `rtl`,
                },
                x == null ? void 0 : x.input,
                M.input,
                B
              ),
              variant: (0, U.default)({ [`${N}-${fe}`]: pe }, te(N, ae)),
              affixWrapper: (0, U.default)(
                {
                  [`${N}-affix-wrapper-sm`]: q === `small`,
                  [`${N}-affix-wrapper-lg`]: q === `large`,
                  [`${N}-affix-wrapper-rtl`]: E === `rtl`,
                },
                B
              ),
              wrapper: (0, U.default)({ [`${N}-group-rtl`]: E === `rtl` }, B),
              groupWrapper: (0, U.default)(
                {
                  [`${N}-group-wrapper-sm`]: q === `small`,
                  [`${N}-group-wrapper-lg`]: q === `large`,
                  [`${N}-group-wrapper-rtl`]: E === `rtl`,
                  [`${N}-group-wrapper-${fe}`]: pe,
                },
                te(`${N}-group-wrapper`, ae, Z),
                B
              ),
            }),
          })
        )
      )
    );
  }),
  He = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 000 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35 0-51.5zM512 766c-161.3 0-279.4-81.8-362.7-254C232.6 339.8 350.7 258 512 258c161.3 0 279.4 81.8 362.7 254C791.5 684.2 673.4 766 512 766zm-4-430c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm0 288c-61.9 0-112-50.1-112-112s50.1-112 112-112 112 50.1 112 112-50.1 112-112 112z`,
          },
        },
      ],
    },
    name: `eye`,
    theme: `outlined`,
  };
n();
var Ue = H.forwardRef(function (e, t) {
    return H.createElement(N, r({}, e, { ref: t, icon: He }));
  }),
  We = (e) => {
    let { getPrefixCls: t, direction: n } = (0, H.useContext)(a),
      { prefixCls: r, className: i } = e,
      o = t(`input-group`, r),
      [s, c, l] = Ee(t(`input`)),
      u = (0, U.default)(
        o,
        l,
        {
          [`${o}-lg`]: e.size === `large`,
          [`${o}-sm`]: e.size === `small`,
          [`${o}-compact`]: e.compact,
          [`${o}-rtl`]: n === `rtl`,
        },
        c,
        i
      ),
      d = (0, H.useContext)(F),
      f = (0, H.useMemo)(
        () => Object.assign(Object.assign({}, d), { isFormItemInput: !1 }),
        [d]
      );
    return s(
      H.createElement(
        `span`,
        {
          className: u,
          style: e.style,
          onMouseEnter: e.onMouseEnter,
          onMouseLeave: e.onMouseLeave,
          onFocus: e.onFocus,
          onBlur: e.onBlur,
        },
        H.createElement(F.Provider, { value: f }, e.children)
      )
    );
  },
  Ge = (e) => {
    let { componentCls: t, paddingXS: n } = e;
    return {
      [t]: {
        display: `inline-flex`,
        alignItems: `center`,
        flexWrap: `nowrap`,
        columnGap: n,
        [`${t}-input-wrapper`]: {
          position: `relative`,
          [`${t}-mask-icon`]: {
            position: `absolute`,
            zIndex: `1`,
            top: `50%`,
            right: `50%`,
            transform: `translate(50%, -50%)`,
            pointerEvents: `none`,
          },
          [`${t}-mask-input`]: {
            color: `transparent`,
            caretColor: e.colorText,
          },
          [`${t}-mask-input[type=number]::-webkit-inner-spin-button`]: {
            "-webkit-appearance": `none`,
            margin: 0,
          },
          [`${t}-mask-input[type=number]`]: { "-moz-appearance": `textfield` },
        },
        "&-rtl": { direction: `rtl` },
        [`${t}-input`]: { textAlign: `center`, paddingInline: e.paddingXXS },
        [`&${t}-sm ${t}-input`]: {
          paddingInline: e.calc(e.paddingXXS).div(2).equal(),
        },
        [`&${t}-lg ${t}-input`]: { paddingInline: e.paddingXS },
      },
    };
  },
  Ke = T([`Input`, `OTP`], (e) => Ge(g(e, K(e))), re),
  qe = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Je = H.forwardRef((e, t) => {
    let {
        className: n,
        value: r,
        onChange: i,
        onActiveChange: o,
        index: s,
        mask: c,
      } = e,
      l = qe(e, [
        `className`,
        `value`,
        `onChange`,
        `onActiveChange`,
        `index`,
        `mask`,
      ]),
      { getPrefixCls: u } = H.useContext(a),
      d = u(`otp`),
      f = typeof c == `string` ? c : r,
      p = H.useRef(null);
    H.useImperativeHandle(t, () => p.current);
    let m = (e) => {
        i(s, e.target.value);
      },
      h = () => {
        M(() => {
          var e;
          let t = (e = p.current) == null ? void 0 : e.input;
          document.activeElement === t && t && t.select();
        });
      };
    return H.createElement(
      `span`,
      { className: `${d}-input-wrapper`, role: `presentation` },
      c &&
        r !== `` &&
        r !== void 0 &&
        H.createElement(
          `span`,
          { className: `${d}-mask-icon`, "aria-hidden": `true` },
          f
        ),
      H.createElement(
        Ve,
        Object.assign(
          {
            "aria-label": `OTP Input ${s + 1}`,
            type: c === !0 ? `password` : `text`,
          },
          l,
          {
            ref: p,
            value: r,
            onInput: m,
            onFocus: h,
            onKeyDown: (e) => {
              let { key: t, ctrlKey: n, metaKey: r } = e;
              t === `ArrowLeft`
                ? o(s - 1)
                : t === `ArrowRight`
                ? o(s + 1)
                : t === `z` && (n || r) && e.preventDefault(),
                h();
            },
            onKeyUp: (e) => {
              e.key === `Backspace` && !r && o(s - 1), h();
            },
            onMouseDown: h,
            onMouseUp: h,
            className: (0, U.default)(n, { [`${d}-mask-input`]: c }),
          }
        )
      )
    );
  });
_();
var Ye = function (e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) &&
      t.indexOf(r) < 0 &&
      (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == `function`)
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
        (n[r[i]] = e[r[i]]);
  return n;
};
function Xe(e) {
  return (e || ``).split(``);
}
var Ze = (e) => {
    let { index: t, prefixCls: n, separator: r } = e,
      i = typeof r == `function` ? r(t) : r;
    return i
      ? H.createElement(`span`, { className: `${n}-separator` }, i)
      : null;
  },
  Qe = H.forwardRef((e, t) => {
    let {
        prefixCls: n,
        length: r = 6,
        size: o,
        defaultValue: s,
        value: c,
        onChange: l,
        formatter: u,
        separator: d,
        variant: f,
        disabled: p,
        status: m,
        autoFocus: g,
        mask: _,
        type: y,
        onInput: b,
        inputMode: x,
      } = e,
      S = Ye(e, [
        `prefixCls`,
        `length`,
        `size`,
        `defaultValue`,
        `value`,
        `onChange`,
        `formatter`,
        `separator`,
        `variant`,
        `disabled`,
        `status`,
        `autoFocus`,
        `mask`,
        `type`,
        `onInput`,
        `inputMode`,
      ]),
      { getPrefixCls: C, direction: w } = H.useContext(a),
      T = C(`otp`, n),
      E = z(S, { aria: !0, data: !0, attr: !0 }),
      [D, O, k] = Ke(T),
      A = h((e) => o ?? e),
      j = H.useContext(F),
      M = W(j.status, m),
      ee = H.useMemo(
        () =>
          Object.assign(Object.assign({}, j), {
            status: M,
            hasFeedback: !1,
            feedbackIcon: null,
          }),
        [j, M]
      ),
      N = H.useRef(null),
      P = H.useRef({});
    H.useImperativeHandle(t, () => ({
      focus: () => {
        var e;
        (e = P.current[0]) == null || e.focus();
      },
      blur: () => {
        var e;
        for (let t = 0; t < r; t += 1) (e = P.current[t]) == null || e.blur();
      },
      nativeElement: N.current,
    }));
    let I = (e) => (u ? u(e) : e),
      [L, R] = H.useState(() => Xe(I(s || ``)));
    H.useEffect(() => {
      c !== void 0 && R(Xe(c));
    }, [c]);
    let B = i((e) => {
        R(e),
          b && b(e),
          l &&
            e.length === r &&
            e.every((e) => e) &&
            e.some((e, t) => L[t] !== e) &&
            l(e.join(``));
      }),
      V = i((e, t) => {
        let n = v(L);
        for (let t = 0; t < e; t += 1) n[t] || (n[t] = ``);
        t.length <= 1 ? (n[e] = t) : (n = n.slice(0, e).concat(Xe(t))),
          (n = n.slice(0, r));
        for (let e = n.length - 1; e >= 0 && !n[e]; --e) n.pop();
        return (
          (n = Xe(I(n.map((e) => e || ` `).join(``))).map((e, t) =>
            e === ` ` && !n[t] ? n[t] : e
          )),
          n
        );
      }),
      te = (e, t) => {
        var n;
        let i = V(e, t),
          a = Math.min(e + t.length, r - 1);
        a !== e && i[e] !== void 0 && ((n = P.current[a]) == null || n.focus()),
          B(i);
      },
      ne = (e) => {
        var t;
        (t = P.current[e]) == null || t.focus();
      },
      G = {
        variant: f,
        disabled: p,
        status: M,
        mask: _,
        type: y,
        inputMode: x,
      };
    return D(
      H.createElement(
        `div`,
        Object.assign({}, E, {
          ref: N,
          className: (0, U.default)(
            T,
            {
              [`${T}-sm`]: A === `small`,
              [`${T}-lg`]: A === `large`,
              [`${T}-rtl`]: w === `rtl`,
            },
            k,
            O
          ),
          role: `group`,
        }),
        H.createElement(
          F.Provider,
          { value: ee },
          Array.from({ length: r }).map((e, t) => {
            let n = `otp-${t}`,
              i = L[t] || ``;
            return H.createElement(
              H.Fragment,
              { key: n },
              H.createElement(
                Je,
                Object.assign(
                  {
                    ref: (e) => {
                      P.current[t] = e;
                    },
                    index: t,
                    size: A,
                    htmlSize: 1,
                    className: `${T}-input`,
                    onChange: te,
                    value: i,
                    onActiveChange: ne,
                    autoFocus: t === 0 && g,
                  },
                  G
                )
              ),
              t < r - 1 &&
                H.createElement(Ze, { separator: d, index: t, prefixCls: T })
            );
          })
        )
      )
    );
  }),
  $e = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 000-51.5zm-63.57-320.64L836 122.88a8 8 0 00-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 000 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 000 11.31L155.17 889a8 8 0 0011.31 0l712.15-712.12a8 8 0 000-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 00-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 01146.2-106.69L401.31 546.2A112 112 0 01396 512z`,
          },
        },
        {
          tag: `path`,
          attrs: {
            d: `M508 624c-3.46 0-6.87-.16-10.25-.47l-52.82 52.82a176.09 176.09 0 00227.42-227.42l-52.82 52.82c.31 3.38.47 6.79.47 10.25a111.94 111.94 0 01-112 112z`,
          },
        },
      ],
    },
    name: `eye-invisible`,
    theme: `outlined`,
  };
n();
var et = H.forwardRef(function (e, t) {
    return H.createElement(N, r({}, e, { ref: t, icon: $e }));
  }),
  tt = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  nt = (e) => (e ? H.createElement(Ue, null) : H.createElement(et, null)),
  rt = { click: `onClick`, hover: `onMouseOver` },
  it = H.forwardRef((e, t) => {
    let {
        disabled: n,
        action: r = `click`,
        visibilityToggle: i = !0,
        iconRender: o = nt,
        suffix: s,
      } = e,
      c = H.useContext(k),
      l = n ?? c,
      u = typeof i == `object` && i.visible !== void 0,
      [f, p] = (0, H.useState)(() => (u ? i.visible : !1)),
      m = (0, H.useRef)(null);
    H.useEffect(() => {
      u && p(i.visible);
    }, [u, i]);
    let h = Re(m),
      g = () => {
        var e;
        if (l) return;
        f && h();
        let t = !f;
        p(t),
          typeof i == `object` &&
            ((e = i.onVisibleChange) == null || e.call(i, t));
      },
      _ = (e) => {
        let t = rt[r] || ``,
          n = o(f),
          i = {
            [t]: g,
            className: `${e}-icon`,
            key: `passwordIcon`,
            onMouseDown: (e) => {
              e.preventDefault();
            },
            onMouseUp: (e) => {
              e.preventDefault();
            },
          };
        return H.cloneElement(
          H.isValidElement(n) ? n : H.createElement(`span`, null, n),
          i
        );
      },
      { className: v, prefixCls: y, inputPrefixCls: b, size: x } = e,
      S = tt(e, [`className`, `prefixCls`, `inputPrefixCls`, `size`]),
      { getPrefixCls: C } = H.useContext(a),
      w = C(`input`, b),
      T = C(`input-password`, y),
      E = i && _(T),
      D = (0, U.default)(T, v, { [`${T}-${x}`]: !!x }),
      O = Object.assign(
        Object.assign({}, A(S, [`suffix`, `iconRender`, `visibilityToggle`])),
        {
          type: f ? `text` : `password`,
          className: D,
          prefixCls: w,
          suffix: H.createElement(H.Fragment, null, E, s),
        }
      );
    return (
      x && (O.size = x), H.createElement(Ve, Object.assign({ ref: d(t, m) }, O))
    );
  }),
  at = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  ot = H.forwardRef((e, t) => {
    let {
        prefixCls: n,
        inputPrefixCls: r,
        className: i,
        size: o,
        suffix: s,
        enterButton: c = !1,
        addonAfter: l,
        loading: u,
        disabled: f,
        onSearch: p,
        onChange: m,
        onCompositionStart: g,
        onCompositionEnd: _,
        variant: v,
        onPressEnter: y,
      } = e,
      b = at(e, [
        `prefixCls`,
        `inputPrefixCls`,
        `className`,
        `size`,
        `suffix`,
        `enterButton`,
        `addonAfter`,
        `loading`,
        `disabled`,
        `onSearch`,
        `onChange`,
        `onCompositionStart`,
        `onCompositionEnd`,
        `variant`,
        `onPressEnter`,
      ]),
      { getPrefixCls: x, direction: S } = H.useContext(a),
      C = H.useRef(!1),
      T = x(`input-search`, n),
      E = x(`input`, r),
      { compactSize: D } = w(T, S),
      O = h((e) => o ?? D ?? e),
      k = H.useRef(null),
      A = (e) => {
        e != null &&
          e.target &&
          e.type === `click` &&
          p &&
          p(e.target.value, e, { source: `clear` }),
          m == null || m(e);
      },
      M = (e) => {
        var t;
        document.activeElement ===
          ((t = k.current) == null ? void 0 : t.input) && e.preventDefault();
      },
      ee = (e) => {
        var t, n;
        p &&
          p(
            (n = (t = k.current) == null ? void 0 : t.input) == null
              ? void 0
              : n.value,
            e,
            { source: `input` }
          );
      },
      N = (e) => {
        C.current || u || (y == null || y(e), ee(e));
      },
      P = typeof c == `boolean` ? H.createElement(G, null) : null,
      F = `${T}-button`,
      I,
      L = c || {},
      R = L.type && L.type.__ANT_BUTTON === !0;
    (I =
      R || L.type === `button`
        ? j(
            L,
            Object.assign(
              {
                onMouseDown: M,
                onClick: (e) => {
                  var t, n;
                  (n =
                    (t = L == null ? void 0 : L.props) == null
                      ? void 0
                      : t.onClick) == null || n.call(t, e),
                    ee(e);
                },
                key: `enterButton`,
              },
              R ? { className: F, size: O } : {}
            )
          )
        : H.createElement(
            B,
            {
              className: F,
              color: c ? `primary` : `default`,
              size: O,
              disabled: f,
              key: `enterButton`,
              onMouseDown: M,
              onClick: ee,
              loading: u,
              icon: P,
              variant:
                v === `borderless` || v === `filled` || v === `underlined`
                  ? `text`
                  : c
                  ? `solid`
                  : void 0,
            },
            c
          )),
      l && (I = [I, j(l, { key: `addonAfter` })]);
    let z = (0, U.default)(
        T,
        {
          [`${T}-rtl`]: S === `rtl`,
          [`${T}-${O}`]: !!O,
          [`${T}-with-button`]: !!c,
        },
        i
      ),
      V = Object.assign(Object.assign({}, b), {
        className: z,
        prefixCls: E,
        type: `search`,
        size: O,
        variant: v,
        onPressEnter: N,
        onCompositionStart: (e) => {
          (C.current = !0), g == null || g(e);
        },
        onCompositionEnd: (e) => {
          (C.current = !1), _ == null || _(e);
        },
        addonAfter: I,
        suffix: s,
        onChange: A,
        disabled: f,
      });
    return H.createElement(Ve, Object.assign({ ref: d(k, t) }, V));
  }),
  st = `
  min-height:0 !important;
  max-height:none !important;
  height:0 !important;
  visibility:hidden !important;
  overflow:hidden !important;
  position:absolute !important;
  z-index:-1000 !important;
  top:0 !important;
  right:0 !important;
  pointer-events: none !important;
`,
  ct = [
    `letter-spacing`,
    `line-height`,
    `padding-top`,
    `padding-bottom`,
    `font-family`,
    `font-weight`,
    `font-size`,
    `font-variant`,
    `text-rendering`,
    `text-transform`,
    `width`,
    `text-indent`,
    `padding-left`,
    `padding-right`,
    `border-width`,
    `box-sizing`,
    `word-break`,
    `white-space`,
  ],
  lt = {},
  $;
function ut(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
    n =
      e.getAttribute(`id`) ||
      e.getAttribute(`data-reactid`) ||
      e.getAttribute(`name`);
  if (t && lt[n]) return lt[n];
  var r = window.getComputedStyle(e),
    i =
      r.getPropertyValue(`box-sizing`) ||
      r.getPropertyValue(`-moz-box-sizing`) ||
      r.getPropertyValue(`-webkit-box-sizing`),
    a =
      parseFloat(r.getPropertyValue(`padding-bottom`)) +
      parseFloat(r.getPropertyValue(`padding-top`)),
    o =
      parseFloat(r.getPropertyValue(`border-bottom-width`)) +
      parseFloat(r.getPropertyValue(`border-top-width`)),
    s = {
      sizingStyle: ct
        .map(function (e) {
          return `${e}:${r.getPropertyValue(e)}`;
        })
        .join(`;`),
      paddingSize: a,
      borderSize: o,
      boxSizing: i,
    };
  return t && n && (lt[n] = s), s;
}
function dt(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
    n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : null,
    r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
  $ ||
    (($ = document.createElement(`textarea`)),
    $.setAttribute(`tab-index`, `-1`),
    $.setAttribute(`aria-hidden`, `true`),
    $.setAttribute(`name`, `hiddenTextarea`),
    document.body.appendChild($)),
    e.getAttribute(`wrap`)
      ? $.setAttribute(`wrap`, e.getAttribute(`wrap`))
      : $.removeAttribute(`wrap`);
  var i = ut(e, t),
    a = i.paddingSize,
    o = i.borderSize,
    s = i.boxSizing,
    c = i.sizingStyle;
  $.setAttribute(`style`, `${c};${st}`),
    ($.value = e.value || e.placeholder || ``);
  var l = void 0,
    u = void 0,
    d,
    f = $.scrollHeight;
  if (
    (s === `border-box` ? (f += o) : s === `content-box` && (f -= a),
    n !== null || r !== null)
  ) {
    $.value = ` `;
    var p = $.scrollHeight - a;
    n !== null &&
      ((l = p * n),
      s === `border-box` && (l = l + a + o),
      (f = Math.max(l, f))),
      r !== null &&
        ((u = p * r),
        s === `border-box` && (u = u + a + o),
        (d = f > u ? `` : `hidden`),
        (f = Math.min(u, f)));
  }
  var m = { height: f, overflowY: d, resize: `none` };
  return l && (m.minHeight = l), u && (m.maxHeight = u), m;
}
n(), u(), s(), D(), C();
var ft = [
    `prefixCls`,
    `defaultValue`,
    `value`,
    `autoSize`,
    `onResize`,
    `className`,
    `style`,
    `disabled`,
    `onChange`,
    `onInternalAutoSize`,
  ],
  pt = 0,
  mt = 1,
  ht = 2,
  gt = H.forwardRef(function (e, t) {
    var n = e,
      i = n.prefixCls,
      a = n.defaultValue,
      s = n.value,
      u = n.autoSize,
      d = n.onResize,
      f = n.className,
      m = n.style,
      h = n.disabled,
      g = n.onChange;
    n.onInternalAutoSize;
    var _ = E(n, ft),
      v = O(a, {
        value: s,
        postState: function (e) {
          return e ?? ``;
        },
      }),
      y = x(v, 2),
      b = y[0],
      S = y[1],
      C = function (e) {
        S(e.target.value), g == null || g(e);
      },
      w = H.useRef();
    H.useImperativeHandle(t, function () {
      return { textArea: w.current };
    });
    var T = H.useMemo(
        function () {
          return u && p(u) === `object` ? [u.minRows, u.maxRows] : [];
        },
        [u]
      ),
      D = x(T, 2),
      k = D[0],
      A = D[1],
      j = !!u,
      N = H.useState(ht),
      P = x(N, 2),
      F = P[0],
      I = P[1],
      L = H.useState(),
      R = x(L, 2),
      z = R[0],
      B = R[1],
      V = function () {
        I(pt);
      };
    l(
      function () {
        j && V();
      },
      [s, k, A, j]
    ),
      l(
        function () {
          if (F === pt) I(mt);
          else if (F === mt) {
            var e = dt(w.current, !1, k, A);
            I(ht), B(e);
          }
        },
        [F]
      );
    var te = H.useRef(),
      W = function () {
        M.cancel(te.current);
      },
      ne = function (e) {
        F === ht &&
          (d == null || d(e),
          u &&
            (W(),
            (te.current = M(function () {
              V();
            }))));
      };
    H.useEffect(function () {
      return W;
    }, []);
    var G = j ? z : null,
      K = o(o({}, m), G);
    return (
      (F === pt || F === mt) &&
        ((K.overflowY = `hidden`), (K.overflowX = `hidden`)),
      H.createElement(
        ee,
        { onResize: ne, disabled: !(u || d) },
        H.createElement(
          `textarea`,
          r({}, _, {
            ref: w,
            style: K,
            className: (0, U.default)(i, f, c({}, `${i}-disabled`, h)),
            disabled: h,
            value: b,
            onChange: C,
          })
        )
      )
    );
  });
n(), u(), _(), D(), C();
var _t = [
    `defaultValue`,
    `value`,
    `onFocus`,
    `onBlur`,
    `onChange`,
    `allowClear`,
    `maxLength`,
    `onCompositionStart`,
    `onCompositionEnd`,
    `suffix`,
    `prefixCls`,
    `showCount`,
    `count`,
    `className`,
    `style`,
    `disabled`,
    `hidden`,
    `classNames`,
    `styles`,
    `onResize`,
    `onClear`,
    `onPressEnter`,
    `readOnly`,
    `autoSize`,
    `onKeyDown`,
  ],
  vt = H.forwardRef(function (e, t) {
    var n = e.defaultValue,
      i = e.value,
      a = e.onFocus,
      s = e.onBlur,
      l = e.onChange,
      u = e.allowClear,
      d = e.maxLength,
      f = e.onCompositionStart,
      p = e.onCompositionEnd,
      m = e.suffix,
      h = e.prefixCls,
      g = h === void 0 ? `rc-textarea` : h,
      _ = e.showCount,
      y = e.count,
      b = e.className,
      S = e.style,
      C = e.disabled,
      w = e.hidden,
      T = e.classNames,
      D = e.styles,
      k = e.onResize,
      A = e.onClear,
      j = e.onPressEnter,
      M = e.readOnly,
      ee = e.autoSize,
      N = e.onKeyDown,
      P = E(e, _t),
      F = O(n, { value: i, defaultValue: n }),
      I = x(F, 2),
      L = I[0],
      R = I[1],
      z = L == null ? `` : String(L),
      B = H.useState(!1),
      V = x(B, 2),
      te = V[0],
      W = V[1],
      ne = H.useRef(!1),
      G = H.useState(null),
      K = x(G, 2),
      re = K[0],
      q = K[1],
      J = (0, H.useRef)(null),
      Y = (0, H.useRef)(null),
      X = function () {
        var e;
        return (e = Y.current) == null ? void 0 : e.textArea;
      },
      Z = function () {
        X().focus();
      };
    (0, H.useImperativeHandle)(t, function () {
      var e;
      return {
        resizableTextArea: Y.current,
        focus: Z,
        blur: function () {
          X().blur();
        },
        nativeElement:
          ((e = J.current) == null ? void 0 : e.nativeElement) || X(),
      };
    }),
      (0, H.useEffect)(
        function () {
          W(function (e) {
            return !C && e;
          });
        },
        [C]
      );
    var ie = H.useState(null),
      ae = x(ie, 2),
      oe = ae[0],
      se = ae[1];
    H.useEffect(
      function () {
        if (oe) {
          var e;
          (e = X()).setSelectionRange.apply(e, v(oe));
        }
      },
      [oe]
    );
    var Q = Pe(y, _),
      ce = Q.max ?? d,
      le = Number(ce) > 0,
      ue = Q.strategy(z),
      de = !!ce && ue > ce,
      fe = function (e, t) {
        var n = t;
        !ne.current &&
          Q.exceedFormatter &&
          Q.max &&
          Q.strategy(t) > Q.max &&
          ((n = Q.exceedFormatter(t, { max: Q.max })),
          t !== n && se([X().selectionStart || 0, X().selectionEnd || 0])),
          R(n),
          Ae(e.currentTarget, e, l, n);
      },
      pe = function (e) {
        (ne.current = !0), f == null || f(e);
      },
      me = function (e) {
        (ne.current = !1), fe(e, e.currentTarget.value), p == null || p(e);
      },
      he = function (e) {
        fe(e, e.target.value);
      },
      ge = function (e) {
        e.key === `Enter` && j && j(e), N == null || N(e);
      },
      _e = function (e) {
        W(!0), a == null || a(e);
      },
      ve = function (e) {
        W(!1), s == null || s(e);
      },
      ye = function (e) {
        R(``), Z(), Ae(X(), e, l);
      },
      be = m,
      xe;
    Q.show &&
      ((xe = Q.showFormatter
        ? Q.showFormatter({ value: z, count: ue, maxLength: ce })
        : `${ue}${le ? ` / ${ce}` : ``}`),
      (be = H.createElement(
        H.Fragment,
        null,
        be,
        H.createElement(
          `span`,
          {
            className: (0, U.default)(
              `${g}-data-count`,
              T == null ? void 0 : T.count
            ),
            style: D == null ? void 0 : D.count,
          },
          xe
        )
      )));
    var Se = function (e) {
        var t;
        k == null || k(e), (t = X()) != null && t.style.height && q(!0);
      },
      Ce = !ee && !_ && !u;
    return H.createElement(
      Me,
      {
        ref: J,
        value: z,
        allowClear: u,
        handleReset: ye,
        suffix: be,
        prefixCls: g,
        classNames: o(
          o({}, T),
          {},
          {
            affixWrapper: (0, U.default)(
              T == null ? void 0 : T.affixWrapper,
              c(c({}, `${g}-show-count`, _), `${g}-textarea-allow-clear`, u)
            ),
          }
        ),
        disabled: C,
        focused: te,
        className: (0, U.default)(b, de && `${g}-out-of-range`),
        style: o(o({}, S), re && !Ce ? { height: `auto` } : {}),
        dataAttrs: {
          affixWrapper: { "data-count": typeof xe == `string` ? xe : void 0 },
        },
        hidden: w,
        readOnly: M,
        onClear: A,
      },
      H.createElement(
        gt,
        r({}, P, {
          autoSize: ee,
          maxLength: d,
          onKeyDown: ge,
          onChange: he,
          onFocus: _e,
          onBlur: ve,
          onCompositionStart: pe,
          onCompositionEnd: me,
          className: (0, U.default)(T == null ? void 0 : T.textarea),
          style: o(
            o({}, D == null ? void 0 : D.textarea),
            {},
            { resize: S == null ? void 0 : S.resize }
          ),
          disabled: C,
          prefixCls: g,
          onResize: Se,
          ref: Y,
          readOnly: M,
        })
      )
    );
  }),
  yt = (e) => {
    let { componentCls: t, paddingLG: n } = e,
      r = `${t}-textarea`;
    return {
      [`textarea${t}`]: {
        maxWidth: `100%`,
        height: `auto`,
        minHeight: e.controlHeight,
        lineHeight: e.lineHeight,
        verticalAlign: `bottom`,
        transition: `all ${e.motionDurationSlow}`,
        resize: `vertical`,
        [`&${t}-mouse-active`]: {
          transition: `all ${e.motionDurationSlow}, height 0s, width 0s`,
        },
      },
      [`${t}-textarea-affix-wrapper-resize-dirty`]: { width: `auto` },
      [r]: {
        position: `relative`,
        "&-show-count": {
          [`${t}-data-count`]: {
            position: `absolute`,
            bottom: e.calc(e.fontSize).mul(e.lineHeight).mul(-1).equal(),
            insetInlineEnd: 0,
            color: e.colorTextDescription,
            whiteSpace: `nowrap`,
            pointerEvents: `none`,
          },
        },
        [`
        &-allow-clear > ${t},
        &-affix-wrapper${r}-has-feedback ${t}
      `]: { paddingInlineEnd: n },
        [`&-affix-wrapper${t}-affix-wrapper`]: {
          padding: 0,
          [`> textarea${t}`]: {
            fontSize: `inherit`,
            border: `none`,
            outline: `none`,
            background: `transparent`,
            minHeight: e
              .calc(e.controlHeight)
              .sub(e.calc(e.lineWidth).mul(2))
              .equal(),
            "&:focus": { boxShadow: `none !important` },
          },
          [`${t}-suffix`]: {
            margin: 0,
            "> *:not(:last-child)": { marginInline: 0 },
            [`${t}-clear-icon`]: {
              position: `absolute`,
              insetInlineEnd: e.paddingInline,
              insetBlockStart: e.paddingXS,
            },
            [`${r}-suffix`]: {
              position: `absolute`,
              top: 0,
              insetInlineEnd: e.paddingInline,
              bottom: 0,
              zIndex: 1,
              display: `inline-flex`,
              alignItems: `center`,
              margin: `auto`,
              pointerEvents: `none`,
            },
          },
        },
        [`&-affix-wrapper${t}-affix-wrapper-rtl`]: {
          [`${t}-suffix`]: {
            [`${t}-data-count`]: { direction: `ltr`, insetInlineStart: 0 },
          },
        },
        [`&-affix-wrapper${t}-affix-wrapper-sm`]: {
          [`${t}-suffix`]: {
            [`${t}-clear-icon`]: { insetInlineEnd: e.paddingInlineSM },
          },
        },
      },
    };
  },
  bt = T([`Input`, `TextArea`], (e) => yt(g(e, K(e))), re, { resetFont: !1 }),
  xt = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  St = (0, H.forwardRef)((e, t) => {
    var n;
    let {
        prefixCls: r,
        bordered: i = !0,
        size: a,
        disabled: o,
        status: s,
        allowClear: c,
        classNames: l,
        rootClassName: u,
        className: d,
        style: f,
        styles: p,
        variant: m,
        showCount: g,
        onMouseDown: _,
        onResize: v,
      } = e,
      b = xt(e, [
        `prefixCls`,
        `bordered`,
        `size`,
        `disabled`,
        `status`,
        `allowClear`,
        `classNames`,
        `rootClassName`,
        `className`,
        `style`,
        `styles`,
        `variant`,
        `showCount`,
        `onMouseDown`,
        `onResize`,
      ]),
      {
        getPrefixCls: x,
        direction: S,
        allowClear: C,
        autoComplete: T,
        className: E,
        style: D,
        classNames: O,
        styles: A,
      } = y(`textArea`),
      j = H.useContext(k),
      M = o ?? j,
      { status: ee, hasFeedback: N, feedbackIcon: P } = H.useContext(F),
      I = W(ee, s),
      L = H.useRef(null);
    H.useImperativeHandle(t, () => {
      var e;
      return {
        resizableTextArea:
          (e = L.current) == null ? void 0 : e.resizableTextArea,
        focus: (e) => {
          var t, n;
          je(
            (n = (t = L.current) == null ? void 0 : t.resizableTextArea) == null
              ? void 0
              : n.textArea,
            e
          );
        },
        blur: () => {
          var e;
          return (e = L.current) == null ? void 0 : e.blur();
        },
      };
    });
    let z = x(`input`, r),
      B = R(z),
      [ne, G, K] = Te(z, u),
      [re] = bt(z, B),
      { compactSize: q, compactItemClassnames: J } = w(z, S),
      Y = h((e) => a ?? q ?? e),
      [X, Z] = V(`textArea`, m, i),
      ie = Le(c ?? C),
      [ae, oe] = H.useState(!1),
      [se, Q] = H.useState(!1),
      ce = (e) => {
        oe(!0), _ == null || _(e);
        let t = () => {
          oe(!1), document.removeEventListener(`mouseup`, t);
        };
        document.addEventListener(`mouseup`, t);
      },
      le = (e) => {
        var t, n;
        if ((v == null || v(e), ae && typeof getComputedStyle == `function`)) {
          let e =
            (n = (t = L.current) == null ? void 0 : t.nativeElement) == null
              ? void 0
              : n.querySelector(`textarea`);
          e && getComputedStyle(e).resize === `both` && Q(!0);
        }
      };
    return ne(
      re(
        H.createElement(
          vt,
          Object.assign({ autoComplete: T }, b, {
            style: Object.assign(Object.assign({}, D), f),
            styles: Object.assign(Object.assign({}, A), p),
            disabled: M,
            allowClear: ie,
            className: (0, U.default)(
              K,
              B,
              d,
              u,
              J,
              E,
              se && `${z}-textarea-affix-wrapper-resize-dirty`
            ),
            classNames: Object.assign(Object.assign(Object.assign({}, l), O), {
              textarea: (0, U.default)(
                { [`${z}-sm`]: Y === `small`, [`${z}-lg`]: Y === `large` },
                G,
                l == null ? void 0 : l.textarea,
                O.textarea,
                ae && `${z}-mouse-active`
              ),
              variant: (0, U.default)({ [`${z}-${X}`]: Z }, te(z, I)),
              affixWrapper: (0, U.default)(
                `${z}-textarea-affix-wrapper`,
                {
                  [`${z}-affix-wrapper-rtl`]: S === `rtl`,
                  [`${z}-affix-wrapper-sm`]: Y === `small`,
                  [`${z}-affix-wrapper-lg`]: Y === `large`,
                  [`${z}-textarea-show-count`]:
                    g || ((n = e.count) == null ? void 0 : n.show),
                },
                G
              ),
            }),
            prefixCls: z,
            suffix:
              N &&
              H.createElement(`span`, { className: `${z}-textarea-suffix` }, P),
            showCount: g,
            ref: L,
            onResize: le,
            onMouseDown: ce,
          })
        )
      )
    );
  }),
  Ct = Ve;
(Ct.Group = We),
  (Ct.Search = ot),
  (Ct.TextArea = St),
  (Ct.Password = it),
  (Ct.OTP = Qe);
export {
  te as C,
  W as S,
  Z as _,
  Me as a,
  K as b,
  ve as c,
  Y as d,
  oe as f,
  ae as g,
  ce as h,
  Ve as i,
  ge as l,
  ue as m,
  St as n,
  je as o,
  J as p,
  Ue as r,
  _e as s,
  Ct as t,
  me as u,
  pe as v,
  G as x,
  re as y,
};
