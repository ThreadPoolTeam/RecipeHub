import {
  c as e,
  n as t,
  s as n,
  t as r,
} from "./assertThisInitialized-DqpgQyeg.js";
import { t as i } from "./wrapNativeSuper-BsdumfAK.js";
import { n as a, t as o } from "./inheritsLoose-BimZ4dLJ.js";
e(), t(), a();
var s = (function (e) {
  o(t, e);
  function t(t) {
    var n =
      e.call(
        this,
        `An error occurred. See https://github.com/styled-components/polished/blob/main/src/internalHelpers/errors.md#` +
          t +
          ` for more information.`
      ) || this;
    return r(n);
  }
  return t;
})(i(Error));
function c(e) {
  return Math.round(e * 255);
}
function l(e, t, n) {
  return c(e) + `,` + c(t) + `,` + c(n);
}
function u(e, t, n, r) {
  if ((r === void 0 && (r = l), t === 0)) return r(n, n, n);
  var i = (((e % 360) + 360) % 360) / 60,
    a = (1 - Math.abs(2 * n - 1)) * t,
    o = a * (1 - Math.abs((i % 2) - 1)),
    s = 0,
    c = 0,
    u = 0;
  i >= 0 && i < 1
    ? ((s = a), (c = o))
    : i >= 1 && i < 2
    ? ((s = o), (c = a))
    : i >= 2 && i < 3
    ? ((c = a), (u = o))
    : i >= 3 && i < 4
    ? ((c = o), (u = a))
    : i >= 4 && i < 5
    ? ((s = o), (u = a))
    : i >= 5 && i < 6 && ((s = a), (u = o));
  var d = n - a / 2,
    f = s + d,
    p = c + d,
    m = u + d;
  return r(f, p, m);
}
var d = {
  aliceblue: `f0f8ff`,
  antiquewhite: `faebd7`,
  aqua: `00ffff`,
  aquamarine: `7fffd4`,
  azure: `f0ffff`,
  beige: `f5f5dc`,
  bisque: `ffe4c4`,
  black: `000`,
  blanchedalmond: `ffebcd`,
  blue: `0000ff`,
  blueviolet: `8a2be2`,
  brown: `a52a2a`,
  burlywood: `deb887`,
  cadetblue: `5f9ea0`,
  chartreuse: `7fff00`,
  chocolate: `d2691e`,
  coral: `ff7f50`,
  cornflowerblue: `6495ed`,
  cornsilk: `fff8dc`,
  crimson: `dc143c`,
  cyan: `00ffff`,
  darkblue: `00008b`,
  darkcyan: `008b8b`,
  darkgoldenrod: `b8860b`,
  darkgray: `a9a9a9`,
  darkgreen: `006400`,
  darkgrey: `a9a9a9`,
  darkkhaki: `bdb76b`,
  darkmagenta: `8b008b`,
  darkolivegreen: `556b2f`,
  darkorange: `ff8c00`,
  darkorchid: `9932cc`,
  darkred: `8b0000`,
  darksalmon: `e9967a`,
  darkseagreen: `8fbc8f`,
  darkslateblue: `483d8b`,
  darkslategray: `2f4f4f`,
  darkslategrey: `2f4f4f`,
  darkturquoise: `00ced1`,
  darkviolet: `9400d3`,
  deeppink: `ff1493`,
  deepskyblue: `00bfff`,
  dimgray: `696969`,
  dimgrey: `696969`,
  dodgerblue: `1e90ff`,
  firebrick: `b22222`,
  floralwhite: `fffaf0`,
  forestgreen: `228b22`,
  fuchsia: `ff00ff`,
  gainsboro: `dcdcdc`,
  ghostwhite: `f8f8ff`,
  gold: `ffd700`,
  goldenrod: `daa520`,
  gray: `808080`,
  green: `008000`,
  greenyellow: `adff2f`,
  grey: `808080`,
  honeydew: `f0fff0`,
  hotpink: `ff69b4`,
  indianred: `cd5c5c`,
  indigo: `4b0082`,
  ivory: `fffff0`,
  khaki: `f0e68c`,
  lavender: `e6e6fa`,
  lavenderblush: `fff0f5`,
  lawngreen: `7cfc00`,
  lemonchiffon: `fffacd`,
  lightblue: `add8e6`,
  lightcoral: `f08080`,
  lightcyan: `e0ffff`,
  lightgoldenrodyellow: `fafad2`,
  lightgray: `d3d3d3`,
  lightgreen: `90ee90`,
  lightgrey: `d3d3d3`,
  lightpink: `ffb6c1`,
  lightsalmon: `ffa07a`,
  lightseagreen: `20b2aa`,
  lightskyblue: `87cefa`,
  lightslategray: `789`,
  lightslategrey: `789`,
  lightsteelblue: `b0c4de`,
  lightyellow: `ffffe0`,
  lime: `0f0`,
  limegreen: `32cd32`,
  linen: `faf0e6`,
  magenta: `f0f`,
  maroon: `800000`,
  mediumaquamarine: `66cdaa`,
  mediumblue: `0000cd`,
  mediumorchid: `ba55d3`,
  mediumpurple: `9370db`,
  mediumseagreen: `3cb371`,
  mediumslateblue: `7b68ee`,
  mediumspringgreen: `00fa9a`,
  mediumturquoise: `48d1cc`,
  mediumvioletred: `c71585`,
  midnightblue: `191970`,
  mintcream: `f5fffa`,
  mistyrose: `ffe4e1`,
  moccasin: `ffe4b5`,
  navajowhite: `ffdead`,
  navy: `000080`,
  oldlace: `fdf5e6`,
  olive: `808000`,
  olivedrab: `6b8e23`,
  orange: `ffa500`,
  orangered: `ff4500`,
  orchid: `da70d6`,
  palegoldenrod: `eee8aa`,
  palegreen: `98fb98`,
  paleturquoise: `afeeee`,
  palevioletred: `db7093`,
  papayawhip: `ffefd5`,
  peachpuff: `ffdab9`,
  peru: `cd853f`,
  pink: `ffc0cb`,
  plum: `dda0dd`,
  powderblue: `b0e0e6`,
  purple: `800080`,
  rebeccapurple: `639`,
  red: `f00`,
  rosybrown: `bc8f8f`,
  royalblue: `4169e1`,
  saddlebrown: `8b4513`,
  salmon: `fa8072`,
  sandybrown: `f4a460`,
  seagreen: `2e8b57`,
  seashell: `fff5ee`,
  sienna: `a0522d`,
  silver: `c0c0c0`,
  skyblue: `87ceeb`,
  slateblue: `6a5acd`,
  slategray: `708090`,
  slategrey: `708090`,
  snow: `fffafa`,
  springgreen: `00ff7f`,
  steelblue: `4682b4`,
  tan: `d2b48c`,
  teal: `008080`,
  thistle: `d8bfd8`,
  tomato: `ff6347`,
  turquoise: `40e0d0`,
  violet: `ee82ee`,
  wheat: `f5deb3`,
  white: `fff`,
  whitesmoke: `f5f5f5`,
  yellow: `ff0`,
  yellowgreen: `9acd32`,
};
function f(e) {
  if (typeof e != `string`) return e;
  var t = e.toLowerCase();
  return d[t] ? `#` + d[t] : e;
}
var p = /^#[a-fA-F0-9]{6}$/,
  m = /^#[a-fA-F0-9]{8}$/,
  h = /^#[a-fA-F0-9]{3}$/,
  g = /^#[a-fA-F0-9]{4}$/,
  _ = /^rgb\(\s*(\d{1,3})\s*(?:,)?\s*(\d{1,3})\s*(?:,)?\s*(\d{1,3})\s*\)$/i,
  v =
    /^rgb(?:a)?\(\s*(\d{1,3})\s*(?:,)?\s*(\d{1,3})\s*(?:,)?\s*(\d{1,3})\s*(?:,|\/)\s*([-+]?\d*[.]?\d+[%]?)\s*\)$/i,
  y =
    /^hsl\(\s*(\d{0,3}[.]?[0-9]+(?:deg)?)\s*(?:,)?\s*(\d{1,3}[.]?[0-9]?)%\s*(?:,)?\s*(\d{1,3}[.]?[0-9]?)%\s*\)$/i,
  b =
    /^hsl(?:a)?\(\s*(\d{0,3}[.]?[0-9]+(?:deg)?)\s*(?:,)?\s*(\d{1,3}[.]?[0-9]?)%\s*(?:,)?\s*(\d{1,3}[.]?[0-9]?)%\s*(?:,|\/)\s*([-+]?\d*[.]?\d+[%]?)\s*\)$/i;
function x(e) {
  if (typeof e != `string`) throw new s(3);
  var t = f(e);
  if (t.match(p))
    return {
      red: parseInt(`` + t[1] + t[2], 16),
      green: parseInt(`` + t[3] + t[4], 16),
      blue: parseInt(`` + t[5] + t[6], 16),
    };
  if (t.match(m)) {
    var n = parseFloat((parseInt(`` + t[7] + t[8], 16) / 255).toFixed(2));
    return {
      red: parseInt(`` + t[1] + t[2], 16),
      green: parseInt(`` + t[3] + t[4], 16),
      blue: parseInt(`` + t[5] + t[6], 16),
      alpha: n,
    };
  }
  if (t.match(h))
    return {
      red: parseInt(`` + t[1] + t[1], 16),
      green: parseInt(`` + t[2] + t[2], 16),
      blue: parseInt(`` + t[3] + t[3], 16),
    };
  if (t.match(g)) {
    var r = parseFloat((parseInt(`` + t[4] + t[4], 16) / 255).toFixed(2));
    return {
      red: parseInt(`` + t[1] + t[1], 16),
      green: parseInt(`` + t[2] + t[2], 16),
      blue: parseInt(`` + t[3] + t[3], 16),
      alpha: r,
    };
  }
  var i = _.exec(t);
  if (i)
    return {
      red: parseInt(`` + i[1], 10),
      green: parseInt(`` + i[2], 10),
      blue: parseInt(`` + i[3], 10),
    };
  var a = v.exec(t.substring(0, 50));
  if (a)
    return {
      red: parseInt(`` + a[1], 10),
      green: parseInt(`` + a[2], 10),
      blue: parseInt(`` + a[3], 10),
      alpha:
        parseFloat(`` + a[4]) > 1
          ? parseFloat(`` + a[4]) / 100
          : parseFloat(`` + a[4]),
    };
  var o = y.exec(t);
  if (o) {
    var c =
        `rgb(` +
        u(
          parseInt(`` + o[1], 10),
          parseInt(`` + o[2], 10) / 100,
          parseInt(`` + o[3], 10) / 100
        ) +
        `)`,
      l = _.exec(c);
    if (!l) throw new s(4, t, c);
    return {
      red: parseInt(`` + l[1], 10),
      green: parseInt(`` + l[2], 10),
      blue: parseInt(`` + l[3], 10),
    };
  }
  var d = b.exec(t.substring(0, 50));
  if (d) {
    var x =
        `rgb(` +
        u(
          parseInt(`` + d[1], 10),
          parseInt(`` + d[2], 10) / 100,
          parseInt(`` + d[3], 10) / 100
        ) +
        `)`,
      S = _.exec(x);
    if (!S) throw new s(4, t, x);
    return {
      red: parseInt(`` + S[1], 10),
      green: parseInt(`` + S[2], 10),
      blue: parseInt(`` + S[3], 10),
      alpha:
        parseFloat(`` + d[4]) > 1
          ? parseFloat(`` + d[4]) / 100
          : parseFloat(`` + d[4]),
    };
  }
  throw new s(5);
}
function S(e) {
  var t = e.red / 255,
    n = e.green / 255,
    r = e.blue / 255,
    i = Math.max(t, n, r),
    a = Math.min(t, n, r),
    o = (i + a) / 2;
  if (i === a)
    return e.alpha === void 0
      ? { hue: 0, saturation: 0, lightness: o }
      : { hue: 0, saturation: 0, lightness: o, alpha: e.alpha };
  var s,
    c = i - a,
    l = o > 0.5 ? c / (2 - i - a) : c / (i + a);
  switch (i) {
    case t:
      s = (n - r) / c + (n < r ? 6 : 0);
      break;
    case n:
      s = (r - t) / c + 2;
      break;
    default:
      s = (t - n) / c + 4;
  }
  return (
    (s *= 60),
    e.alpha === void 0
      ? { hue: s, saturation: l, lightness: o }
      : { hue: s, saturation: l, lightness: o, alpha: e.alpha }
  );
}
function C(e) {
  return S(x(e));
}
var w = function (e) {
  return e.length === 7 && e[1] === e[2] && e[3] === e[4] && e[5] === e[6]
    ? `#` + e[1] + e[3] + e[5]
    : e;
};
function T(e) {
  var t = e.toString(16);
  return t.length === 1 ? `0` + t : t;
}
function E(e) {
  return T(Math.round(e * 255));
}
function D(e, t, n) {
  return w(`#` + E(e) + E(t) + E(n));
}
function O(e, t, n) {
  return u(e, t, n, D);
}
function k(e, t, n) {
  if (typeof e == `number` && typeof t == `number` && typeof n == `number`)
    return O(e, t, n);
  if (typeof e == `object` && t === void 0 && n === void 0)
    return O(e.hue, e.saturation, e.lightness);
  throw new s(1);
}
function A(e, t, n, r) {
  if (
    typeof e == `number` &&
    typeof t == `number` &&
    typeof n == `number` &&
    typeof r == `number`
  )
    return r >= 1 ? O(e, t, n) : `rgba(` + u(e, t, n) + `,` + r + `)`;
  if (typeof e == `object` && t === void 0 && n === void 0 && r === void 0)
    return e.alpha >= 1
      ? O(e.hue, e.saturation, e.lightness)
      : `rgba(` + u(e.hue, e.saturation, e.lightness) + `,` + e.alpha + `)`;
  throw new s(2);
}
function j(e, t, n) {
  if (typeof e == `number` && typeof t == `number` && typeof n == `number`)
    return w(`#` + T(e) + T(t) + T(n));
  if (typeof e == `object` && t === void 0 && n === void 0)
    return w(`#` + T(e.red) + T(e.green) + T(e.blue));
  throw new s(6);
}
function M(e, t, n, r) {
  if (typeof e == `string` && typeof t == `number`) {
    var i = x(e);
    return `rgba(` + i.red + `,` + i.green + `,` + i.blue + `,` + t + `)`;
  }
  if (
    typeof e == `number` &&
    typeof t == `number` &&
    typeof n == `number` &&
    typeof r == `number`
  )
    return r >= 1
      ? j(e, t, n)
      : `rgba(` + e + `,` + t + `,` + n + `,` + r + `)`;
  if (typeof e == `object` && t === void 0 && n === void 0 && r === void 0)
    return e.alpha >= 1
      ? j(e.red, e.green, e.blue)
      : `rgba(` + e.red + `,` + e.green + `,` + e.blue + `,` + e.alpha + `)`;
  throw new s(7);
}
var N = function (e) {
    return (
      typeof e.red == `number` &&
      typeof e.green == `number` &&
      typeof e.blue == `number` &&
      (typeof e.alpha != `number` || e.alpha === void 0)
    );
  },
  P = function (e) {
    return (
      typeof e.red == `number` &&
      typeof e.green == `number` &&
      typeof e.blue == `number` &&
      typeof e.alpha == `number`
    );
  },
  F = function (e) {
    return (
      typeof e.hue == `number` &&
      typeof e.saturation == `number` &&
      typeof e.lightness == `number` &&
      (typeof e.alpha != `number` || e.alpha === void 0)
    );
  },
  I = function (e) {
    return (
      typeof e.hue == `number` &&
      typeof e.saturation == `number` &&
      typeof e.lightness == `number` &&
      typeof e.alpha == `number`
    );
  };
function L(e) {
  if (typeof e != `object`) throw new s(8);
  if (P(e)) return M(e);
  if (N(e)) return j(e);
  if (I(e)) return A(e);
  if (F(e)) return k(e);
  throw new s(8);
}
function R(e, t, n) {
  return function () {
    var r = n.concat(Array.prototype.slice.call(arguments));
    return r.length >= t ? e.apply(this, r) : R(e, t, r);
  };
}
function z(e) {
  return R(e, e.length, []);
}
function B(e, t) {
  if (t === `transparent`) return t;
  var r = C(t);
  return L(n({}, r, { hue: r.hue + parseFloat(e) }));
}
z(B);
function V(e, t, n) {
  return Math.max(e, Math.min(t, n));
}
function H(e, t) {
  if (t === `transparent`) return t;
  var r = C(t);
  return L(n({}, r, { lightness: V(0, 1, r.lightness - parseFloat(e)) }));
}
var U = z(H);
function W(e, t) {
  if (t === `transparent`) return t;
  var r = C(t);
  return L(n({}, r, { saturation: V(0, 1, r.saturation - parseFloat(e)) }));
}
z(W);
function G(e, t) {
  if (t === `transparent`) return t;
  var r = C(t);
  return L(n({}, r, { lightness: V(0, 1, r.lightness + parseFloat(e)) }));
}
var K = z(G);
function q(e, t, r) {
  if (t === `transparent`) return r;
  if (r === `transparent`) return t;
  if (e === 0) return r;
  var i = x(t),
    a = n({}, i, { alpha: typeof i.alpha == `number` ? i.alpha : 1 }),
    o = x(r),
    s = n({}, o, { alpha: typeof o.alpha == `number` ? o.alpha : 1 }),
    c = a.alpha - s.alpha,
    l = parseFloat(e) * 2 - 1,
    u = ((l * c === -1 ? l : l + c) / (1 + l * c) + 1) / 2,
    d = 1 - u;
  return M({
    red: Math.floor(a.red * u + s.red * d),
    green: Math.floor(a.green * u + s.green * d),
    blue: Math.floor(a.blue * u + s.blue * d),
    alpha: a.alpha * parseFloat(e) + s.alpha * (1 - parseFloat(e)),
  });
}
var J = z(q);
function Y(e, t) {
  if (t === `transparent`) return t;
  var r = x(t),
    i = typeof r.alpha == `number` ? r.alpha : 1;
  return M(n({}, r, { alpha: V(0, 1, (i * 100 + parseFloat(e) * 100) / 100) }));
}
z(Y);
function X(e) {
  if (
    typeof e == `object` &&
    typeof e.red == `number` &&
    typeof e.green == `number` &&
    typeof e.blue == `number`
  )
    return typeof e.alpha == `number`
      ? M({ red: e.red, green: e.green, blue: e.blue, alpha: e.alpha })
      : j({ red: e.red, green: e.green, blue: e.blue });
  throw new s(46);
}
function Z(e, t) {
  if (t === `transparent`) return t;
  var r = C(t);
  return L(n({}, r, { saturation: V(0, 1, r.saturation + parseFloat(e)) }));
}
z(Z);
function Q(e, t) {
  return t === `transparent` ? t : L(n({}, C(t), { hue: parseFloat(e) }));
}
z(Q);
function $(e, t) {
  return t === `transparent` ? t : L(n({}, C(t), { lightness: parseFloat(e) }));
}
z($);
function ee(e, t) {
  return t === `transparent`
    ? t
    : L(n({}, C(t), { saturation: parseFloat(e) }));
}
z(ee);
function te(e, t) {
  return t === `transparent` ? t : J(parseFloat(e), `rgb(0, 0, 0)`, t);
}
z(te);
function ne(e, t) {
  return t === `transparent` ? t : J(parseFloat(e), `rgb(255, 255, 255)`, t);
}
z(ne);
function re(e, t) {
  if (t === `transparent`) return t;
  var r = x(t),
    i = typeof r.alpha == `number` ? r.alpha : 1;
  return M(
    n({}, r, {
      alpha: V(0, 1, (i * 100 - parseFloat(e) * 100).toFixed(2) / 100),
    })
  );
}
z(re);
export { M as i, K as n, X as r, U as t };
