import { _ as e, g as t } from "./utils-CV9JYz4f.js";
import { D as n, N as r } from "./Paths-3vkx8h28.js";
import { i } from "./index-DG2EaUNY.js";
import { t as a } from "./NavigateTo-CWRFhxPL.js";
var o = () => (t() ? (e() ? n : r) : `/`),
  s = () => {
    a(o());
  },
  c = () => {
    i.replace(o());
  };
export { s as n, c as r, o as t };
