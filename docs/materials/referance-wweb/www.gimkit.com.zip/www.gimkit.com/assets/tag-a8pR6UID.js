import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  E as n,
  H as r,
  Ut as i,
  X as a,
  b as o,
  c as s,
  m as c,
  s as l,
} from "./Compact-CRRKXVA1.js";
import { i as u, l as d } from "./color-Dzrzfp-h.js";
import { n as f, r as p, u as m } from "./tooltip-Yg3f8G0Q.js";
import { o as h, s as g } from "./modal-Ch5Fwjpt.js";
import { r as _ } from "./button-Cpfts2Ff.js";
var v = e(t()),
  y = e(i()),
  b = (e) => {
    let {
        paddingXXS: t,
        lineWidth: n,
        tagPaddingHorizontal: r,
        componentCls: i,
        calc: o,
      } = e,
      s = o(r).sub(n).equal(),
      l = o(t).sub(n).equal();
    return {
      [i]: Object.assign(Object.assign({}, c(e)), {
        display: `inline-block`,
        height: `auto`,
        marginInlineEnd: e.marginXS,
        paddingInline: s,
        fontSize: e.tagFontSize,
        lineHeight: e.tagLineHeight,
        whiteSpace: `nowrap`,
        background: e.defaultBg,
        border: `${a(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
        borderRadius: e.borderRadiusSM,
        opacity: 1,
        transition: `all ${e.motionDurationMid}`,
        textAlign: `start`,
        position: `relative`,
        [`&${i}-rtl`]: { direction: `rtl` },
        "&, a, a:hover": { color: e.defaultColor },
        [`${i}-close-icon`]: {
          marginInlineStart: l,
          fontSize: e.tagIconSize,
          color: e.colorIcon,
          cursor: `pointer`,
          transition: `all ${e.motionDurationMid}`,
          "&:hover": { color: e.colorTextHeading },
        },
        [`&${i}-has-color`]: {
          borderColor: `transparent`,
          [`&, a, a:hover, ${e.iconCls}-close, ${e.iconCls}-close:hover`]: {
            color: e.colorTextLightSolid,
          },
        },
        "&-checkable": {
          backgroundColor: `transparent`,
          borderColor: `transparent`,
          cursor: `pointer`,
          [`&:not(${i}-checkable-checked):hover`]: {
            color: e.colorPrimary,
            backgroundColor: e.colorFillSecondary,
          },
          "&:active, &-checked": { color: e.colorTextLightSolid },
          "&-checked": {
            backgroundColor: e.colorPrimary,
            "&:hover": { backgroundColor: e.colorPrimaryHover },
          },
          "&:active": { backgroundColor: e.colorPrimaryActive },
        },
        "&-hidden": { display: `none` },
        [`> ${e.iconCls} + span, > span + ${e.iconCls}`]: {
          marginInlineStart: s,
        },
      }),
      [`${i}-borderless`]: {
        borderColor: `transparent`,
        background: e.tagBorderlessBg,
      },
    };
  },
  x = (e) => {
    let { lineWidth: t, fontSizeIcon: n, calc: r } = e,
      i = e.fontSizeSM;
    return o(e, {
      tagFontSize: i,
      tagLineHeight: a(r(e.lineHeightSM).mul(i).equal()),
      tagIconSize: r(n).sub(r(t).mul(2)).equal(),
      tagPaddingHorizontal: 8,
      tagBorderlessBg: e.defaultBg,
    });
  },
  S = (e) => ({
    defaultBg: new r(e.colorFillQuaternary)
      .onBackground(e.colorBgContainer)
      .toHexString(),
    defaultColor: e.colorText,
  }),
  C = l(`Tag`, (e) => b(x(e)), S),
  w = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  T = v.forwardRef((e, t) => {
    let {
        prefixCls: r,
        style: i,
        className: a,
        checked: o,
        children: s,
        icon: c,
        onChange: l,
        onClick: u,
      } = e,
      d = w(e, [
        `prefixCls`,
        `style`,
        `className`,
        `checked`,
        `children`,
        `icon`,
        `onChange`,
        `onClick`,
      ]),
      { getPrefixCls: f, tag: p } = v.useContext(n),
      m = (e) => {
        l == null || l(!o), u == null || u(e);
      },
      h = f(`tag`, r),
      [g, _, b] = C(h),
      x = (0, y.default)(
        h,
        `${h}-checkable`,
        { [`${h}-checkable-checked`]: o },
        p == null ? void 0 : p.className,
        a,
        _,
        b
      );
    return g(
      v.createElement(
        `span`,
        Object.assign({}, d, {
          ref: t,
          style: Object.assign(
            Object.assign({}, i),
            p == null ? void 0 : p.style
          ),
          className: x,
          onClick: m,
        }),
        c,
        v.createElement(`span`, null, s)
      )
    );
  }),
  E = (e) =>
    m(
      e,
      (
        t,
        { textColor: n, lightBorderColor: r, lightColor: i, darkColor: a }
      ) => ({
        [`${e.componentCls}${e.componentCls}-${t}`]: {
          color: n,
          background: i,
          borderColor: r,
          "&-inverse": {
            color: e.colorTextLightSolid,
            background: a,
            borderColor: a,
          },
          [`&${e.componentCls}-borderless`]: { borderColor: `transparent` },
        },
      })
    ),
  D = s([`Tag`, `preset`], (e) => E(x(e)), S);
function O(e) {
  return typeof e == `string` ? e.charAt(0).toUpperCase() + e.slice(1) : e;
}
var k = (e, t, n) => {
    let r = O(n);
    return {
      [`${e.componentCls}${e.componentCls}-${t}`]: {
        color: e[`color${n}`],
        background: e[`color${r}Bg`],
        borderColor: e[`color${r}Border`],
        [`&${e.componentCls}-borderless`]: { borderColor: `transparent` },
      },
    };
  },
  A = s(
    [`Tag`, `status`],
    (e) => {
      let t = x(e);
      return [
        k(t, `success`, `Success`),
        k(t, `processing`, `Info`),
        k(t, `error`, `Error`),
        k(t, `warning`, `Warning`),
      ];
    },
    S
  ),
  j = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  M = v.forwardRef((e, t) => {
    let {
        prefixCls: r,
        className: i,
        rootClassName: a,
        style: o,
        children: s,
        icon: c,
        color: l,
        onClose: m,
        bordered: b = !0,
        visible: x,
      } = e,
      S = j(e, [
        `prefixCls`,
        `className`,
        `rootClassName`,
        `style`,
        `children`,
        `icon`,
        `color`,
        `onClose`,
        `bordered`,
        `visible`,
      ]),
      { getPrefixCls: w, direction: T, tag: E } = v.useContext(n),
      [O, k] = v.useState(!0),
      M = u(S, [`closeIcon`, `closable`]);
    v.useEffect(() => {
      x !== void 0 && k(x);
    }, [x]);
    let N = f(l),
      P = p(l),
      F = N || P,
      I = Object.assign(
        Object.assign(
          { backgroundColor: l && !F ? l : void 0 },
          E == null ? void 0 : E.style
        ),
        o
      ),
      L = w(`tag`, r),
      [R, z, B] = C(L),
      V = (0, y.default)(
        L,
        E == null ? void 0 : E.className,
        {
          [`${L}-${l}`]: F,
          [`${L}-has-color`]: l && !F,
          [`${L}-hidden`]: !O,
          [`${L}-rtl`]: T === `rtl`,
          [`${L}-borderless`]: !b,
        },
        i,
        a,
        z,
        B
      ),
      H = (e) => {
        e.stopPropagation(), m == null || m(e), !e.defaultPrevented && k(!1);
      },
      [, U] = g(h(e), h(E), {
        closable: !1,
        closeIconRender: (e) => {
          let t = v.createElement(
            `span`,
            { className: `${L}-close-icon`, onClick: H },
            e
          );
          return d(e, t, (e) => ({
            onClick: (t) => {
              var n;
              (n = e == null ? void 0 : e.onClick) == null || n.call(e, t),
                H(t);
            },
            className: (0, y.default)(
              e == null ? void 0 : e.className,
              `${L}-close-icon`
            ),
          }));
        },
      }),
      W = typeof S.onClick == `function` || (s && s.type === `a`),
      G = c || null,
      K = G
        ? v.createElement(
            v.Fragment,
            null,
            G,
            s && v.createElement(`span`, null, s)
          )
        : s,
      q = v.createElement(
        `span`,
        Object.assign({}, M, { ref: t, className: V, style: I }),
        K,
        U,
        N && v.createElement(D, { key: `preset`, prefixCls: L }),
        P && v.createElement(A, { key: `status`, prefixCls: L })
      );
    return R(W ? v.createElement(_, { component: `Tag` }, q) : q);
  });
M.CheckableTag = T;
export { M as t };
