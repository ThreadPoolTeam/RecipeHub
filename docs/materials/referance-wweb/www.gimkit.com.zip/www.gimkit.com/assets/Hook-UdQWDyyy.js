var e = (function (e) {
  return (e.selectBox = `selectBox`), (e.kit = `kit`), (e.number = `number`), e;
})({});
export { e as t };
