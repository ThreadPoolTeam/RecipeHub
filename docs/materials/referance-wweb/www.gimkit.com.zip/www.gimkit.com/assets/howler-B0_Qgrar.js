import { t as e } from "./rolldown-runtime-C0FnF6B9.js";
import { n as t, t as n } from "./dist-Cmw-iXzl.js";
var r = e((e) => {
  t(),
    (function () {
      var t = function () {
        this.init();
      };
      t.prototype = {
        init: function () {
          var e = this || r;
          return (
            (e._counter = 1e3),
            (e._html5AudioPool = []),
            (e.html5PoolSize = 10),
            (e._codecs = {}),
            (e._howls = []),
            (e._muted = !1),
            (e._volume = 1),
            (e._canPlayEvent = `canplaythrough`),
            (e._navigator =
              typeof window < `u` && window.navigator
                ? window.navigator
                : null),
            (e.masterGain = null),
            (e.noAudio = !1),
            (e.usingWebAudio = !0),
            (e.autoSuspend = !0),
            (e.ctx = null),
            (e.autoUnlock = !0),
            e._setup(),
            e
          );
        },
        volume: function (e) {
          var t = this || r;
          if (
            ((e = parseFloat(e)),
            t.ctx || d(),
            e !== void 0 && e >= 0 && e <= 1)
          ) {
            if (((t._volume = e), t._muted)) return t;
            t.usingWebAudio &&
              t.masterGain.gain.setValueAtTime(e, r.ctx.currentTime);
            for (var n = 0; n < t._howls.length; n++)
              if (!t._howls[n]._webAudio)
                for (
                  var i = t._howls[n]._getSoundIds(), a = 0;
                  a < i.length;
                  a++
                ) {
                  var o = t._howls[n]._soundById(i[a]);
                  o && o._node && (o._node.volume = o._volume * e);
                }
            return t;
          }
          return t._volume;
        },
        mute: function (e) {
          var t = this || r;
          t.ctx || d(),
            (t._muted = e),
            t.usingWebAudio &&
              t.masterGain.gain.setValueAtTime(
                e ? 0 : t._volume,
                r.ctx.currentTime
              );
          for (var n = 0; n < t._howls.length; n++)
            if (!t._howls[n]._webAudio)
              for (
                var i = t._howls[n]._getSoundIds(), a = 0;
                a < i.length;
                a++
              ) {
                var o = t._howls[n]._soundById(i[a]);
                o && o._node && (o._node.muted = e ? !0 : o._muted);
              }
          return t;
        },
        stop: function () {
          for (var e = this || r, t = 0; t < e._howls.length; t++)
            e._howls[t].stop();
          return e;
        },
        unload: function () {
          for (var e = this || r, t = e._howls.length - 1; t >= 0; t--)
            e._howls[t].unload();
          return (
            e.usingWebAudio &&
              e.ctx &&
              e.ctx.close !== void 0 &&
              (e.ctx.close(), (e.ctx = null), d()),
            e
          );
        },
        codecs: function (e) {
          return (this || r)._codecs[e.replace(/^x-/, ``)];
        },
        _setup: function () {
          var e = this || r;
          if (
            ((e.state = (e.ctx && e.ctx.state) || `suspended`),
            e._autoSuspend(),
            !e.usingWebAudio)
          ) {
            if (typeof Audio < `u`)
              try {
                var t = new Audio();
                t.oncanplaythrough === void 0 && (e._canPlayEvent = `canplay`);
              } catch {
                e.noAudio = !0;
              }
            else e.noAudio = !0;
          }
          try {
            var t = new Audio();
            t.muted && (e.noAudio = !0);
          } catch {}
          return e.noAudio || e._setupCodecs(), e;
        },
        _setupCodecs: function () {
          var e = this || r,
            t = null;
          try {
            t = typeof Audio < `u` ? new Audio() : null;
          } catch {
            return e;
          }
          if (!t || typeof t.canPlayType != `function`) return e;
          var n = t.canPlayType(`audio/mpeg;`).replace(/^no$/, ``),
            i = e._navigator ? e._navigator.userAgent : ``,
            a = i.match(/OPR\/(\d+)/g),
            o = a && parseInt(a[0].split(`/`)[1], 10) < 33,
            s = i.indexOf(`Safari`) !== -1 && i.indexOf(`Chrome`) === -1,
            c = i.match(/Version\/(.*?) /),
            l = s && c && parseInt(c[1], 10) < 15;
          return (
            (e._codecs = {
              mp3: !(
                o ||
                (!n && !t.canPlayType(`audio/mp3;`).replace(/^no$/, ``))
              ),
              mpeg: !!n,
              opus: !!t
                .canPlayType(`audio/ogg; codecs="opus"`)
                .replace(/^no$/, ``),
              ogg: !!t
                .canPlayType(`audio/ogg; codecs="vorbis"`)
                .replace(/^no$/, ``),
              oga: !!t
                .canPlayType(`audio/ogg; codecs="vorbis"`)
                .replace(/^no$/, ``),
              wav: !!(
                t.canPlayType(`audio/wav; codecs="1"`) ||
                t.canPlayType(`audio/wav`)
              ).replace(/^no$/, ``),
              aac: !!t.canPlayType(`audio/aac;`).replace(/^no$/, ``),
              caf: !!t.canPlayType(`audio/x-caf;`).replace(/^no$/, ``),
              m4a: !!(
                t.canPlayType(`audio/x-m4a;`) ||
                t.canPlayType(`audio/m4a;`) ||
                t.canPlayType(`audio/aac;`)
              ).replace(/^no$/, ``),
              m4b: !!(
                t.canPlayType(`audio/x-m4b;`) ||
                t.canPlayType(`audio/m4b;`) ||
                t.canPlayType(`audio/aac;`)
              ).replace(/^no$/, ``),
              mp4: !!(
                t.canPlayType(`audio/x-mp4;`) ||
                t.canPlayType(`audio/mp4;`) ||
                t.canPlayType(`audio/aac;`)
              ).replace(/^no$/, ``),
              weba: !(
                l ||
                !t
                  .canPlayType(`audio/webm; codecs="vorbis"`)
                  .replace(/^no$/, ``)
              ),
              webm: !(
                l ||
                !t
                  .canPlayType(`audio/webm; codecs="vorbis"`)
                  .replace(/^no$/, ``)
              ),
              dolby: !!t
                .canPlayType(`audio/mp4; codecs="ec-3"`)
                .replace(/^no$/, ``),
              flac: !!(
                t.canPlayType(`audio/x-flac;`) || t.canPlayType(`audio/flac;`)
              ).replace(/^no$/, ``),
            }),
            e
          );
        },
        _unlockAudio: function () {
          var e = this || r;
          if (!e._audioUnlocked && e.ctx) {
            (e._audioUnlocked = !1),
              (e.autoUnlock = !1),
              !e._mobileUnloaded &&
                e.ctx.sampleRate !== 44100 &&
                ((e._mobileUnloaded = !0), e.unload()),
              (e._scratchBuffer = e.ctx.createBuffer(1, 1, 22050));
            var t = function (n) {
              for (; e._html5AudioPool.length < e.html5PoolSize; )
                try {
                  var r = new Audio();
                  (r._unlocked = !0), e._releaseHtml5Audio(r);
                } catch {
                  e.noAudio = !0;
                  break;
                }
              for (var i = 0; i < e._howls.length; i++)
                if (!e._howls[i]._webAudio)
                  for (
                    var a = e._howls[i]._getSoundIds(), o = 0;
                    o < a.length;
                    o++
                  ) {
                    var s = e._howls[i]._soundById(a[o]);
                    s &&
                      s._node &&
                      !s._node._unlocked &&
                      ((s._node._unlocked = !0), s._node.load());
                  }
              e._autoResume();
              var c = e.ctx.createBufferSource();
              (c.buffer = e._scratchBuffer),
                c.connect(e.ctx.destination),
                c.start === void 0 ? c.noteOn(0) : c.start(0),
                typeof e.ctx.resume == `function` && e.ctx.resume(),
                (c.onended = function () {
                  c.disconnect(0),
                    (e._audioUnlocked = !0),
                    document.removeEventListener(`touchstart`, t, !0),
                    document.removeEventListener(`touchend`, t, !0),
                    document.removeEventListener(`click`, t, !0),
                    document.removeEventListener(`keydown`, t, !0);
                  for (var n = 0; n < e._howls.length; n++)
                    e._howls[n]._emit(`unlock`);
                });
            };
            return (
              document.addEventListener(`touchstart`, t, !0),
              document.addEventListener(`touchend`, t, !0),
              document.addEventListener(`click`, t, !0),
              document.addEventListener(`keydown`, t, !0),
              e
            );
          }
        },
        _obtainHtml5Audio: function () {
          var e = this || r;
          if (e._html5AudioPool.length) return e._html5AudioPool.pop();
          var t = new Audio().play();
          return (
            t &&
              typeof Promise < `u` &&
              (t instanceof Promise || typeof t.then == `function`) &&
              t.catch(function () {
                console.warn(
                  `HTML5 Audio pool exhausted, returning potentially locked audio object.`
                );
              }),
            new Audio()
          );
        },
        _releaseHtml5Audio: function (e) {
          var t = this || r;
          return e._unlocked && t._html5AudioPool.push(e), t;
        },
        _autoSuspend: function () {
          var e = this;
          if (
            e.autoSuspend &&
            e.ctx &&
            e.ctx.suspend !== void 0 &&
            r.usingWebAudio
          ) {
            for (var t = 0; t < e._howls.length; t++)
              if (e._howls[t]._webAudio) {
                for (var n = 0; n < e._howls[t]._sounds.length; n++)
                  if (!e._howls[t]._sounds[n]._paused) return e;
              }
            return (
              e._suspendTimer && clearTimeout(e._suspendTimer),
              (e._suspendTimer = setTimeout(function () {
                if (e.autoSuspend) {
                  (e._suspendTimer = null), (e.state = `suspending`);
                  var t = function () {
                    (e.state = `suspended`),
                      e._resumeAfterSuspend &&
                        (delete e._resumeAfterSuspend, e._autoResume());
                  };
                  e.ctx.suspend().then(t, t);
                }
              }, 3e4)),
              e
            );
          }
        },
        _autoResume: function () {
          var e = this;
          if (e.ctx && e.ctx.resume !== void 0 && r.usingWebAudio)
            return (
              e.state === `running` &&
              e.ctx.state !== `interrupted` &&
              e._suspendTimer
                ? (clearTimeout(e._suspendTimer), (e._suspendTimer = null))
                : e.state === `suspended` ||
                  (e.state === `running` && e.ctx.state === `interrupted`)
                ? (e.ctx.resume().then(function () {
                    e.state = `running`;
                    for (var t = 0; t < e._howls.length; t++)
                      e._howls[t]._emit(`resume`);
                  }),
                  e._suspendTimer &&
                    (clearTimeout(e._suspendTimer), (e._suspendTimer = null)))
                : e.state === `suspending` && (e._resumeAfterSuspend = !0),
              e
            );
        },
      };
      var r = new t(),
        i = function (e) {
          var t = this;
          !e.src || e.src.length === 0
            ? console.error(
                `An array of source files must be passed with any new Howl.`
              )
            : t.init(e);
        };
      i.prototype = {
        init: function (e) {
          var t = this;
          return (
            r.ctx || d(),
            (t._autoplay = e.autoplay || !1),
            (t._format = typeof e.format == `string` ? [e.format] : e.format),
            (t._html5 = e.html5 || !1),
            (t._muted = e.mute || !1),
            (t._loop = e.loop || !1),
            (t._pool = e.pool || 5),
            (t._preload =
              typeof e.preload == `boolean` || e.preload === `metadata`
                ? e.preload
                : !0),
            (t._rate = e.rate || 1),
            (t._sprite = e.sprite || {}),
            (t._src = typeof e.src == `string` ? [e.src] : e.src),
            (t._volume = e.volume === void 0 ? 1 : e.volume),
            (t._xhr = {
              method: e.xhr && e.xhr.method ? e.xhr.method : `GET`,
              headers: e.xhr && e.xhr.headers ? e.xhr.headers : null,
              withCredentials:
                e.xhr && e.xhr.withCredentials ? e.xhr.withCredentials : !1,
            }),
            (t._duration = 0),
            (t._state = `unloaded`),
            (t._sounds = []),
            (t._endTimers = {}),
            (t._queue = []),
            (t._playLock = !1),
            (t._onend = e.onend ? [{ fn: e.onend }] : []),
            (t._onfade = e.onfade ? [{ fn: e.onfade }] : []),
            (t._onload = e.onload ? [{ fn: e.onload }] : []),
            (t._onloaderror = e.onloaderror ? [{ fn: e.onloaderror }] : []),
            (t._onplayerror = e.onplayerror ? [{ fn: e.onplayerror }] : []),
            (t._onpause = e.onpause ? [{ fn: e.onpause }] : []),
            (t._onplay = e.onplay ? [{ fn: e.onplay }] : []),
            (t._onstop = e.onstop ? [{ fn: e.onstop }] : []),
            (t._onmute = e.onmute ? [{ fn: e.onmute }] : []),
            (t._onvolume = e.onvolume ? [{ fn: e.onvolume }] : []),
            (t._onrate = e.onrate ? [{ fn: e.onrate }] : []),
            (t._onseek = e.onseek ? [{ fn: e.onseek }] : []),
            (t._onunlock = e.onunlock ? [{ fn: e.onunlock }] : []),
            (t._onresume = []),
            (t._webAudio = r.usingWebAudio && !t._html5),
            r.ctx !== void 0 && r.ctx && r.autoUnlock && r._unlockAudio(),
            r._howls.push(t),
            t._autoplay &&
              t._queue.push({
                event: `play`,
                action: function () {
                  t.play();
                },
              }),
            t._preload && t._preload !== `none` && t.load(),
            t
          );
        },
        load: function () {
          var e = this,
            t = null;
          if (r.noAudio) e._emit(`loaderror`, null, `No audio support.`);
          else {
            typeof e._src == `string` && (e._src = [e._src]);
            for (var n = 0; n < e._src.length; n++) {
              var i, o;
              if (e._format && e._format[n]) i = e._format[n];
              else {
                if (((o = e._src[n]), typeof o != `string`)) {
                  e._emit(
                    `loaderror`,
                    null,
                    `Non-string found in selected audio sources - ignoring.`
                  );
                  continue;
                }
                (i = /^data:audio\/([^;,]+);/i.exec(o)),
                  i || (i = /\.([^.]+)$/.exec(o.split(`?`, 1)[0])),
                  i && (i = i[1].toLowerCase());
              }
              if (
                (i ||
                  console.warn(
                    `No file extension was found. Consider using the "format" property or specify an extension.`
                  ),
                i && r.codecs(i))
              ) {
                t = e._src[n];
                break;
              }
            }
            if (!t)
              e._emit(
                `loaderror`,
                null,
                `No codec support for selected audio sources.`
              );
            else
              return (
                (e._src = t),
                (e._state = `loading`),
                window.location.protocol === `https:` &&
                  t.slice(0, 5) === `http:` &&
                  ((e._html5 = !0), (e._webAudio = !1)),
                new a(e),
                e._webAudio && s(e),
                e
              );
          }
        },
        play: function (e, t) {
          var n = this,
            i = null;
          if (typeof e == `number`) (i = e), (e = null);
          else if (
            typeof e == `string` &&
            n._state === `loaded` &&
            !n._sprite[e]
          )
            return null;
          else if (e === void 0 && ((e = `__default`), !n._playLock)) {
            for (var a = 0, o = 0; o < n._sounds.length; o++)
              n._sounds[o]._paused &&
                !n._sounds[o]._ended &&
                (a++, (i = n._sounds[o]._id));
            a === 1 ? (e = null) : (i = null);
          }
          var s = i ? n._soundById(i) : n._inactiveSound();
          if (!s) return null;
          if (
            (i && !e && (e = s._sprite || `__default`), n._state !== `loaded`)
          ) {
            (s._sprite = e), (s._ended = !1);
            var c = s._id;
            return (
              n._queue.push({
                event: `play`,
                action: function () {
                  n.play(c);
                },
              }),
              c
            );
          }
          if (i && !s._paused) return t || n._loadQueue(`play`), s._id;
          n._webAudio && r._autoResume();
          var l = Math.max(0, s._seek > 0 ? s._seek : n._sprite[e][0] / 1e3),
            u = Math.max(0, (n._sprite[e][0] + n._sprite[e][1]) / 1e3 - l),
            d = (u * 1e3) / Math.abs(s._rate),
            f = n._sprite[e][0] / 1e3,
            p = (n._sprite[e][0] + n._sprite[e][1]) / 1e3;
          (s._sprite = e), (s._ended = !1);
          var m = function () {
            (s._paused = !1),
              (s._seek = l),
              (s._start = f),
              (s._stop = p),
              (s._loop = !!(s._loop || n._sprite[e][2]));
          };
          if (l >= p) n._ended(s);
          else {
            var h = s._node;
            if (n._webAudio) {
              var g = function () {
                (n._playLock = !1), m(), n._refreshBuffer(s);
                var e = s._muted || n._muted ? 0 : s._volume;
                h.gain.setValueAtTime(e, r.ctx.currentTime),
                  (s._playStart = r.ctx.currentTime),
                  h.bufferSource.start === void 0
                    ? s._loop
                      ? h.bufferSource.noteGrainOn(0, l, 86400)
                      : h.bufferSource.noteGrainOn(0, l, u)
                    : s._loop
                    ? h.bufferSource.start(0, l, 86400)
                    : h.bufferSource.start(0, l, u),
                  d !== 1 / 0 &&
                    (n._endTimers[s._id] = setTimeout(n._ended.bind(n, s), d)),
                  t ||
                    setTimeout(function () {
                      n._emit(`play`, s._id), n._loadQueue();
                    }, 0);
              };
              r.state === `running` && r.ctx.state !== `interrupted`
                ? g()
                : ((n._playLock = !0),
                  n.once(`resume`, g),
                  n._clearTimer(s._id));
            } else {
              var _ = function () {
                (h.currentTime = l),
                  (h.muted = s._muted || n._muted || r._muted || h.muted),
                  (h.volume = s._volume * r.volume()),
                  (h.playbackRate = s._rate);
                try {
                  var i = h.play();
                  if (
                    (i &&
                    typeof Promise < `u` &&
                    (i instanceof Promise || typeof i.then == `function`)
                      ? ((n._playLock = !0),
                        m(),
                        i
                          .then(function () {
                            (n._playLock = !1),
                              (h._unlocked = !0),
                              t ? n._loadQueue() : n._emit(`play`, s._id);
                          })
                          .catch(function () {
                            (n._playLock = !1),
                              n._emit(
                                `playerror`,
                                s._id,
                                `Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.`
                              ),
                              (s._ended = !0),
                              (s._paused = !0);
                          }))
                      : t || ((n._playLock = !1), m(), n._emit(`play`, s._id)),
                    (h.playbackRate = s._rate),
                    h.paused)
                  ) {
                    n._emit(
                      `playerror`,
                      s._id,
                      `Playback was unable to start. This is most commonly an issue on mobile devices and Chrome where playback was not within a user interaction.`
                    );
                    return;
                  }
                  e !== `__default` || s._loop
                    ? (n._endTimers[s._id] = setTimeout(n._ended.bind(n, s), d))
                    : ((n._endTimers[s._id] = function () {
                        n._ended(s),
                          h.removeEventListener(
                            `ended`,
                            n._endTimers[s._id],
                            !1
                          );
                      }),
                      h.addEventListener(`ended`, n._endTimers[s._id], !1));
                } catch (e) {
                  n._emit(`playerror`, s._id, e);
                }
              };
              h.src ===
                `data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA` &&
                ((h.src = n._src), h.load());
              var v =
                (window && window.ejecta) ||
                (!h.readyState && r._navigator.isCocoonJS);
              if (h.readyState >= 3 || v) _();
              else {
                (n._playLock = !0), (n._state = `loading`);
                var y = function () {
                  (n._state = `loaded`),
                    _(),
                    h.removeEventListener(r._canPlayEvent, y, !1);
                };
                h.addEventListener(r._canPlayEvent, y, !1),
                  n._clearTimer(s._id);
              }
            }
            return s._id;
          }
        },
        pause: function (e) {
          var t = this;
          if (t._state !== `loaded` || t._playLock)
            return (
              t._queue.push({
                event: `pause`,
                action: function () {
                  t.pause(e);
                },
              }),
              t
            );
          for (var n = t._getSoundIds(e), r = 0; r < n.length; r++) {
            t._clearTimer(n[r]);
            var i = t._soundById(n[r]);
            if (
              i &&
              !i._paused &&
              ((i._seek = t.seek(n[r])),
              (i._rateSeek = 0),
              (i._paused = !0),
              t._stopFade(n[r]),
              i._node)
            ) {
              if (t._webAudio) {
                if (!i._node.bufferSource) continue;
                i._node.bufferSource.stop === void 0
                  ? i._node.bufferSource.noteOff(0)
                  : i._node.bufferSource.stop(0),
                  t._cleanBuffer(i._node);
              } else
                (!isNaN(i._node.duration) || i._node.duration === 1 / 0) &&
                  i._node.pause();
            }
            arguments[1] || t._emit(`pause`, i ? i._id : null);
          }
          return t;
        },
        stop: function (e, t) {
          var n = this;
          if (n._state !== `loaded` || n._playLock)
            return (
              n._queue.push({
                event: `stop`,
                action: function () {
                  n.stop(e);
                },
              }),
              n
            );
          for (var r = n._getSoundIds(e), i = 0; i < r.length; i++) {
            n._clearTimer(r[i]);
            var a = n._soundById(r[i]);
            a &&
              ((a._seek = a._start || 0),
              (a._rateSeek = 0),
              (a._paused = !0),
              (a._ended = !0),
              n._stopFade(r[i]),
              a._node &&
                (n._webAudio
                  ? a._node.bufferSource &&
                    (a._node.bufferSource.stop === void 0
                      ? a._node.bufferSource.noteOff(0)
                      : a._node.bufferSource.stop(0),
                    n._cleanBuffer(a._node))
                  : (!isNaN(a._node.duration) || a._node.duration === 1 / 0) &&
                    ((a._node.currentTime = a._start || 0),
                    a._node.pause(),
                    a._node.duration === 1 / 0 && n._clearSound(a._node))),
              t || n._emit(`stop`, a._id));
          }
          return n;
        },
        mute: function (e, t) {
          var n = this;
          if (n._state !== `loaded` || n._playLock)
            return (
              n._queue.push({
                event: `mute`,
                action: function () {
                  n.mute(e, t);
                },
              }),
              n
            );
          if (t === void 0) {
            if (typeof e == `boolean`) n._muted = e;
            else return n._muted;
          }
          for (var i = n._getSoundIds(t), a = 0; a < i.length; a++) {
            var o = n._soundById(i[a]);
            o &&
              ((o._muted = e),
              o._interval && n._stopFade(o._id),
              n._webAudio && o._node
                ? o._node.gain.setValueAtTime(
                    e ? 0 : o._volume,
                    r.ctx.currentTime
                  )
                : o._node && (o._node.muted = r._muted ? !0 : e),
              n._emit(`mute`, o._id));
          }
          return n;
        },
        volume: function () {
          var e = this,
            t = arguments,
            n,
            i;
          if (t.length === 0) return e._volume;
          t.length === 1 || (t.length === 2 && t[1] === void 0)
            ? e._getSoundIds().indexOf(t[0]) >= 0
              ? (i = parseInt(t[0], 10))
              : (n = parseFloat(t[0]))
            : t.length >= 2 &&
              ((n = parseFloat(t[0])), (i = parseInt(t[1], 10)));
          var a;
          if (n !== void 0 && n >= 0 && n <= 1) {
            if (e._state !== `loaded` || e._playLock)
              return (
                e._queue.push({
                  event: `volume`,
                  action: function () {
                    e.volume.apply(e, t);
                  },
                }),
                e
              );
            i === void 0 && (e._volume = n), (i = e._getSoundIds(i));
            for (var o = 0; o < i.length; o++)
              (a = e._soundById(i[o])),
                a &&
                  ((a._volume = n),
                  t[2] || e._stopFade(i[o]),
                  e._webAudio && a._node && !a._muted
                    ? a._node.gain.setValueAtTime(n, r.ctx.currentTime)
                    : a._node && !a._muted && (a._node.volume = n * r.volume()),
                  e._emit(`volume`, a._id));
          } else
            return (a = i ? e._soundById(i) : e._sounds[0]), a ? a._volume : 0;
          return e;
        },
        fade: function (e, t, n, i) {
          var a = this;
          if (a._state !== `loaded` || a._playLock)
            return (
              a._queue.push({
                event: `fade`,
                action: function () {
                  a.fade(e, t, n, i);
                },
              }),
              a
            );
          (e = Math.min(Math.max(0, parseFloat(e)), 1)),
            (t = Math.min(Math.max(0, parseFloat(t)), 1)),
            (n = parseFloat(n)),
            a.volume(e, i);
          for (var o = a._getSoundIds(i), s = 0; s < o.length; s++) {
            var c = a._soundById(o[s]);
            if (c) {
              if ((i || a._stopFade(o[s]), a._webAudio && !c._muted)) {
                var l = r.ctx.currentTime,
                  u = l + n / 1e3;
                (c._volume = e),
                  c._node.gain.setValueAtTime(e, l),
                  c._node.gain.linearRampToValueAtTime(t, u);
              }
              a._startFadeInterval(c, e, t, n, o[s], i === void 0);
            }
          }
          return a;
        },
        _startFadeInterval: function (e, t, n, r, i, a) {
          var o = this,
            s = t,
            c = n - t,
            l = Math.abs(c / 0.01),
            u = Math.max(4, l > 0 ? r / l : r),
            d = Date.now();
          (e._fadeTo = n),
            (e._interval = setInterval(function () {
              var i = (Date.now() - d) / r;
              (d = Date.now()),
                (s += c * i),
                (s = Math.round(s * 100) / 100),
                (s = c < 0 ? Math.max(n, s) : Math.min(n, s)),
                o._webAudio ? (e._volume = s) : o.volume(s, e._id, !0),
                a && (o._volume = s),
                ((n < t && s <= n) || (n > t && s >= n)) &&
                  (clearInterval(e._interval),
                  (e._interval = null),
                  (e._fadeTo = null),
                  o.volume(n, e._id),
                  o._emit(`fade`, e._id));
            }, u));
        },
        _stopFade: function (e) {
          var t = this,
            n = t._soundById(e);
          return (
            n &&
              n._interval &&
              (t._webAudio &&
                n._node.gain.cancelScheduledValues(r.ctx.currentTime),
              clearInterval(n._interval),
              (n._interval = null),
              t.volume(n._fadeTo, e),
              (n._fadeTo = null),
              t._emit(`fade`, e)),
            t
          );
        },
        loop: function () {
          var e = this,
            t = arguments,
            n,
            r,
            i;
          if (t.length === 0) return e._loop;
          if (t.length === 1) {
            if (typeof t[0] == `boolean`) (n = t[0]), (e._loop = n);
            else
              return (i = e._soundById(parseInt(t[0], 10))), i ? i._loop : !1;
          } else t.length === 2 && ((n = t[0]), (r = parseInt(t[1], 10)));
          for (var a = e._getSoundIds(r), o = 0; o < a.length; o++)
            (i = e._soundById(a[o])),
              i &&
                ((i._loop = n),
                e._webAudio &&
                  i._node &&
                  i._node.bufferSource &&
                  ((i._node.bufferSource.loop = n),
                  n &&
                    ((i._node.bufferSource.loopStart = i._start || 0),
                    (i._node.bufferSource.loopEnd = i._stop),
                    e.playing(a[o]) && (e.pause(a[o], !0), e.play(a[o], !0)))));
          return e;
        },
        rate: function () {
          var e = this,
            t = arguments,
            n,
            i;
          t.length === 0
            ? (i = e._sounds[0]._id)
            : t.length === 1
            ? e._getSoundIds().indexOf(t[0]) >= 0
              ? (i = parseInt(t[0], 10))
              : (n = parseFloat(t[0]))
            : t.length === 2 &&
              ((n = parseFloat(t[0])), (i = parseInt(t[1], 10)));
          var a;
          if (typeof n == `number`) {
            if (e._state !== `loaded` || e._playLock)
              return (
                e._queue.push({
                  event: `rate`,
                  action: function () {
                    e.rate.apply(e, t);
                  },
                }),
                e
              );
            i === void 0 && (e._rate = n), (i = e._getSoundIds(i));
            for (var o = 0; o < i.length; o++)
              if (((a = e._soundById(i[o])), a)) {
                e.playing(i[o]) &&
                  ((a._rateSeek = e.seek(i[o])),
                  (a._playStart = e._webAudio
                    ? r.ctx.currentTime
                    : a._playStart)),
                  (a._rate = n),
                  e._webAudio && a._node && a._node.bufferSource
                    ? a._node.bufferSource.playbackRate.setValueAtTime(
                        n,
                        r.ctx.currentTime
                      )
                    : a._node && (a._node.playbackRate = n);
                var s = e.seek(i[o]),
                  c =
                    (((e._sprite[a._sprite][0] + e._sprite[a._sprite][1]) /
                      1e3 -
                      s) *
                      1e3) /
                    Math.abs(a._rate);
                (e._endTimers[i[o]] || !a._paused) &&
                  (e._clearTimer(i[o]),
                  (e._endTimers[i[o]] = setTimeout(e._ended.bind(e, a), c))),
                  e._emit(`rate`, a._id);
              }
          } else return (a = e._soundById(i)), a ? a._rate : e._rate;
          return e;
        },
        seek: function () {
          var e = this,
            t = arguments,
            n,
            i;
          if (
            (t.length === 0
              ? e._sounds.length && (i = e._sounds[0]._id)
              : t.length === 1
              ? e._getSoundIds().indexOf(t[0]) >= 0
                ? (i = parseInt(t[0], 10))
                : e._sounds.length &&
                  ((i = e._sounds[0]._id), (n = parseFloat(t[0])))
              : t.length === 2 &&
                ((n = parseFloat(t[0])), (i = parseInt(t[1], 10))),
            i === void 0)
          )
            return 0;
          if (typeof n == `number` && (e._state !== `loaded` || e._playLock))
            return (
              e._queue.push({
                event: `seek`,
                action: function () {
                  e.seek.apply(e, t);
                },
              }),
              e
            );
          var a = e._soundById(i);
          if (a) {
            if (typeof n == `number` && n >= 0) {
              var o = e.playing(i);
              o && e.pause(i, !0),
                (a._seek = n),
                (a._ended = !1),
                e._clearTimer(i),
                !e._webAudio &&
                  a._node &&
                  !isNaN(a._node.duration) &&
                  (a._node.currentTime = n);
              var s = function () {
                o && e.play(i, !0), e._emit(`seek`, i);
              };
              if (o && !e._webAudio) {
                var c = function () {
                  e._playLock ? setTimeout(c, 0) : s();
                };
                setTimeout(c, 0);
              } else s();
            } else if (e._webAudio) {
              var l = e.playing(i) ? r.ctx.currentTime - a._playStart : 0,
                u = a._rateSeek ? a._rateSeek - a._seek : 0;
              return a._seek + (u + l * Math.abs(a._rate));
            } else return a._node.currentTime;
          }
          return e;
        },
        playing: function (e) {
          var t = this;
          if (typeof e == `number`) {
            var n = t._soundById(e);
            return n ? !n._paused : !1;
          }
          for (var r = 0; r < t._sounds.length; r++)
            if (!t._sounds[r]._paused) return !0;
          return !1;
        },
        duration: function (e) {
          var t = this,
            n = t._duration,
            r = t._soundById(e);
          return r && (n = t._sprite[r._sprite][1] / 1e3), n;
        },
        state: function () {
          return this._state;
        },
        unload: function () {
          for (var e = this, t = e._sounds, n = 0; n < t.length; n++)
            t[n]._paused || e.stop(t[n]._id),
              e._webAudio ||
                (e._clearSound(t[n]._node),
                t[n]._node.removeEventListener(`error`, t[n]._errorFn, !1),
                t[n]._node.removeEventListener(
                  r._canPlayEvent,
                  t[n]._loadFn,
                  !1
                ),
                t[n]._node.removeEventListener(`ended`, t[n]._endFn, !1),
                r._releaseHtml5Audio(t[n]._node)),
              delete t[n]._node,
              e._clearTimer(t[n]._id);
          var i = r._howls.indexOf(e);
          i >= 0 && r._howls.splice(i, 1);
          var a = !0;
          for (n = 0; n < r._howls.length; n++)
            if (
              r._howls[n]._src === e._src ||
              e._src.indexOf(r._howls[n]._src) >= 0
            ) {
              a = !1;
              break;
            }
          return (
            o && a && delete o[e._src],
            (r.noAudio = !1),
            (e._state = `unloaded`),
            (e._sounds = []),
            (e = null),
            null
          );
        },
        on: function (e, t, n, r) {
          var i = this,
            a = i[`_on` + e];
          return (
            typeof t == `function` &&
              a.push(r ? { id: n, fn: t, once: r } : { id: n, fn: t }),
            i
          );
        },
        off: function (e, t, n) {
          var r = this,
            i = r[`_on` + e],
            a = 0;
          if ((typeof t == `number` && ((n = t), (t = null)), t || n))
            for (a = 0; a < i.length; a++) {
              var o = n === i[a].id;
              if ((t === i[a].fn && o) || (!t && o)) {
                i.splice(a, 1);
                break;
              }
            }
          else if (e) r[`_on` + e] = [];
          else {
            var s = Object.keys(r);
            for (a = 0; a < s.length; a++)
              s[a].indexOf(`_on`) === 0 &&
                Array.isArray(r[s[a]]) &&
                (r[s[a]] = []);
          }
          return r;
        },
        once: function (e, t, n) {
          var r = this;
          return r.on(e, t, n, 1), r;
        },
        _emit: function (e, t, n) {
          for (var r = this, i = r[`_on` + e], a = i.length - 1; a >= 0; a--)
            (!i[a].id || i[a].id === t || e === `load`) &&
              (setTimeout(
                function (e) {
                  e.call(this, t, n);
                }.bind(r, i[a].fn),
                0
              ),
              i[a].once && r.off(e, i[a].fn, i[a].id));
          return r._loadQueue(e), r;
        },
        _loadQueue: function (e) {
          var t = this;
          if (t._queue.length > 0) {
            var n = t._queue[0];
            n.event === e && (t._queue.shift(), t._loadQueue()),
              e || n.action();
          }
          return t;
        },
        _ended: function (e) {
          var t = this,
            n = e._sprite;
          if (
            !t._webAudio &&
            e._node &&
            !e._node.paused &&
            !e._node.ended &&
            e._node.currentTime < e._stop
          )
            return setTimeout(t._ended.bind(t, e), 100), t;
          var i = !!(e._loop || t._sprite[n][2]);
          if (
            (t._emit(`end`, e._id),
            !t._webAudio && i && t.stop(e._id, !0).play(e._id),
            t._webAudio && i)
          ) {
            t._emit(`play`, e._id),
              (e._seek = e._start || 0),
              (e._rateSeek = 0),
              (e._playStart = r.ctx.currentTime);
            var a = ((e._stop - e._start) * 1e3) / Math.abs(e._rate);
            t._endTimers[e._id] = setTimeout(t._ended.bind(t, e), a);
          }
          return (
            t._webAudio &&
              !i &&
              ((e._paused = !0),
              (e._ended = !0),
              (e._seek = e._start || 0),
              (e._rateSeek = 0),
              t._clearTimer(e._id),
              t._cleanBuffer(e._node),
              r._autoSuspend()),
            !t._webAudio && !i && t.stop(e._id, !0),
            t
          );
        },
        _clearTimer: function (e) {
          var t = this;
          if (t._endTimers[e]) {
            if (typeof t._endTimers[e] != `function`)
              clearTimeout(t._endTimers[e]);
            else {
              var n = t._soundById(e);
              n &&
                n._node &&
                n._node.removeEventListener(`ended`, t._endTimers[e], !1);
            }
            delete t._endTimers[e];
          }
          return t;
        },
        _soundById: function (e) {
          for (var t = this, n = 0; n < t._sounds.length; n++)
            if (e === t._sounds[n]._id) return t._sounds[n];
          return null;
        },
        _inactiveSound: function () {
          var e = this;
          e._drain();
          for (var t = 0; t < e._sounds.length; t++)
            if (e._sounds[t]._ended) return e._sounds[t].reset();
          return new a(e);
        },
        _drain: function () {
          var e = this,
            t = e._pool,
            n = 0,
            r = 0;
          if (!(e._sounds.length < t)) {
            for (r = 0; r < e._sounds.length; r++) e._sounds[r]._ended && n++;
            for (r = e._sounds.length - 1; r >= 0; r--) {
              if (n <= t) return;
              e._sounds[r]._ended &&
                (e._webAudio &&
                  e._sounds[r]._node &&
                  e._sounds[r]._node.disconnect(0),
                e._sounds.splice(r, 1),
                n--);
            }
          }
        },
        _getSoundIds: function (e) {
          var t = this;
          if (e === void 0) {
            for (var n = [], r = 0; r < t._sounds.length; r++)
              n.push(t._sounds[r]._id);
            return n;
          }
          return [e];
        },
        _refreshBuffer: function (e) {
          var t = this;
          return (
            (e._node.bufferSource = r.ctx.createBufferSource()),
            (e._node.bufferSource.buffer = o[t._src]),
            e._panner
              ? e._node.bufferSource.connect(e._panner)
              : e._node.bufferSource.connect(e._node),
            (e._node.bufferSource.loop = e._loop),
            e._loop &&
              ((e._node.bufferSource.loopStart = e._start || 0),
              (e._node.bufferSource.loopEnd = e._stop || 0)),
            e._node.bufferSource.playbackRate.setValueAtTime(
              e._rate,
              r.ctx.currentTime
            ),
            t
          );
        },
        _cleanBuffer: function (e) {
          var t = this,
            n = r._navigator && r._navigator.vendor.indexOf(`Apple`) >= 0;
          if (!e.bufferSource) return t;
          if (
            r._scratchBuffer &&
            e.bufferSource &&
            ((e.bufferSource.onended = null), e.bufferSource.disconnect(0), n)
          )
            try {
              e.bufferSource.buffer = r._scratchBuffer;
            } catch {}
          return (e.bufferSource = null), t;
        },
        _clearSound: function (e) {
          /MSIE |Trident\//.test(r._navigator && r._navigator.userAgent) ||
            (e.src = `data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA`);
        },
      };
      var a = function (e) {
        (this._parent = e), this.init();
      };
      a.prototype = {
        init: function () {
          var e = this,
            t = e._parent;
          return (
            (e._muted = t._muted),
            (e._loop = t._loop),
            (e._volume = t._volume),
            (e._rate = t._rate),
            (e._seek = 0),
            (e._paused = !0),
            (e._ended = !0),
            (e._sprite = `__default`),
            (e._id = ++r._counter),
            t._sounds.push(e),
            e.create(),
            e
          );
        },
        create: function () {
          var e = this,
            t = e._parent,
            n = r._muted || e._muted || e._parent._muted ? 0 : e._volume;
          return (
            t._webAudio
              ? ((e._node =
                  r.ctx.createGain === void 0
                    ? r.ctx.createGainNode()
                    : r.ctx.createGain()),
                e._node.gain.setValueAtTime(n, r.ctx.currentTime),
                (e._node.paused = !0),
                e._node.connect(r.masterGain))
              : r.noAudio ||
                ((e._node = r._obtainHtml5Audio()),
                (e._errorFn = e._errorListener.bind(e)),
                e._node.addEventListener(`error`, e._errorFn, !1),
                (e._loadFn = e._loadListener.bind(e)),
                e._node.addEventListener(r._canPlayEvent, e._loadFn, !1),
                (e._endFn = e._endListener.bind(e)),
                e._node.addEventListener(`ended`, e._endFn, !1),
                (e._node.src = t._src),
                (e._node.preload = t._preload === !0 ? `auto` : t._preload),
                (e._node.volume = n * r.volume()),
                e._node.load()),
            e
          );
        },
        reset: function () {
          var e = this,
            t = e._parent;
          return (
            (e._muted = t._muted),
            (e._loop = t._loop),
            (e._volume = t._volume),
            (e._rate = t._rate),
            (e._seek = 0),
            (e._rateSeek = 0),
            (e._paused = !0),
            (e._ended = !0),
            (e._sprite = `__default`),
            (e._id = ++r._counter),
            e
          );
        },
        _errorListener: function () {
          var e = this;
          e._parent._emit(
            `loaderror`,
            e._id,
            e._node.error ? e._node.error.code : 0
          ),
            e._node.removeEventListener(`error`, e._errorFn, !1);
        },
        _loadListener: function () {
          var e = this,
            t = e._parent;
          (t._duration = Math.ceil(e._node.duration * 10) / 10),
            Object.keys(t._sprite).length === 0 &&
              (t._sprite = { __default: [0, t._duration * 1e3] }),
            t._state !== `loaded` &&
              ((t._state = `loaded`), t._emit(`load`), t._loadQueue()),
            e._node.removeEventListener(r._canPlayEvent, e._loadFn, !1);
        },
        _endListener: function () {
          var e = this,
            t = e._parent;
          t._duration === 1 / 0 &&
            ((t._duration = Math.ceil(e._node.duration * 10) / 10),
            t._sprite.__default[1] === 1 / 0 &&
              (t._sprite.__default[1] = t._duration * 1e3),
            t._ended(e)),
            e._node.removeEventListener(`ended`, e._endFn, !1);
        },
      };
      var o = {},
        s = function (e) {
          var t = e._src;
          if (o[t]) (e._duration = o[t].duration), u(e);
          else if (/^data:[^;]+;base64,/.test(t)) {
            for (
              var n = atob(t.split(`,`)[1]),
                r = new Uint8Array(n.length),
                i = 0;
              i < n.length;
              ++i
            )
              r[i] = n.charCodeAt(i);
            l(r.buffer, e);
          } else {
            var a = new XMLHttpRequest();
            a.open(e._xhr.method, t, !0),
              (a.withCredentials = e._xhr.withCredentials),
              (a.responseType = `arraybuffer`),
              e._xhr.headers &&
                Object.keys(e._xhr.headers).forEach(function (t) {
                  a.setRequestHeader(t, e._xhr.headers[t]);
                }),
              (a.onload = function () {
                var t = (a.status + ``)[0];
                t !== `0` && t !== `2` && t !== `3`
                  ? e._emit(
                      `loaderror`,
                      null,
                      `Failed loading audio file with status: ` + a.status + `.`
                    )
                  : l(a.response, e);
              }),
              (a.onerror = function () {
                e._webAudio &&
                  ((e._html5 = !0),
                  (e._webAudio = !1),
                  (e._sounds = []),
                  delete o[t],
                  e.load());
              }),
              c(a);
          }
        },
        c = function (e) {
          try {
            e.send();
          } catch {
            e.onerror();
          }
        },
        l = function (e, t) {
          var n = function () {
              t._emit(`loaderror`, null, `Decoding audio data failed.`);
            },
            i = function (e) {
              e && t._sounds.length > 0 ? ((o[t._src] = e), u(t, e)) : n();
            };
          typeof Promise < `u` && r.ctx.decodeAudioData.length === 1
            ? r.ctx.decodeAudioData(e).then(i).catch(n)
            : r.ctx.decodeAudioData(e, i, n);
        },
        u = function (e, t) {
          t && !e._duration && (e._duration = t.duration),
            Object.keys(e._sprite).length === 0 &&
              (e._sprite = { __default: [0, e._duration * 1e3] }),
            e._state !== `loaded` &&
              ((e._state = `loaded`), e._emit(`load`), e._loadQueue());
        },
        d = function () {
          if (r.usingWebAudio) {
            try {
              typeof AudioContext < `u`
                ? (r.ctx = new AudioContext())
                : typeof webkitAudioContext < `u`
                ? (r.ctx = new webkitAudioContext())
                : (r.usingWebAudio = !1);
            } catch {
              r.usingWebAudio = !1;
            }
            r.ctx || (r.usingWebAudio = !1);
            var e = /iP(hone|od|ad)/.test(
                r._navigator && r._navigator.platform
              ),
              t =
                r._navigator &&
                r._navigator.appVersion.match(/OS (\d+)_(\d+)_?(\d+)?/),
              n = t ? parseInt(t[1], 10) : null;
            if (e && n && n < 9) {
              var i = /safari/.test(
                r._navigator && r._navigator.userAgent.toLowerCase()
              );
              r._navigator && !i && (r.usingWebAudio = !1);
            }
            r.usingWebAudio &&
              ((r.masterGain =
                r.ctx.createGain === void 0
                  ? r.ctx.createGainNode()
                  : r.ctx.createGain()),
              r.masterGain.gain.setValueAtTime(
                r._muted ? 0 : r._volume,
                r.ctx.currentTime
              ),
              r.masterGain.connect(r.ctx.destination)),
              r._setup();
          }
        };
      typeof define == `function` &&
        define.amd &&
        define([], function () {
          return { Howler: r, Howl: i };
        }),
        e !== void 0 && ((e.Howler = r), (e.Howl = i)),
        n === void 0
          ? typeof window < `u` &&
            ((window.HowlerGlobal = t),
            (window.Howler = r),
            (window.Howl = i),
            (window.Sound = a))
          : ((n.HowlerGlobal = t), (n.Howler = r), (n.Howl = i), (n.Sound = a));
    })(),
    (function () {
      (HowlerGlobal.prototype._pos = [0, 0, 0]),
        (HowlerGlobal.prototype._orientation = [0, 0, -1, 0, 1, 0]),
        (HowlerGlobal.prototype.stereo = function (e) {
          var t = this;
          if (!t.ctx || !t.ctx.listener) return t;
          for (var n = t._howls.length - 1; n >= 0; n--) t._howls[n].stereo(e);
          return t;
        }),
        (HowlerGlobal.prototype.pos = function (e, t, n) {
          var r = this;
          if (!r.ctx || !r.ctx.listener) return r;
          if (
            ((t = typeof t == `number` ? t : r._pos[1]),
            (n = typeof n == `number` ? n : r._pos[2]),
            typeof e == `number`)
          )
            (r._pos = [e, t, n]),
              r.ctx.listener.positionX === void 0
                ? r.ctx.listener.setPosition(r._pos[0], r._pos[1], r._pos[2])
                : (r.ctx.listener.positionX.setTargetAtTime(
                    r._pos[0],
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  r.ctx.listener.positionY.setTargetAtTime(
                    r._pos[1],
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  r.ctx.listener.positionZ.setTargetAtTime(
                    r._pos[2],
                    Howler.ctx.currentTime,
                    0.1
                  ));
          else return r._pos;
          return r;
        }),
        (HowlerGlobal.prototype.orientation = function (e, t, n, r, i, a) {
          var o = this;
          if (!o.ctx || !o.ctx.listener) return o;
          var s = o._orientation;
          if (
            ((t = typeof t == `number` ? t : s[1]),
            (n = typeof n == `number` ? n : s[2]),
            (r = typeof r == `number` ? r : s[3]),
            (i = typeof i == `number` ? i : s[4]),
            (a = typeof a == `number` ? a : s[5]),
            typeof e == `number`)
          )
            (o._orientation = [e, t, n, r, i, a]),
              o.ctx.listener.forwardX === void 0
                ? o.ctx.listener.setOrientation(e, t, n, r, i, a)
                : (o.ctx.listener.forwardX.setTargetAtTime(
                    e,
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  o.ctx.listener.forwardY.setTargetAtTime(
                    t,
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  o.ctx.listener.forwardZ.setTargetAtTime(
                    n,
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  o.ctx.listener.upX.setTargetAtTime(
                    r,
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  o.ctx.listener.upY.setTargetAtTime(
                    i,
                    Howler.ctx.currentTime,
                    0.1
                  ),
                  o.ctx.listener.upZ.setTargetAtTime(
                    a,
                    Howler.ctx.currentTime,
                    0.1
                  ));
          else return s;
          return o;
        }),
        (Howl.prototype.init = (function (e) {
          return function (t) {
            var n = this;
            return (
              (n._orientation = t.orientation || [1, 0, 0]),
              (n._stereo = t.stereo || null),
              (n._pos = t.pos || null),
              (n._pannerAttr = {
                coneInnerAngle:
                  t.coneInnerAngle === void 0 ? 360 : t.coneInnerAngle,
                coneOuterAngle:
                  t.coneOuterAngle === void 0 ? 360 : t.coneOuterAngle,
                coneOuterGain: t.coneOuterGain === void 0 ? 0 : t.coneOuterGain,
                distanceModel:
                  t.distanceModel === void 0 ? `inverse` : t.distanceModel,
                maxDistance: t.maxDistance === void 0 ? 1e4 : t.maxDistance,
                panningModel:
                  t.panningModel === void 0 ? `HRTF` : t.panningModel,
                refDistance: t.refDistance === void 0 ? 1 : t.refDistance,
                rolloffFactor: t.rolloffFactor === void 0 ? 1 : t.rolloffFactor,
              }),
              (n._onstereo = t.onstereo ? [{ fn: t.onstereo }] : []),
              (n._onpos = t.onpos ? [{ fn: t.onpos }] : []),
              (n._onorientation = t.onorientation
                ? [{ fn: t.onorientation }]
                : []),
              e.call(this, t)
            );
          };
        })(Howl.prototype.init)),
        (Howl.prototype.stereo = function (t, n) {
          var r = this;
          if (!r._webAudio) return r;
          if (r._state !== `loaded`)
            return (
              r._queue.push({
                event: `stereo`,
                action: function () {
                  r.stereo(t, n);
                },
              }),
              r
            );
          var i =
            Howler.ctx.createStereoPanner === void 0 ? `spatial` : `stereo`;
          if (n === void 0) {
            if (typeof t == `number`) (r._stereo = t), (r._pos = [t, 0, 0]);
            else return r._stereo;
          }
          for (var a = r._getSoundIds(n), o = 0; o < a.length; o++) {
            var s = r._soundById(a[o]);
            if (s) {
              if (typeof t == `number`)
                (s._stereo = t),
                  (s._pos = [t, 0, 0]),
                  s._node &&
                    ((s._pannerAttr.panningModel = `equalpower`),
                    (!s._panner || !s._panner.pan) && e(s, i),
                    i === `spatial`
                      ? s._panner.positionX === void 0
                        ? s._panner.setPosition(t, 0, 0)
                        : (s._panner.positionX.setValueAtTime(
                            t,
                            Howler.ctx.currentTime
                          ),
                          s._panner.positionY.setValueAtTime(
                            0,
                            Howler.ctx.currentTime
                          ),
                          s._panner.positionZ.setValueAtTime(
                            0,
                            Howler.ctx.currentTime
                          ))
                      : s._panner.pan.setValueAtTime(
                          t,
                          Howler.ctx.currentTime
                        )),
                  r._emit(`stereo`, s._id);
              else return s._stereo;
            }
          }
          return r;
        }),
        (Howl.prototype.pos = function (t, n, r, i) {
          var a = this;
          if (!a._webAudio) return a;
          if (a._state !== `loaded`)
            return (
              a._queue.push({
                event: `pos`,
                action: function () {
                  a.pos(t, n, r, i);
                },
              }),
              a
            );
          if (
            ((n = typeof n == `number` ? n : 0),
            (r = typeof r == `number` ? r : -0.5),
            i === void 0)
          ) {
            if (typeof t == `number`) a._pos = [t, n, r];
            else return a._pos;
          }
          for (var o = a._getSoundIds(i), s = 0; s < o.length; s++) {
            var c = a._soundById(o[s]);
            if (c) {
              if (typeof t == `number`)
                (c._pos = [t, n, r]),
                  c._node &&
                    ((!c._panner || c._panner.pan) && e(c, `spatial`),
                    c._panner.positionX === void 0
                      ? c._panner.setPosition(t, n, r)
                      : (c._panner.positionX.setValueAtTime(
                          t,
                          Howler.ctx.currentTime
                        ),
                        c._panner.positionY.setValueAtTime(
                          n,
                          Howler.ctx.currentTime
                        ),
                        c._panner.positionZ.setValueAtTime(
                          r,
                          Howler.ctx.currentTime
                        ))),
                  a._emit(`pos`, c._id);
              else return c._pos;
            }
          }
          return a;
        }),
        (Howl.prototype.orientation = function (t, n, r, i) {
          var a = this;
          if (!a._webAudio) return a;
          if (a._state !== `loaded`)
            return (
              a._queue.push({
                event: `orientation`,
                action: function () {
                  a.orientation(t, n, r, i);
                },
              }),
              a
            );
          if (
            ((n = typeof n == `number` ? n : a._orientation[1]),
            (r = typeof r == `number` ? r : a._orientation[2]),
            i === void 0)
          ) {
            if (typeof t == `number`) a._orientation = [t, n, r];
            else return a._orientation;
          }
          for (var o = a._getSoundIds(i), s = 0; s < o.length; s++) {
            var c = a._soundById(o[s]);
            if (c) {
              if (typeof t == `number`)
                (c._orientation = [t, n, r]),
                  c._node &&
                    (c._panner ||
                      (c._pos || (c._pos = a._pos || [0, 0, -0.5]),
                      e(c, `spatial`)),
                    c._panner.orientationX === void 0
                      ? c._panner.setOrientation(t, n, r)
                      : (c._panner.orientationX.setValueAtTime(
                          t,
                          Howler.ctx.currentTime
                        ),
                        c._panner.orientationY.setValueAtTime(
                          n,
                          Howler.ctx.currentTime
                        ),
                        c._panner.orientationZ.setValueAtTime(
                          r,
                          Howler.ctx.currentTime
                        ))),
                  a._emit(`orientation`, c._id);
              else return c._orientation;
            }
          }
          return a;
        }),
        (Howl.prototype.pannerAttr = function () {
          var t = this,
            n = arguments,
            r,
            i,
            a;
          if (!t._webAudio) return t;
          if (n.length === 0) return t._pannerAttr;
          if (n.length === 1) {
            if (typeof n[0] == `object`)
              (r = n[0]),
                i === void 0 &&
                  (r.pannerAttr ||
                    (r.pannerAttr = {
                      coneInnerAngle: r.coneInnerAngle,
                      coneOuterAngle: r.coneOuterAngle,
                      coneOuterGain: r.coneOuterGain,
                      distanceModel: r.distanceModel,
                      maxDistance: r.maxDistance,
                      refDistance: r.refDistance,
                      rolloffFactor: r.rolloffFactor,
                      panningModel: r.panningModel,
                    }),
                  (t._pannerAttr = {
                    coneInnerAngle:
                      r.pannerAttr.coneInnerAngle === void 0
                        ? t._coneInnerAngle
                        : r.pannerAttr.coneInnerAngle,
                    coneOuterAngle:
                      r.pannerAttr.coneOuterAngle === void 0
                        ? t._coneOuterAngle
                        : r.pannerAttr.coneOuterAngle,
                    coneOuterGain:
                      r.pannerAttr.coneOuterGain === void 0
                        ? t._coneOuterGain
                        : r.pannerAttr.coneOuterGain,
                    distanceModel:
                      r.pannerAttr.distanceModel === void 0
                        ? t._distanceModel
                        : r.pannerAttr.distanceModel,
                    maxDistance:
                      r.pannerAttr.maxDistance === void 0
                        ? t._maxDistance
                        : r.pannerAttr.maxDistance,
                    refDistance:
                      r.pannerAttr.refDistance === void 0
                        ? t._refDistance
                        : r.pannerAttr.refDistance,
                    rolloffFactor:
                      r.pannerAttr.rolloffFactor === void 0
                        ? t._rolloffFactor
                        : r.pannerAttr.rolloffFactor,
                    panningModel:
                      r.pannerAttr.panningModel === void 0
                        ? t._panningModel
                        : r.pannerAttr.panningModel,
                  }));
            else
              return (
                (a = t._soundById(parseInt(n[0], 10))),
                a ? a._pannerAttr : t._pannerAttr
              );
          } else n.length === 2 && ((r = n[0]), (i = parseInt(n[1], 10)));
          for (var o = t._getSoundIds(i), s = 0; s < o.length; s++)
            if (((a = t._soundById(o[s])), a)) {
              var c = a._pannerAttr;
              c = {
                coneInnerAngle:
                  r.coneInnerAngle === void 0
                    ? c.coneInnerAngle
                    : r.coneInnerAngle,
                coneOuterAngle:
                  r.coneOuterAngle === void 0
                    ? c.coneOuterAngle
                    : r.coneOuterAngle,
                coneOuterGain:
                  r.coneOuterGain === void 0
                    ? c.coneOuterGain
                    : r.coneOuterGain,
                distanceModel:
                  r.distanceModel === void 0
                    ? c.distanceModel
                    : r.distanceModel,
                maxDistance:
                  r.maxDistance === void 0 ? c.maxDistance : r.maxDistance,
                refDistance:
                  r.refDistance === void 0 ? c.refDistance : r.refDistance,
                rolloffFactor:
                  r.rolloffFactor === void 0
                    ? c.rolloffFactor
                    : r.rolloffFactor,
                panningModel:
                  r.panningModel === void 0 ? c.panningModel : r.panningModel,
              };
              var l = a._panner;
              l ||
                (a._pos || (a._pos = t._pos || [0, 0, -0.5]),
                e(a, `spatial`),
                (l = a._panner)),
                (l.coneInnerAngle = c.coneInnerAngle),
                (l.coneOuterAngle = c.coneOuterAngle),
                (l.coneOuterGain = c.coneOuterGain),
                (l.distanceModel = c.distanceModel),
                (l.maxDistance = c.maxDistance),
                (l.refDistance = c.refDistance),
                (l.rolloffFactor = c.rolloffFactor),
                (l.panningModel = c.panningModel);
            }
          return t;
        }),
        (Sound.prototype.init = (function (e) {
          return function () {
            var t = this,
              n = t._parent;
            (t._orientation = n._orientation),
              (t._stereo = n._stereo),
              (t._pos = n._pos),
              (t._pannerAttr = n._pannerAttr),
              e.call(this),
              t._stereo
                ? n.stereo(t._stereo)
                : t._pos && n.pos(t._pos[0], t._pos[1], t._pos[2], t._id);
          };
        })(Sound.prototype.init)),
        (Sound.prototype.reset = (function (e) {
          return function () {
            var t = this,
              n = t._parent;
            return (
              (t._orientation = n._orientation),
              (t._stereo = n._stereo),
              (t._pos = n._pos),
              (t._pannerAttr = n._pannerAttr),
              t._stereo
                ? n.stereo(t._stereo)
                : t._pos
                ? n.pos(t._pos[0], t._pos[1], t._pos[2], t._id)
                : t._panner &&
                  (t._panner.disconnect(0),
                  (t._panner = void 0),
                  n._refreshBuffer(t)),
              e.call(this)
            );
          };
        })(Sound.prototype.reset));
      var e = function (e, t) {
        (t = t || `spatial`),
          t === `spatial`
            ? ((e._panner = Howler.ctx.createPanner()),
              (e._panner.coneInnerAngle = e._pannerAttr.coneInnerAngle),
              (e._panner.coneOuterAngle = e._pannerAttr.coneOuterAngle),
              (e._panner.coneOuterGain = e._pannerAttr.coneOuterGain),
              (e._panner.distanceModel = e._pannerAttr.distanceModel),
              (e._panner.maxDistance = e._pannerAttr.maxDistance),
              (e._panner.refDistance = e._pannerAttr.refDistance),
              (e._panner.rolloffFactor = e._pannerAttr.rolloffFactor),
              (e._panner.panningModel = e._pannerAttr.panningModel),
              e._panner.positionX === void 0
                ? e._panner.setPosition(e._pos[0], e._pos[1], e._pos[2])
                : (e._panner.positionX.setValueAtTime(
                    e._pos[0],
                    Howler.ctx.currentTime
                  ),
                  e._panner.positionY.setValueAtTime(
                    e._pos[1],
                    Howler.ctx.currentTime
                  ),
                  e._panner.positionZ.setValueAtTime(
                    e._pos[2],
                    Howler.ctx.currentTime
                  )),
              e._panner.orientationX === void 0
                ? e._panner.setOrientation(
                    e._orientation[0],
                    e._orientation[1],
                    e._orientation[2]
                  )
                : (e._panner.orientationX.setValueAtTime(
                    e._orientation[0],
                    Howler.ctx.currentTime
                  ),
                  e._panner.orientationY.setValueAtTime(
                    e._orientation[1],
                    Howler.ctx.currentTime
                  ),
                  e._panner.orientationZ.setValueAtTime(
                    e._orientation[2],
                    Howler.ctx.currentTime
                  )))
            : ((e._panner = Howler.ctx.createStereoPanner()),
              e._panner.pan.setValueAtTime(e._stereo, Howler.ctx.currentTime)),
          e._panner.connect(e._node),
          e._paused || e._parent.pause(e._id, !0).play(e._id, !0);
      };
    })();
});
export { r as t };
