import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { l as n } from "./assertThisInitialized-DqpgQyeg.js";
var r = e(t());
n();
function i() {
  return (
    (i = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    i.apply(this, arguments)
  );
}
var a;
(function (e) {
  (e.Pop = `POP`), (e.Push = `PUSH`), (e.Replace = `REPLACE`);
})(a || (a = {}));
function o(e, t) {
  if (e === !1 || e == null) throw Error(t);
}
function s(e, t) {
  if (!e) {
    typeof console < `u` && console.warn(t);
    try {
      throw Error(t);
    } catch {}
  }
}
function c(e) {
  let { pathname: t = `/`, search: n = ``, hash: r = `` } = e;
  return (
    n && n !== `?` && (t += n.charAt(0) === `?` ? n : `?` + n),
    r && r !== `#` && (t += r.charAt(0) === `#` ? r : `#` + r),
    t
  );
}
function l(e) {
  let t = {};
  if (e) {
    let n = e.indexOf(`#`);
    n >= 0 && ((t.hash = e.substr(n)), (e = e.substr(0, n)));
    let r = e.indexOf(`?`);
    r >= 0 && ((t.search = e.substr(r)), (e = e.substr(0, r))),
      e && (t.pathname = e);
  }
  return t;
}
var u;
(function (e) {
  (e.data = `data`),
    (e.deferred = `deferred`),
    (e.redirect = `redirect`),
    (e.error = `error`);
})(u || (u = {}));
function d(e, t, n) {
  return n === void 0 && (n = `/`), f(e, t, n, !1);
}
function f(e, t, n, r) {
  let i = C((typeof t == `string` ? l(t) : t).pathname || `/`, n);
  if (i == null) return null;
  let a = p(e);
  h(a);
  let o = null;
  for (let e = 0; o == null && e < a.length; ++e) {
    let t = ae(i);
    o = re(a[e], t, r);
  }
  return o;
}
function p(e, t, n, r) {
  t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = ``);
  let i = (e, i, a) => {
    let s = {
      relativePath: a === void 0 ? e.path || `` : a,
      caseSensitive: e.caseSensitive === !0,
      childrenIndex: i,
      route: e,
    };
    s.relativePath.startsWith(`/`) &&
      (o(
        s.relativePath.startsWith(r),
        `Absolute route path "` +
          s.relativePath +
          `" nested under path ` +
          (`"` + r + `" is not valid. An absolute child route path `) +
          `must start with the combined path of all its parent routes.`
      ),
      (s.relativePath = s.relativePath.slice(r.length)));
    let c = D([r, s.relativePath]),
      l = n.concat(s);
    e.children &&
      e.children.length > 0 &&
      (o(
        e.index !== !0,
        `Index routes must not have child routes. Please remove ` +
          (`all child routes from route path "` + c + `".`)
      ),
      p(e.children, t, l, c)),
      (e.path != null || e.index) &&
        t.push({ path: c, score: te(c, e.index), routesMeta: l });
  };
  return (
    e.forEach((e, t) => {
      var n;
      if (e.path === `` || !((n = e.path) != null && n.includes(`?`))) i(e, t);
      else for (let n of m(e.path)) i(e, t, n);
    }),
    t
  );
}
function m(e) {
  let t = e.split(`/`);
  if (t.length === 0) return [];
  let [n, ...r] = t,
    i = n.endsWith(`?`),
    a = n.replace(/\?$/, ``);
  if (r.length === 0) return i ? [a, ``] : [a];
  let o = m(r.join(`/`)),
    s = [];
  return (
    s.push(...o.map((e) => (e === `` ? a : [a, e].join(`/`)))),
    i && s.push(...o),
    s.map((t) => (e.startsWith(`/`) && t === `` ? `/` : t))
  );
}
function h(e) {
  e.sort((e, t) =>
    e.score === t.score
      ? ne(
          e.routesMeta.map((e) => e.childrenIndex),
          t.routesMeta.map((e) => e.childrenIndex)
        )
      : t.score - e.score
  );
}
var g = /^:[\w-]+$/,
  _ = 3,
  v = 2,
  y = 1,
  b = 10,
  ee = -2,
  x = (e) => e === `*`;
function te(e, t) {
  let n = e.split(`/`),
    r = n.length;
  return (
    n.some(x) && (r += ee),
    t && (r += v),
    n
      .filter((e) => !x(e))
      .reduce((e, t) => e + (g.test(t) ? _ : t === `` ? y : b), r)
  );
}
function ne(e, t) {
  return e.length === t.length && e.slice(0, -1).every((e, n) => e === t[n])
    ? e[e.length - 1] - t[t.length - 1]
    : 0;
}
function re(e, t, n) {
  n === void 0 && (n = !1);
  let { routesMeta: r } = e,
    i = {},
    a = `/`,
    o = [];
  for (let e = 0; e < r.length; ++e) {
    let s = r[e],
      c = e === r.length - 1,
      l = a === `/` ? t : t.slice(a.length) || `/`,
      u = S(
        { path: s.relativePath, caseSensitive: s.caseSensitive, end: c },
        l
      ),
      d = s.route;
    if (
      (!u &&
        c &&
        n &&
        !r[r.length - 1].route.index &&
        (u = S(
          { path: s.relativePath, caseSensitive: s.caseSensitive, end: !1 },
          l
        )),
      !u)
    )
      return null;
    Object.assign(i, u.params),
      o.push({
        params: i,
        pathname: D([a, u.pathname]),
        pathnameBase: le(D([a, u.pathnameBase])),
        route: d,
      }),
      u.pathnameBase !== `/` && (a = D([a, u.pathnameBase]));
  }
  return o;
}
function S(e, t) {
  typeof e == `string` && (e = { path: e, caseSensitive: !1, end: !0 });
  let [n, r] = ie(e.path, e.caseSensitive, e.end),
    i = t.match(n);
  if (!i) return null;
  let a = i[0],
    o = a.replace(/(.)\/+$/, `$1`),
    s = i.slice(1);
  return {
    params: r.reduce((e, t, n) => {
      let { paramName: r, isOptional: i } = t;
      if (r === `*`) {
        let e = s[n] || ``;
        o = a.slice(0, a.length - e.length).replace(/(.)\/+$/, `$1`);
      }
      let c = s[n];
      return (e[r] = i && !c ? void 0 : (c || ``).replace(/%2F/g, `/`)), e;
    }, {}),
    pathname: a,
    pathnameBase: o,
    pattern: e,
  };
}
function ie(e, t, n) {
  t === void 0 && (t = !1),
    n === void 0 && (n = !0),
    s(
      e === `*` || !e.endsWith(`*`) || e.endsWith(`/*`),
      `Route path "` +
        e +
        `" will be treated as if it were ` +
        (`"` + e.replace(/\*$/, `/*`) + '" because the `*` character must ') +
        "always follow a `/` in the pattern. To get rid of this warning, " +
        (`please change the route path to "` + e.replace(/\*$/, `/*`) + `".`)
    );
  let r = [],
    i =
      `^` +
      e
        .replace(/\/*\*?$/, ``)
        .replace(/^\/*/, `/`)
        .replace(/[\\.*+^${}|()[\]]/g, `\\$&`)
        .replace(
          /\/:([\w-]+)(\?)?/g,
          (e, t, n) => (
            r.push({ paramName: t, isOptional: n != null }),
            n ? `/?([^\\/]+)?` : `/([^\\/]+)`
          )
        );
  return (
    e.endsWith(`*`)
      ? (r.push({ paramName: `*` }),
        (i += e === `*` || e === `/*` ? `(.*)$` : `(?:\\/(.+)|\\/*)$`))
      : n
      ? (i += `\\/*$`)
      : e !== `` && e !== `/` && (i += `(?:(?=\\/|$))`),
    [new RegExp(i, t ? void 0 : `i`), r]
  );
}
function ae(e) {
  try {
    return e
      .split(`/`)
      .map((e) => decodeURIComponent(e).replace(/\//g, `%2F`))
      .join(`/`);
  } catch (t) {
    return (
      s(
        !1,
        `The URL path "` +
          e +
          `" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ` +
          (`encoding (` + t + `).`)
      ),
      e
    );
  }
}
function C(e, t) {
  if (t === `/`) return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith(`/`) ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== `/` ? null : e.slice(n) || `/`;
}
function oe(e, t) {
  t === void 0 && (t = `/`);
  let {
    pathname: n,
    search: r = ``,
    hash: i = ``,
  } = typeof e == `string` ? l(e) : e;
  return {
    pathname: n ? (n.startsWith(`/`) ? n : se(n, t)) : t,
    search: ue(r),
    hash: O(i),
  };
}
function se(e, t) {
  let n = t.replace(/\/+$/, ``).split(`/`);
  return (
    e.split(`/`).forEach((e) => {
      e === `..` ? n.length > 1 && n.pop() : e !== `.` && n.push(e);
    }),
    n.length > 1 ? n.join(`/`) : `/`
  );
}
function w(e, t, n, r) {
  return (
    `Cannot include a '` +
    e +
    `' character in a manually specified ` +
    ("`to." +
      t +
      "` field [" +
      JSON.stringify(r) +
      `].  Please separate it out to the `) +
    ("`to." + n + "` field. Alternatively you may provide the full path as ") +
    `a string in <Link to="..."> and the router will parse it for you.`
  );
}
function ce(e) {
  return e.filter(
    (e, t) => t === 0 || (e.route.path && e.route.path.length > 0)
  );
}
function T(e, t) {
  let n = ce(e);
  return t
    ? n.map((e, t) => (t === n.length - 1 ? e.pathname : e.pathnameBase))
    : n.map((e) => e.pathnameBase);
}
function E(e, t, n, r) {
  r === void 0 && (r = !1);
  let a;
  typeof e == `string`
    ? (a = l(e))
    : ((a = i({}, e)),
      o(
        !a.pathname || !a.pathname.includes(`?`),
        w(`?`, `pathname`, `search`, a)
      ),
      o(
        !a.pathname || !a.pathname.includes(`#`),
        w(`#`, `pathname`, `hash`, a)
      ),
      o(!a.search || !a.search.includes(`#`), w(`#`, `search`, `hash`, a)));
  let s = e === `` || a.pathname === ``,
    c = s ? `/` : a.pathname,
    u;
  if (c == null) u = n;
  else {
    let e = t.length - 1;
    if (!r && c.startsWith(`..`)) {
      let t = c.split(`/`);
      for (; t[0] === `..`; ) t.shift(), --e;
      a.pathname = t.join(`/`);
    }
    u = e >= 0 ? t[e] : `/`;
  }
  let d = oe(a, u),
    f = c && c !== `/` && c.endsWith(`/`),
    p = (s || c === `.`) && n.endsWith(`/`);
  return !d.pathname.endsWith(`/`) && (f || p) && (d.pathname += `/`), d;
}
var D = (e) => e.join(`/`).replace(/\/\/+/g, `/`),
  le = (e) => e.replace(/\/+$/, ``).replace(/^\/*/, `/`),
  ue = (e) => (!e || e === `?` ? `` : e.startsWith(`?`) ? e : `?` + e),
  O = (e) => (!e || e === `#` ? `` : e.startsWith(`#`) ? e : `#` + e);
function de(e) {
  return (
    e != null &&
    typeof e.status == `number` &&
    typeof e.statusText == `string` &&
    typeof e.internal == `boolean` &&
    `data` in e
  );
}
var k = [`post`, `put`, `patch`, `delete`];
new Set(k);
var fe = [`get`, ...k];
new Set(fe);
function A() {
  return (
    (A = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    A.apply(this, arguments)
  );
}
var j = r.createContext(null),
  pe = r.createContext(null),
  M = r.createContext(null),
  N = r.createContext(null),
  P = r.createContext({ outlet: null, matches: [], isDataRoute: !1 }),
  F = r.createContext(null);
function me(e, t) {
  let { relative: n } = t === void 0 ? {} : t;
  !I() && o(!1);
  let { basename: i, navigator: a } = r.useContext(M),
    { hash: s, pathname: c, search: l } = B(e, { relative: n }),
    u = c;
  return (
    i !== `/` && (u = c === `/` ? i : D([i, c])),
    a.createHref({ pathname: u, search: l, hash: s })
  );
}
function I() {
  return r.useContext(N) != null;
}
function L() {
  return !I() && o(!1), r.useContext(N).location;
}
function R(e) {
  r.useContext(M).static || r.useLayoutEffect(e);
}
function z() {
  let { isDataRoute: e } = r.useContext(P);
  return e ? De() : he();
}
function he() {
  !I() && o(!1);
  let e = r.useContext(j),
    { basename: t, future: n, navigator: i } = r.useContext(M),
    { matches: a } = r.useContext(P),
    { pathname: s } = L(),
    c = JSON.stringify(T(a, n.v7_relativeSplatPath)),
    l = r.useRef(!1);
  return (
    R(() => {
      l.current = !0;
    }),
    r.useCallback(
      function (n, r) {
        if ((r === void 0 && (r = {}), !l.current)) return;
        if (typeof n == `number`) {
          i.go(n);
          return;
        }
        let a = E(n, JSON.parse(c), s, r.relative === `path`);
        e == null &&
          t !== `/` &&
          (a.pathname = a.pathname === `/` ? t : D([t, a.pathname])),
          (r.replace ? i.replace : i.push)(a, r.state, r);
      },
      [t, i, c, s, e]
    )
  );
}
function ge() {
  let { matches: e } = r.useContext(P),
    t = e[e.length - 1];
  return t ? t.params : {};
}
function B(e, t) {
  let { relative: n } = t === void 0 ? {} : t,
    { future: i } = r.useContext(M),
    { matches: a } = r.useContext(P),
    { pathname: o } = L(),
    s = JSON.stringify(T(a, i.v7_relativeSplatPath));
  return r.useMemo(() => E(e, JSON.parse(s), o, n === `path`), [e, s, o, n]);
}
function _e(e, t) {
  return ve(e, t);
}
function ve(e, t, n, i) {
  !I() && o(!1);
  let { navigator: s } = r.useContext(M),
    { matches: c } = r.useContext(P),
    u = c[c.length - 1],
    f = u ? u.params : {};
  u && u.pathname;
  let p = u ? u.pathnameBase : `/`;
  u && u.route;
  let m = L(),
    h;
  if (t) {
    var g;
    let e = typeof t == `string` ? l(t) : t;
    !(p === `/` || ((g = e.pathname) != null && g.startsWith(p))) && o(!1),
      (h = e);
  } else h = m;
  let _ = h.pathname || `/`,
    v = _;
  if (p !== `/`) {
    let e = p.replace(/^\//, ``).split(`/`);
    v = `/` + _.replace(/^\//, ``).split(`/`).slice(e.length).join(`/`);
  }
  let y = d(e, { pathname: v }),
    b = V(
      y &&
        y.map((e) =>
          Object.assign({}, e, {
            params: Object.assign({}, f, e.params),
            pathname: D([
              p,
              s.encodeLocation
                ? s.encodeLocation(e.pathname).pathname
                : e.pathname,
            ]),
            pathnameBase:
              e.pathnameBase === `/`
                ? p
                : D([
                    p,
                    s.encodeLocation
                      ? s.encodeLocation(e.pathnameBase).pathname
                      : e.pathnameBase,
                  ]),
          })
        ),
      c,
      n,
      i
    );
  return t && b
    ? r.createElement(
        N.Provider,
        {
          value: {
            location: A(
              {
                pathname: `/`,
                search: ``,
                hash: ``,
                state: null,
                key: `default`,
              },
              h
            ),
            navigationType: a.Pop,
          },
        },
        b
      )
    : b;
}
function ye() {
  let e = Ee(),
    t = de(e)
      ? e.status + ` ` + e.statusText
      : e instanceof Error
      ? e.message
      : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null;
  return r.createElement(
    r.Fragment,
    null,
    r.createElement(`h2`, null, `Unexpected Application Error!`),
    r.createElement(`h3`, { style: { fontStyle: `italic` } }, t),
    n
      ? r.createElement(
          `pre`,
          {
            style: {
              padding: `0.5rem`,
              backgroundColor: `rgba(200,200,200, 0.5)`,
            },
          },
          n
        )
      : null,
    null
  );
}
var be = r.createElement(ye, null),
  xe = class extends r.Component {
    constructor(e) {
      super(e),
        (this.state = {
          location: e.location,
          revalidation: e.revalidation,
          error: e.error,
        });
    }
    static getDerivedStateFromError(e) {
      return { error: e };
    }
    static getDerivedStateFromProps(e, t) {
      return t.location !== e.location ||
        (t.revalidation !== `idle` && e.revalidation === `idle`)
        ? { error: e.error, location: e.location, revalidation: e.revalidation }
        : {
            error: e.error === void 0 ? t.error : e.error,
            location: t.location,
            revalidation: e.revalidation || t.revalidation,
          };
    }
    componentDidCatch(e, t) {
      console.error(
        `React Router caught the following error during render`,
        e,
        t
      );
    }
    render() {
      return this.state.error === void 0
        ? this.props.children
        : r.createElement(
            P.Provider,
            { value: this.props.routeContext },
            r.createElement(F.Provider, {
              value: this.state.error,
              children: this.props.component,
            })
          );
    }
  };
function Se(e) {
  let { routeContext: t, match: n, children: i } = e,
    a = r.useContext(j);
  return (
    a &&
      a.static &&
      a.staticContext &&
      (n.route.errorElement || n.route.ErrorBoundary) &&
      (a.staticContext._deepestRenderedBoundaryId = n.route.id),
    r.createElement(P.Provider, { value: t }, i)
  );
}
function V(e, t, n, i) {
  var a;
  if (
    (t === void 0 && (t = []),
    n === void 0 && (n = null),
    i === void 0 && (i = null),
    e == null)
  ) {
    var s;
    if (!n) return null;
    if (n.errors) e = n.matches;
    else if (
      (s = i) != null &&
      s.v7_partialHydration &&
      t.length === 0 &&
      !n.initialized &&
      n.matches.length > 0
    )
      e = n.matches;
    else return null;
  }
  let c = e,
    l = (a = n) == null ? void 0 : a.errors;
  if (l != null) {
    let e = c.findIndex(
      (e) => e.route.id && (l == null ? void 0 : l[e.route.id]) !== void 0
    );
    !(e >= 0) && o(!1), (c = c.slice(0, Math.min(c.length, e + 1)));
  }
  let u = !1,
    d = -1;
  if (n && i && i.v7_partialHydration)
    for (let e = 0; e < c.length; e++) {
      let t = c[e];
      if (
        ((t.route.HydrateFallback || t.route.hydrateFallbackElement) && (d = e),
        t.route.id)
      ) {
        let { loaderData: e, errors: r } = n,
          i =
            t.route.loader &&
            e[t.route.id] === void 0 &&
            (!r || r[t.route.id] === void 0);
        if (t.route.lazy || i) {
          (u = !0), (c = d >= 0 ? c.slice(0, d + 1) : [c[0]]);
          break;
        }
      }
    }
  return c.reduceRight((e, i, a) => {
    let o,
      s = !1,
      f = null,
      p = null;
    n &&
      ((o = l && i.route.id ? l[i.route.id] : void 0),
      (f = i.route.errorElement || be),
      u &&
        (d < 0 && a === 0
          ? (Oe(
              `route-fallback`,
              !1,
              "No `HydrateFallback` element provided to render during initial hydration"
            ),
            (s = !0),
            (p = null))
          : d === a &&
            ((s = !0), (p = i.route.hydrateFallbackElement || null))));
    let m = t.concat(c.slice(0, a + 1)),
      h = () => {
        let t;
        return (
          (t = o
            ? f
            : s
            ? p
            : i.route.Component
            ? r.createElement(i.route.Component, null)
            : i.route.element
            ? i.route.element
            : e),
          r.createElement(Se, {
            match: i,
            routeContext: { outlet: e, matches: m, isDataRoute: n != null },
            children: t,
          })
        );
      };
    return n && (i.route.ErrorBoundary || i.route.errorElement || a === 0)
      ? r.createElement(xe, {
          location: n.location,
          revalidation: n.revalidation,
          component: f,
          error: o,
          children: h(),
          routeContext: { outlet: null, matches: m, isDataRoute: !0 },
        })
      : h();
  }, null);
}
var H = (function (e) {
    return (
      (e.UseBlocker = `useBlocker`),
      (e.UseRevalidator = `useRevalidator`),
      (e.UseNavigateStable = `useNavigate`),
      e
    );
  })(H || {}),
  U = (function (e) {
    return (
      (e.UseBlocker = `useBlocker`),
      (e.UseLoaderData = `useLoaderData`),
      (e.UseActionData = `useActionData`),
      (e.UseRouteError = `useRouteError`),
      (e.UseNavigation = `useNavigation`),
      (e.UseRouteLoaderData = `useRouteLoaderData`),
      (e.UseMatches = `useMatches`),
      (e.UseRevalidator = `useRevalidator`),
      (e.UseNavigateStable = `useNavigate`),
      (e.UseRouteId = `useRouteId`),
      e
    );
  })(U || {});
function Ce(e) {
  let t = r.useContext(j);
  return !t && o(!1), t;
}
function we(e) {
  let t = r.useContext(pe);
  return !t && o(!1), t;
}
function Te(e) {
  let t = r.useContext(P);
  return !t && o(!1), t;
}
function W(e) {
  let t = Te(e),
    n = t.matches[t.matches.length - 1];
  return !n.route.id && o(!1), n.route.id;
}
function Ee() {
  var e;
  let t = r.useContext(F),
    n = we(U.UseRouteError),
    i = W(U.UseRouteError);
  return t === void 0 ? ((e = n.errors) == null ? void 0 : e[i]) : t;
}
function De() {
  let { router: e } = Ce(H.UseNavigateStable),
    t = W(U.UseNavigateStable),
    n = r.useRef(!1);
  return (
    R(() => {
      n.current = !0;
    }),
    r.useCallback(
      function (r, i) {
        i === void 0 && (i = {}),
          n.current &&
            (typeof r == `number`
              ? e.navigate(r)
              : e.navigate(r, A({ fromRouteId: t }, i)));
      },
      [e, t]
    )
  );
}
var G = {};
function Oe(e, t, n) {
  !t && !G[e] && (G[e] = !0);
}
var K = (e, t, n) => (
  `` +
    t +
    ("You can use the `" + e + "` future flag to opt-in early. ") +
    (`For more information, see ` + n + `.`),
  void 0
);
function ke(e, t) {
  (e == null ? void 0 : e.v7_startTransition) === void 0 &&
    K(
      `v7_startTransition`,
      "React Router will begin wrapping state updates in `React.startTransition` in v7",
      `https://reactrouter.com/v6/upgrading/future#v7_starttransition`
    ),
    (e == null ? void 0 : e.v7_relativeSplatPath) === void 0 &&
      (!t || t.v7_relativeSplatPath === void 0) &&
      K(
        `v7_relativeSplatPath`,
        `Relative route resolution within Splat routes is changing in v7`,
        `https://reactrouter.com/v6/upgrading/future#v7_relativesplatpath`
      ),
    t &&
      (t.v7_fetcherPersist === void 0 &&
        K(
          `v7_fetcherPersist`,
          `The persistence behavior of fetchers is changing in v7`,
          `https://reactrouter.com/v6/upgrading/future#v7_fetcherpersist`
        ),
      t.v7_normalizeFormMethod === void 0 &&
        K(
          `v7_normalizeFormMethod`,
          "Casing of `formMethod` fields is being normalized to uppercase in v7",
          `https://reactrouter.com/v6/upgrading/future#v7_normalizeformmethod`
        ),
      t.v7_partialHydration === void 0 &&
        K(
          `v7_partialHydration`,
          "`RouterProvider` hydration behavior is changing in v7",
          `https://reactrouter.com/v6/upgrading/future#v7_partialhydration`
        ),
      t.v7_skipActionErrorRevalidation === void 0 &&
        K(
          `v7_skipActionErrorRevalidation`,
          "The revalidation behavior after 4xx/5xx `action` responses is changing in v7",
          `https://reactrouter.com/v6/upgrading/future#v7_skipactionerrorrevalidation`
        ));
}
function Ae(e) {
  let { to: t, replace: n, state: i, relative: a } = e;
  !I() && o(!1);
  let { future: s, static: c } = r.useContext(M),
    { matches: l } = r.useContext(P),
    { pathname: u } = L(),
    d = z(),
    f = E(t, T(l, s.v7_relativeSplatPath), u, a === `path`),
    p = JSON.stringify(f);
  return (
    r.useEffect(
      () => d(JSON.parse(p), { replace: n, state: i, relative: a }),
      [d, p, a, n, i]
    ),
    null
  );
}
function q(e) {
  o(!1);
}
function je(e) {
  let {
    basename: t = `/`,
    children: n = null,
    location: i,
    navigationType: s = a.Pop,
    navigator: c,
    static: u = !1,
    future: d,
  } = e;
  I() && o(!1);
  let f = t.replace(/^\/*/, `/`),
    p = r.useMemo(
      () => ({
        basename: f,
        navigator: c,
        static: u,
        future: A({ v7_relativeSplatPath: !1 }, d),
      }),
      [f, d, c, u]
    );
  typeof i == `string` && (i = l(i));
  let {
      pathname: m = `/`,
      search: h = ``,
      hash: g = ``,
      state: _ = null,
      key: v = `default`,
    } = i,
    y = r.useMemo(() => {
      let e = C(m, f);
      return e == null
        ? null
        : {
            location: { pathname: e, search: h, hash: g, state: _, key: v },
            navigationType: s,
          };
    }, [f, m, h, g, _, v, s]);
  return y == null
    ? null
    : r.createElement(
        M.Provider,
        { value: p },
        r.createElement(N.Provider, { children: n, value: y })
      );
}
function Me(e) {
  let { children: t, location: n } = e;
  return _e(J(t), n);
}
var Ne = (function (e) {
  return (
    (e[(e.pending = 0)] = `pending`),
    (e[(e.success = 1)] = `success`),
    (e[(e.error = 2)] = `error`),
    e
  );
})(Ne || {});
new Promise(() => {}), r.Component;
function J(e, t) {
  t === void 0 && (t = []);
  let n = [];
  return (
    r.Children.forEach(e, (e, i) => {
      if (!r.isValidElement(e)) return;
      let a = [...t, i];
      if (e.type === r.Fragment) {
        n.push.apply(n, J(e.props.children, a));
        return;
      }
      e.type !== q && o(!1), e.props.index && e.props.children && o(!1);
      let s = {
        id: e.props.id || a.join(`-`),
        caseSensitive: e.props.caseSensitive,
        element: e.props.element,
        Component: e.props.Component,
        index: e.props.index,
        path: e.props.path,
        loader: e.props.loader,
        action: e.props.action,
        errorElement: e.props.errorElement,
        ErrorBoundary: e.props.ErrorBoundary,
        hasErrorBoundary:
          e.props.ErrorBoundary != null || e.props.errorElement != null,
        shouldRevalidate: e.props.shouldRevalidate,
        handle: e.props.handle,
        lazy: e.props.lazy,
      };
      e.props.children && (s.children = J(e.props.children, a)), n.push(s);
    }),
    n
  );
}
function Y() {
  return (
    (Y = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        }),
    Y.apply(this, arguments)
  );
}
function Pe(e, t) {
  if (e == null) return {};
  for (var n = {}, r = Object.keys(e), i, a = 0; a < r.length; a++)
    (i = r[a]), !(t.indexOf(i) >= 0) && (n[i] = e[i]);
  return n;
}
function Fe(e) {
  return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey);
}
function Ie(e, t) {
  return e.button === 0 && (!t || t === `_self`) && !Fe(e);
}
function X(e) {
  return (
    e === void 0 && (e = ``),
    new URLSearchParams(
      typeof e == `string` || Array.isArray(e) || e instanceof URLSearchParams
        ? e
        : Object.keys(e).reduce((t, n) => {
            let r = e[n];
            return t.concat(Array.isArray(r) ? r.map((e) => [n, e]) : [[n, r]]);
          }, [])
    )
  );
}
function Le(e, t) {
  let n = X(e);
  return (
    t &&
      t.forEach((e, r) => {
        n.has(r) ||
          t.getAll(r).forEach((e) => {
            n.append(r, e);
          });
      }),
    n
  );
}
var Re = [
    `onClick`,
    `relative`,
    `reloadDocument`,
    `replace`,
    `state`,
    `target`,
    `to`,
    `preventScrollReset`,
    `viewTransition`,
  ],
  ze = `6`;
try {
  window.__reactRouterVersion = ze;
} catch {}
var Z = r.startTransition;
function Be(e) {
  let { basename: t, children: n, future: i, history: a } = e,
    [o, s] = r.useState({ action: a.action, location: a.location }),
    { v7_startTransition: c } = i || {},
    l = r.useCallback(
      (e) => {
        c && Z ? Z(() => s(e)) : s(e);
      },
      [s, c]
    );
  return (
    r.useLayoutEffect(() => a.listen(l), [a, l]),
    r.useEffect(() => ke(i), [i]),
    r.createElement(je, {
      basename: t,
      children: n,
      location: o.location,
      navigationType: o.action,
      navigator: a,
      future: i,
    })
  );
}
var Ve =
    typeof window < `u` &&
    window.document !== void 0 &&
    window.document.createElement !== void 0,
  He = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  Ue = r.forwardRef(function (e, t) {
    let {
        onClick: n,
        relative: i,
        reloadDocument: a,
        replace: o,
        state: s,
        target: c,
        to: l,
        preventScrollReset: u,
        viewTransition: d,
      } = e,
      f = Pe(e, Re),
      { basename: p } = r.useContext(M),
      m,
      h = !1;
    if (typeof l == `string` && He.test(l) && ((m = l), Ve))
      try {
        let e = new URL(window.location.href),
          t = l.startsWith(`//`) ? new URL(e.protocol + l) : new URL(l),
          n = C(t.pathname, p);
        t.origin === e.origin && n != null
          ? (l = n + t.search + t.hash)
          : (h = !0);
      } catch {}
    let g = me(l, { relative: i }),
      _ = We(l, {
        replace: o,
        state: s,
        target: c,
        preventScrollReset: u,
        relative: i,
        viewTransition: d,
      });
    function v(e) {
      n && n(e), e.defaultPrevented || _(e);
    }
    return r.createElement(
      `a`,
      Y({}, f, { href: m || g, onClick: h || a ? n : v, ref: t, target: c })
    );
  }),
  Q;
(function (e) {
  (e.UseScrollRestoration = `useScrollRestoration`),
    (e.UseSubmit = `useSubmit`),
    (e.UseSubmitFetcher = `useSubmitFetcher`),
    (e.UseFetcher = `useFetcher`),
    (e.useViewTransitionState = `useViewTransitionState`);
})(Q || (Q = {}));
var $;
(function (e) {
  (e.UseFetcher = `useFetcher`),
    (e.UseFetchers = `useFetchers`),
    (e.UseScrollRestoration = `useScrollRestoration`);
})($ || ($ = {}));
function We(e, t) {
  let {
      target: n,
      replace: i,
      state: a,
      preventScrollReset: o,
      relative: s,
      viewTransition: l,
    } = t === void 0 ? {} : t,
    u = z(),
    d = L(),
    f = B(e, { relative: s });
  return r.useCallback(
    (t) => {
      if (Ie(t, n)) {
        t.preventDefault();
        let n = i === void 0 ? c(d) === c(f) : i;
        u(e, {
          replace: n,
          state: a,
          preventScrollReset: o,
          relative: s,
          viewTransition: l,
        });
      }
    },
    [d, u, f, i, a, n, e, o, s, l]
  );
}
function Ge(e) {
  let t = r.useRef(X(e)),
    n = r.useRef(!1),
    i = L(),
    a = r.useMemo(() => Le(i.search, n.current ? null : t.current), [i.search]),
    o = z();
  return [
    a,
    r.useCallback(
      (e, t) => {
        let r = X(typeof e == `function` ? e(a) : e);
        (n.current = !0), o(`?` + r, t);
      },
      [o, a]
    ),
  ];
}
export {
  q as a,
  z as c,
  d,
  Ae as i,
  ge as l,
  Ue as n,
  Me as o,
  Ge as r,
  L as s,
  Be as t,
  S as u,
};
