import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { Ft as n } from "./Compact-CRRKXVA1.js";
var r = e(t()),
  i = {
    items_per_page: `/ page`,
    jump_to: `Go to`,
    jump_to_confirm: `confirm`,
    page: `Page`,
    prev_page: `Previous Page`,
    next_page: `Next Page`,
    prev_5: `Previous 5 Pages`,
    next_5: `Next 5 Pages`,
    prev_3: `Previous 3 Pages`,
    next_3: `Next 3 Pages`,
    page_size: `Page Size`,
  },
  a = n(
    n(
      {},
      {
        yearFormat: `YYYY`,
        dayFormat: `D`,
        cellMeridiemFormat: `A`,
        monthBeforeYear: !0,
      }
    ),
    {},
    {
      locale: `en_US`,
      today: `Today`,
      now: `Now`,
      backToToday: `Back to today`,
      ok: `OK`,
      clear: `Clear`,
      week: `Week`,
      month: `Month`,
      year: `Year`,
      timeSelect: `select time`,
      dateSelect: `select date`,
      weekSelect: `Choose a week`,
      monthSelect: `Choose a month`,
      yearSelect: `Choose a year`,
      decadeSelect: `Choose a decade`,
      dateFormat: `M/D/YYYY`,
      dateTimeFormat: `M/D/YYYY HH:mm:ss`,
      previousMonth: `Previous month (PageUp)`,
      nextMonth: `Next month (PageDown)`,
      previousYear: `Last year (Control + left)`,
      nextYear: `Next year (Control + right)`,
      previousDecade: `Last decade`,
      nextDecade: `Next decade`,
      previousCentury: `Last century`,
      nextCentury: `Next century`,
    }
  ),
  o = {
    placeholder: `Select time`,
    rangePlaceholder: [`Start time`, `End time`],
  },
  s = {
    lang: Object.assign(
      {
        placeholder: `Select date`,
        yearPlaceholder: `Select year`,
        quarterPlaceholder: `Select quarter`,
        monthPlaceholder: `Select month`,
        weekPlaceholder: `Select week`,
        rangePlaceholder: [`Start date`, `End date`],
        rangeYearPlaceholder: [`Start year`, `End year`],
        rangeQuarterPlaceholder: [`Start quarter`, `End quarter`],
        rangeMonthPlaceholder: [`Start month`, `End month`],
        rangeWeekPlaceholder: [`Start week`, `End week`],
      },
      a
    ),
    timePickerLocale: Object.assign({}, o),
  },
  c = s,
  l = "${label} is not a valid ${type}",
  u = {
    locale: `en`,
    Pagination: i,
    DatePicker: s,
    TimePicker: o,
    Calendar: c,
    global: { placeholder: `Please select`, close: `Close` },
    Table: {
      filterTitle: `Filter menu`,
      filterConfirm: `OK`,
      filterReset: `Reset`,
      filterEmptyText: `No filters`,
      filterCheckAll: `Select all items`,
      filterSearchPlaceholder: `Search in filters`,
      emptyText: `No data`,
      selectAll: `Select current page`,
      selectInvert: `Invert current page`,
      selectNone: `Clear all data`,
      selectionAll: `Select all data`,
      sortTitle: `Sort`,
      expand: `Expand row`,
      collapse: `Collapse row`,
      triggerDesc: `Click to sort descending`,
      triggerAsc: `Click to sort ascending`,
      cancelSort: `Click to cancel sorting`,
    },
    Tour: { Next: `Next`, Previous: `Previous`, Finish: `Finish` },
    Modal: { okText: `OK`, cancelText: `Cancel`, justOkText: `OK` },
    Popconfirm: { okText: `OK`, cancelText: `Cancel` },
    Transfer: {
      titles: [``, ``],
      searchPlaceholder: `Search here`,
      itemUnit: `item`,
      itemsUnit: `items`,
      remove: `Remove`,
      selectCurrent: `Select current page`,
      removeCurrent: `Remove current page`,
      selectAll: `Select all data`,
      deselectAll: `Deselect all data`,
      removeAll: `Remove all data`,
      selectInvert: `Invert current page`,
    },
    Upload: {
      uploading: `Uploading...`,
      removeFile: `Remove file`,
      uploadError: `Upload error`,
      previewFile: `Preview file`,
      downloadFile: `Download file`,
    },
    Empty: { description: `No data` },
    Icon: { icon: `icon` },
    Text: {
      edit: `Edit`,
      copy: `Copy`,
      copied: `Copied`,
      expand: `Expand`,
      collapse: `Collapse`,
    },
    Form: {
      optional: `(optional)`,
      defaultValidateMessages: {
        default: "Field validation error for ${label}",
        required: "Please enter ${label}",
        enum: "${label} must be one of [${enum}]",
        whitespace: "${label} cannot be a blank character",
        date: {
          format: "${label} date format is invalid",
          parse: "${label} cannot be converted to a date",
          invalid: "${label} is an invalid date",
        },
        types: {
          string: l,
          method: l,
          array: l,
          object: l,
          number: l,
          date: l,
          boolean: l,
          integer: l,
          float: l,
          regexp: l,
          email: l,
          url: l,
          hex: l,
        },
        string: {
          len: "${label} must be ${len} characters",
          min: "${label} must be at least ${min} characters",
          max: "${label} must be up to ${max} characters",
          range: "${label} must be between ${min}-${max} characters",
        },
        number: {
          len: "${label} must be equal to ${len}",
          min: "${label} must be minimum ${min}",
          max: "${label} must be maximum ${max}",
          range: "${label} must be between ${min}-${max}",
        },
        array: {
          len: "Must be ${len} ${label}",
          min: "At least ${min} ${label}",
          max: "At most ${max} ${label}",
          range: "The amount of ${label} must be between ${min}-${max}",
        },
        pattern: { mismatch: "${label} does not match the pattern ${pattern}" },
      },
    },
    Image: { preview: `Preview` },
    QRCode: {
      expired: `QR code expired`,
      refresh: `Refresh`,
      scanned: `Scanned`,
    },
    ColorPicker: {
      presetEmpty: `Empty`,
      transparent: `Transparent`,
      singleColor: `Single`,
      gradientColor: `Gradient`,
    },
  },
  d = (0, r.createContext)(void 0),
  f = (e, t) => {
    let n = r.useContext(d);
    return [
      r.useMemo(() => {
        let r = t || u[e],
          i = (n == null ? void 0 : n[e]) ?? {};
        return Object.assign(
          Object.assign({}, typeof r == `function` ? r() : r),
          i || {}
        );
      }, [e, t, n]),
      r.useMemo(() => {
        let e = n == null ? void 0 : n.locale;
        return n != null && n.exist && !e ? u.locale : e;
      }, [n]),
    ];
  };
export { i as a, s as i, d as n, u as r, f as t };
