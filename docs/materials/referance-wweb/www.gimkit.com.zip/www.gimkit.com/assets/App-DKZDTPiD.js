import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { O as t, x as n } from "./utils-CV9JYz4f.js";
import { t as r } from "./react-IpA8Qn9U.js";
import { t as i } from "./select-tq7TTR4P.js";
import { t as a } from "./input-CWNNlK6u.js";
import { t as o } from "./input-number-BjcB2pmv.js";
import { h as s, p as c } from "./decorate-DQbPZ5_K.js";
import { t as l } from "./jsx-runtime-CA2T8_y1.js";
import { l as u, s as d } from "./index-DG2EaUNY.js";
import { r as f } from "./mobxreact.esm-CES6mMUm.js";
import { t as p } from "./lodash-QVF93A2Q.js";
import { t as m } from "./Sizes-BSTN-qyL.js";
import { t as h } from "./Hook-UdQWDyyy.js";
import { t as g } from "./AppTypes-D0iU_NZ_.js";
var _ = e(r()),
  v = u.div.attrs({ className: `maxWidth flex vc between` })`
  box-sizing: border-box;
  padding: 13px 20px;
  border-style: solid;
  border-radius: 4px;
  border-width: 1px;
  border-color: rgba(0, 0, 0, 0.2);
  box-shadow: 0 3px 14px 0 rgba(0, 0, 0, 0.12);
  transition: transform 0.23s;
  will-change: transform;
  overflow: hidden;
  &:hover {
    transform: scale(1.02);
  }
`,
  y = u.div.attrs({ className: `flex vc` })``,
  b = u.div`
  font-size: 23px;
  margin-right: 10px;
`,
  x = u.div`
  font-size: 23px;
  font-weight: ${d.Bold};
`,
  S = u.div`
  font-size: 15px;
  margin-top: -2px;
`,
  C = u.div`
  flex-shrink: 0;
  margin-left: 25px;
`,
  w = l(),
  T = (e) =>
    (0, w.jsxs)(v, {
      children: [
        (0, w.jsxs)(y, {
          children: [
            e.emoji ? (0, w.jsx)(b, { children: e.emoji }) : null,
            (0, w.jsxs)(`div`, {
              children: [
                (0, w.jsx)(x, { children: e.title }),
                e.description
                  ? (0, w.jsx)(S, { children: e.description })
                  : null,
              ],
            }),
          ],
        }),
        (0, w.jsx)(C, { children: e.children }),
      ],
    }),
  E = p(),
  D = (e) =>
    (0, w.jsx)(T, {
      emoji: e.emoji,
      title: e.title,
      description: e.description,
      children: (0, w.jsx)(i, {
        value: e.value,
        style: { width: e.customWidth || m.optionWidth },
        size: `large`,
        onChange: (t) => e.onValueChanged(t),
        disabled: e.readOnly,
        children: e.options.map((t) =>
          (0, w.jsx)(
            i.Option,
            { value: t.value, children: t.name },
            `${e.title || `no-title`}-${t.value}`
          )
        ),
      }),
    }),
  O = (e) => (e === `` ? `` : isNaN(Number(e)) ? String(e) : n(Number(e))),
  k = (e) => {
    let [n, r] = _.useState(e.value),
      [i, a] = _.useState(e.value),
      [s, c, l] = t(!1),
      u = (e) => {
        r(e);
      };
    _.useEffect(() => {
      a(e.value), r(e.value);
    }, [e.value]);
    let d = () => {
      n !== i && e.onChange(n), l(), r(e.value);
    };
    return (0, w.jsx)(o, {
      ...e,
      value: s ? n : i,
      onChange: u,
      onFocus: c,
      onBlur: d,
    });
  },
  A = (e) => {
    let t = _.useCallback(
      (t) => {
        if ((0, E.isNil)(t) && e.allowEmpty) return t;
        let n = t ? (e.step ? Math.round(t / e.step) * e.step : t) : 0;
        return (
          !(0, E.isNil)(e.min) && n < e.min
            ? (n = e.min)
            : !(0, E.isNil)(e.max) && n > e.max && (n = e.max),
          n
        );
      },
      [e.max, e.min, e.step]
    );
    _.useEffect(() => {
      (0, E.isNil)(e.value) || (e.max && e.value > e.max && n(t(e.max)));
    }, [e.value, e.max]);
    let n = (n) => {
      e.onValueChanged(t(n));
    };
    return (0, w.jsx)(T, {
      emoji: e.emoji,
      title: e.title,
      description: e.description,
      children: (0, w.jsx)(k, {
        size: `large`,
        formatter: O,
        value: e.value,
        max: e.max,
        min: e.min,
        step: e.step,
        style: { width: e.customWidth || m.optionWidth },
        onChange: n,
        disabled: e.readOnly,
      }),
    });
  },
  j = (e, t) => {
    var n;
    return (n = JSON.parse(localStorage.getItem(g.hookSavedOptions) || `{}`)[
      t
    ]) == null
      ? void 0
      : n[e];
  },
  M = (e) => {
    var t;
    let { hookJSON: n, experienceId: r, kitId: i } = e,
      a = {};
    return (
      n == null ||
        (t = n.hooks) == null ||
        t.forEach((e) => {
          if (e.type === h.kit) a[e.key] = i || ``;
          else if (e.type == h.selectBox) {
            let t = e.options;
            if (t.options.length) {
              let n =
                t.options.find((e) => e === t.defaultOption) || t.options[0];
              if (r) {
                let i = j(e.key, r);
                if (i) {
                  let e = t.options.find((e) => e === i);
                  e && (n = e);
                }
              }
              n && (a[e.key] = n);
            }
          } else if (e.type === h.number) {
            let t = e.options,
              n = t.defaultValue;
            if (r) {
              let i = j(e.key, r);
              if (!(0, E.isNil)(i) && typeof i == `number`) {
                let e = !1;
                ((0, E.isNil)(t.min) || i > t.min) &&
                  ((0, E.isNil)(t.max) || i < t.max) &&
                  ((0, E.isNil)(t.step) || i % t.step === 0) &&
                  (e = !0),
                  e && (n = i);
              }
            }
            a[e.key] = n;
          }
        }),
      a
    );
  },
  N = (e) =>
    (0, w.jsx)(T, {
      emoji: e.emoji,
      title: e.title,
      description: e.description,
      children: (0, w.jsx)(a, {
        size: `large`,
        value: e.value,
        placeholder: e.placeholder,
        style: { width: e.customWidth || m.optionWidth },
        onChange: (t) => {
          e.onValueChanged(t.target.value);
        },
        disabled: e.readOnly,
      }),
    }),
  P = (function (e) {
    return (e.editor = `editor`), (e.experiencePicker = `experiencePicker`), e;
  })({}),
  F = (function (e) {
    return (e.kit = `kit`), e;
  })({}),
  I = (e) => {
    let t, n;
    return (
      (t = e.key),
      e.displayName && (t = e.displayName),
      e.displayDescription && (n = e.displayDescription),
      { title: t, description: n }
    );
  },
  L = (e) => {
    let { title: t, description: n } = I(e.hook);
    if (e.location === P.editor) {
      let e = `We're showing this hook for testing purposes, but this hook won't be visible when choosing this map from the Mode Picker.`;
      n ? (n += ` - ${e}`) : (n = e);
    }
    return (0, w.jsx)(N, {
      title: t,
      description: n,
      value: e.value,
      onValueChanged: e.onChange,
      placeholder: `Kit ID`,
      readOnly: e.readOnly,
    });
  },
  R = (e) => {
    let { title: t, description: n } = I(e.hook),
      r = e.hook.options;
    return (0, w.jsx)(A, {
      title: t,
      description: n,
      value: e.value,
      onValueChanged: (t) => {
        (0, E.isNil)(t) && !(0, E.isNil)(r.defaultValue)
          ? e.onChange(r.defaultValue)
          : e.onChange(t);
      },
      min: r.min,
      max: r.max,
      step: r.step,
      allowEmpty: !0,
      readOnly: e.readOnly,
    });
  },
  z = (e) => {
    let { title: t, description: n } = I(e.hook),
      r = e.hook.options;
    return (0, w.jsx)(D, {
      title: t,
      description: n,
      value: e.value,
      onValueChanged: e.onChange,
      options: r.options.map((e) => ({ value: e, name: e })),
      readOnly: e.readOnly,
    });
  },
  B = (e) => {
    let t = e.state[e.hook.key],
      n = (t) => {
        e.modifyState(e.hook.key, t);
      };
    return e.hook.type === h.selectBox
      ? (0, w.jsx)(z, {
          value: t,
          onChange: n,
          hook: e.hook,
          readOnly: e.readOnly,
        })
      : e.hook.type === h.kit
      ? (0, w.jsx)(L, {
          value: t,
          onChange: n,
          hook: e.hook,
          location: e.location,
          readOnly: e.readOnly,
        })
      : e.hook.type === h.number
      ? (0, w.jsx)(R, {
          value: t,
          onChange: n,
          hook: e.hook,
          readOnly: e.readOnly,
        })
      : null;
  },
  V = (function (e) {
    return (e.hookValue = `hookValue`), (e.modeType = `modeType`), e;
  })({}),
  H = (function (e) {
    return (e.equal = `EQUAL`), (e.notEqual = `NOT_EQUAL`), e;
  })({}),
  U = (function (e) {
    return (e.equal = `EQUAL`), (e.notEqual = `NOT_EQUAL`), e;
  })({}),
  W = (e, t) => {
    var n;
    let r = [];
    return (
      e == null ||
        (n = e.hooks) == null ||
        (n = n.hooks) == null ||
        n.forEach((n) => {
          var i;
          if (
            !(n.type === h.kit && t[n.key] && e.location === P.experiencePicker)
          ) {
            if (n.type === h.selectBox) {
              var a;
              let e = n.options;
              if (!(e != null && (a = e.options) != null && a.length)) return;
            }
            (n != null &&
              (i = n.hiddenScenarios) != null &&
              i.find((n) => {
                var r, i;
                return (r = n.conditions) != null && r.length
                  ? !!(
                      (i = n.conditions) != null &&
                      i.every((n) => {
                        if (n.type === V.hookValue) {
                          let e = n.options,
                            r = e.value,
                            i = t[e.key];
                          if (e.compare === H.equal) {
                            if (r == i) return !0;
                          } else if (e.compare === H.notEqual && r != i)
                            return !0;
                        } else if (n.type === V.modeType) {
                          let t = e.modeType,
                            r = n.options;
                          return r.compare === U.equal
                            ? t === r.mode
                            : t !== r.mode;
                        }
                        return !1;
                      })
                    )
                  : !1;
              })) ||
              r.push(n);
          }
        }),
      r
    );
  },
  G = (e, t) => {
    let n = [];
    return (
      W({ ...e, location: P.editor }, t).forEach((e) => {
        e.type === h.kit &&
          t[e.key] &&
          n.push({ type: F.kit, value: t[e.key] });
      }),
      (0, E.uniqBy)(n, `value`)
    );
  },
  K = f((e) => {
    let [t] = _.useState(() => c(e.defaultState || M({ hookJSON: e.hooks }))),
      n = (e, n) => {
        t[e] = n;
      },
      r = s(t),
      i = JSON.stringify(r);
    _.useEffect(() => {
      e.onConnectedResourcesChange && e.onConnectedResourcesChange(G(e, r)),
        !e.readOnly && e.onStateChange && e.onStateChange(r);
    }, [i, e.readOnly]);
    let a = W(e, r);
    return (0, w.jsxs)(w.Fragment, {
      children: [
        e.header ? e.header(a.length) : null,
        a.map((t, i) =>
          (0, w.jsxs)(
            _.Fragment,
            {
              children: [
                (0, w.jsx)(B, {
                  hook: t,
                  state: r,
                  modifyState: n,
                  location: e.location,
                  readOnly: e.readOnly,
                }),
                i !== a.length - 1 &&
                  (0, w.jsx)(`div`, { style: { height: 10 } }),
              ],
            },
            `hook-form-${t.key}`
          )
        ),
        e.footer ? e.footer(a.length) : null,
      ],
    });
  });
export {
  x as _,
  P as a,
  A as c,
  D as d,
  T as f,
  y as g,
  S as h,
  U as i,
  k as l,
  v as m,
  V as n,
  F as o,
  C as p,
  H as r,
  M as s,
  K as t,
  O as u,
};
