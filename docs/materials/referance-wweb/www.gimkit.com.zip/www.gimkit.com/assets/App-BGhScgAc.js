const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/Authenticated-B_L-au8y.js",
      "assets/rolldown-runtime-C0FnF6B9.js",
      "assets/utils-CV9JYz4f.js",
      "assets/dist-Cmw-iXzl.js",
      "assets/react-IpA8Qn9U.js",
      "assets/modal-Ch5Fwjpt.js",
      "assets/assertThisInitialized-DqpgQyeg.js",
      "assets/Compact-CRRKXVA1.js",
      "assets/color-Dzrzfp-h.js",
      "assets/ContextIsolator-D7w7V6rn.js",
      "assets/dist-CZ_f6czE.js",
      "assets/wrapNativeSuper-BsdumfAK.js",
      "assets/InfoCircleFilled-C11bHdqb.js",
      "assets/compact-item-BOjQ1zv3.js",
      "assets/useLocale-2b_qVRjr.js",
      "assets/useCSSVarCls-7-ltqzGc.js",
      "assets/pickAttrs-DgAKW8il.js",
      "assets/button-Cpfts2Ff.js",
      "assets/PurePanel-CIt2t_IW.js",
      "assets/Company-bnq9XEUn.js",
      "assets/Paths-3vkx8h28.js",
      "assets/decorate-DQbPZ5_K.js",
      "assets/jsx-runtime-CA2T8_y1.js",
      "assets/dropdown-3sTYoCoX.js",
      "assets/tooltip-Yg3f8G0Q.js",
      "assets/es-C_Dx0dL1.js",
      "assets/es-sgMnT67r.js",
      "assets/index-DG2EaUNY.js",
      "assets/dist-BbGQUgM_.js",
      "assets/spin-DkTHPaic.js",
      "assets/QueryClientProvider-Cv8zTiWk.js",
      "assets/queryClient-CqRCNEqN.js",
      "assets/infiniteQueryBehavior-DOR7IVF4.js",
      "assets/index-Tu04tXLf.css",
      "assets/collapse-CVZX-k2a.js",
      "assets/move-2ruV_Z5Z.js",
      "assets/es-Bg8IQMoo.js",
      "assets/EllipsisOutlined-CafYbeLj.js",
      "assets/space-CUvL4cnc.js",
      "assets/App-CE5RJ_0n.js",
      "assets/noop-triWPphM.js",
      "assets/useWarningOnMountInDevelopment-nDZj8mfV.js",
      "assets/FontAwesomeIcon-DXsIaciY.js",
      "assets/lib-BIEg2P_t.js",
      "assets/colors-BC931Gh8.js",
      "assets/SiteHeaderAlpha-D4p9p3aq.js",
      "assets/mobxreact.esm-CES6mMUm.js",
      "assets/NavigateTo-CWRFhxPL.js",
      "assets/Shortcut-BgA2PDii.js",
      "assets/Names-cLrBZ1-_.js",
      "assets/GetPlanName-Ct-tBRkr.js",
      "assets/App-CI2JVlDm.js",
      "assets/message-qrVed8Dv.js",
      "assets/context-BtBbAhyZ.js",
      "assets/input-CWNNlK6u.js",
      "assets/useVariants-Bm4HVCER.js",
      "assets/StarOutlined-BsxCzDLq.js",
      "assets/copy-to-clipboard-CvKIjgDa.js",
      "assets/AccessibleAnchor-DBB6YL1z.js",
      "assets/module-BnqNkjna.js",
      "assets/tiny-invariant-C3zCT6lm.js",
      "assets/TrackPostHogEvent-CU1un-J8.js",
      "assets/price-Cqtaw0ya.js",
      "assets/motion-CBkcxAMn.js",
      "assets/Sizes-BSTN-qyL.js",
    ])
) => i.map((i) => d[i]);
import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { O as t, g as n } from "./utils-CV9JYz4f.js";
import { t as r } from "./react-IpA8Qn9U.js";
import { c as i, s as a } from "./assertThisInitialized-DqpgQyeg.js";
import { n as o } from "./dist-BbGQUgM_.js";
import { r as s } from "./compact-item-BOjQ1zv3.js";
import { a as c } from "./InfoCircleFilled-C11bHdqb.js";
import { t as l } from "./button-Cpfts2Ff.js";
import { t as u } from "./drawer-B0n6VOBn.js";
import { t as d } from "./space-CUvL4cnc.js";
import { E as f, q as p } from "./Paths-3vkx8h28.js";
import { f as m, p as h, t as g } from "./decorate-DQbPZ5_K.js";
import { t as _ } from "./jsx-runtime-CA2T8_y1.js";
import { i as v, n as y, r as b, t as x } from "./SiteHeaderAlpha-D4p9p3aq.js";
import { c as S, h as C, l as w, p as T, v as E } from "./index-DG2EaUNY.js";
import { t as D } from "./AccessibleAnchor-DBB6YL1z.js";
import { r as O } from "./mobxreact.esm-CES6mMUm.js";
import { t as k } from "./module-BnqNkjna.js";
import { t as A } from "./FontAwesomeIcon-DXsIaciY.js";
var j = e(r());
i();
var M = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        { tag: `defs`, attrs: {}, children: [{ tag: `style`, attrs: {} }] },
        {
          tag: `path`,
          attrs: {
            d: `M521.7 82c-152.5-.4-286.7 78.5-363.4 197.7-3.4 5.3.4 12.3 6.7 12.3h70.3c4.8 0 9.3-2.1 12.3-5.8 7-8.5 14.5-16.7 22.4-24.5 32.6-32.5 70.5-58.1 112.7-75.9 43.6-18.4 90-27.8 137.9-27.8 47.9 0 94.3 9.3 137.9 27.8 42.2 17.8 80.1 43.4 112.7 75.9 32.6 32.5 58.1 70.4 76 112.5C865.7 417.8 875 464.1 875 512c0 47.9-9.4 94.2-27.8 137.8-17.8 42.1-43.4 80-76 112.5s-70.5 58.1-112.7 75.9A352.8 352.8 0 01520.6 866c-47.9 0-94.3-9.4-137.9-27.8A353.84 353.84 0 01270 762.3c-7.9-7.9-15.3-16.1-22.4-24.5-3-3.7-7.6-5.8-12.3-5.8H165c-6.3 0-10.2 7-6.7 12.3C234.9 863.2 368.5 942 520.6 942c236.2 0 428-190.1 430.4-425.6C953.4 277.1 761.3 82.6 521.7 82zM395.02 624v-76h-314c-4.4 0-8-3.6-8-8v-56c0-4.4 3.6-8 8-8h314v-76c0-6.7 7.8-10.5 13-6.3l141.9 112a8 8 0 010 12.6l-141.9 112c-5.2 4.1-13 .4-13-6.3z`,
          },
        },
      ],
    },
    name: `login`,
    theme: `outlined`,
  },
  N = j.forwardRef(function (e, t) {
    return j.createElement(s, a({}, e, { ref: t, icon: M }));
  }),
  P = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M904 160H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0 624H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8zm0-312H120c-4.4 0-8 3.6-8 8v64c0 4.4 3.6 8 8 8h784c4.4 0 8-3.6 8-8v-64c0-4.4-3.6-8-8-8z`,
          },
        },
      ],
    },
    name: `menu`,
    theme: `outlined`,
  };
i();
var ee = j.forwardRef(function (e, t) {
    return j.createElement(s, a({}, e, { ref: t, icon: P }));
  }),
  F = (function (e) {
    return (
      (e.profile = `profile`),
      (e.account = `account`),
      (e.gameSettings = `game-settings`),
      (e.billing = `billing`),
      (e.support = `support`),
      e
    );
  })(F || {}),
  I = class {
    constructor() {
      (this.currentTab = F.profile), m(this);
    }
  };
g([h], I.prototype, `currentTab`, void 0);
var L = { navigation: new I() },
  R = j.createContext(L),
  z = b(),
  B = _(),
  V = (e) => {
    let { width: n } = (0, z.useWindowSize)(),
      [r, i, a] = t(!1),
      [o, s] = j.useState(!1),
      [f, p] = j.useState(null),
      m = j.useRef(),
      [h] = k(m),
      g = j.useRef(),
      [_] = k(g);
    return (
      j.useEffect(() => {
        n && h && !_ && (!f || n > f) && p(n);
      }, [n, f, h, _]),
      j.useEffect(() => {
        s(!!(f && n <= f));
      }, [n, f]),
      (0, B.jsx)(c, {
        theme: { token: { borderRadius: 50 } },
        children: (0, B.jsxs)(H, {
          ref: m,
          children: [
            (0, B.jsx)(`div`, { ref: g, style: { flex: 1 } }),
            o
              ? (0, B.jsx)(`div`, {
                  style: { flexShrink: 0 },
                  children: (0, B.jsx)(l, {
                    onClick: i,
                    type: `text`,
                    icon: (0, B.jsx)(ee, {}),
                  }),
                })
              : (0, B.jsx)(U, {
                  style: { opacity: +!!_ },
                  children: (0, B.jsx)(d, {
                    size: 10,
                    direction: `horizontal`,
                    children: e.items.map((e) =>
                      (0, B.jsx)(j.Fragment, { children: e.item(o) }, e.key)
                    ),
                  }),
                }),
            o
              ? (0, B.jsx)(u, {
                  placement: `right`,
                  open: r,
                  onClose: a,
                  children: (0, B.jsx)(d, {
                    size: 12,
                    direction: `vertical`,
                    className: `maxWidth`,
                    children: e.items.map((e) =>
                      (0, B.jsx)(
                        j.Fragment,
                        {
                          children: (0, B.jsx)(`div`, {
                            className: `maxAll flex-center`,
                            children: e.item(o),
                          }),
                        },
                        e.key
                      )
                    ),
                  }),
                })
              : null,
          ],
        }),
      })
    );
  },
  H = w.div`
  flex: 1;
  overflow: hidden;
  display: flex;
`,
  U = w.div`
  flex-shrink: 0;
`,
  W = (e) =>
    (0, B.jsx)(D, {
      to: e.path,
      onClick: e.onClick,
      className: `maxWidth`,
      children: (0, B.jsx)(l, {
        type: `dashed`,
        icon: e.icon,
        block: e.block,
        children: e.children,
      }),
    }),
  G = O(() => {
    let e = () => {
        let e = `/login`;
        return (
          window &&
            window.location &&
            window.location.pathname &&
            window.location.pathname.startsWith(`/view`) &&
            (e += `?location=${encodeURIComponent(window.location.pathname)}`),
          e
        );
      },
      t = v(`(max-width: 850px)`),
      n = [];
    return (
      n.push({
        key: `join`,
        item: (e) =>
          (0, B.jsx)(W, {
            onClick: () => {
              window.open(`/join`, `_self`);
            },
            icon: (0, B.jsx)(A, { name: `far fa-gamepad` }),
            block: e,
            children: `Join Game`,
          }),
      }),
      t ||
        n.push({
          key: `pricing`,
          item: (e) =>
            (0, B.jsx)(W, {
              path: f,
              icon: (0, B.jsx)(A, { name: `far fa-users` }),
              block: e,
              children: `Group Pricing`,
            }),
        }),
      n.push({
        key: `signup`,
        item: (e) =>
          (0, B.jsx)(W, {
            path: p,
            icon: (0, B.jsx)(A, { name: `far fa-user-plus` }),
            block: e,
            children: `Sign Up`,
          }),
      }),
      n.push({
        key: `login`,
        item: (t) =>
          (0, B.jsx)(D, {
            to: e(),
            className: `maxAll`,
            children: (0, B.jsx)(l, {
              type: `primary`,
              size: `large`,
              icon: (0, B.jsx)(N, {}),
              block: t,
              children: `Login`,
            }),
          }),
      }),
      (0, B.jsx)(V, { items: n })
    );
  }),
  K = () =>
    (0, B.jsx)(`div`, {
      style: { height: `var(--header-height)`, flexShrink: 0, width: `100%` },
    }),
  q = `/client/img/svgLogo.svg`,
  J = `/client/img/svgLogoWhite.svg`,
  Y = O((e) => {
    let {
        navigation: { homeUrl: t },
      } = j.useContext(T),
      n = e.theme === y.dark ? J : q;
    return (0, B.jsx)(X, { to: t, children: (0, B.jsx)(Z, { src: n }, n) });
  }),
  X = w(o)``,
  Z = w.img.attrs({ alt: `Gimkit Logo` })`
  height: 32px;
  margin-right: 90px;
`,
  Q = j.lazy(() =>
    C(
      () => import(`./Authenticated-B_L-au8y.js`),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37,
        38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
      ])
    )
  ),
  te = j.lazy(() =>
    C(
      () => import(`./App-CI2JVlDm.js`).then((e) => e.t),
      __vite__mapDeps([
        51, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 52, 53, 54, 26, 27, 28, 29, 30, 31, 32, 33, 55, 56, 57, 58,
        59, 60, 61, 62, 63, 64,
      ])
    )
  ),
  $ = (e) => {
    let [t, r] = j.useState(!1),
      { navigation: i } = j.useContext(T),
      { ref: a, height: o } = (0, z.useComponentSize)();
    j.useEffect(() => {
      document.documentElement.style.setProperty(`--header-height`, `${o}px`),
        (i.headerHeight = o);
    }, [o]);
    let s = () => r(!0),
      l = () => r(!1),
      u = j.useMemo(() => e.theme ?? y.light, [e.theme]),
      d = j.useMemo(() => e.alpha ?? x.standard, [e.alpha]),
      f = j.useMemo(
        () =>
          d === x.none
            ? 1
            : d === x.darker
            ? u === y.light
              ? 0.9
              : 0.75
            : u === y.light
            ? 0.85
            : 0.45,
        [d, u]
      ),
      p = j.useMemo(
        () =>
          u === y.light ? `rgba(255, 255, 255, ${f})` : `rgba(16,16,16, ${f})`,
        [u, d]
      ),
      m = j.useMemo(
        () => (u === y.light ? `rgb(235, 238, 241)` : `rgb(143 143 143 / 60%)`),
        [u, f]
      );
    return (0, B.jsx)(B.Fragment, {
      children: (0, B.jsxs)(c, {
        theme: {
          algorithm: u === y.light ? E.defaultAlgorithm : E.darkAlgorithm,
          token: { fontFamily: S.SFPro },
        },
        children: [
          (0, B.jsxs)(ne, {
            ref: a,
            style: e.containerDivStyle,
            children: [
              (0, B.jsx)(re, {
                $background: p,
                $hideBorder: e.hideBorder,
                $borderColor: m,
                children: (0, B.jsx)(R.Provider, {
                  value: L,
                  children: (0, B.jsxs)(ie, {
                    $signedIn: n(),
                    children: [
                      (0, B.jsx)(Y, { theme: e.theme }),
                      n()
                        ? (0, B.jsx)(j.Suspense, {
                            fallback: null,
                            children: (0, B.jsx)(Q, {
                              showUpgradeModal: s,
                              theme: u,
                            }),
                          })
                        : (0, B.jsx)(G, { theme: e.theme }),
                    ],
                  }),
                }),
              }),
              e.children,
            ],
          }),
          t
            ? (0, B.jsx)(j.Suspense, {
                fallback: null,
                children: (0, B.jsx)(te, {
                  id: `header`,
                  visible: t,
                  close: l,
                  showModes: !0,
                }),
              })
            : null,
          e.includeSpacer ? (0, B.jsx)(K, {}) : null,
        ],
      }),
    });
  },
  ne = w.div.attrs({ className: `maxWidth` })`
  height: auto;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9;
`,
  re = w.header`
  display: flex;
  height: auto;
  background: ${(e) => e.$background};
  backdrop-filter: blur(4px);
  overflow: hidden;
  flex-wrap: wrap;
  align-items: center;
  padding: 15px 25px;
  justify-content: space-between;
  width: 100%;
  box-shadow: inset 0 -1px ${(e) =>
    e.$hideBorder ? `rgba(255,255,255,0)` : e.$borderColor};
  @media print {
    display: none;
  }
`,
  ie = w.div.attrs({ className: `flex maxWidth between vc` })`
  /* Reserve the large navigation button's height before and after lazy loading,
     including when the navigation collapses to the smaller mobile menu. */
  min-height: ${(e) => (e.$signedIn ? `40px` : `0`)};
`,
  ae = (e) => (0, B.jsx)($, { ...e });
export { R as a, N as c, V as i, K as n, L as o, W as r, F as s, ae as t };
