var e = () => !1,
  t = () => {},
  n = () => 5988,
  r = () => {},
  i = () => 1499,
  a = (e, t = !1) => {
    let n = Math.floor(e / 100),
      r = e % 100;
    return t && r === 0 ? `$${n}` : `$${n}.${r.toString().padStart(2, `0`)}`;
  },
  o = (e, t) => {
    let n = e;
    return (
      t != null && t.roundUp && n % 100 != 0 && (n = Math.ceil(n / 100) * 100),
      a(n, (t == null ? void 0 : t.simple) ?? !1)
    );
  },
  s = (e) => o(n(), e),
  c = (e) => a(Math.round(n() / 12), (e == null ? void 0 : e.simple) ?? !1),
  l = (e) => o(i(), e);
export { l as a, e as c, c as i, t as n, r as o, n as r, i as s, s as t };
