import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import {
  Ft as i,
  It as a,
  Lt as o,
  Ut as s,
  lt as c,
  nt as l,
  tt as u,
  ut as d,
  x as f,
} from "./Compact-CRRKXVA1.js";
import { v as p } from "./color-Dzrzfp-h.js";
n(), o(), d(), l();
var m = e(s()),
  h = e(t()),
  g = [
    `prefixCls`,
    `className`,
    `style`,
    `checked`,
    `disabled`,
    `defaultChecked`,
    `type`,
    `title`,
    `onChange`,
  ],
  _ = (0, h.forwardRef)(function (e, t) {
    var n = e.prefixCls,
      o = n === void 0 ? `rc-checkbox` : n,
      s = e.className,
      l = e.style,
      d = e.checked,
      p = e.disabled,
      _ = e.defaultChecked,
      v = _ !== void 0 && _,
      y = e.type,
      b = y === void 0 ? `checkbox` : y,
      x = e.title,
      S = e.onChange,
      C = u(e, g),
      w = (0, h.useRef)(null),
      T = (0, h.useRef)(null),
      E = f(v, { value: d }),
      D = c(E, 2),
      O = D[0],
      k = D[1];
    (0, h.useImperativeHandle)(t, function () {
      return {
        focus: function (e) {
          var t;
          (t = w.current) == null || t.focus(e);
        },
        blur: function () {
          var e;
          (e = w.current) == null || e.blur();
        },
        input: w.current,
        nativeElement: T.current,
      };
    });
    var A = (0, m.default)(
      o,
      s,
      a(a({}, `${o}-checked`, O), `${o}-disabled`, p)
    );
    return h.createElement(
      `span`,
      { className: A, title: x, style: l, ref: T },
      h.createElement(
        `input`,
        r({}, C, {
          className: `${o}-input`,
          ref: w,
          onChange: function (t) {
            p ||
              (`checked` in e || k(t.target.checked),
              S == null ||
                S({
                  target: i(
                    i({}, e),
                    {},
                    { type: b, checked: t.target.checked }
                  ),
                  stopPropagation: function () {
                    t.stopPropagation();
                  },
                  preventDefault: function () {
                    t.preventDefault();
                  },
                  nativeEvent: t.nativeEvent,
                }));
          },
          disabled: p,
          checked: !!O,
          type: b,
        })
      ),
      h.createElement(`span`, { className: `${o}-inner` })
    );
  });
function v(e) {
  let t = h.useRef(null),
    n = () => {
      p.cancel(t.current), (t.current = null);
    };
  return [
    () => {
      n(),
        (t.current = p(() => {
          t.current = null;
        }));
    },
    (r) => {
      t.current && (r.stopPropagation(), n()), e == null || e(r);
    },
  ];
}
export { _ as n, v as t };
