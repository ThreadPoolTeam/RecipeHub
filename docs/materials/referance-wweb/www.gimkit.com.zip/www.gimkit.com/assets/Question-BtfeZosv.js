import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import { r as i } from "./compact-item-BOjQ1zv3.js";
import { t as a } from "./tooltip-Yg3f8G0Q.js";
import { t as o } from "./button-Cpfts2Ff.js";
import { t as s } from "./card-BwiVPEuq.js";
import { t as c } from "./checkbox-iotPIfGb.js";
import { t as l } from "./CopyOutlined-CkgZQzHi.js";
import { t as u } from "./EditOutlined-kJy0G9DP.js";
import { t as d } from "./tag-a8pR6UID.js";
import { t as f } from "./jsx-runtime-CA2T8_y1.js";
import { c as p, l as m, n as h, y as g } from "./index-DG2EaUNY.js";
import { t as _ } from "./FontAwesomeIcon-DXsIaciY.js";
import { t as v } from "./getCloudinaryUrl-CR7quWSQ.js";
import { t as y } from "./LazyLatexRenderer-2fSYYaQ3.js";
import { t as b } from "./ImagePreview-C03s6d62.js";
var x = e(t());
n();
var S = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M842 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 140.3-113.7 254-254 254S258 594.3 258 454c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8 0 168.7 126.6 307.9 290 327.6V884H326.7c-13.7 0-24.7 14.3-24.7 32v36c0 4.4 2.8 8 6.2 8h407.6c3.4 0 6.2-3.6 6.2-8v-36c0-17.7-11-32-24.7-32H548V782.1c165.3-18 294-158 294-328.1zM512 624c93.9 0 170-75.2 170-168V232c0-92.8-76.1-168-170-168s-170 75.2-170 168v224c0 92.8 76.1 168 170 168zm-94-392c0-50.6 41.9-92 94-92s94 41.4 94 92v224c0 50.6-41.9 92-94 92s-94-41.4-94-92V232z`,
          },
        },
      ],
    },
    name: `audio`,
    theme: `outlined`,
  },
  C = x.forwardRef(function (e, t) {
    return x.createElement(i, r({}, e, { ref: t, icon: S }));
  }),
  w = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M696 480H544V328c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v152H328c-4.4 0-8 3.6-8 8v48c0 4.4 3.6 8 8 8h152v152c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V544h152c4.4 0 8-3.6 8-8v-48c0-4.4-3.6-8-8-8z`,
          },
        },
        {
          tag: `path`,
          attrs: {
            d: `M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z`,
          },
        },
      ],
    },
    name: `plus-circle`,
    theme: `outlined`,
  };
n();
var T = x.forwardRef(function (e, t) {
    return x.createElement(i, r({}, e, { ref: t, icon: w }));
  }),
  E = (function (e) {
    return (e.public = `public`), (e.private = `private`), e;
  })({}),
  D = (function (e) {
    return (e.multipleChoice = `mc`), (e.textInput = `text`), e;
  })({}),
  O = (function (e) {
    return (e[(e.exact = 1)] = `exact`), (e[(e.contains = 2)] = `contains`), e;
  })({}),
  k = (function (e) {
    return (e.mapAssignment = `mapAssignment`), e;
  })({}),
  A = (function (e) {
    return (
      (e.completed = `completed`),
      (e.inProgress = `inProgress`),
      (e.notStarted = `notStarted`),
      e
    );
  })({}),
  j = f(),
  M = m.div`
  display: flex;
  align-items: center;
`,
  N = m.div`
  color: ${(e) => (e.customTextColor ? e.customTextColor : h.Black)};
  font-size: ${(e) => (e.customFontSize ? e.customFontSize : 26)}px;
  font-weight: ${(e) => (e.customFontWeight ? e.customFontWeight : 600)};
`,
  P = m.div``,
  F = (e) => {
    var t;
    return (0, j.jsxs)(M, {
      onClick: (t) => (e.blockOutsideClicks ? t.stopPropagation() : null),
      children: [
        e.image &&
          (0, j.jsx)(b, {
            image: e.image,
            size: e.customImageSize || 45,
            customRightMargin: e.customImageMargin || 5,
            showBorder: !0,
          }),
        e.latex
          ? (0, j.jsx)(P, {
              style:
                (t = e.text) != null && t.length
                  ? {
                      color: h.Black,
                      padding: 20,
                      border: `1px solid ${h.Black}`,
                      borderRadius: 5,
                      marginRight: 10,
                      fontSize: e.customFontSize || 26,
                    }
                  : { color: h.Black, fontSize: e.customFontSize || 26 },
              children: (0, j.jsx)(y, { latex: e.latex }),
            })
          : null,
        (0, j.jsx)(N, { ...e, children: e.text }),
      ],
    });
  },
  I = m(s)`
  font-family: ${(e) => (e.$font ? e.$font : p.SFPro)};
  color: ${h.Black};
  margin-bottom: 5px !important;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  min-height: max-content;
  cursor: pointer;
`,
  L = class extends x.Component {
    constructor(...e) {
      super(...e),
        (this.state = { showingAnswers: this.props.showAllAnswers }),
        (this.toggleShowingAnswers = () => {
          this.props.blockToggleShowAnswers ||
            this.setState({ showingAnswers: !this.state.showingAnswers });
        }),
        (this.onAudioPress = (e) => {
          e.stopPropagation(), new Audio(v(this.props.question.audio)).play();
        });
    }
    componentDidUpdate(e) {
      e.showAllAnswers !== this.props.showAllAnswers &&
        (this.props.showAllAnswers
          ? this.setState({ showingAnswers: !0 })
          : this.setState({ showingAnswers: !1 }));
    }
    render() {
      let {
          question: e,
          showCheckbox: t,
          checked: n,
          canEdit: r,
          canAdd: i,
          fontFamily: s,
        } = this.props,
        f = p.SFPro;
      s && (f = s);
      let m = this.props.fontSizeMultiplier || 1,
        h = e.audio && !e.text && !e.image && !e.latex;
      return (0, j.jsxs)(I, {
        $font: f,
        style: this.props.customStyle,
        bodyStyle: Object.assign(this.props.customBodyStyle || {}, {
          width: `100%`,
        }),
        hoverable: !0,
        onClick: this.toggleShowingAnswers,
        children: [
          (0, j.jsxs)(`div`, {
            style: this.props.customContentStyle,
            children: [
              (0, j.jsxs)(`div`, {
                style: { justifyContent: `space-between` },
                className: `flex vc maxWidth`,
                children: [
                  (0, j.jsxs)(`div`, {
                    className: `flex vc`,
                    children: [
                      t &&
                        (0, j.jsx)(c, {
                          style: { zoom: 1.3, marginRight: 10, marginTop: 4 },
                          onChange: this.props.handleCheckChange,
                          onClick: (e) => e.stopPropagation(),
                          checked: n,
                        }),
                      e.source === `ai` &&
                        (0, j.jsx)(a, {
                          title: `This question was generated with AI`,
                          children: (0, j.jsx)(d, {
                            color: `magenta`,
                            style: { marginRight: 10, fontFamily: f },
                            children: (0, j.jsx)(_, {
                              name: `far fa-sparkles`,
                            }),
                          }),
                        }),
                      (0, j.jsx)(F, {
                        text: e.text,
                        image: e.image,
                        latex: e.latex,
                        customFontSize: 26 * m,
                        customImageMargin: 10,
                        customImageSize: 72,
                      }),
                      e.audio &&
                        (0, j.jsx)(a, {
                          title: `Play Audio`,
                          children: (0, j.jsx)(o, {
                            style: {
                              marginLeft: h ? 0 : 10,
                              marginRight: h ? 10 : 0,
                            },
                            type: `primary`,
                            shape: `circle`,
                            icon: (0, j.jsx)(C, {}),
                            onClick: this.onAudioPress,
                          }),
                        }),
                      h &&
                        (0, j.jsx)(F, {
                          text: `Audio Only Question`,
                          customTextColor: `#bdbdbd`,
                        }),
                      e.type === D.textInput &&
                        (0, j.jsx)(d, {
                          color: `magenta`,
                          style: { marginLeft: 10, fontFamily: f },
                          children: `Text Input`,
                        }),
                    ],
                  }),
                  r &&
                    (0, j.jsxs)(`div`, {
                      className: `flex vc`,
                      style: { marginLeft: 10 },
                      children: [
                        (0, j.jsx)(a, {
                          title: `Copy`,
                          placement: `bottom`,
                          children: (0, j.jsx)(o, {
                            shape: `circle`,
                            icon: (0, j.jsx)(l, {}),
                            onClick: this.props.onCopyClicked,
                            size: `small`,
                            style: { marginRight: 5 },
                          }),
                        }),
                        (0, j.jsx)(a, {
                          title: `Edit`,
                          placement: `bottom`,
                          children: (0, j.jsx)(o, {
                            shape: `circle`,
                            icon: (0, j.jsx)(u, {}),
                            size: `small`,
                            onClick: this.props.onEditClicked,
                          }),
                        }),
                      ],
                    }),
                  i &&
                    (0, j.jsx)(a, {
                      title: `Add Question`,
                      placement: `left`,
                      children: (0, j.jsx)(T, {
                        style: { fontSize: 19 },
                        onClick: this.props.onAddClicked,
                      }),
                    }),
                  this.props.customRightComponent
                    ? this.props.customRightComponent
                    : null,
                ],
              }),
              this.state.showingAnswers &&
                (0, j.jsx)(`div`, { style: { height: 12 } }),
              this.state.showingAnswers &&
                (0, j.jsx)(`div`, {
                  className: `maxWidth`,
                  style: { paddingLeft: t ? 34 : 0 },
                  children: e.answers.map((t, n) =>
                    (0, j.jsxs)(
                      x.Fragment,
                      {
                        children: [
                          (0, j.jsxs)(`div`, {
                            className: `flex vc`,
                            children: [
                              (0, j.jsx)(F, {
                                text: t.text,
                                image: t.image,
                                latex: t.latex,
                                customTextColor: t.correct ? `green` : null,
                                customFontSize: 18 * m,
                                customFontWeight: 400,
                                blockOutsideClicks: !0,
                              }),
                              t.image || t.latex
                                ? (0, j.jsx)(d, {
                                    color: t.correct ? `green` : `red`,
                                    style: { marginLeft: t.image ? 2 : 12 },
                                    children: t.correct
                                      ? `Correct`
                                      : `Incorrect`,
                                  })
                                : null,
                            ],
                          }),
                          n + 1 !== e.answers.length &&
                            (0, j.jsx)(g, {
                              style: { marginTop: 6, marginBottom: 6 },
                            }),
                        ],
                      },
                      t._id
                    )
                  ),
                }),
            ],
          }),
          this.props.customBottomComponent
            ? this.props.customBottomComponent
            : null,
        ],
      });
    }
  };
export { D as a, C as c, E as i, A as n, O as o, k as r, T as s, L as t };
