import "./Compact-CRRKXVA1.js";
import { _ as e } from "./color-Dzrzfp-h.js";
import { S as t } from "./ContextIsolator-D7w7V6rn.js";
var n = new e(`antMoveDownIn`, {
    "0%": {
      transform: `translate3d(0, 100%, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
    "100%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
  }),
  r = new e(`antMoveDownOut`, {
    "0%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
    "100%": {
      transform: `translate3d(0, 100%, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
  }),
  i = new e(`antMoveLeftIn`, {
    "0%": {
      transform: `translate3d(-100%, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
    "100%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
  }),
  a = new e(`antMoveLeftOut`, {
    "0%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
    "100%": {
      transform: `translate3d(-100%, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
  }),
  o = new e(`antMoveRightIn`, {
    "0%": {
      transform: `translate3d(100%, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
    "100%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
  }),
  s = new e(`antMoveRightOut`, {
    "0%": {
      transform: `translate3d(0, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 1,
    },
    "100%": {
      transform: `translate3d(100%, 0, 0)`,
      transformOrigin: `0 0`,
      opacity: 0,
    },
  }),
  c = {
    "move-up": {
      inKeyframes: new e(`antMoveUpIn`, {
        "0%": {
          transform: `translate3d(0, -100%, 0)`,
          transformOrigin: `0 0`,
          opacity: 0,
        },
        "100%": {
          transform: `translate3d(0, 0, 0)`,
          transformOrigin: `0 0`,
          opacity: 1,
        },
      }),
      outKeyframes: new e(`antMoveUpOut`, {
        "0%": {
          transform: `translate3d(0, 0, 0)`,
          transformOrigin: `0 0`,
          opacity: 1,
        },
        "100%": {
          transform: `translate3d(0, -100%, 0)`,
          transformOrigin: `0 0`,
          opacity: 0,
        },
      }),
    },
    "move-down": { inKeyframes: n, outKeyframes: r },
    "move-left": { inKeyframes: i, outKeyframes: a },
    "move-right": { inKeyframes: o, outKeyframes: s },
  },
  l = (e, n) => {
    let { antCls: r } = e,
      i = `${r}-${n}`,
      { inKeyframes: a, outKeyframes: o } = c[n];
    return [
      t(i, a, o, e.motionDurationMid),
      {
        [`
        ${i}-enter,
        ${i}-appear
      `]: { opacity: 0, animationTimingFunction: e.motionEaseOutCirc },
        [`${i}-leave`]: { animationTimingFunction: e.motionEaseInOutCirc },
      },
    ];
  };
export { l as t };
