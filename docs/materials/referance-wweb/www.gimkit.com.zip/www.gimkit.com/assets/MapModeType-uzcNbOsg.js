var e = (function (e) {
  return (e.liveGame = `liveGame`), (e.assignment = `assignment`), e;
})({});
export { e as t };
