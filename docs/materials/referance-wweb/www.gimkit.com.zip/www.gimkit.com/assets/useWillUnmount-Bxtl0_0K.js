import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
var n = e(t());
function r(e) {
  (0, n.useEffect)(function () {
    return e;
  }, []);
}
export { r as t };
