import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import { r as i } from "./compact-item-BOjQ1zv3.js";
var a = e(t());
n();
var o = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z`,
          },
        },
      ],
    },
    name: `down`,
    theme: `outlined`,
  },
  s = a.forwardRef(function (e, t) {
    return a.createElement(i, r({}, e, { ref: t, icon: o }));
  });
export { s as t };
