import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { t as n } from "./select-tq7TTR4P.js";
import { i as r, n as i } from "./NameAndPasswordStage-BK5mWxG2.js";
import { W as a, et as o } from "./Paths-3vkx8h28.js";
import { t as s } from "./jsx-runtime-CA2T8_y1.js";
import { y as c } from "./index-DG2EaUNY.js";
import { a as l, i as u, t as d } from "./StoreContext-CNTvAaXw.js";
var f = e(t()),
  p = s(),
  m = [
    `STEM`,
    `Arts`,
    `Communications`,
    `Computer Science`,
    `Counselor`,
    `Deaf Education`,
    `World Languages`,
    `Speech and Language`,
    `English/Language Arts`,
    `American Sign Language`,
    `Science`,
    `Special Education`,
    `Gifted and Talented`,
    `Technology`,
    `Engineering`,
    `Math`,
    `History and Social Studies`,
    `Health/Physical Education`,
    `English Language Learner (ELL)`,
    `Family & Consumer Science (FACS)`,
    `Homeschool`,
    `School Administrator`,
    `Librarian`,
    `Technology/Instructional Coach`,
    `Other`,
  ].sort(),
  h = [
    `Pre-K`,
    `Elementary School`,
    `Middle School`,
    `High School`,
    `Post High School`,
    `Other School`,
    `Not Using For School`,
    `Other`,
  ],
  g = () => {
    let { login: e } = f.useContext(d),
      [t, s] = f.useState(``),
      [g, _] = f.useState(``),
      v = (e) => s(e),
      y = (e) => _(e),
      b = !t || !g;
    return (0, p.jsxs)(p.Fragment, {
      children: [
        (0, p.jsx)(i, { children: `💡 Area of Expertise` }),
        (0, p.jsx)(n, {
          style: { width: `100%` },
          placeholder: `Select one...`,
          size: `large`,
          onChange: v,
          optionFilterProp: `label`,
          showSearch: !0,
          options: m.map((e) => ({ value: e, label: e })),
        }),
        (0, p.jsx)(`div`, { style: { height: 10 } }),
        (0, p.jsx)(i, { children: `🎂 Grade Level` }),
        (0, p.jsx)(n, {
          style: { width: `100%` },
          placeholder: `Select one...`,
          size: `large`,
          onChange: y,
          optionFilterProp: `label`,
          showSearch: !0,
          options: h.map((e) => ({ value: e, label: e })),
        }),
        (0, p.jsx)(l, {
          size: `large`,
          style: { marginTop: 10 },
          disabled: b,
          onClick: () => {
            b ||
              ((e.areaOfExpertise = t),
              (e.gradeLevel = g),
              e.informationNeeded.replace(
                e.informationNeeded.filter(
                  (e) => e !== u.areaOfExpertise && e !== u.gradeLevel
                )
              ));
          },
          children: `Continue`,
        }),
        (0, p.jsx)(c, {}),
        (0, p.jsxs)(`div`, {
          style: { textAlign: `center` },
          children: [
            `By continuing, you agree to our`,
            ` `,
            (0, p.jsx)(`a`, {
              href: a,
              target: `_blank`,
              children: `Privacy Policy`,
            }),
            ` `,
            `and`,
            ` `,
            (0, p.jsx)(`a`, {
              href: o,
              target: `_blank`,
              children: `Terms Of Service`,
            }),
            `.`,
          ],
        }),
        (0, p.jsx)(`div`, { style: { height: 25 } }),
        (0, p.jsx)(r, {
          link: `https://www.notion.so/gimkit/Area-of-Expertise-Grade-Level-a435b570d18844c78f323708686e0f52`,
        }),
      ],
    });
  };
export { m as n, g as t };
