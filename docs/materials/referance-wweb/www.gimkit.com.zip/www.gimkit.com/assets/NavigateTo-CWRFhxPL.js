import { i as e } from "./index-DG2EaUNY.js";
var t = (t) => {
  e.push(t);
};
export { t };
