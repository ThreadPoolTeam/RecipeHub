var e = (e) => e.startsWith(window.location.origin) || e.startsWith(`/`);
export { e as t };
