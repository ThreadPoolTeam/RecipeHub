import {
  a as e,
  n as t,
  o as n,
  r,
  t as i,
} from "./rolldown-runtime-C0FnF6B9.js";
import { Z as a } from "./utils-CV9JYz4f.js";
import { t as o } from "./react-IpA8Qn9U.js";
import {
  c as s,
  l as c,
  n as l,
  s as u,
  t as d,
} from "./assertThisInitialized-DqpgQyeg.js";
import {
  gt as f,
  ht as p,
  it as m,
  nt as h,
  rt as g,
  tt as _,
} from "./Compact-CRRKXVA1.js";
import { f as v, i as y, p as b, t as x } from "./decorate-DQbPZ5_K.js";
import { t as S } from "./jsx-runtime-CA2T8_y1.js";
import { S as C, l as w } from "./index-DG2EaUNY.js";
import { r as ee } from "./mobxreact.esm-CES6mMUm.js";
import { n as te, t as ne } from "./inheritsLoose-BimZ4dLJ.js";
import {
  a as T,
  i as E,
  n as D,
  o as O,
  r as k,
  t as A,
} from "./clsx.m-Cobbdkh4.js";
import {
  _ as re,
  c as ie,
  d as ae,
  f as oe,
  g as se,
  h as ce,
  l as le,
  m as ue,
  o as de,
  p as fe,
  s as j,
  t as pe,
  u as M,
  v as me,
} from "./Tooltip-cUK7XNYH.js";
import { t as N } from "./howler-B0_Qgrar.js";
import { t as P } from "./getCloudinaryUrl-CR7quWSQ.js";
import { t as F } from "./LazyLatexRenderer-2fSYYaQ3.js";
import { t as he } from "./typeof-D4Fcv4W7.js";
var I,
  ge,
  L,
  _e,
  ve = t(() => {
    s(),
      h(),
      (I = n(o())),
      D(),
      T(),
      E(),
      (ge = function (e) {
        return {
          root: {
            userSelect: `none`,
            width: `1em`,
            height: `1em`,
            display: `inline-block`,
            fill: `currentColor`,
            flexShrink: 0,
            fontSize: e.typography.pxToRem(24),
            transition: e.transitions.create(`fill`, {
              duration: e.transitions.duration.shorter,
            }),
          },
          colorPrimary: { color: e.palette.primary.main },
          colorSecondary: { color: e.palette.secondary.main },
          colorAction: { color: e.palette.action.active },
          colorError: { color: e.palette.error.main },
          colorDisabled: { color: e.palette.action.disabled },
          fontSizeInherit: { fontSize: `inherit` },
          fontSizeSmall: { fontSize: e.typography.pxToRem(20) },
          fontSizeLarge: { fontSize: e.typography.pxToRem(35) },
        };
      }),
      (L = I.forwardRef(function (e, t) {
        var n = e.children,
          r = e.classes,
          i = e.className,
          a = e.color,
          o = a === void 0 ? `inherit` : a,
          s = e.component,
          c = s === void 0 ? `svg` : s,
          l = e.fontSize,
          d = l === void 0 ? `medium` : l,
          f = e.htmlColor,
          p = e.titleAccess,
          m = e.viewBox,
          h = m === void 0 ? `0 0 24 24` : m,
          g = _(e, [
            `children`,
            `classes`,
            `className`,
            `color`,
            `component`,
            `fontSize`,
            `htmlColor`,
            `titleAccess`,
            `viewBox`,
          ]);
        return I.createElement(
          c,
          u(
            {
              className: A(
                r.root,
                i,
                o !== `inherit` && r[`color${k(o)}`],
                d !== "default" && d !== `medium` && r[`fontSize${k(d)}`]
              ),
              focusable: `false`,
              viewBox: h,
              color: f,
              "aria-hidden": !p || void 0,
              role: p ? `img` : void 0,
              ref: t,
            },
            g
          ),
          n,
          p ? I.createElement(`title`, null, p) : null
        );
      })),
      (L.muiName = `SvgIcon`),
      (_e = O(ge, { name: `MuiSvgIcon` })(L));
  }),
  ye = t(() => {
    ve();
  });
function be(e, t) {
  var n = function (t, n) {
    return R.createElement(_e, u({ ref: n }, t), e);
  };
  return (n.muiName = _e.muiName), R.memo(R.forwardRef(n));
}
var R,
  xe = t(() => {
    s(), (R = n(o())), ye();
  });
function Se(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 166,
    n;
  function r() {
    var r = [...arguments],
      i = this;
    clearTimeout(n),
      (n = setTimeout(function () {
        e.apply(i, r);
      }, t));
  }
  return (
    (r.clear = function () {
      clearTimeout(n);
    }),
    r
  );
}
var Ce = t(() => {});
function we(e, t) {
  return function () {
    return null;
  };
}
var Te = t(() => {});
function z(e, t) {
  return Ee.isValidElement(e) && t.indexOf(e.type.muiName) !== -1;
}
var Ee,
  De = t(() => {
    Ee = n(o());
  });
function B(e) {
  return (e && e.ownerDocument) || document;
}
var V = t(() => {});
function Oe(e) {
  return B(e).defaultView || window;
}
var ke = t(() => {
  V();
});
function Ae(e) {
  return function () {
    return null;
  };
}
var je = t(() => {});
function Me(e, t, n, r, i) {
  return null;
}
var Ne = t(() => {});
function H(e) {
  var t = U.useRef(e);
  return (
    Pe(function () {
      t.current = e;
    }),
    U.useCallback(function () {
      return t.current.apply(void 0, arguments);
    }, [])
  );
}
var U,
  Pe,
  Fe = t(() => {
    (U = n(o())), (Pe = typeof window < `u` ? U.useLayoutEffect : U.useEffect);
  }),
  Ie = r({
    capitalize: () => k,
    createChainedFunction: () => re,
    createSvgIcon: () => be,
    debounce: () => Se,
    deprecatedPropType: () => we,
    isMuiElement: () => z,
    ownerDocument: () => B,
    ownerWindow: () => Oe,
    requirePropFactory: () => Ae,
    setRef: () => se,
    unstable_useId: () => M,
    unsupportedProp: () => Me,
    useControlled: () => ue,
    useEventCallback: () => H,
    useForkRef: () => oe,
    useIsFocusVisible: () => ie,
  }),
  Le = t(() => {
    E(),
      me(),
      xe(),
      Ce(),
      Te(),
      De(),
      V(),
      ke(),
      je(),
      ce(),
      Ne(),
      fe(),
      Fe(),
      ae(),
      le(),
      j();
  }),
  Re = n(c());
l(), m(), te();
var W = n(o());
function ze(e, t) {
  var n = function (e) {
      return t && (0, W.isValidElement)(e) ? t(e) : e;
    },
    r = Object.create(null);
  return (
    e &&
      W.Children.map(e, function (e) {
        return e;
      }).forEach(function (e) {
        r[e.key] = n(e);
      }),
    r
  );
}
function Be(e, t) {
  (e = e || {}), (t = t || {});
  function n(n) {
    return n in t ? t[n] : e[n];
  }
  var r = Object.create(null),
    i = [];
  for (var a in e) a in t ? i.length && ((r[a] = i), (i = [])) : i.push(a);
  var o,
    s = {};
  for (var c in t) {
    if (r[c])
      for (o = 0; o < r[c].length; o++) {
        var l = r[c][o];
        s[r[c][o]] = n(l);
      }
    s[c] = n(c);
  }
  for (o = 0; o < i.length; o++) s[i[o]] = n(i[o]);
  return s;
}
function G(e, t, n) {
  return n[t] == null ? e.props[t] : n[t];
}
function Ve(e, t) {
  return ze(e.children, function (n) {
    return (0,
    W.cloneElement)(n, { onExited: t.bind(null, n), in: !0, appear: G(n, `appear`, e), enter: G(n, `enter`, e), exit: G(n, `exit`, e) });
  });
}
function He(e, t, n) {
  var r = ze(e.children),
    i = Be(t, r);
  return (
    Object.keys(i).forEach(function (a) {
      var o = i[a];
      if ((0, W.isValidElement)(o)) {
        var s = a in t,
          c = a in r,
          l = t[a],
          u = (0, W.isValidElement)(l) && !l.props.in;
        c && (!s || u)
          ? (i[a] = (0, W.cloneElement)(o, {
              onExited: n.bind(null, o),
              in: !0,
              exit: G(o, `exit`, e),
              enter: G(o, `enter`, e),
            }))
          : !c && s && !u
          ? (i[a] = (0, W.cloneElement)(o, { in: !1 }))
          : c &&
            s &&
            (0, W.isValidElement)(l) &&
            (i[a] = (0, W.cloneElement)(o, {
              onExited: n.bind(null, o),
              in: l.props.in,
              exit: G(o, `exit`, e),
              enter: G(o, `enter`, e),
            }));
      }
    }),
    i
  );
}
s();
var Ue =
    Object.values ||
    function (e) {
      return Object.keys(e).map(function (t) {
        return e[t];
      });
    },
  We = {
    component: `div`,
    childFactory: function (e) {
      return e;
    },
  },
  Ge = (function (e) {
    ne(t, e);
    function t(t, n) {
      var r = e.call(this, t, n) || this;
      return (
        (r.state = {
          contextValue: { isMounting: !0 },
          handleExited: r.handleExited.bind(d(r)),
          firstRender: !0,
        }),
        r
      );
    }
    var n = t.prototype;
    return (
      (n.componentDidMount = function () {
        (this.mounted = !0),
          this.setState({ contextValue: { isMounting: !1 } });
      }),
      (n.componentWillUnmount = function () {
        this.mounted = !1;
      }),
      (t.getDerivedStateFromProps = function (e, t) {
        var n = t.children,
          r = t.handleExited;
        return {
          children: t.firstRender ? Ve(e, r) : He(e, n, r),
          firstRender: !1,
        };
      }),
      (n.handleExited = function (e, t) {
        var n = ze(this.props.children);
        e.key in n ||
          (e.props.onExited && e.props.onExited(t),
          this.mounted &&
            this.setState(function (t) {
              var n = u({}, t.children);
              return delete n[e.key], { children: n };
            }));
      }),
      (n.render = function () {
        var e = this.props,
          t = e.component,
          n = e.childFactory,
          r = g(e, [`component`, `childFactory`]),
          i = this.state.contextValue,
          a = Ue(this.state.children).map(n);
        return (
          delete r.appear,
          delete r.enter,
          delete r.exit,
          t === null
            ? W.createElement(de.Provider, { value: i }, a)
            : W.createElement(
                de.Provider,
                { value: i },
                W.createElement(t, r, a)
              )
        );
      }),
      t
    );
  })(W.Component);
(Ge.propTypes = {}), (Ge.defaultProps = We), f(), D(), Fe();
var Ke = typeof window > `u` ? W.useEffect : W.useLayoutEffect;
function qe(e) {
  var t = e.classes,
    n = e.pulsate,
    r = n !== void 0 && n,
    i = e.rippleX,
    a = e.rippleY,
    o = e.rippleSize,
    s = e.in,
    c = e.onExited,
    l = c === void 0 ? function () {} : c,
    u = e.timeout,
    d = W.useState(!1),
    f = d[0],
    p = d[1],
    m = A(t.ripple, t.rippleVisible, r && t.ripplePulsate),
    h = { width: o, height: o, top: -(o / 2) + a, left: -(o / 2) + i },
    g = A(t.child, f && t.childLeaving, r && t.childPulsate),
    _ = H(l);
  return (
    Ke(
      function () {
        if (!s) {
          p(!0);
          var e = setTimeout(_, u);
          return function () {
            clearTimeout(e);
          };
        }
      },
      [_, s, u]
    ),
    W.createElement(
      `span`,
      { className: m, style: h },
      W.createElement(`span`, { className: g })
    )
  );
}
s(), h(), D(), T();
var Je = 550,
  Ye = function (e) {
    return {
      root: {
        overflow: `hidden`,
        pointerEvents: `none`,
        position: `absolute`,
        zIndex: 0,
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        borderRadius: `inherit`,
      },
      ripple: { opacity: 0, position: `absolute` },
      rippleVisible: {
        opacity: 0.3,
        transform: `scale(1)`,
        animation: `$enter ${Je}ms ${e.transitions.easing.easeInOut}`,
      },
      ripplePulsate: {
        animationDuration: `${e.transitions.duration.shorter}ms`,
      },
      child: {
        opacity: 1,
        display: `block`,
        width: `100%`,
        height: `100%`,
        borderRadius: `50%`,
        backgroundColor: `currentColor`,
      },
      childLeaving: {
        opacity: 0,
        animation: `$exit ${Je}ms ${e.transitions.easing.easeInOut}`,
      },
      childPulsate: {
        position: `absolute`,
        left: 0,
        top: 0,
        animation: `$pulsate 2500ms ${e.transitions.easing.easeInOut} 200ms infinite`,
      },
      "@keyframes enter": {
        "0%": { transform: `scale(0)`, opacity: 0.1 },
        "100%": { transform: `scale(1)`, opacity: 0.3 },
      },
      "@keyframes exit": { "0%": { opacity: 1 }, "100%": { opacity: 0 } },
      "@keyframes pulsate": {
        "0%": { transform: `scale(1)` },
        "50%": { transform: `scale(0.92)` },
        "100%": { transform: `scale(1)` },
      },
    };
  },
  Xe = W.forwardRef(function (e, t) {
    var n = e.center,
      r = n !== void 0 && n,
      i = e.classes,
      a = e.className,
      o = _(e, [`center`, `classes`, `className`]),
      s = W.useState([]),
      c = s[0],
      l = s[1],
      d = W.useRef(0),
      f = W.useRef(null);
    W.useEffect(
      function () {
        f.current && (f.current(), (f.current = null));
      },
      [c]
    );
    var m = W.useRef(!1),
      h = W.useRef(null),
      g = W.useRef(null),
      v = W.useRef(null);
    W.useEffect(function () {
      return function () {
        clearTimeout(h.current);
      };
    }, []);
    var y = W.useCallback(
        function (e) {
          var t = e.pulsate,
            n = e.rippleX,
            r = e.rippleY,
            a = e.rippleSize,
            o = e.cb;
          l(function (e) {
            return [].concat(p(e), [
              W.createElement(qe, {
                key: d.current,
                classes: i,
                timeout: Je,
                pulsate: t,
                rippleX: n,
                rippleY: r,
                rippleSize: a,
              }),
            ]);
          }),
            (d.current += 1),
            (f.current = o);
        },
        [i]
      ),
      b = W.useCallback(
        function () {
          var e =
              arguments.length > 0 && arguments[0] !== void 0
                ? arguments[0]
                : {},
            t =
              arguments.length > 1 && arguments[1] !== void 0
                ? arguments[1]
                : {},
            n = arguments.length > 2 ? arguments[2] : void 0,
            i = t.pulsate,
            a = i !== void 0 && i,
            o = t.center,
            s = o === void 0 ? r || t.pulsate : o,
            c = t.fakeElement,
            l = c !== void 0 && c;
          if (e.type === `mousedown` && m.current) m.current = !1;
          else {
            e.type === `touchstart` && (m.current = !0);
            var u = l ? null : v.current,
              d = u
                ? u.getBoundingClientRect()
                : { width: 0, height: 0, left: 0, top: 0 },
              f,
              p,
              _;
            if (
              s ||
              (e.clientX === 0 && e.clientY === 0) ||
              (!e.clientX && !e.touches)
            )
              (f = Math.round(d.width / 2)), (p = Math.round(d.height / 2));
            else {
              var b = e.touches ? e.touches[0] : e,
                x = b.clientX,
                S = b.clientY;
              (f = Math.round(x - d.left)), (p = Math.round(S - d.top));
            }
            if (s)
              (_ = Math.sqrt((2 * d.width ** 2 + d.height ** 2) / 3)),
                _ % 2 == 0 && (_ += 1);
            else {
              var C =
                  Math.max(Math.abs((u ? u.clientWidth : 0) - f), f) * 2 + 2,
                w = Math.max(Math.abs((u ? u.clientHeight : 0) - p), p) * 2 + 2;
              _ = Math.sqrt(C ** 2 + w ** 2);
            }
            e.touches
              ? g.current === null &&
                ((g.current = function () {
                  y({
                    pulsate: a,
                    rippleX: f,
                    rippleY: p,
                    rippleSize: _,
                    cb: n,
                  });
                }),
                (h.current = setTimeout(function () {
                  g.current && (g.current(), (g.current = null));
                }, 80)))
              : y({ pulsate: a, rippleX: f, rippleY: p, rippleSize: _, cb: n });
          }
        },
        [r, y]
      ),
      x = W.useCallback(
        function () {
          b({}, { pulsate: !0 });
        },
        [b]
      ),
      S = W.useCallback(function (e, t) {
        clearTimeout(h.current),
          e.type === `touchend` && g.current
            ? (e.persist(),
              g.current(),
              (g.current = null),
              (h.current = setTimeout(function () {
                S(e, t);
              })))
            : ((g.current = null),
              l(function (e) {
                return e.length > 0 ? e.slice(1) : e;
              }),
              (f.current = t));
      }, []);
    return (
      W.useImperativeHandle(
        t,
        function () {
          return { pulsate: x, start: b, stop: S };
        },
        [x, b, S]
      ),
      W.createElement(
        `span`,
        u({ className: A(i.root, a), ref: v }, o),
        W.createElement(Ge, { component: null, exit: !0 }, c)
      )
    );
  }),
  Ze = O(Ye, { flip: !1, name: `MuiTouchRipple` })(W.memo(Xe));
s(), h(), D(), ae(), Fe(), T(), j();
var Qe = {
    root: {
      display: `inline-flex`,
      alignItems: `center`,
      justifyContent: `center`,
      position: `relative`,
      WebkitTapHighlightColor: `transparent`,
      backgroundColor: `transparent`,
      outline: 0,
      border: 0,
      margin: 0,
      borderRadius: 0,
      padding: 0,
      cursor: `pointer`,
      userSelect: `none`,
      verticalAlign: `middle`,
      "-moz-appearance": `none`,
      "-webkit-appearance": `none`,
      textDecoration: `none`,
      color: `inherit`,
      "&::-moz-focus-inner": { borderStyle: `none` },
      "&$disabled": { pointerEvents: `none`, cursor: `default` },
      "@media print": { colorAdjust: `exact` },
    },
    disabled: {},
    focusVisible: {},
  },
  $e = W.forwardRef(function (e, t) {
    var n = e.action,
      r = e.buttonRef,
      i = e.centerRipple,
      a = i !== void 0 && i,
      o = e.children,
      s = e.classes,
      c = e.className,
      l = e.component,
      d = l === void 0 ? `button` : l,
      f = e.disabled,
      p = f !== void 0 && f,
      m = e.disableRipple,
      h = m !== void 0 && m,
      g = e.disableTouchRipple,
      v = g !== void 0 && g,
      y = e.focusRipple,
      b = y !== void 0 && y,
      x = e.focusVisibleClassName,
      S = e.onBlur,
      C = e.onClick,
      w = e.onFocus,
      ee = e.onFocusVisible,
      te = e.onKeyDown,
      ne = e.onKeyUp,
      T = e.onMouseDown,
      E = e.onMouseLeave,
      D = e.onMouseUp,
      O = e.onTouchEnd,
      k = e.onTouchMove,
      re = e.onTouchStart,
      ae = e.onDragLeave,
      se = e.tabIndex,
      ce = se === void 0 ? 0 : se,
      le = e.TouchRippleProps,
      ue = e.type,
      de = ue === void 0 ? `button` : ue,
      fe = _(
        e,
        `action.buttonRef.centerRipple.children.classes.className.component.disabled.disableRipple.disableTouchRipple.focusRipple.focusVisibleClassName.onBlur.onClick.onFocus.onFocusVisible.onKeyDown.onKeyUp.onMouseDown.onMouseLeave.onMouseUp.onTouchEnd.onTouchMove.onTouchStart.onDragLeave.tabIndex.TouchRippleProps.type`.split(
          `.`
        )
      ),
      j = W.useRef(null);
    function pe() {
      return Re.findDOMNode(j.current);
    }
    var M = W.useRef(null),
      me = W.useState(!1),
      N = me[0],
      P = me[1];
    p && N && P(!1);
    var F = ie(),
      he = F.isFocusVisible,
      I = F.onBlurVisible,
      ge = F.ref;
    W.useImperativeHandle(
      n,
      function () {
        return {
          focusVisible: function () {
            P(!0), j.current.focus();
          },
        };
      },
      []
    ),
      W.useEffect(
        function () {
          N && b && !h && M.current.pulsate();
        },
        [h, b, N]
      );
    function L(e, t) {
      var n =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : v;
      return H(function (r) {
        return t && t(r), !n && M.current && M.current[e](r), !0;
      });
    }
    var _e = L(`start`, T),
      ve = L(`stop`, ae),
      ye = L(`stop`, D),
      be = L(`stop`, function (e) {
        N && e.preventDefault(), E && E(e);
      }),
      R = L(`start`, re),
      xe = L(`stop`, O),
      Se = L(`stop`, k),
      Ce = L(
        `stop`,
        function (e) {
          N && (I(e), P(!1)), S && S(e);
        },
        !1
      ),
      we = H(function (e) {
        j.current || (j.current = e.currentTarget),
          he(e) && (P(!0), ee && ee(e)),
          w && w(e);
      }),
      Te = function () {
        var e = pe();
        return d && d !== `button` && !(e.tagName === `A` && e.href);
      },
      z = W.useRef(!1),
      Ee = H(function (e) {
        b &&
          !z.current &&
          N &&
          M.current &&
          e.key === ` ` &&
          ((z.current = !0),
          e.persist(),
          M.current.stop(e, function () {
            M.current.start(e);
          })),
          e.target === e.currentTarget &&
            Te() &&
            e.key === ` ` &&
            e.preventDefault(),
          te && te(e),
          e.target === e.currentTarget &&
            Te() &&
            e.key === `Enter` &&
            !p &&
            (e.preventDefault(), C && C(e));
      }),
      De = H(function (e) {
        b &&
          e.key === ` ` &&
          M.current &&
          N &&
          !e.defaultPrevented &&
          ((z.current = !1),
          e.persist(),
          M.current.stop(e, function () {
            M.current.pulsate(e);
          })),
          ne && ne(e),
          C &&
            e.target === e.currentTarget &&
            Te() &&
            e.key === ` ` &&
            !e.defaultPrevented &&
            C(e);
      }),
      B = d;
    B === `button` && fe.href && (B = `a`);
    var V = {};
    B === `button`
      ? ((V.type = de), (V.disabled = p))
      : ((B !== `a` || !fe.href) && (V.role = `button`),
        (V[`aria-disabled`] = p));
    var Oe = oe(r, t),
      ke = oe(ge, j),
      Ae = oe(Oe, ke),
      je = W.useState(!1),
      Me = je[0],
      Ne = je[1];
    W.useEffect(function () {
      Ne(!0);
    }, []);
    var U = Me && !h && !p;
    return W.createElement(
      B,
      u(
        {
          className: A(s.root, c, N && [s.focusVisible, x], p && s.disabled),
          onBlur: Ce,
          onClick: C,
          onFocus: we,
          onKeyDown: Ee,
          onKeyUp: De,
          onMouseDown: _e,
          onMouseLeave: be,
          onMouseUp: ye,
          onDragLeave: ve,
          onTouchEnd: xe,
          onTouchMove: Se,
          onTouchStart: R,
          ref: Ae,
          tabIndex: p ? -1 : ce,
        },
        V,
        fe
      ),
      o,
      U ? W.createElement(Ze, u({ ref: M, center: a }, le)) : null
    );
  }),
  et = O(Qe, { name: `MuiButtonBase` })($e);
h(), s(), D(), T(), E();
var tt = function (e) {
    return {
      root: u({}, e.typography.button, {
        boxSizing: `border-box`,
        minHeight: 36,
        transition: e.transitions.create(
          [`background-color`, `box-shadow`, `border`],
          { duration: e.transitions.duration.short }
        ),
        borderRadius: `50%`,
        padding: 0,
        minWidth: 0,
        width: 56,
        height: 56,
        boxShadow: e.shadows[6],
        "&:active": { boxShadow: e.shadows[12] },
        color: e.palette.getContrastText(e.palette.grey[300]),
        backgroundColor: e.palette.grey[300],
        "&:hover": {
          backgroundColor: e.palette.grey.A100,
          "@media (hover: none)": { backgroundColor: e.palette.grey[300] },
          "&$disabled": {
            backgroundColor: e.palette.action.disabledBackground,
          },
          textDecoration: `none`,
        },
        "&$focusVisible": { boxShadow: e.shadows[6] },
        "&$disabled": {
          color: e.palette.action.disabled,
          boxShadow: e.shadows[0],
          backgroundColor: e.palette.action.disabledBackground,
        },
      }),
      label: {
        width: `100%`,
        display: `inherit`,
        alignItems: `inherit`,
        justifyContent: `inherit`,
      },
      primary: {
        color: e.palette.primary.contrastText,
        backgroundColor: e.palette.primary.main,
        "&:hover": {
          backgroundColor: e.palette.primary.dark,
          "@media (hover: none)": { backgroundColor: e.palette.primary.main },
        },
      },
      secondary: {
        color: e.palette.secondary.contrastText,
        backgroundColor: e.palette.secondary.main,
        "&:hover": {
          backgroundColor: e.palette.secondary.dark,
          "@media (hover: none)": { backgroundColor: e.palette.secondary.main },
        },
      },
      extended: {
        borderRadius: 24,
        padding: `0 16px`,
        width: `auto`,
        minHeight: `auto`,
        minWidth: 48,
        height: 48,
        "&$sizeSmall": {
          width: `auto`,
          padding: `0 8px`,
          borderRadius: 17,
          minWidth: 34,
          height: 34,
        },
        "&$sizeMedium": {
          width: `auto`,
          padding: `0 16px`,
          borderRadius: 20,
          minWidth: 40,
          height: 40,
        },
      },
      focusVisible: {},
      disabled: {},
      colorInherit: { color: `inherit` },
      sizeSmall: { width: 40, height: 40 },
      sizeMedium: { width: 48, height: 48 },
    };
  },
  nt = W.forwardRef(function (e, t) {
    var n = e.children,
      r = e.classes,
      i = e.className,
      a = e.color,
      o = a === void 0 ? `default` : a,
      s = e.component,
      c = s === void 0 ? `button` : s,
      l = e.disabled,
      d = l !== void 0 && l,
      f = e.disableFocusRipple,
      p = f !== void 0 && f,
      m = e.focusVisibleClassName,
      h = e.size,
      g = h === void 0 ? `large` : h,
      v = e.variant,
      y = v === void 0 ? `circular` : v,
      b = _(e, [
        `children`,
        `classes`,
        `className`,
        `color`,
        `component`,
        `disabled`,
        `disableFocusRipple`,
        `focusVisibleClassName`,
        `size`,
        `variant`,
      ]);
    return W.createElement(
      et,
      u(
        {
          className: A(
            r.root,
            i,
            g !== `large` && r[`size${k(g)}`],
            d && r.disabled,
            y === `extended` && r.extended,
            {
              primary: r.primary,
              secondary: r.secondary,
              inherit: r.colorInherit,
            }[o]
          ),
          component: c,
          disabled: d,
          focusRipple: !p,
          focusVisibleClassName: A(r.focusVisible, m),
          ref: t,
        },
        b
      ),
      W.createElement(`span`, { className: r.label }, n)
    );
  }),
  rt = O(tt, { name: `MuiFab` })(nt),
  it = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.default = t);
    function t(e, t) {
      if (e === t) return !0;
      var n = Object.keys(e),
        r = Object.keys(t);
      if (n.length !== r.length) return !1;
      for (var i = Object.prototype.hasOwnProperty, a = 0; a < n.length; a++)
        if (!i.call(t, n[a]) || e[n[a]] !== t[n[a]]) return !1;
      return !0;
    }
  }),
  at = i((e) => {
    Object.defineProperties(e, {
      __esModule: { value: !0 },
      [Symbol.toStringTag]: { value: `Module` },
    });
    function t(e) {
      return e &&
        e.__esModule &&
        Object.prototype.hasOwnProperty.call(e, `default`)
        ? e.default
        : e;
    }
    var n = { exports: {} },
      r = (n.exports = {}),
      i,
      a;
    function o() {
      throw Error(`setTimeout has not been defined`);
    }
    function s() {
      throw Error(`clearTimeout has not been defined`);
    }
    (function () {
      try {
        i = typeof setTimeout == `function` ? setTimeout : o;
      } catch {
        i = o;
      }
      try {
        a = typeof clearTimeout == `function` ? clearTimeout : s;
      } catch {
        a = s;
      }
    })();
    function c(e) {
      if (i === setTimeout) return setTimeout(e, 0);
      if ((i === o || !i) && setTimeout)
        return (i = setTimeout), setTimeout(e, 0);
      try {
        return i(e, 0);
      } catch {
        try {
          return i.call(null, e, 0);
        } catch {
          return i.call(this, e, 0);
        }
      }
    }
    function l(e) {
      if (a === clearTimeout) return clearTimeout(e);
      if ((a === s || !a) && clearTimeout)
        return (a = clearTimeout), clearTimeout(e);
      try {
        return a(e);
      } catch {
        try {
          return a.call(null, e);
        } catch {
          return a.call(this, e);
        }
      }
    }
    var u = [],
      d = !1,
      f,
      p = -1;
    function m() {
      d &&
        f &&
        ((d = !1), f.length ? (u = f.concat(u)) : (p = -1), u.length && h());
    }
    function h() {
      if (!d) {
        var e = c(m);
        d = !0;
        for (var t = u.length; t; ) {
          for (f = u, u = []; ++p < t; ) f && f[p].run();
          (p = -1), (t = u.length);
        }
        (f = null), (d = !1), l(e);
      }
    }
    r.nextTick = function (e) {
      var t = Array(arguments.length - 1);
      if (arguments.length > 1)
        for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
      u.push(new g(e, t)), u.length === 1 && !d && c(h);
    };
    function g(e, t) {
      (this.fun = e), (this.array = t);
    }
    (g.prototype.run = function () {
      this.fun.apply(null, this.array);
    }),
      (r.title = `browser`),
      (r.browser = !0),
      (r.env = {}),
      (r.argv = []),
      (r.version = ``),
      (r.versions = {});
    function _() {}
    (r.on = _),
      (r.addListener = _),
      (r.once = _),
      (r.off = _),
      (r.removeListener = _),
      (r.removeAllListeners = _),
      (r.emit = _),
      (r.prependListener = _),
      (r.prependOnceListener = _),
      (r.listeners = function (e) {
        return [];
      }),
      (r.binding = function (e) {
        throw Error(`process.binding is not supported`);
      }),
      (r.cwd = function () {
        return `/`;
      }),
      (r.chdir = function (e) {
        throw Error(`process.chdir is not supported`);
      }),
      (r.umask = function () {
        return 0;
      });
    var v = n.exports,
      y = t(v);
    (e.default = y), (e.process = y);
  }),
  ot = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.default = r);
    var t = n(at());
    function n(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function r(e, n) {
      var r = [],
        i = 0,
        a = !0;
      function o(e) {
        function i() {
          n && n(e, r);
        }
        a ? t.default.nextTick(i) : i();
      }
      function s(t, n) {
        r.push(n), ++i >= e.length || t ? o(t) : e[i](s);
      }
      e.length > 0 ? e[0](s) : o(null), (a = !1);
    }
  }),
  st = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.default = n);
    var t = function () {};
    function n(e, n) {
      var r =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : t;
      e()
        ? n(function t(i) {
            var a = [...arguments].slice(1);
            i ? r(i) : e.apply(this, a) ? n(t) : r(null);
          })
        : r(null);
    }
  }),
  ct = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.default = t);
    function t(e, t) {
      var n = void 0,
        r = void 0,
        i = void 0,
        a = void 0,
        o = 0;
      function s() {
        (a = 0), (o = +new Date()), (i = e.apply(n, r)), (n = null), (r = null);
      }
      return function () {
        (n = this), (r = arguments);
        var e = new Date() - o;
        return a || (e >= t ? s() : (a = setTimeout(s, t - e))), i;
      };
    }
  }),
  lt = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.default = n);
    var t = 0;
    function n() {
      return t++;
    }
  }),
  ut = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }),
      (e.innerHeight = t),
      (e.innerWidth = n);
    function t(e) {
      var t = window.getComputedStyle(e, null);
      return t
        ? e.clientHeight -
            parseInt(t.getPropertyValue(`padding-top`), 10) -
            parseInt(t.getPropertyValue(`padding-bottom`), 10)
        : e.clientHeight;
    }
    function n(e) {
      var t = window.getComputedStyle(e, null);
      return t
        ? e.clientWidth -
            parseInt(t.getPropertyValue(`padding-left`), 10) -
            parseInt(t.getPropertyValue(`padding-right`), 10)
        : e.clientWidth;
    }
  }),
  dt = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t =
        Object.assign ||
        function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n)
              Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
          }
          return e;
        },
      n = (function () {
        function e(e, t) {
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            (r.enumerable = r.enumerable || !1),
              (r.configurable = !0),
              `value` in r && (r.writable = !0),
              Object.defineProperty(e, r.key, r);
          }
        }
        return function (t, n, r) {
          return n && e(t.prototype, n), r && e(t, r), t;
        };
      })(),
      r = p(o()),
      i = p(a()),
      s = p(it()),
      c = p(ot()),
      l = p(st()),
      u = p(ct()),
      d = p(lt()),
      f = ut();
    function p(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function m(e, t) {
      var n = {};
      for (var r in e)
        t.indexOf(r) >= 0 ||
          (Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]));
      return n;
    }
    function h(e, t) {
      if (!(e instanceof t))
        throw TypeError(`Cannot call a class as a function`);
    }
    function g(e, t) {
      if (!e)
        throw ReferenceError(
          `this hasn't been initialised - super() hasn't been called`
        );
      return t && (typeof t == `object` || typeof t == `function`) ? t : e;
    }
    function _(e, t) {
      if (typeof t != `function` && t !== null)
        throw TypeError(
          `Super expression must either be null or a function, not ` + typeof t
        );
      (e.prototype = Object.create(t && t.prototype, {
        constructor: {
          value: e,
          enumerable: !1,
          writable: !0,
          configurable: !0,
        },
      })),
        t &&
          (Object.setPrototypeOf
            ? Object.setPrototypeOf(e, t)
            : (e.__proto__ = t));
    }
    function v(e, t) {
      return e.scrollWidth - 1 <= t;
    }
    function y(e, t) {
      return e.scrollHeight - 1 <= t;
    }
    function b() {}
    var x = (function (e) {
      _(i, e);
      function i(e) {
        h(this, i);
        var t = g(
          this,
          (i.__proto__ || Object.getPrototypeOf(i)).call(this, e)
        );
        return (
          (t.state = { fontSize: null, ready: !1 }),
          (t.handleWindowResize = function () {
            t.process();
          }),
          `perfectFit` in e &&
            console.warn(`TextFit property perfectFit has been removed.`),
          (t.handleWindowResize = (0, u.default)(
            t.handleWindowResize,
            e.throttle
          )),
          t
        );
      }
      return (
        n(i, [
          {
            key: `componentDidMount`,
            value: function () {
              this.props.autoResize &&
                window.addEventListener(`resize`, this.handleWindowResize),
                this.process();
            },
          },
          {
            key: `componentDidUpdate`,
            value: function (e) {
              this.state.ready &&
                ((0, s.default)(this.props, e) || this.process());
            },
          },
          {
            key: `componentWillUnmount`,
            value: function () {
              this.props.autoResize &&
                window.removeEventListener(`resize`, this.handleWindowResize),
                (this.pid = (0, d.default)());
            },
          },
          {
            key: `process`,
            value: function () {
              var e = this,
                t = this.props,
                n = t.min,
                r = t.max,
                i = t.mode,
                a = t.forceSingleModeWidth,
                o = t.onReady,
                s = this._parent,
                u = this._child,
                p = (0, f.innerWidth)(s),
                m = (0, f.innerHeight)(s);
              if (m <= 0 || isNaN(m))
                console.warn(
                  `Can not process element without height. Make sure the element is displayed and has a static height.`
                );
              else if (p <= 0 || isNaN(p))
                console.warn(
                  `Can not process element without width. Make sure the element is displayed and has a static width.`
                );
              else {
                var h = (0, d.default)();
                this.pid = h;
                var g = function () {
                    return h !== e.pid;
                  },
                  _ =
                    i === `multi`
                      ? function () {
                          return y(u, m);
                        }
                      : function () {
                          return v(u, p);
                        },
                  b =
                    i === `multi`
                      ? function () {
                          return v(u, p);
                        }
                      : function () {
                          return y(u, m);
                        },
                  x = void 0,
                  S = n,
                  C = r;
                this.setState({ ready: !1 }),
                  (0, c.default)(
                    [
                      function (t) {
                        return (0, l.default)(
                          function () {
                            return S <= C;
                          },
                          function (t) {
                            if (g()) return t(!0);
                            (x = parseInt((S + C) / 2, 10)),
                              e.setState({ fontSize: x }, function () {
                                return g()
                                  ? t(!0)
                                  : (_() ? (S = x + 1) : (C = x - 1), t());
                              });
                          },
                          t
                        );
                      },
                      function (t) {
                        return (i === `single` && a) || b()
                          ? t()
                          : ((S = n),
                            (C = x),
                            (0, l.default)(
                              function () {
                                return S < C;
                              },
                              function (t) {
                                if (g()) return t(!0);
                                (x = parseInt((S + C) / 2, 10)),
                                  e.setState({ fontSize: x }, function () {
                                    return h === e.pid
                                      ? (b() ? (S = x + 1) : (C = x - 1), t())
                                      : t(!0);
                                  });
                              },
                              t
                            ));
                      },
                      function (t) {
                        if (
                          ((x = Math.min(S, C)),
                          (x = Math.max(x, n)),
                          (x = Math.min(x, r)),
                          (x = Math.max(x, 0)),
                          g())
                        )
                          return t(!0);
                        e.setState({ fontSize: x }, t);
                      },
                    ],
                    function (t) {
                      t ||
                        g() ||
                        e.setState({ ready: !0 }, function () {
                          return o(x);
                        });
                    }
                  );
              }
            },
          },
          {
            key: `render`,
            value: function () {
              var e = this,
                n = this.props,
                i = n.children,
                a = n.text,
                o = n.style;
              n.min, n.max;
              var s = n.mode;
              n.forceWidth,
                n.forceSingleModeWidth,
                n.throttle,
                n.autoResize,
                n.onReady;
              var c = m(n, [
                  `children`,
                  `text`,
                  `style`,
                  `min`,
                  `max`,
                  `mode`,
                  `forceWidth`,
                  `forceSingleModeWidth`,
                  `throttle`,
                  `autoResize`,
                  `onReady`,
                ]),
                l = this.state,
                u = l.fontSize,
                d = l.ready,
                f = t({}, o, { fontSize: u }),
                p = { display: d ? `block` : `inline-block` };
              return (
                s === `single` && (p.whiteSpace = `nowrap`),
                r.default.createElement(
                  `div`,
                  t(
                    {
                      ref: function (t) {
                        return (e._parent = t);
                      },
                      style: f,
                    },
                    c
                  ),
                  r.default.createElement(
                    `div`,
                    {
                      ref: function (t) {
                        return (e._child = t);
                      },
                      style: p,
                    },
                    a && typeof i == `function` ? (d ? i(a) : a) : i
                  )
                )
              );
            },
          },
        ]),
        i
      );
    })(r.default.Component);
    (x.propTypes = {
      children: i.default.node,
      text: i.default.string,
      min: i.default.number,
      max: i.default.number,
      mode: i.default.oneOf([`single`, `multi`]),
      forceSingleModeWidth: i.default.bool,
      throttle: i.default.number,
      onReady: i.default.func,
    }),
      (x.defaultProps = {
        min: 1,
        max: 100,
        mode: `multi`,
        forceSingleModeWidth: !0,
        throttle: 50,
        autoResize: !0,
        onReady: b,
      }),
      (e.default = x);
  }),
  ft = i((e) => {
    Object.defineProperty(e, "__esModule", { value: !0 }), (e.Textfit = void 0);
    var t = n(dt());
    function n(e) {
      return e && e.__esModule ? e : { default: e };
    }
    (e.Textfit = t.default), (e.default = t.default);
  }),
  K = S(),
  pt = N(),
  mt = ft(),
  ht = (function (e) {
    return (e.multipleChoice = `mc`), (e.textInput = `text`), e;
  })({}),
  gt = (function (e) {
    return (e[(e.exact = 1)] = `exact`), (e[(e.contains = 2)] = `contains`), e;
  })({}),
  _t = (e, t) =>
    (0, K.jsx)(`span`, {
      className: e ? `` : `notranslate lang-en`,
      children: t,
    }),
  vt = (e) =>
    e && (e.isTrusted === !0 || e.isTrusted === !1) ? e.isTrusted : !0,
  yt = (e, t) => {
    t && vt(e) && t();
  },
  bt = (e, t) => {
    if (!t) return !1;
    let n = !1;
    return (
      e &&
        e.answers.find((n) => {
          if (n.correct) {
            if (e.type === ht.multipleChoice) return t === n._id;
            if (e.type === ht.textInput) {
              let e = xt(t),
                r = xt(n.text),
                i = n.textType ?? gt.exact;
              if (i === gt.exact) return e === r;
              if (i === gt.contains) return e.includes(r);
            }
          }
          return !1;
        }) &&
        (n = !0),
      n
    );
  },
  xt = (e) => {
    let t = e.trim();
    return (
      (t = t.replace(/[\u2018\u2019]/g, `'`).replace(/[\u201C\u201D]/g, `"`)),
      (t = t.toLowerCase()),
      t
    );
  };
function St(e) {
  "@babel/helpers - typeof";
  return (
    (St =
      typeof Symbol == `function` && typeof Symbol.iterator == `symbol`
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              typeof Symbol == `function` &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? `symbol`
              : typeof e;
          }),
    St(e)
  );
}
function Ct(e, t) {
  if (!(e instanceof t)) throw TypeError(`Cannot call a class as a function`);
}
function wt(e, t) {
  for (var n = 0; n < t.length; n++) {
    var r = t[n];
    (r.enumerable = r.enumerable || !1),
      (r.configurable = !0),
      `value` in r && (r.writable = !0),
      Object.defineProperty(e, r.key, r);
  }
}
function Tt(e, t, n) {
  return (
    t && wt(e.prototype, t),
    n && wt(e, n),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    e
  );
}
function Et(e, t) {
  if (typeof t != `function` && t !== null)
    throw TypeError(`Super expression must either be null or a function`);
  (e.prototype = Object.create(t && t.prototype, {
    constructor: { value: e, writable: !0, configurable: !0 },
  })),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    t && Dt(e, t);
}
function Dt(e, t) {
  return (
    (Dt = Object.setPrototypeOf
      ? Object.setPrototypeOf.bind()
      : function (e, t) {
          return (e.__proto__ = t), e;
        }),
    Dt(e, t)
  );
}
function Ot(e) {
  var t = jt();
  return function () {
    var n = Mt(e),
      r;
    if (t) {
      var i = Mt(this).constructor;
      r = Reflect.construct(n, arguments, i);
    } else r = n.apply(this, arguments);
    return kt(this, r);
  };
}
function kt(e, t) {
  if (t && (St(t) === `object` || typeof t == `function`)) return t;
  if (t !== void 0)
    throw TypeError(`Derived constructors may only return object or undefined`);
  return At(e);
}
function At(e) {
  if (e === void 0)
    throw ReferenceError(
      `this hasn't been initialised - super() hasn't been called`
    );
  return e;
}
function jt() {
  if (typeof Reflect > `u` || !Reflect.construct || Reflect.construct.sham)
    return !1;
  if (typeof Proxy == `function`) return !0;
  try {
    return (
      Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      ),
      !0
    );
  } catch {
    return !1;
  }
}
function Mt(e) {
  return (
    (Mt = Object.setPrototypeOf
      ? Object.getPrototypeOf.bind()
      : function (e) {
          return e.__proto__ || Object.getPrototypeOf(e);
        }),
    Mt(e)
  );
}
function Nt(e, t) {
  if (!document.head.querySelector(`#` + e)) {
    var n = document.createElement(`style`);
    (n.textContent = t),
      (n.type = `text/css`),
      (n.id = e),
      document.head.appendChild(n);
  }
}
var Pt = (function (e) {
    Et(n, e);
    var t = Ot(n);
    function n() {
      return Ct(this, n), t.apply(this, arguments);
    }
    return (
      Tt(n, [
        {
          key: `componentDidMount`,
          value: function () {
            Nt(this.props.name, this.props.css);
          },
        },
        {
          key: `componentWillUnmount`,
          value: function () {
            var e = document.getElementById(this.props.name);
            e.parentNode.removeChild(e);
          },
        },
        {
          key: `render`,
          value: function () {
            return null;
          },
        },
      ]),
      n
    );
  })(W.Component),
  Ft = function (e) {
    var t = e.imageBackgroundColor;
    return `
  body {
    overflow: hidden;
  }

  .__react_modal_image__modal_container {
    position: fixed;
    z-index: 5000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.8);
    touch-action: none;
    overflow: hidden;
  }

  .__react_modal_image__modal_content {
    position: relative;
    height: 100%;
    width: 100%;
  }

  .__react_modal_image__modal_content img, 
  .__react_modal_image__modal_content svg {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate3d(-50%, -50%, 0);
    -webkit-transform: translate3d(-50%, -50%, 0);
    -ms-transform: translate3d(-50%, -50%, 0);
    overflow: hidden;
  }

  .__react_modal_image__medium_img {
    max-width: 98%;
    max-height: 98%;
    background-color: ${t};
  }

  .__react_modal_image__large_img {
    cursor: move;
    background-color: ${t}
  }

  .__react_modal_image__icon_menu a {
    display: inline-block;
    font-size: 40px;
    cursor: pointer;
    line-height: 40px;
    box-sizing: border-box;
    border: none;
    padding: 0px 5px 0px 5px;
    margin-left: 10px;
    color: white;
    background-color: rgba(0, 0, 0, 0);
  }

  .__react_modal_image__icon_menu {
    display: inline-block;
    float: right;
  }

  .__react_modal_image__caption {
    display: inline-block;
    color: white;
    font-size: 120%;
    padding: 10px;
    margin: 0;
  }

  .__react_modal_image__header {
    position: absolute;
    top: 0;
    width: 100%;
    background-color: rgba(0, 0, 0, 0.7);
    overflow: hidden;
  }
`;
  },
  It = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        height: `24`,
        viewBox: `0 0 24 24`,
        width: `24`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, { d: `M0 0h24v24H0z`, fill: `none` }),
      W.createElement(`path`, {
        d: `M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z`,
      })
    );
  },
  Lt = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        height: `24`,
        viewBox: `0 0 24 24`,
        width: `24`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, { d: `M0 0h24v24H0z`, fill: `none` }),
      W.createElement(`path`, {
        d: `M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z`,
      })
    );
  },
  Rt = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        height: `24`,
        viewBox: `0 0 24 24`,
        width: `24`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, {
        d: `M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z`,
      }),
      W.createElement(`path`, { d: `M0 0h24v24H0z`, fill: `none` })
    );
  },
  zt = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        height: `24`,
        viewBox: `0 0 24 24`,
        width: `24`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, {
        d: `M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z`,
      }),
      W.createElement(`path`, { d: `M0 0h24v24H0z`, fill: `none` })
    );
  },
  Bt = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        height: `48`,
        viewBox: `0 0 24 24`,
        width: `48`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, {
        d: `M6 2v6h.01L6 8.01 10 12l-4 4 .01.01H6V22h12v-5.99h-.01L18 16l-4-4 4-3.99-.01-.01H18V2H6zm10 14.5V20H8v-3.5l4-4 4 4zm-4-5l-4-4V4h8v3.5l-4 4z`,
      }),
      W.createElement(`path`, { d: `M0 0h24v24H0V0z`, fill: `none` })
    );
  },
  Vt = function () {
    return W.createElement(
      `svg`,
      {
        fill: `#ffffff`,
        width: `24`,
        height: `24`,
        viewBox: `0 0 24 24`,
        xmlns: `http://www.w3.org/2000/svg`,
      },
      W.createElement(`path`, {
        fill: `none`,
        d: `M0 0h24v24H0V0zm0 0h24v24H0V0z`,
      }),
      W.createElement(`path`, {
        d: `M7.47 21.49C4.2 19.93 1.86 16.76 1.5 13H0c.51 6.16 5.66 11 11.95 11 .23 0 .44-.02.66-.03L8.8 20.15l-1.33 1.34zM12.05 0c-.23 0-.44.02-.66.04l3.81 3.81 1.33-1.33C19.8 4.07 22.14 7.24 22.5 11H24c-.51-6.16-5.66-11-11.95-11zM16 14h2V8c0-1.11-.9-2-2-2h-6v2h6v6zm-8 2V4H6v2H4v2h2v8c0 1.1.89 2 2 2h8v2h2v-2h2v-2H8z`,
      })
    );
  };
function Ht(e) {
  return document.location.hostname !== new URL(e, document.location).hostname;
}
var Ut = function (e) {
    return function (t) {
      Ht(e) &&
        (t.preventDefault(),
        fetch(e)
          .then(function (t) {
            return (
              t.ok ||
                console.error(
                  `Failed to download image, HTTP status ` +
                    t.status +
                    ` from ` +
                    e
                ),
              t.blob().then(function (t) {
                var n = document.createElement(`a`);
                n.setAttribute(`download`, e.split(`/`).pop()),
                  (n.href = URL.createObjectURL(t)),
                  n.click();
              })
            );
          })
          .catch(function (t) {
            console.error(t),
              console.error(`Failed to download image from ` + e);
          }));
    };
  },
  Wt = function (e) {
    var t = e.image,
      n = e.alt,
      r = e.zoomed,
      i = e.toggleZoom,
      a = e.toggleRotate,
      o = e.onClose,
      s = e.enableDownload,
      c = e.enableZoom,
      l = e.enableRotate;
    return W.createElement(
      `div`,
      { className: `__react_modal_image__header` },
      W.createElement(
        `span`,
        { className: `__react_modal_image__icon_menu` },
        s &&
          W.createElement(
            `a`,
            { href: t, download: !0, onClick: Ut(t) },
            W.createElement(Rt, null)
          ),
        c &&
          W.createElement(
            `a`,
            { onClick: i },
            r ? W.createElement(Lt, null) : W.createElement(It, null)
          ),
        l && W.createElement(`a`, { onClick: a }, W.createElement(Vt, null)),
        W.createElement(`a`, { onClick: o }, W.createElement(zt, null))
      ),
      n &&
        W.createElement(
          `span`,
          { className: `__react_modal_image__caption` },
          n
        )
    );
  };
function Gt(e) {
  "@babel/helpers - typeof";
  return (
    (Gt =
      typeof Symbol == `function` && typeof Symbol.iterator == `symbol`
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              typeof Symbol == `function` &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? `symbol`
              : typeof e;
          }),
    Gt(e)
  );
}
function Kt(e, t) {
  if (!(e instanceof t)) throw TypeError(`Cannot call a class as a function`);
}
function qt(e, t) {
  for (var n = 0; n < t.length; n++) {
    var r = t[n];
    (r.enumerable = r.enumerable || !1),
      (r.configurable = !0),
      `value` in r && (r.writable = !0),
      Object.defineProperty(e, r.key, r);
  }
}
function Jt(e, t, n) {
  return (
    t && qt(e.prototype, t),
    n && qt(e, n),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    e
  );
}
function Yt(e, t) {
  if (typeof t != `function` && t !== null)
    throw TypeError(`Super expression must either be null or a function`);
  (e.prototype = Object.create(t && t.prototype, {
    constructor: { value: e, writable: !0, configurable: !0 },
  })),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    t && Xt(e, t);
}
function Xt(e, t) {
  return (
    (Xt = Object.setPrototypeOf
      ? Object.setPrototypeOf.bind()
      : function (e, t) {
          return (e.__proto__ = t), e;
        }),
    Xt(e, t)
  );
}
function Zt(e) {
  var t = en();
  return function () {
    var n = tn(e),
      r;
    if (t) {
      var i = tn(this).constructor;
      r = Reflect.construct(n, arguments, i);
    } else r = n.apply(this, arguments);
    return Qt(this, r);
  };
}
function Qt(e, t) {
  if (t && (Gt(t) === `object` || typeof t == `function`)) return t;
  if (t !== void 0)
    throw TypeError(`Derived constructors may only return object or undefined`);
  return $t(e);
}
function $t(e) {
  if (e === void 0)
    throw ReferenceError(
      `this hasn't been initialised - super() hasn't been called`
    );
  return e;
}
function en() {
  if (typeof Reflect > `u` || !Reflect.construct || Reflect.construct.sham)
    return !1;
  if (typeof Proxy == `function`) return !0;
  try {
    return (
      Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      ),
      !0
    );
  } catch {
    return !1;
  }
}
function tn(e) {
  return (
    (tn = Object.setPrototypeOf
      ? Object.getPrototypeOf.bind()
      : function (e) {
          return e.__proto__ || Object.getPrototypeOf(e);
        }),
    tn(e)
  );
}
function nn(e, t, n) {
  return (
    t in e
      ? Object.defineProperty(e, t, {
          value: n,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = n),
    e
  );
}
var rn = (function (e) {
  Yt(n, e);
  var t = Zt(n);
  function n() {
    var e;
    Kt(this, n);
    var r = [...arguments];
    return (
      (e = t.call.apply(t, [this].concat(r))),
      nn($t(e), `state`, { loading: !0 }),
      nn($t(e), `handleOnLoad`, function () {
        e.setState({ loading: !1 });
      }),
      nn($t(e), `handleOnContextMenu`, function (t) {
        !e.props.contextMenu && t.preventDefault();
      }),
      e
    );
  }
  return (
    Jt(n, [
      {
        key: `render`,
        value: function () {
          var e = this.props,
            t = e.id,
            n = e.className,
            r = e.src,
            i = e.style,
            a = e.handleDoubleClick;
          return W.createElement(
            `div`,
            null,
            this.state.loading && W.createElement(Bt, null),
            W.createElement(`img`, {
              id: t,
              className: n,
              src: r,
              style: i,
              onLoad: this.handleOnLoad,
              onDoubleClick: a,
              onContextMenu: this.handleOnContextMenu,
            })
          );
        },
      },
    ]),
    n
  );
})(W.Component);
function an(e) {
  "@babel/helpers - typeof";
  return (
    (an =
      typeof Symbol == `function` && typeof Symbol.iterator == `symbol`
        ? function (e) {
            return typeof e;
          }
        : function (e) {
            return e &&
              typeof Symbol == `function` &&
              e.constructor === Symbol &&
              e !== Symbol.prototype
              ? `symbol`
              : typeof e;
          }),
    an(e)
  );
}
function on(e, t) {
  if (!(e instanceof t)) throw TypeError(`Cannot call a class as a function`);
}
function sn(e, t) {
  for (var n = 0; n < t.length; n++) {
    var r = t[n];
    (r.enumerable = r.enumerable || !1),
      (r.configurable = !0),
      `value` in r && (r.writable = !0),
      Object.defineProperty(e, r.key, r);
  }
}
function cn(e, t, n) {
  return (
    t && sn(e.prototype, t),
    n && sn(e, n),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    e
  );
}
function ln(e, t) {
  if (typeof t != `function` && t !== null)
    throw TypeError(`Super expression must either be null or a function`);
  (e.prototype = Object.create(t && t.prototype, {
    constructor: { value: e, writable: !0, configurable: !0 },
  })),
    Object.defineProperty(e, "prototype", { writable: !1 }),
    t && un(e, t);
}
function un(e, t) {
  return (
    (un = Object.setPrototypeOf
      ? Object.setPrototypeOf.bind()
      : function (e, t) {
          return (e.__proto__ = t), e;
        }),
    un(e, t)
  );
}
function dn(e) {
  var t = pn();
  return function () {
    var n = mn(e),
      r;
    if (t) {
      var i = mn(this).constructor;
      r = Reflect.construct(n, arguments, i);
    } else r = n.apply(this, arguments);
    return fn(this, r);
  };
}
function fn(e, t) {
  if (t && (an(t) === `object` || typeof t == `function`)) return t;
  if (t !== void 0)
    throw TypeError(`Derived constructors may only return object or undefined`);
  return q(e);
}
function q(e) {
  if (e === void 0)
    throw ReferenceError(
      `this hasn't been initialised - super() hasn't been called`
    );
  return e;
}
function pn() {
  if (typeof Reflect > `u` || !Reflect.construct || Reflect.construct.sham)
    return !1;
  if (typeof Proxy == `function`) return !0;
  try {
    return (
      Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      ),
      !0
    );
  } catch {
    return !1;
  }
}
function mn(e) {
  return (
    (mn = Object.setPrototypeOf
      ? Object.getPrototypeOf.bind()
      : function (e) {
          return e.__proto__ || Object.getPrototypeOf(e);
        }),
    mn(e)
  );
}
function J(e, t, n) {
  return (
    t in e
      ? Object.defineProperty(e, t, {
          value: n,
          enumerable: !0,
          configurable: !0,
          writable: !0,
        })
      : (e[t] = n),
    e
  );
}
var hn = (function (e) {
    ln(n, e);
    var t = dn(n);
    function n() {
      var e;
      on(this, n);
      var r = [...arguments];
      return (
        (e = t.call.apply(t, [this].concat(r))),
        J(q(e), `state`, {
          move: { x: 0, y: 0 },
          moveStart: void 0,
          zoomed: !1,
          rotationDeg: 0,
        }),
        J(q(e), `handleKeyDown`, function (t) {
          (t.keyCode === 27 || t.keyCode === 13) && e.props.onClose();
        }),
        J(q(e), `getCoordinatesIfOverImg`, function (t) {
          var n = t.changedTouches ? t.changedTouches[0] : t;
          if (n.target.id === `react-modal-image-img`) {
            var r = e.contentEl.getBoundingClientRect();
            return { x: n.clientX - r.left, y: n.clientY - r.top };
          }
        }),
        J(q(e), `handleMouseDownOrTouchStart`, function (t) {
          if ((t.preventDefault(), !(t.touches && t.touches.length > 1))) {
            var n = e.getCoordinatesIfOverImg(t);
            n || e.props.onClose(),
              e.state.zoomed &&
                e.setState(function (e) {
                  return {
                    moveStart: { x: n.x - e.move.x, y: n.y - e.move.y },
                  };
                });
          }
        }),
        J(q(e), `handleMouseMoveOrTouchMove`, function (t) {
          if (
            (t.preventDefault(),
            e.state.zoomed &&
              e.state.moveStart &&
              !(t.touches && t.touches.length > 1))
          ) {
            var n = e.getCoordinatesIfOverImg(t);
            n &&
              e.setState(function (e) {
                return {
                  move: { x: n.x - e.moveStart.x, y: n.y - e.moveStart.y },
                };
              });
          }
        }),
        J(q(e), `handleMouseUpOrTouchEnd`, function (t) {
          e.setState({ moveStart: void 0 });
        }),
        J(q(e), `toggleZoom`, function (t) {
          t.preventDefault(),
            e.setState(function (e) {
              return {
                zoomed: !e.zoomed,
                move: e.zoomed ? { x: 0, y: 0 } : e.move,
              };
            });
        }),
        J(q(e), `toggleRotate`, function (t) {
          t.preventDefault(),
            e.state.rotationDeg === 360
              ? e.setState({ rotationDeg: 90 })
              : e.setState(function (e) {
                  return { rotationDeg: (e.rotationDeg += 90) };
                });
        }),
        e
      );
    }
    return (
      cn(n, [
        {
          key: `componentDidMount`,
          value: function () {
            document.addEventListener(`keydown`, this.handleKeyDown, !1);
          },
        },
        {
          key: `componentWillUnmount`,
          value: function () {
            document.removeEventListener(`keydown`, this.handleKeyDown, !1);
          },
        },
        {
          key: `render`,
          value: function () {
            var e = this,
              t = this.props,
              n = t.medium,
              r = t.large,
              i = t.alt,
              a = t.onClose,
              o = t.hideDownload,
              s = t.hideZoom,
              c = t.showRotate,
              l = t.imageBackgroundColor,
              u = l === void 0 ? `black` : l,
              d = this.state,
              f = d.move,
              p = d.zoomed,
              m = d.rotationDeg;
            return W.createElement(
              `div`,
              null,
              W.createElement(Pt, {
                name: `__react_modal_image__lightbox`,
                css: Ft({ imageBackgroundColor: u }),
              }),
              W.createElement(
                `div`,
                { className: `__react_modal_image__modal_container` },
                W.createElement(
                  `div`,
                  {
                    className: `__react_modal_image__modal_content`,
                    onMouseDown: this.handleMouseDownOrTouchStart,
                    onMouseUp: this.handleMouseUpOrTouchEnd,
                    onMouseMove: this.handleMouseMoveOrTouchMove,
                    onTouchStart: this.handleMouseDownOrTouchStart,
                    onTouchEnd: this.handleMouseUpOrTouchEnd,
                    onTouchMove: this.handleMouseMoveOrTouchMove,
                    ref: function (t) {
                      e.contentEl = t;
                    },
                  },
                  p &&
                    W.createElement(rn, {
                      id: `react-modal-image-img`,
                      className: `__react_modal_image__large_img`,
                      src: r || n,
                      style: {
                        transform: `translate3d(-50%, -50%, 0) translate3d(${f.x}px, ${f.y}px, 0) rotate(${m}deg)`,
                        WebkitTransform: `translate3d(-50%, -50%, 0) translate3d(${f.x}px, ${f.y}px, 0) rotate(${m}deg)`,
                        MsTransform: `translate3d(-50%, -50%, 0) translate3d(${f.x}px, ${f.y}px, 0) rotate(${m}deg)`,
                      },
                      handleDoubleClick: this.toggleZoom,
                    }),
                  !p &&
                    W.createElement(rn, {
                      id: `react-modal-image-img`,
                      className: `__react_modal_image__medium_img`,
                      src: n || r,
                      handleDoubleClick: this.toggleZoom,
                      contextMenu: !n,
                      style: {
                        transform: `translate3d(-50%, -50%, 0) rotate(${m}deg)`,
                        WebkitTransform: `translate3d(-50%, -50%, 0) rotate(${m}deg)`,
                        MsTransform: `translate3d(-50%, -50%, 0) rotate(${m}deg)`,
                      },
                    })
                ),
                W.createElement(Wt, {
                  image: r || n,
                  alt: i,
                  zoomed: p,
                  toggleZoom: this.toggleZoom,
                  toggleRotate: this.toggleRotate,
                  onClose: a,
                  enableDownload: !o,
                  enableZoom: !s,
                  enableRotate: !!c,
                })
              )
            );
          },
        },
      ]),
      n
    );
  })(W.Component),
  gn = W.createContext(!1),
  _n,
  vn = {
    backgroundColor: `rgba(255,255,31, 0.21)`,
    boxShadow: `10px 0 0 rgba(255,255,31, 0.21), -10px 0 0 rgba(255,255,31, 0.21)`,
    borderRadius: 9,
  },
  yn = w.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
  width: 100%;
`,
  Y = class extends W.Component {
    render() {
      let {
        paddingHorizontal: e,
        paddingVertical: t,
        customStyle: n,
        ...r
      } = this.props;
      return (
        delete r.text,
        delete r.highlighted,
        (0, K.jsx)(yn, {
          className: this.props.customClass,
          style: n,
          children: (0, K.jsx)(mt.Textfit, {
            style: {
              height: `100%`,
              width: `100%`,
              display: `flex`,
              justifyContent: this.props.disableHorizontalCentering
                ? `flex-start`
                : `center`,
              alignItems: `center`,
              paddingTop: t,
              paddingBottom: t,
              paddingLeft: this.props.paddingLeft || e,
              paddingRight: e,
              boxSizing: `border-box`,
              fontWeight: this.props.noBold
                ? `normal`
                : `var(--question-text-font-weight, 900)`,
            },
            ...r,
            max: this.context ? 1e4 : this.props.max,
            children: (0, K.jsx)(`div`, {
              style: this.props.highlighted ? vn : void 0,
              children: this.props.text,
            }),
          }),
        })
      );
    }
  };
(_n = Y),
  (_n.contextType = gn),
  (_n.defaultProps = {
    paddingHorizontal: `6%`,
    paddingVertical: 15,
    max: 50,
    mode: `single`,
    forceSingleModeWidth: !1,
  });
var bn = i((e, t) => {
    function n(e) {
      return e && e.__esModule ? e : { default: e };
    }
    (t.exports = n),
      (t.exports.__esModule = !0),
      (t.exports.default = t.exports);
  }),
  xn = i((e, t) => {
    var n = he().default;
    function r(e, i) {
      if (typeof WeakMap == `function`)
        var a = new WeakMap(),
          o = new WeakMap();
      return ((t.exports = r =
        function (e, t) {
          if (!t && e && e.__esModule) return e;
          var r,
            i,
            s = { __proto__: null, default: e };
          if (e === null || (n(e) != `object` && typeof e != `function`))
            return s;
          if ((r = t ? o : a)) {
            if (r.has(e)) return r.get(e);
            r.set(e, s);
          }
          for (var c in e)
            c !== "default" &&
              {}.hasOwnProperty.call(e, c) &&
              ((i =
                (r = Object.defineProperty) &&
                Object.getOwnPropertyDescriptor(e, c)) &&
              (i.get || i.set)
                ? r(s, c, i)
                : (s[c] = e[c]));
          return s;
        }),
      (t.exports.__esModule = !0),
      (t.exports.default = t.exports))(e, i);
    }
    (t.exports = r),
      (t.exports.__esModule = !0),
      (t.exports.default = t.exports);
  }),
  Sn = i((t) => {
    Object.defineProperty(t, "__esModule", { value: !0 }),
      Object.defineProperty(t, "default", {
        enumerable: !0,
        get: function () {
          return n.createSvgIcon;
        },
      });
    var n = (Le(), e(Ie));
  }),
  Cn = n(
    i((e) => {
      var t = bn(),
        n = xn();
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = void 0);
      var r = n(o());
      e.default = (0, t(Sn()).default)(
        r.createElement(`path`, { d: `M8 5v14l11-7z` }),
        `PlayArrow`
      );
    })()
  ),
  X = class {
    constructor() {
      (this.enabled = !1),
        (this.canPlayAgain = !0),
        (this.isCurrentlySpeaking = !1),
        (this.hasPlayedForCurrentQuestion = !1),
        (this.currentlyPlayingQuestionAudio = !1),
        (this.currentlyPlayingQuestionText = !1),
        (this.currentlyPlayingAnswerAudio = !1),
        (this.answerIndex = 0),
        (this.finishedReadingQuestion = !1),
        (this.audioQuestion = null),
        (this.speechQuestion = null),
        (this.chosenVoice = null),
        (this.answersTimeout = null),
        (this.reset = (e) => {
          (this.isCurrentlySpeaking = !1),
            (this.currentlyPlayingQuestionAudio = !1),
            (this.currentlyPlayingQuestionText = !1),
            (this.currentlyPlayingAnswerAudio = !1),
            (this.answerIndex = 0),
            (this.audioQuestion = null),
            (this.speechQuestion = null),
            e &&
              ((this.hasPlayedForCurrentQuestion = !1),
              (this.finishedReadingQuestion = !1),
              (this.canPlayAgain = !0));
        }),
        v(this);
    }
  };
x([b], X.prototype, `enabled`, void 0),
  x([b], X.prototype, `canPlayAgain`, void 0),
  x([b], X.prototype, `isCurrentlySpeaking`, void 0),
  x([b], X.prototype, `hasPlayedForCurrentQuestion`, void 0),
  x([b], X.prototype, `currentlyPlayingQuestionAudio`, void 0),
  x([b], X.prototype, `currentlyPlayingQuestionText`, void 0),
  x([b], X.prototype, `currentlyPlayingAnswerAudio`, void 0),
  x([b], X.prototype, `answerIndex`, void 0),
  x([b], X.prototype, `finishedReadingQuestion`, void 0),
  x([b], X.prototype, `speechQuestion`, void 0),
  x([b], X.prototype, `chosenVoice`, void 0),
  x([b], X.prototype, `answersTimeout`, void 0),
  x([y.bound], X.prototype, `reset`, void 0);
var Z = { readToMe: new X() },
  wn = 500,
  Tn = 0.8,
  En = [`Samantha`, `Victoria`],
  Dn = (e, t = !0) => {
    On(t), kn(e);
  },
  On = (e) => {
    Z.readToMe.audioQuestion &&
      (Z.readToMe.audioQuestion.stop(), (Z.readToMe.audioQuestion = null)),
      Z.readToMe.speechQuestion &&
        ((Z.readToMe.speechQuestion.onend = null),
        (Z.readToMe.speechQuestion = null)),
      Z.readToMe.answersTimeout && clearTimeout(Z.readToMe.answersTimeout),
      Z.readToMe.reset(e),
      window.speechSynthesis.cancel();
  },
  kn = async (e) => {
    if (
      !Z.readToMe.enabled &&
      e.audio &&
      !Z.readToMe.hasPlayedForCurrentQuestion
    )
      An(e.audio);
    else if (
      `speechSynthesis` in window &&
      Z.readToMe.enabled &&
      !Z.readToMe.isCurrentlySpeaking &&
      !Z.readToMe.hasPlayedForCurrentQuestion
    ) {
      Z.readToMe.isCurrentlySpeaking = !0;
      let t, n;
      e != null &&
        e.text &&
        ((n = new SpeechSynthesisUtterance(e.text)),
        (n.voice = await Fn()),
        (n.rate = Tn),
        (Z.readToMe.speechQuestion = n)),
        e != null &&
          e.audio &&
          ((t = new pt.Howl({
            src: [e.audio],
            onplay: Nn,
            onend:
              e != null && e.text
                ? () => window.speechSynthesis.speak(n)
                : () => Q(e),
          })),
          (Z.readToMe.audioQuestion = t)),
        t && n
          ? ((n.onstart = Pn),
            (n.onend = () => Q(e)),
            t.play(),
            (Z.readToMe.hasPlayedForCurrentQuestion = !0))
          : n
          ? ((n.onstart = Pn),
            (n.onend = () => Q(e)),
            window.speechSynthesis.speak(n),
            (Z.readToMe.hasPlayedForCurrentQuestion = !0))
          : t
          ? (t.play(), (Z.readToMe.hasPlayedForCurrentQuestion = !0))
          : (Q(e), (Z.readToMe.hasPlayedForCurrentQuestion = !0));
    }
  },
  An = (e) => {
    if (
      !Z.readToMe.enabled ||
      (Z.readToMe.enabled &&
        !Z.readToMe.currentlyPlayingQuestionAudio &&
        !Z.readToMe.currentlyPlayingAnswerAudio &&
        Z.readToMe.hasPlayedForCurrentQuestion)
    ) {
      let t = new pt.Howl({
        src: [P(e)],
        onplay: () => Nn(),
        onend: () => Q(),
        html5: !0,
      });
      (Z.readToMe.audioQuestion = t), t.play();
    }
  },
  jn = async (e) => {
    Z.readToMe.isCurrentlySpeaking = !0;
    let t = e.answers.filter((e) => e.text != null);
    if (e.type === ht.multipleChoice && t.length) {
      Z.readToMe.currentlyPlayingAnswerAudio = !0;
      let n = e.answers.findIndex((e) => e._id === t[t.length - 1]._id);
      for (let [t, r] of e.answers.entries()) {
        if (!r.text) continue;
        let e = new SpeechSynthesisUtterance();
        (e.text = r.text),
          (e.rate = Tn),
          (e.voice = await Fn()),
          (e.onstart = () => (Z.readToMe.answerIndex = t)),
          (e.onend = () => {
            window.speechSynthesis.pause(),
              setTimeout(() => window.speechSynthesis.resume(), wn);
          }),
          t >= n && (e.onend = () => Mn()),
          window.speechSynthesis.speak(e);
      }
    } else Mn();
  },
  Mn = () => {
    (Z.readToMe.isCurrentlySpeaking = !1),
      (Z.readToMe.currentlyPlayingAnswerAudio = !1),
      (Z.readToMe.finishedReadingQuestion = !0),
      window.speechSynthesis.cancel();
  },
  Nn = () => {
    Z.readToMe.currentlyPlayingQuestionAudio = !0;
  },
  Pn = () => {
    Z.readToMe.currentlyPlayingQuestionText = !0;
  },
  Q = (e) => {
    (Z.readToMe.currentlyPlayingQuestionAudio = !1),
      (Z.readToMe.currentlyPlayingQuestionText = !1),
      e && (Z.readToMe.answersTimeout = setTimeout(() => jn(e), wn));
  },
  Fn = async () => {
    let e = await In();
    if (e != null && e.length) {
      let t = e.filter((e) => En.includes(e.name));
      if (t.length) return t[0];
    }
    return null;
  },
  In = () =>
    new Promise((e) => {
      Z.readToMe.chosenVoice && e([Z.readToMe.chosenVoice]);
      let t = speechSynthesis.getVoices();
      t.length
        ? e(t)
        : (e([]),
          (speechSynthesis.onvoiceschanged = () => {
            (t = speechSynthesis.getVoices()), e(t);
          }));
    }),
  Ln = {
    play: Dn,
    stop: On,
    hasFinishedReading: () => Z.readToMe.finishedReadingQuestion,
    playAudio: An,
    canPlayAgain: () => Z.readToMe.canPlayAgain,
  },
  Rn = `Replay Audio`,
  zn = ee((e) =>
    (0, K.jsx)(pe, {
      title: (0, K.jsx)(`span`, { style: { fontSize: 14 }, children: Rn }),
      placement: `left`,
      children: (0, K.jsx)(rt, {
        onClick: () => {
          Ln.playAudio(e.audio);
        },
        color: `secondary`,
        style: { flexShrink: 0 },
        children: (0, K.jsx)(Cn.default, {}),
      }),
    })
  );
s(), m(), te();
var $ = n(a()),
  Bn = [`client`, `offset`, `scroll`, `bounds`, `margin`];
function Vn(e) {
  var t = [];
  return (
    Bn.forEach(function (n) {
      e[n] && t.push(n);
    }),
    t
  );
}
function Hn(e, t) {
  var n = {};
  if (
    (t.indexOf(`client`) > -1 &&
      (n.client = {
        top: e.clientTop,
        left: e.clientLeft,
        width: e.clientWidth,
        height: e.clientHeight,
      }),
    t.indexOf(`offset`) > -1 &&
      (n.offset = {
        top: e.offsetTop,
        left: e.offsetLeft,
        width: e.offsetWidth,
        height: e.offsetHeight,
      }),
    t.indexOf(`scroll`) > -1 &&
      (n.scroll = {
        top: e.scrollTop,
        left: e.scrollLeft,
        width: e.scrollWidth,
        height: e.scrollHeight,
      }),
    t.indexOf(`bounds`) > -1)
  ) {
    var r = e.getBoundingClientRect();
    n.bounds = {
      top: r.top,
      right: r.right,
      bottom: r.bottom,
      left: r.left,
      width: r.width,
      height: r.height,
    };
  }
  if (t.indexOf(`margin`) > -1) {
    var i = getComputedStyle(e);
    n.margin = {
      top: i ? parseInt(i.marginTop) : 0,
      right: i ? parseInt(i.marginRight) : 0,
      bottom: i ? parseInt(i.marginBottom) : 0,
      left: i ? parseInt(i.marginLeft) : 0,
    };
  }
  return n;
}
function Un(e) {
  return (e && e.ownerDocument && e.ownerDocument.defaultView) || window;
}
function Wn(e) {
  return function (t) {
    var n,
      r = (n = (function (n) {
        ne(r, n);
        function r() {
          var t,
            r = [...arguments];
          return (
            (t = n.call.apply(n, [this].concat(r)) || this),
            (t.state = {
              contentRect: {
                entry: {},
                client: {},
                offset: {},
                scroll: {},
                bounds: {},
                margin: {},
              },
            }),
            (t._animationFrameID = null),
            (t._resizeObserver = null),
            (t._node = null),
            (t._window = null),
            (t.measure = function (n) {
              var r = Hn(t._node, e || Vn(t.props));
              n && (r.entry = n[0].contentRect),
                (t._animationFrameID = t._window.requestAnimationFrame(
                  function () {
                    t._resizeObserver !== null &&
                      (t.setState({ contentRect: r }),
                      typeof t.props.onResize == `function` &&
                        t.props.onResize(r));
                  }
                ));
            }),
            (t._handleRef = function (e) {
              t._resizeObserver !== null &&
                t._node !== null &&
                t._resizeObserver.unobserve(t._node),
                (t._node = e),
                (t._window = Un(t._node));
              var n = t.props.innerRef;
              n &&
                (typeof n == `function` ? n(t._node) : (n.current = t._node)),
                t._resizeObserver !== null &&
                  t._node !== null &&
                  t._resizeObserver.observe(t._node);
            }),
            t
          );
        }
        var i = r.prototype;
        return (
          (i.componentDidMount = function () {
            (this._resizeObserver =
              this._window !== null && this._window.ResizeObserver
                ? new this._window.ResizeObserver(this.measure)
                : new C(this.measure)),
              this._node !== null &&
                (this._resizeObserver.observe(this._node),
                typeof this.props.onResize == `function` &&
                  this.props.onResize(Hn(this._node, e || Vn(this.props))));
          }),
          (i.componentWillUnmount = function () {
            this._window !== null &&
              this._window.cancelAnimationFrame(this._animationFrameID),
              this._resizeObserver !== null &&
                (this._resizeObserver.disconnect(),
                (this._resizeObserver = null));
          }),
          (i.render = function () {
            var e = this.props;
            e.innerRef, e.onResize;
            var n = g(e, [`innerRef`, `onResize`]);
            return (0, W.createElement)(
              t,
              u({}, n, {
                measureRef: this._handleRef,
                measure: this.measure,
                contentRect: this.state.contentRect,
              })
            );
          }),
          r
        );
      })(W.Component));
    return (
      (n.propTypes = {
        client: $.default.bool,
        offset: $.default.bool,
        scroll: $.default.bool,
        bounds: $.default.bool,
        margin: $.default.bool,
        innerRef: $.default.oneOfType([$.default.object, $.default.func]),
        onResize: $.default.func,
      }),
      r
    );
  };
}
var Gn = Wn()(function (e) {
  var t = e.measure,
    n = e.measureRef,
    r = e.contentRect,
    i = e.children;
  return i({ measure: t, measureRef: n, contentRect: r });
});
(Gn.displayName = `Measure`), (Gn.propTypes.children = $.default.func);
var Kn = (e) => {
    let [t, n] = W.useState({ width: -1, height: -1 }),
      [r, i] = W.useState(!1),
      a = (e) => {
        e.bounds && n(e.bounds);
      },
      o = () => i(!0),
      s = () => i(!1),
      { text: c, image: l, audio: u, latex: d } = e,
      { width: f } = t;
    return (0, K.jsxs)(K.Fragment, {
      children: [
        r &&
          (0, K.jsx)(hn, {
            large: P(l),
            onClose: s,
            hideDownload: !0,
            showRotate: !1,
            hideZoom: !0,
          }),
        (0, K.jsxs)(qn, {
          children: [
            (0, K.jsxs)(Jn, {
              children: [
                (0, K.jsx)(Gn, {
                  bounds: !0,
                  onResize: a,
                  children: ({ measureRef: e }) =>
                    (0, K.jsx)(`div`, { ref: e, style: { flex: 1 } }),
                }),
                u && (0, K.jsx)(zn, { audio: u }),
                u && !l && !d && (0, K.jsx)(`div`, { style: { width: `2vw` } }),
                l &&
                  (0, K.jsx)(`img`, {
                    src: P(l),
                    alt: `Question`,
                    onClick: o,
                    style: {
                      maxHeight: `90%`,
                      maxWidth: `calc(80% - ${u ? 56 : 0}px)`,
                      marginRight: `2vw`,
                      marginLeft: u ? `2vw` : 0,
                      borderRadius: 4,
                      cursor: `pointer`,
                    },
                  }),
                d &&
                  (0, K.jsx)(Yn, {
                    style: {
                      width: `calc(80% - ${u ? 56 : 0}px)`,
                      marginLeft: u ? `2vw` : 0,
                    },
                    children: (0, K.jsx)(Y, {
                      text: (0, K.jsx)(F, { latex: d }),
                      noBold: !0,
                    }),
                  }),
              ],
            }),
            (0, K.jsxs)(Xn, {
              children: [
                (0, K.jsx)(Y, {
                  text: _t(e.allowGoogleTranslate, c),
                  paddingHorizontal: `0px`,
                  paddingVertical: `6%`,
                  customStyle: { width: `calc(100% - ${f}px)` },
                  mode: `multi`,
                  disableHorizontalCentering: !0,
                  highlighted: e.highlighted,
                  noBold: e.noBold,
                }),
                (0, K.jsx)(`div`, { style: { width: f, height: `100%` } }),
              ],
            }),
          ],
        }),
      ],
    });
  },
  qn = w.div`
  box-sizing: border-box;
  padding-top: 10px;
  padding-bottom: 10px;
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0px 4%;
`,
  Jn = w.div`
  width: 40%;
  height: 100%;
  display: flex;
  align-items: center;
`,
  Yn = w.div`
  height: 90%;
  margin-right: 2vw;
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.2);
  padding: 10%;
`,
  Xn = w.div`
  width: 60%;
  display: flex;
  align-items: center;
  height: 100%;
`,
  Zn = (e) => {
    let [t, n] = W.useState(!1),
      { image: r, audio: i, latex: a } = e;
    return (0, K.jsxs)(K.Fragment, {
      children: [
        r &&
          t &&
          (0, K.jsx)(hn, {
            large: P(r),
            onClose: () => n(!1),
            hideDownload: !0,
            showRotate: !1,
            hideZoom: !0,
          }),
        (0, K.jsxs)(qn, {
          children: [
            i && (0, K.jsx)(zn, { audio: i }),
            r &&
              (0, K.jsx)(`img`, {
                src: P(r),
                alt: `Question`,
                onClick: () => n(!0),
                style: {
                  maxHeight: `90%`,
                  height: `90%`,
                  maxWidth: `90%`,
                  borderRadius: 4,
                  cursor: `pointer`,
                },
              }),
            a &&
              (0, K.jsx)(Y, { text: (0, K.jsx)(F, { latex: a }), noBold: !0 }),
          ],
        }),
      ],
    });
  },
  Qn = (e) =>
    (0, K.jsx)(Y, {
      mode: `multi`,
      text: _t(e.allowGoogleTranslate || !1, e.text),
      highlighted: e.highlighted,
      noBold: e.noBold,
    });
export {
  De as C,
  be as D,
  Ce as E,
  xe as O,
  B as S,
  Se as T,
  Fe as _,
  Z as a,
  Oe as b,
  bn as c,
  yt as d,
  bt as f,
  et as g,
  ft as h,
  Ln as i,
  Y as l,
  ht as m,
  Zn as n,
  Sn as o,
  _t as p,
  Kn as r,
  xn as s,
  Qn as t,
  gn as u,
  H as v,
  z as w,
  V as x,
  ke as y,
};
