import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { C as t, g as n } from "./utils-CV9JYz4f.js";
import { t as r } from "./react-IpA8Qn9U.js";
import { l as i } from "./dist-BbGQUgM_.js";
import { i as a, n as o, r as s } from "./ContentContainer-DHxbCe5y.js";
import "./Paths-3vkx8h28.js";
import { t as c } from "./jsx-runtime-CA2T8_y1.js";
import { t as l } from "./mobxreact.esm-CES6mMUm.js";
import { t as u } from "./NavigateTo-CWRFhxPL.js";
var d = e(r()),
  f = (e) => {
    let { kit: r } = a;
    (r.errorFetchingKit = !1),
      (r.fetchingKit = !0),
      t({
        url: `/api/games/fetch/${e}`,
        method: `get`,
        success: (e) => {
          n() && (a.user.loggedIn = !0),
            (r.id = e.kit._id),
            (r.name = e.kit.title),
            (r.coverPhoto = e.kit.gif),
            (r.creatorName = e.creator.name),
            (r.creatorId = e.creator._id),
            (r.kitPrivacy = e.kit.privacy),
            r.questions.replace(e.kit.questions);
        },
        error: (e) => {
          (r.errorFetchingKit = !0), u(`/`);
        },
        both: () => (r.fetchingKit = !1),
      });
  },
  p = c(),
  m = () => {
    let { id: e } = i();
    return (
      d.useEffect(
        () => (
          f(e),
          () => {
            a.navigation.reset();
          }
        ),
        [e]
      ),
      (0, p.jsx)(s.Provider, {
        value: a,
        children: (0, p.jsx)(l, {
          ...a,
          children: (0, p.jsx)(p.Fragment, {
            children: (0, p.jsx)(o, { kitId: e }),
          }),
        }),
      })
    );
  };
export { m as default };
