import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  J as n,
  Ut as r,
  b as i,
  k as a,
  m as o,
  s,
} from "./Compact-CRRKXVA1.js";
import { _ as c, s as l } from "./color-Dzrzfp-h.js";
var u = e(t()),
  d = e(r());
function f(e, t, n) {
  var r = n || {},
    i = r.noTrailing,
    a = i !== void 0 && i,
    o = r.noLeading,
    s = o !== void 0 && o,
    c = r.debounceMode,
    l = c === void 0 ? void 0 : c,
    u,
    d = !1,
    f = 0;
  function p() {
    u && clearTimeout(u);
  }
  function m(e) {
    var t = (e || {}).upcomingOnly,
      n = t !== void 0 && t;
    p(), (d = !n);
  }
  function h() {
    var n = [...arguments],
      r = this,
      i = Date.now() - f;
    if (d) return;
    function o() {
      (f = Date.now()), t.apply(r, n);
    }
    function c() {
      u = void 0;
    }
    !s && l && !u && o(),
      p(),
      l === void 0 && i > e
        ? s
          ? ((f = Date.now()), a || (u = setTimeout(l ? c : o, e)))
          : o()
        : a !== !0 && (u = setTimeout(l ? c : o, l === void 0 ? e - i : e));
  }
  return (h.cancel = m), h;
}
function p(e, t, n) {
  var r = (n || {}).atBegin;
  return f(e, t, { debounceMode: (r !== void 0 && r) !== !1 });
}
var m = 100,
  h = m / 5,
  g = m / 2 - h / 2,
  _ = 80 * Math.PI,
  v = 50,
  y = (e) => {
    let { dotClassName: t, style: n, hasCircleCls: r } = e;
    return u.createElement(`circle`, {
      className: (0, d.default)(`${t}-circle`, { [`${t}-circle-bg`]: r }),
      r: g,
      cx: v,
      cy: v,
      strokeWidth: h,
      style: n,
    });
  },
  b = ({ percent: e, prefixCls: t }) => {
    let r = `${t}-dot`,
      i = `${r}-holder`,
      a = `${i}-hidden`,
      [o, s] = u.useState(!1);
    n(() => {
      e !== 0 && s(!0);
    }, [e !== 0]);
    let c = Math.max(Math.min(e, 100), 0);
    if (!o) return null;
    let l = {
      strokeDashoffset: `${_ / 4}`,
      strokeDasharray: `${(_ * c) / 100} ${(_ * (100 - c)) / 100}`,
    };
    return u.createElement(
      `span`,
      { className: (0, d.default)(i, `${r}-progress`, c <= 0 && a) },
      u.createElement(
        `svg`,
        {
          viewBox: `0 0 ${m} ${m}`,
          role: `progressbar`,
          "aria-valuemin": 0,
          "aria-valuemax": 100,
          "aria-valuenow": c,
        },
        u.createElement(y, { dotClassName: r, hasCircleCls: !0 }),
        u.createElement(y, { dotClassName: r, style: l })
      )
    );
  };
function x(e) {
  let { prefixCls: t, percent: n = 0 } = e,
    r = `${t}-dot`,
    i = `${r}-holder`,
    a = `${i}-hidden`;
  return u.createElement(
    u.Fragment,
    null,
    u.createElement(
      `span`,
      { className: (0, d.default)(i, n > 0 && a) },
      u.createElement(
        `span`,
        { className: (0, d.default)(r, `${t}-dot-spin`) },
        [1, 2, 3, 4].map((e) =>
          u.createElement(`i`, { className: `${t}-dot-item`, key: e })
        )
      )
    ),
    u.createElement(b, { prefixCls: t, percent: n })
  );
}
function S(e) {
  var t;
  let { prefixCls: n, indicator: r, percent: i } = e,
    a = `${n}-dot`;
  return r && u.isValidElement(r)
    ? l(r, {
        className: (0, d.default)(
          (t = r.props) == null ? void 0 : t.className,
          a
        ),
        percent: i,
      })
    : u.createElement(x, { prefixCls: n, percent: i });
}
var C = new c(`antSpinMove`, { to: { opacity: 1 } }),
  w = new c(`antRotate`, { to: { transform: `rotate(405deg)` } }),
  T = (e) => {
    let { componentCls: t, calc: n } = e;
    return {
      [t]: Object.assign(Object.assign({}, o(e)), {
        position: `absolute`,
        display: `none`,
        color: e.colorPrimary,
        fontSize: 0,
        textAlign: `center`,
        verticalAlign: `middle`,
        opacity: 0,
        transition: `transform ${e.motionDurationSlow} ${e.motionEaseInOutCirc}`,
        "&-spinning": {
          position: `relative`,
          display: `inline-block`,
          opacity: 1,
        },
        [`${t}-text`]: {
          fontSize: e.fontSize,
          paddingTop: n(n(e.dotSize).sub(e.fontSize)).div(2).add(2).equal(),
        },
        "&-fullscreen": {
          position: `fixed`,
          width: `100vw`,
          height: `100vh`,
          backgroundColor: e.colorBgMask,
          zIndex: e.zIndexPopupBase,
          inset: 0,
          display: `flex`,
          alignItems: `center`,
          flexDirection: `column`,
          justifyContent: `center`,
          opacity: 0,
          visibility: `hidden`,
          transition: `all ${e.motionDurationMid}`,
          "&-show": { opacity: 1, visibility: `visible` },
          [t]: {
            [`${t}-dot-holder`]: { color: e.colorWhite },
            [`${t}-text`]: { color: e.colorTextLightSolid },
          },
        },
        "&-nested-loading": {
          position: `relative`,
          [`> div > ${t}`]: {
            position: `absolute`,
            top: 0,
            insetInlineStart: 0,
            zIndex: 4,
            display: `block`,
            width: `100%`,
            height: `100%`,
            maxHeight: e.contentHeight,
            [`${t}-dot`]: {
              position: `absolute`,
              top: `50%`,
              insetInlineStart: `50%`,
              margin: n(e.dotSize).mul(-1).div(2).equal(),
            },
            [`${t}-text`]: {
              position: `absolute`,
              top: `50%`,
              width: `100%`,
              textShadow: `0 1px 2px ${e.colorBgContainer}`,
            },
            [`&${t}-show-text ${t}-dot`]: {
              marginTop: n(e.dotSize).div(2).mul(-1).sub(10).equal(),
            },
            "&-sm": {
              [`${t}-dot`]: { margin: n(e.dotSizeSM).mul(-1).div(2).equal() },
              [`${t}-text`]: {
                paddingTop: n(n(e.dotSizeSM).sub(e.fontSize))
                  .div(2)
                  .add(2)
                  .equal(),
              },
              [`&${t}-show-text ${t}-dot`]: {
                marginTop: n(e.dotSizeSM).div(2).mul(-1).sub(10).equal(),
              },
            },
            "&-lg": {
              [`${t}-dot`]: { margin: n(e.dotSizeLG).mul(-1).div(2).equal() },
              [`${t}-text`]: {
                paddingTop: n(n(e.dotSizeLG).sub(e.fontSize))
                  .div(2)
                  .add(2)
                  .equal(),
              },
              [`&${t}-show-text ${t}-dot`]: {
                marginTop: n(e.dotSizeLG).div(2).mul(-1).sub(10).equal(),
              },
            },
          },
          [`${t}-container`]: {
            position: `relative`,
            transition: `opacity ${e.motionDurationSlow}`,
            "&::after": {
              position: `absolute`,
              top: 0,
              insetInlineEnd: 0,
              bottom: 0,
              insetInlineStart: 0,
              zIndex: 10,
              width: `100%`,
              height: `100%`,
              background: e.colorBgContainer,
              opacity: 0,
              transition: `all ${e.motionDurationSlow}`,
              content: `""`,
              pointerEvents: `none`,
            },
          },
          [`${t}-blur`]: {
            clear: `both`,
            opacity: 0.5,
            userSelect: `none`,
            pointerEvents: `none`,
            "&::after": { opacity: 0.4, pointerEvents: `auto` },
          },
        },
        "&-tip": { color: e.spinDotDefault },
        [`${t}-dot-holder`]: {
          width: `1em`,
          height: `1em`,
          fontSize: e.dotSize,
          display: `inline-block`,
          transition: `transform ${e.motionDurationSlow} ease, opacity ${e.motionDurationSlow} ease`,
          transformOrigin: `50% 50%`,
          lineHeight: 1,
          color: e.colorPrimary,
          "&-hidden": { transform: `scale(0.3)`, opacity: 0 },
        },
        [`${t}-dot-progress`]: { position: `absolute`, inset: 0 },
        [`${t}-dot`]: {
          position: `relative`,
          display: `inline-block`,
          fontSize: e.dotSize,
          width: `1em`,
          height: `1em`,
          "&-item": {
            position: `absolute`,
            display: `block`,
            width: n(e.dotSize).sub(n(e.marginXXS).div(2)).div(2).equal(),
            height: n(e.dotSize).sub(n(e.marginXXS).div(2)).div(2).equal(),
            background: `currentColor`,
            borderRadius: `100%`,
            transform: `scale(0.75)`,
            transformOrigin: `50% 50%`,
            opacity: 0.3,
            animationName: C,
            animationDuration: `1s`,
            animationIterationCount: `infinite`,
            animationTimingFunction: `linear`,
            animationDirection: `alternate`,
            "&:nth-child(1)": {
              top: 0,
              insetInlineStart: 0,
              animationDelay: `0s`,
            },
            "&:nth-child(2)": {
              top: 0,
              insetInlineEnd: 0,
              animationDelay: `0.4s`,
            },
            "&:nth-child(3)": {
              insetInlineEnd: 0,
              bottom: 0,
              animationDelay: `0.8s`,
            },
            "&:nth-child(4)": {
              bottom: 0,
              insetInlineStart: 0,
              animationDelay: `1.2s`,
            },
          },
          "&-spin": {
            transform: `rotate(45deg)`,
            animationName: w,
            animationDuration: `1.2s`,
            animationIterationCount: `infinite`,
            animationTimingFunction: `linear`,
          },
          "&-circle": {
            strokeLinecap: `round`,
            transition: [
              `stroke-dashoffset`,
              `stroke-dasharray`,
              `stroke`,
              `stroke-width`,
              `opacity`,
            ]
              .map((t) => `${t} ${e.motionDurationSlow} ease`)
              .join(`,`),
            fillOpacity: 0,
            stroke: `currentcolor`,
          },
          "&-circle-bg": { stroke: e.colorFillSecondary },
        },
        [`&-sm ${t}-dot`]: { "&, &-holder": { fontSize: e.dotSizeSM } },
        [`&-sm ${t}-dot-holder`]: {
          i: {
            width: n(n(e.dotSizeSM).sub(n(e.marginXXS).div(2)))
              .div(2)
              .equal(),
            height: n(n(e.dotSizeSM).sub(n(e.marginXXS).div(2)))
              .div(2)
              .equal(),
          },
        },
        [`&-lg ${t}-dot`]: { "&, &-holder": { fontSize: e.dotSizeLG } },
        [`&-lg ${t}-dot-holder`]: {
          i: {
            width: n(n(e.dotSizeLG).sub(e.marginXXS)).div(2).equal(),
            height: n(n(e.dotSizeLG).sub(e.marginXXS)).div(2).equal(),
          },
        },
        [`&${t}-show-text ${t}-text`]: { display: `block` },
      }),
    };
  },
  E = s(
    `Spin`,
    (e) => T(i(e, { spinDotDefault: e.colorTextDescription })),
    (e) => {
      let { controlHeightLG: t, controlHeight: n } = e;
      return {
        contentHeight: 400,
        dotSize: t / 2,
        dotSizeSM: t * 0.35,
        dotSizeLG: n,
      };
    }
  ),
  D = 200,
  O = [
    [30, 0.05],
    [70, 0.03],
    [96, 0.01],
  ];
function k(e, t) {
  let [n, r] = u.useState(0),
    i = u.useRef(null),
    a = t === `auto`;
  return (
    u.useEffect(
      () => (
        a &&
          e &&
          (r(0),
          (i.current = setInterval(() => {
            r((e) => {
              let t = 100 - e;
              for (let n = 0; n < O.length; n += 1) {
                let [r, i] = O[n];
                if (e <= r) return e + t * i;
              }
              return e;
            });
          }, D))),
        () => {
          clearInterval(i.current);
        }
      ),
      [a, e]
    ),
    a ? n : t
  );
}
var A = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  j;
function M(e, t) {
  return !!e && !!t && !Number.isNaN(Number(t));
}
var N = (e) => {
  let {
      prefixCls: t,
      spinning: n = !0,
      delay: r = 0,
      className: i,
      rootClassName: o,
      size: s = `default`,
      tip: c,
      wrapperClassName: l,
      style: f,
      children: m,
      fullscreen: h = !1,
      indicator: g,
      percent: _,
    } = e,
    v = A(e, [
      `prefixCls`,
      `spinning`,
      `delay`,
      `className`,
      `rootClassName`,
      `size`,
      `tip`,
      `wrapperClassName`,
      `style`,
      `children`,
      `fullscreen`,
      `indicator`,
      `percent`,
    ]),
    {
      getPrefixCls: y,
      direction: b,
      className: x,
      style: C,
      indicator: w,
    } = a(`spin`),
    T = y(`spin`, t),
    [D, O, N] = E(T),
    [P, F] = u.useState(() => n && !M(n, r)),
    I = k(P, _);
  u.useEffect(() => {
    if (n) {
      let e = p(r, () => {
        F(!0);
      });
      return (
        e(),
        () => {
          var t;
          (t = e == null ? void 0 : e.cancel) == null || t.call(e);
        }
      );
    }
    F(!1);
  }, [r, n]);
  let L = u.useMemo(() => m !== void 0 && !h, [m, h]),
    R = (0, d.default)(
      T,
      x,
      {
        [`${T}-sm`]: s === `small`,
        [`${T}-lg`]: s === `large`,
        [`${T}-spinning`]: P,
        [`${T}-show-text`]: !!c,
        [`${T}-rtl`]: b === `rtl`,
      },
      i,
      !h && o,
      O,
      N
    ),
    z = (0, d.default)(`${T}-container`, { [`${T}-blur`]: P }),
    B = g ?? w ?? j,
    V = Object.assign(Object.assign({}, C), f),
    H = u.createElement(
      `div`,
      Object.assign({}, v, {
        style: V,
        className: R,
        "aria-live": `polite`,
        "aria-busy": P,
      }),
      u.createElement(S, { prefixCls: T, indicator: B, percent: I }),
      c && (L || h)
        ? u.createElement(`div`, { className: `${T}-text` }, c)
        : null
    );
  return D(
    L
      ? u.createElement(
          `div`,
          Object.assign({}, v, {
            className: (0, d.default)(`${T}-nested-loading`, l, O, N),
          }),
          P && u.createElement(`div`, { key: `loading` }, H),
          u.createElement(`div`, { className: z, key: `container` }, m)
        )
      : h
      ? u.createElement(
          `div`,
          {
            className: (0, d.default)(
              `${T}-fullscreen`,
              { [`${T}-fullscreen-show`]: P },
              o,
              O,
              N
            ),
          },
          H
        )
      : H
  );
};
N.setDefaultIndicator = (e) => {
  j = e;
};
export { N as t };
