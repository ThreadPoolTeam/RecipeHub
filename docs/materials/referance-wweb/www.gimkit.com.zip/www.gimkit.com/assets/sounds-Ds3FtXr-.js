import { t as e } from "./GetAssetPath-BJVbNkUu.js";
import { t } from "./MapSound-DVf9Tbc5.js";
var n = {
  correct: new t({
    src: [e(`devices/gimkit_live_question/sounds/correct.mp3`)],
    volume: 0.7,
    preload: !1,
  }),
  correctCash: new t({
    src: [e(`devices/gimkit_live_question/sounds/correct_cash.mp3`)],
    preload: !1,
  }),
  incorrect: new t({
    src: [e(`devices/gimkit_live_question/sounds/incorrect.mp3`)],
    preload: !1,
  }),
  click: new t({
    src: [e(`devices/gimkit_live_question/sounds/click.mp3`)],
    preload: !1,
  }),
};
export { n as t };
