var e = { sideMargin: 50, optionWidth: 200 };
export { e as t };
