import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { t as n } from "./button-Cpfts2Ff.js";
import { f as r, i, p as a, t as o } from "./decorate-DQbPZ5_K.js";
import { t as s } from "./jsx-runtime-CA2T8_y1.js";
import { r as c } from "./mobxreact.esm-CES6mMUm.js";
var l = e(t()),
  u = s(),
  d = c((e) =>
    (0, u.jsx)(n, {
      disabled: e.disabled,
      size: e.size || `middle`,
      type: `primary`,
      onClick: e.onClick,
      style: Object.assign({ width: `100%` }, e.style),
      loading: e.loading,
      children: e.children,
    })
  ),
  f = {
    email: `EMAIL`,
    password: `PASSWORD`,
    accountPassword: `ACCOUNT_PASSWORD`,
    firstName: `FIRST_NAME`,
    lastName: `LAST_NAME`,
    accountType: `ACCOUNT_TYPE`,
    country: `COUNTRY`,
    areaOfExpertise: `AREA_OF_EXPERTISE`,
    gradeLevel: `GRADE_LEVEL`,
    organization: `ORGANIZATION`,
    acceptedLatestPolicies: `ACCEPTED_LATEST_POLICIES`,
    schoolId: `SCHOOL_ID`,
    districtId: `DISTRICT_ID`,
  },
  p = {
    userExists: !1,
    email: ``,
    accountType: null,
    googleToken: ``,
    firstName: ``,
    lastName: ``,
    password: ``,
    schoolId: ``,
    districtId: ``,
    country: ``,
    areaOfExpertise: ``,
    gradeLevel: ``,
    organization: ``,
    acceptsLatestPolicies: !1,
    authenticated: !1,
  },
  {
    userExists: m,
    email: h,
    accountType: g,
    googleToken: _,
    firstName: v,
    lastName: y,
    password: b,
    schoolId: x,
    districtId: S,
    country: C,
    areaOfExpertise: w,
    gradeLevel: T,
    organization: E,
    acceptsLatestPolicies: D,
    authenticated: O,
  } = p,
  k = class {
    constructor() {
      (this.userExists = m),
        (this.email = h),
        (this.accountType = g),
        (this.googleToken = _),
        (this.firstName = v),
        (this.lastName = y),
        (this.password = b),
        (this.schoolId = x),
        (this.districtId = S),
        (this.country = C),
        (this.areaOfExpertise = w),
        (this.gradeLevel = T),
        (this.organization = E),
        (this.acceptsLatestPolicies = D),
        (this.authenticated = O),
        (this.informationNeeded = a.array([f.email])),
        (this.reset = () => {
          Object.keys(p).forEach((e) => (this[e] = p[e])),
            this.informationNeeded.replace([f.email]);
        }),
        r(this);
    }
  };
o([a], k.prototype, `userExists`, void 0),
  o([a], k.prototype, `email`, void 0),
  o([a], k.prototype, `accountType`, void 0),
  o([a], k.prototype, `googleToken`, void 0),
  o([a], k.prototype, `firstName`, void 0),
  o([a], k.prototype, `lastName`, void 0),
  o([a], k.prototype, `password`, void 0),
  o([a], k.prototype, `schoolId`, void 0),
  o([a], k.prototype, `districtId`, void 0),
  o([a], k.prototype, `country`, void 0),
  o([a], k.prototype, `areaOfExpertise`, void 0),
  o([a], k.prototype, `gradeLevel`, void 0),
  o([a], k.prototype, `organization`, void 0),
  o([a], k.prototype, `acceptsLatestPolicies`, void 0),
  o([a], k.prototype, `authenticated`, void 0),
  o([a], k.prototype, `informationNeeded`, void 0),
  o([i], k.prototype, `reset`, void 0);
var A = (function (e) {
    return (
      (e.email = `email`),
      (e.password = `password`),
      (e.accountType = `accountType`),
      (e.studentSpecificInfo = `studentSpecificInfo`),
      (e.nameAndPassword = `nameAndPassword`),
      (e.school = `school`),
      (e.educatorSpecificInfo = `educatorSpecificInfo`),
      (e.nonSchoolSpecificInfo = `nonSchoolSpecificInfo`),
      (e.acceptPolicies = `acceptPolicies`),
      (e.verifyClass = `verifyClass`),
      e
    );
  })(A || {}),
  j = {
    currentStage: A.email,
    emailSignInBlocked: !1,
    creatingAccount: !1,
    loggingIn: !1,
    updatingAccountInformation: !1,
    loginError: null,
    redirectUri: ``,
    classJoiningId: ``,
    classJoiningName: ``,
    classJoiningTeacherName: ``,
  },
  {
    currentStage: M,
    emailSignInBlocked: N,
    creatingAccount: P,
    loggingIn: F,
    updatingAccountInformation: I,
    loginError: L,
    redirectUri: R,
    classJoiningId: z,
    classJoiningName: B,
    classJoiningTeacherName: V,
  } = j,
  H = class {
    constructor() {
      (this.currentStage = M),
        (this.emailSignInBlocked = N),
        (this.creatingAccount = P),
        (this.loggingIn = F),
        (this.updatingAccountInformation = I),
        (this.loginError = L),
        (this.redirectUri = R),
        (this.classJoiningId = z),
        (this.classJoiningName = B),
        (this.classJoiningTeacherName = V),
        (this.reset = () => {
          Object.keys(j).forEach((e) => (this[e] = j[e]));
        }),
        r(this);
    }
  };
o([a], H.prototype, `currentStage`, void 0),
  o([a], H.prototype, `emailSignInBlocked`, void 0),
  o([a], H.prototype, `creatingAccount`, void 0),
  o([a], H.prototype, `loggingIn`, void 0),
  o([a], H.prototype, `updatingAccountInformation`, void 0),
  o([a], H.prototype, `loginError`, void 0),
  o([a], H.prototype, `redirectUri`, void 0),
  o([a], H.prototype, `classJoiningId`, void 0),
  o([a], H.prototype, `classJoiningName`, void 0),
  o([a], H.prototype, `classJoiningTeacherName`, void 0),
  o([i], H.prototype, `reset`, void 0);
var U = { login: new k(), navigation: new H() },
  W = l.createContext(U);
export { d as a, f as i, U as n, A as r, W as t };
