import { n as e } from "./rolldown-runtime-C0FnF6B9.js";
import { a as t, o as n } from "./assertThisInitialized-DqpgQyeg.js";
function r(e, n) {
  (e.prototype = Object.create(n.prototype)),
    (e.prototype.constructor = e),
    t(e, n);
}
var i = e(() => {
  n();
});
export { i as n, r as t };
