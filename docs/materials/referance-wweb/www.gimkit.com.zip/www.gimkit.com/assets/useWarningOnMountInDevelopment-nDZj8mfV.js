import { a as e } from "./index-DG2EaUNY.js";
function t(t) {
  e(function () {});
}
export { t };
