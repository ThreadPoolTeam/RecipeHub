import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import {
  At as i,
  Bt as a,
  C as o,
  E as s,
  H as c,
  Nt as l,
  Ut as u,
  X as d,
  _ as f,
  b as p,
  d as m,
  g as h,
  h as g,
  jt as _,
  l as v,
  m as y,
  r as b,
  s as x,
  u as S,
  x as C,
} from "./Compact-CRRKXVA1.js";
import { i as w, s as T } from "./color-Dzrzfp-h.js";
import { r as E } from "./compact-item-BOjQ1zv3.js";
import {
  A as D,
  D as O,
  E as k,
  b as A,
  t as j,
  w as M,
} from "./ContextIsolator-D7w7V6rn.js";
import { a as N, c as P, i as F, o as I, t as L } from "./tooltip-Yg3f8G0Q.js";
import { t as R } from "./useCSSVarCls-7-ltqzGc.js";
import { t as z } from "./button-Cpfts2Ff.js";
import { t as B } from "./collapse-CVZX-k2a.js";
import { t as V } from "./move-2ruV_Z5Z.js";
import { a as H, i as U, n as W, o as ee, r as te } from "./es-Bg8IQMoo.js";
import { t as ne } from "./PurePanel-CIt2t_IW.js";
import {
  a as G,
  c as re,
  i as ie,
  n as ae,
  o as K,
  r as oe,
  s as se,
  t as q,
} from "./EllipsisOutlined-CafYbeLj.js";
import { t as ce } from "./space-CUvL4cnc.js";
var J = e(t());
n();
var le = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z`,
          },
        },
      ],
    },
    name: `right`,
    theme: `outlined`,
  },
  ue = J.forwardRef(function (e, t) {
    return J.createElement(E, r({}, e, { ref: t, icon: le }));
  }),
  de = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 000 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z`,
          },
        },
      ],
    },
    name: `left`,
    theme: `outlined`,
  };
n();
var fe = J.forwardRef(function (e, t) {
    return J.createElement(E, r({}, e, { ref: t, icon: de }));
  }),
  Y = e(u()),
  pe = (e) => (typeof e != `object` && typeof e != `function`) || e === null,
  me = J.createContext({}),
  X = (0, J.createContext)({
    prefixCls: ``,
    firstLevel: !0,
    inlineCollapsed: !1,
  }),
  he = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  ge = (e) => {
    let { prefixCls: t, className: n, dashed: r } = e,
      i = he(e, [`prefixCls`, `className`, `dashed`]),
      { getPrefixCls: a } = J.useContext(s),
      o = a(`menu`, t),
      c = (0, Y.default)({ [`${o}-item-divider-dashed`]: !!r }, n);
    return J.createElement(ie, Object.assign({ className: c }, i));
  },
  Z = (e) => {
    var t;
    let {
        className: n,
        children: r,
        icon: i,
        title: o,
        danger: s,
        extra: c,
      } = e,
      {
        prefixCls: l,
        firstLevel: u,
        direction: d,
        disableMenuItemTitleTooltip: f,
        inlineCollapsed: p,
      } = J.useContext(X),
      m = (e) => {
        let t = r == null ? void 0 : r[0],
          n = J.createElement(
            `span`,
            {
              className: (0, Y.default)(`${l}-title-content`, {
                [`${l}-title-content-with-extra`]: !!c || c === 0,
              }),
            },
            r
          );
        return (!i || (J.isValidElement(r) && r.type === `span`)) &&
          r &&
          e &&
          u &&
          typeof t == `string`
          ? J.createElement(
              `div`,
              { className: `${l}-inline-collapsed-noicon` },
              t.charAt(0)
            )
          : n;
      },
      { siderCollapsed: h } = J.useContext(me),
      g = o;
    o === void 0 ? (g = u ? r : ``) : o === !1 && (g = ``);
    let _ = { title: g };
    !h && !p && ((_.title = null), (_.open = !1));
    let v = a(r).length,
      y = J.createElement(
        K,
        Object.assign({}, w(e, [`title`, `icon`, `danger`]), {
          className: (0, Y.default)(
            {
              [`${l}-item-danger`]: s,
              [`${l}-item-only-child`]: (i ? v + 1 : v) === 1,
            },
            n
          ),
          title: typeof o == `string` ? o : void 0,
        }),
        T(i, {
          className: (0, Y.default)(
            J.isValidElement(i)
              ? (t = i.props) == null
                ? void 0
                : t.className
              : void 0,
            `${l}-item-icon`
          ),
        }),
        m(p)
      );
    return (
      f ||
        (y = J.createElement(
          L,
          Object.assign({}, _, {
            placement: d === `rtl` ? `left` : `right`,
            classNames: { root: `${l}-inline-collapsed-tooltip` },
          }),
          y
        )),
      y
    );
  },
  _e = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  ve = J.createContext(null),
  ye = J.forwardRef((e, t) => {
    let { children: n } = e,
      r = _e(e, [`children`]),
      a = J.useContext(ve),
      o = J.useMemo(
        () => Object.assign(Object.assign({}, a), r),
        [a, r.prefixCls, r.mode, r.selectable, r.rootClassName]
      ),
      s = _(n),
      c = l(t, s ? i(n) : null);
    return J.createElement(
      ve.Provider,
      { value: o },
      J.createElement(j, { space: !0 }, s ? J.cloneElement(n, { ref: c }) : n)
    );
  }),
  be = (e) => {
    let {
      componentCls: t,
      motionDurationSlow: n,
      horizontalLineHeight: r,
      colorSplit: i,
      lineWidth: a,
      lineType: o,
      itemPaddingInline: s,
    } = e;
    return {
      [`${t}-horizontal`]: {
        lineHeight: r,
        border: 0,
        borderBottom: `${d(a)} ${o} ${i}`,
        boxShadow: `none`,
        "&::after": {
          display: `block`,
          clear: `both`,
          height: 0,
          content: `"\\20"`,
        },
        [`${t}-item, ${t}-submenu`]: {
          position: `relative`,
          display: `inline-block`,
          verticalAlign: `bottom`,
          paddingInline: s,
        },
        [`> ${t}-item:hover,
        > ${t}-item-active,
        > ${t}-submenu ${t}-submenu-title:hover`]: {
          backgroundColor: `transparent`,
        },
        [`${t}-item, ${t}-submenu-title`]: {
          transition: [`border-color ${n}`, `background ${n}`].join(`,`),
        },
        [`${t}-submenu-arrow`]: { display: `none` },
      },
    };
  },
  xe = ({ componentCls: e, menuArrowOffset: t, calc: n }) => ({
    [`${e}-rtl`]: { direction: `rtl` },
    [`${e}-submenu-rtl`]: { transformOrigin: `100% 0` },
    [`${e}-rtl${e}-vertical,
    ${e}-submenu-rtl ${e}-vertical`]: {
      [`${e}-submenu-arrow`]: {
        "&::before": {
          transform: `rotate(-45deg) translateY(${d(n(t).mul(-1).equal())})`,
        },
        "&::after": { transform: `rotate(45deg) translateY(${d(t)})` },
      },
    },
  }),
  Se = (e) => S(e),
  Ce = (e, t) => {
    let {
      componentCls: n,
      itemColor: r,
      itemSelectedColor: i,
      subMenuItemSelectedColor: a,
      groupTitleColor: o,
      itemBg: s,
      subMenuItemBg: c,
      itemSelectedBg: l,
      activeBarHeight: u,
      activeBarWidth: f,
      activeBarBorderWidth: p,
      motionDurationSlow: m,
      motionEaseInOut: h,
      motionEaseOut: g,
      itemPaddingInline: _,
      motionDurationMid: v,
      itemHoverColor: y,
      lineType: b,
      colorSplit: x,
      itemDisabledColor: S,
      dangerItemColor: C,
      dangerItemHoverColor: w,
      dangerItemSelectedColor: T,
      dangerItemActiveBg: E,
      dangerItemSelectedBg: D,
      popupBg: O,
      itemHoverBg: k,
      itemActiveBg: A,
      menuSubMenuBg: j,
      horizontalItemSelectedColor: M,
      horizontalItemSelectedBg: N,
      horizontalItemBorderRadius: P,
      horizontalItemHoverBg: F,
    } = e;
    return {
      [`${n}-${t}, ${n}-${t} > ${n}`]: {
        color: r,
        background: s,
        [`&${n}-root:focus-visible`]: Object.assign({}, Se(e)),
        [`${n}-item`]: { "&-group-title, &-extra": { color: o } },
        [`${n}-submenu-selected > ${n}-submenu-title`]: { color: a },
        [`${n}-item, ${n}-submenu-title`]: {
          color: r,
          [`&:not(${n}-item-disabled):focus-visible`]: Object.assign({}, Se(e)),
        },
        [`${n}-item-disabled, ${n}-submenu-disabled`]: {
          color: `${S} !important`,
        },
        [`${n}-item:not(${n}-item-selected):not(${n}-submenu-selected)`]: {
          [`&:hover, > ${n}-submenu-title:hover`]: { color: y },
        },
        [`&:not(${n}-horizontal)`]: {
          [`${n}-item:not(${n}-item-selected)`]: {
            "&:hover": { backgroundColor: k },
            "&:active": { backgroundColor: A },
          },
          [`${n}-submenu-title`]: {
            "&:hover": { backgroundColor: k },
            "&:active": { backgroundColor: A },
          },
        },
        [`${n}-item-danger`]: {
          color: C,
          [`&${n}-item:hover`]: {
            [`&:not(${n}-item-selected):not(${n}-submenu-selected)`]: {
              color: w,
            },
          },
          [`&${n}-item:active`]: { background: E },
        },
        [`${n}-item a`]: { "&, &:hover": { color: `inherit` } },
        [`${n}-item-selected`]: {
          color: i,
          [`&${n}-item-danger`]: { color: T },
          "a, a:hover": { color: `inherit` },
        },
        [`& ${n}-item-selected`]: {
          backgroundColor: l,
          [`&${n}-item-danger`]: { backgroundColor: D },
        },
        [`&${n}-submenu > ${n}`]: { backgroundColor: j },
        [`&${n}-popup > ${n}`]: { backgroundColor: O },
        [`&${n}-submenu-popup > ${n}`]: { backgroundColor: O },
        [`&${n}-horizontal`]: Object.assign(
          Object.assign({}, t === `dark` ? { borderBottom: 0 } : {}),
          {
            [`> ${n}-item, > ${n}-submenu`]: {
              top: p,
              marginTop: e.calc(p).mul(-1).equal(),
              marginBottom: 0,
              borderRadius: P,
              "&::after": {
                position: `absolute`,
                insetInline: _,
                bottom: 0,
                borderBottom: `${d(u)} solid transparent`,
                transition: `border-color ${m} ${h}`,
                content: `""`,
              },
              "&:hover, &-active, &-open": {
                background: F,
                "&::after": { borderBottomWidth: u, borderBottomColor: M },
              },
              "&-selected": {
                color: M,
                backgroundColor: N,
                "&:hover": { backgroundColor: N },
                "&::after": { borderBottomWidth: u, borderBottomColor: M },
              },
            },
          }
        ),
        [`&${n}-root`]: {
          [`&${n}-inline, &${n}-vertical`]: {
            borderInlineEnd: `${d(p)} ${b} ${x}`,
          },
        },
        [`&${n}-inline`]: {
          [`${n}-sub${n}-inline`]: { background: c },
          [`${n}-item`]: {
            position: `relative`,
            "&::after": {
              position: `absolute`,
              insetBlock: 0,
              insetInlineEnd: 0,
              borderInlineEnd: `${d(f)} solid ${i}`,
              transform: `scaleY(0.0001)`,
              opacity: 0,
              transition: [`transform ${v} ${g}`, `opacity ${v} ${g}`].join(
                `,`
              ),
              content: `""`,
            },
            [`&${n}-item-danger`]: { "&::after": { borderInlineEndColor: T } },
          },
          [`${n}-selected, ${n}-item-selected`]: {
            "&::after": {
              transform: `scaleY(1)`,
              opacity: 1,
              transition: [`transform ${v} ${h}`, `opacity ${v} ${h}`].join(
                `,`
              ),
            },
          },
        },
      },
    };
  },
  we = (e) => {
    let {
        componentCls: t,
        itemHeight: n,
        itemMarginInline: r,
        padding: i,
        menuArrowSize: a,
        marginXS: o,
        itemMarginBlock: s,
        itemWidth: c,
        itemPaddingInline: l,
      } = e,
      u = e.calc(a).add(i).add(o).equal();
    return {
      [`${t}-item`]: { position: `relative`, overflow: `hidden` },
      [`${t}-item, ${t}-submenu-title`]: {
        height: n,
        lineHeight: d(n),
        paddingInline: l,
        overflow: `hidden`,
        textOverflow: `ellipsis`,
        marginInline: r,
        marginBlock: s,
        width: c,
      },
      [`> ${t}-item,
            > ${t}-submenu > ${t}-submenu-title`]: {
        height: n,
        lineHeight: d(n),
      },
      [`${t}-item-group-list ${t}-submenu-title,
            ${t}-submenu-title`]: { paddingInlineEnd: u },
    };
  },
  Te = (e) => {
    let {
        componentCls: t,
        iconCls: n,
        itemHeight: r,
        colorTextLightSolid: i,
        dropdownWidth: a,
        controlHeightLG: o,
        motionEaseOut: s,
        paddingXL: c,
        itemMarginInline: l,
        fontSizeLG: u,
        motionDurationFast: f,
        motionDurationSlow: p,
        paddingXS: m,
        boxShadowSecondary: g,
        collapsedWidth: _,
        collapsedIconSize: v,
      } = e,
      y = {
        height: r,
        lineHeight: d(r),
        listStylePosition: `inside`,
        listStyleType: `disc`,
      };
    return [
      {
        [t]: {
          "&-inline, &-vertical": Object.assign(
            { [`&${t}-root`]: { boxShadow: `none` } },
            we(e)
          ),
        },
        [`${t}-submenu-popup`]: {
          [`${t}-vertical`]: Object.assign(Object.assign({}, we(e)), {
            boxShadow: g,
          }),
        },
      },
      {
        [`${t}-submenu-popup ${t}-vertical${t}-sub`]: {
          minWidth: a,
          maxHeight: `calc(100vh - ${d(e.calc(o).mul(2.5).equal())})`,
          padding: `0`,
          overflow: `hidden`,
          borderInlineEnd: 0,
          "&:not([class*='-active'])": {
            overflowX: `hidden`,
            overflowY: `auto`,
          },
        },
      },
      {
        [`${t}-inline`]: {
          width: `100%`,
          [`&${t}-root`]: {
            [`${t}-item, ${t}-submenu-title`]: {
              display: `flex`,
              alignItems: `center`,
              transition: [
                `border-color ${p}`,
                `background ${p}`,
                `padding ${f} ${s}`,
              ].join(`,`),
              [`> ${t}-title-content`]: {
                flex: `auto`,
                minWidth: 0,
                overflow: `hidden`,
                textOverflow: `ellipsis`,
              },
              "> *": { flex: `none` },
            },
          },
          [`${t}-sub${t}-inline`]: {
            padding: 0,
            border: 0,
            borderRadius: 0,
            boxShadow: `none`,
            [`& > ${t}-submenu > ${t}-submenu-title`]: y,
            [`& ${t}-item-group-title`]: { paddingInlineStart: c },
          },
          [`${t}-item`]: y,
        },
      },
      {
        [`${t}-inline-collapsed`]: {
          width: _,
          [`&${t}-root`]: {
            [`${t}-item, ${t}-submenu ${t}-submenu-title`]: {
              [`> ${t}-inline-collapsed-noicon`]: {
                fontSize: u,
                textAlign: `center`,
              },
            },
          },
          [`> ${t}-item,
          > ${t}-item-group > ${t}-item-group-list > ${t}-item,
          > ${t}-item-group > ${t}-item-group-list > ${t}-submenu > ${t}-submenu-title,
          > ${t}-submenu > ${t}-submenu-title`]: {
            insetInlineStart: 0,
            paddingInline: `calc(50% - ${d(e.calc(v).div(2).equal())} - ${d(
              l
            )})`,
            textOverflow: `clip`,
            [`
            ${t}-submenu-arrow,
            ${t}-submenu-expand-icon
          `]: { opacity: 0 },
            [`${t}-item-icon, ${n}`]: {
              margin: 0,
              fontSize: v,
              lineHeight: d(r),
              "+ span": { display: `inline-block`, opacity: 0 },
            },
          },
          [`${t}-item-icon, ${n}`]: { display: `inline-block` },
          "&-tooltip": {
            pointerEvents: `none`,
            [`${t}-item-icon, ${n}`]: { display: `none` },
            "a, a:hover": { color: i },
          },
          [`${t}-item-group-title`]: Object.assign(Object.assign({}, h), {
            paddingInline: m,
          }),
        },
      },
    ];
  },
  Ee = (e) => {
    let {
      componentCls: t,
      motionDurationSlow: n,
      motionDurationMid: r,
      motionEaseInOut: i,
      motionEaseOut: a,
      iconCls: o,
      iconSize: s,
      iconMarginInlineEnd: c,
    } = e;
    return {
      [`${t}-item, ${t}-submenu-title`]: {
        position: `relative`,
        display: `block`,
        margin: 0,
        whiteSpace: `nowrap`,
        cursor: `pointer`,
        transition: [
          `border-color ${n}`,
          `background ${n}`,
          `padding calc(${n} + 0.1s) ${i}`,
        ].join(`,`),
        [`${t}-item-icon, ${o}`]: {
          minWidth: s,
          fontSize: s,
          transition: [
            `font-size ${r} ${a}`,
            `margin ${n} ${i}`,
            `color ${n}`,
          ].join(`,`),
          "+ span": {
            marginInlineStart: c,
            opacity: 1,
            transition: [`opacity ${n} ${i}`, `margin ${n}`, `color ${n}`].join(
              `,`
            ),
          },
        },
        [`${t}-item-icon`]: Object.assign({}, g()),
        [`&${t}-item-only-child`]: {
          [`> ${o}, > ${t}-item-icon`]: { marginInlineEnd: 0 },
        },
      },
      [`${t}-item-disabled, ${t}-submenu-disabled`]: {
        background: `none !important`,
        cursor: `not-allowed`,
        "&::after": { borderColor: `transparent !important` },
        a: {
          color: `inherit !important`,
          cursor: `not-allowed`,
          pointerEvents: `none`,
        },
        [`> ${t}-submenu-title`]: {
          color: `inherit !important`,
          cursor: `not-allowed`,
        },
      },
    };
  },
  De = (e) => {
    let {
      componentCls: t,
      motionDurationSlow: n,
      motionEaseInOut: r,
      borderRadius: i,
      menuArrowSize: a,
      menuArrowOffset: o,
    } = e;
    return {
      [`${t}-submenu`]: {
        "&-expand-icon, &-arrow": {
          position: `absolute`,
          top: `50%`,
          insetInlineEnd: e.margin,
          width: a,
          color: `currentcolor`,
          transform: `translateY(-50%)`,
          transition: `transform ${n} ${r}, opacity ${n}`,
        },
        "&-arrow": {
          "&::before, &::after": {
            position: `absolute`,
            width: e.calc(a).mul(0.6).equal(),
            height: e.calc(a).mul(0.15).equal(),
            backgroundColor: `currentcolor`,
            borderRadius: i,
            transition: [
              `background ${n} ${r}`,
              `transform ${n} ${r}`,
              `top ${n} ${r}`,
              `color ${n} ${r}`,
            ].join(`,`),
            content: `""`,
          },
          "&::before": {
            transform: `rotate(45deg) translateY(${d(
              e.calc(o).mul(-1).equal()
            )})`,
          },
          "&::after": { transform: `rotate(-45deg) translateY(${d(o)})` },
        },
      },
    };
  },
  Oe = (e) => {
    let {
      antCls: t,
      componentCls: n,
      fontSize: r,
      motionDurationSlow: i,
      motionDurationMid: a,
      motionEaseInOut: o,
      paddingXS: s,
      padding: c,
      colorSplit: l,
      lineWidth: u,
      zIndexPopup: f,
      borderRadiusLG: p,
      subMenuItemBorderRadius: m,
      menuArrowSize: h,
      menuArrowOffset: g,
      lineType: _,
      groupTitleLineHeight: b,
      groupTitleFontSize: x,
    } = e;
    return [
      {
        "": {
          [n]: Object.assign(Object.assign({}, v()), {
            "&-hidden": { display: `none` },
          }),
        },
        [`${n}-submenu-hidden`]: { display: `none` },
      },
      {
        [n]: Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(Object.assign(Object.assign({}, y(e)), v()), {
                  marginBottom: 0,
                  paddingInlineStart: 0,
                  fontSize: r,
                  lineHeight: 0,
                  listStyle: `none`,
                  outline: `none`,
                  transition: `width ${i} cubic-bezier(0.2, 0, 0, 1) 0s`,
                  "ul, ol": { margin: 0, padding: 0, listStyle: `none` },
                  "&-overflow": {
                    display: `flex`,
                    [`${n}-item`]: { flex: `none` },
                  },
                  [`${n}-item, ${n}-submenu, ${n}-submenu-title`]: {
                    borderRadius: e.itemBorderRadius,
                  },
                  [`${n}-item-group-title`]: {
                    padding: `${d(s)} ${d(c)}`,
                    fontSize: x,
                    lineHeight: b,
                    transition: `all ${i}`,
                  },
                  [`&-horizontal ${n}-submenu`]: {
                    transition: [
                      `border-color ${i} ${o}`,
                      `background ${i} ${o}`,
                    ].join(`,`),
                  },
                  [`${n}-submenu, ${n}-submenu-inline`]: {
                    transition: [
                      `border-color ${i} ${o}`,
                      `background ${i} ${o}`,
                      `padding ${a} ${o}`,
                    ].join(`,`),
                  },
                  [`${n}-submenu ${n}-sub`]: {
                    cursor: `initial`,
                    transition: [
                      `background ${i} ${o}`,
                      `padding ${i} ${o}`,
                    ].join(`,`),
                  },
                  [`${n}-title-content`]: {
                    transition: `color ${i}`,
                    "&-with-extra": {
                      display: `inline-flex`,
                      alignItems: `center`,
                      width: `100%`,
                    },
                    [`> ${t}-typography-ellipsis-single-line`]: {
                      display: `inline`,
                      verticalAlign: `unset`,
                    },
                    [`${n}-item-extra`]: {
                      marginInlineStart: `auto`,
                      paddingInlineStart: e.padding,
                    },
                  },
                  [`${n}-item a`]: {
                    "&::before": {
                      position: `absolute`,
                      inset: 0,
                      backgroundColor: `transparent`,
                      content: `""`,
                    },
                  },
                  [`${n}-item-divider`]: {
                    overflow: `hidden`,
                    lineHeight: 0,
                    borderColor: l,
                    borderStyle: _,
                    borderWidth: 0,
                    borderTopWidth: u,
                    marginBlock: u,
                    padding: 0,
                    "&-dashed": { borderStyle: `dashed` },
                  },
                }),
                Ee(e)
              ),
              {
                [`${n}-item-group`]: {
                  [`${n}-item-group-list`]: {
                    margin: 0,
                    padding: 0,
                    [`${n}-item, ${n}-submenu-title`]: {
                      paddingInline: `${d(e.calc(r).mul(2).equal())} ${d(c)}`,
                    },
                  },
                },
                "&-submenu": {
                  "&-popup": {
                    position: `absolute`,
                    zIndex: f,
                    borderRadius: p,
                    boxShadow: `none`,
                    transformOrigin: `0 0`,
                    [`&${n}-submenu`]: { background: `transparent` },
                    "&::before": {
                      position: `absolute`,
                      inset: 0,
                      zIndex: -1,
                      width: `100%`,
                      height: `100%`,
                      opacity: 0,
                      content: `""`,
                    },
                    [`> ${n}`]: Object.assign(
                      Object.assign(
                        Object.assign({ borderRadius: p }, Ee(e)),
                        De(e)
                      ),
                      {
                        [`${n}-item, ${n}-submenu > ${n}-submenu-title`]: {
                          borderRadius: m,
                        },
                        [`${n}-submenu-title::after`]: {
                          transition: `transform ${i} ${o}`,
                        },
                      }
                    ),
                  },
                  "\n          &-placement-leftTop,\n          &-placement-bottomRight,\n          ":
                    { transformOrigin: `100% 0` },
                  "\n          &-placement-leftBottom,\n          &-placement-topRight,\n          ":
                    { transformOrigin: `100% 100%` },
                  "\n          &-placement-rightBottom,\n          &-placement-topLeft,\n          ":
                    { transformOrigin: `0 100%` },
                  "\n          &-placement-bottomLeft,\n          &-placement-rightTop,\n          ":
                    { transformOrigin: `0 0` },
                  "\n          &-placement-leftTop,\n          &-placement-leftBottom\n          ":
                    { paddingInlineEnd: e.paddingXS },
                  "\n          &-placement-rightTop,\n          &-placement-rightBottom\n          ":
                    { paddingInlineStart: e.paddingXS },
                  "\n          &-placement-topRight,\n          &-placement-topLeft\n          ":
                    { paddingBottom: e.paddingXS },
                  "\n          &-placement-bottomRight,\n          &-placement-bottomLeft\n          ":
                    { paddingTop: e.paddingXS },
                },
              }
            ),
            De(e)
          ),
          {
            [`&-inline-collapsed ${n}-submenu-arrow,
        &-inline ${n}-submenu-arrow`]: {
              "&::before": { transform: `rotate(-45deg) translateX(${d(g)})` },
              "&::after": {
                transform: `rotate(45deg) translateX(${d(
                  e.calc(g).mul(-1).equal()
                )})`,
              },
            },
            [`${n}-submenu-open${n}-submenu-inline > ${n}-submenu-title > ${n}-submenu-arrow`]:
              {
                transform: `translateY(${d(
                  e.calc(h).mul(0.2).mul(-1).equal()
                )})`,
                "&::after": {
                  transform: `rotate(-45deg) translateX(${d(
                    e.calc(g).mul(-1).equal()
                  )})`,
                },
                "&::before": { transform: `rotate(45deg) translateX(${d(g)})` },
              },
          }
        ),
      },
      { [`${t}-layout-header`]: { [n]: { lineHeight: `inherit` } } },
    ];
  },
  ke = (e) => {
    let {
        colorPrimary: t,
        colorError: n,
        colorTextDisabled: r,
        colorErrorBg: i,
        colorText: a,
        colorTextDescription: o,
        colorBgContainer: s,
        colorFillAlter: l,
        colorFillContent: u,
        lineWidth: d,
        lineWidthBold: f,
        controlItemBgActive: p,
        colorBgTextHover: m,
        controlHeightLG: h,
        lineHeight: g,
        colorBgElevated: _,
        marginXXS: v,
        padding: y,
        fontSize: b,
        controlHeightSM: x,
        fontSizeLG: S,
        colorTextLightSolid: C,
        colorErrorHover: w,
      } = e,
      T = e.activeBarWidth ?? 0,
      E = e.activeBarBorderWidth ?? d,
      D = e.itemMarginInline ?? e.marginXXS,
      O = new c(C).setA(0.65).toRgbString();
    return {
      dropdownWidth: 160,
      zIndexPopup: e.zIndexPopupBase + 50,
      radiusItem: e.borderRadiusLG,
      itemBorderRadius: e.borderRadiusLG,
      radiusSubMenuItem: e.borderRadiusSM,
      subMenuItemBorderRadius: e.borderRadiusSM,
      colorItemText: a,
      itemColor: a,
      colorItemTextHover: a,
      itemHoverColor: a,
      colorItemTextHoverHorizontal: t,
      horizontalItemHoverColor: t,
      colorGroupTitle: o,
      groupTitleColor: o,
      colorItemTextSelected: t,
      itemSelectedColor: t,
      subMenuItemSelectedColor: t,
      colorItemTextSelectedHorizontal: t,
      horizontalItemSelectedColor: t,
      colorItemBg: s,
      itemBg: s,
      colorItemBgHover: m,
      itemHoverBg: m,
      colorItemBgActive: u,
      itemActiveBg: p,
      colorSubItemBg: l,
      subMenuItemBg: l,
      colorItemBgSelected: p,
      itemSelectedBg: p,
      colorItemBgSelectedHorizontal: `transparent`,
      horizontalItemSelectedBg: `transparent`,
      colorActiveBarWidth: 0,
      activeBarWidth: T,
      colorActiveBarHeight: f,
      activeBarHeight: f,
      colorActiveBarBorderSize: d,
      activeBarBorderWidth: E,
      colorItemTextDisabled: r,
      itemDisabledColor: r,
      colorDangerItemText: n,
      dangerItemColor: n,
      colorDangerItemTextHover: n,
      dangerItemHoverColor: n,
      colorDangerItemTextSelected: n,
      dangerItemSelectedColor: n,
      colorDangerItemBgActive: i,
      dangerItemActiveBg: i,
      colorDangerItemBgSelected: i,
      dangerItemSelectedBg: i,
      itemMarginInline: D,
      horizontalItemBorderRadius: 0,
      horizontalItemHoverBg: `transparent`,
      itemHeight: h,
      groupTitleLineHeight: g,
      collapsedWidth: h * 2,
      popupBg: _,
      itemMarginBlock: v,
      itemPaddingInline: y,
      horizontalLineHeight: `${h * 1.15}px`,
      iconSize: b,
      iconMarginInlineEnd: x - b,
      collapsedIconSize: S,
      groupTitleFontSize: b,
      darkItemDisabledColor: new c(C).setA(0.25).toRgbString(),
      darkItemColor: O,
      darkDangerItemColor: n,
      darkItemBg: `#001529`,
      darkPopupBg: `#001529`,
      darkSubMenuItemBg: `#000c17`,
      darkItemSelectedColor: C,
      darkItemSelectedBg: t,
      darkDangerItemSelectedBg: n,
      darkItemHoverBg: `transparent`,
      darkGroupTitleColor: O,
      darkItemHoverColor: C,
      darkDangerItemHoverColor: w,
      darkDangerItemSelectedColor: C,
      darkDangerItemActiveBg: n,
      itemWidth: T ? `calc(100% + ${E}px)` : `calc(100% - ${D * 2}px)`,
    };
  },
  Ae = (e, t = e, n = !0) =>
    x(
      `Menu`,
      (e) => {
        let {
            colorBgElevated: t,
            controlHeightLG: n,
            fontSize: r,
            darkItemColor: i,
            darkDangerItemColor: a,
            darkItemBg: o,
            darkSubMenuItemBg: s,
            darkItemSelectedColor: c,
            darkItemSelectedBg: l,
            darkDangerItemSelectedBg: u,
            darkItemHoverBg: d,
            darkGroupTitleColor: f,
            darkItemHoverColor: m,
            darkItemDisabledColor: h,
            darkDangerItemHoverColor: g,
            darkDangerItemSelectedColor: _,
            darkDangerItemActiveBg: v,
            popupBg: y,
            darkPopupBg: b,
          } = e,
          x = e.calc(r).div(7).mul(5).equal(),
          S = p(e, {
            menuArrowSize: x,
            menuHorizontalHeight: e.calc(n).mul(1.15).equal(),
            menuArrowOffset: e.calc(x).mul(0.25).equal(),
            menuSubMenuBg: t,
            calc: e.calc,
            popupBg: y,
          }),
          C = p(S, {
            itemColor: i,
            itemHoverColor: m,
            groupTitleColor: f,
            itemSelectedColor: c,
            subMenuItemSelectedColor: c,
            itemBg: o,
            popupBg: b,
            subMenuItemBg: s,
            itemActiveBg: `transparent`,
            itemSelectedBg: l,
            activeBarHeight: 0,
            activeBarBorderWidth: 0,
            itemHoverBg: d,
            itemDisabledColor: h,
            dangerItemColor: a,
            dangerItemHoverColor: g,
            dangerItemSelectedColor: _,
            dangerItemActiveBg: v,
            dangerItemSelectedBg: u,
            menuSubMenuBg: s,
            horizontalItemSelectedColor: c,
            horizontalItemSelectedBg: l,
          });
        return [
          Oe(S),
          be(S),
          Te(S),
          Ce(S, `light`),
          Ce(C, `dark`),
          xe(S),
          B(S),
          W(S, `slide-up`),
          W(S, `slide-down`),
          A(S, `zoom-big`),
        ];
      },
      ke,
      {
        deprecatedTokens: [
          [`colorGroupTitle`, `groupTitleColor`],
          [`radiusItem`, `itemBorderRadius`],
          [`radiusSubMenuItem`, `subMenuItemBorderRadius`],
          [`colorItemText`, `itemColor`],
          [`colorItemTextHover`, `itemHoverColor`],
          [`colorItemTextHoverHorizontal`, `horizontalItemHoverColor`],
          [`colorItemTextSelected`, `itemSelectedColor`],
          [`colorItemTextSelectedHorizontal`, `horizontalItemSelectedColor`],
          [`colorItemTextDisabled`, `itemDisabledColor`],
          [`colorDangerItemText`, `dangerItemColor`],
          [`colorDangerItemTextHover`, `dangerItemHoverColor`],
          [`colorDangerItemTextSelected`, `dangerItemSelectedColor`],
          [`colorDangerItemBgActive`, `dangerItemActiveBg`],
          [`colorDangerItemBgSelected`, `dangerItemSelectedBg`],
          [`colorItemBg`, `itemBg`],
          [`colorItemBgHover`, `itemHoverBg`],
          [`colorSubItemBg`, `subMenuItemBg`],
          [`colorItemBgActive`, `itemActiveBg`],
          [`colorItemBgSelectedHorizontal`, `horizontalItemSelectedBg`],
          [`colorActiveBarWidth`, `activeBarWidth`],
          [`colorActiveBarHeight`, `activeBarHeight`],
          [`colorActiveBarBorderSize`, `activeBarBorderWidth`],
          [`colorItemBgSelected`, `itemSelectedBg`],
        ],
        injectStyle: n,
        unitless: { groupTitleLineHeight: !0 },
      }
    )(e, t),
  je = (e) => {
    var t;
    let { popupClassName: n, icon: r, title: i, theme: a } = e,
      o = J.useContext(X),
      { prefixCls: s, inlineCollapsed: c, theme: l } = o,
      u = se(),
      d;
    if (!r)
      d =
        c && !u.length && i && typeof i == `string`
          ? J.createElement(
              `div`,
              { className: `${s}-inline-collapsed-noicon` },
              i.charAt(0)
            )
          : J.createElement(`span`, { className: `${s}-title-content` }, i);
    else {
      let e = J.isValidElement(i) && i.type === `span`;
      d = J.createElement(
        J.Fragment,
        null,
        T(r, {
          className: (0, Y.default)(
            J.isValidElement(r)
              ? (t = r.props) == null
                ? void 0
                : t.className
              : void 0,
            `${s}-item-icon`
          ),
        }),
        e ? i : J.createElement(`span`, { className: `${s}-title-content` }, i)
      );
    }
    let f = J.useMemo(
        () => Object.assign(Object.assign({}, o), { firstLevel: !1 }),
        [o]
      ),
      [p] = k(`Menu`);
    return J.createElement(
      X.Provider,
      { value: f },
      J.createElement(
        G,
        Object.assign({}, w(e, [`icon`]), {
          title: d,
          popupClassName: (0, Y.default)(s, n, `${s}-${a || l}`),
          popupStyle: Object.assign({ zIndex: p }, e.popupStyle),
        })
      )
    );
  },
  Me = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  };
function Ne(e) {
  return e === null || e === !1;
}
var Pe = { item: Z, submenu: je, divider: ge },
  Fe = (0, J.forwardRef)((e, t) => {
    var n;
    let r = J.useContext(ve),
      i = r || {},
      {
        getPrefixCls: a,
        getPopupContainer: c,
        direction: l,
        menu: u,
      } = J.useContext(s),
      d = a(),
      {
        prefixCls: f,
        className: p,
        style: m,
        theme: h = `light`,
        expandIcon: g,
        _internalDisableMenuItemTitleTooltip: _,
        inlineCollapsed: v,
        siderCollapsed: y,
        rootClassName: b,
        mode: x,
        selectable: S,
        onClick: C,
        overflowedIndicatorPopupClassName: E,
      } = e,
      D = Me(e, [
        `prefixCls`,
        `className`,
        `style`,
        `theme`,
        `expandIcon`,
        `_internalDisableMenuItemTitleTooltip`,
        `inlineCollapsed`,
        `siderCollapsed`,
        `rootClassName`,
        `mode`,
        `selectable`,
        `onClick`,
        `overflowedIndicatorPopupClassName`,
      ]),
      O = w(D, [`collapsedWidth`]);
    (n = i.validator) == null || n.call(i, { mode: x });
    let k = o((...e) => {
        var t;
        C == null || C.apply(void 0, e), (t = i.onClick) == null || t.call(i);
      }),
      A = i.mode || x,
      j = S ?? i.selectable,
      N = v ?? y,
      P = {
        horizontal: { motionName: `${d}-slide-up` },
        inline: M(d),
        other: { motionName: `${d}-zoom-big` },
      },
      F = a(`menu`, f || i.prefixCls),
      I = R(F),
      [L, z, B] = Ae(F, I, !r),
      V = (0, Y.default)(`${F}-${h}`, u == null ? void 0 : u.className, p),
      H = J.useMemo(() => {
        var e;
        if (typeof g == `function` || Ne(g)) return g || null;
        if (typeof i.expandIcon == `function` || Ne(i.expandIcon))
          return i.expandIcon || null;
        if (
          typeof (u == null ? void 0 : u.expandIcon) == `function` ||
          Ne(u == null ? void 0 : u.expandIcon)
        )
          return (u == null ? void 0 : u.expandIcon) || null;
        let t =
          g ??
          (i == null ? void 0 : i.expandIcon) ??
          (u == null ? void 0 : u.expandIcon);
        return T(t, {
          className: (0, Y.default)(
            `${F}-submenu-expand-icon`,
            J.isValidElement(t)
              ? (e = t.props) == null
                ? void 0
                : e.className
              : void 0
          ),
        });
      }, [
        g,
        i == null ? void 0 : i.expandIcon,
        u == null ? void 0 : u.expandIcon,
        F,
      ]),
      U = J.useMemo(
        () => ({
          prefixCls: F,
          inlineCollapsed: N || !1,
          direction: l,
          firstLevel: !0,
          theme: h,
          mode: A,
          disableMenuItemTitleTooltip: _,
        }),
        [F, N, l, _, h]
      );
    return L(
      J.createElement(
        ve.Provider,
        { value: null },
        J.createElement(
          X.Provider,
          { value: U },
          J.createElement(
            ae,
            Object.assign(
              {
                getPopupContainer: c,
                overflowedIndicator: J.createElement(q, null),
                overflowedIndicatorPopupClassName: (0, Y.default)(
                  F,
                  `${F}-${h}`,
                  E
                ),
                mode: A,
                selectable: j,
                onClick: k,
              },
              O,
              {
                inlineCollapsed: N,
                style: Object.assign(
                  Object.assign({}, u == null ? void 0 : u.style),
                  m
                ),
                className: V,
                prefixCls: F,
                direction: l,
                defaultMotions: P,
                expandIcon: H,
                ref: t,
                rootClassName: (0, Y.default)(b, z, i.rootClassName, B, I),
                _internalComponents: Pe,
              }
            )
          )
        )
      )
    );
  }),
  Q = (0, J.forwardRef)((e, t) => {
    let n = (0, J.useRef)(null),
      r = J.useContext(me);
    return (
      (0, J.useImperativeHandle)(t, () => ({
        menu: n.current,
        focus: (e) => {
          var t;
          (t = n.current) == null || t.focus(e);
        },
      })),
      J.createElement(Fe, Object.assign({ ref: n }, e, r))
    );
  });
(Q.Item = Z), (Q.SubMenu = je), (Q.Divider = ge), (Q.ItemGroup = oe);
var Ie = (e) => {
    let {
        componentCls: t,
        menuCls: n,
        colorError: r,
        colorTextLightSolid: i,
      } = e,
      a = `${n}-item`;
    return {
      [`${t}, ${t}-menu-submenu`]: {
        [`${n} ${a}`]: {
          [`&${a}-danger:not(${a}-disabled)`]: {
            color: r,
            "&:hover": { color: i, backgroundColor: r },
          },
        },
      },
    };
  },
  Le = (e) => {
    let {
      componentCls: t,
      menuCls: n,
      zIndexPopup: r,
      dropdownArrowDistance: i,
      sizePopupArrow: a,
      antCls: o,
      iconCls: s,
      motionDurationMid: c,
      paddingBlock: l,
      fontSize: u,
      dropdownEdgeChildPadding: f,
      colorTextDisabled: p,
      fontSizeIcon: h,
      controlPaddingHorizontal: g,
      colorBgElevated: _,
    } = e;
    return [
      {
        [t]: {
          position: `absolute`,
          top: -9999,
          left: { _skip_check_: !0, value: -9999 },
          zIndex: r,
          display: `block`,
          "&::before": {
            position: `absolute`,
            insetBlock: e.calc(a).div(2).sub(i).equal(),
            zIndex: -9999,
            opacity: 1e-4,
            content: `""`,
          },
          "&-menu-vertical": { maxHeight: `100vh`, overflowY: `auto` },
          [`&-trigger${o}-btn`]: {
            [`& > ${s}-down, & > ${o}-btn-icon > ${s}-down`]: { fontSize: h },
          },
          [`${t}-wrap`]: {
            position: `relative`,
            [`${o}-btn > ${s}-down`]: { fontSize: h },
            [`${s}-down::before`]: { transition: `transform ${c}` },
          },
          [`${t}-wrap-open`]: {
            [`${s}-down::before`]: { transform: `rotate(180deg)` },
          },
          "\n        &-hidden,\n        &-menu-hidden,\n        &-menu-submenu-hidden\n      ":
            { display: `none` },
          [`&${o}-slide-down-enter${o}-slide-down-enter-active${t}-placement-bottomLeft,
          &${o}-slide-down-appear${o}-slide-down-appear-active${t}-placement-bottomLeft,
          &${o}-slide-down-enter${o}-slide-down-enter-active${t}-placement-bottom,
          &${o}-slide-down-appear${o}-slide-down-appear-active${t}-placement-bottom,
          &${o}-slide-down-enter${o}-slide-down-enter-active${t}-placement-bottomRight,
          &${o}-slide-down-appear${o}-slide-down-appear-active${t}-placement-bottomRight`]:
            { animationName: H },
          [`&${o}-slide-up-enter${o}-slide-up-enter-active${t}-placement-topLeft,
          &${o}-slide-up-appear${o}-slide-up-appear-active${t}-placement-topLeft,
          &${o}-slide-up-enter${o}-slide-up-enter-active${t}-placement-top,
          &${o}-slide-up-appear${o}-slide-up-appear-active${t}-placement-top,
          &${o}-slide-up-enter${o}-slide-up-enter-active${t}-placement-topRight,
          &${o}-slide-up-appear${o}-slide-up-appear-active${t}-placement-topRight`]:
            { animationName: te },
          [`&${o}-slide-down-leave${o}-slide-down-leave-active${t}-placement-bottomLeft,
          &${o}-slide-down-leave${o}-slide-down-leave-active${t}-placement-bottom,
          &${o}-slide-down-leave${o}-slide-down-leave-active${t}-placement-bottomRight`]:
            { animationName: ee },
          [`&${o}-slide-up-leave${o}-slide-up-leave-active${t}-placement-topLeft,
          &${o}-slide-up-leave${o}-slide-up-leave-active${t}-placement-top,
          &${o}-slide-up-leave${o}-slide-up-leave-active${t}-placement-topRight`]:
            { animationName: U },
        },
      },
      I(e, _, { arrowPlacement: { top: !0, bottom: !0 } }),
      {
        [`${t} ${n}`]: { position: `relative`, margin: 0 },
        [`${n}-submenu-popup`]: {
          position: `absolute`,
          zIndex: r,
          background: `transparent`,
          boxShadow: `none`,
          transformOrigin: `0 0`,
          "ul, li": { listStyle: `none`, margin: 0 },
        },
        [`${t}, ${t}-menu-submenu`]: Object.assign(Object.assign({}, y(e)), {
          [n]: Object.assign(
            Object.assign(
              {
                padding: f,
                listStyleType: `none`,
                backgroundColor: _,
                backgroundClip: `padding-box`,
                borderRadius: e.borderRadiusLG,
                outline: `none`,
                boxShadow: e.boxShadowSecondary,
              },
              m(e)
            ),
            {
              "&:empty": { padding: 0, boxShadow: `none` },
              [`${n}-item-group-title`]: {
                padding: `${d(l)} ${d(g)}`,
                color: e.colorTextDescription,
                transition: `all ${c}`,
              },
              [`${n}-item`]: {
                position: `relative`,
                display: `flex`,
                alignItems: `center`,
              },
              [`${n}-item-icon`]: {
                minWidth: u,
                marginInlineEnd: e.marginXS,
                fontSize: e.fontSizeSM,
              },
              [`${n}-title-content`]: {
                flex: `auto`,
                "&-with-extra": {
                  display: `inline-flex`,
                  alignItems: `center`,
                  width: `100%`,
                },
                "> a": {
                  color: `inherit`,
                  transition: `all ${c}`,
                  "&:hover": { color: `inherit` },
                  "&::after": { position: `absolute`, inset: 0, content: `""` },
                },
                [`${n}-item-extra`]: {
                  paddingInlineStart: e.padding,
                  marginInlineStart: `auto`,
                  fontSize: e.fontSizeSM,
                  color: e.colorTextDescription,
                },
              },
              [`${n}-item, ${n}-submenu-title`]: Object.assign(
                Object.assign(
                  {
                    display: `flex`,
                    margin: 0,
                    padding: `${d(l)} ${d(g)}`,
                    color: e.colorText,
                    fontWeight: `normal`,
                    fontSize: u,
                    lineHeight: e.lineHeight,
                    cursor: `pointer`,
                    transition: `all ${c}`,
                    borderRadius: e.borderRadiusSM,
                    "&:hover, &-active": {
                      backgroundColor: e.controlItemBgHover,
                    },
                  },
                  m(e)
                ),
                {
                  "&-selected": {
                    color: e.colorPrimary,
                    backgroundColor: e.controlItemBgActive,
                    "&:hover, &-active": {
                      backgroundColor: e.controlItemBgActiveHover,
                    },
                  },
                  "&-disabled": {
                    color: p,
                    cursor: `not-allowed`,
                    "&:hover": {
                      color: p,
                      backgroundColor: _,
                      cursor: `not-allowed`,
                    },
                    a: { pointerEvents: `none` },
                  },
                  "&-divider": {
                    height: 1,
                    margin: `${d(e.marginXXS)} 0`,
                    overflow: `hidden`,
                    lineHeight: 0,
                    backgroundColor: e.colorSplit,
                  },
                  [`${t}-menu-submenu-expand-icon`]: {
                    position: `absolute`,
                    insetInlineEnd: e.paddingXS,
                    [`${t}-menu-submenu-arrow-icon`]: {
                      marginInlineEnd: `0 !important`,
                      color: e.colorIcon,
                      fontSize: h,
                      fontStyle: `normal`,
                    },
                  },
                }
              ),
              [`${n}-item-group-list`]: {
                margin: `0 ${d(e.marginXS)}`,
                padding: 0,
                listStyle: `none`,
              },
              [`${n}-submenu-title`]: {
                paddingInlineEnd: e.calc(g).add(e.fontSizeSM).equal(),
              },
              [`${n}-submenu-vertical`]: { position: `relative` },
              [`${n}-submenu${n}-submenu-disabled ${t}-menu-submenu-title`]: {
                [`&, ${t}-menu-submenu-arrow-icon`]: {
                  color: p,
                  backgroundColor: _,
                  cursor: `not-allowed`,
                },
              },
              [`${n}-submenu-selected ${t}-menu-submenu-title`]: {
                color: e.colorPrimary,
              },
            }
          ),
        }),
      },
      [
        W(e, `slide-up`),
        W(e, `slide-down`),
        V(e, `move-up`),
        V(e, `move-down`),
        A(e, `zoom-big`),
      ],
    ];
  },
  Re = x(
    `Dropdown`,
    (e) => {
      let {
          marginXXS: t,
          sizePopupArrow: n,
          paddingXXS: r,
          componentCls: i,
        } = e,
        a = p(e, {
          menuCls: `${i}-menu`,
          dropdownArrowDistance: e.calc(n).div(2).add(t).equal(),
          dropdownEdgeChildPadding: r,
        });
      return [Le(a), Ie(a)];
    },
    (e) =>
      Object.assign(
        Object.assign(
          {
            zIndexPopup: e.zIndexPopupBase + 50,
            paddingBlock: (e.controlHeight - e.fontSize * e.lineHeight) / 2,
          },
          N({ contentRadius: e.borderRadiusLG, limitVerticalRadius: !0 })
        ),
        P(e)
      ),
    { resetStyle: !1 }
  ),
  $ = (e) => {
    let {
        menu: t,
        arrow: n,
        prefixCls: r,
        children: i,
        trigger: a,
        disabled: c,
        dropdownRender: l,
        popupRender: u,
        getPopupContainer: d,
        overlayClassName: p,
        rootClassName: m,
        overlayStyle: h,
        open: g,
        onOpenChange: _,
        visible: v,
        onVisibleChange: y,
        mouseEnterDelay: b = 0.15,
        mouseLeaveDelay: x = 0.1,
        autoAdjustOverflow: S = !0,
        placement: E = ``,
        overlay: A,
        transitionName: j,
        destroyOnHidden: M,
        destroyPopupOnHide: N,
      } = e,
      {
        getPopupContainer: P,
        getPrefixCls: I,
        direction: L,
        dropdown: z,
      } = J.useContext(s),
      B = u || l;
    D(`Dropdown`);
    let V = J.useMemo(() => {
        let e = I();
        return j === void 0
          ? E.includes(`top`)
            ? `${e}-slide-down`
            : `${e}-slide-up`
          : j;
      }, [I, E, j]),
      H = J.useMemo(
        () =>
          E
            ? E.includes(`Center`)
              ? E.slice(0, E.indexOf(`Center`))
              : E
            : L === `rtl`
            ? `bottomRight`
            : `bottomLeft`,
        [E, L]
      ),
      U = I(`dropdown`, r),
      W = R(U),
      [ee, te, ne] = Re(U, W),
      [, G] = f(),
      ie = J.Children.only(pe(i) ? J.createElement(`span`, null, i) : i),
      ae = T(ie, {
        className: (0, Y.default)(
          `${U}-trigger`,
          { [`${U}-rtl`]: L === `rtl` },
          ie.props.className
        ),
        disabled: ie.props.disabled ?? c,
      }),
      K = c ? [] : a,
      oe = !!(K != null && K.includes(`contextMenu`)),
      [se, q] = C(!1, { value: g ?? v }),
      ce = o((e) => {
        _ == null || _(e, { source: `trigger` }), y == null || y(e), q(e);
      }),
      le = (0, Y.default)(p, m, te, ne, W, z == null ? void 0 : z.className, {
        [`${U}-rtl`]: L === `rtl`,
      }),
      de = F({
        arrowPointAtCenter: typeof n == `object` && n.pointAtCenter,
        autoAdjustOverflow: S,
        offset: G.marginXXS,
        arrowWidth: n ? G.sizePopupArrow : 0,
        borderRadius: G.borderRadius,
      }),
      me = J.useCallback(() => {
        (t != null && t.selectable && t != null && t.multiple) ||
          (_ == null || _(!1, { source: `menu` }), q(!1));
      }, [t == null ? void 0 : t.selectable, t == null ? void 0 : t.multiple]),
      X = () => {
        let e;
        return (
          (e =
            t != null && t.items
              ? J.createElement(Q, Object.assign({}, t))
              : typeof A == `function`
              ? A()
              : A),
          B && (e = B(e)),
          (e = J.Children.only(
            typeof e == `string` ? J.createElement(`span`, null, e) : e
          )),
          J.createElement(
            ye,
            {
              prefixCls: `${U}-menu`,
              rootClassName: (0, Y.default)(ne, W),
              expandIcon: J.createElement(
                `span`,
                { className: `${U}-menu-submenu-arrow` },
                L === `rtl`
                  ? J.createElement(fe, {
                      className: `${U}-menu-submenu-arrow-icon`,
                    })
                  : J.createElement(ue, {
                      className: `${U}-menu-submenu-arrow-icon`,
                    })
              ),
              mode: `vertical`,
              selectable: !1,
              onClick: me,
              validator: ({ mode: e }) => {},
            },
            e
          )
        );
      },
      [he, ge] = k(`Dropdown`, h == null ? void 0 : h.zIndex),
      Z = J.createElement(
        re,
        Object.assign({ alignPoint: oe }, w(e, [`rootClassName`]), {
          mouseEnterDelay: b,
          mouseLeaveDelay: x,
          visible: se,
          builtinPlacements: de,
          arrow: !!n,
          overlayClassName: le,
          prefixCls: U,
          getPopupContainer: d || P,
          transitionName: V,
          trigger: K,
          overlay: X,
          placement: H,
          onVisibleChange: ce,
          overlayStyle: Object.assign(
            Object.assign(Object.assign({}, z == null ? void 0 : z.style), h),
            { zIndex: he }
          ),
          autoDestroy: M ?? N,
        }),
        ae
      );
    return he && (Z = J.createElement(O.Provider, { value: ge }, Z)), ee(Z);
  },
  ze = ne($, `align`, void 0, `dropdown`, (e) => e);
$._InternalPanelDoNotUseOrYouWillBeFired = (e) =>
  J.createElement(ze, Object.assign({}, e), J.createElement(`span`, null));
var Be = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Ve = (e) => {
    let {
        getPopupContainer: t,
        getPrefixCls: n,
        direction: r,
      } = J.useContext(s),
      {
        prefixCls: i,
        type: a = `default`,
        danger: o,
        disabled: c,
        loading: l,
        onClick: u,
        htmlType: d,
        children: f,
        className: p,
        menu: m,
        arrow: h,
        autoFocus: g,
        overlay: _,
        trigger: v,
        align: y,
        open: x,
        onOpenChange: S,
        placement: C,
        getPopupContainer: w,
        href: T,
        icon: E = J.createElement(q, null),
        title: D,
        buttonsRender: O = (e) => e,
        mouseEnterDelay: k,
        mouseLeaveDelay: A,
        overlayClassName: j,
        overlayStyle: M,
        destroyOnHidden: N,
        destroyPopupOnHide: P,
        dropdownRender: F,
        popupRender: I,
      } = e,
      L = Be(
        e,
        `prefixCls.type.danger.disabled.loading.onClick.htmlType.children.className.menu.arrow.autoFocus.overlay.trigger.align.open.onOpenChange.placement.getPopupContainer.href.icon.title.buttonsRender.mouseEnterDelay.mouseLeaveDelay.overlayClassName.overlayStyle.destroyOnHidden.destroyPopupOnHide.dropdownRender.popupRender`.split(
          `.`
        )
      ),
      R = n(`dropdown`, i),
      B = `${R}-button`,
      V = {
        menu: m,
        arrow: h,
        autoFocus: g,
        align: y,
        disabled: c,
        trigger: c ? [] : v,
        onOpenChange: S,
        getPopupContainer: w || t,
        mouseEnterDelay: k,
        mouseLeaveDelay: A,
        overlayClassName: j,
        overlayStyle: M,
        destroyOnHidden: N,
        popupRender: I || F,
      },
      { compactSize: H, compactItemClassnames: U } = b(R, r),
      W = (0, Y.default)(B, U, p);
    `destroyPopupOnHide` in e && (V.destroyPopupOnHide = P),
      `overlay` in e && (V.overlay = _),
      `open` in e && (V.open = x),
      (V.placement =
        `placement` in e ? C : r === `rtl` ? `bottomLeft` : `bottomRight`);
    let [ee, te] = O([
      J.createElement(
        z,
        {
          type: a,
          danger: o,
          disabled: c,
          loading: l,
          onClick: u,
          htmlType: d,
          href: T,
          title: D,
        },
        f
      ),
      J.createElement(z, { type: a, danger: o, icon: E }),
    ]);
    return J.createElement(
      ce.Compact,
      Object.assign({ className: W, size: H, block: !0 }, L),
      ee,
      J.createElement($, Object.assign({}, V), te)
    );
  };
Ve.__ANT_BUTTON = !0;
var He = $;
He.Button = Ve;
export { fe as a, ye as i, $ as n, ue as o, Q as r, He as t };
