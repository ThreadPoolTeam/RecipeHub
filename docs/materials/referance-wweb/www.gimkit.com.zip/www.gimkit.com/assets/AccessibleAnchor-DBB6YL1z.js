import "./rolldown-runtime-C0FnF6B9.js";
import { t as e } from "./react-IpA8Qn9U.js";
import { n as t } from "./dist-BbGQUgM_.js";
import { t as n } from "./jsx-runtime-CA2T8_y1.js";
e();
var r = n(),
  i = (e) =>
    e.external || !e.to
      ? (0, r.jsx)(`a`, {
          href: e.to,
          tabIndex: Number(e.tabIndex || `0`),
          onClick: e.onClick,
          onKeyPress: (t) => {
            e.onClick && t.key === `Enter` && (t.preventDefault(), e.onClick());
          },
          className: e.className,
          target: e.target,
          style: e.style,
          children: e.children,
        })
      : (0, r.jsx)(t, {
          to: e.to,
          tabIndex: Number(e.tabIndex || `0`),
          onClick: e.onClick,
          className: e.className,
          target: e.target,
          style: e.style,
          children: e.children,
        });
export { i as t };
