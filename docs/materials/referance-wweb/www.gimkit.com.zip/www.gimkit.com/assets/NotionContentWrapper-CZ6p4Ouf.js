const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/NotionContent-CNsH3k1C.js",
      "assets/rolldown-runtime-C0FnF6B9.js",
      "assets/dist-Cmw-iXzl.js",
      "assets/utils-CV9JYz4f.js",
      "assets/react-IpA8Qn9U.js",
      "assets/modal-Ch5Fwjpt.js",
      "assets/assertThisInitialized-DqpgQyeg.js",
      "assets/Compact-CRRKXVA1.js",
      "assets/color-Dzrzfp-h.js",
      "assets/ContextIsolator-D7w7V6rn.js",
      "assets/dist-CZ_f6czE.js",
      "assets/wrapNativeSuper-BsdumfAK.js",
      "assets/InfoCircleFilled-C11bHdqb.js",
      "assets/compact-item-BOjQ1zv3.js",
      "assets/useLocale-2b_qVRjr.js",
      "assets/useCSSVarCls-7-ltqzGc.js",
      "assets/pickAttrs-DgAKW8il.js",
      "assets/button-Cpfts2Ff.js",
      "assets/PurePanel-CIt2t_IW.js",
      "assets/Company-bnq9XEUn.js",
      "assets/Paths-3vkx8h28.js",
      "assets/decorate-DQbPZ5_K.js",
      "assets/jsx-runtime-CA2T8_y1.js",
      "assets/index-DG2EaUNY.js",
      "assets/dist-BbGQUgM_.js",
      "assets/spin-DkTHPaic.js",
      "assets/QueryClientProvider-Cv8zTiWk.js",
      "assets/queryClient-CqRCNEqN.js",
      "assets/infiniteQueryBehavior-DOR7IVF4.js",
      "assets/index-Tu04tXLf.css",
      "assets/toPropertyKey-CUCj2864.js",
      "assets/typeof-D4Fcv4W7.js",
      "assets/NotionContent-DJb2r84x.css",
    ])
) => i.map((i) => d[i]);
import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { a as n } from "./modal-Ch5Fwjpt.js";
import { t as r } from "./jsx-runtime-CA2T8_y1.js";
import { h as i } from "./index-DG2EaUNY.js";
var a = e(t()),
  o = r(),
  s = a.lazy(() =>
    i(
      () => import(`./NotionContent-CNsH3k1C.js`),
      __vite__mapDeps([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
        20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
      ])
    )
  ),
  c = (e) => {
    let t = e.hideSkeleton
      ? (0, o.jsx)(`div`, { className: `maxWidth` })
      : (0, o.jsx)(`div`, {
          className: `maxWidth`,
          children: (0, o.jsx)(n, {
            active: !0,
            title: !1,
            paragraph: { rows: 9 },
          }),
        });
    return (0, o.jsx)(a.Suspense, {
      fallback: t,
      children: (0, o.jsx)(s, { ...e }),
    });
  };
export { c as t };
