var e = void 0,
  t = () => {
    var t;
    if (e) return e;
    if ({}.CDN_MAP_ASSETS_URL !== void 0) return (e = {}.CDN_MAP_ASSETS_URL), e;
    let n =
      (t = document.querySelector(`meta[property="cdn-map-assets-url"]`)) ==
      null
        ? void 0
        : t.getAttribute(`content`);
    return n !== void 0 && n !== `$CDN_MAP_ASSETS_URL` ? ((e = n), e) : ``;
  },
  n = (e) => {
    let n = t();
    return e.startsWith(`/assets/map`) ? `${n}${e}` : `${n}/assets/map/${e}`;
  };
export { n as t };
