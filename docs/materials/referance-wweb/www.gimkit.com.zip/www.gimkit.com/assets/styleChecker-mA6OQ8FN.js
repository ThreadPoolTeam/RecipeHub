import { ct as e } from "./Compact-CRRKXVA1.js";
var t = function (t) {
    if (e() && window.document.documentElement) {
      var n = Array.isArray(t) ? t : [t],
        r = window.document.documentElement;
      return n.some(function (e) {
        return e in r.style;
      });
    }
    return !1;
  },
  n = function (e, n) {
    if (!t(e)) return !1;
    var r = document.createElement(`div`),
      i = r.style[e];
    return (r.style[e] = n), r.style[e] !== i;
  };
function r(e, r) {
  return !Array.isArray(e) && r !== void 0 ? n(e, r) : t(e);
}
export { r as t };
