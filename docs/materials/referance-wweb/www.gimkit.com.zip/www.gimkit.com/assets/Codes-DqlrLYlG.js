var e = `CLASSIC`,
  t = `TEAMS`,
  n = `THANOS`,
  r = `BOSS_BATTLE`,
  i = `HUMAN_ZOMBIE_DEFENDING_HOMEBASE`,
  a = `LAVA`,
  o = `IMPOSTER`,
  s = `DRAW`,
  c = `PARDY`;
export { o as a, t as c, i, n as l, e as n, a as o, s as r, c as s, r as t };
