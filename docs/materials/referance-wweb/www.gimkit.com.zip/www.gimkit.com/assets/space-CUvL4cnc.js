import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { Bt as n, Ut as r, i, k as a, t as o } from "./Compact-CRRKXVA1.js";
var s = e(t()),
  c = e(r());
function l(e) {
  return [`small`, `middle`, `large`].includes(e);
}
function u(e) {
  return e ? typeof e == `number` && !Number.isNaN(e) : !1;
}
var d = s.createContext({ latestIndex: 0 }),
  f = d.Provider,
  p = ({ className: e, index: t, children: n, split: r, style: i }) => {
    let { latestIndex: a } = s.useContext(d);
    return n == null
      ? null
      : s.createElement(
          s.Fragment,
          null,
          s.createElement(`div`, { className: e, style: i }, n),
          t < a && r && s.createElement(`span`, { className: `${e}-split` }, r)
        );
  },
  m = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  h = s.forwardRef((e, t) => {
    let {
        getPrefixCls: r,
        direction: o,
        size: d,
        className: h,
        style: g,
        classNames: _,
        styles: v,
      } = a(`space`),
      {
        size: y = d ?? `small`,
        align: b,
        className: x,
        rootClassName: S,
        children: C,
        direction: w = `horizontal`,
        prefixCls: T,
        split: E,
        style: D,
        wrap: O = !1,
        classNames: k,
        styles: A,
      } = e,
      j = m(e, [
        `size`,
        `align`,
        `className`,
        `rootClassName`,
        `children`,
        `direction`,
        `prefixCls`,
        `split`,
        `style`,
        `wrap`,
        `classNames`,
        `styles`,
      ]),
      [M, N] = Array.isArray(y) ? y : [y, y],
      P = l(N),
      F = l(M),
      I = u(N),
      L = u(M),
      R = n(C, { keepEmpty: !0 }),
      z = b === void 0 && w === `horizontal` ? `center` : b,
      B = r(`space`, T),
      [V, H, U] = i(B),
      W = (0, c.default)(
        B,
        h,
        H,
        `${B}-${w}`,
        {
          [`${B}-rtl`]: o === `rtl`,
          [`${B}-align-${z}`]: z,
          [`${B}-gap-row-${N}`]: P,
          [`${B}-gap-col-${M}`]: F,
        },
        x,
        S,
        U
      ),
      G = (0, c.default)(`${B}-item`, (k == null ? void 0 : k.item) ?? _.item),
      K = 0,
      q = R.map((e, t) => {
        e != null && (K = t);
        let n = (e == null ? void 0 : e.key) || `${G}-${t}`;
        return s.createElement(
          p,
          {
            className: G,
            key: n,
            index: t,
            split: E,
            style: (A == null ? void 0 : A.item) ?? v.item,
          },
          e
        );
      }),
      J = s.useMemo(() => ({ latestIndex: K }), [K]);
    if (R.length === 0) return null;
    let Y = {};
    return (
      O && (Y.flexWrap = `wrap`),
      !F && L && (Y.columnGap = M),
      !P && I && (Y.rowGap = N),
      V(
        s.createElement(
          `div`,
          Object.assign(
            {
              ref: t,
              className: W,
              style: Object.assign(Object.assign(Object.assign({}, Y), g), D),
            },
            j
          ),
          s.createElement(f, { value: J }, q)
        )
      )
    );
  });
h.Compact = o;
export { h as t };
