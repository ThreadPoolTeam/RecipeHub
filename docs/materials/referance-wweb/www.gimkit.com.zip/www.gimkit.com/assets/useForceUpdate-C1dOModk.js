import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
var n = e(t());
function r() {
  let [, e] = n.useReducer((e) => e + 1, 0);
  return e;
}
export { r as t };
