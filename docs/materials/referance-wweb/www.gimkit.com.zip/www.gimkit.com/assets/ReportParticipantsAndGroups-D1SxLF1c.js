import "./rolldown-runtime-C0FnF6B9.js";
import { S as e } from "./utils-CV9JYz4f.js";
import { t } from "./react-IpA8Qn9U.js";
import { t as n } from "./space-CUvL4cnc.js";
import { t as r } from "./jsx-runtime-CA2T8_y1.js";
import { r as i } from "./ReportAccuracyMeter-CS5kz4mp.js";
t();
var a = r(),
  o = (t) => {
    var r;
    return (0, a.jsxs)(`div`, {
      children: [
        (0, a.jsxs)(`div`, {
          style: { fontStyle: `italic` },
          children: [t.participants, ` `, e(`participant`, t.participants)],
        }),
        (r = t.groups) != null && r.length
          ? (0, a.jsx)(n, {
              direction: `horizontal`,
              wrap: !0,
              size: `small`,
              style: { marginTop: `0.3em` },
              children: t.groups.map((e) =>
                (0, a.jsx)(
                  i,
                  { to: `/class/${e._id}`, children: e.name },
                  t.reportId + e._id
                )
              ),
            })
          : null,
      ],
    });
  };
export { o as t };
