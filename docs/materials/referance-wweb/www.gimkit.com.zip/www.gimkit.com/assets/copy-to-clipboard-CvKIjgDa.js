import { t as e } from "./rolldown-runtime-C0FnF6B9.js";
var t = e((e, t) => {
    t.exports = function () {
      var e = document.getSelection();
      if (!e.rangeCount) return function () {};
      for (var t = document.activeElement, n = [], r = 0; r < e.rangeCount; r++)
        n.push(e.getRangeAt(r));
      switch (t.tagName.toUpperCase()) {
        case `INPUT`:
        case `TEXTAREA`:
          t.blur();
          break;
        default:
          t = null;
      }
      return (
        e.removeAllRanges(),
        function () {
          e.type === `Caret` && e.removeAllRanges(),
            e.rangeCount ||
              n.forEach(function (t) {
                e.addRange(t);
              }),
            t && t.focus();
        }
      );
    };
  }),
  n = e((e, n) => {
    var r = t(),
      i = { "text/plain": `Text`, "text/html": `Url`, default: `Text` },
      a = `Copy to clipboard: #{key}, Enter`;
    function o(e) {
      var t = (/mac os x/i.test(navigator.userAgent) ? `⌘` : `Ctrl`) + `+C`;
      return e.replace(/#{\s*key\s*}/g, t);
    }
    function s(e, t) {
      var n,
        s,
        c,
        l,
        u,
        d,
        f = !1;
      t || (t = {}), (n = t.debug || !1);
      try {
        if (
          ((c = r()),
          (l = document.createRange()),
          (u = document.getSelection()),
          (d = document.createElement(`span`)),
          (d.textContent = e),
          (d.ariaHidden = `true`),
          (d.style.all = `unset`),
          (d.style.position = `fixed`),
          (d.style.top = 0),
          (d.style.clip = `rect(0, 0, 0, 0)`),
          (d.style.whiteSpace = `pre`),
          (d.style.webkitUserSelect = `text`),
          (d.style.MozUserSelect = `text`),
          (d.style.msUserSelect = `text`),
          (d.style.userSelect = `text`),
          d.addEventListener(`copy`, function (r) {
            if ((r.stopPropagation(), t.format)) {
              if ((r.preventDefault(), r.clipboardData === void 0)) {
                n && console.warn(`unable to use e.clipboardData`),
                  n && console.warn(`trying IE specific stuff`),
                  window.clipboardData.clearData();
                var a = i[t.format] || i.default;
                window.clipboardData.setData(a, e);
              } else
                r.clipboardData.clearData(),
                  r.clipboardData.setData(t.format, e);
            }
            t.onCopy && (r.preventDefault(), t.onCopy(r.clipboardData));
          }),
          document.body.appendChild(d),
          l.selectNodeContents(d),
          u.addRange(l),
          !document.execCommand(`copy`))
        )
          throw Error(`copy command was unsuccessful`);
        f = !0;
      } catch (r) {
        n && console.error(`unable to copy using execCommand: `, r),
          n && console.warn(`trying IE specific stuff`);
        try {
          window.clipboardData.setData(t.format || `text`, e),
            t.onCopy && t.onCopy(window.clipboardData),
            (f = !0);
        } catch (r) {
          n && console.error(`unable to copy using clipboardData: `, r),
            n && console.error(`falling back to prompt`),
            (s = o(`message` in t ? t.message : a)),
            window.prompt(s, e);
        }
      } finally {
        u &&
          (typeof u.removeRange == `function`
            ? u.removeRange(l)
            : u.removeAllRanges()),
          d && document.body.removeChild(d),
          c();
      }
      return f;
    }
    n.exports = s;
  });
export { n as t };
