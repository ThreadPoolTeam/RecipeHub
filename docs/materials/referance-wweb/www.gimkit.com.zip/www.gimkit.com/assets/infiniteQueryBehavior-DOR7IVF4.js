function e() {
  return {
    onFetch: (e) => {
      e.fetchFn = () => {
        var r, i, a, o, s, c;
        let l =
            (r = e.fetchOptions) == null || (i = r.meta) == null
              ? void 0
              : i.refetchPage,
          u =
            (a = e.fetchOptions) == null || (o = a.meta) == null
              ? void 0
              : o.fetchMore,
          d = u == null ? void 0 : u.pageParam,
          f = (u == null ? void 0 : u.direction) === `forward`,
          p = (u == null ? void 0 : u.direction) === `backward`,
          m = ((s = e.state.data) == null ? void 0 : s.pages) || [],
          h = ((c = e.state.data) == null ? void 0 : c.pageParams) || [],
          g = h,
          _ = !1,
          v = (t) => {
            Object.defineProperty(t, "signal", {
              enumerable: !0,
              get: () => {
                var t;
                if ((t = e.signal) != null && t.aborted) _ = !0;
                else {
                  var n;
                  (n = e.signal) == null ||
                    n.addEventListener(`abort`, () => {
                      _ = !0;
                    });
                }
                return e.signal;
              },
            });
          },
          y =
            e.options.queryFn ||
            (() =>
              Promise.reject(
                `Missing queryFn for queryKey '` + e.options.queryHash + `'`
              )),
          b = (e, t, n, r) => (
            (g = r ? [t, ...g] : [...g, t]), r ? [n, ...e] : [...e, n]
          ),
          x = (t, n, r, i) => {
            if (_) return Promise.reject(`Cancelled`);
            if (r === void 0 && !n && t.length) return Promise.resolve(t);
            let a = {
              queryKey: e.queryKey,
              pageParam: r,
              meta: e.options.meta,
            };
            v(a);
            let o = y(a);
            return Promise.resolve(o).then((e) => b(t, r, e, i));
          },
          S;
        if (!m.length) S = x([]);
        else if (f) {
          let n = d !== void 0;
          S = x(m, n, n ? d : t(e.options, m));
        } else if (p) {
          let t = d !== void 0;
          S = x(m, t, t ? d : n(e.options, m), !0);
        } else {
          g = [];
          let n = e.options.getNextPageParam === void 0;
          S =
            !(l && m[0]) || l(m[0], 0, m)
              ? x([], n, h[0])
              : Promise.resolve(b([], h[0], m[0]));
          for (let r = 1; r < m.length; r++)
            S = S.then((i) => {
              if (!(l && m[r]) || l(m[r], r, m)) {
                let a = n ? h[r] : t(e.options, i);
                return x(i, n, a);
              }
              return Promise.resolve(b(i, h[r], m[r]));
            });
        }
        return S.then((e) => ({ pages: e, pageParams: g }));
      };
    },
  };
}
function t(e, t) {
  return e.getNextPageParam == null
    ? void 0
    : e.getNextPageParam(t[t.length - 1], t);
}
function n(e, t) {
  return e.getPreviousPageParam == null
    ? void 0
    : e.getPreviousPageParam(t[0], t);
}
function r(e, n) {
  if (e.getNextPageParam && Array.isArray(n)) {
    let r = t(e, n);
    return r != null && r !== !1;
  }
}
function i(e, t) {
  if (e.getPreviousPageParam && Array.isArray(t)) {
    let r = n(e, t);
    return r != null && r !== !1;
  }
}
export { i as n, e as r, r as t };
