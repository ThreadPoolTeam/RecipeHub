import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, g as r, y as i } from "./motion-CBkcxAMn.js";
var a = e(t(), 1);
function o(e) {
  let t = r(() => n(e)),
    { isStatic: o } = (0, a.useContext)(i);
  if (o) {
    let [, n] = (0, a.useState)(e);
    (0, a.useEffect)(() => t.on(`change`, n), []);
  }
  return t;
}
export { o as t };
