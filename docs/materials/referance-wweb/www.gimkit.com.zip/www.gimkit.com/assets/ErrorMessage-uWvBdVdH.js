import "./rolldown-runtime-C0FnF6B9.js";
import { t as e } from "./react-IpA8Qn9U.js";
import { t } from "./jsx-runtime-CA2T8_y1.js";
import { b as n } from "./index-DG2EaUNY.js";
e();
var r = t(),
  i = (e) =>
    e.error
      ? (0, r.jsx)(n, {
          message: `Error`,
          style: e.style,
          type: `error`,
          description:
            e.error && e.error.message && e.error.message.text
              ? e.error.message.text
              : typeof e.error == `string`
              ? e.error
              : `Unknown Error. Please try again.`,
          showIcon: !0,
        })
      : null;
export { i as t };
