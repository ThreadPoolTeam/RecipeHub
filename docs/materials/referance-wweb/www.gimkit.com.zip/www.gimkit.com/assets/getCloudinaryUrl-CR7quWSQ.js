var e = (e) => {
    let r = t(e);
    return r
      ? e.includes(`/video/upload`)
        ? `https://${n}/video/upload/${r}`
        : `https://${n}/image/upload/f_auto,fl_lossy,q_auto/${r}`
      : e;
  },
  t = (e) => {
    if (
      !a.some((t) => e.includes(t)) ||
      (e.includes(r) && !e.includes(`/${i}/`))
    )
      return null;
    let t = e.split(`/`);
    if (!t || !t.length || t.length < 2) return null;
    let n = t[t.length - 2],
      o = t[t.length - 1];
    return !n || !o || !n.startsWith(`v`) ? null : `${n}/${o}`;
  },
  n = `media.gimkit.com`,
  r = `res.cloudinary.com`,
  i = `gimkit-production`,
  a = [n, r];
export { e as t };
