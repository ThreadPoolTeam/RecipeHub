import "./rolldown-runtime-C0FnF6B9.js";
import { t as e } from "./react-IpA8Qn9U.js";
import { n as t } from "./Company-bnq9XEUn.js";
import { t as n } from "./jsx-runtime-CA2T8_y1.js";
e();
var r = n(),
  i = {
    title: (0, r.jsx)(r.Fragment, { children: `Copy kits with Pro` }),
    description: (0, r.jsxs)(r.Fragment, {
      children: [
        `To copy kits and make them your own, upgrade to `,
        t,
        ` Pro.`,
      ],
    }),
  };
export { i as t };
