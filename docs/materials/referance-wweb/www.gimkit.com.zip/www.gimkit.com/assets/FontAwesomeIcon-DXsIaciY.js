import "./rolldown-runtime-C0FnF6B9.js";
import { t as e } from "./react-IpA8Qn9U.js";
import { t } from "./jsx-runtime-CA2T8_y1.js";
e();
var n = t(),
  r = (e) =>
    (0, n.jsx)(`i`, {
      className: `${e.name}${e.className ? ` ${e.className}` : ``}`,
      style: e.style,
    });
export { r as t };
