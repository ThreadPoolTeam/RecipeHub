import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  At as n,
  Bt as r,
  E as i,
  J as a,
  Mt as o,
  Ot as s,
  S as c,
  Ut as l,
  X as u,
  a as d,
  b as f,
  c as p,
  gt as m,
  ht as h,
  k as g,
  m as _,
  s as v,
  w as y,
} from "./Compact-CRRKXVA1.js";
import {
  d as b,
  f as x,
  g as S,
  h as C,
  i as w,
  r as T,
  s as E,
  v as D,
} from "./color-Dzrzfp-h.js";
import { n as O } from "./compact-item-BOjQ1zv3.js";
import {
  A as k,
  M as A,
  N as j,
  a as M,
  c as ee,
  f as N,
  h as P,
  i as F,
  l as I,
  m as te,
  n as L,
  o as ne,
  p as R,
  r as z,
  s as B,
  u as V,
  w as H,
  x as U,
} from "./ContextIsolator-D7w7V6rn.js";
import { c as re, i as ie, n as W } from "./InfoCircleFilled-C11bHdqb.js";
import { r as G, t as ae } from "./useLocale-2b_qVRjr.js";
import { t as K } from "./tooltip-Yg3f8G0Q.js";
import { n as q, t as oe } from "./useCSSVarCls-7-ltqzGc.js";
import { a as J, i as Y, n as se, r as ce } from "./useForm-IQSiwVDR.js";
import { n as le, r as ue } from "./modal-Ch5Fwjpt.js";
import { t as de } from "./collapse-CVZX-k2a.js";
import { n as fe, t as pe } from "./useBreakpoint-XQ3aLfc0.js";
import { t as me } from "./QuestionCircleOutlined-CBoGD_SS.js";
var X = e(l()),
  Z = e(t()),
  he = (0, Z.createContext)({});
m();
var ge = function (e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) &&
      t.indexOf(r) < 0 &&
      (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == `function`)
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
        (n[r[i]] = e[r[i]]);
  return n;
};
function _e(e) {
  return typeof e == `number`
    ? `${e} ${e} auto`
    : /^\d+(\.\d+)?(px|em|rem|%)$/.test(e)
    ? `0 0 ${e}`
    : e;
}
var ve = [`xs`, `sm`, `md`, `lg`, `xl`, `xxl`],
  ye = Z.forwardRef((e, t) => {
    let { getPrefixCls: n, direction: r } = Z.useContext(i),
      { gutter: a, wrap: o } = Z.useContext(he),
      {
        prefixCls: s,
        span: c,
        order: l,
        offset: u,
        push: d,
        pull: f,
        className: p,
        children: m,
        flex: h,
        style: g,
      } = e,
      _ = ge(e, [
        `prefixCls`,
        `span`,
        `order`,
        `offset`,
        `push`,
        `pull`,
        `className`,
        `children`,
        `flex`,
        `style`,
      ]),
      v = n(`col`, s),
      [y, b, x] = le(v),
      S = {},
      C = {};
    ve.forEach((t) => {
      let n = {},
        i = e[t];
      typeof i == `number`
        ? (n.span = i)
        : typeof i == `object` && (n = i || {}),
        delete _[t],
        (C = Object.assign(Object.assign({}, C), {
          [`${v}-${t}-${n.span}`]: n.span !== void 0,
          [`${v}-${t}-order-${n.order}`]: n.order || n.order === 0,
          [`${v}-${t}-offset-${n.offset}`]: n.offset || n.offset === 0,
          [`${v}-${t}-push-${n.push}`]: n.push || n.push === 0,
          [`${v}-${t}-pull-${n.pull}`]: n.pull || n.pull === 0,
          [`${v}-rtl`]: r === `rtl`,
        })),
        n.flex &&
          ((C[`${v}-${t}-flex`] = !0), (S[`--${v}-${t}-flex`] = _e(n.flex)));
    });
    let w = (0, X.default)(
        v,
        {
          [`${v}-${c}`]: c !== void 0,
          [`${v}-order-${l}`]: l,
          [`${v}-offset-${u}`]: u,
          [`${v}-push-${d}`]: d,
          [`${v}-pull-${f}`]: f,
        },
        p,
        C,
        b,
        x
      ),
      T = {};
    if (a && a[0] > 0) {
      let e = a[0] / 2;
      (T.paddingLeft = e), (T.paddingRight = e);
    }
    return (
      h && ((T.flex = _e(h)), o === !1 && !T.minWidth && (T.minWidth = 0)),
      y(
        Z.createElement(
          `div`,
          Object.assign({}, _, {
            style: Object.assign(Object.assign(Object.assign({}, T), g), S),
            className: w,
            ref: t,
          }),
          m
        )
      )
    );
  });
function be(e, t) {
  let n = [void 0, void 0],
    r = Array.isArray(e) ? e : [e, void 0],
    i = t || { xs: !0, sm: !0, md: !0, lg: !0, xl: !0, xxl: !0 };
  return (
    r.forEach((e, t) => {
      if (typeof e == `object` && e)
        for (let r = 0; r < fe.length; r++) {
          let a = fe[r];
          if (i[a] && e[a] !== void 0) {
            n[t] = e[a];
            break;
          }
        }
      else n[t] = e;
    }),
    n
  );
}
var xe = function (e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) &&
      t.indexOf(r) < 0 &&
      (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == `function`)
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
        (n[r[i]] = e[r[i]]);
  return n;
};
function Se(e, t) {
  let [n, r] = Z.useState(typeof e == `string` ? e : ``),
    i = () => {
      if ((typeof e == `string` && r(e), typeof e == `object`))
        for (let n = 0; n < fe.length; n++) {
          let i = fe[n];
          if (!t || !t[i]) continue;
          let a = e[i];
          if (a !== void 0) {
            r(a);
            return;
          }
        }
    };
  return (
    Z.useEffect(() => {
      i();
    }, [JSON.stringify(e), t]),
    n
  );
}
var Ce = Z.forwardRef((e, t) => {
  let {
      prefixCls: n,
      justify: r,
      align: a,
      className: o,
      style: s,
      children: c,
      gutter: l = 0,
      wrap: u,
    } = e,
    d = xe(e, [
      `prefixCls`,
      `justify`,
      `align`,
      `className`,
      `style`,
      `children`,
      `gutter`,
      `wrap`,
    ]),
    { getPrefixCls: f, direction: p } = Z.useContext(i),
    m = pe(!0, null),
    h = Se(a, m),
    g = Se(r, m),
    _ = f(`row`, n),
    [v, y, b] = ue(_),
    x = be(l, m),
    S = (0, X.default)(
      _,
      {
        [`${_}-no-wrap`]: u === !1,
        [`${_}-${g}`]: g,
        [`${_}-${h}`]: h,
        [`${_}-rtl`]: p === `rtl`,
      },
      o,
      y,
      b
    ),
    C = {},
    w = x[0] != null && x[0] > 0 ? x[0] / -2 : void 0;
  w && ((C.marginLeft = w), (C.marginRight = w));
  let [T, E] = x;
  C.rowGap = E;
  let D = Z.useMemo(() => ({ gutter: [T, E], wrap: u }), [T, E, u]);
  return v(
    Z.createElement(
      he.Provider,
      { value: D },
      Z.createElement(
        `div`,
        Object.assign({}, d, {
          className: S,
          style: Object.assign(Object.assign({}, C), s),
          ref: t,
        }),
        c
      )
    )
  );
});
function we(e) {
  return e == null
    ? null
    : typeof e == `object` && !(0, Z.isValidElement)(e)
    ? e
    : { title: e };
}
function Te(e) {
  let [t, n] = Z.useState(e);
  return (
    Z.useEffect(() => {
      let t = setTimeout(
        () => {
          n(e);
        },
        e.length ? 0 : 10
      );
      return () => {
        clearTimeout(t);
      };
    }, [e]),
    t
  );
}
var Ee = (e) => {
    let { componentCls: t } = e,
      n = `${t}-show-help`,
      r = `${t}-show-help-item`;
    return {
      [n]: {
        transition: `opacity ${e.motionDurationFast} ${e.motionEaseInOut}`,
        "&-appear, &-enter": { opacity: 0, "&-active": { opacity: 1 } },
        "&-leave": { opacity: 1, "&-active": { opacity: 0 } },
        [r]: {
          overflow: `hidden`,
          transition: `height ${e.motionDurationFast} ${e.motionEaseInOut},
                     opacity ${e.motionDurationFast} ${e.motionEaseInOut},
                     transform ${e.motionDurationFast} ${e.motionEaseInOut} !important`,
          [`&${r}-appear, &${r}-enter`]: {
            transform: `translateY(-5px)`,
            opacity: 0,
            "&-active": { transform: `translateY(0)`, opacity: 1 },
          },
          [`&${r}-leave-active`]: { transform: `translateY(-5px)` },
        },
      },
    };
  },
  De = (e) => ({
    legend: {
      display: `block`,
      width: `100%`,
      marginBottom: e.marginLG,
      padding: 0,
      color: e.colorTextDescription,
      fontSize: e.fontSizeLG,
      lineHeight: `inherit`,
      border: 0,
      borderBottom: `${u(e.lineWidth)} ${e.lineType} ${e.colorBorder}`,
    },
    'input[type="search"]': { boxSizing: `border-box` },
    'input[type="radio"], input[type="checkbox"]': { lineHeight: `normal` },
    'input[type="file"]': { display: `block` },
    'input[type="range"]': { display: `block`, width: `100%` },
    "select[multiple], select[size]": { height: `auto` },
    "input[type='file']:focus,\n  input[type='radio']:focus,\n  input[type='checkbox']:focus":
      {
        outline: 0,
        boxShadow: `0 0 0 ${u(e.controlOutlineWidth)} ${e.controlOutline}`,
      },
    output: {
      display: `block`,
      paddingTop: 15,
      color: e.colorText,
      fontSize: e.fontSize,
      lineHeight: e.lineHeight,
    },
  }),
  Oe = (e, t) => {
    let { formItemCls: n } = e;
    return {
      [n]: {
        [`${n}-label > label`]: { height: t },
        [`${n}-control-input`]: { minHeight: t },
      },
    };
  },
  ke = (e) => {
    let { componentCls: t } = e;
    return {
      [e.componentCls]: Object.assign(
        Object.assign(Object.assign({}, _(e)), De(e)),
        {
          [`${t}-text`]: {
            display: `inline-block`,
            paddingInlineEnd: e.paddingSM,
          },
          "&-small": Object.assign({}, Oe(e, e.controlHeightSM)),
          "&-large": Object.assign({}, Oe(e, e.controlHeightLG)),
        }
      ),
    };
  },
  Ae = (e) => {
    let {
      formItemCls: t,
      iconCls: n,
      rootPrefixCls: r,
      antCls: i,
      labelRequiredMarkColor: a,
      labelColor: o,
      labelFontSize: s,
      labelHeight: c,
      labelColonMarginInlineStart: l,
      labelColonMarginInlineEnd: u,
      itemMarginBottom: d,
    } = e;
    return {
      [t]: Object.assign(Object.assign({}, _(e)), {
        marginBottom: d,
        verticalAlign: `top`,
        "&-with-help": { transition: `none` },
        [`&-hidden,
        &-hidden${i}-row`]: { display: `none` },
        "&-has-warning": { [`${t}-split`]: { color: e.colorError } },
        "&-has-error": { [`${t}-split`]: { color: e.colorWarning } },
        [`${t}-label`]: {
          flexGrow: 0,
          overflow: `hidden`,
          whiteSpace: `nowrap`,
          textAlign: `end`,
          verticalAlign: `middle`,
          "&-left": { textAlign: `start` },
          "&-wrap": {
            overflow: `unset`,
            lineHeight: e.lineHeight,
            whiteSpace: `unset`,
            "> label": { verticalAlign: `middle`, textWrap: `balance` },
          },
          "> label": {
            position: `relative`,
            display: `inline-flex`,
            alignItems: `center`,
            maxWidth: `100%`,
            height: c,
            color: o,
            fontSize: s,
            [`> ${n}`]: { fontSize: e.fontSize, verticalAlign: `top` },
            [`&${t}-required`]: {
              "&::before": {
                display: `inline-block`,
                marginInlineEnd: e.marginXXS,
                color: a,
                fontSize: e.fontSize,
                fontFamily: `SimSun, sans-serif`,
                lineHeight: 1,
                content: `"*"`,
              },
              [`&${t}-required-mark-hidden, &${t}-required-mark-optional`]: {
                "&::before": { display: `none` },
              },
            },
            [`${t}-optional`]: {
              display: `inline-block`,
              marginInlineStart: e.marginXXS,
              color: e.colorTextDescription,
              [`&${t}-required-mark-hidden`]: { display: `none` },
            },
            [`${t}-tooltip`]: {
              color: e.colorTextDescription,
              cursor: `help`,
              writingMode: `horizontal-tb`,
              marginInlineStart: e.marginXXS,
            },
            "&::after": {
              content: `":"`,
              position: `relative`,
              marginBlock: 0,
              marginInlineStart: l,
              marginInlineEnd: u,
            },
            [`&${t}-no-colon::after`]: { content: `"\\a0"` },
          },
        },
        [`${t}-control`]: {
          "--ant-display": `flex`,
          flexDirection: `column`,
          flexGrow: 1,
          [`&:first-child:not([class^="'${r}-col-'"]):not([class*="' ${r}-col-'"])`]:
            { width: `100%` },
          "&-input": {
            position: `relative`,
            display: `flex`,
            alignItems: `center`,
            minHeight: e.controlHeight,
            "&-content": {
              flex: `auto`,
              maxWidth: `100%`,
              [`&:has(> ${i}-switch:only-child, > ${i}-rate:only-child)`]: {
                display: `flex`,
                alignItems: `center`,
              },
            },
          },
        },
        [t]: {
          "&-additional": { display: `flex`, flexDirection: `column` },
          "&-explain, &-extra": {
            clear: `both`,
            color: e.colorTextDescription,
            fontSize: e.fontSize,
            lineHeight: e.lineHeight,
          },
          "&-explain-connected": { width: `100%` },
          "&-extra": {
            minHeight: e.controlHeightSM,
            transition: `color ${e.motionDurationMid} ${e.motionEaseOut}`,
          },
          "&-explain": {
            "&-error": { color: e.colorError },
            "&-warning": { color: e.colorWarning },
          },
        },
        [`&-with-help ${t}-explain`]: { height: `auto`, opacity: 1 },
        [`${t}-feedback-icon`]: {
          fontSize: e.fontSize,
          textAlign: `center`,
          visibility: `visible`,
          animationName: U,
          animationDuration: e.motionDurationMid,
          animationTimingFunction: e.motionEaseOutBack,
          pointerEvents: `none`,
          "&-success": { color: e.colorSuccess },
          "&-error": { color: e.colorError },
          "&-warning": { color: e.colorWarning },
          "&-validating": { color: e.colorPrimary },
        },
      }),
    };
  },
  Q = (e) => ({
    padding: e.verticalLabelPadding,
    margin: e.verticalLabelMargin,
    whiteSpace: `initial`,
    textAlign: `start`,
    "> label": { margin: 0, "&::after": { visibility: `hidden` } },
  }),
  je = (e) => {
    let { antCls: t, formItemCls: n } = e;
    return {
      [`${n}-horizontal`]: {
        [`${n}-label`]: { flexGrow: 0 },
        [`${n}-control`]: { flex: `1 1 0`, minWidth: 0 },
        [`${n}-label[class$='-24'], ${n}-label[class*='-24 ']`]: {
          [`& + ${n}-control`]: { minWidth: `unset` },
        },
        [`${t}-col-24${n}-label,
        ${t}-col-xl-24${n}-label`]: Q(e),
      },
    };
  },
  Me = (e) => {
    let { componentCls: t, formItemCls: n, inlineItemMarginBottom: r } = e;
    return {
      [`${t}-inline`]: {
        display: `flex`,
        flexWrap: `wrap`,
        [`${n}-inline`]: {
          flex: `none`,
          marginInlineEnd: e.margin,
          marginBottom: r,
          "&-row": { flexWrap: `nowrap` },
          [`> ${n}-label,
        > ${n}-control`]: { display: `inline-block`, verticalAlign: `top` },
          [`> ${n}-label`]: { flex: `none` },
          [`${t}-text`]: { display: `inline-block` },
          [`${n}-has-feedback`]: { display: `inline-block` },
        },
      },
    };
  },
  Ne = (e) => {
    let { componentCls: t, formItemCls: n, rootPrefixCls: r } = e;
    return {
      [`${n} ${n}-label`]: Q(e),
      [`${t}:not(${t}-inline)`]: {
        [n]: {
          flexWrap: `wrap`,
          [`${n}-label, ${n}-control`]: {
            [`&:not([class*=" ${r}-col-xs"])`]: {
              flex: `0 0 100%`,
              maxWidth: `100%`,
            },
          },
        },
      },
    };
  },
  Pe = (e) => {
    let { componentCls: t, formItemCls: n, antCls: r } = e;
    return {
      [`${n}-vertical`]: {
        [`${n}-row`]: { flexDirection: `column` },
        [`${n}-label > label`]: { height: `auto` },
        [`${n}-control`]: { width: `100%` },
        [`${n}-label,
        ${r}-col-24${n}-label,
        ${r}-col-xl-24${n}-label`]: Q(e),
      },
      [`@media (max-width: ${u(e.screenXSMax)})`]: [
        Ne(e),
        {
          [t]: {
            [`${n}:not(${n}-horizontal)`]: {
              [`${r}-col-xs-24${n}-label`]: Q(e),
            },
          },
        },
      ],
      [`@media (max-width: ${u(e.screenSMMax)})`]: {
        [t]: {
          [`${n}:not(${n}-horizontal)`]: { [`${r}-col-sm-24${n}-label`]: Q(e) },
        },
      },
      [`@media (max-width: ${u(e.screenMDMax)})`]: {
        [t]: {
          [`${n}:not(${n}-horizontal)`]: { [`${r}-col-md-24${n}-label`]: Q(e) },
        },
      },
      [`@media (max-width: ${u(e.screenLGMax)})`]: {
        [t]: {
          [`${n}:not(${n}-horizontal)`]: { [`${r}-col-lg-24${n}-label`]: Q(e) },
        },
      },
    };
  },
  Fe = (e) => ({
    labelRequiredMarkColor: e.colorError,
    labelColor: e.colorTextHeading,
    labelFontSize: e.fontSize,
    labelHeight: e.controlHeight,
    labelColonMarginInlineStart: e.marginXXS / 2,
    labelColonMarginInlineEnd: e.marginXS,
    itemMarginBottom: e.marginLG,
    verticalLabelPadding: `0 0 ${e.paddingXS}px`,
    verticalLabelMargin: 0,
    inlineItemMarginBottom: 0,
  }),
  Ie = (e, t) =>
    f(e, { formItemCls: `${e.componentCls}-item`, rootPrefixCls: t }),
  Le = v(
    `Form`,
    (e, { rootPrefixCls: t }) => {
      let n = Ie(e, t);
      return [ke(n), Ae(n), Ee(n), je(n), Me(n), Pe(n), de(n), U];
    },
    Fe,
    { order: -1e3 }
  ),
  Re = [];
function ze(e, t, n, r = 0) {
  return {
    key: typeof e == `string` ? e : `${t}-${r}`,
    error: e,
    errorStatus: n,
  };
}
var Be = ({
    help: e,
    helpStatus: t,
    errors: n = Re,
    warnings: r = Re,
    className: i,
    fieldId: a,
    onVisibleChanged: o,
  }) => {
    let { prefixCls: s } = Z.useContext(F),
      c = `${s}-item-explain`,
      l = oe(s),
      [u, d, f] = Le(s, l),
      p = Z.useMemo(() => H(s), [s]),
      m = Te(n),
      g = Te(r),
      _ = Z.useMemo(
        () =>
          e == null
            ? [].concat(
                h(m.map((e, t) => ze(e, `error`, `error`, t))),
                h(g.map((e, t) => ze(e, `warning`, `warning`, t)))
              )
            : [ze(e, `help`, t)],
        [e, t, m, g]
      ),
      v = Z.useMemo(() => {
        let e = {};
        return (
          _.forEach(({ key: t }) => {
            e[t] = (e[t] || 0) + 1;
          }),
          _.map((t, n) =>
            Object.assign(Object.assign({}, t), {
              key: e[t.key] > 1 ? `${t.key}-fallback-${n}` : t.key,
            })
          )
        );
      }, [_]),
      y = {};
    return (
      a && (y.id = `${a}_help`),
      u(
        Z.createElement(
          b,
          {
            motionDeadline: p.motionDeadline,
            motionName: `${s}-show-help`,
            visible: !!v.length,
            onVisibleChanged: o,
          },
          (e) => {
            let { className: t, style: n } = e;
            return Z.createElement(
              `div`,
              Object.assign({}, y, {
                className: (0, X.default)(c, t, f, l, i, d),
                style: n,
              }),
              Z.createElement(
                x,
                Object.assign({ keys: v }, H(s), {
                  motionName: `${s}-show-help-item`,
                  component: !1,
                }),
                (e) => {
                  let {
                    key: t,
                    error: n,
                    errorStatus: r,
                    className: i,
                    style: a,
                  } = e;
                  return Z.createElement(
                    `div`,
                    {
                      key: t,
                      className: (0, X.default)(i, { [`${c}-${r}`]: r }),
                      style: a,
                    },
                    n
                  );
                }
              )
            );
          }
        )
      )
    );
  },
  Ve = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  He = Z.forwardRef((e, t) => {
    let n = Z.useContext(C),
      {
        getPrefixCls: r,
        direction: i,
        requiredMark: a,
        colon: o,
        scrollToFirstError: s,
        className: c,
        style: l,
      } = g(`form`),
      {
        prefixCls: u,
        className: f,
        rootClassName: p,
        size: m,
        disabled: h = n,
        form: _,
        colon: v,
        labelAlign: b,
        labelWrap: x,
        labelCol: w,
        wrapperCol: T,
        hideRequiredMark: E,
        layout: D = `horizontal`,
        scrollToFirstError: O,
        requiredMark: k,
        onFinishFailed: A,
        name: j,
        style: N,
        feedbackIcons: P,
        variant: F,
      } = e,
      te = Ve(e, [
        `prefixCls`,
        `className`,
        `rootClassName`,
        `size`,
        `disabled`,
        `form`,
        `colon`,
        `labelAlign`,
        `labelWrap`,
        `labelCol`,
        `wrapperCol`,
        `hideRequiredMark`,
        `layout`,
        `scrollToFirstError`,
        `requiredMark`,
        `onFinishFailed`,
        `name`,
        `style`,
        `feedbackIcons`,
        `variant`,
      ]),
      R = d(m),
      z = Z.useContext(re),
      B = Z.useMemo(
        () => (k === void 0 ? (E ? !1 : a === void 0 || a) : k),
        [E, k, a]
      ),
      V = v ?? o,
      H = r(`form`, u),
      U = oe(H),
      [ie, W, G] = Le(H, U),
      ae = (0, X.default)(
        H,
        `${H}-${D}`,
        {
          [`${H}-hide-required-mark`]: B === !1,
          [`${H}-rtl`]: i === `rtl`,
          [`${H}-${R}`]: R,
        },
        G,
        U,
        W,
        c,
        f,
        p
      ),
      [K] = se(_),
      { __INTERNAL__: q } = K;
    q.name = j;
    let J = Z.useMemo(
        () => ({
          name: j,
          labelAlign: b,
          labelCol: w,
          labelWrap: x,
          wrapperCol: T,
          layout: D,
          colon: V,
          requiredMark: B,
          itemRef: q.itemRef,
          form: K,
          feedbackIcons: P,
        }),
        [j, b, w, T, D, V, B, K, P]
      ),
      Y = Z.useRef(null);
    Z.useImperativeHandle(t, () => {
      var e;
      return Object.assign(Object.assign({}, K), {
        nativeElement: (e = Y.current) == null ? void 0 : e.nativeElement,
      });
    });
    let ce = (e, t) => {
      if (e) {
        let n = { block: `nearest` };
        typeof e == `object` && (n = Object.assign(Object.assign({}, n), e)),
          K.scrollToField(t, n);
      }
    };
    return ie(
      Z.createElement(
        ee.Provider,
        { value: F },
        Z.createElement(
          S,
          { disabled: h },
          Z.createElement(
            y.Provider,
            { value: R },
            Z.createElement(
              M,
              { validateMessages: z },
              Z.createElement(
                L.Provider,
                { value: J },
                Z.createElement(
                  ne,
                  { status: !0 },
                  Z.createElement(
                    I,
                    Object.assign({ id: j }, te, {
                      name: j,
                      onFinishFailed: (e) => {
                        if ((A == null || A(e), e.errorFields.length)) {
                          let t = e.errorFields[0].name;
                          if (O !== void 0) {
                            ce(O, t);
                            return;
                          }
                          s !== void 0 && ce(s, t);
                        }
                      },
                      form: K,
                      ref: Y,
                      style: Object.assign(Object.assign({}, l), N),
                      className: ae,
                    })
                  )
                )
              )
            )
          )
        )
      )
    );
  });
function Ue(e) {
  if (typeof e == `function`) return e;
  let t = r(e);
  return t.length <= 1 ? t[0] : t;
}
var We = () => {
  let { status: e, errors: t = [], warnings: n = [] } = Z.useContext(z);
  return { status: e, errors: t, warnings: n };
};
We.Context = z;
function Ge(e) {
  let [t, n] = Z.useState(e),
    r = Z.useRef(null),
    i = Z.useRef([]),
    a = Z.useRef(!1);
  Z.useEffect(
    () => (
      (a.current = !1),
      () => {
        (a.current = !0), D.cancel(r.current), (r.current = null);
      }
    ),
    []
  );
  function o(e) {
    a.current ||
      (r.current === null &&
        ((i.current = []),
        (r.current = D(() => {
          (r.current = null),
            n((e) => {
              let t = e;
              return (
                i.current.forEach((e) => {
                  t = e(t);
                }),
                t
              );
            });
        }))),
      i.current.push(e));
  }
  return [t, o];
}
function Ke() {
  let { itemRef: e } = Z.useContext(L),
    t = Z.useRef({});
  function r(r, i) {
    let a = i && typeof i == `object` && n(i),
      o = r.join(`_`);
    return (
      (t.current.name !== o || t.current.originRef !== a) &&
        ((t.current.name = o),
        (t.current.originRef = a),
        (t.current.ref = s(e(r), a))),
      t.current.ref
    );
  }
  return r;
}
var qe = (e) => {
    let { formItemCls: t } = e;
    return {
      "@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none)":
        { [`${t}-control`]: { display: `flex` } },
    };
  },
  Je = p([`Form`, `item-item`], (e, { rootPrefixCls: t }) => qe(Ie(e, t))),
  Ye = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Xe = 24,
  Ze = (e) => {
    let {
        prefixCls: t,
        status: n,
        labelCol: r,
        wrapperCol: i,
        children: o,
        errors: s,
        warnings: c,
        _internalItemRender: l,
        extra: u,
        help: d,
        fieldId: f,
        marginBottom: p,
        onErrorVisibleChanged: m,
        label: h,
      } = e,
      g = `${t}-item`,
      _ = Z.useContext(L),
      v = Z.useMemo(() => {
        let e = Object.assign({}, i || _.wrapperCol || {});
        return (
          h === null &&
            !r &&
            !i &&
            _.labelCol &&
            [void 0, `xs`, `sm`, `md`, `lg`, `xl`, `xxl`].forEach((t) => {
              let n = t ? [t] : [],
                r = j(_.labelCol, n),
                i = typeof r == `object` ? r : {},
                a = j(e, n),
                o = typeof a == `object` ? a : {};
              `span` in i &&
                !(`offset` in o) &&
                i.span < Xe &&
                (e = A(e, [].concat(n, [`offset`]), i.span));
            }),
          e
        );
      }, [i, _]),
      y = (0, X.default)(`${g}-control`, v.className),
      b = Z.useMemo(() => {
        let { labelCol: e, wrapperCol: t } = _;
        return Ye(_, [`labelCol`, `wrapperCol`]);
      }, [_]),
      x = Z.useRef(null),
      [S, C] = Z.useState(0);
    a(() => {
      u && x.current ? C(x.current.clientHeight) : C(0);
    }, [u]);
    let w = Z.createElement(
        `div`,
        { className: `${g}-control-input` },
        Z.createElement(`div`, { className: `${g}-control-input-content` }, o)
      ),
      T = Z.useMemo(() => ({ prefixCls: t, status: n }), [t, n]),
      E =
        p !== null || s.length || c.length
          ? Z.createElement(
              F.Provider,
              { value: T },
              Z.createElement(Be, {
                fieldId: f,
                errors: s,
                warnings: c,
                help: d,
                helpStatus: n,
                className: `${g}-explain-connected`,
                onVisibleChanged: m,
              })
            )
          : null,
      D = {};
    f && (D.id = `${f}_extra`);
    let O = u
        ? Z.createElement(
            `div`,
            Object.assign({}, D, { className: `${g}-extra`, ref: x }),
            u
          )
        : null,
      k =
        E || O
          ? Z.createElement(
              `div`,
              {
                className: `${g}-additional`,
                style: p ? { minHeight: p + S } : {},
              },
              E,
              O
            )
          : null,
      M =
        l && l.mark === `pro_table_render` && l.render
          ? l.render(e, { input: w, errorList: E, extra: O })
          : Z.createElement(Z.Fragment, null, w, k);
    return Z.createElement(
      L.Provider,
      { value: b },
      Z.createElement(ye, Object.assign({}, v, { className: y }), M),
      Z.createElement(Je, { prefixCls: t })
    );
  },
  Qe = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  $e = ({
    prefixCls: e,
    label: t,
    htmlFor: n,
    labelCol: r,
    labelAlign: i,
    colon: a,
    required: o,
    requiredMark: s,
    tooltip: c,
    vertical: l,
  }) => {
    var u;
    let [d] = ae(`Form`),
      { labelAlign: f, labelCol: p, labelWrap: m, colon: h } = Z.useContext(L);
    if (!t) return null;
    let g = r || p || {},
      _ = i || f,
      v = `${e}-item-label`,
      y = (0, X.default)(v, _ === `left` && `${v}-left`, g.className, {
        [`${v}-wrap`]: !!m,
      }),
      b = t,
      x = a === !0 || (h !== !1 && a !== !1);
    x &&
      !l &&
      typeof t == `string` &&
      t.trim() &&
      (b = t.replace(/[:|：]\s*$/, ``));
    let S = we(c);
    if (S) {
      let { icon: t = Z.createElement(me, null) } = S,
        n = Qe(S, [`icon`]),
        r = Z.createElement(
          K,
          Object.assign({}, n),
          Z.cloneElement(t, {
            className: `${e}-item-tooltip`,
            title: ``,
            onClick: (e) => {
              e.preventDefault();
            },
            tabIndex: null,
          })
        );
      b = Z.createElement(Z.Fragment, null, b, r);
    }
    let C = s === `optional`,
      w = typeof s == `function`,
      T = s === !1;
    w
      ? (b = s(b, { required: !!o }))
      : C &&
        !o &&
        (b = Z.createElement(
          Z.Fragment,
          null,
          b,
          Z.createElement(
            `span`,
            { className: `${e}-item-optional`, title: `` },
            (d == null ? void 0 : d.optional) ||
              ((u = G.Form) == null ? void 0 : u.optional)
          )
        ));
    let E;
    T ? (E = `hidden`) : (C || w) && (E = `optional`);
    let D = (0, X.default)({
      [`${e}-item-required`]: o,
      [`${e}-item-required-mark-${E}`]: E,
      [`${e}-item-no-colon`]: !x,
    });
    return Z.createElement(
      ye,
      Object.assign({}, g, { className: y }),
      Z.createElement(
        `label`,
        { htmlFor: n, className: D, title: typeof t == `string` ? t : `` },
        b
      )
    );
  },
  et = { success: ie, warning: W, error: q, validating: O };
function tt({
  children: e,
  errors: t,
  warnings: n,
  hasFeedback: r,
  validateStatus: i,
  prefixCls: a,
  meta: o,
  noStyle: s,
  name: c,
}) {
  let l = `${a}-item`,
    { feedbackIcons: u } = Z.useContext(L),
    d = Y(t, n, o, null, !!r, i),
    {
      isFormItemInput: f,
      status: p,
      hasFeedback: m,
      feedbackIcon: h,
      name: g,
    } = Z.useContext(z),
    _ = Z.useMemo(() => {
      var e;
      let i;
      if (r) {
        let a = (r !== !0 && r.icons) || u,
          o =
            d &&
            ((e =
              a == null ? void 0 : a({ status: d, errors: t, warnings: n })) ==
            null
              ? void 0
              : e[d]),
          s = d && et[d];
        i =
          o !== !1 && s
            ? Z.createElement(
                `span`,
                {
                  className: (0, X.default)(
                    `${l}-feedback-icon`,
                    `${l}-feedback-icon-${d}`
                  ),
                },
                o || Z.createElement(s, null)
              )
            : null;
      }
      let a = {
        status: d || ``,
        errors: t,
        warnings: n,
        hasFeedback: !!r,
        feedbackIcon: i,
        isFormItemInput: !0,
        name: c,
      };
      return (
        s &&
          ((a.status = (d ?? p) || ``),
          (a.isFormItemInput = f),
          (a.hasFeedback = !!(r ?? m)),
          (a.feedbackIcon = r === void 0 ? h : a.feedbackIcon),
          (a.name = c ?? g)),
        a
      );
    }, [d, r, s, f, p]);
  return Z.createElement(z.Provider, { value: _ }, e);
}
var nt = function (e, t) {
  var n = {};
  for (var r in e)
    Object.prototype.hasOwnProperty.call(e, r) &&
      t.indexOf(r) < 0 &&
      (n[r] = e[r]);
  if (e != null && typeof Object.getOwnPropertySymbols == `function`)
    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
      t.indexOf(r[i]) < 0 &&
        Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
        (n[r[i]] = e[r[i]]);
  return n;
};
function rt(e) {
  let {
      prefixCls: t,
      className: n,
      rootClassName: r,
      style: i,
      help: o,
      errors: s,
      warnings: c,
      validateStatus: l,
      meta: u,
      hasFeedback: d,
      hidden: f,
      children: p,
      fieldId: m,
      required: h,
      isRequired: g,
      onSubItemMetaChange: _,
      layout: v,
      name: y,
    } = e,
    b = nt(e, [
      `prefixCls`,
      `className`,
      `rootClassName`,
      `style`,
      `help`,
      `errors`,
      `warnings`,
      `validateStatus`,
      `meta`,
      `hasFeedback`,
      `hidden`,
      `children`,
      `fieldId`,
      `required`,
      `isRequired`,
      `onSubItemMetaChange`,
      `layout`,
      `name`,
    ]),
    x = `${t}-item`,
    { requiredMark: S, layout: C } = Z.useContext(L),
    E = v || C,
    D = E === `vertical`,
    O = Z.useRef(null),
    k = Te(s),
    A = Te(c),
    j = o != null,
    M = !!(j || s.length || c.length),
    ee = !!O.current && T(O.current),
    [N, P] = Z.useState(null);
  a(() => {
    if (M && O.current) {
      let e = getComputedStyle(O.current);
      P(parseInt(e.marginBottom, 10));
    }
  }, [M, ee]);
  let F = (e) => {
      e || P(null);
    },
    I = ((e = !1) => {
      let t = e ? k : u.errors,
        n = e ? A : u.warnings;
      return Y(t, n, u, ``, !!d, l);
    })(),
    te = (0, X.default)(x, n, r, {
      [`${x}-with-help`]: j || k.length || A.length,
      [`${x}-has-feedback`]: I && d,
      [`${x}-has-success`]: I === `success`,
      [`${x}-has-warning`]: I === `warning`,
      [`${x}-has-error`]: I === `error`,
      [`${x}-is-validating`]: I === `validating`,
      [`${x}-hidden`]: f,
      [`${x}-${E}`]: E,
    });
  return Z.createElement(
    `div`,
    { className: te, style: i, ref: O },
    Z.createElement(
      Ce,
      Object.assign(
        { className: `${x}-row` },
        w(
          b,
          `_internalItemRender.colon.dependencies.extra.fieldKey.getValueFromEvent.getValueProps.htmlFor.id.initialValue.isListField.label.labelAlign.labelCol.labelWrap.messageVariables.name.normalize.noStyle.preserve.requiredMark.rules.shouldUpdate.trigger.tooltip.validateFirst.validateTrigger.valuePropName.wrapperCol.validateDebounce`.split(
            `.`
          )
        )
      ),
      Z.createElement(
        $e,
        Object.assign({ htmlFor: m }, e, {
          requiredMark: S,
          required: h ?? g,
          prefixCls: t,
          vertical: D,
        })
      ),
      Z.createElement(
        Ze,
        Object.assign({}, e, u, {
          errors: k,
          warnings: A,
          prefixCls: t,
          status: I,
          help: o,
          marginBottom: N,
          onErrorVisibleChanged: F,
        }),
        Z.createElement(
          B.Provider,
          { value: _ },
          Z.createElement(
            tt,
            {
              prefixCls: t,
              meta: u,
              errors: u.errors,
              warnings: u.warnings,
              hasFeedback: d,
              validateStatus: I,
              name: y,
            },
            p
          )
        )
      )
    ),
    !!N &&
      Z.createElement(`div`, {
        className: `${x}-margin-offset`,
        style: { marginBottom: -N },
      })
  );
}
m();
var it = `__SPLIT__`;
function at(e, t) {
  let n = Object.keys(e),
    r = Object.keys(t);
  return (
    n.length === r.length &&
    n.every((n) => {
      let r = e[n],
        i = t[n];
      return r === i || typeof r == `function` || typeof i == `function`;
    })
  );
}
var ot = Z.memo(
  ({ children: e }) => e,
  (e, t) =>
    at(e.control, t.control) &&
    e.update === t.update &&
    e.childProps.length === t.childProps.length &&
    e.childProps.every((e, n) => e === t.childProps[n])
);
function st() {
  return {
    errors: [],
    warnings: [],
    touched: !1,
    validating: !1,
    name: [],
    validated: !1,
  };
}
function ct(e) {
  let {
      name: t,
      noStyle: n,
      className: r,
      dependencies: a,
      prefixCls: s,
      shouldUpdate: l,
      rules: u,
      children: d,
      required: f,
      label: p,
      messageVariables: m,
      trigger: g = `onChange`,
      validateTrigger: _,
      hidden: v,
      help: y,
      layout: b,
    } = e,
    { getPrefixCls: x } = Z.useContext(i),
    { name: S } = Z.useContext(L),
    C = Ue(d),
    w = typeof C == `function`,
    T = Z.useContext(B),
    { validateTrigger: D } = Z.useContext(P),
    O = _ === void 0 ? D : _,
    A = t != null,
    j = x(`form`, s),
    M = oe(j),
    [ee, N, F] = Le(j, M);
  k(`Form.Item`);
  let I = Z.useContext(te),
    ne = Z.useRef(null),
    [z, V] = Ge({}),
    [H, U] = c(() => st()),
    re = (e) => {
      let t = I == null ? void 0 : I.getKey(e.name);
      if ((U(e.destroy ? st() : e, !0), n && y !== !1 && T)) {
        let n = e.name;
        if (e.destroy) n = ne.current || n;
        else if (t !== void 0) {
          let [e, r] = t;
          (n = [e].concat(h(r))), (ne.current = n);
        }
        T(e, n);
      }
    },
    ie = (e, t) => {
      V((n) => {
        let r = Object.assign({}, n),
          i = [].concat(h(e.name.slice(0, -1)), h(t)).join(it);
        return e.destroy ? delete r[i] : (r[i] = e), r;
      });
    },
    [W, G] = Z.useMemo(() => {
      let e = h(H.errors),
        t = h(H.warnings);
      return (
        Object.values(z).forEach((n) => {
          e.push.apply(e, h(n.errors || [])),
            t.push.apply(t, h(n.warnings || []));
        }),
        [e, t]
      );
    }, [z, H.errors, H.warnings]),
    ae = Ke();
  function K(i, a, o) {
    return n && !v
      ? Z.createElement(
          tt,
          {
            prefixCls: j,
            hasFeedback: e.hasFeedback,
            validateStatus: e.validateStatus,
            meta: H,
            errors: W,
            warnings: G,
            noStyle: !0,
            name: t,
          },
          i
        )
      : Z.createElement(
          rt,
          Object.assign({ key: `row` }, e, {
            className: (0, X.default)(r, F, M, N),
            prefixCls: j,
            fieldId: a,
            isRequired: o,
            errors: W,
            warnings: G,
            meta: H,
            onSubItemMetaChange: ie,
            layout: b,
            name: t,
          }),
          i
        );
  }
  if (!A && !w && !a) return ee(K(C));
  let q = {};
  return (
    typeof p == `string` ? (q.label = p) : t && (q.label = String(t)),
    m && (q = Object.assign(Object.assign({}, q), m)),
    ee(
      Z.createElement(
        R,
        Object.assign({}, e, {
          messageVariables: q,
          trigger: g,
          validateTrigger: O,
          onMetaChange: re,
        }),
        (n, r, i) => {
          let s = J(t).length && r ? r.name : [],
            c = ce(s, S),
            d =
              f === void 0
                ? !!(
                    u != null &&
                    u.some((e) => {
                      if (
                        e &&
                        typeof e == `object` &&
                        e.required &&
                        !e.warningOnly
                      )
                        return !0;
                      if (typeof e == `function`) {
                        let t = e(i);
                        return (
                          (t == null ? void 0 : t.required) &&
                          !(t != null && t.warningOnly)
                        );
                      }
                      return !1;
                    })
                  )
                : f,
            p = Object.assign({}, n),
            m = null;
          if (Array.isArray(C) && A) m = C;
          else if ((!w || ((l || a) && !A)) && (!a || w || A)) {
            if (Z.isValidElement(C)) {
              let t = Object.assign(Object.assign({}, C.props), p);
              if (
                (t.id || (t.id = c),
                y || W.length > 0 || G.length > 0 || e.extra)
              ) {
                let n = [];
                (y || W.length > 0) && n.push(`${c}_help`),
                  e.extra && n.push(`${c}_extra`),
                  (t[`aria-describedby`] = n.join(` `));
              }
              W.length > 0 && (t[`aria-invalid`] = `true`),
                d && (t[`aria-required`] = `true`),
                o(C) && (t.ref = ae(s, C)),
                new Set([].concat(h(J(g)), h(J(O)))).forEach((e) => {
                  t[e] = (...t) => {
                    var n, r, i, a, o;
                    (i = p[e]) == null || (n = i).call.apply(n, [p].concat(t)),
                      (o = (a = C.props)[e]) == null ||
                        (r = o).call.apply(r, [a].concat(t));
                  };
                });
              let n = [
                t[`aria-required`],
                t[`aria-invalid`],
                t[`aria-describedby`],
              ];
              m = Z.createElement(
                ot,
                { control: p, update: C, childProps: n },
                E(C, t)
              );
            } else m = w && (l || a) && !A ? C(i) : C;
          }
          return K(m, c, d);
        }
      )
    )
  );
}
var lt = ct;
lt.useStatus = We;
var ut = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  dt = (e) => {
    var { prefixCls: t, children: n } = e,
      r = ut(e, [`prefixCls`, `children`]);
    let { getPrefixCls: a } = Z.useContext(i),
      o = a(`form`, t),
      s = Z.useMemo(() => ({ prefixCls: o, status: `error` }), [o]);
    return Z.createElement(N, Object.assign({}, r), (e, t, r) =>
      Z.createElement(
        F.Provider,
        { value: s },
        n(
          e.map((e) =>
            Object.assign(Object.assign({}, e), { fieldKey: e.key })
          ),
          t,
          { errors: r.errors, warnings: r.warnings }
        )
      )
    );
  };
function ft() {
  let { form: e } = Z.useContext(L);
  return e;
}
var $ = He;
($.Item = lt),
  ($.List = dt),
  ($.ErrorList = Be),
  ($.useForm = se),
  ($.useFormInstance = ft),
  ($.useWatch = V),
  ($.Provider = M),
  ($.create = () => {});
export { $ as t };
