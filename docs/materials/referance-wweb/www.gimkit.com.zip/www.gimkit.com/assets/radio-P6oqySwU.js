import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  E as n,
  Ot as r,
  Ut as i,
  X as a,
  a as o,
  b as s,
  m as c,
  s as l,
  u,
  x as d,
} from "./Compact-CRRKXVA1.js";
import { h as f } from "./color-Dzrzfp-h.js";
import { g as p, r as m } from "./ContextIsolator-D7w7V6rn.js";
import { t as h } from "./useCSSVarCls-7-ltqzGc.js";
import { t as g } from "./pickAttrs-DgAKW8il.js";
import { t as _ } from "./useForm-IQSiwVDR.js";
import { i as v, r as y } from "./button-Cpfts2Ff.js";
import { n as b, t as x } from "./useBubbleLock-CgH4_GTm.js";
var S = e(i()),
  C = e(t()),
  w = C.createContext(null),
  T = w.Provider,
  E = C.createContext(null),
  D = E.Provider,
  O = (e) => {
    let { componentCls: t, antCls: n } = e,
      r = `${t}-group`;
    return {
      [r]: Object.assign(Object.assign({}, c(e)), {
        display: `inline-block`,
        fontSize: 0,
        [`&${r}-rtl`]: { direction: `rtl` },
        [`&${r}-block`]: { display: `flex` },
        [`${n}-badge ${n}-badge-count`]: { zIndex: 1 },
        [`> ${n}-badge:not(:first-child) > ${n}-button-wrapper`]: {
          borderInlineStart: `none`,
        },
      }),
    };
  },
  k = (e) => {
    let {
        componentCls: t,
        wrapperMarginInlineEnd: n,
        colorPrimary: r,
        radioSize: i,
        motionDurationSlow: o,
        motionDurationMid: s,
        motionEaseInOutCirc: l,
        colorBgContainer: d,
        colorBorder: f,
        lineWidth: p,
        colorBgContainerDisabled: m,
        colorTextDisabled: h,
        paddingXS: g,
        dotColorDisabled: _,
        lineType: v,
        radioColor: y,
        radioBgColor: b,
        calc: x,
      } = e,
      S = `${t}-inner`,
      C = x(i).sub(x(4).mul(2)),
      w = x(1).mul(i).equal({ unit: !0 });
    return {
      [`${t}-wrapper`]: Object.assign(Object.assign({}, c(e)), {
        display: `inline-flex`,
        alignItems: `baseline`,
        marginInlineStart: 0,
        marginInlineEnd: n,
        cursor: `pointer`,
        "&:last-child": { marginInlineEnd: 0 },
        [`&${t}-wrapper-rtl`]: { direction: `rtl` },
        "&-disabled": { cursor: `not-allowed`, color: e.colorTextDisabled },
        "&::after": {
          display: `inline-block`,
          width: 0,
          overflow: `hidden`,
          content: `"\\a0"`,
        },
        "&-block": { flex: 1, justifyContent: `center` },
        [`${t}-checked::after`]: {
          position: `absolute`,
          insetBlockStart: 0,
          insetInlineStart: 0,
          width: `100%`,
          height: `100%`,
          border: `${a(p)} ${v} ${r}`,
          borderRadius: `50%`,
          visibility: `hidden`,
          opacity: 0,
          content: `""`,
        },
        [t]: Object.assign(Object.assign({}, c(e)), {
          position: `relative`,
          display: `inline-block`,
          outline: `none`,
          cursor: `pointer`,
          alignSelf: `center`,
          borderRadius: `50%`,
        }),
        [`${t}-wrapper:hover &,
        &:hover ${S}`]: { borderColor: r },
        [`${t}-input:focus-visible + ${S}`]: u(e),
        [`${t}:hover::after, ${t}-wrapper:hover &::after`]: {
          visibility: `visible`,
        },
        [`${t}-inner`]: {
          "&::after": {
            boxSizing: `border-box`,
            position: `absolute`,
            insetBlockStart: `50%`,
            insetInlineStart: `50%`,
            display: `block`,
            width: w,
            height: w,
            marginBlockStart: x(1).mul(i).div(-2).equal({ unit: !0 }),
            marginInlineStart: x(1).mul(i).div(-2).equal({ unit: !0 }),
            backgroundColor: y,
            borderBlockStart: 0,
            borderInlineStart: 0,
            borderRadius: w,
            transform: `scale(0)`,
            opacity: 0,
            transition: `all ${o} ${l}`,
            content: `""`,
          },
          boxSizing: `border-box`,
          position: `relative`,
          insetBlockStart: 0,
          insetInlineStart: 0,
          display: `block`,
          width: w,
          height: w,
          backgroundColor: d,
          borderColor: f,
          borderStyle: `solid`,
          borderWidth: p,
          borderRadius: `50%`,
          transition: `all ${s}`,
        },
        [`${t}-input`]: {
          position: `absolute`,
          inset: 0,
          zIndex: 1,
          cursor: `pointer`,
          opacity: 0,
        },
        [`${t}-checked`]: {
          [S]: {
            borderColor: r,
            backgroundColor: b,
            "&::after": {
              transform: `scale(${e.calc(e.dotSize).div(i).equal()})`,
              opacity: 1,
              transition: `all ${o} ${l}`,
            },
          },
        },
        [`${t}-disabled`]: {
          cursor: `not-allowed`,
          [S]: {
            backgroundColor: m,
            borderColor: f,
            cursor: `not-allowed`,
            "&::after": { backgroundColor: _ },
          },
          [`${t}-input`]: { cursor: `not-allowed` },
          [`${t}-disabled + span`]: { color: h, cursor: `not-allowed` },
          [`&${t}-checked`]: {
            [S]: { "&::after": { transform: `scale(${x(C).div(i).equal()})` } },
          },
        },
        [`span${t} + *`]: { paddingInlineStart: g, paddingInlineEnd: g },
      }),
    };
  },
  A = (e) => {
    let {
      buttonColor: t,
      controlHeight: n,
      componentCls: r,
      lineWidth: i,
      lineType: o,
      colorBorder: s,
      motionDurationSlow: c,
      motionDurationMid: l,
      buttonPaddingInline: d,
      fontSize: f,
      buttonBg: p,
      fontSizeLG: m,
      controlHeightLG: h,
      controlHeightSM: g,
      paddingXS: _,
      borderRadius: v,
      borderRadiusSM: y,
      borderRadiusLG: b,
      buttonCheckedBg: x,
      buttonSolidCheckedColor: S,
      colorTextDisabled: C,
      colorBgContainerDisabled: w,
      buttonCheckedBgDisabled: T,
      buttonCheckedColorDisabled: E,
      colorPrimary: D,
      colorPrimaryHover: O,
      colorPrimaryActive: k,
      buttonSolidCheckedBg: A,
      buttonSolidCheckedHoverBg: j,
      buttonSolidCheckedActiveBg: M,
      calc: N,
    } = e;
    return {
      [`${r}-button-wrapper`]: {
        position: `relative`,
        display: `inline-block`,
        height: n,
        margin: 0,
        paddingInline: d,
        paddingBlock: 0,
        color: t,
        fontSize: f,
        lineHeight: a(N(n).sub(N(i).mul(2)).equal()),
        background: p,
        border: `${a(i)} ${o} ${s}`,
        borderBlockStartWidth: N(i).add(0.02).equal(),
        borderInlineStartWidth: 0,
        borderInlineEndWidth: i,
        cursor: `pointer`,
        transition: [`color ${l}`, `background ${l}`, `box-shadow ${l}`].join(
          `,`
        ),
        a: { color: t },
        [`> ${r}-button`]: {
          position: `absolute`,
          insetBlockStart: 0,
          insetInlineStart: 0,
          zIndex: -1,
          width: `100%`,
          height: `100%`,
        },
        "&:not(:first-child)": {
          "&::before": {
            position: `absolute`,
            insetBlockStart: N(i).mul(-1).equal(),
            insetInlineStart: N(i).mul(-1).equal(),
            display: `block`,
            boxSizing: `content-box`,
            width: 1,
            height: `100%`,
            paddingBlock: i,
            paddingInline: 0,
            backgroundColor: s,
            transition: `background-color ${c}`,
            content: `""`,
          },
        },
        "&:first-child": {
          borderInlineStart: `${a(i)} ${o} ${s}`,
          borderStartStartRadius: v,
          borderEndStartRadius: v,
        },
        "&:last-child": { borderStartEndRadius: v, borderEndEndRadius: v },
        "&:first-child:last-child": { borderRadius: v },
        [`${r}-group-large &`]: {
          height: h,
          fontSize: m,
          lineHeight: a(N(h).sub(N(i).mul(2)).equal()),
          "&:first-child": {
            borderStartStartRadius: b,
            borderEndStartRadius: b,
          },
          "&:last-child": { borderStartEndRadius: b, borderEndEndRadius: b },
        },
        [`${r}-group-small &`]: {
          height: g,
          paddingInline: N(_).sub(i).equal(),
          paddingBlock: 0,
          lineHeight: a(N(g).sub(N(i).mul(2)).equal()),
          "&:first-child": {
            borderStartStartRadius: y,
            borderEndStartRadius: y,
          },
          "&:last-child": { borderStartEndRadius: y, borderEndEndRadius: y },
        },
        "&:hover": { position: `relative`, color: D },
        "&:has(:focus-visible)": u(e),
        [`${r}-inner, input[type='checkbox'], input[type='radio']`]: {
          width: 0,
          height: 0,
          opacity: 0,
          pointerEvents: `none`,
        },
        [`&-checked:not(${r}-button-wrapper-disabled)`]: {
          zIndex: 1,
          color: D,
          background: x,
          borderColor: D,
          "&::before": { backgroundColor: D },
          "&:first-child": { borderColor: D },
          "&:hover": {
            color: O,
            borderColor: O,
            "&::before": { backgroundColor: O },
          },
          "&:active": {
            color: k,
            borderColor: k,
            "&::before": { backgroundColor: k },
          },
        },
        [`${r}-group-solid &-checked:not(${r}-button-wrapper-disabled)`]: {
          color: S,
          background: A,
          borderColor: A,
          "&:hover": { color: S, background: j, borderColor: j },
          "&:active": { color: S, background: M, borderColor: M },
        },
        "&-disabled": {
          color: C,
          backgroundColor: w,
          borderColor: s,
          cursor: `not-allowed`,
          "&:first-child, &:hover": {
            color: C,
            backgroundColor: w,
            borderColor: s,
          },
        },
        [`&-disabled${r}-button-wrapper-checked`]: {
          color: E,
          backgroundColor: T,
          borderColor: s,
          boxShadow: `none`,
        },
        "&-block": { flex: 1, textAlign: `center` },
      },
    };
  },
  j = l(
    `Radio`,
    (e) => {
      let { controlOutline: t, controlOutlineWidth: n } = e,
        r = `0 0 0 ${a(n)} ${t}`,
        i = s(e, { radioFocusShadow: r, radioButtonFocusShadow: r });
      return [O(i), k(i), A(i)];
    },
    (e) => {
      let {
          wireframe: t,
          padding: n,
          marginXS: r,
          lineWidth: i,
          fontSizeLG: a,
          colorText: o,
          colorBgContainer: s,
          colorTextDisabled: c,
          controlItemBgActiveDisabled: l,
          colorTextLightSolid: u,
          colorPrimary: d,
          colorPrimaryHover: f,
          colorPrimaryActive: p,
          colorWhite: m,
        } = e,
        h = a;
      return {
        radioSize: h,
        dotSize: t ? h - 8 : h - (4 + i) * 2,
        dotColorDisabled: c,
        buttonSolidCheckedColor: u,
        buttonSolidCheckedBg: d,
        buttonSolidCheckedHoverBg: f,
        buttonSolidCheckedActiveBg: p,
        buttonBg: s,
        buttonCheckedBg: s,
        buttonColor: o,
        buttonCheckedBgDisabled: l,
        buttonCheckedColorDisabled: c,
        buttonPaddingInline: n - i,
        wrapperMarginInlineEnd: r,
        radioColor: t ? d : m,
        radioBgColor: t ? s : d,
      };
    },
    { unitless: { radioSize: !0, dotSize: !0 } }
  ),
  M = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  N = C.forwardRef((e, t) => {
    let i = C.useContext(w),
      a = C.useContext(E),
      { getPrefixCls: o, direction: s, radio: c } = C.useContext(n),
      l = C.useRef(null),
      u = r(t, l),
      { isFormItemInput: d } = C.useContext(m),
      p = (t) => {
        var n, r;
        (n = e.onChange) == null || n.call(e, t),
          (r = i == null ? void 0 : i.onChange) == null || r.call(i, t);
      },
      {
        prefixCls: g,
        className: _,
        rootClassName: T,
        children: D,
        style: O,
        title: k,
      } = e,
      A = M(e, [
        `prefixCls`,
        `className`,
        `rootClassName`,
        `children`,
        `style`,
        `title`,
      ]),
      N = o(`radio`, g),
      P = ((i == null ? void 0 : i.optionType) || a) === `button`,
      F = P ? `${N}-button` : N,
      I = h(N),
      [L, R, z] = j(N, I),
      B = Object.assign({}, A),
      V = C.useContext(f);
    i &&
      ((B.name = i.name),
      (B.onChange = p),
      (B.checked = e.value === i.value),
      (B.disabled = B.disabled ?? i.disabled)),
      (B.disabled = B.disabled ?? V);
    let H = (0, S.default)(
        `${F}-wrapper`,
        {
          [`${F}-wrapper-checked`]: B.checked,
          [`${F}-wrapper-disabled`]: B.disabled,
          [`${F}-wrapper-rtl`]: s === `rtl`,
          [`${F}-wrapper-in-form-item`]: d,
          [`${F}-wrapper-block`]: !!(i != null && i.block),
        },
        c == null ? void 0 : c.className,
        _,
        T,
        R,
        z,
        I
      ),
      [U, W] = x(B.onClick);
    return L(
      C.createElement(
        y,
        { component: `Radio`, disabled: B.disabled },
        C.createElement(
          `label`,
          {
            className: H,
            style: Object.assign(
              Object.assign({}, c == null ? void 0 : c.style),
              O
            ),
            onMouseEnter: e.onMouseEnter,
            onMouseLeave: e.onMouseLeave,
            title: k,
            onClick: U,
          },
          C.createElement(
            b,
            Object.assign({}, B, {
              className: (0, S.default)(B.className, { [v]: !P }),
              type: `radio`,
              prefixCls: F,
              ref: u,
              onClick: W,
            })
          ),
          D === void 0
            ? null
            : C.createElement(`span`, { className: `${F}-label` }, D)
        )
      )
    );
  }),
  P = C.forwardRef((e, t) => {
    let { getPrefixCls: r, direction: i } = C.useContext(n),
      { name: a } = C.useContext(m),
      s = p(_(a)),
      {
        prefixCls: c,
        className: l,
        rootClassName: u,
        options: f,
        buttonStyle: v = `outline`,
        disabled: y,
        children: b,
        size: x,
        style: w,
        id: E,
        optionType: D,
        name: O = s,
        defaultValue: k,
        value: A,
        block: M = !1,
        onChange: P,
        onMouseEnter: F,
        onMouseLeave: I,
        onFocus: L,
        onBlur: R,
      } = e,
      [z, B] = d(k, { value: A }),
      V = C.useCallback(
        (t) => {
          let n = z,
            r = t.target.value;
          `value` in e || B(r), r !== n && (P == null || P(t));
        },
        [z, B, P]
      ),
      H = r(`radio`, c),
      U = `${H}-group`,
      W = h(H),
      [G, K, q] = j(H, W),
      J = b;
    f &&
      f.length > 0 &&
      (J = f.map((e) =>
        typeof e == `string` || typeof e == `number`
          ? C.createElement(
              N,
              {
                key: e.toString(),
                prefixCls: H,
                disabled: y,
                value: e,
                checked: z === e,
              },
              e
            )
          : C.createElement(
              N,
              {
                key: `radio-group-value-options-${e.value}`,
                prefixCls: H,
                disabled: e.disabled || y,
                value: e.value,
                checked: z === e.value,
                title: e.title,
                style: e.style,
                className: e.className,
                id: e.id,
                required: e.required,
              },
              e.label
            )
      ));
    let Y = o(x),
      X = (0, S.default)(
        U,
        `${U}-${v}`,
        { [`${U}-${Y}`]: Y, [`${U}-rtl`]: i === `rtl`, [`${U}-block`]: M },
        l,
        u,
        K,
        q,
        W
      ),
      Z = C.useMemo(
        () => ({
          onChange: V,
          value: z,
          disabled: y,
          name: O,
          optionType: D,
          block: M,
        }),
        [V, z, y, O, D, M]
      );
    return G(
      C.createElement(
        `div`,
        Object.assign({}, g(e, { aria: !0, data: !0 }), {
          className: X,
          style: w,
          onMouseEnter: F,
          onMouseLeave: I,
          onFocus: L,
          onBlur: R,
          id: E,
          ref: t,
        }),
        C.createElement(T, { value: Z }, J)
      )
    );
  }),
  F = C.memo(P),
  I = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  L = C.forwardRef((e, t) => {
    let { getPrefixCls: r } = C.useContext(n),
      { prefixCls: i } = e,
      a = I(e, [`prefixCls`]),
      o = r(`radio`, i);
    return C.createElement(
      D,
      { value: `button` },
      C.createElement(
        N,
        Object.assign({ prefixCls: o }, a, { type: `radio`, ref: t })
      )
    );
  }),
  R = N;
(R.Button = L), (R.Group = F), (R.__ANT_RADIO = !0);
export { R as t };
