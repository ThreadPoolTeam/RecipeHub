import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import { _ as i } from "./Compact-CRRKXVA1.js";
import { r as a } from "./compact-item-BOjQ1zv3.js";
var o = e(t());
n();
var s = {
    icon: {
      tag: `svg`,
      attrs: {
        "fill-rule": `evenodd`,
        viewBox: `64 64 896 896`,
        focusable: `false`,
      },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M512 64c247.4 0 448 200.6 448 448S759.4 960 512 960 64 759.4 64 512 264.6 64 512 64zm127.98 274.82h-.04l-.08.06L512 466.75 384.14 338.88c-.04-.05-.06-.06-.08-.06a.12.12 0 00-.07 0c-.03 0-.05.01-.09.05l-45.02 45.02a.2.2 0 00-.05.09.12.12 0 000 .07v.02a.27.27 0 00.06.06L466.75 512 338.88 639.86c-.05.04-.06.06-.06.08a.12.12 0 000 .07c0 .03.01.05.05.09l45.02 45.02a.2.2 0 00.09.05.12.12 0 00.07 0c.02 0 .04-.01.08-.05L512 557.25l127.86 127.87c.04.04.06.05.08.05a.12.12 0 00.07 0c.03 0 .05-.01.09-.05l45.02-45.02a.2.2 0 00.05-.09.12.12 0 000-.07v-.02a.27.27 0 00-.05-.06L557.25 512l127.87-127.86c.04-.04.05-.06.05-.08a.12.12 0 000-.07c0-.03-.01-.05-.05-.09l-45.02-45.02a.2.2 0 00-.09-.05.12.12 0 00-.07 0z`,
          },
        },
      ],
    },
    name: `close-circle`,
    theme: `filled`,
  },
  c = o.forwardRef(function (e, t) {
    return o.createElement(a, r({}, e, { ref: t, icon: s }));
  }),
  l = (e) => {
    let [, , , , t] = i();
    return t ? `${e}-css-var` : ``;
  };
export { c as n, l as t };
