function e(e, t) {
  if (!e) throw Error(`Invariant failed`);
}
export { e as t };
