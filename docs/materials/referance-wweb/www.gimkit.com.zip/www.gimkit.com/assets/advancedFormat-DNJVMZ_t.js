import { t as e } from "./rolldown-runtime-C0FnF6B9.js";
var t = e((e, t) => {
  (function (n, r) {
    typeof e == `object` && t !== void 0
      ? (t.exports = r())
      : typeof define == `function` && define.amd
      ? define(r)
      : ((n =
          typeof globalThis < `u`
            ? globalThis
            : n || self).dayjs_plugin_advancedFormat = r());
  })(e, function () {
    return function (e, t) {
      var n = t.prototype,
        r = n.format;
      n.format = function (e) {
        var t = this,
          n = this.$locale();
        if (!this.isValid()) return r.bind(this)(e);
        var i = this.$utils(),
          a = (e || `YYYY-MM-DDTHH:mm:ssZ`).replace(
            /\[([^\]]+)]|Q|wo|ww|w|WW|W|zzz|z|gggg|GGGG|Do|X|x|k{1,2}|S/g,
            function (e) {
              switch (e) {
                case `Q`:
                  return Math.ceil((t.$M + 1) / 3);
                case `Do`:
                  return n.ordinal(t.$D);
                case `gggg`:
                  return t.weekYear();
                case `GGGG`:
                  return t.isoWeekYear();
                case `wo`:
                  return n.ordinal(t.week(), `W`);
                case `w`:
                case `ww`:
                  return i.s(t.week(), e === `w` ? 1 : 2, `0`);
                case `W`:
                case `WW`:
                  return i.s(t.isoWeek(), e === `W` ? 1 : 2, `0`);
                case `k`:
                case `kk`:
                  return i.s(
                    String(t.$H === 0 ? 24 : t.$H),
                    e === `k` ? 1 : 2,
                    `0`
                  );
                case `X`:
                  return Math.floor(t.$d.getTime() / 1e3);
                case `x`:
                  return t.$d.getTime();
                case `z`:
                  return `[` + t.offsetName() + `]`;
                case `zzz`:
                  return `[` + t.offsetName(`long`) + `]`;
                default:
                  return e;
              }
            }
          );
        return r.bind(this)(a);
      };
    };
  });
});
export { t };
