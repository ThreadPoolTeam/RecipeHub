var e = (function (e) {
  return (
    (e.language = `gimkit-3.0-game-language`),
    (e.currency = `gimkit-game-currency`),
    (e.music = `gimkit-music-track`),
    (e.allowGoogleTranslate = `gimkit-google-translate-allowed`),
    (e.editorDefaultLanguage = `gimkit-editor-v4-default-language`),
    (e.editorDefaultGradeLevel = `gimkit-editor-v4-default-grade-level`),
    (e.editorDefaultSubject = `gimkit-editor-v4-default-subject`),
    (e.cosmosBlockedInGame = `gimkit-cosmos-blocked-in-game`),
    (e.hookSavedOptions = `gimkit-hook-saved-options`),
    e
  );
})({});
export { e as t };
