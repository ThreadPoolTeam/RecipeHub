import { o as e, t } from "./rolldown-runtime-C0FnF6B9.js";
import {
  C as n,
  E as r,
  O as i,
  Q as a,
  S as o,
  _ as s,
  c,
  s as l,
  t as u,
  u as d,
  v as f,
  w as p,
  y as m,
} from "./utils-CV9JYz4f.js";
import { t as h } from "./react-IpA8Qn9U.js";
import { c as g, s as _ } from "./assertThisInitialized-DqpgQyeg.js";
import {
  C as v,
  Dt as y,
  E as b,
  Et as x,
  Ft as S,
  H as C,
  Ht as w,
  It as T,
  J as E,
  Lt as D,
  Tt as O,
  Ut as k,
  Vt as A,
  X as j,
  Y as M,
  a as N,
  b as P,
  g as F,
  gt as I,
  ht as L,
  k as R,
  lt as z,
  m as ee,
  nt as te,
  r as ne,
  s as B,
  tt as re,
  ut as V,
  wt as ie,
  x as H,
  zt as ae,
} from "./Compact-CRRKXVA1.js";
import { h as oe, i as se, r as ce, v as U } from "./color-Dzrzfp-h.js";
import { t as le } from "./es-sgMnT67r.js";
import { r as ue, t as de } from "./compact-item-BOjQ1zv3.js";
import { E as fe, r as pe, t as me } from "./ContextIsolator-D7w7V6rn.js";
import { a as W } from "./InfoCircleFilled-C11bHdqb.js";
import { i as G, t as he } from "./useLocale-2b_qVRjr.js";
import { c as K, s as ge, t as _e } from "./tooltip-Yg3f8G0Q.js";
import { t as ve } from "./useCSSVarCls-7-ltqzGc.js";
import { t as ye } from "./pickAttrs-DgAKW8il.js";
import { t as be } from "./message-qrVed8Dv.js";
import { t as xe } from "./modal-Ch5Fwjpt.js";
import { t as q } from "./button-Cpfts2Ff.js";
import { r as Se, t as Ce } from "./dropdown-3sTYoCoX.js";
import { t as we } from "./move-2ruV_Z5Z.js";
import {
  a as Te,
  i as Ee,
  n as De,
  o as Oe,
  r as J,
  t as ke,
} from "./es-Bg8IQMoo.js";
import { t as Ae } from "./PurePanel-CIt2t_IW.js";
import { t as je } from "./es-C_Dx0dL1.js";
import { i as Me, n as Ne, r as Pe, t as Fe } from "./select-tq7TTR4P.js";
import {
  C as Ie,
  S as Le,
  _ as Re,
  b as ze,
  f as Be,
  h as Ve,
  t as He,
  u as Ue,
  v as We,
  y as Ge,
} from "./input-CWNNlK6u.js";
import { t as Ke } from "./useVariants-Bm4HVCER.js";
import { t as qe } from "./EllipsisOutlined-CafYbeLj.js";
import { t as Je } from "./advancedFormat-DNJVMZ_t.js";
import { n as Ye } from "./tabs-Db8OwWAd.js";
import { t as Xe } from "./card-BwiVPEuq.js";
import { t as Ze } from "./spin-DkTHPaic.js";
import { t as Qe } from "./input-number-BjcB2pmv.js";
import { n as $e, t as et } from "./ExportOutlined-C4fgI9G2.js";
import { n as tt, r as nt, t as rt } from "./fonts-luAVEHQ3.js";
import { t as it } from "./drawer-B0n6VOBn.js";
import { t as at } from "./space-CUvL4cnc.js";
import { s as ot, t as st } from "./Question-BtfeZosv.js";
import { t as ct } from "./DeleteOutlined-DtO1uPkf.js";
import { t as lt } from "./EditOutlined-kJy0G9DP.js";
import { t as ut } from "./StarOutlined-BsxCzDLq.js";
import { t as dt } from "./UsergroupAddOutlined-WbCtBwQw.js";
import { t as ft } from "./switch-WXDzZTE6.js";
import { t as pt } from "./copy-to-clipboard-CvKIjgDa.js";
import { n as mt } from "./Company-bnq9XEUn.js";
import { I as ht, r as gt } from "./Paths-3vkx8h28.js";
import { h as _t, p as vt } from "./decorate-DQbPZ5_K.js";
import { t as yt } from "./jsx-runtime-CA2T8_y1.js";
import { i as bt } from "./SiteHeaderAlpha-D4p9p3aq.js";
import { t as xt } from "./useQuery-CbbU5Ntf.js";
import {
  a as St,
  c as Ct,
  g as wt,
  l as Y,
  n as X,
  r as Tt,
  s as Et,
  u as Dt,
  y as Ot,
} from "./index-DG2EaUNY.js";
import { t as kt } from "./AccessibleAnchor-DBB6YL1z.js";
import { t as At } from "./Paper-vN6t0bnU.js";
import { r as jt } from "./mobxreact.esm-CES6mMUm.js";
import { t as Mt } from "./NavigateTo-CWRFhxPL.js";
import "./TrackPostHogEvent-CU1un-J8.js";
import { t as Nt } from "./TrackEvent-Bvi0Ap0t.js";
import { c as Pt, i as Ft, t as It } from "./price-Cqtaw0ya.js";
import { t as Lt } from "./CircularProgress-DQlkF5wx.js";
import { t as Rt } from "./lodash-QVF93A2Q.js";
import { t as zt } from "./motion-CBkcxAMn.js";
import { t as Bt } from "./MapModeType-uzcNbOsg.js";
import { t as Vt } from "./QuizTypes-BBn8sZp5.js";
import { t as Ht } from "./ImagePreview-C03s6d62.js";
import { t as Ut } from "./Sizes-BSTN-qyL.js";
import {
  a as Wt,
  c as Gt,
  i as Kt,
  l as qt,
  n as Jt,
  o as Yt,
  s as Xt,
} from "./App-CI2JVlDm.js";
import { t as Zt } from "./NotionContentWrapper-CZ6p4Ouf.js";
import {
  _ as Qt,
  a as $t,
  c as en,
  d as tn,
  f as nn,
  g as rn,
  h as an,
  m as on,
  p as sn,
  s as cn,
  t as ln,
  u as un,
} from "./App-DKZDTPiD.js";
import {
  a as dn,
  c as fn,
  i as pn,
  l as mn,
  o as hn,
  r as gn,
  s as _n,
  t as vn,
} from "./Codes-DqlrLYlG.js";
import { t as yn } from "./Hook-UdQWDyyy.js";
import { t as bn } from "./AppTypes-D0iU_NZ_.js";
import { t as xn } from "./InfiniteScroller-VKxO5ObD.js";
import { r as Sn } from "./RedirectToHomepage-Ban-t_MN.js";
var Cn = t((e, t) => {
    (function (n, r) {
      typeof e == `object` && t !== void 0
        ? (t.exports = r())
        : typeof define == `function` && define.amd
        ? define(r)
        : ((n =
            typeof globalThis < `u`
              ? globalThis
              : n || self).dayjs_plugin_weekday = r());
    })(e, function () {
      return function (e, t) {
        t.prototype.weekday = function (e) {
          var t = this.$locale().weekStart || 0,
            n = this.$W,
            r = (n < t ? n + 7 : n) - t;
          return this.$utils().u(e) ? r : this.subtract(r, `day`).add(e, `day`);
        };
      };
    });
  }),
  wn = t((e, t) => {
    (function (n, r) {
      typeof e == `object` && t !== void 0
        ? (t.exports = r())
        : typeof define == `function` && define.amd
        ? define(r)
        : ((n =
            typeof globalThis < `u`
              ? globalThis
              : n || self).dayjs_plugin_localeData = r());
    })(e, function () {
      return function (e, t, n) {
        var r = t.prototype,
          i = function (e) {
            return e && (e.indexOf ? e : e.s);
          },
          a = function (e, t, n, r, a) {
            var o = e.name ? e : e.$locale(),
              s = i(o[t]),
              c = i(o[n]),
              l =
                s ||
                c.map(function (e) {
                  return e.slice(0, r);
                });
            if (!a) return l;
            var u = o.weekStart;
            return l.map(function (e, t) {
              return l[(t + (u || 0)) % 7];
            });
          },
          o = function () {
            return n.Ls[n.locale()];
          },
          s = function (e, t) {
            return (
              e.formats[t] ||
              (function (e) {
                return e.replace(
                  /(\[[^\]]+])|(MMMM|MM|DD|dddd)/g,
                  function (e, t, n) {
                    return t || n.slice(1);
                  }
                );
              })(e.formats[t.toUpperCase()])
            );
          },
          c = function () {
            var e = this;
            return {
              months: function (t) {
                return t ? t.format(`MMMM`) : a(e, `months`);
              },
              monthsShort: function (t) {
                return t ? t.format(`MMM`) : a(e, `monthsShort`, `months`, 3);
              },
              firstDayOfWeek: function () {
                return e.$locale().weekStart || 0;
              },
              weekdays: function (t) {
                return t ? t.format(`dddd`) : a(e, `weekdays`);
              },
              weekdaysMin: function (t) {
                return t ? t.format(`dd`) : a(e, `weekdaysMin`, `weekdays`, 2);
              },
              weekdaysShort: function (t) {
                return t
                  ? t.format(`ddd`)
                  : a(e, `weekdaysShort`, `weekdays`, 3);
              },
              longDateFormat: function (t) {
                return s(e.$locale(), t);
              },
              meridiem: this.$locale().meridiem,
              ordinal: this.$locale().ordinal,
            };
          };
        (r.localeData = function () {
          return c.bind(this)();
        }),
          (n.localeData = function () {
            var e = o();
            return {
              firstDayOfWeek: function () {
                return e.weekStart || 0;
              },
              weekdays: function () {
                return n.weekdays();
              },
              weekdaysShort: function () {
                return n.weekdaysShort();
              },
              weekdaysMin: function () {
                return n.weekdaysMin();
              },
              months: function () {
                return n.months();
              },
              monthsShort: function () {
                return n.monthsShort();
              },
              longDateFormat: function (t) {
                return s(e, t);
              },
              meridiem: e.meridiem,
              ordinal: e.ordinal,
            };
          }),
          (n.months = function () {
            return a(o(), `months`);
          }),
          (n.monthsShort = function () {
            return a(o(), `monthsShort`, `months`, 3);
          }),
          (n.weekdays = function (e) {
            return a(o(), `weekdays`, null, null, e);
          }),
          (n.weekdaysShort = function (e) {
            return a(o(), `weekdaysShort`, `weekdays`, 3, e);
          }),
          (n.weekdaysMin = function (e) {
            return a(o(), `weekdaysMin`, `weekdays`, 2, e);
          });
      };
    });
  }),
  Tn = t((e, t) => {
    (function (n, r) {
      typeof e == `object` && t !== void 0
        ? (t.exports = r())
        : typeof define == `function` && define.amd
        ? define(r)
        : ((n =
            typeof globalThis < `u`
              ? globalThis
              : n || self).dayjs_plugin_weekOfYear = r());
    })(e, function () {
      var e = `week`,
        t = `year`;
      return function (n, r, i) {
        var a = r.prototype;
        (a.week = function (n) {
          if ((n === void 0 && (n = null), n !== null))
            return this.add(7 * (n - this.week()), `day`);
          var r = this.$locale().yearStart || 1;
          if (this.month() === 11 && this.date() > 25) {
            var a = i(this).startOf(t).add(1, t).date(r),
              o = i(this).endOf(e);
            if (a.isBefore(o)) return 1;
          }
          var s = i(this)
              .startOf(t)
              .date(r)
              .startOf(e)
              .subtract(1, `millisecond`),
            c = this.diff(s, e, !0);
          return c < 0 ? i(this).startOf(`week`).week() : Math.ceil(c);
        }),
          (a.weeks = function (e) {
            return e === void 0 && (e = null), this.week(e);
          });
      };
    });
  }),
  En = t((e, t) => {
    (function (n, r) {
      typeof e == `object` && t !== void 0
        ? (t.exports = r())
        : typeof define == `function` && define.amd
        ? define(r)
        : ((n =
            typeof globalThis < `u`
              ? globalThis
              : n || self).dayjs_plugin_weekYear = r());
    })(e, function () {
      return function (e, t) {
        t.prototype.weekYear = function () {
          var e = this.month(),
            t = this.week(),
            n = this.year();
          return t === 1 && e === 11 ? n + 1 : e === 0 && t >= 52 ? n - 1 : n;
        };
      };
    });
  }),
  Dn = t((e, t) => {
    (function (n, r) {
      typeof e == `object` && t !== void 0
        ? (t.exports = r())
        : typeof define == `function` && define.amd
        ? define(r)
        : ((n =
            typeof globalThis < `u`
              ? globalThis
              : n || self).dayjs_plugin_customParseFormat = r());
    })(e, function () {
      var e = {
          LTS: `h:mm:ss A`,
          LT: `h:mm A`,
          L: `MM/DD/YYYY`,
          LL: `MMMM D, YYYY`,
          LLL: `MMMM D, YYYY h:mm A`,
          LLLL: `dddd, MMMM D, YYYY h:mm A`,
        },
        t =
          /(\[[^[]*\])|([-_:/.,()\s]+)|(A|a|Q|YYYY|YY?|ww?|MM?M?M?|Do|DD?|hh?|HH?|mm?|ss?|S{1,3}|z|ZZ?)/g,
        n = /\d/,
        r = /\d\d/,
        i = /\d\d?/,
        a = /\d*[^-_:/,()\s\d]+/,
        o = {},
        s = function (e) {
          return (e = +e) + (e > 68 ? 1900 : 2e3);
        },
        c = function (e) {
          return function (t) {
            this[e] = +t;
          };
        },
        l = [
          /[+-]\d\d:?(\d\d)?|Z/,
          function (e) {
            (this.zone || (this.zone = {})).offset = (function (e) {
              if (!e || e === `Z`) return 0;
              var t = e.match(/([+-]|\d\d)/g),
                n = 60 * t[1] + (+t[2] || 0);
              return n === 0 ? 0 : t[0] === `+` ? -n : n;
            })(e);
          },
        ],
        u = function (e) {
          var t = o[e];
          return t && (t.indexOf ? t : t.s.concat(t.f));
        },
        d = function (e, t) {
          var n,
            r = o.meridiem;
          if (r) {
            for (var i = 1; i <= 24; i += 1)
              if (e.indexOf(r(i, 0, t)) > -1) {
                n = i > 12;
                break;
              }
          } else n = e === (t ? `pm` : `PM`);
          return n;
        },
        f = {
          A: [
            a,
            function (e) {
              this.afternoon = d(e, !1);
            },
          ],
          a: [
            a,
            function (e) {
              this.afternoon = d(e, !0);
            },
          ],
          Q: [
            n,
            function (e) {
              this.month = 3 * (e - 1) + 1;
            },
          ],
          S: [
            n,
            function (e) {
              this.milliseconds = 100 * e;
            },
          ],
          SS: [
            r,
            function (e) {
              this.milliseconds = 10 * e;
            },
          ],
          SSS: [
            /\d{3}/,
            function (e) {
              this.milliseconds = +e;
            },
          ],
          s: [i, c(`seconds`)],
          ss: [i, c(`seconds`)],
          m: [i, c(`minutes`)],
          mm: [i, c(`minutes`)],
          H: [i, c(`hours`)],
          h: [i, c(`hours`)],
          HH: [i, c(`hours`)],
          hh: [i, c(`hours`)],
          D: [i, c(`day`)],
          DD: [r, c(`day`)],
          Do: [
            a,
            function (e) {
              var t = o.ordinal,
                n = e.match(/\d+/);
              if (((this.day = n[0]), t))
                for (var r = 1; r <= 31; r += 1)
                  t(r).replace(/\[|\]/g, ``) === e && (this.day = r);
            },
          ],
          w: [i, c(`week`)],
          ww: [r, c(`week`)],
          M: [i, c(`month`)],
          MM: [r, c(`month`)],
          MMM: [
            a,
            function (e) {
              var t = u(`months`),
                n =
                  (
                    u(`monthsShort`) ||
                    t.map(function (e) {
                      return e.slice(0, 3);
                    })
                  ).indexOf(e) + 1;
              if (n < 1) throw Error();
              this.month = n % 12 || n;
            },
          ],
          MMMM: [
            a,
            function (e) {
              var t = u(`months`).indexOf(e) + 1;
              if (t < 1) throw Error();
              this.month = t % 12 || t;
            },
          ],
          Y: [/[+-]?\d+/, c(`year`)],
          YY: [
            r,
            function (e) {
              this.year = s(e);
            },
          ],
          YYYY: [/\d{4}/, c(`year`)],
          Z: l,
          ZZ: l,
        };
      function p(n) {
        for (
          var r = n,
            i = o && o.formats,
            a = (n = r.replace(
              /(\[[^\]]+])|(LTS?|l{1,4}|L{1,4})/g,
              function (t, n, r) {
                var a = r && r.toUpperCase();
                return (
                  n ||
                  i[r] ||
                  e[r] ||
                  i[a].replace(
                    /(\[[^\]]+])|(MMMM|MM|DD|dddd)/g,
                    function (e, t, n) {
                      return t || n.slice(1);
                    }
                  )
                );
              }
            )).match(t),
            s = a.length,
            c = 0;
          c < s;
          c += 1
        ) {
          var l = a[c],
            u = f[l],
            d = u && u[0],
            p = u && u[1];
          a[c] = p ? { regex: d, parser: p } : l.replace(/^\[|\]$/g, ``);
        }
        return function (e) {
          for (var t = {}, n = 0, r = 0; n < s; n += 1) {
            var i = a[n];
            if (typeof i == `string`) r += i.length;
            else {
              var o = i.regex,
                c = i.parser,
                l = e.slice(r),
                u = o.exec(l)[0];
              c.call(t, u), (e = e.replace(u, ``));
            }
          }
          return (
            (function (e) {
              var t = e.afternoon;
              if (t !== void 0) {
                var n = e.hours;
                t ? n < 12 && (e.hours += 12) : n === 12 && (e.hours = 0),
                  delete e.afternoon;
              }
            })(t),
            t
          );
        };
      }
      return function (e, t, n) {
        (n.p.customParseFormat = !0),
          e && e.parseTwoDigitYear && (s = e.parseTwoDigitYear);
        var r = t.prototype,
          i = r.parse;
        r.parse = function (e) {
          var t = e.date,
            r = e.utc,
            a = e.args;
          this.$u = r;
          var s = a[1];
          if (typeof s == `string`) {
            var c = !0 === a[2],
              l = !0 === a[3],
              u = c || l,
              d = a[2];
            l && (d = a[2]),
              (o = this.$locale()),
              !c && d && (o = n.Ls[d]),
              (this.$d = (function (e, t, n, r) {
                try {
                  if ([`x`, `X`].indexOf(t) > -1)
                    return new Date((t === `X` ? 1e3 : 1) * e);
                  var i = p(t)(e),
                    a = i.year,
                    o = i.month,
                    s = i.day,
                    c = i.hours,
                    l = i.minutes,
                    u = i.seconds,
                    d = i.milliseconds,
                    f = i.zone,
                    m = i.week,
                    h = new Date(),
                    g = s || (a || o ? 1 : h.getDate()),
                    _ = a || h.getFullYear(),
                    v = 0;
                  (a && !o) || (v = o > 0 ? o - 1 : h.getMonth());
                  var y,
                    b = c || 0,
                    x = l || 0,
                    S = u || 0,
                    C = d || 0;
                  return f
                    ? new Date(
                        Date.UTC(_, v, g, b, x, S, C + 60 * f.offset * 1e3)
                      )
                    : n
                    ? new Date(Date.UTC(_, v, g, b, x, S, C))
                    : ((y = new Date(_, v, g, b, x, S, C)),
                      m && (y = r(y).week(m).toDate()),
                      y);
                } catch {
                  return new Date(``);
                }
              })(t, s, r, n)),
              this.init(),
              d && !0 !== d && (this.$L = this.locale(d).$L),
              u && t != this.format(s) && (this.$d = new Date(``)),
              (o = {});
          } else if (s instanceof Array)
            for (var f = s.length, m = 1; m <= f; m += 1) {
              a[1] = s[m - 1];
              var h = n.apply(this, a);
              if (h.isValid()) {
                (this.$d = h.$d), (this.$L = h.$L), this.init();
                break;
              }
              m === f && (this.$d = new Date(``));
            }
          else i.call(this, e);
        };
      };
    });
  }),
  On = e(a()),
  kn = e(Cn()),
  An = e(wn()),
  jn = e(Tn()),
  Mn = e(En()),
  Nn = e(Je()),
  Pn = e(Dn());
On.default.extend(Pn.default),
  On.default.extend(Nn.default),
  On.default.extend(kn.default),
  On.default.extend(An.default),
  On.default.extend(jn.default),
  On.default.extend(Mn.default),
  On.default.extend(function (e, t) {
    var n = t.prototype,
      r = n.format;
    n.format = function (e) {
      var t = (e || ``).replace(`Wo`, `wo`);
      return r.bind(this)(t);
    };
  });
var Fn = {
    bn_BD: `bn-bd`,
    by_BY: `be`,
    en_GB: `en-gb`,
    en_US: `en`,
    fr_BE: `fr`,
    fr_CA: `fr-ca`,
    hy_AM: `hy-am`,
    kmr_IQ: `ku`,
    nl_BE: `nl-be`,
    pt_BR: `pt-br`,
    zh_CN: `zh-cn`,
    zh_HK: `zh-hk`,
    zh_TW: `zh-tw`,
  },
  In = function (e) {
    return Fn[e] || e.split(`_`)[0];
  },
  Ln = {
    getNow: function () {
      var e = (0, On.default)();
      return typeof e.tz == `function` ? e.tz() : e;
    },
    getFixedDate: function (e) {
      return (0, On.default)(e, [`YYYY-M-DD`, `YYYY-MM-DD`]);
    },
    getEndDate: function (e) {
      return e.endOf(`month`);
    },
    getWeekDay: function (e) {
      var t = e.locale(`en`);
      return t.weekday() + t.localeData().firstDayOfWeek();
    },
    getYear: function (e) {
      return e.year();
    },
    getMonth: function (e) {
      return e.month();
    },
    getDate: function (e) {
      return e.date();
    },
    getHour: function (e) {
      return e.hour();
    },
    getMinute: function (e) {
      return e.minute();
    },
    getSecond: function (e) {
      return e.second();
    },
    getMillisecond: function (e) {
      return e.millisecond();
    },
    addYear: function (e, t) {
      return e.add(t, `year`);
    },
    addMonth: function (e, t) {
      return e.add(t, `month`);
    },
    addDate: function (e, t) {
      return e.add(t, `day`);
    },
    setYear: function (e, t) {
      return e.year(t);
    },
    setMonth: function (e, t) {
      return e.month(t);
    },
    setDate: function (e, t) {
      return e.date(t);
    },
    setHour: function (e, t) {
      return e.hour(t);
    },
    setMinute: function (e, t) {
      return e.minute(t);
    },
    setSecond: function (e, t) {
      return e.second(t);
    },
    setMillisecond: function (e, t) {
      return e.millisecond(t);
    },
    isAfter: function (e, t) {
      return e.isAfter(t);
    },
    isValidate: function (e) {
      return e.isValid();
    },
    locale: {
      getWeekFirstDay: function (e) {
        return (0, On.default)().locale(In(e)).localeData().firstDayOfWeek();
      },
      getWeekFirstDate: function (e, t) {
        return t.locale(In(e)).weekday(0);
      },
      getWeek: function (e, t) {
        return t.locale(In(e)).week();
      },
      getShortWeekDays: function (e) {
        return (0, On.default)().locale(In(e)).localeData().weekdaysMin();
      },
      getShortMonths: function (e) {
        return (0, On.default)().locale(In(e)).localeData().monthsShort();
      },
      format: function (e, t, n) {
        return t.locale(In(e)).format(n);
      },
      parse: function (e, t, n) {
        for (var r = In(e), i = 0; i < n.length; i += 1) {
          var a = n[i],
            o = t;
          if (a.includes(`wo`) || a.includes(`Wo`)) {
            for (
              var s = o.split(`-`)[0],
                c = o.split(`-`)[1],
                l = (0, On.default)(s, `YYYY`).startOf(`year`).locale(r),
                u = 0;
              u <= 52;
              u += 1
            ) {
              var d = l.add(u, `week`);
              if (d.format(`Wo`) === c) return d;
            }
            return null;
          }
          var f = (0, On.default)(o, a, !0).locale(r);
          if (f.isValid()) return f;
        }
        return null;
      },
    },
  },
  Z = e(h()),
  Q = e(k());
g(), D(), I(), V();
function Rn(e, t) {
  return e === void 0 ? (t ? `bottomRight` : `bottomLeft`) : e;
}
var zn = Z.createContext(null),
  Bn = {
    bottomLeft: {
      points: [`tl`, `bl`],
      offset: [0, 4],
      overflow: { adjustX: 1, adjustY: 1 },
    },
    bottomRight: {
      points: [`tr`, `br`],
      offset: [0, 4],
      overflow: { adjustX: 1, adjustY: 1 },
    },
    topLeft: {
      points: [`bl`, `tl`],
      offset: [0, -4],
      overflow: { adjustX: 0, adjustY: 1 },
    },
    topRight: {
      points: [`br`, `tr`],
      offset: [0, -4],
      overflow: { adjustX: 0, adjustY: 1 },
    },
  };
function Vn(e) {
  var t = e.popupElement,
    n = e.popupStyle,
    r = e.popupClassName,
    i = e.popupAlign,
    a = e.transitionName,
    o = e.getPopupContainer,
    s = e.children,
    c = e.range,
    l = e.placement,
    u = e.builtinPlacements,
    d = u === void 0 ? Bn : u,
    f = e.direction,
    p = e.visible,
    m = e.onClose,
    h = `${Z.useContext(zn).prefixCls}-dropdown`,
    g = Rn(l, f === `rtl`);
  return Z.createElement(
    je,
    {
      showAction: [],
      hideAction: [`click`],
      popupPlacement: g,
      builtinPlacements: d,
      prefixCls: h,
      popupTransitionName: a,
      popup: t,
      popupAlign: i,
      popupVisible: p,
      popupClassName: (0, Q.default)(
        r,
        T(T({}, `${h}-range`, c), `${h}-rtl`, f === `rtl`)
      ),
      popupStyle: n,
      stretch: `minWidth`,
      getPopupContainer: o,
      onPopupVisibleChange: function (e) {
        e || m();
      },
    },
    s
  );
}
function Hn(e, t) {
  for (
    var n =
        arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : `0`,
      r = String(e);
    r.length < t;

  )
    r = `${n}${r}`;
  return r;
}
function Un(e) {
  return e == null ? [] : Array.isArray(e) ? e : [e];
}
function Wn(e, t, n) {
  var r = L(e);
  return (r[t] = n), r;
}
function Gn(e, t) {
  var n = {};
  return (
    (t || Object.keys(e)).forEach(function (t) {
      e[t] !== void 0 && (n[t] = e[t]);
    }),
    n
  );
}
function Kn(e, t, n) {
  if (n) return n;
  switch (e) {
    case `time`:
      return t.fieldTimeFormat;
    case `datetime`:
      return t.fieldDateTimeFormat;
    case `month`:
      return t.fieldMonthFormat;
    case `year`:
      return t.fieldYearFormat;
    case `quarter`:
      return t.fieldQuarterFormat;
    case `week`:
      return t.fieldWeekFormat;
    default:
      return t.fieldDateFormat;
  }
}
function qn(e, t, n) {
  var r = n === void 0 ? t[t.length - 1] : n,
    i = t.find(function (t) {
      return e[t];
    });
  return r === i ? void 0 : e[i];
}
function Jn(e) {
  return Gn(e, [
    `placement`,
    `builtinPlacements`,
    `popupAlign`,
    `getPopupContainer`,
    `transitionName`,
    `direction`,
  ]);
}
function Yn(e, t, n, r) {
  var i = Z.useMemo(
    function () {
      return (
        e ||
        function (e, r) {
          var i = e;
          return t && r.type === `date`
            ? t(i, r.today)
            : n && r.type === `month`
            ? n(i, r.locale)
            : r.originNode;
        }
      );
    },
    [e, n, t]
  );
  return Z.useCallback(
    function (e, t) {
      return i(e, S(S({}, t), {}, { range: r }));
    },
    [i, r]
  );
}
function Xn(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [],
    r = Z.useState([!1, !1]),
    i = z(r, 2),
    a = i[0],
    o = i[1];
  return [
    Z.useMemo(
      function () {
        return a.map(function (r, i) {
          if (r) return !0;
          var a = e[i];
          return a ? !!((!n[i] && !a) || (a && t(a, { activeIndex: i }))) : !1;
        });
      },
      [e, a, t, n]
    ),
    function (e, t) {
      o(function (n) {
        return Wn(n, t, e);
      });
    },
  ];
}
function Zn(e, t, n, r, i) {
  var a = ``,
    o = [];
  return (
    e && o.push(i ? `hh` : `HH`),
    t && o.push(`mm`),
    n && o.push(`ss`),
    (a = o.join(`:`)),
    r && (a += `.SSS`),
    i && (a += ` A`),
    a
  );
}
function Qn(e, t, n, r, i, a) {
  var o = e.fieldDateTimeFormat,
    s = e.fieldDateFormat,
    c = e.fieldTimeFormat,
    l = e.fieldMonthFormat,
    u = e.fieldYearFormat,
    d = e.fieldWeekFormat,
    f = e.fieldQuarterFormat,
    p = e.yearFormat,
    m = e.cellYearFormat,
    h = e.cellQuarterFormat,
    g = e.dayFormat,
    _ = e.cellDateFormat,
    v = Zn(t, n, r, i, a);
  return S(
    S({}, e),
    {},
    {
      fieldDateTimeFormat: o || `YYYY-MM-DD ${v}`,
      fieldDateFormat: s || `YYYY-MM-DD`,
      fieldTimeFormat: c || v,
      fieldMonthFormat: l || `YYYY-MM`,
      fieldYearFormat: u || `YYYY`,
      fieldWeekFormat: d || `gggg-wo`,
      fieldQuarterFormat: f || `YYYY-[Q]Q`,
      yearFormat: p || `YYYY`,
      cellYearFormat: m || `YYYY`,
      cellQuarterFormat: h || `[Q]Q`,
      cellDateFormat: _ || g || `D`,
    }
  );
}
function $n(e, t) {
  var n = t.showHour,
    r = t.showMinute,
    i = t.showSecond,
    a = t.showMillisecond,
    o = t.use12Hours;
  return Z.useMemo(
    function () {
      return Qn(e, n, r, i, a, o);
    },
    [e, n, r, i, a, o]
  );
}
V(), w();
function er(e, t, n) {
  return (
    n ??
    t.some(function (t) {
      return e.includes(t);
    })
  );
}
var tr = [
  `showNow`,
  `showHour`,
  `showMinute`,
  `showSecond`,
  `showMillisecond`,
  `use12Hours`,
  `hourStep`,
  `minuteStep`,
  `secondStep`,
  `millisecondStep`,
  `hideDisabledOptions`,
  `defaultValue`,
  `disabledHours`,
  `disabledMinutes`,
  `disabledSeconds`,
  `disabledMilliseconds`,
  `disabledTime`,
  `changeOnScroll`,
  `defaultOpenValue`,
];
function nr(e) {
  var t = Gn(e, tr),
    n = e.format,
    r = e.picker,
    i = null;
  return (
    n &&
      ((i = n),
      Array.isArray(i) && (i = i[0]),
      (i = A(i) === `object` ? i.format : i)),
    r === `time` && (t.format = i),
    [t, i]
  );
}
function rr(e) {
  return e && typeof e == `string`;
}
function ir(e, t, n, r) {
  return [e, t, n, r].some(function (e) {
    return e !== void 0;
  });
}
function ar(e, t, n, r, i) {
  var a = t,
    o = n,
    s = r;
  if (!e && !a && !o && !s && !i) (a = !0), (o = !0), (s = !0);
  else if (e) {
    var c = [a, o, s].some(function (e) {
        return e === !1;
      }),
      l = [a, o, s].some(function (e) {
        return e === !0;
      }),
      u = c ? !0 : !l;
    (a = a ?? u), (o = o ?? u), (s = s ?? u);
  }
  return [a, o, s, i];
}
function or(e) {
  var t = e.showTime,
    n = nr(e),
    r = z(n, 2),
    i = r[0],
    a = r[1],
    o = t && A(t) === `object` ? t : {},
    s = S(S({ defaultOpenValue: o.defaultOpenValue || o.defaultValue }, i), o),
    c = s.showMillisecond,
    l = s.showHour,
    u = s.showMinute,
    d = s.showSecond,
    f = ar(ir(l, u, d, c), l, u, d, c),
    p = z(f, 3);
  return (
    (l = p[0]),
    (u = p[1]),
    (d = p[2]),
    [
      s,
      S(
        S({}, s),
        {},
        { showHour: l, showMinute: u, showSecond: d, showMillisecond: c }
      ),
      s.format,
      a,
    ]
  );
}
function sr(e, t, n, r, i) {
  if (e === `datetime` || e === `time`) {
    for (
      var a = r, o = Kn(e, i, null), s = [t, n], c = 0;
      c < s.length;
      c += 1
    ) {
      var l = Un(s[c])[0];
      if (rr(l)) {
        o = l;
        break;
      }
    }
    var u = a.showHour,
      d = a.showMinute,
      f = a.showSecond,
      p = a.showMillisecond,
      m = a.use12Hours,
      h = er(o, [`a`, `A`, `LT`, `LLL`, `LTS`], m),
      g = ir(u, d, f, p);
    g ||
      ((u = er(o, [`H`, `h`, `k`, `LT`, `LLL`])),
      (d = er(o, [`m`, `LT`, `LLL`])),
      (f = er(o, [`s`, `LTS`])),
      (p = er(o, [`SSS`])));
    var _ = ar(g, u, d, f, p),
      v = z(_, 3);
    (u = v[0]), (d = v[1]), (f = v[2]);
    var y = t || Zn(u, d, f, p, h);
    return S(
      S({}, a),
      {},
      {
        format: y,
        showHour: u,
        showMinute: d,
        showSecond: f,
        showMillisecond: p,
        use12Hours: h,
      }
    );
  }
  return null;
}
w();
function cr(e, t, n) {
  return t === !1
    ? null
    : (t && A(t) === `object` ? t : {}).clearIcon ||
        n ||
        Z.createElement(`span`, { className: `${e}-clear-btn` });
}
function lr(e, t, n) {
  return (!e && !t) || e === t ? !0 : !e || !t ? !1 : n();
}
function ur(e, t, n) {
  return lr(t, n, function () {
    return Math.floor(e.getYear(t) / 10) === Math.floor(e.getYear(n) / 10);
  });
}
function dr(e, t, n) {
  return lr(t, n, function () {
    return e.getYear(t) === e.getYear(n);
  });
}
function fr(e, t) {
  return Math.floor(e.getMonth(t) / 3) + 1;
}
function pr(e, t, n) {
  return lr(t, n, function () {
    return dr(e, t, n) && fr(e, t) === fr(e, n);
  });
}
function mr(e, t, n) {
  return lr(t, n, function () {
    return dr(e, t, n) && e.getMonth(t) === e.getMonth(n);
  });
}
function hr(e, t, n) {
  return lr(t, n, function () {
    return dr(e, t, n) && mr(e, t, n) && e.getDate(t) === e.getDate(n);
  });
}
function gr(e, t, n) {
  return lr(t, n, function () {
    return (
      e.getHour(t) === e.getHour(n) &&
      e.getMinute(t) === e.getMinute(n) &&
      e.getSecond(t) === e.getSecond(n)
    );
  });
}
function _r(e, t, n) {
  return lr(t, n, function () {
    return (
      hr(e, t, n) && gr(e, t, n) && e.getMillisecond(t) === e.getMillisecond(n)
    );
  });
}
function vr(e, t, n, r) {
  return lr(n, r, function () {
    return (
      dr(e, e.locale.getWeekFirstDate(t, n), e.locale.getWeekFirstDate(t, r)) &&
      e.locale.getWeek(t, n) === e.locale.getWeek(t, r)
    );
  });
}
function yr(e, t, n, r, i) {
  switch (i) {
    case `date`:
      return hr(e, n, r);
    case `week`:
      return vr(e, t.locale, n, r);
    case `month`:
      return mr(e, n, r);
    case `quarter`:
      return pr(e, n, r);
    case `year`:
      return dr(e, n, r);
    case `decade`:
      return ur(e, n, r);
    case `time`:
      return gr(e, n, r);
    default:
      return _r(e, n, r);
  }
}
function br(e, t, n, r) {
  return !t || !n || !r ? !1 : e.isAfter(r, t) && e.isAfter(n, r);
}
function xr(e, t, n, r, i) {
  return yr(e, t, n, r, i) ? !0 : e.isAfter(n, r);
}
function Sr(e, t, n) {
  var r = t.locale.getWeekFirstDay(e),
    i = t.setDate(n, 1),
    a = t.getWeekDay(i),
    o = t.addDate(i, r - a);
  return (
    t.getMonth(o) === t.getMonth(n) &&
      t.getDate(o) > 1 &&
      (o = t.addDate(o, -7)),
    o
  );
}
function Cr(e, t) {
  var n = t.generateConfig,
    r = t.locale,
    i = t.format;
  return e
    ? typeof i == `function`
      ? i(e)
      : n.locale.format(r.locale, e, i)
    : ``;
}
function wr(e, t, n) {
  var r = t,
    i = [`getHour`, `getMinute`, `getSecond`, `getMillisecond`];
  return (
    [`setHour`, `setMinute`, `setSecond`, `setMillisecond`].forEach(function (
      t,
      a
    ) {
      r = n ? e[t](r, e[i[a]](n)) : e[t](r, 0);
    }),
    r
  );
}
function Tr(e, t, n, r, i) {
  return v(function (a, o) {
    return !!(
      (n && n(a, o)) ||
      (r && e.isAfter(r, a) && !yr(e, t, r, a, o.type)) ||
      (i && e.isAfter(a, i) && !yr(e, t, i, a, o.type))
    );
  });
}
w();
function Er(e, t, n) {
  return Z.useMemo(
    function () {
      var r = Un(Kn(e, t, n)),
        i = r[0],
        a = A(i) === `object` && i.type === `mask` ? i.format : null;
      return [
        r.map(function (e) {
          return typeof e == `string` || typeof e == `function` ? e : e.format;
        }),
        a,
      ];
    },
    [e, t, n]
  );
}
function Dr(e, t, n) {
  return typeof e[0] == `function` || n ? !0 : t;
}
function Or(e, t, n, r) {
  return v(function (i, a) {
    var o = S({ type: t }, a);
    if ((delete o.activeIndex, !e.isValidate(i) || (n && n(i, o)))) return !0;
    if ((t === `date` || t === `time`) && r) {
      var s,
        c = a && a.activeIndex === 1 ? `end` : `start`,
        l =
          ((s = r.disabledTime) == null
            ? void 0
            : s.call(r, i, c, { from: o.from })) || {},
        u = l.disabledHours,
        d = l.disabledMinutes,
        f = l.disabledSeconds,
        p = l.disabledMilliseconds,
        m = r.disabledHours,
        h = r.disabledMinutes,
        g = r.disabledSeconds,
        _ = u || m,
        v = d || h,
        y = f || g,
        b = e.getHour(i),
        x = e.getMinute(i),
        C = e.getSecond(i),
        w = e.getMillisecond(i);
      if (
        (_ && _().includes(b)) ||
        (v && v(b).includes(x)) ||
        (y && y(b, x).includes(C)) ||
        (p && p(b, x, C).includes(w))
      )
        return !0;
    }
    return !1;
  });
}
V();
function kr(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
  return Z.useMemo(
    function () {
      var n = e && Un(e);
      return t && n && (n[1] = n[1] || n[0]), n;
    },
    [e, t]
  );
}
function Ar(e, t) {
  var n = e.generateConfig,
    r = e.locale,
    i = e.picker,
    a = i === void 0 ? `date` : i,
    o = e.prefixCls,
    s = o === void 0 ? `rc-picker` : o,
    c = e.styles,
    l = c === void 0 ? {} : c,
    u = e.classNames,
    d = u === void 0 ? {} : u,
    f = e.order,
    p = f === void 0 || f,
    m = e.components,
    h = m === void 0 ? {} : m,
    g = e.inputRender,
    _ = e.allowClear,
    v = e.clearIcon,
    y = e.needConfirm,
    b = e.multiple,
    x = e.format,
    C = e.inputReadOnly,
    w = e.disabledDate,
    T = e.minDate,
    E = e.maxDate,
    D = e.showTime,
    O = e.value,
    k = e.defaultValue,
    A = e.pickerValue,
    j = e.defaultPickerValue,
    M = kr(O),
    N = kr(k),
    P = kr(A),
    F = kr(j),
    I = a === `date` && D ? `datetime` : a,
    L = I === `time` || I === `datetime`,
    R = L || b,
    ee = y ?? L,
    te = or(e),
    ne = z(te, 4),
    B = ne[0],
    re = ne[1],
    V = ne[2],
    ie = ne[3],
    H = $n(r, re),
    ae = Z.useMemo(
      function () {
        return sr(I, V, ie, B, H);
      },
      [I, V, ie, B, H]
    ),
    oe = Z.useMemo(
      function () {
        return S(
          S({}, e),
          {},
          {
            prefixCls: s,
            locale: H,
            picker: a,
            styles: l,
            classNames: d,
            order: p,
            components: S({ input: g }, h),
            clearIcon: cr(s, _, v),
            showTime: ae,
            value: M,
            defaultValue: N,
            pickerValue: P,
            defaultPickerValue: F,
          },
          t == null ? void 0 : t()
        );
      },
      [e]
    ),
    se = Er(I, H, x),
    ce = z(se, 2),
    U = ce[0],
    le = ce[1],
    ue = Dr(U, C, b),
    de = Tr(n, r, w, T, E),
    fe = Or(n, a, de, ae);
  return [
    Z.useMemo(
      function () {
        return S(
          S({}, oe),
          {},
          { needConfirm: ee, inputReadOnly: ue, disabledDate: de }
        );
      },
      [oe, ee, ue, de]
    ),
    I,
    R,
    U,
    le,
    fe,
  ];
}
V();
function jr(e, t, n) {
  var r = H(t, { value: e }),
    i = z(r, 2),
    a = i[0],
    o = i[1],
    s = Z.useRef(e),
    c = Z.useRef(),
    l = function () {
      U.cancel(c.current);
    },
    u = v(function () {
      o(s.current), n && a !== s.current && n(s.current);
    }),
    d = v(function (e, t) {
      l(), (s.current = e), e || t ? u() : (c.current = U(u));
    });
  return (
    Z.useEffect(function () {
      return l;
    }, []),
    [a, d]
  );
}
V();
function Mr(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [],
    r = arguments.length > 3 ? arguments[3] : void 0,
    i = jr(
      !n.every(function (e) {
        return e;
      }) && e,
      t || !1,
      r
    ),
    a = z(i, 2),
    o = a[0],
    s = a[1];
  function c(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    (!t.inherit || o) && s(e, t.force);
  }
  return [o, c];
}
function Nr(e) {
  var t = Z.useRef();
  return (
    Z.useImperativeHandle(e, function () {
      var e;
      return {
        nativeElement: (e = t.current) == null ? void 0 : e.nativeElement,
        focus: function (e) {
          var n;
          (n = t.current) == null || n.focus(e);
        },
        blur: function () {
          var e;
          (e = t.current) == null || e.blur();
        },
      };
    }),
    t
  );
}
V();
function Pr(e, t) {
  return Z.useMemo(
    function () {
      return (
        e ||
        (t
          ? (ae(!1, "`ranges` is deprecated. Please use `presets` instead."),
            Object.entries(t).map(function (e) {
              var t = z(e, 2);
              return { label: t[0], value: t[1] };
            }))
          : [])
      );
    },
    [e, t]
  );
}
function Fr(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1,
    r = Z.useRef(t);
  (r.current = t),
    M(
      function () {
        if (e) r.current(e);
        else {
          var t = U(function () {
            r.current(e);
          }, n);
          return function () {
            U.cancel(t);
          };
        }
      },
      [e]
    );
}
V();
function Ir(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [],
    n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2],
    r = Z.useState(0),
    i = z(r, 2),
    a = i[0],
    o = i[1],
    s = Z.useState(!1),
    c = z(s, 2),
    l = c[0],
    u = c[1],
    d = Z.useRef([]),
    f = Z.useRef(null),
    p = Z.useRef(null),
    m = function (e) {
      f.current = e;
    };
  return (
    Fr(l || n, function () {
      l || ((d.current = []), m(null));
    }),
    Z.useEffect(
      function () {
        l && d.current.push(a);
      },
      [l, a]
    ),
    [
      l,
      function (e) {
        u(e);
      },
      function (e) {
        return e && (p.current = e), p.current;
      },
      a,
      o,
      function (n) {
        var r = d.current,
          i = new Set(
            r.filter(function (e) {
              return n[e] || t[e];
            })
          ),
          a = +(r[r.length - 1] === 0);
        return i.size >= 2 || e[a] ? null : a;
      },
      d.current,
      m,
      function (e) {
        return f.current === e;
      },
    ]
  );
}
V();
function Lr(e, t, n, r, i, a) {
  var o = n[n.length - 1];
  return function (s, c) {
    var l = z(e, 2),
      u = l[0],
      d = l[1],
      f = S(S({}, c), {}, { from: qn(e, n) });
    return (o === 1 &&
      t[0] &&
      u &&
      !yr(r, i, u, s, f.type) &&
      r.isAfter(u, s)) ||
      (o === 0 && t[1] && d && !yr(r, i, d, s, f.type) && r.isAfter(s, d))
      ? !0
      : a == null
      ? void 0
      : a(s, f);
  };
}
V();
function Rr(e, t, n, r) {
  switch (t) {
    case `date`:
    case `week`:
      return e.addMonth(n, r);
    case `month`:
    case `quarter`:
      return e.addYear(n, r);
    case `year`:
      return e.addYear(n, r * 10);
    case `decade`:
      return e.addYear(n, r * 100);
    default:
      return n;
  }
}
var zr = [];
function Br(e, t, n, r, i, a, o, s) {
  var c = arguments.length > 8 && arguments[8] !== void 0 ? arguments[8] : zr,
    l = arguments.length > 9 && arguments[9] !== void 0 ? arguments[9] : zr,
    u = arguments.length > 10 && arguments[10] !== void 0 ? arguments[10] : zr,
    d = arguments.length > 11 ? arguments[11] : void 0,
    f = arguments.length > 12 ? arguments[12] : void 0,
    p = arguments.length > 13 ? arguments[13] : void 0,
    m = o === `time`,
    h = a || 0,
    g = function (t) {
      var r = e.getNow();
      return m && (r = wr(e, r)), c[t] || n[t] || r;
    },
    _ = z(l, 2),
    v = _[0],
    y = _[1],
    b = H(
      function () {
        return g(0);
      },
      { value: v }
    ),
    x = z(b, 2),
    S = x[0],
    C = x[1],
    w = H(
      function () {
        return g(1);
      },
      { value: y }
    ),
    T = z(w, 2),
    D = T[0],
    O = T[1],
    k = Z.useMemo(
      function () {
        var t = [S, D][h];
        return m ? t : wr(e, t, u[h]);
      },
      [m, S, D, h, e, u]
    ),
    A = function (n) {
      var i =
          arguments.length > 1 && arguments[1] !== void 0
            ? arguments[1]
            : `panel`,
        a = [C, O][h];
      a(n);
      var s = [S, D];
      (s[h] = n),
        d &&
          (!yr(e, t, S, s[0], o) || !yr(e, t, D, s[1], o)) &&
          d(s, { source: i, range: h === 1 ? `end` : `start`, mode: r });
    },
    j = function (n, r) {
      if (s) {
        var i = {
          date: `month`,
          week: `month`,
          month: `year`,
          quarter: `year`,
        }[o];
        if (
          (i && !yr(e, t, n, r, i)) ||
          (o === `year` &&
            n &&
            Math.floor(e.getYear(n) / 10) !== Math.floor(e.getYear(r) / 10))
        )
          return Rr(e, o, r, -1);
      }
      return r;
    },
    M = Z.useRef(null);
  return (
    E(
      function () {
        if (i && !c[h]) {
          var t = m ? null : e.getNow();
          if (
            (M.current !== null && M.current !== h
              ? (t = [S, D][h ^ 1])
              : n[h]
              ? (t = h === 0 ? n[0] : j(n[0], n[1]))
              : n[h ^ 1] && (t = n[h ^ 1]),
            t)
          ) {
            f && e.isAfter(f, t) && (t = f);
            var r = s ? Rr(e, o, t, 1) : t;
            p && e.isAfter(r, p) && (t = s ? Rr(e, o, p, -1) : p),
              A(t, `reset`);
          }
        }
      },
      [i, h, n[h]]
    ),
    Z.useEffect(
      function () {
        M.current = i ? h : null;
      },
      [i, h]
    ),
    E(
      function () {
        i && c && c[h] && A(c[h], `reset`);
      },
      [i, h]
    ),
    [k, A]
  );
}
V();
function Vr(e, t) {
  var n = Z.useRef(e),
    r = Z.useState({}),
    i = z(r, 2)[1],
    a = function (e) {
      return e && t !== void 0 ? t : n.current;
    };
  return [
    a,
    function (e) {
      (n.current = e), i({});
    },
    a(!0),
  ];
}
V(), I();
var Hr = [];
function Ur(e, t, n) {
  return [
    function (r) {
      return r.map(function (r) {
        return Cr(r, { generateConfig: e, locale: t, format: n[0] });
      });
    },
    function (t, n) {
      for (var r = Math.max(t.length, n.length), i = -1, a = 0; a < r; a += 1) {
        var o = t[a] || null,
          s = n[a] || null;
        if (o !== s && !_r(e, o, s)) {
          i = a;
          break;
        }
      }
      return [i < 0, i !== 0];
    },
  ];
}
function Wr(e, t) {
  return L(e).sort(function (e, n) {
    return t.isAfter(e, n) ? 1 : -1;
  });
}
function Gr(e) {
  var t = Vr(e),
    n = z(t, 2),
    r = n[0],
    i = n[1],
    a = v(function () {
      i(e);
    });
  return (
    Z.useEffect(
      function () {
        a();
      },
      [e]
    ),
    [r, i]
  );
}
function Kr(e, t, n, r, i, a, o, s, c) {
  var l = H(a, { value: o }),
    u = z(l, 2),
    d = u[0],
    f = u[1],
    p = d || Hr,
    m = Gr(p),
    h = z(m, 2),
    g = h[0],
    _ = h[1],
    y = Ur(e, t, n),
    b = z(y, 2),
    x = b[0],
    S = b[1];
  return [
    p,
    f,
    g,
    v(function (t) {
      var n = L(t);
      if (r) for (var a = 0; a < 2; a += 1) n[a] = n[a] || null;
      else
        i &&
          (n = Wr(
            n.filter(function (e) {
              return e;
            }),
            e
          ));
      var o = S(g(), n),
        c = z(o, 2),
        l = c[0],
        u = c[1];
      if (!l && (_(n), s)) {
        var d = x(n);
        s(n, d, { range: u ? `end` : `start` });
      }
    }),
    function () {
      c && c(g());
    },
  ];
}
function qr(e, t, n, r, i, a, o, s, c, l) {
  var u = e.generateConfig,
    d = e.locale,
    f = e.picker,
    p = e.onChange,
    m = e.allowEmpty,
    h = e.order,
    g =
      !a.some(function (e) {
        return e;
      }) && h,
    _ = Ur(u, d, o),
    y = z(_, 2),
    b = y[0],
    x = y[1],
    S = Vr(t),
    C = z(S, 2),
    w = C[0],
    T = C[1],
    E = v(function () {
      T(t);
    });
  Z.useEffect(
    function () {
      E();
    },
    [t]
  );
  var D = v(function (e) {
      var r = e === null,
        o = L(e || w());
      if (r)
        for (var s = Math.max(a.length, o.length), c = 0; c < s; c += 1)
          a[c] || (o[c] = null);
      g && o[0] && o[1] && (o = Wr(o, u)), i(o);
      var _ = z(o, 2),
        v = _[0],
        y = _[1],
        S = !v,
        C = !y,
        T = !m || ((!S || m[0]) && (!C || m[1])),
        E = !h || S || C || yr(u, d, v, y, f) || u.isAfter(y, v),
        D =
          (a[0] || !v || !l(v, { activeIndex: 0 })) &&
          (a[1] || !y || !l(y, { from: v, activeIndex: 1 })),
        O = r || (T && E && D);
      if (O) {
        n(o);
        var k = x(o, t),
          A = z(k, 1)[0];
        p &&
          !A &&
          p(
            r &&
              o.every(function (e) {
                return !e;
              })
              ? null
              : o,
            b(o)
          );
      }
      return O;
    }),
    O = v(function (e, t) {
      T(Wn(w(), e, r()[e])), t && D();
    }),
    k = !s && !c;
  return (
    Fr(
      !k,
      function () {
        k && (D(), i(t), E());
      },
      2
    ),
    [O, D]
  );
}
function Jr(e, t, n, r, i) {
  return t !== `date` && t !== `time`
    ? !1
    : n === void 0
    ? r === void 0
      ? !i && (e === `date` || e === `time`)
      : r
    : n;
}
I();
function Yr(e, t, n, r, i, a) {
  var o = e;
  function s(e, t, n) {
    var r = a[e](o),
      i = n.find(function (e) {
        return e.value === r;
      });
    if (!i || i.disabled) {
      var s = n.filter(function (e) {
          return !e.disabled;
        }),
        c =
          L(s)
            .reverse()
            .find(function (e) {
              return e.value <= r;
            }) || s[0];
      c && ((r = c.value), (o = a[t](o, r)));
    }
    return r;
  }
  var c = s(`getHour`, `setHour`, t()),
    l = s(`getMinute`, `setMinute`, n(c));
  return (
    s(
      `getMillisecond`,
      `setMillisecond`,
      i(c, l, s(`getSecond`, `setSecond`, r(c, l)))
    ),
    o
  );
}
V();
function Xr() {
  return [];
}
function Zr(e, t) {
  for (
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1,
      r = arguments.length > 3 && arguments[3] !== void 0 && arguments[3],
      i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : [],
      a = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 2,
      o = [],
      s = n >= 1 ? n | 0 : 1,
      c = e;
    c <= t;
    c += s
  ) {
    var l = i.includes(c);
    (!l || !r) && o.push({ label: Hn(c, a), value: c, disabled: l });
  }
  return o;
}
function Qr(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    n = arguments.length > 2 ? arguments[2] : void 0,
    r = t || {},
    i = r.use12Hours,
    a = r.hourStep,
    o = a === void 0 ? 1 : a,
    s = r.minuteStep,
    c = s === void 0 ? 1 : s,
    l = r.secondStep,
    u = l === void 0 ? 1 : l,
    d = r.millisecondStep,
    f = d === void 0 ? 100 : d,
    p = r.hideDisabledOptions,
    m = r.disabledTime,
    h = r.disabledHours,
    g = r.disabledMinutes,
    _ = r.disabledSeconds,
    v = Z.useMemo(
      function () {
        return n || e.getNow();
      },
      [n, e]
    ),
    y = Z.useCallback(
      function (e) {
        var t = (m == null ? void 0 : m(e)) || {};
        return [
          t.disabledHours || h || Xr,
          t.disabledMinutes || g || Xr,
          t.disabledSeconds || _ || Xr,
          t.disabledMilliseconds || Xr,
        ];
      },
      [m, h, g, _]
    ),
    b = Z.useMemo(
      function () {
        return y(v);
      },
      [v, y]
    ),
    x = z(b, 4),
    C = x[0],
    w = x[1],
    T = x[2],
    E = x[3],
    D = Z.useCallback(
      function (e, t, n, r) {
        var a = Zr(0, 23, o, p, e());
        return [
          i
            ? a.map(function (e) {
                return S(S({}, e), {}, { label: Hn(e.value % 12 || 12, 2) });
              })
            : a,
          function (e) {
            return Zr(0, 59, c, p, t(e));
          },
          function (e, t) {
            return Zr(0, 59, u, p, n(e, t));
          },
          function (e, t, n) {
            return Zr(0, 999, f, p, r(e, t, n), 3);
          },
        ];
      },
      [p, o, i, f, c, u]
    ),
    O = Z.useMemo(
      function () {
        return D(C, w, T, E);
      },
      [D, C, w, T, E]
    ),
    k = z(O, 4),
    A = k[0],
    j = k[1],
    M = k[2],
    N = k[3];
  return [
    function (t, n) {
      var r = function () {
          return A;
        },
        i = j,
        a = M,
        o = N;
      if (n) {
        var s = y(n),
          c = z(s, 4),
          l = c[0],
          u = c[1],
          d = c[2],
          f = c[3],
          p = D(l, u, d, f),
          m = z(p, 4),
          h = m[0],
          g = m[1],
          _ = m[2],
          v = m[3];
        (r = function () {
          return h;
        }),
          (i = g),
          (a = _),
          (o = v);
      }
      return Yr(t, r, i, a, o, e);
    },
    A,
    j,
    M,
    N,
  ];
}
V();
function $r(e) {
  var t = e.mode,
    n = e.internalMode,
    r = e.renderExtraFooter,
    i = e.showNow,
    a = e.showTime,
    o = e.onSubmit,
    s = e.onNow,
    c = e.invalid,
    l = e.needConfirm,
    u = e.generateConfig,
    d = e.disabledDate,
    f = Z.useContext(zn),
    p = f.prefixCls,
    m = f.locale,
    h = f.button,
    g = h === void 0 ? `button` : h,
    _ = u.getNow(),
    v = Qr(u, a, _),
    y = z(v, 1)[0],
    b = r == null ? void 0 : r(t),
    x = d(_, { type: t }),
    S = function () {
      x || s(y(_));
    },
    C = `${p}-now`,
    w = `${C}-btn`,
    T =
      i &&
      Z.createElement(
        `li`,
        { className: C },
        Z.createElement(
          `a`,
          {
            className: (0, Q.default)(w, x && `${w}-disabled`),
            "aria-disabled": x,
            onClick: S,
          },
          n === `date` ? m.today : m.now
        )
      ),
    E =
      l &&
      Z.createElement(
        `li`,
        { className: `${p}-ok` },
        Z.createElement(g, { disabled: c, onClick: o }, m.ok)
      ),
    D = (T || E) && Z.createElement(`ul`, { className: `${p}-ranges` }, T, E);
  return !b && !D
    ? null
    : Z.createElement(
        `div`,
        { className: `${p}-footer` },
        b && Z.createElement(`div`, { className: `${p}-footer-extra` }, b),
        D
      );
}
I();
function ei(e, t, n) {
  function r(r, i) {
    var a = r.findIndex(function (r) {
      return yr(e, t, r, i, n);
    });
    if (a === -1) return [].concat(L(r), [i]);
    var o = L(r);
    return o.splice(a, 1), o;
  }
  return r;
}
var ti = Z.createContext(null);
function ni() {
  return Z.useContext(ti);
}
function ri(e, t) {
  var n = e.prefixCls,
    r = e.generateConfig,
    i = e.locale,
    a = e.disabledDate,
    o = e.minDate,
    s = e.maxDate,
    c = e.cellRender,
    l = e.hoverValue,
    u = e.hoverRangeValue,
    d = e.onHover,
    f = e.values,
    p = e.pickerValue,
    m = e.onSelect,
    h = e.prevIcon,
    g = e.nextIcon,
    _ = e.superPrevIcon,
    v = e.superNextIcon,
    y = r.getNow();
  return [
    {
      now: y,
      values: f,
      pickerValue: p,
      prefixCls: n,
      disabledDate: a,
      minDate: o,
      maxDate: s,
      cellRender: c,
      hoverValue: l,
      hoverRangeValue: u,
      onHover: d,
      locale: i,
      generateConfig: r,
      onSelect: m,
      panelType: t,
      prevIcon: h,
      nextIcon: g,
      superPrevIcon: _,
      superNextIcon: v,
    },
    y,
  ];
}
var ii = Z.createContext({});
D(), V();
function ai(e) {
  for (
    var t = e.rowNum,
      n = e.colNum,
      r = e.baseDate,
      i = e.getCellDate,
      a = e.prefixColumn,
      o = e.rowClassName,
      s = e.titleFormat,
      c = e.getCellText,
      l = e.getCellClassName,
      u = e.headerCells,
      d = e.cellSelection,
      f = d === void 0 || d,
      p = e.disabledDate,
      m = ni(),
      h = m.prefixCls,
      g = m.panelType,
      _ = m.now,
      v = m.disabledDate,
      y = m.cellRender,
      b = m.onHover,
      x = m.hoverValue,
      C = m.hoverRangeValue,
      w = m.generateConfig,
      E = m.values,
      D = m.locale,
      O = m.onSelect,
      k = p || v,
      A = `${h}-cell`,
      j = Z.useContext(ii).onCellDblClick,
      M = function (e) {
        return E.some(function (t) {
          return t && yr(w, D, e, t, g);
        });
      },
      N = [],
      P = 0;
    P < t;
    P += 1
  ) {
    for (
      var F = [],
        I = void 0,
        L = function () {
          var e = i(r, P * n + R),
            t = k == null ? void 0 : k(e, { type: g });
          R === 0 && ((I = e), a && F.push(a(I)));
          var o = !1,
            u = !1,
            d = !1;
          if (f && C) {
            var p = z(C, 2),
              m = p[0],
              v = p[1];
            (o = br(w, m, v, e)),
              (u = yr(w, D, e, m, g)),
              (d = yr(w, D, e, v, g));
          }
          var E = s
              ? Cr(e, { locale: D, format: s, generateConfig: w })
              : void 0,
            N = Z.createElement(`div`, { className: `${A}-inner` }, c(e));
          F.push(
            Z.createElement(
              `td`,
              {
                key: R,
                title: E,
                className: (0, Q.default)(
                  A,
                  S(
                    T(
                      T(
                        T(
                          T(
                            T(
                              T({}, `${A}-disabled`, t),
                              `${A}-hover`,
                              (x || []).some(function (t) {
                                return yr(w, D, e, t, g);
                              })
                            ),
                            `${A}-in-range`,
                            o && !u && !d
                          ),
                          `${A}-range-start`,
                          u
                        ),
                        `${A}-range-end`,
                        d
                      ),
                      `${h}-cell-selected`,
                      !C && g !== `week` && M(e)
                    ),
                    l(e)
                  )
                ),
                onClick: function () {
                  t || O(e);
                },
                onDoubleClick: function () {
                  !t && j && j();
                },
                onMouseEnter: function () {
                  t || b == null || b(e);
                },
                onMouseLeave: function () {
                  t || b == null || b(null);
                },
              },
              y
                ? y(e, {
                    prefixCls: h,
                    originNode: N,
                    today: _,
                    type: g,
                    locale: D,
                  })
                : N
            )
          );
        },
        R = 0;
      R < n;
      R += 1
    )
      L();
    N.push(
      Z.createElement(`tr`, { key: P, className: o == null ? void 0 : o(I) }, F)
    );
  }
  return Z.createElement(
    `div`,
    { className: `${h}-body` },
    Z.createElement(
      `table`,
      { className: `${h}-content` },
      u && Z.createElement(`thead`, null, Z.createElement(`tr`, null, u)),
      Z.createElement(`tbody`, null, N)
    )
  );
}
var oi = { visibility: `hidden` };
function si(e) {
  var t = e.offset,
    n = e.superOffset,
    r = e.onChange,
    i = e.getStart,
    a = e.getEnd,
    o = e.children,
    s = ni(),
    c = s.prefixCls,
    l = s.prevIcon,
    u = l === void 0 ? `‹` : l,
    d = s.nextIcon,
    f = d === void 0 ? `›` : d,
    p = s.superPrevIcon,
    m = p === void 0 ? `«` : p,
    h = s.superNextIcon,
    g = h === void 0 ? `»` : h,
    _ = s.minDate,
    v = s.maxDate,
    y = s.generateConfig,
    b = s.locale,
    x = s.pickerValue,
    S = s.panelType,
    C = `${c}-header`,
    w = Z.useContext(ii),
    T = w.hidePrev,
    E = w.hideNext,
    D = w.hideHeader,
    O = Z.useMemo(
      function () {
        return !_ || !t || !a ? !1 : !xr(y, b, a(t(-1, x)), _, S);
      },
      [_, t, x, a, y, b, S]
    ),
    k = Z.useMemo(
      function () {
        return !_ || !n || !a ? !1 : !xr(y, b, a(n(-1, x)), _, S);
      },
      [_, n, x, a, y, b, S]
    ),
    A = Z.useMemo(
      function () {
        return !v || !t || !i ? !1 : !xr(y, b, v, i(t(1, x)), S);
      },
      [v, t, x, i, y, b, S]
    ),
    j = Z.useMemo(
      function () {
        return !v || !n || !i ? !1 : !xr(y, b, v, i(n(1, x)), S);
      },
      [v, n, x, i, y, b, S]
    ),
    M = function (e) {
      t && r(t(e, x));
    },
    N = function (e) {
      n && r(n(e, x));
    };
  if (D) return null;
  var P = `${C}-prev-btn`,
    F = `${C}-next-btn`,
    I = `${C}-super-prev-btn`,
    L = `${C}-super-next-btn`;
  return Z.createElement(
    `div`,
    { className: C },
    n &&
      Z.createElement(
        `button`,
        {
          type: `button`,
          "aria-label": b.previousYear,
          onClick: function () {
            return N(-1);
          },
          tabIndex: -1,
          className: (0, Q.default)(I, k && `${I}-disabled`),
          disabled: k,
          style: T ? oi : {},
        },
        m
      ),
    t &&
      Z.createElement(
        `button`,
        {
          type: `button`,
          "aria-label": b.previousMonth,
          onClick: function () {
            return M(-1);
          },
          tabIndex: -1,
          className: (0, Q.default)(P, O && `${P}-disabled`),
          disabled: O,
          style: T ? oi : {},
        },
        u
      ),
    Z.createElement(`div`, { className: `${C}-view` }, o),
    t &&
      Z.createElement(
        `button`,
        {
          type: `button`,
          "aria-label": b.nextMonth,
          onClick: function () {
            return M(1);
          },
          tabIndex: -1,
          className: (0, Q.default)(F, A && `${F}-disabled`),
          disabled: A,
          style: E ? oi : {},
        },
        f
      ),
    n &&
      Z.createElement(
        `button`,
        {
          type: `button`,
          "aria-label": b.nextYear,
          onClick: function () {
            return N(1);
          },
          tabIndex: -1,
          className: (0, Q.default)(L, j && `${L}-disabled`),
          disabled: j,
          style: E ? oi : {},
        },
        g
      )
  );
}
D(), V();
function ci(e) {
  var t = e.prefixCls,
    n = e.panelName,
    r = n === void 0 ? `date` : n,
    i = e.locale,
    a = e.generateConfig,
    o = e.pickerValue,
    s = e.onPickerValueChange,
    c = e.onModeChange,
    l = e.mode,
    u = l === void 0 ? `date` : l,
    d = e.disabledDate,
    f = e.onSelect,
    p = e.onHover,
    m = e.showWeek,
    h = `${t}-${r}-panel`,
    g = `${t}-cell`,
    v = u === `week`,
    y = ri(e, u),
    b = z(y, 2),
    x = b[0],
    S = b[1],
    C = a.locale.getWeekFirstDay(i.locale),
    w = a.setDate(o, 1),
    E = Sr(i.locale, a, w),
    D = a.getMonth(o),
    O = (m === void 0 ? v : m)
      ? function (e) {
          var t = d == null ? void 0 : d(e, { type: `week` });
          return Z.createElement(
            `td`,
            {
              key: `week`,
              className: (0, Q.default)(
                g,
                `${g}-week`,
                T({}, `${g}-disabled`, t)
              ),
              onClick: function () {
                t || f(e);
              },
              onMouseEnter: function () {
                t || p == null || p(e);
              },
              onMouseLeave: function () {
                t || p == null || p(null);
              },
            },
            Z.createElement(
              `div`,
              { className: `${g}-inner` },
              a.locale.getWeek(i.locale, e)
            )
          );
        }
      : null,
    k = [],
    A =
      i.shortWeekDays ||
      (a.locale.getShortWeekDays ? a.locale.getShortWeekDays(i.locale) : []);
  O &&
    k.push(
      Z.createElement(
        `th`,
        { key: `empty` },
        Z.createElement(
          `span`,
          {
            style: {
              width: 0,
              height: 0,
              position: `absolute`,
              overflow: `hidden`,
              opacity: 0,
            },
          },
          i.week
        )
      )
    );
  for (var j = 0; j < 7; j += 1)
    k.push(Z.createElement(`th`, { key: j }, A[(j + C) % 7]));
  var M = function (e, t) {
      return a.addDate(e, t);
    },
    N = function (e) {
      return Cr(e, { locale: i, format: i.cellDateFormat, generateConfig: a });
    },
    P = function (e) {
      return T(
        T({}, `${t}-cell-in-view`, mr(a, e, o)),
        `${t}-cell-today`,
        hr(a, e, S)
      );
    },
    F =
      i.shortMonths ||
      (a.locale.getShortMonths ? a.locale.getShortMonths(i.locale) : []),
    I = Z.createElement(
      `button`,
      {
        type: `button`,
        "aria-label": i.yearSelect,
        key: `year`,
        onClick: function () {
          c(`year`, o);
        },
        tabIndex: -1,
        className: `${t}-year-btn`,
      },
      Cr(o, { locale: i, format: i.yearFormat, generateConfig: a })
    ),
    L = Z.createElement(
      `button`,
      {
        type: `button`,
        "aria-label": i.monthSelect,
        key: `month`,
        onClick: function () {
          c(`month`, o);
        },
        tabIndex: -1,
        className: `${t}-month-btn`,
      },
      i.monthFormat
        ? Cr(o, { locale: i, format: i.monthFormat, generateConfig: a })
        : F[D]
    ),
    R = i.monthBeforeYear ? [L, I] : [I, L];
  return Z.createElement(
    ti.Provider,
    { value: x },
    Z.createElement(
      `div`,
      { className: (0, Q.default)(h, m && `${h}-show-week`) },
      Z.createElement(
        si,
        {
          offset: function (e) {
            return a.addMonth(o, e);
          },
          superOffset: function (e) {
            return a.addYear(o, e);
          },
          onChange: s,
          getStart: function (e) {
            return a.setDate(e, 1);
          },
          getEnd: function (e) {
            var t = a.setDate(e, 1);
            return (t = a.addMonth(t, 1)), a.addDate(t, -1);
          },
        },
        R
      ),
      Z.createElement(
        ai,
        _({ titleFormat: i.fieldDateFormat }, e, {
          colNum: 7,
          rowNum: 6,
          baseDate: E,
          headerCells: k,
          getCellDate: M,
          getCellText: N,
          getCellClassName: P,
          prefixColumn: O,
          cellSelection: !v,
        })
      )
    )
  );
}
var li = 1 / 3;
function ui(e, t) {
  var n = Z.useRef(!1),
    r = Z.useRef(null),
    i = Z.useRef(null),
    a = function () {
      return n.current;
    },
    o = function () {
      U.cancel(r.current), (n.current = !1);
    },
    s = Z.useRef();
  return [
    v(function () {
      var a = e.current;
      if (((i.current = null), (s.current = 0), a)) {
        var c = a.querySelector(`[data-value="${t}"]`),
          l = a.querySelector(`li`);
        c &&
          l &&
          (function e() {
            o(), (n.current = !0), (s.current += 1);
            var t = a.scrollTop,
              u = l.offsetTop,
              d = c.offsetTop,
              f = d - u;
            if ((d === 0 && c !== l) || !ce(a))
              s.current <= 5 && (r.current = U(e));
            else {
              var p = t + (f - t) * li,
                m = Math.abs(f - p);
              i.current !== null && i.current < m
                ? o()
                : ((i.current = m),
                  m <= 1
                    ? ((a.scrollTop = f), o())
                    : ((a.scrollTop = p), (r.current = U(e))));
            }
          })();
      }
    }),
    o,
    a,
  ];
}
D(), I(), V();
var di = 300;
function fi(e) {
  return e
    .map(function (e) {
      return [e.value, e.label, e.disabled].join(`,`);
    })
    .join(`;`);
}
function pi(e) {
  var t = e.units,
    n = e.value,
    r = e.optionalValue,
    i = e.type,
    a = e.onChange,
    o = e.onHover,
    s = e.onDblClick,
    c = e.changeOnScroll,
    l = ni(),
    u = l.prefixCls,
    d = l.cellRender,
    f = l.now,
    p = l.locale,
    m = `${u}-time-panel`,
    h = `${u}-time-panel-cell`,
    g = Z.useRef(null),
    _ = Z.useRef(),
    v = function () {
      clearTimeout(_.current);
    },
    y = ui(g, n ?? r),
    b = z(y, 3),
    x = b[0],
    S = b[1],
    C = b[2];
  E(
    function () {
      return (
        x(),
        v(),
        function () {
          S(), v();
        }
      );
    },
    [n, r, fi(t)]
  );
  var w = function (e) {
      v();
      var n = e.target;
      !C() &&
        c &&
        (_.current = setTimeout(function () {
          var e = g.current,
            r = e.querySelector(`li`).offsetTop,
            i = Array.from(e.querySelectorAll(`li`))
              .map(function (e) {
                return e.offsetTop - r;
              })
              .map(function (e, r) {
                return t[r].disabled ? 2 ** 53 - 1 : Math.abs(e - n.scrollTop);
              }),
            o = Math.min.apply(Math, L(i)),
            s =
              t[
                i.findIndex(function (e) {
                  return e === o;
                })
              ];
          s && !s.disabled && a(s.value);
        }, di));
    },
    D = `${m}-column`;
  return Z.createElement(
    `ul`,
    { className: D, ref: g, "data-type": i, onScroll: w },
    t.map(function (e) {
      var t = e.label,
        r = e.value,
        c = e.disabled,
        l = Z.createElement(`div`, { className: `${h}-inner` }, t);
      return Z.createElement(
        `li`,
        {
          key: r,
          className: (0, Q.default)(
            h,
            T(T({}, `${h}-selected`, n === r), `${h}-disabled`, c)
          ),
          onClick: function () {
            c || a(r);
          },
          onDoubleClick: function () {
            !c && s && s();
          },
          onMouseEnter: function () {
            o(r);
          },
          onMouseLeave: function () {
            o(null);
          },
          "data-value": r,
        },
        d
          ? d(r, {
              prefixCls: u,
              originNode: l,
              today: f,
              type: `time`,
              subType: i,
              locale: p,
            })
          : l
      );
    })
  );
}
g(), V();
function mi(e) {
  return e < 12;
}
function hi(e) {
  var t = e.showHour,
    n = e.showMinute,
    r = e.showSecond,
    i = e.showMillisecond,
    a = e.use12Hours,
    o = e.changeOnScroll,
    s = ni(),
    c = s.prefixCls,
    l = s.values,
    u = s.generateConfig,
    d = s.locale,
    f = s.onSelect,
    p = s.onHover,
    m = p === void 0 ? function () {} : p,
    h = s.pickerValue,
    g = (l == null ? void 0 : l[0]) || null,
    v = Z.useContext(ii).onCellDblClick,
    y = Qr(u, e, g),
    b = z(y, 5),
    x = b[0],
    S = b[1],
    C = b[2],
    w = b[3],
    T = b[4],
    E = function (e) {
      return [g && u[e](g), h && u[e](h)];
    },
    D = E(`getHour`),
    O = z(D, 2),
    k = O[0],
    A = O[1],
    j = E(`getMinute`),
    M = z(j, 2),
    N = M[0],
    P = M[1],
    F = E(`getSecond`),
    I = z(F, 2),
    L = I[0],
    R = I[1],
    ee = E(`getMillisecond`),
    te = z(ee, 2),
    ne = te[0],
    B = te[1],
    re = k === null ? null : mi(k) ? `am` : `pm`,
    V = Z.useMemo(
      function () {
        return a
          ? mi(k)
            ? S.filter(function (e) {
                return mi(e.value);
              })
            : S.filter(function (e) {
                return !mi(e.value);
              })
          : S;
      },
      [k, S, a]
    ),
    ie = function (e, t) {
      var n,
        r = e.filter(function (e) {
          return !e.disabled;
        });
      return t ?? (r == null || (n = r[0]) == null ? void 0 : n.value);
    },
    H = ie(S, k),
    ae = Z.useMemo(
      function () {
        return C(H);
      },
      [C, H]
    ),
    oe = ie(ae, N),
    se = Z.useMemo(
      function () {
        return w(H, oe);
      },
      [w, H, oe]
    ),
    ce = ie(se, L),
    U = Z.useMemo(
      function () {
        return T(H, oe, ce);
      },
      [T, H, oe, ce]
    ),
    le = ie(U, ne),
    ue = Z.useMemo(
      function () {
        if (!a) return [];
        var e = u.getNow(),
          t = u.setHour(e, 6),
          n = u.setHour(e, 18),
          r = function (e, t) {
            var n = d.cellMeridiemFormat;
            return n ? Cr(e, { generateConfig: u, locale: d, format: n }) : t;
          };
        return [
          {
            label: r(t, `AM`),
            value: `am`,
            disabled: S.every(function (e) {
              return e.disabled || !mi(e.value);
            }),
          },
          {
            label: r(n, `PM`),
            value: `pm`,
            disabled: S.every(function (e) {
              return e.disabled || mi(e.value);
            }),
          },
        ];
      },
      [S, a, u, d]
    ),
    de = function (e) {
      f(x(e));
    },
    fe = Z.useMemo(
      function () {
        var e = g || h || u.getNow(),
          t = function (e) {
            return e != null;
          };
        return (
          t(k)
            ? ((e = u.setHour(e, k)),
              (e = u.setMinute(e, N)),
              (e = u.setSecond(e, L)),
              (e = u.setMillisecond(e, ne)))
            : t(A)
            ? ((e = u.setHour(e, A)),
              (e = u.setMinute(e, P)),
              (e = u.setSecond(e, R)),
              (e = u.setMillisecond(e, B)))
            : t(H) &&
              ((e = u.setHour(e, H)),
              (e = u.setMinute(e, oe)),
              (e = u.setSecond(e, ce)),
              (e = u.setMillisecond(e, le))),
          e
        );
      },
      [g, h, k, N, L, ne, H, oe, ce, le, A, P, R, B, u]
    ),
    pe = function (e, t) {
      return e === null ? null : u[t](fe, e);
    },
    me = function (e) {
      return pe(e, `setHour`);
    },
    W = function (e) {
      return pe(e, `setMinute`);
    },
    G = function (e) {
      return pe(e, `setSecond`);
    },
    he = function (e) {
      return pe(e, `setMillisecond`);
    },
    K = function (e) {
      return e === null
        ? null
        : e === `am` && !mi(k)
        ? u.setHour(fe, k - 12)
        : e === `pm` && mi(k)
        ? u.setHour(fe, k + 12)
        : fe;
    },
    ge = function (e) {
      de(me(e));
    },
    _e = function (e) {
      de(W(e));
    },
    ve = function (e) {
      de(G(e));
    },
    ye = function (e) {
      de(he(e));
    },
    be = function (e) {
      de(K(e));
    },
    xe = function (e) {
      m(me(e));
    },
    q = function (e) {
      m(W(e));
    },
    Se = function (e) {
      m(G(e));
    },
    Ce = function (e) {
      m(he(e));
    },
    we = function (e) {
      m(K(e));
    },
    Te = { onDblClick: v, changeOnScroll: o };
  return Z.createElement(
    `div`,
    { className: `${c}-content` },
    t &&
      Z.createElement(
        pi,
        _(
          {
            units: V,
            value: k,
            optionalValue: A,
            type: `hour`,
            onChange: ge,
            onHover: xe,
          },
          Te
        )
      ),
    n &&
      Z.createElement(
        pi,
        _(
          {
            units: ae,
            value: N,
            optionalValue: P,
            type: `minute`,
            onChange: _e,
            onHover: q,
          },
          Te
        )
      ),
    r &&
      Z.createElement(
        pi,
        _(
          {
            units: se,
            value: L,
            optionalValue: R,
            type: `second`,
            onChange: ve,
            onHover: Se,
          },
          Te
        )
      ),
    i &&
      Z.createElement(
        pi,
        _(
          {
            units: U,
            value: ne,
            optionalValue: B,
            type: `millisecond`,
            onChange: ye,
            onHover: Ce,
          },
          Te
        )
      ),
    a &&
      Z.createElement(
        pi,
        _(
          { units: ue, value: re, type: `meridiem`, onChange: be, onHover: we },
          Te
        )
      )
  );
}
V();
function gi(e) {
  var t = e.prefixCls,
    n = e.value,
    r = e.locale,
    i = e.generateConfig,
    a = e.showTime,
    o = (a || {}).format,
    s = `${t}-time-panel`,
    c = ri(e, `time`),
    l = z(c, 1)[0];
  return Z.createElement(
    ti.Provider,
    { value: l },
    Z.createElement(
      `div`,
      { className: (0, Q.default)(s) },
      Z.createElement(
        si,
        null,
        n ? Cr(n, { locale: r, format: o, generateConfig: i }) : `\xA0`
      ),
      Z.createElement(hi, a)
    )
  );
}
g(), V();
function _i(e) {
  var t = e.prefixCls,
    n = e.generateConfig,
    r = e.showTime,
    i = e.onSelect,
    a = e.value,
    o = e.pickerValue,
    s = e.onHover,
    c = `${t}-datetime-panel`,
    l = Qr(n, r),
    u = z(l, 1)[0],
    d = function (e) {
      return a ? wr(n, e, a) : wr(n, e, o);
    };
  return Z.createElement(
    `div`,
    { className: c },
    Z.createElement(
      ci,
      _({}, e, {
        onSelect: function (e) {
          var t = d(e);
          i(u(t, t));
        },
        onHover: function (e) {
          s == null || s(e && d(e));
        },
      })
    ),
    Z.createElement(gi, e)
  );
}
g(), D(), V();
function vi(e) {
  var t = e.prefixCls,
    n = e.locale,
    r = e.generateConfig,
    i = e.pickerValue,
    a = e.disabledDate,
    o = e.onPickerValueChange,
    s = `${t}-decade-panel`,
    c = ri(e, `decade`),
    l = z(c, 1)[0],
    u = function (e) {
      var t = Math.floor(r.getYear(e) / 100) * 100;
      return r.setYear(e, t);
    },
    d = function (e) {
      var t = u(e);
      return r.addYear(t, 99);
    },
    f = u(i),
    p = d(i),
    m = r.addYear(f, -10),
    h = function (e, t) {
      return r.addYear(e, t * 10);
    },
    g = function (e) {
      var t = n.cellYearFormat;
      return `${Cr(e, { locale: n, format: t, generateConfig: r })}-${Cr(
        r.addYear(e, 9),
        { locale: n, format: t, generateConfig: r }
      )}`;
    },
    v = function (e) {
      return T(
        {},
        `${t}-cell-in-view`,
        ur(r, e, f) || ur(r, e, p) || br(r, f, p, e)
      );
    },
    y = a
      ? function (e, t) {
          var n = r.setDate(e, 1),
            i = r.setMonth(n, 0),
            o = r.setYear(i, Math.floor(r.getYear(i) / 10) * 10),
            s = r.addYear(o, 10),
            c = r.addDate(s, -1);
          return a(o, t) && a(c, t);
        }
      : null,
    b = `${Cr(f, { locale: n, format: n.yearFormat, generateConfig: r })}-${Cr(
      p,
      { locale: n, format: n.yearFormat, generateConfig: r }
    )}`;
  return Z.createElement(
    ti.Provider,
    { value: l },
    Z.createElement(
      `div`,
      { className: s },
      Z.createElement(
        si,
        {
          superOffset: function (e) {
            return r.addYear(i, e * 100);
          },
          onChange: o,
          getStart: u,
          getEnd: d,
        },
        b
      ),
      Z.createElement(
        ai,
        _({}, e, {
          disabledDate: y,
          colNum: 3,
          rowNum: 4,
          baseDate: m,
          getCellDate: h,
          getCellText: g,
          getCellClassName: v,
        })
      )
    )
  );
}
g(), D(), V();
function yi(e) {
  var t = e.prefixCls,
    n = e.locale,
    r = e.generateConfig,
    i = e.pickerValue,
    a = e.disabledDate,
    o = e.onPickerValueChange,
    s = e.onModeChange,
    c = `${t}-month-panel`,
    l = ri(e, `month`),
    u = z(l, 1)[0],
    d = r.setMonth(i, 0),
    f =
      n.shortMonths ||
      (r.locale.getShortMonths ? r.locale.getShortMonths(n.locale) : []),
    p = function (e, t) {
      return r.addMonth(e, t);
    },
    m = function (e) {
      var t = r.getMonth(e);
      return n.monthFormat
        ? Cr(e, { locale: n, format: n.monthFormat, generateConfig: r })
        : f[t];
    },
    h = function () {
      return T({}, `${t}-cell-in-view`, !0);
    },
    g = a
      ? function (e, t) {
          var n = r.setDate(e, 1),
            i = r.setMonth(n, r.getMonth(n) + 1),
            o = r.addDate(i, -1);
          return a(n, t) && a(o, t);
        }
      : null,
    v = Z.createElement(
      `button`,
      {
        type: `button`,
        key: `year`,
        "aria-label": n.yearSelect,
        onClick: function () {
          s(`year`);
        },
        tabIndex: -1,
        className: `${t}-year-btn`,
      },
      Cr(i, { locale: n, format: n.yearFormat, generateConfig: r })
    );
  return Z.createElement(
    ti.Provider,
    { value: u },
    Z.createElement(
      `div`,
      { className: c },
      Z.createElement(
        si,
        {
          superOffset: function (e) {
            return r.addYear(i, e);
          },
          onChange: o,
          getStart: function (e) {
            return r.setMonth(e, 0);
          },
          getEnd: function (e) {
            return r.setMonth(e, 11);
          },
        },
        v
      ),
      Z.createElement(
        ai,
        _({}, e, {
          disabledDate: g,
          titleFormat: n.fieldMonthFormat,
          colNum: 3,
          rowNum: 4,
          baseDate: d,
          getCellDate: p,
          getCellText: m,
          getCellClassName: h,
        })
      )
    )
  );
}
g(), D(), V();
function bi(e) {
  var t = e.prefixCls,
    n = e.locale,
    r = e.generateConfig,
    i = e.pickerValue,
    a = e.onPickerValueChange,
    o = e.onModeChange,
    s = `${t}-quarter-panel`,
    c = ri(e, `quarter`),
    l = z(c, 1)[0],
    u = r.setMonth(i, 0),
    d = function (e, t) {
      return r.addMonth(e, t * 3);
    },
    f = function (e) {
      return Cr(e, {
        locale: n,
        format: n.cellQuarterFormat,
        generateConfig: r,
      });
    },
    p = function () {
      return T({}, `${t}-cell-in-view`, !0);
    },
    m = Z.createElement(
      `button`,
      {
        type: `button`,
        key: `year`,
        "aria-label": n.yearSelect,
        onClick: function () {
          o(`year`);
        },
        tabIndex: -1,
        className: `${t}-year-btn`,
      },
      Cr(i, { locale: n, format: n.yearFormat, generateConfig: r })
    );
  return Z.createElement(
    ti.Provider,
    { value: l },
    Z.createElement(
      `div`,
      { className: s },
      Z.createElement(
        si,
        {
          superOffset: function (e) {
            return r.addYear(i, e);
          },
          onChange: a,
          getStart: function (e) {
            return r.setMonth(e, 0);
          },
          getEnd: function (e) {
            return r.setMonth(e, 11);
          },
        },
        m
      ),
      Z.createElement(
        ai,
        _({}, e, {
          titleFormat: n.fieldQuarterFormat,
          colNum: 4,
          rowNum: 1,
          baseDate: u,
          getCellDate: d,
          getCellText: f,
          getCellClassName: p,
        })
      )
    )
  );
}
g(), D(), V();
function xi(e) {
  var t = e.prefixCls,
    n = e.generateConfig,
    r = e.locale,
    i = e.value,
    a = e.hoverValue,
    o = e.hoverRangeValue,
    s = r.locale,
    c = `${t}-week-panel-row`;
  return Z.createElement(
    ci,
    _({}, e, {
      mode: `week`,
      panelName: `week`,
      rowClassName: function (e) {
        var t = {};
        if (o) {
          var r = z(o, 2),
            l = r[0],
            u = r[1],
            d = vr(n, s, l, e),
            f = vr(n, s, u, e);
          (t[`${c}-range-start`] = d),
            (t[`${c}-range-end`] = f),
            (t[`${c}-range-hover`] = !d && !f && br(n, l, u, e));
        }
        return (
          a &&
            (t[`${c}-hover`] = a.some(function (t) {
              return vr(n, s, e, t);
            })),
          (0, Q.default)(c, T({}, `${c}-selected`, !o && vr(n, s, i, e)), t)
        );
      },
    })
  );
}
g(), D(), V();
function Si(e) {
  var t = e.prefixCls,
    n = e.locale,
    r = e.generateConfig,
    i = e.pickerValue,
    a = e.disabledDate,
    o = e.onPickerValueChange,
    s = e.onModeChange,
    c = `${t}-year-panel`,
    l = ri(e, `year`),
    u = z(l, 1)[0],
    d = function (e) {
      var t = Math.floor(r.getYear(e) / 10) * 10;
      return r.setYear(e, t);
    },
    f = function (e) {
      var t = d(e);
      return r.addYear(t, 9);
    },
    p = d(i),
    m = f(i),
    h = r.addYear(p, -1),
    g = function (e, t) {
      return r.addYear(e, t);
    },
    v = function (e) {
      return Cr(e, { locale: n, format: n.cellYearFormat, generateConfig: r });
    },
    y = function (e) {
      return T(
        {},
        `${t}-cell-in-view`,
        dr(r, e, p) || dr(r, e, m) || br(r, p, m, e)
      );
    },
    b = a
      ? function (e, t) {
          var n = r.setMonth(e, 0),
            i = r.setDate(n, 1),
            o = r.addYear(i, 1),
            s = r.addDate(o, -1);
          return a(i, t) && a(s, t);
        }
      : null,
    x = Z.createElement(
      `button`,
      {
        type: `button`,
        key: `decade`,
        "aria-label": n.decadeSelect,
        onClick: function () {
          s(`decade`);
        },
        tabIndex: -1,
        className: `${t}-decade-btn`,
      },
      Cr(p, { locale: n, format: n.yearFormat, generateConfig: r }),
      `-`,
      Cr(m, { locale: n, format: n.yearFormat, generateConfig: r })
    );
  return Z.createElement(
    ti.Provider,
    { value: u },
    Z.createElement(
      `div`,
      { className: c },
      Z.createElement(
        si,
        {
          superOffset: function (e) {
            return r.addYear(i, e * 10);
          },
          onChange: o,
          getStart: d,
          getEnd: f,
        },
        x
      ),
      Z.createElement(
        ai,
        _({}, e, {
          disabledDate: b,
          titleFormat: n.fieldYearFormat,
          colNum: 3,
          rowNum: 4,
          baseDate: h,
          getCellDate: g,
          getCellText: v,
          getCellClassName: y,
        })
      )
    )
  );
}
g(), D(), I(), V();
var Ci = {
  date: ci,
  datetime: _i,
  week: xi,
  month: yi,
  quarter: bi,
  year: Si,
  decade: vi,
  time: gi,
};
function wi(e, t) {
  var n,
    r = e.locale,
    i = e.generateConfig,
    a = e.direction,
    o = e.prefixCls,
    s = e.tabIndex,
    c = s === void 0 ? 0 : s,
    l = e.multiple,
    u = e.defaultValue,
    d = e.value,
    f = e.onChange,
    p = e.onSelect,
    m = e.defaultPickerValue,
    h = e.pickerValue,
    g = e.onPickerValueChange,
    y = e.mode,
    b = e.onPanelChange,
    x = e.picker,
    C = x === void 0 ? `date` : x,
    w = e.showTime,
    E = e.hoverValue,
    D = e.hoverRangeValue,
    O = e.cellRender,
    k = e.dateRender,
    A = e.monthCellRender,
    j = e.components,
    M = j === void 0 ? {} : j,
    N = e.hideHeader,
    P =
      ((n = Z.useContext(zn)) == null ? void 0 : n.prefixCls) ||
      o ||
      `rc-picker`,
    F = Z.useRef();
  Z.useImperativeHandle(t, function () {
    return { nativeElement: F.current };
  });
  var I = or(e),
    R = z(I, 4),
    ee = R[0],
    te = R[1],
    ne = R[2],
    B = R[3],
    re = $n(r, te),
    V = C === `date` && w ? `datetime` : C,
    ie = Z.useMemo(
      function () {
        return sr(V, ne, B, ee, re);
      },
      [V, ne, B, ee, re]
    ),
    ae = i.getNow(),
    oe = H(C, {
      value: y,
      postState: function (e) {
        return e || `date`;
      },
    }),
    se = z(oe, 2),
    ce = se[0],
    U = se[1],
    le = ce === `date` && ie ? `datetime` : ce,
    ue = ei(i, r, V),
    de = H(u, { value: d }),
    fe = z(de, 2),
    pe = fe[0],
    me = fe[1],
    W = Z.useMemo(
      function () {
        var e = Un(pe).filter(function (e) {
          return e;
        });
        return l ? e : e.slice(0, 1);
      },
      [pe, l]
    ),
    G = v(function (e) {
      me(e),
        f &&
          (e === null ||
            W.length !== e.length ||
            W.some(function (t, n) {
              return !yr(i, r, t, e[n], V);
            })) &&
          (f == null || f(l ? e : e[0]));
    }),
    he = v(function (e) {
      p == null || p(e), ce === C && G(l ? ue(W, e) : [e]);
    }),
    K = H(m || W[0] || ae, { value: h }),
    ge = z(K, 2),
    _e = ge[0],
    ve = ge[1];
  Z.useEffect(
    function () {
      W[0] && !h && ve(W[0]);
    },
    [W[0]]
  );
  var ye = function (e, t) {
      b == null || b(e || h, t || ce);
    },
    be = function (e) {
      var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1];
      ve(e), g == null || g(e), t && ye(e);
    },
    xe = function (e, t) {
      U(e), t && be(t), ye(t, e);
    },
    q = function (e) {
      if ((he(e), be(e), ce !== C)) {
        var t = [`decade`, `year`],
          n = [].concat(t, [`month`]),
          r =
            {
              quarter: [].concat(t, [`quarter`]),
              week: [].concat(L(n), [`week`]),
              date: [].concat(L(n), [`date`]),
            }[C] || n,
          i = r[r.indexOf(ce) + 1];
        i && xe(i, e);
      }
    },
    Se = Z.useMemo(
      function () {
        var e, t;
        if (Array.isArray(D)) {
          var n = z(D, 2);
          (e = n[0]), (t = n[1]);
        } else e = D;
        return !e && !t
          ? null
          : ((e = e || t), (t = t || e), i.isAfter(e, t) ? [t, e] : [e, t]);
      },
      [D, i]
    ),
    Ce = Yn(O, k, A),
    we = M[le] || Ci[le] || ci,
    Te = Z.useContext(ii),
    Ee = Z.useMemo(
      function () {
        return S(S({}, Te), {}, { hideHeader: N });
      },
      [Te, N]
    ),
    De = `${P}-panel`,
    Oe = Gn(e, [
      `showWeek`,
      `prevIcon`,
      `nextIcon`,
      `superPrevIcon`,
      `superNextIcon`,
      `disabledDate`,
      `minDate`,
      `maxDate`,
      `onHover`,
    ]);
  return Z.createElement(
    ii.Provider,
    { value: Ee },
    Z.createElement(
      `div`,
      {
        ref: F,
        tabIndex: c,
        className: (0, Q.default)(De, T({}, `${De}-rtl`, a === `rtl`)),
      },
      Z.createElement(
        we,
        _({}, Oe, {
          showTime: ie,
          prefixCls: P,
          locale: re,
          generateConfig: i,
          onModeChange: xe,
          pickerValue: _e,
          onPickerValueChange: function (e) {
            be(e, !0);
          },
          value: W[0],
          onSelect: q,
          values: W,
          cellRender: Ce,
          hoverRangeValue: Se,
          hoverValue: E,
        })
      )
    )
  );
}
var Ti = Z.memo(Z.forwardRef(wi));
g();
function Ei(e) {
  var t = e.picker,
    n = e.multiplePanel,
    r = e.pickerValue,
    i = e.onPickerValueChange,
    a = e.needConfirm,
    o = e.onSubmit,
    s = e.range,
    c = e.hoverValue,
    l = Z.useContext(zn),
    u = l.prefixCls,
    d = l.generateConfig,
    f = Z.useCallback(
      function (e, n) {
        return Rr(d, t, e, n);
      },
      [d, t]
    ),
    p = Z.useMemo(
      function () {
        return f(r, 1);
      },
      [r, f]
    ),
    m = function (e) {
      i(f(e, -1));
    },
    h = {
      onCellDblClick: function () {
        a && o();
      },
    },
    g = t === `time`,
    v = S(
      S({}, e),
      {},
      { hoverValue: null, hoverRangeValue: null, hideHeader: g }
    );
  return (
    s ? (v.hoverRangeValue = c) : (v.hoverValue = c),
    n
      ? Z.createElement(
          `div`,
          { className: `${u}-panels` },
          Z.createElement(
            ii.Provider,
            { value: S(S({}, h), {}, { hideNext: !0 }) },
            Z.createElement(Ti, v)
          ),
          Z.createElement(
            ii.Provider,
            { value: S(S({}, h), {}, { hidePrev: !0 }) },
            Z.createElement(
              Ti,
              _({}, v, { pickerValue: p, onPickerValueChange: m })
            )
          )
        )
      : Z.createElement(
          ii.Provider,
          { value: S({}, h) },
          Z.createElement(Ti, v)
        )
  );
}
function Di(e) {
  return typeof e == `function` ? e() : e;
}
function Oi(e) {
  var t = e.prefixCls,
    n = e.presets,
    r = e.onClick,
    i = e.onHover;
  return n.length
    ? Z.createElement(
        `div`,
        { className: `${t}-presets` },
        Z.createElement(
          `ul`,
          null,
          n.map(function (e, t) {
            var n = e.label,
              a = e.value;
            return Z.createElement(
              `li`,
              {
                key: t,
                onClick: function () {
                  r(Di(a));
                },
                onMouseEnter: function () {
                  i(Di(a));
                },
                onMouseLeave: function () {
                  i(null);
                },
              },
              n
            );
          })
        )
      )
    : null;
}
D(), g(), V();
function ki(e) {
  var t = e.panelRender,
    n = e.internalMode,
    r = e.picker,
    i = e.showNow,
    a = e.range,
    o = e.multiple,
    s = e.activeInfo,
    c = s === void 0 ? [0, 0, 0] : s,
    l = e.presets,
    u = e.onPresetHover,
    d = e.onPresetSubmit,
    f = e.onFocus,
    p = e.onBlur,
    m = e.onPanelMouseDown,
    h = e.direction,
    g = e.value,
    v = e.onSelect,
    y = e.isInvalid,
    b = e.defaultOpenValue,
    x = e.onOk,
    S = e.onSubmit,
    C = Z.useContext(zn).prefixCls,
    w = `${C}-panel`,
    E = h === `rtl`,
    D = Z.useRef(null),
    O = Z.useRef(null),
    k = Z.useState(0),
    A = z(k, 2),
    j = A[0],
    M = A[1],
    N = Z.useState(0),
    P = z(N, 2),
    F = P[0],
    I = P[1],
    L = Z.useState(0),
    R = z(L, 2),
    ee = R[0],
    te = R[1],
    ne = function (e) {
      e.width && M(e.width);
    },
    B = z(c, 3),
    re = B[0],
    V = B[1],
    ie = B[2],
    H = Z.useState(0),
    ae = z(H, 2),
    oe = ae[0],
    se = ae[1];
  Z.useEffect(
    function () {
      se(10);
    },
    [re]
  ),
    Z.useEffect(
      function () {
        if (a && O.current) {
          var e,
            t = ((e = D.current) == null ? void 0 : e.offsetWidth) || 0,
            n = O.current.getBoundingClientRect();
          if (!n.height || n.right < 0) {
            se(function (e) {
              return Math.max(0, e - 1);
            });
            return;
          }
          if ((te((E ? V - t : re) - n.left), j && j < ie)) {
            var r = E ? n.right - (V - t + j) : re + t - n.left - j;
            I(Math.max(0, r));
          } else I(0);
        }
      },
      [oe, E, j, re, V, ie, a]
    );
  function ce(e) {
    return e.filter(function (e) {
      return e;
    });
  }
  var U = Z.useMemo(
      function () {
        return ce(Un(g));
      },
      [g]
    ),
    ue = r === `time` && !U.length,
    de = Z.useMemo(
      function () {
        return ue ? ce([b]) : U;
      },
      [ue, U, b]
    ),
    fe = ue ? b : U,
    pe = Z.useMemo(
      function () {
        return (
          !de.length ||
          de.some(function (e) {
            return y(e);
          })
        );
      },
      [de, y]
    ),
    me = Z.createElement(
      `div`,
      { className: `${C}-panel-layout` },
      Z.createElement(Oi, { prefixCls: C, presets: l, onClick: d, onHover: u }),
      Z.createElement(
        `div`,
        null,
        Z.createElement(Ei, _({}, e, { value: fe })),
        Z.createElement(
          $r,
          _({}, e, {
            showNow: !o && i,
            invalid: pe,
            onSubmit: function () {
              ue && v(b), x(), S();
            },
          })
        )
      )
    );
  t && (me = t(me));
  var W = `${w}-container`,
    G = `marginLeft`,
    he = `marginRight`,
    K = Z.createElement(
      `div`,
      {
        onMouseDown: m,
        tabIndex: -1,
        className: (0, Q.default)(W, `${C}-${n}-panel-container`),
        style: T(T({}, E ? he : G, F), E ? G : he, `auto`),
        onFocus: f,
        onBlur: p,
      },
      me
    );
  return (
    a &&
      (K = Z.createElement(
        `div`,
        {
          onMouseDown: m,
          ref: O,
          className: (0, Q.default)(
            `${C}-range-wrapper`,
            `${C}-${r}-range-wrapper`
          ),
        },
        Z.createElement(`div`, {
          ref: D,
          className: `${C}-range-arrow`,
          style: { left: ee },
        }),
        Z.createElement(le, { onResize: ne }, K)
      )),
    K
  );
}
te();
function Ai(e, t) {
  var n = e.format,
    r = e.maskFormat,
    i = e.generateConfig,
    a = e.locale,
    o = e.preserveInvalidOnBlur,
    s = e.inputReadOnly,
    c = e.required,
    l = e[`aria-required`],
    u = e.onSubmit,
    d = e.onFocus,
    f = e.onBlur,
    p = e.onInputChange,
    m = e.onInvalid,
    h = e.open,
    g = e.onOpenChange,
    _ = e.onKeyDown,
    v = e.onChange,
    y = e.activeHelp,
    b = e.name,
    x = e.autoComplete,
    C = e.id,
    w = e.value,
    T = e.invalid,
    E = e.placeholder,
    D = e.disabled,
    O = e.activeIndex,
    k = e.allHelp,
    A = e.picker,
    j = function (e, t) {
      var n = i.locale.parse(a.locale, e, [t]);
      return n && i.isValidate(n) ? n : null;
    },
    M = n[0],
    N = Z.useCallback(
      function (e) {
        return Cr(e, { locale: a, format: M, generateConfig: i });
      },
      [a, i, M]
    ),
    P = Z.useMemo(
      function () {
        return w.map(N);
      },
      [w, N]
    ),
    F = Z.useMemo(
      function () {
        var e = A === `time` ? 8 : 10,
          t = typeof M == `function` ? M(i.getNow()).length : M.length;
        return Math.max(e, t) + 2;
      },
      [M, A, i]
    ),
    I = function (e) {
      for (var t = 0; t < n.length; t += 1) {
        var r = n[t];
        if (typeof r == `string`) {
          var i = j(e, r);
          if (i) return i;
        }
      }
      return !1;
    };
  return [
    function (n) {
      function i(e) {
        return n === void 0 ? e : e[n];
      }
      var a = ye(e, { aria: !0, data: !0 }),
        w = S(
          S({}, a),
          {},
          {
            format: r,
            validateFormat: function (e) {
              return !!I(e);
            },
            preserveInvalidOnBlur: o,
            readOnly: s,
            required: c,
            "aria-required": l,
            name: b,
            autoComplete: x,
            size: F,
            id: i(C),
            value: i(P) || ``,
            invalid: i(T),
            placeholder: i(E),
            active: O === n,
            helped: k || (y && O === n),
            disabled: i(D),
            onFocus: function (e) {
              d(e, n);
            },
            onBlur: function (e) {
              f(e, n);
            },
            onSubmit: u,
            onChange: function (e) {
              p();
              var t = I(e);
              t ? (m(!1, n), v(t, n)) : m(!!e, n);
            },
            onHelp: function () {
              g(!0, { index: n });
            },
            onKeyDown: function (e) {
              var t = !1;
              if (
                (_ == null ||
                  _(e, function () {
                    t = !0;
                  }),
                !e.defaultPrevented && !t)
              )
                switch (e.key) {
                  case `Escape`:
                    g(!1, { index: n });
                    break;
                  case `Enter`:
                    h || g(!0);
                }
            },
          },
          t == null ? void 0 : t({ valueTexts: P })
        );
      return (
        Object.keys(w).forEach(function (e) {
          w[e] === void 0 && delete w[e];
        }),
        w
      );
    },
    N,
  ];
}
var ji = [`onMouseEnter`, `onMouseLeave`];
function Mi(e) {
  return Z.useMemo(
    function () {
      return Gn(e, ji);
    },
    [e]
  );
}
g();
var Ni = [`icon`, `type`],
  Pi = [`onClear`];
function Fi(e) {
  var t = e.icon,
    n = e.type,
    r = re(e, Ni),
    i = Z.useContext(zn).prefixCls;
  return t
    ? Z.createElement(`span`, _({ className: `${i}-${n}` }, r), t)
    : null;
}
function Ii(e) {
  var t = e.onClear,
    n = re(e, Pi);
  return Z.createElement(
    Fi,
    _({}, n, {
      type: `clear`,
      role: `button`,
      onMouseDown: function (e) {
        e.preventDefault();
      },
      onClick: function (e) {
        e.stopPropagation(), t();
      },
    })
  );
}
y(), O(), D();
var Li = [`YYYY`, `MM`, `DD`, `HH`, `mm`, `ss`, `SSS`],
  Ri = `顧`,
  zi = (function () {
    function e(t) {
      x(this, e),
        T(this, `format`, void 0),
        T(this, `maskFormat`, void 0),
        T(this, `cells`, void 0),
        T(this, `maskCells`, void 0),
        (this.format = t);
      var n = Li.map(function (e) {
          return `(${e})`;
        }).join(`|`),
        r = new RegExp(n, `g`);
      this.maskFormat = t.replace(r, function (e) {
        return Ri.repeat(e.length);
      });
      var i = RegExp(`(${Li.join(`|`)})`),
        a = (t.split(i) || []).filter(function (e) {
          return e;
        }),
        o = 0;
      (this.cells = a.map(function (e) {
        var t = Li.includes(e),
          n = o,
          r = o + e.length;
        return (o = r), { text: e, mask: t, start: n, end: r };
      })),
        (this.maskCells = this.cells.filter(function (e) {
          return e.mask;
        }));
    }
    return (
      ie(e, [
        {
          key: `getSelection`,
          value: function (e) {
            var t = this.maskCells[e] || {},
              n = t.start,
              r = t.end;
            return [n || 0, r || 0];
          },
        },
        {
          key: `match`,
          value: function (e) {
            for (var t = 0; t < this.maskFormat.length; t += 1) {
              var n = this.maskFormat[t],
                r = e[t];
              if (!r || (n !== Ri && n !== r)) return !1;
            }
            return !0;
          },
        },
        {
          key: `size`,
          value: function () {
            return this.maskCells.length;
          },
        },
        {
          key: `getMaskCellIndex`,
          value: function (e) {
            for (
              var t = 2 ** 53 - 1, n = 0, r = 0;
              r < this.maskCells.length;
              r += 1
            ) {
              var i = this.maskCells[r],
                a = i.start,
                o = i.end;
              if (e >= a && e <= o) return r;
              var s = Math.min(Math.abs(e - a), Math.abs(e - o));
              s < t && ((t = s), (n = r));
            }
            return n;
          },
        },
      ]),
      e
    );
  })();
function Bi(e) {
  return {
    YYYY: [0, 9999, new Date().getFullYear()],
    MM: [1, 12],
    DD: [1, 31],
    HH: [0, 23],
    mm: [0, 59],
    ss: [0, 59],
    SSS: [0, 999],
  }[e];
}
g(), D(), V(), te();
var Vi = [
    `active`,
    `showActiveCls`,
    `suffixIcon`,
    `format`,
    `validateFormat`,
    `onChange`,
    `onInput`,
    `helped`,
    `onHelp`,
    `onSubmit`,
    `onKeyDown`,
    `preserveInvalidOnBlur`,
    `invalid`,
    `clearIcon`,
  ],
  Hi = Z.forwardRef(function (e, t) {
    var n = e.active,
      r = e.showActiveCls,
      i = r === void 0 || r,
      a = e.suffixIcon,
      o = e.format,
      s = e.validateFormat,
      c = e.onChange;
    e.onInput;
    var l = e.helped,
      u = e.onHelp,
      d = e.onSubmit,
      f = e.onKeyDown,
      p = e.preserveInvalidOnBlur,
      m = p !== void 0 && p,
      h = e.invalid,
      g = e.clearIcon,
      y = re(e, Vi),
      b = e.value,
      x = e.onFocus,
      S = e.onBlur,
      C = e.onMouseUp,
      w = Z.useContext(zn),
      D = w.prefixCls,
      O = w.input,
      k = O === void 0 ? `input` : O,
      A = `${D}-input`,
      j = Z.useState(!1),
      M = z(j, 2),
      N = M[0],
      P = M[1],
      F = Z.useState(b),
      I = z(F, 2),
      L = I[0],
      R = I[1],
      ee = Z.useState(``),
      te = z(ee, 2),
      ne = te[0],
      B = te[1],
      V = Z.useState(null),
      ie = z(V, 2),
      H = ie[0],
      ae = ie[1],
      oe = Z.useState(null),
      se = z(oe, 2),
      ce = se[0],
      le = se[1],
      ue = L || ``;
    Z.useEffect(
      function () {
        R(b);
      },
      [b]
    );
    var de = Z.useRef(),
      fe = Z.useRef();
    Z.useImperativeHandle(t, function () {
      return {
        nativeElement: de.current,
        inputElement: fe.current,
        focus: function (e) {
          fe.current.focus(e);
        },
        blur: function () {
          fe.current.blur();
        },
      };
    });
    var pe = Z.useMemo(
        function () {
          return new zi(o || ``);
        },
        [o]
      ),
      me = Z.useMemo(
        function () {
          return l ? [0, 0] : pe.getSelection(H);
        },
        [pe, H, l]
      ),
      W = z(me, 2),
      G = W[0],
      he = W[1],
      K = function (e) {
        e && e !== o && e !== b && u();
      },
      ge = v(function (e) {
        s(e) && c(e), R(e), K(e);
      }),
      _e = function (e) {
        if (!o) {
          var t = e.target.value;
          K(t), R(t), c(t);
        }
      },
      ve = function (e) {
        var t = e.clipboardData.getData(`text`);
        s(t) && ge(t);
      },
      ye = Z.useRef(!1),
      be = function () {
        ye.current = !0;
      },
      xe = function (e) {
        var t = e.target.selectionStart;
        ae(pe.getMaskCellIndex(t)),
          le({}),
          C == null || C(e),
          (ye.current = !1);
      },
      q = function (e) {
        P(!0), ae(0), B(``), x(e);
      },
      Se = function (e) {
        S(e);
      },
      Ce = function (e) {
        P(!1), Se(e);
      };
    Fr(n, function () {
      !n && !m && R(b);
    });
    var we = function (e) {
        e.key === `Enter` && s(ue) && d(), f == null || f(e);
      },
      Te = function (e) {
        we(e);
        var t = e.key,
          n = null,
          r = null,
          i = he - G,
          a = o.slice(G, he),
          s = function (e) {
            ae(function (t) {
              var n = t + e;
              return (n = Math.max(n, 0)), (n = Math.min(n, pe.size() - 1)), n;
            });
          },
          c = function (e) {
            var t = Bi(a),
              n = z(t, 3),
              r = n[0],
              i = n[1],
              o = n[2],
              s = ue.slice(G, he),
              c = Number(s);
            if (isNaN(c)) return String(o || (e > 0 ? r : i));
            var l = c + e,
              u = i - r + 1;
            return String(r + ((u + l - r) % u));
          };
        switch (t) {
          case `Backspace`:
          case `Delete`:
            (n = ``), (r = a);
            break;
          case `ArrowLeft`:
            (n = ``), s(-1);
            break;
          case `ArrowRight`:
            (n = ``), s(1);
            break;
          case `ArrowUp`:
            (n = ``), (r = c(1));
            break;
          case `ArrowDown`:
            (n = ``), (r = c(-1));
            break;
          default:
            isNaN(Number(t)) || ((n = ne + t), (r = n));
        }
        n !== null && (B(n), n.length >= i && (s(1), B(``))),
          r !== null &&
            ge((ue.slice(0, G) + Hn(r, i) + ue.slice(he)).slice(0, o.length)),
          le({});
      },
      Ee = Z.useRef();
    E(
      function () {
        if (N && o && !ye.current) {
          if (!pe.match(ue)) ge(o);
          else
            return (
              fe.current.setSelectionRange(G, he),
              (Ee.current = U(function () {
                fe.current.setSelectionRange(G, he);
              })),
              function () {
                U.cancel(Ee.current);
              }
            );
        }
      },
      [pe, o, N, ue, H, G, he, ce, ge]
    );
    var De = o
      ? {
          onFocus: q,
          onBlur: Ce,
          onKeyDown: Te,
          onMouseDown: be,
          onMouseUp: xe,
          onPaste: ve,
        }
      : {};
    return Z.createElement(
      `div`,
      {
        ref: de,
        className: (0, Q.default)(
          A,
          T(T({}, `${A}-active`, n && i), `${A}-placeholder`, l)
        ),
      },
      Z.createElement(
        k,
        _(
          { ref: fe, "aria-invalid": h, autoComplete: `off` },
          y,
          { onKeyDown: we, onBlur: Se },
          De,
          { value: ue, onChange: _e }
        )
      ),
      Z.createElement(Fi, { type: `suffix`, icon: a }),
      g
    );
  });
g(), D(), V(), w(), te();
var Ui =
    `id.prefix.clearIcon.suffixIcon.separator.activeIndex.activeHelp.allHelp.focused.onFocus.onBlur.onKeyDown.locale.generateConfig.placeholder.className.style.onClick.onClear.value.onChange.onSubmit.onInputChange.format.maskFormat.preserveInvalidOnBlur.onInvalid.disabled.invalid.inputReadOnly.direction.onOpenChange.onActiveInfo.placement.onMouseDown.required.aria-required.autoFocus.tabIndex`.split(
      `.`
    ),
  Wi = [`index`];
function Gi(e, t) {
  var n = e.id,
    r = e.prefix,
    i = e.clearIcon,
    a = e.suffixIcon,
    o = e.separator,
    s = o === void 0 ? `~` : o,
    c = e.activeIndex;
  e.activeHelp, e.allHelp;
  var l = e.focused;
  e.onFocus, e.onBlur, e.onKeyDown, e.locale, e.generateConfig;
  var u = e.placeholder,
    d = e.className,
    f = e.style,
    p = e.onClick,
    m = e.onClear,
    h = e.value;
  e.onChange,
    e.onSubmit,
    e.onInputChange,
    e.format,
    e.maskFormat,
    e.preserveInvalidOnBlur,
    e.onInvalid;
  var g = e.disabled,
    y = e.invalid;
  e.inputReadOnly;
  var b = e.direction;
  e.onOpenChange;
  var x = e.onActiveInfo;
  e.placement;
  var C = e.onMouseDown;
  e.required, e[`aria-required`];
  var w = e.autoFocus,
    E = e.tabIndex,
    D = re(e, Ui),
    O = b === `rtl`,
    k = Z.useContext(zn).prefixCls,
    j = Z.useMemo(
      function () {
        if (typeof n == `string`) return [n];
        var e = n || {};
        return [e.start, e.end];
      },
      [n]
    ),
    M = Z.useRef(),
    N = Z.useRef(),
    P = Z.useRef(),
    F = function (e) {
      var t;
      return (t = [N, P][e]) == null ? void 0 : t.current;
    };
  Z.useImperativeHandle(t, function () {
    return {
      nativeElement: M.current,
      focus: function (e) {
        if (A(e) === `object`) {
          var t,
            n = e || {},
            r = n.index,
            i = r === void 0 ? 0 : r,
            a = re(n, Wi);
          (t = F(i)) == null || t.focus(a);
        } else {
          var o;
          (o = F(e ?? 0)) == null || o.focus();
        }
      },
      blur: function () {
        var e, t;
        (e = F(0)) == null || e.blur(), (t = F(1)) == null || t.blur();
      },
    };
  });
  var I = Mi(D),
    L = Z.useMemo(
      function () {
        return Array.isArray(u) ? u : [u, u];
      },
      [u]
    ),
    R = Ai(S(S({}, e), {}, { id: j, placeholder: L })),
    ee = z(R, 1)[0],
    te = Z.useState({ position: `absolute`, width: 0 }),
    ne = z(te, 2),
    B = ne[0],
    V = ne[1],
    ie = v(function () {
      var e = F(c);
      if (e) {
        var t = e.nativeElement.getBoundingClientRect(),
          n = M.current.getBoundingClientRect(),
          r = t.left - n.left;
        V(function (e) {
          return S(S({}, e), {}, { width: t.width, left: r });
        }),
          x([t.left, t.right, n.width]);
      }
    });
  Z.useEffect(
    function () {
      ie();
    },
    [c]
  );
  var H = i && ((h[0] && !g[0]) || (h[1] && !g[1])),
    ae = w && !g[0],
    oe = w && !ae && !g[1];
  return Z.createElement(
    le,
    { onResize: ie },
    Z.createElement(
      `div`,
      _({}, I, {
        className: (0, Q.default)(
          k,
          `${k}-range`,
          T(
            T(
              T(
                T({}, `${k}-focused`, l),
                `${k}-disabled`,
                g.every(function (e) {
                  return e;
                })
              ),
              `${k}-invalid`,
              y.some(function (e) {
                return e;
              })
            ),
            `${k}-rtl`,
            O
          ),
          d
        ),
        style: f,
        ref: M,
        onClick: p,
        onMouseDown: function (e) {
          var t = e.target;
          t !== N.current.inputElement &&
            t !== P.current.inputElement &&
            e.preventDefault(),
            C == null || C(e);
        },
      }),
      r && Z.createElement(`div`, { className: `${k}-prefix` }, r),
      Z.createElement(
        Hi,
        _({ ref: N }, ee(0), {
          autoFocus: ae,
          tabIndex: E,
          "date-range": `start`,
        })
      ),
      Z.createElement(`div`, { className: `${k}-range-separator` }, s),
      Z.createElement(
        Hi,
        _({ ref: P }, ee(1), {
          autoFocus: oe,
          tabIndex: E,
          "date-range": `end`,
        })
      ),
      Z.createElement(`div`, { className: `${k}-active-bar`, style: B }),
      Z.createElement(Fi, { type: `suffix`, icon: a }),
      H && Z.createElement(Ii, { icon: i, onClear: m })
    )
  );
}
var Ki = Z.forwardRef(Gi);
g(), I(), V();
function qi(e, t) {
  var n = e ?? t;
  return Array.isArray(n) ? n : [n, n];
}
function Ji(e) {
  return e === 1 ? `end` : `start`;
}
function Yi(e, t) {
  var n = Ar(e, function () {
      var t = e.disabled,
        n = e.allowEmpty;
      return { disabled: qi(t, !1), allowEmpty: qi(n, !1) };
    }),
    r = z(n, 6),
    i = r[0],
    a = r[1],
    o = r[2],
    s = r[3],
    c = r[4],
    l = r[5],
    u = i.prefixCls,
    d = i.styles,
    f = i.classNames,
    p = i.defaultValue,
    m = i.value,
    h = i.needConfirm,
    g = i.onKeyDown,
    y = i.disabled,
    b = i.allowEmpty,
    x = i.disabledDate,
    C = i.minDate,
    w = i.maxDate,
    T = i.defaultOpen,
    D = i.open,
    O = i.onOpenChange,
    k = i.locale,
    A = i.generateConfig,
    j = i.picker,
    M = i.showNow,
    N = i.showToday,
    P = i.showTime,
    F = i.mode,
    I = i.onPanelChange,
    R = i.onCalendarChange,
    ee = i.onOk,
    te = i.defaultPickerValue,
    ne = i.pickerValue,
    B = i.onPickerValueChange,
    re = i.inputReadOnly,
    V = i.suffixIcon,
    ie = i.onFocus,
    ae = i.onBlur,
    oe = i.presets,
    ce = i.ranges,
    U = i.components,
    le = i.cellRender,
    ue = i.dateRender,
    de = i.monthCellRender,
    fe = i.onClick,
    pe = Nr(t),
    me = Mr(D, T, y, O),
    W = z(me, 2),
    G = W[0],
    he = W[1],
    K = function (e, t) {
      (y.some(function (e) {
        return !e;
      }) ||
        !e) &&
        he(e, t);
    },
    ge = Kr(A, k, s, !0, !1, p, m, R, ee),
    _e = z(ge, 5),
    ve = _e[0],
    be = _e[1],
    xe = _e[2],
    q = _e[3],
    Se = _e[4],
    Ce = xe(),
    we = Ir(y, b, G),
    Te = z(we, 9),
    Ee = Te[0],
    De = Te[1],
    Oe = Te[2],
    J = Te[3],
    ke = Te[4],
    Ae = Te[5],
    je = Te[6],
    Me = Te[7],
    Ne = Te[8],
    Pe = function (e, t) {
      De(!0), ie == null || ie(e, { range: Ji(t ?? J) });
    },
    Fe = function (e, t) {
      De(!1), ae == null || ae(e, { range: Ji(t ?? J) });
    },
    Ie = Z.useMemo(
      function () {
        if (!P) return null;
        var e = P.disabledTime,
          t = e
            ? function (t) {
                return e(t, Ji(J), { from: qn(Ce, je, J) });
              }
            : void 0;
        return S(S({}, P), {}, { disabledTime: t });
      },
      [P, J, Ce, je]
    ),
    Le = H([j, j], { value: F }),
    Re = z(Le, 2),
    ze = Re[0],
    Be = Re[1],
    Ve = ze[J] || j,
    He = Ve === `date` && Ie ? `datetime` : Ve,
    Ue = He === j && He !== `time`,
    We = Jr(j, Ve, M, N, !0),
    Ge = qr(i, ve, be, xe, q, y, s, Ee, G, l),
    Ke = z(Ge, 2),
    qe = Ke[0],
    Je = Ke[1],
    Ye = Lr(Ce, y, je, A, k, x),
    Xe = Xn(Ce, l, b),
    Ze = z(Xe, 2),
    Qe = Ze[0],
    $e = Ze[1],
    et = Br(
      A,
      k,
      Ce,
      ze,
      G,
      J,
      a,
      Ue,
      te,
      ne,
      Ie == null ? void 0 : Ie.defaultOpenValue,
      B,
      C,
      w
    ),
    tt = z(et, 2),
    nt = tt[0],
    rt = tt[1],
    it = v(function (e, t, n) {
      var r = Wn(ze, J, t);
      if (((r[0] !== ze[0] || r[1] !== ze[1]) && Be(r), I && n !== !1)) {
        var i = L(Ce);
        e && (i[J] = e), I(i, r);
      }
    }),
    at = function (e, t) {
      return Wn(Ce, t, e);
    },
    ot = function (e, t) {
      var n = Ce;
      e && (n = at(e, J)), Me(J);
      var r = Ae(n);
      q(n),
        qe(J, r === null),
        r === null ? K(!1, { force: !0 }) : t || pe.current.focus({ index: r });
    },
    st = function (e) {
      var t = e.target.getRootNode();
      if (
        !pe.current.nativeElement.contains(
          t.activeElement ?? document.activeElement
        )
      ) {
        var n = y.findIndex(function (e) {
          return !e;
        });
        n >= 0 && pe.current.focus({ index: n });
      }
      K(!0), fe == null || fe(e);
    },
    ct = function () {
      Je(null), K(!1, { force: !0 });
    },
    lt = Z.useState(null),
    ut = z(lt, 2),
    dt = ut[0],
    ft = ut[1],
    pt = Z.useState(null),
    mt = z(pt, 2),
    ht = mt[0],
    gt = mt[1],
    _t = Z.useMemo(
      function () {
        return ht || Ce;
      },
      [Ce, ht]
    );
  Z.useEffect(
    function () {
      G || gt(null);
    },
    [G]
  );
  var vt = Z.useState([0, 0, 0]),
    yt = z(vt, 2),
    bt = yt[0],
    xt = yt[1],
    St = Pr(oe, ce),
    Ct = function (e) {
      gt(e), ft(`preset`);
    },
    wt = function (e) {
      Je(e) && K(!1, { force: !0 });
    },
    Y = function (e) {
      ot(e);
    },
    X = function (e) {
      gt(e ? at(e, J) : null), ft(`cell`);
    },
    Tt = function (e) {
      K(!0), Pe(e);
    },
    Et = function () {
      Oe(`panel`);
    },
    Dt = function (e) {
      q(Wn(Ce, J, e)), !h && !o && a === He && ot(e);
    },
    Ot = function () {
      K(!1);
    },
    kt = Yn(le, ue, de, Ji(J)),
    At = Ce[J] || null,
    jt = v(function (e) {
      return l(e, { activeIndex: J });
    }),
    Mt = Z.useMemo(
      function () {
        var e = ye(i, !1);
        return se(
          i,
          [].concat(L(Object.keys(e)), [
            `onChange`,
            `onCalendarChange`,
            `style`,
            `className`,
            `onPanelChange`,
            `disabledTime`,
          ])
        );
      },
      [i]
    ),
    Nt = Z.createElement(
      ki,
      _({}, Mt, {
        showNow: We,
        showTime: Ie,
        range: !0,
        multiplePanel: Ue,
        activeInfo: bt,
        disabledDate: Ye,
        onFocus: Tt,
        onBlur: Fe,
        onPanelMouseDown: Et,
        picker: j,
        mode: Ve,
        internalMode: He,
        onPanelChange: it,
        format: c,
        value: At,
        isInvalid: jt,
        onChange: null,
        onSelect: Dt,
        pickerValue: nt,
        defaultOpenValue: Un(P == null ? void 0 : P.defaultOpenValue)[J],
        onPickerValueChange: rt,
        hoverValue: _t,
        onHover: X,
        needConfirm: h,
        onSubmit: ot,
        onOk: Se,
        presets: St,
        onPresetHover: Ct,
        onPresetSubmit: wt,
        onNow: Y,
        cellRender: kt,
      })
    ),
    Pt = function (e, t) {
      q(at(e, t));
    },
    Ft = function () {
      Oe(`input`);
    },
    It = function (e, t) {
      var n = je.length,
        r = je[n - 1];
      n && r !== t && h && !b[r] && !Ne(r) && Ce[r]
        ? pe.current.focus({ index: r })
        : (Oe(`input`),
          K(!0, { inherit: !0 }),
          J !== t && G && !h && o && ot(null, !0),
          ke(t),
          Pe(e, t));
    },
    Lt = function (e, t) {
      K(!1), !h && Oe() === `input` && qe(J, Ae(Ce) === null), Fe(e, t);
    },
    Rt = function (e, t) {
      e.key === `Tab` && ot(null, !0), g == null || g(e, t);
    },
    zt = Z.useMemo(
      function () {
        return {
          prefixCls: u,
          locale: k,
          generateConfig: A,
          button: U.button,
          input: U.input,
        };
      },
      [u, k, A, U.button, U.input]
    );
  return (
    E(
      function () {
        G && J !== void 0 && it(null, j, !1);
      },
      [G, J, j]
    ),
    E(
      function () {
        var e = Oe();
        !G && e === `input` && (K(!1), ot(null, !0)),
          !G && o && !h && e === `panel` && (K(!0), ot());
      },
      [G]
    ),
    Z.createElement(
      zn.Provider,
      { value: zt },
      Z.createElement(
        Vn,
        _({}, Jn(i), {
          popupElement: Nt,
          popupStyle: d.popup,
          popupClassName: f.popup,
          visible: G,
          onClose: Ot,
          range: !0,
        }),
        Z.createElement(
          Ki,
          _({}, i, {
            ref: pe,
            suffixIcon: V,
            activeIndex: Ee || G ? J : null,
            activeHelp: !!ht,
            allHelp: !!ht && dt === `preset`,
            focused: Ee,
            onFocus: It,
            onBlur: Lt,
            onKeyDown: Rt,
            onSubmit: ot,
            value: _t,
            maskFormat: c,
            onChange: Pt,
            onInputChange: Ft,
            format: s,
            inputReadOnly: re,
            disabled: y,
            open: G,
            onOpenChange: K,
            onClick: st,
            onClear: ct,
            invalid: Qe,
            onInvalid: $e,
            onActiveInfo: xt,
          })
        )
      )
    )
  );
}
var Xi = Z.forwardRef(Yi);
function Zi(e) {
  var t = e.prefixCls,
    n = e.value,
    r = e.onRemove,
    i = e.removeIcon,
    a = i === void 0 ? `×` : i,
    o = e.formatDate,
    s = e.disabled,
    c = e.maxTagCount,
    l = e.placeholder,
    u = `${t}-selector`,
    d = `${t}-selection`,
    f = `${d}-overflow`;
  function p(e, t) {
    return Z.createElement(
      `span`,
      {
        className: (0, Q.default)(`${d}-item`),
        title: typeof e == `string` ? e : null,
      },
      Z.createElement(`span`, { className: `${d}-item-content` }, e),
      !s &&
        t &&
        Z.createElement(
          `span`,
          {
            onMouseDown: function (e) {
              e.preventDefault();
            },
            onClick: t,
            className: `${d}-item-remove`,
          },
          a
        )
    );
  }
  function m(e) {
    return p(o(e), function (t) {
      t && t.stopPropagation(), r(e);
    });
  }
  function h(e) {
    return p(`+ ${e.length} ...`);
  }
  return Z.createElement(
    `div`,
    { className: u },
    Z.createElement(ke, {
      prefixCls: f,
      data: n,
      renderItem: m,
      renderRest: h,
      itemKey: function (e) {
        return o(e);
      },
      maxCount: c,
    }),
    !n.length &&
      Z.createElement(`span`, { className: `${t}-selection-placeholder` }, l)
  );
}
D(), g(), V(), te();
var Qi =
  `id.open.prefix.clearIcon.suffixIcon.activeHelp.allHelp.focused.onFocus.onBlur.onKeyDown.locale.generateConfig.placeholder.className.style.onClick.onClear.internalPicker.value.onChange.onSubmit.onInputChange.multiple.maxTagCount.format.maskFormat.preserveInvalidOnBlur.onInvalid.disabled.invalid.inputReadOnly.direction.onOpenChange.onMouseDown.required.aria-required.autoFocus.tabIndex.removeIcon`.split(
    `.`
  );
function $i(e, t) {
  e.id;
  var n = e.open,
    r = e.prefix,
    i = e.clearIcon,
    a = e.suffixIcon;
  e.activeHelp, e.allHelp;
  var o = e.focused;
  e.onFocus, e.onBlur, e.onKeyDown;
  var s = e.locale,
    c = e.generateConfig,
    l = e.placeholder,
    u = e.className,
    d = e.style,
    f = e.onClick,
    p = e.onClear,
    m = e.internalPicker,
    h = e.value,
    g = e.onChange,
    v = e.onSubmit;
  e.onInputChange;
  var y = e.multiple,
    b = e.maxTagCount;
  e.format, e.maskFormat, e.preserveInvalidOnBlur, e.onInvalid;
  var x = e.disabled,
    C = e.invalid;
  e.inputReadOnly;
  var w = e.direction;
  e.onOpenChange;
  var E = e.onMouseDown;
  e.required, e[`aria-required`];
  var D = e.autoFocus,
    O = e.tabIndex,
    k = e.removeIcon,
    A = re(e, Qi),
    j = w === `rtl`,
    M = Z.useContext(zn).prefixCls,
    N = Z.useRef(),
    P = Z.useRef();
  Z.useImperativeHandle(t, function () {
    return {
      nativeElement: N.current,
      focus: function (e) {
        var t;
        (t = P.current) == null || t.focus(e);
      },
      blur: function () {
        var e;
        (e = P.current) == null || e.blur();
      },
    };
  });
  var F = Mi(A),
    I = function (e) {
      g([e]);
    },
    L = function (e) {
      g(
        h.filter(function (t) {
          return t && !yr(c, s, t, e, m);
        })
      ),
        n || v();
    },
    R = Ai(S(S({}, e), {}, { onChange: I }), function (e) {
      return { value: e.valueTexts[0] || ``, active: o };
    }),
    ee = z(R, 2),
    te = ee[0],
    ne = ee[1],
    B = !!(i && h.length && !x),
    V = y
      ? Z.createElement(
          Z.Fragment,
          null,
          Z.createElement(Zi, {
            prefixCls: M,
            value: h,
            onRemove: L,
            formatDate: ne,
            maxTagCount: b,
            disabled: x,
            removeIcon: k,
            placeholder: l,
          }),
          Z.createElement(`input`, {
            className: `${M}-multiple-input`,
            value: h.map(ne).join(`,`),
            ref: P,
            readOnly: !0,
            autoFocus: D,
            tabIndex: O,
          }),
          Z.createElement(Fi, { type: `suffix`, icon: a }),
          B && Z.createElement(Ii, { icon: i, onClear: p })
        )
      : Z.createElement(
          Hi,
          _({ ref: P }, te(), {
            autoFocus: D,
            tabIndex: O,
            suffixIcon: a,
            clearIcon: B && Z.createElement(Ii, { icon: i, onClear: p }),
            showActiveCls: !1,
          })
        );
  return Z.createElement(
    `div`,
    _({}, F, {
      className: (0, Q.default)(
        M,
        T(
          T(
            T(
              T(T({}, `${M}-multiple`, y), `${M}-focused`, o),
              `${M}-disabled`,
              x
            ),
            `${M}-invalid`,
            C
          ),
          `${M}-rtl`,
          j
        ),
        u
      ),
      style: d,
      ref: N,
      onClick: f,
      onMouseDown: function (e) {
        var t;
        e.target !== ((t = P.current) == null ? void 0 : t.inputElement) &&
          e.preventDefault(),
          E == null || E(e);
      },
    }),
    r && Z.createElement(`div`, { className: `${M}-prefix` }, r),
    V
  );
}
var ea = Z.forwardRef($i);
g(), I(), V();
function ta(e, t) {
  var n = Ar(e),
    r = z(n, 6),
    i = r[0],
    a = r[1],
    o = r[2],
    s = r[3],
    c = r[4],
    l = r[5],
    u = i,
    d = u.prefixCls,
    f = u.styles,
    p = u.classNames,
    m = u.order,
    h = u.defaultValue,
    g = u.value,
    y = u.needConfirm,
    b = u.onChange,
    x = u.onKeyDown,
    C = u.disabled,
    w = u.disabledDate,
    T = u.minDate,
    D = u.maxDate,
    O = u.defaultOpen,
    k = u.open,
    A = u.onOpenChange,
    j = u.locale,
    M = u.generateConfig,
    N = u.picker,
    P = u.showNow,
    F = u.showToday,
    I = u.showTime,
    R = u.mode,
    ee = u.onPanelChange,
    te = u.onCalendarChange,
    ne = u.onOk,
    B = u.multiple,
    re = u.defaultPickerValue,
    V = u.pickerValue,
    ie = u.onPickerValueChange,
    ae = u.inputReadOnly,
    oe = u.suffixIcon,
    ce = u.removeIcon,
    U = u.onFocus,
    le = u.onBlur,
    ue = u.presets,
    de = u.components,
    fe = u.cellRender,
    pe = u.dateRender,
    me = u.monthCellRender,
    W = u.onClick,
    G = Nr(t);
  function he(e) {
    return e === null ? null : B ? e : e[0];
  }
  var K = ei(M, j, a),
    ge = Mr(k, O, [C], A),
    _e = z(ge, 2),
    ve = _e[0],
    be = _e[1],
    xe = Kr(
      M,
      j,
      s,
      !1,
      m,
      h,
      g,
      function (e, t, n) {
        if (te) {
          var r = S({}, n);
          delete r.range, te(he(e), he(t), r);
        }
      },
      function (e) {
        ne == null || ne(he(e));
      }
    ),
    q = z(xe, 5),
    Se = q[0],
    Ce = q[1],
    we = q[2],
    Te = q[3],
    Ee = q[4],
    De = we(),
    Oe = Ir([C]),
    J = z(Oe, 4),
    ke = J[0],
    Ae = J[1],
    je = J[2],
    Me = J[3],
    Ne = function (e) {
      Ae(!0), U == null || U(e, {});
    },
    Pe = function (e) {
      Ae(!1), le == null || le(e, {});
    },
    Fe = H(N, { value: R }),
    Ie = z(Fe, 2),
    Le = Ie[0],
    Re = Ie[1],
    ze = Le === `date` && I ? `datetime` : Le,
    Be = Jr(N, Le, P, F),
    Ve =
      b &&
      function (e, t) {
        b(he(e), he(t));
      },
    He = qr(
      S(S({}, i), {}, { onChange: Ve }),
      Se,
      Ce,
      we,
      Te,
      [],
      s,
      ke,
      ve,
      l
    ),
    Ue = z(He, 2)[1],
    We = Xn(De, l),
    Ge = z(We, 2),
    Ke = Ge[0],
    qe = Ge[1],
    Je = Z.useMemo(
      function () {
        return Ke.some(function (e) {
          return e;
        });
      },
      [Ke]
    ),
    Ye = Br(
      M,
      j,
      De,
      [Le],
      ve,
      Me,
      a,
      !1,
      re,
      V,
      Un(I == null ? void 0 : I.defaultOpenValue),
      function (e, t) {
        if (ie) {
          var n = S(S({}, t), {}, { mode: t.mode[0] });
          delete n.range, ie(e[0], n);
        }
      },
      T,
      D
    ),
    Xe = z(Ye, 2),
    Ze = Xe[0],
    Qe = Xe[1],
    $e = v(function (e, t, n) {
      Re(t), ee && n !== !1 && ee(e || De[De.length - 1], t);
    }),
    et = function () {
      Ue(we()), be(!1, { force: !0 });
    },
    tt = function (e) {
      !C &&
        !G.current.nativeElement.contains(document.activeElement) &&
        G.current.focus(),
        be(!0),
        W == null || W(e);
    },
    nt = function () {
      Ue(null), be(!1, { force: !0 });
    },
    rt = Z.useState(null),
    it = z(rt, 2),
    at = it[0],
    ot = it[1],
    st = Z.useState(null),
    ct = z(st, 2),
    lt = ct[0],
    ut = ct[1],
    dt = Z.useMemo(
      function () {
        var e = [lt].concat(L(De)).filter(function (e) {
          return e;
        });
        return B ? e : e.slice(0, 1);
      },
      [De, lt, B]
    ),
    ft = Z.useMemo(
      function () {
        return !B && lt
          ? [lt]
          : De.filter(function (e) {
              return e;
            });
      },
      [De, lt, B]
    );
  Z.useEffect(
    function () {
      ve || ut(null);
    },
    [ve]
  );
  var pt = Pr(ue),
    mt = function (e) {
      ut(e), ot(`preset`);
    },
    ht = function (e) {
      Ue(B ? K(we(), e) : [e]) && !B && be(!1, { force: !0 });
    },
    gt = function (e) {
      ht(e);
    },
    _t = function (e) {
      ut(e), ot(`cell`);
    },
    vt = function (e) {
      be(!0), Ne(e);
    },
    yt = function (e) {
      je(`panel`),
        !(B && ze !== N) &&
          (Te(B ? K(we(), e) : [e]), !y && !o && a === ze && et());
    },
    bt = function () {
      be(!1);
    },
    xt = Yn(fe, pe, me),
    St = Z.useMemo(
      function () {
        var e = ye(i, !1),
          t = se(
            i,
            [].concat(L(Object.keys(e)), [
              `onChange`,
              `onCalendarChange`,
              `style`,
              `className`,
              `onPanelChange`,
            ])
          );
        return S(S({}, t), {}, { multiple: i.multiple });
      },
      [i]
    ),
    Ct = Z.createElement(
      ki,
      _({}, St, {
        showNow: Be,
        showTime: I,
        disabledDate: w,
        onFocus: vt,
        onBlur: Pe,
        picker: N,
        mode: Le,
        internalMode: ze,
        onPanelChange: $e,
        format: c,
        value: De,
        isInvalid: l,
        onChange: null,
        onSelect: yt,
        pickerValue: Ze,
        defaultOpenValue: I == null ? void 0 : I.defaultOpenValue,
        onPickerValueChange: Qe,
        hoverValue: dt,
        onHover: _t,
        needConfirm: y,
        onSubmit: et,
        onOk: Ee,
        presets: pt,
        onPresetHover: mt,
        onPresetSubmit: ht,
        onNow: gt,
        cellRender: xt,
      })
    ),
    wt = function (e) {
      Te(e);
    },
    Y = function () {
      je(`input`);
    },
    X = function (e) {
      je(`input`), be(!0, { inherit: !0 }), Ne(e);
    },
    Tt = function (e) {
      be(!1), Pe(e);
    },
    Et = function (e, t) {
      e.key === `Tab` && et(), x == null || x(e, t);
    },
    Dt = Z.useMemo(
      function () {
        return {
          prefixCls: d,
          locale: j,
          generateConfig: M,
          button: de.button,
          input: de.input,
        };
      },
      [d, j, M, de.button, de.input]
    );
  return (
    E(
      function () {
        ve && Me !== void 0 && $e(null, N, !1);
      },
      [ve, Me, N]
    ),
    E(
      function () {
        var e = je();
        !ve && e === `input` && (be(!1), et()),
          !ve && o && !y && e === `panel` && et();
      },
      [ve]
    ),
    Z.createElement(
      zn.Provider,
      { value: Dt },
      Z.createElement(
        Vn,
        _({}, Jn(i), {
          popupElement: Ct,
          popupStyle: f.popup,
          popupClassName: p.popup,
          visible: ve,
          onClose: bt,
        }),
        Z.createElement(
          ea,
          _({}, i, {
            ref: G,
            suffixIcon: oe,
            removeIcon: ce,
            activeHelp: !!lt,
            allHelp: !!lt && at === `preset`,
            focused: ke,
            onFocus: X,
            onBlur: Tt,
            onKeyDown: Et,
            onSubmit: et,
            value: ft,
            maskFormat: c,
            onChange: wt,
            onInputChange: Y,
            internalPicker: a,
            format: s,
            inputReadOnly: ae,
            disabled: C,
            open: ve,
            onOpenChange: be,
            onClick: tt,
            onClear: nt,
            invalid: Je,
            onInvalid: function (e) {
              qe(e, 0);
            },
          })
        )
      )
    )
  );
}
var na = Z.forwardRef(ta),
  ra = (e, t) => {
    let { componentCls: n, controlHeight: r } = e,
      i = t ? `${n}-${t}` : ``,
      a = Me(e);
    return [
      {
        [`${n}-multiple${i}`]: {
          paddingBlock: a.containerPadding,
          paddingInlineStart: a.basePadding,
          minHeight: r,
          [`${n}-selection-item`]: {
            height: a.itemHeight,
            lineHeight: j(a.itemLineHeight),
          },
        },
      },
    ];
  },
  ia = (e) => {
    let { componentCls: t, calc: n, lineWidth: r } = e,
      i = P(e, {
        fontHeight: e.fontSize,
        selectHeight: e.controlHeightSM,
        multipleSelectItemHeight: e.multipleItemHeightSM,
        borderRadius: e.borderRadiusSM,
        borderRadiusSM: e.borderRadiusXS,
        controlHeight: e.controlHeightSM,
      }),
      a = P(e, {
        fontHeight: n(e.multipleItemHeightLG).sub(n(r).mul(2).equal()).equal(),
        fontSize: e.fontSizeLG,
        selectHeight: e.controlHeightLG,
        multipleSelectItemHeight: e.multipleItemHeightLG,
        borderRadius: e.borderRadiusLG,
        borderRadiusSM: e.borderRadius,
        controlHeight: e.controlHeightLG,
      });
    return [
      ra(i, `small`),
      ra(e),
      ra(a, `large`),
      {
        [`${t}${t}-multiple`]: Object.assign(
          Object.assign(
            {
              width: `100%`,
              cursor: `text`,
              [`${t}-selector`]: {
                flex: `auto`,
                padding: 0,
                position: `relative`,
                "&:after": { margin: 0 },
                [`${t}-selection-placeholder`]: {
                  position: `absolute`,
                  top: `50%`,
                  insetInlineStart: e.inputPaddingHorizontalBase,
                  insetInlineEnd: 0,
                  transform: `translateY(-50%)`,
                  transition: `all ${e.motionDurationSlow}`,
                  overflow: `hidden`,
                  whiteSpace: `nowrap`,
                  textOverflow: `ellipsis`,
                  flex: 1,
                  color: e.colorTextPlaceholder,
                  pointerEvents: `none`,
                },
              },
            },
            Pe(e)
          ),
          {
            [`${t}-multiple-input`]: {
              width: 0,
              height: 0,
              border: 0,
              visibility: `hidden`,
              position: `absolute`,
              zIndex: -1,
            },
          }
        ),
      },
    ];
  },
  aa = (e) => {
    let {
      pickerCellCls: t,
      pickerCellInnerCls: n,
      cellHeight: r,
      borderRadiusSM: i,
      motionDurationMid: a,
      cellHoverBg: o,
      lineWidth: s,
      lineType: c,
      colorPrimary: l,
      cellActiveWithRangeBg: u,
      colorTextLightSolid: d,
      colorTextDisabled: f,
      cellBgDisabled: p,
      colorFillSecondary: m,
    } = e;
    return {
      "&::before": {
        position: `absolute`,
        top: `50%`,
        insetInlineStart: 0,
        insetInlineEnd: 0,
        zIndex: 1,
        height: r,
        transform: `translateY(-50%)`,
        content: `""`,
        pointerEvents: `none`,
      },
      [n]: {
        position: `relative`,
        zIndex: 2,
        display: `inline-block`,
        minWidth: r,
        height: r,
        lineHeight: j(r),
        borderRadius: i,
        transition: `background ${a}`,
      },
      [`&:hover:not(${t}-in-view):not(${t}-disabled),
    &:hover:not(${t}-selected):not(${t}-range-start):not(${t}-range-end):not(${t}-disabled)`]:
        { [n]: { background: o } },
      [`&-in-view${t}-today ${n}`]: {
        "&::before": {
          position: `absolute`,
          top: 0,
          insetInlineEnd: 0,
          bottom: 0,
          insetInlineStart: 0,
          zIndex: 1,
          border: `${j(s)} ${c} ${l}`,
          borderRadius: i,
          content: `""`,
        },
      },
      [`&-in-view${t}-in-range,
      &-in-view${t}-range-start,
      &-in-view${t}-range-end`]: {
        position: `relative`,
        [`&:not(${t}-disabled):before`]: { background: u },
      },
      [`&-in-view${t}-selected,
      &-in-view${t}-range-start,
      &-in-view${t}-range-end`]: {
        [`&:not(${t}-disabled) ${n}`]: { color: d, background: l },
        [`&${t}-disabled ${n}`]: { background: m },
      },
      [`&-in-view${t}-range-start:not(${t}-disabled):before`]: {
        insetInlineStart: `50%`,
      },
      [`&-in-view${t}-range-end:not(${t}-disabled):before`]: {
        insetInlineEnd: `50%`,
      },
      [`&-in-view${t}-range-start:not(${t}-range-end) ${n}`]: {
        borderStartStartRadius: i,
        borderEndStartRadius: i,
        borderStartEndRadius: 0,
        borderEndEndRadius: 0,
      },
      [`&-in-view${t}-range-end:not(${t}-range-start) ${n}`]: {
        borderStartStartRadius: 0,
        borderEndStartRadius: 0,
        borderStartEndRadius: i,
        borderEndEndRadius: i,
      },
      "&-disabled": {
        color: f,
        cursor: `not-allowed`,
        [n]: { background: `transparent` },
        "&::before": { background: p },
      },
      [`&-disabled${t}-today ${n}::before`]: { borderColor: f },
    };
  },
  oa = (e) => {
    let {
        componentCls: t,
        pickerCellCls: n,
        pickerCellInnerCls: r,
        pickerYearMonthCellWidth: i,
        pickerControlIconSize: a,
        cellWidth: o,
        paddingSM: s,
        paddingXS: c,
        paddingXXS: l,
        colorBgContainer: u,
        lineWidth: d,
        lineType: f,
        borderRadiusLG: p,
        colorPrimary: m,
        colorTextHeading: h,
        colorSplit: g,
        pickerControlIconBorderWidth: _,
        colorIcon: v,
        textHeight: y,
        motionDurationMid: b,
        colorIconHover: x,
        fontWeightStrong: S,
        cellHeight: w,
        pickerCellPaddingVertical: T,
        colorTextDisabled: E,
        colorText: D,
        fontSize: O,
        motionDurationSlow: k,
        withoutTimeCellHeight: A,
        pickerQuarterPanelContentHeight: M,
        borderRadiusSM: N,
        colorTextLightSolid: P,
        cellHoverBg: F,
        timeColumnHeight: I,
        timeColumnWidth: L,
        timeCellHeight: R,
        controlItemBgActive: z,
        marginXXS: ee,
        pickerDatePanelPaddingHorizontal: te,
        pickerControlIconMargin: ne,
      } = e,
      B = e.calc(o).mul(7).add(e.calc(te).mul(2)).equal();
    return {
      [t]: {
        "&-panel": {
          display: `inline-flex`,
          flexDirection: `column`,
          textAlign: `center`,
          background: u,
          borderRadius: p,
          outline: `none`,
          "&-focused": { borderColor: m },
          "&-rtl": {
            [`${t}-prev-icon,
              ${t}-super-prev-icon`]: { transform: `rotate(45deg)` },
            [`${t}-next-icon,
              ${t}-super-next-icon`]: { transform: `rotate(-135deg)` },
            [`${t}-time-panel`]: {
              [`${t}-content`]: {
                direction: `ltr`,
                "> *": { direction: `rtl` },
              },
            },
          },
        },
        "&-decade-panel,\n        &-year-panel,\n        &-quarter-panel,\n        &-month-panel,\n        &-week-panel,\n        &-date-panel,\n        &-time-panel":
          { display: `flex`, flexDirection: `column`, width: B },
        "&-header": {
          display: `flex`,
          padding: `0 ${j(c)}`,
          color: h,
          borderBottom: `${j(d)} ${f} ${g}`,
          "> *": { flex: `none` },
          button: {
            padding: 0,
            color: v,
            lineHeight: j(y),
            background: `transparent`,
            border: 0,
            cursor: `pointer`,
            transition: `color ${b}`,
            fontSize: `inherit`,
            display: `inline-flex`,
            alignItems: `center`,
            justifyContent: `center`,
            "&:empty": { display: `none` },
          },
          "> button": {
            minWidth: `1.6em`,
            fontSize: O,
            "&:hover": { color: x },
            "&:disabled": { opacity: 0.25, pointerEvents: `none` },
          },
          "&-view": {
            flex: `auto`,
            fontWeight: S,
            lineHeight: j(y),
            "> button": {
              color: `inherit`,
              fontWeight: `inherit`,
              verticalAlign: `top`,
              "&:not(:first-child)": { marginInlineStart: c },
              "&:hover": { color: m },
            },
          },
        },
        "&-prev-icon,\n        &-next-icon,\n        &-super-prev-icon,\n        &-super-next-icon":
          {
            position: `relative`,
            width: a,
            height: a,
            "&::before": {
              position: `absolute`,
              top: 0,
              insetInlineStart: 0,
              width: a,
              height: a,
              border: `0 solid currentcolor`,
              borderBlockStartWidth: _,
              borderInlineStartWidth: _,
              content: `""`,
            },
          },
        "&-super-prev-icon,\n        &-super-next-icon": {
          "&::after": {
            position: `absolute`,
            top: ne,
            insetInlineStart: ne,
            display: `inline-block`,
            width: a,
            height: a,
            border: `0 solid currentcolor`,
            borderBlockStartWidth: _,
            borderInlineStartWidth: _,
            content: `""`,
          },
        },
        "&-prev-icon, &-super-prev-icon": { transform: `rotate(-45deg)` },
        "&-next-icon, &-super-next-icon": { transform: `rotate(135deg)` },
        "&-content": {
          width: `100%`,
          tableLayout: `fixed`,
          borderCollapse: `collapse`,
          "th, td": { position: `relative`, minWidth: w, fontWeight: `normal` },
          th: {
            height: e.calc(w).add(e.calc(T).mul(2)).equal(),
            color: D,
            verticalAlign: `middle`,
          },
        },
        "&-cell": Object.assign(
          {
            padding: `${j(T)} 0`,
            color: E,
            cursor: `pointer`,
            "&-in-view": { color: D },
          },
          aa(e)
        ),
        "&-decade-panel,\n        &-year-panel,\n        &-quarter-panel,\n        &-month-panel":
          {
            [`${t}-content`]: { height: e.calc(A).mul(4).equal() },
            [r]: { padding: `0 ${j(c)}` },
          },
        "&-quarter-panel": { [`${t}-content`]: { height: M } },
        "&-decade-panel": {
          [r]: { padding: `0 ${j(e.calc(c).div(2).equal())}` },
          [`${t}-cell::before`]: { display: `none` },
        },
        "&-year-panel,\n        &-quarter-panel,\n        &-month-panel": {
          [`${t}-body`]: { padding: `0 ${j(c)}` },
          [r]: { width: i },
        },
        "&-date-panel": {
          [`${t}-body`]: { padding: `${j(c)} ${j(te)}` },
          [`${t}-content th`]: { boxSizing: `border-box`, padding: 0 },
        },
        "&-week-panel-row": {
          td: {
            "&:before": { transition: `background ${b}` },
            "&:first-child:before": {
              borderStartStartRadius: N,
              borderEndStartRadius: N,
            },
            "&:last-child:before": {
              borderStartEndRadius: N,
              borderEndEndRadius: N,
            },
          },
          "&:hover td:before": { background: F },
          "&-range-start td, &-range-end td, &-selected td, &-hover td": {
            [`&${n}`]: {
              "&:before": { background: m },
              [`&${t}-cell-week`]: { color: new C(P).setA(0.5).toHexString() },
              [r]: { color: P },
            },
          },
          "&-range-hover td:before": { background: z },
        },
        "&-week-panel, &-date-panel-show-week": {
          [`${t}-body`]: { padding: `${j(c)} ${j(s)}` },
          [`${t}-content th`]: { width: `auto` },
        },
        "&-datetime-panel": {
          display: `flex`,
          [`${t}-time-panel`]: { borderInlineStart: `${j(d)} ${f} ${g}` },
          [`${t}-date-panel,
          ${t}-time-panel`]: { transition: `opacity ${k}` },
          "&-active": {
            [`${t}-date-panel,
            ${t}-time-panel`]: { opacity: 0.3, "&-active": { opacity: 1 } },
          },
        },
        "&-time-panel": {
          width: `auto`,
          minWidth: `auto`,
          [`${t}-content`]: { display: `flex`, flex: `auto`, height: I },
          "&-column": {
            flex: `1 0 auto`,
            width: L,
            margin: `${j(l)} 0`,
            padding: 0,
            overflowY: `hidden`,
            textAlign: `start`,
            listStyle: `none`,
            transition: `background ${b}`,
            overflowX: `hidden`,
            "&::-webkit-scrollbar": {
              width: 8,
              backgroundColor: `transparent`,
            },
            "&::-webkit-scrollbar-thumb": {
              backgroundColor: e.colorTextTertiary,
              borderRadius: e.borderRadiusSM,
            },
            "&": {
              scrollbarWidth: `thin`,
              scrollbarColor: `${e.colorTextTertiary} transparent`,
            },
            "&::after": {
              display: `block`,
              height: `calc(100% - ${j(R)})`,
              content: `""`,
            },
            "&:not(:first-child)": { borderInlineStart: `${j(d)} ${f} ${g}` },
            "&-active": { background: new C(z).setA(0.2).toHexString() },
            "&:hover": { overflowY: `auto` },
            "> li": {
              margin: 0,
              padding: 0,
              [`&${t}-time-panel-cell`]: {
                marginInline: ee,
                [`${t}-time-panel-cell-inner`]: {
                  display: `block`,
                  width: e.calc(L).sub(e.calc(ee).mul(2)).equal(),
                  height: R,
                  margin: 0,
                  paddingBlock: 0,
                  paddingInlineEnd: 0,
                  paddingInlineStart: e.calc(L).sub(R).div(2).equal(),
                  color: D,
                  lineHeight: j(R),
                  borderRadius: N,
                  cursor: `pointer`,
                  transition: `background ${b}`,
                  "&:hover": { background: F },
                },
                "&-selected": {
                  [`${t}-time-panel-cell-inner`]: { background: z },
                },
                "&-disabled": {
                  [`${t}-time-panel-cell-inner`]: {
                    color: E,
                    background: `transparent`,
                    cursor: `not-allowed`,
                  },
                },
              },
            },
          },
        },
      },
    };
  },
  sa = (e) => {
    let {
      componentCls: t,
      textHeight: n,
      lineWidth: r,
      paddingSM: i,
      antCls: a,
      colorPrimary: o,
      cellActiveWithRangeBg: s,
      colorPrimaryBorder: c,
      lineType: l,
      colorSplit: u,
    } = e;
    return {
      [`${t}-dropdown`]: {
        [`${t}-footer`]: {
          borderTop: `${j(r)} ${l} ${u}`,
          "&-extra": {
            padding: `0 ${j(i)}`,
            lineHeight: j(e.calc(n).sub(e.calc(r).mul(2)).equal()),
            textAlign: `start`,
            "&:not(:last-child)": { borderBottom: `${j(r)} ${l} ${u}` },
          },
        },
        [`${t}-panels + ${t}-footer ${t}-ranges`]: {
          justifyContent: `space-between`,
        },
        [`${t}-ranges`]: {
          marginBlock: 0,
          paddingInline: j(i),
          overflow: `hidden`,
          textAlign: `start`,
          listStyle: `none`,
          display: `flex`,
          justifyContent: `center`,
          alignItems: `center`,
          "> li": {
            lineHeight: j(e.calc(n).sub(e.calc(r).mul(2)).equal()),
            display: `inline-block`,
          },
          [`${t}-now-btn-disabled`]: {
            pointerEvents: `none`,
            color: e.colorTextDisabled,
          },
          [`${t}-preset > ${a}-tag-blue`]: {
            color: o,
            background: s,
            borderColor: c,
            cursor: `pointer`,
          },
          [`${t}-ok`]: {
            paddingBlock: e.calc(r).mul(2).equal(),
            marginInlineStart: `auto`,
          },
        },
      },
    };
  },
  ca = (e) => {
    let { componentCls: t, controlHeightLG: n, paddingXXS: r, padding: i } = e;
    return {
      pickerCellCls: `${t}-cell`,
      pickerCellInnerCls: `${t}-cell-inner`,
      pickerYearMonthCellWidth: e.calc(n).mul(1.5).equal(),
      pickerQuarterPanelContentHeight: e.calc(n).mul(1.4).equal(),
      pickerCellPaddingVertical: e.calc(r).add(e.calc(r).div(2)).equal(),
      pickerCellBorderGap: 2,
      pickerControlIconSize: 7,
      pickerControlIconMargin: 4,
      pickerControlIconBorderWidth: 1.5,
      pickerDatePanelPaddingHorizontal: e.calc(i).add(e.calc(r).div(2)).equal(),
    };
  },
  la = (e) => {
    let {
        colorBgContainerDisabled: t,
        controlHeight: n,
        controlHeightSM: r,
        controlHeightLG: i,
        paddingXXS: a,
        lineWidth: o,
      } = e,
      s = a * 2,
      c = o * 2,
      l = Math.min(n - s, n - c),
      u = Math.min(r - s, r - c),
      d = Math.min(i - s, i - c);
    return {
      INTERNAL_FIXED_ITEM_MARGIN: Math.floor(a / 2),
      cellHoverBg: e.controlItemBgHover,
      cellActiveWithRangeBg: e.controlItemBgActive,
      cellHoverWithRangeBg: new C(e.colorPrimary).lighten(35).toHexString(),
      cellRangeBorderColor: new C(e.colorPrimary).lighten(20).toHexString(),
      cellBgDisabled: t,
      timeColumnWidth: i * 1.4,
      timeColumnHeight: 224,
      timeCellHeight: 28,
      cellWidth: r * 1.5,
      cellHeight: r,
      textHeight: i,
      withoutTimeCellHeight: i * 1.65,
      multipleItemBg: e.colorFillSecondary,
      multipleItemBorderColor: `transparent`,
      multipleItemHeight: l,
      multipleItemHeightSM: u,
      multipleItemHeightLG: d,
      multipleSelectorBgDisabled: t,
      multipleItemColorDisabled: e.colorTextDisabled,
      multipleItemBorderColorDisabled: `transparent`,
    };
  },
  ua = (e) =>
    Object.assign(
      Object.assign(Object.assign(Object.assign({}, Ge(e)), la(e)), K(e)),
      {
        presetsWidth: 120,
        presetsMaxWidth: 200,
        zIndexPopup: e.zIndexPopupBase + 50,
      }
    ),
  da = (e) => {
    let { componentCls: t } = e;
    return {
      [t]: [
        Object.assign(
          Object.assign(Object.assign(Object.assign({}, Re(e)), We(e)), Ve(e)),
          Be(e)
        ),
        {
          "&-outlined": {
            [`&${t}-multiple ${t}-selection-item`]: {
              background: e.multipleItemBg,
              border: `${j(e.lineWidth)} ${e.lineType} ${
                e.multipleItemBorderColor
              }`,
            },
          },
          "&-filled": {
            [`&${t}-multiple ${t}-selection-item`]: {
              background: e.colorBgContainer,
              border: `${j(e.lineWidth)} ${e.lineType} ${e.colorSplit}`,
            },
          },
          "&-borderless": {
            [`&${t}-multiple ${t}-selection-item`]: {
              background: e.multipleItemBg,
              border: `${j(e.lineWidth)} ${e.lineType} ${
                e.multipleItemBorderColor
              }`,
            },
          },
          "&-underlined": {
            [`&${t}-multiple ${t}-selection-item`]: {
              background: e.multipleItemBg,
              border: `${j(e.lineWidth)} ${e.lineType} ${
                e.multipleItemBorderColor
              }`,
            },
          },
        },
      ],
    };
  },
  fa = (e, t) => ({ padding: `${j(e)} ${j(t)}` }),
  pa = (e) => {
    let { componentCls: t, colorError: n, colorWarning: r } = e;
    return {
      [`${t}:not(${t}-disabled):not([disabled])`]: {
        [`&${t}-status-error`]: { [`${t}-active-bar`]: { background: n } },
        [`&${t}-status-warning`]: { [`${t}-active-bar`]: { background: r } },
      },
    };
  },
  ma = (e) => {
    let {
      componentCls: t,
      antCls: n,
      paddingInline: r,
      lineWidth: i,
      lineType: a,
      colorBorder: o,
      borderRadius: s,
      motionDurationMid: c,
      colorTextDisabled: l,
      colorTextPlaceholder: u,
      fontSizeLG: d,
      inputFontSizeLG: f,
      fontSizeSM: p,
      inputFontSizeSM: m,
      controlHeightSM: h,
      paddingInlineSM: g,
      paddingXS: _,
      marginXS: v,
      colorIcon: y,
      lineWidthBold: b,
      colorPrimary: x,
      motionDurationSlow: S,
      zIndexPopup: C,
      paddingXXS: w,
      sizePopupArrow: T,
      colorBgElevated: E,
      borderRadiusLG: D,
      boxShadowSecondary: O,
      borderRadiusSM: k,
      colorSplit: A,
      cellHoverBg: M,
      presetsWidth: N,
      presetsMaxWidth: P,
      boxShadowPopoverArrow: I,
      fontHeight: L,
      lineHeightLG: R,
    } = e;
    return [
      {
        [t]: Object.assign(
          Object.assign(
            Object.assign({}, ee(e)),
            fa(e.paddingBlock, e.paddingInline)
          ),
          {
            position: `relative`,
            display: `inline-flex`,
            alignItems: `center`,
            lineHeight: 1,
            borderRadius: s,
            transition: `border ${c}, box-shadow ${c}, background ${c}`,
            [`${t}-prefix`]: {
              flex: `0 0 auto`,
              marginInlineEnd: e.inputAffixPadding,
            },
            [`${t}-input`]: {
              position: `relative`,
              display: `inline-flex`,
              alignItems: `center`,
              width: `100%`,
              "> input": Object.assign(
                Object.assign(
                  {
                    position: `relative`,
                    display: `inline-block`,
                    width: `100%`,
                    color: `inherit`,
                    fontSize: e.inputFontSize ?? e.fontSize,
                    lineHeight: e.lineHeight,
                    transition: `all ${c}`,
                  },
                  Ue(u)
                ),
                {
                  flex: `auto`,
                  minWidth: 1,
                  height: `auto`,
                  padding: 0,
                  background: `transparent`,
                  border: 0,
                  fontFamily: `inherit`,
                  "&:focus": { boxShadow: `none`, outline: 0 },
                  "&[disabled]": {
                    background: `transparent`,
                    color: l,
                    cursor: `not-allowed`,
                  },
                }
              ),
              "&-placeholder": { "> input": { color: u } },
            },
            "&-large": Object.assign(
              Object.assign({}, fa(e.paddingBlockLG, e.paddingInlineLG)),
              { [`${t}-input > input`]: { fontSize: f ?? d, lineHeight: R } }
            ),
            "&-small": Object.assign(
              Object.assign({}, fa(e.paddingBlockSM, e.paddingInlineSM)),
              { [`${t}-input > input`]: { fontSize: m ?? p } }
            ),
            [`${t}-suffix`]: {
              display: `flex`,
              flex: `none`,
              alignSelf: `center`,
              marginInlineStart: e.calc(_).div(2).equal(),
              color: l,
              lineHeight: 1,
              pointerEvents: `none`,
              transition: `opacity ${c}, color ${c}`,
              "> *": {
                verticalAlign: `top`,
                "&:not(:last-child)": { marginInlineEnd: v },
              },
            },
            [`${t}-clear`]: {
              position: `absolute`,
              top: `50%`,
              insetInlineEnd: 0,
              color: l,
              lineHeight: 1,
              transform: `translateY(-50%)`,
              cursor: `pointer`,
              opacity: 0,
              transition: `opacity ${c}, color ${c}`,
              "> *": { verticalAlign: `top` },
              "&:hover": { color: y },
            },
            "&:hover": {
              [`${t}-clear`]: { opacity: 1 },
              [`${t}-suffix:not(:last-child)`]: { opacity: 0 },
            },
            [`${t}-separator`]: {
              position: `relative`,
              display: `inline-block`,
              width: `1em`,
              height: d,
              color: l,
              fontSize: d,
              verticalAlign: `top`,
              cursor: `default`,
              [`${t}-focused &`]: { color: y },
              [`${t}-range-separator &`]: {
                [`${t}-disabled &`]: { cursor: `not-allowed` },
              },
            },
            "&-range": {
              position: `relative`,
              display: `inline-flex`,
              [`${t}-active-bar`]: {
                bottom: e.calc(i).mul(-1).equal(),
                height: b,
                background: x,
                opacity: 0,
                transition: `all ${S} ease-out`,
                pointerEvents: `none`,
              },
              [`&${t}-focused`]: { [`${t}-active-bar`]: { opacity: 1 } },
              [`${t}-range-separator`]: {
                alignItems: `center`,
                padding: `0 ${j(_)}`,
                lineHeight: 1,
              },
            },
            "&-range, &-multiple": {
              [`${t}-clear`]: { insetInlineEnd: r },
              [`&${t}-small`]: { [`${t}-clear`]: { insetInlineEnd: g } },
            },
            "&-dropdown": Object.assign(
              Object.assign(Object.assign({}, ee(e)), oa(e)),
              {
                pointerEvents: `none`,
                position: `absolute`,
                top: -9999,
                left: { _skip_check_: !0, value: -9999 },
                zIndex: C,
                [`&${t}-dropdown-hidden`]: { display: `none` },
                "&-rtl": { direction: `rtl` },
                [`&${t}-dropdown-placement-bottomLeft,
            &${t}-dropdown-placement-bottomRight`]: {
                  [`${t}-range-arrow`]: {
                    top: 0,
                    display: `block`,
                    transform: `translateY(-100%)`,
                  },
                },
                [`&${t}-dropdown-placement-topLeft,
            &${t}-dropdown-placement-topRight`]: {
                  [`${t}-range-arrow`]: {
                    bottom: 0,
                    display: `block`,
                    transform: `translateY(100%) rotate(180deg)`,
                  },
                },
                [`&${n}-slide-up-appear, &${n}-slide-up-enter`]: {
                  [`${t}-range-arrow${t}-range-arrow`]: { transition: `none` },
                },
                [`&${n}-slide-up-enter${n}-slide-up-enter-active${t}-dropdown-placement-topLeft,
          &${n}-slide-up-enter${n}-slide-up-enter-active${t}-dropdown-placement-topRight,
          &${n}-slide-up-appear${n}-slide-up-appear-active${t}-dropdown-placement-topLeft,
          &${n}-slide-up-appear${n}-slide-up-appear-active${t}-dropdown-placement-topRight`]:
                  { animationName: J },
                [`&${n}-slide-up-enter${n}-slide-up-enter-active${t}-dropdown-placement-bottomLeft,
          &${n}-slide-up-enter${n}-slide-up-enter-active${t}-dropdown-placement-bottomRight,
          &${n}-slide-up-appear${n}-slide-up-appear-active${t}-dropdown-placement-bottomLeft,
          &${n}-slide-up-appear${n}-slide-up-appear-active${t}-dropdown-placement-bottomRight`]:
                  { animationName: Te },
                [`&${n}-slide-up-leave ${t}-panel-container`]: {
                  pointerEvents: `none`,
                },
                [`&${n}-slide-up-leave${n}-slide-up-leave-active${t}-dropdown-placement-topLeft,
          &${n}-slide-up-leave${n}-slide-up-leave-active${t}-dropdown-placement-topRight`]:
                  { animationName: Ee },
                [`&${n}-slide-up-leave${n}-slide-up-leave-active${t}-dropdown-placement-bottomLeft,
          &${n}-slide-up-leave${n}-slide-up-leave-active${t}-dropdown-placement-bottomRight`]:
                  { animationName: Oe },
                [`${t}-panel > ${t}-time-panel`]: { paddingTop: w },
                [`${t}-range-wrapper`]: {
                  display: `flex`,
                  position: `relative`,
                },
                [`${t}-range-arrow`]: Object.assign(
                  Object.assign(
                    {
                      position: `absolute`,
                      zIndex: 1,
                      display: `none`,
                      paddingInline: e.calc(r).mul(1.5).equal(),
                      boxSizing: `content-box`,
                      transition: `all ${S} ease-out`,
                    },
                    ge(e, E, I)
                  ),
                  {
                    "&:before": {
                      insetInlineStart: e.calc(r).mul(1.5).equal(),
                    },
                  }
                ),
                [`${t}-panel-container`]: {
                  overflow: `hidden`,
                  verticalAlign: `top`,
                  background: E,
                  borderRadius: D,
                  boxShadow: O,
                  transition: `margin ${S}`,
                  display: `inline-block`,
                  pointerEvents: `auto`,
                  [`${t}-panel-layout`]: {
                    display: `flex`,
                    flexWrap: `nowrap`,
                    alignItems: `stretch`,
                  },
                  [`${t}-presets`]: {
                    display: `flex`,
                    flexDirection: `column`,
                    minWidth: N,
                    maxWidth: P,
                    ul: {
                      height: 0,
                      flex: `auto`,
                      listStyle: `none`,
                      overflow: `auto`,
                      margin: 0,
                      padding: _,
                      borderInlineEnd: `${j(i)} ${a} ${A}`,
                      li: Object.assign(Object.assign({}, F), {
                        borderRadius: k,
                        paddingInline: _,
                        paddingBlock: e.calc(h).sub(L).div(2).equal(),
                        cursor: `pointer`,
                        transition: `all ${S}`,
                        "+ li": { marginTop: v },
                        "&:hover": { background: M },
                      }),
                    },
                  },
                  [`${t}-panels`]: {
                    display: `inline-flex`,
                    flexWrap: `nowrap`,
                    "&:last-child": { [`${t}-panel`]: { borderWidth: 0 } },
                  },
                  [`${t}-panel`]: {
                    verticalAlign: `top`,
                    background: `transparent`,
                    borderRadius: 0,
                    borderWidth: 0,
                    [`${t}-content, table`]: { textAlign: `center` },
                    "&-focused": { borderColor: o },
                  },
                },
              }
            ),
            "&-dropdown-range": {
              padding: `${j(e.calc(T).mul(2).div(3).equal())} 0`,
              "&-hidden": { display: `none` },
            },
            "&-rtl": {
              direction: `rtl`,
              [`${t}-separator`]: { transform: `scale(-1, 1)` },
              [`${t}-footer`]: { "&-extra": { direction: `rtl` } },
            },
          }
        ),
      },
      De(e, `slide-up`),
      De(e, `slide-down`),
      we(e, `move-up`),
      we(e, `move-down`),
    ];
  },
  ha = B(
    `DatePicker`,
    (e) => {
      let t = P(ze(e), ca(e), {
        inputPaddingHorizontalBase: e.calc(e.paddingSM).sub(1).equal(),
        multipleSelectItemHeight: e.multipleItemHeight,
        selectHeight: e.controlHeight,
      });
      return [
        sa(t),
        ma(t),
        da(t),
        pa(t),
        ia(t),
        de(e, { focusElCls: `${e.componentCls}-focused` }),
      ];
    },
    ua
  ),
  ga = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `0 0 1024 1024`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M873.1 596.2l-164-208A32 32 0 00684 376h-64.8c-6.7 0-10.4 7.7-6.3 13l144.3 183H152c-4.4 0-8 3.6-8 8v60c0 4.4 3.6 8 8 8h695.9c26.8 0 41.7-30.8 25.2-51.8z`,
          },
        },
      ],
    },
    name: `swap-right`,
    theme: `outlined`,
  };
g();
var _a = Z.forwardRef(function (e, t) {
  return Z.createElement(ue, _({}, e, { ref: t, icon: ga }));
});
function va(e, t, n) {
  return n === void 0
    ? t === `year` && e.lang.yearPlaceholder
      ? e.lang.yearPlaceholder
      : t === `quarter` && e.lang.quarterPlaceholder
      ? e.lang.quarterPlaceholder
      : t === `month` && e.lang.monthPlaceholder
      ? e.lang.monthPlaceholder
      : t === `week` && e.lang.weekPlaceholder
      ? e.lang.weekPlaceholder
      : t === `time` && e.timePickerLocale.placeholder
      ? e.timePickerLocale.placeholder
      : e.lang.placeholder
    : n;
}
function ya(e, t, n) {
  return n === void 0
    ? t === `year` && e.lang.yearPlaceholder
      ? e.lang.rangeYearPlaceholder
      : t === `quarter` && e.lang.quarterPlaceholder
      ? e.lang.rangeQuarterPlaceholder
      : t === `month` && e.lang.monthPlaceholder
      ? e.lang.rangeMonthPlaceholder
      : t === `week` && e.lang.weekPlaceholder
      ? e.lang.rangeWeekPlaceholder
      : t === `time` && e.timePickerLocale.placeholder
      ? e.timePickerLocale.rangePlaceholder
      : e.lang.rangePlaceholder
    : n;
}
function ba(e, t) {
  let { allowClear: n = !0 } = e,
    { clearIcon: r, removeIcon: i } = Ne(
      Object.assign(Object.assign({}, e), {
        prefixCls: t,
        componentName: `DatePicker`,
      })
    );
  return [
    Z.useMemo(
      () => n !== !1 && Object.assign({ clearIcon: r }, n === !0 ? {} : n),
      [n, r]
    ),
    i,
  ];
}
var [xa, Sa] = [`week`, `WeekPicker`],
  [Ca, wa] = [`month`, `MonthPicker`],
  [Ta, Ea] = [`year`, `YearPicker`],
  [Da, Oa] = [`quarter`, `QuarterPicker`],
  [ka, Aa] = [`time`, `TimePicker`],
  ja = (e) =>
    Z.createElement(q, Object.assign({ size: `small`, type: `primary` }, e));
function Ma(e) {
  return (0, Z.useMemo)(() => Object.assign({ button: ja }, e), [e]);
}
I();
function Na(e, ...t) {
  let n = e || {};
  return t.reduce(
    (e, t) => (
      Object.keys(t || {}).forEach((r) => {
        let i = n[r],
          a = t[r];
        if (i && typeof i == `object`) {
          if (a && typeof a == `object`) e[r] = Na(i, e[r], a);
          else {
            let { _default: t } = i;
            (e[r] = e[r] || {}), (e[r][t] = (0, Q.default)(e[r][t], a));
          }
        } else e[r] = (0, Q.default)(e[r], a);
      }),
      e
    ),
    {}
  );
}
function Pa(e, ...t) {
  return Z.useMemo(() => Na.apply(void 0, [e].concat(t)), [t]);
}
function Fa(...e) {
  return Z.useMemo(
    () =>
      e.reduce(
        (e, t = {}) => (
          Object.keys(t).forEach((n) => {
            e[n] = Object.assign(Object.assign({}, e[n]), t[n]);
          }),
          e
        ),
        {}
      ),
    [e]
  );
}
function Ia(e, t) {
  let n = Object.assign({}, e);
  return (
    Object.keys(t).forEach((e) => {
      if (e !== `_default`) {
        let r = t[e],
          i = n[e] || {};
        n[e] = r ? Ia(i, r) : i;
      }
    }),
    n
  );
}
function La(e, t, n) {
  let r = Pa.apply(void 0, [n].concat(L(e))),
    i = Fa.apply(void 0, L(t));
  return Z.useMemo(() => [Ia(r, n), Ia(i, n)], [r, i]);
}
var Ra = (e, t, n, r, i) => {
    let { classNames: a, styles: o } = R(e),
      [s, c] = La([a, t], [o, n], { popup: { _default: `root` } });
    return Z.useMemo(() => {
      var e, t;
      return [
        Object.assign(Object.assign({}, s), {
          popup: Object.assign(Object.assign({}, s.popup), {
            root: (0, Q.default)((e = s.popup) == null ? void 0 : e.root, r),
          }),
        }),
        Object.assign(Object.assign({}, c), {
          popup: Object.assign(Object.assign({}, c.popup), {
            root: Object.assign(
              Object.assign({}, (t = c.popup) == null ? void 0 : t.root),
              i
            ),
          }),
        }),
      ];
    }, [s, c, r, i]);
  },
  za = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Ba = (e) =>
    (0, Z.forwardRef)((t, n) => {
      var r;
      let {
          prefixCls: i,
          getPopupContainer: a,
          components: o,
          className: s,
          style: c,
          placement: l,
          size: u,
          disabled: d,
          bordered: f = !0,
          placeholder: p,
          popupStyle: m,
          popupClassName: h,
          dropdownClassName: g,
          status: _,
          rootClassName: v,
          variant: y,
          picker: x,
          styles: S,
          classNames: C,
        } = t,
        w = za(t, [
          `prefixCls`,
          `getPopupContainer`,
          `components`,
          `className`,
          `style`,
          `placement`,
          `size`,
          `disabled`,
          `bordered`,
          `placeholder`,
          `popupStyle`,
          `popupClassName`,
          `dropdownClassName`,
          `status`,
          `rootClassName`,
          `variant`,
          `picker`,
          `styles`,
          `classNames`,
        ]),
        T = x === ka ? `timePicker` : `datePicker`,
        E = Z.useRef(null),
        {
          getPrefixCls: D,
          direction: O,
          getPopupContainer: k,
          rangePicker: A,
        } = (0, Z.useContext)(b),
        j = D(`picker`, i),
        { compactSize: M, compactItemClassnames: P } = ne(j, O),
        F = D(),
        [I, L] = Ke(`rangePicker`, y, f),
        R = ve(j),
        [z, ee, te] = ha(j, R),
        [B, re] = Ra(T, C, S, h || g, m),
        [V] = ba(t, j),
        ie = Ma(o),
        H = N((e) => u ?? M ?? e),
        ae = Z.useContext(oe),
        se = d ?? ae,
        {
          hasFeedback: ce,
          status: U,
          feedbackIcon: le,
        } = (0, Z.useContext)(pe),
        ue = Z.createElement(
          Z.Fragment,
          null,
          x === ka ? Z.createElement(nt, null) : Z.createElement($e, null),
          ce && le
        );
      (0, Z.useImperativeHandle)(n, () => E.current);
      let [de] = he(`Calendar`, G),
        W = Object.assign(Object.assign({}, de), t.locale),
        [K] = fe(`DatePicker`, (r = re.popup.root) == null ? void 0 : r.zIndex);
      return z(
        Z.createElement(
          me,
          { space: !0 },
          Z.createElement(
            Xi,
            Object.assign(
              {
                separator: Z.createElement(
                  `span`,
                  { "aria-label": `to`, className: `${j}-separator` },
                  Z.createElement(_a, null)
                ),
                disabled: se,
                ref: E,
                placement: l,
                placeholder: ya(W, x, p),
                suffixIcon: ue,
                prevIcon: Z.createElement(`span`, {
                  className: `${j}-prev-icon`,
                }),
                nextIcon: Z.createElement(`span`, {
                  className: `${j}-next-icon`,
                }),
                superPrevIcon: Z.createElement(`span`, {
                  className: `${j}-super-prev-icon`,
                }),
                superNextIcon: Z.createElement(`span`, {
                  className: `${j}-super-next-icon`,
                }),
                transitionName: `${F}-slide-up`,
                picker: x,
              },
              w,
              {
                className: (0, Q.default)(
                  { [`${j}-${H}`]: H, [`${j}-${I}`]: L },
                  Ie(j, Le(U, _), ce),
                  ee,
                  P,
                  s,
                  A == null ? void 0 : A.className,
                  te,
                  R,
                  v,
                  B.root
                ),
                style: Object.assign(
                  Object.assign(
                    Object.assign({}, A == null ? void 0 : A.style),
                    c
                  ),
                  re.root
                ),
                locale: W.lang,
                prefixCls: j,
                getPopupContainer: a || k,
                generateConfig: e,
                components: ie,
                direction: O,
                classNames: {
                  popup: (0, Q.default)(ee, te, R, v, B.popup.root),
                },
                styles: {
                  popup: Object.assign(Object.assign({}, re.popup.root), {
                    zIndex: K,
                  }),
                },
                allowClear: V,
              }
            )
          )
        )
      );
    }),
  Va = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  Ha = (e) => {
    let t = (t, n) => {
        let r = n === Aa ? `timePicker` : `datePicker`;
        return (0, Z.forwardRef)((n, i) => {
          var a;
          let {
              prefixCls: o,
              getPopupContainer: s,
              components: c,
              style: l,
              className: u,
              rootClassName: d,
              size: f,
              bordered: p,
              placement: m,
              placeholder: h,
              popupStyle: g,
              popupClassName: _,
              dropdownClassName: v,
              disabled: y,
              status: x,
              variant: S,
              onCalendarChange: C,
              styles: w,
              classNames: T,
            } = n,
            E = Va(n, [
              `prefixCls`,
              `getPopupContainer`,
              `components`,
              `style`,
              `className`,
              `rootClassName`,
              `size`,
              `bordered`,
              `placement`,
              `placeholder`,
              `popupStyle`,
              `popupClassName`,
              `dropdownClassName`,
              `disabled`,
              `status`,
              `variant`,
              `onCalendarChange`,
              `styles`,
              `classNames`,
            ]),
            {
              getPrefixCls: D,
              direction: O,
              getPopupContainer: k,
              [r]: A,
            } = (0, Z.useContext)(b),
            j = D(`picker`, o),
            { compactSize: M, compactItemClassnames: P } = ne(j, O),
            F = Z.useRef(null),
            [I, L] = Ke(`datePicker`, S, p),
            R = ve(j),
            [z, ee, te] = ha(j, R);
          (0, Z.useImperativeHandle)(i, () => F.current);
          let B = { showToday: !0 },
            re = t || n.picker,
            V = D(),
            { onSelect: ie, multiple: H } = E,
            ae = ie && t === `time` && !H,
            se = (e, t, n) => {
              C == null || C(e, t, n), ae && ie(e);
            },
            [ce, U] = Ra(r, T, w, _ || v, g),
            [le, ue] = ba(n, j),
            de = Ma(c),
            W = N((e) => f ?? M ?? e),
            K = Z.useContext(oe),
            ge = y ?? K,
            {
              hasFeedback: _e,
              status: ye,
              feedbackIcon: be,
            } = (0, Z.useContext)(pe),
            xe = Z.createElement(
              Z.Fragment,
              null,
              re === `time`
                ? Z.createElement(nt, null)
                : Z.createElement($e, null),
              _e && be
            ),
            [q] = he(`DatePicker`, G),
            Se = Object.assign(Object.assign({}, q), n.locale),
            [Ce] = fe(
              `DatePicker`,
              (a = U.popup.root) == null ? void 0 : a.zIndex
            );
          return z(
            Z.createElement(
              me,
              { space: !0 },
              Z.createElement(
                na,
                Object.assign(
                  {
                    ref: F,
                    placeholder: va(Se, re, h),
                    suffixIcon: xe,
                    placement: m,
                    prevIcon: Z.createElement(`span`, {
                      className: `${j}-prev-icon`,
                    }),
                    nextIcon: Z.createElement(`span`, {
                      className: `${j}-next-icon`,
                    }),
                    superPrevIcon: Z.createElement(`span`, {
                      className: `${j}-super-prev-icon`,
                    }),
                    superNextIcon: Z.createElement(`span`, {
                      className: `${j}-super-next-icon`,
                    }),
                    transitionName: `${V}-slide-up`,
                    picker: t,
                    onCalendarChange: se,
                  },
                  B,
                  E,
                  {
                    locale: Se.lang,
                    className: (0, Q.default)(
                      { [`${j}-${W}`]: W, [`${j}-${I}`]: L },
                      Ie(j, Le(ye, x), _e),
                      ee,
                      P,
                      A == null ? void 0 : A.className,
                      u,
                      te,
                      R,
                      d,
                      ce.root
                    ),
                    style: Object.assign(
                      Object.assign(
                        Object.assign({}, A == null ? void 0 : A.style),
                        l
                      ),
                      U.root
                    ),
                    prefixCls: j,
                    getPopupContainer: s || k,
                    generateConfig: e,
                    components: de,
                    direction: O,
                    disabled: ge,
                    classNames: {
                      popup: (0, Q.default)(ee, te, R, d, ce.popup.root),
                    },
                    styles: {
                      popup: Object.assign(Object.assign({}, U.popup.root), {
                        zIndex: Ce,
                      }),
                    },
                    allowClear: le,
                    removeIcon: ue,
                  }
                )
              )
            )
          );
        });
      },
      n = t(),
      r = t(xa, Sa),
      i = t(Ca, wa),
      a = t(Ta, Ea),
      o = t(Da, Oa);
    return {
      DatePicker: n,
      WeekPicker: r,
      MonthPicker: i,
      YearPicker: a,
      TimePicker: t(ka, Aa),
      QuarterPicker: o,
    };
  },
  Ua = (e) => {
    let {
        DatePicker: t,
        WeekPicker: n,
        MonthPicker: r,
        YearPicker: i,
        TimePicker: a,
        QuarterPicker: o,
      } = Ha(e),
      s = Ba(e),
      c = t;
    return (
      (c.WeekPicker = n),
      (c.MonthPicker = r),
      (c.YearPicker = i),
      (c.RangePicker = s),
      (c.TimePicker = a),
      (c.QuarterPicker = o),
      c
    );
  },
  Wa = Ua(Ln);
(Wa._InternalPanelDoNotUseOrYouWillBeFired = Ae(
  Wa,
  `popupAlign`,
  void 0,
  `picker`
)),
  (Wa._InternalRangePanelDoNotUseOrYouWillBeFired = Ae(
    Wa.RangePicker,
    `popupAlign`,
    void 0,
    `picker`
  )),
  (Wa.generatePicker = Ua);
var Ga = {
  icon: {
    tag: `svg`,
    attrs: { viewBox: `64 64 896 896`, focusable: `false` },
    children: [
      {
        tag: `path`,
        attrs: {
          d: `M872 474H286.9l350.2-304c5.6-4.9 2.2-14-5.2-14h-88.5c-3.9 0-7.6 1.4-10.5 3.9L155 487.8a31.96 31.96 0 000 48.3L535.1 866c1.5 1.3 3.3 2 5.2 2h91.5c7.4 0 10.8-9.2 5.2-14L286.9 550H872c4.4 0 8-3.6 8-8v-60c0-4.4-3.6-8-8-8z`,
        },
      },
    ],
  },
  name: `arrow-left`,
  theme: `outlined`,
};
g();
var Ka = Z.forwardRef(function (e, t) {
    return Z.createElement(ue, _({}, e, { ref: t, icon: Ga }));
  }),
  qa = {
    icon: {
      tag: `svg`,
      attrs: {
        "fill-rule": `evenodd`,
        viewBox: `64 64 896 896`,
        focusable: `false`,
      },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M880 912H144c-17.7 0-32-14.3-32-32V144c0-17.7 14.3-32 32-32h360c4.4 0 8 3.6 8 8v56c0 4.4-3.6 8-8 8H184v656h656V520c0-4.4 3.6-8 8-8h56c4.4 0 8 3.6 8 8v360c0 17.7-14.3 32-32 32zM653.3 424.6l52.2 52.2a8.01 8.01 0 01-4.7 13.6l-179.4 21c-5.1.6-9.5-3.7-8.9-8.9l21-179.4c.8-6.6 8.9-9.4 13.6-4.7l52.4 52.4 256.2-256.2c3.1-3.1 8.2-3.1 11.3 0l42.4 42.4c3.1 3.1 3.1 8.2 0 11.3L653.3 424.6z`,
          },
        },
      ],
    },
    name: `import`,
    theme: `outlined`,
  };
g();
var Ja = Z.forwardRef(function (e, t) {
    return Z.createElement(ue, _({}, e, { ref: t, icon: qa }));
  }),
  Ya = {
    MODAL_ENTER_DURATION: 0.34,
    background: {
      out: { background: `rgba(0,0,0,0)` },
      in: { background: `rgba(0,0,0,0.7)` },
    },
    content: { out: { y: `100%`, opacity: 0 }, in: { y: 0, opacity: 1 } },
    CONTENT_ANIMATION_CLASSNAME: `animated fadeIn`,
    CONTENT_ANIMATION_DURATION: 0.4,
  },
  Xa = (function (e) {
    return (e.liveGame = `liveGame`), (e.assignment = `assignment`), e;
  })({}),
  $ = yt(),
  Za = {
    d: { label: `Duration`, image: `clock` },
    c: { label: `Complexity`, image: `puzzle` },
    s: { label: `Style`, image: `gamepad` },
  },
  Qa = (e) => {
    let t = bt(`(min-height: 650px)`),
      n = bt(`(min-width: 600px)`),
      r = Z.useMemo(() => {
        let t = [];
        return (
          Object.keys(e.labels).forEach((n) => {
            let r = Za[n];
            if (r) {
              let i = !0;
              e.mode === Xa.assignment && (i = n === `c`),
                i &&
                  t.push({
                    id: n,
                    label: r.label,
                    title: e.labels[n],
                    image: r.image,
                  });
            }
          }),
          (t = t.sort(
            (e, t) =>
              Object.keys(Za).indexOf(e.id) - Object.keys(Za).indexOf(t.id)
          )),
          t
        );
      }, [e.labels, e.mode]);
    return (0, $.jsxs)(eo, {
      children: [
        (0, $.jsx)(to, { children: e.title }),
        (0, $.jsx)(no, { children: e.description }),
        t && n && r.length
          ? (0, $.jsx)(at, {
              direction: `horizontal`,
              size: 12,
              wrap: !0,
              style: { marginTop: 18 },
              children: r.map((e) =>
                (0, $.jsx)(
                  $a,
                  { label: e.label, title: e.title, image: e.image },
                  e.id + `-label`
                )
              ),
            })
          : null,
      ],
    });
  },
  $a = (e) =>
    (0, $.jsxs)(ro, {
      children: [
        (0, $.jsx)(io, {
          children: (0, $.jsx)(ao, {
            src: `/client/img/experiencePicker/${e.image}.svg`,
          }),
        }),
        (0, $.jsxs)(oo, {
          children: [
            (0, $.jsx)(so, { children: e.label }),
            (0, $.jsx)(co, { children: e.title }),
          ],
        }),
      ],
    }),
  eo = Y.div`
  @media (max-width: ${() => 600}px) {
    text-align: center;
  }
`,
  to = Y.div`
  font-family: ${qt.titleFont};
  font-size: 44px;
  text-transform: uppercase;
  font-weight: ${Et.Black};
  text-shadow: 2px 2px 2px ${X.Black};
`,
  no = Y.div`
  font-size: 18px;
  color: rgba(255, 255, 255, 0.8);
  margin-top: -4px;
`,
  ro = Y.div.attrs({ className: `flex vc` })`
  padding: 8px 14px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.1);
`,
  io = Y.div`
  margin-right: 15px;
`,
  ao = Y.img`
  height: 18px;
  opacity: 0.9;
`,
  oo = Y.div`
  line-height: 1;
`,
  so = Y.div`
  font-family: ${Ct.FugazOne};
  text-transform: uppercase;
  font-size: 10px;
  opacity: 0.8;
`,
  co = Y.div`
  font-size: 13px;
  margin-top: 3px;
  font-weight: ${Et.Bold};
`,
  lo = { background: `#303f9f` },
  uo = (e) => {
    let [t, n, r] = i(!1);
    Z.useEffect(() => {
      r();
    }, [e.pageId]);
    let a = (0, $.jsx)(mo, {
        disabled: !!e.errorMessage,
        onClick: () => {
          e.errorMessage || e.loading || e.onContinue();
        },
        children: e.loading ? `Loading...` : `Continue`,
      }),
      o = Z.useMemo(
        () =>
          e.errorMessage
            ? (0, $.jsx)(_e, {
                mouseEnterDelay: 0,
                placement: `bottom`,
                title: (0, $.jsx)(`span`, {
                  style: { fontWeight: Et.Bold, fontFamily: Ct.ProductSans },
                  children: e.errorMessage,
                }),
                children: a,
              })
            : a,
        [e.errorMessage, e.loading, e.onContinue]
      );
    return (0, $.jsx)($.Fragment, {
      children: (0, $.jsxs)(po, {
        children: [
          o,
          e.pageId
            ? (0, $.jsx)(ho, { onClick: n, children: `Learn more...` })
            : null,
          (0, $.jsx)(it, {
            open: t,
            onClose: r,
            placement: `right`,
            width: 450,
            rootStyle: { zIndex: 10 },
            closable: !0,
            children: (0, $.jsx)(fo, { pageId: e.pageId }),
          }),
        ],
      }),
    });
  },
  fo = (e) => (0, $.jsx)(Zt, { id: e.pageId }),
  po = Y.div.attrs({ className: `flex-center flex-column` })`
  margin-left: 35px;
  flex-shrink: 0;
  @media (max-width: ${() => 600}px) {
    margin-top: 20px;
    margin-left: 0px;
  }
`,
  mo = Y.div.attrs({ className: `flex-center` })`
  width: 183px;
  height: 60px;
  color: ${X.White};
  background: ${X.White};
  color: ${lo.background};
  font-size: 20px;
  border-style: solid;
  border-width: 3px;
  border-color: ${X.White};
  font-weight: ${Et.Black};
  border-radius: 100px;
  cursor: ${(e) => (e.disabled ? `not-allowed` : `pointer`)};
  transition: background 0.3s, color 0.3s;
  ${(e) =>
    e.disabled
      ? ``
      : `
   &:hover {
    background: transparent;
    color: ${X.White};
  }`}
`,
  ho = Y.div`
  color: rgba(255, 255, 255, 0.8);
  cursor: pointer;
  text-decoration: none;
  font-size: 14px;
  margin-top: 8px;
  &:hover {
    color: rgba(255, 255, 255, 1);
    text-decoration: underline;
  }
`,
  go = (e) => {
    let t = Z.useRef();
    return (0, $.jsx)(_o, {
      children: (0, $.jsxs)(`span`, {
        children: [
          `A report will not be generated for this game.`,
          ` `,
          (0, $.jsxs)(_e, {
            title: e.message,
            getPopupContainer: (e) => (t && t.current ? t.current : e),
            placement: `bottom`,
            children: [
              ` `,
              (0, $.jsx)(`span`, {
                style: { textDecoration: `underline`, cursor: `pointer` },
                children: `Why?`,
              }),
            ],
          }),
        ],
      }),
    });
  },
  _o = Y.div.attrs({ className: `flex hc vc maxWidth` })`
  padding: 18px;
  text-align: center;
  font-size: 18px;
  background: #f57c00;
  font-weight: bold;
`,
  vo = (e) =>
    e.noReportErrorMessage
      ? (0, $.jsx)(go, { message: e.noReportErrorMessage })
      : null,
  yo = (e) =>
    (0, $.jsxs)(bo, {
      children: [
        (0, $.jsx)(vo, { noReportErrorMessage: e.noReportErrorMessage }),
        (0, $.jsxs)(xo, {
          children: [
            (0, $.jsx)(Qa, {
              title: e.title,
              description: e.description,
              labels: e.labels,
              mode: e.mode,
            }),
            (0, $.jsx)(uo, {
              onContinue: e.onContinue,
              pageId: e.pageId,
              errorMessage: e.errorMessage,
              loading: e.loading,
            }),
          ],
        }),
      ],
    }),
  bo = Y.div.attrs({
    className: `maxWidth medium-shadow ${Ya.CONTENT_ANIMATION_CLASSNAME}`,
  })`
  z-index: 2;
  position: sticky;
  top: 0;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(10px);
  flex-shrink: 0;
  animation-duration: ${Ya.CONTENT_ANIMATION_DURATION}s;
`,
  xo = Y.div.attrs({ className: `maxWidth flex vc between` })`
  padding: 40px ${Ut.sideMargin}px;
  @media (max-width: ${600}px) {
    flex-direction: column;
  }
`,
  So = Z.forwardRef((e, t) => {
    let [n, , r] = i(!0),
      a = () => {
        r();
      };
    return (
      Gt([`Escape`], () => {
        a();
      }),
      (0, $.jsx)(Co, {
        initial: Ya.background.out,
        animate: n ? Ya.background.in : Ya.background.out,
        transition: { duration: Ya.MODAL_ENTER_DURATION },
        onClick: a,
        children: (0, $.jsx)(wo, {
          ref: t,
          initial: Ya.content.out,
          animate: n ? Ya.content.in : Ya.content.out,
          transition: { duration: Ya.MODAL_ENTER_DURATION },
          onAnimationComplete: () => {
            n || (e.close && e.close());
          },
          onClick: (e) => e.stopPropagation(),
          children: e.children,
        }),
      })
    );
  }),
  Co = Y(zt.div).attrs({ className: `maxAll flex-center` })`
  position: fixed;
  top: 0;
  left: 0;
  z-index: 9;
`,
  wo = Y(zt.div).attrs({ className: `medium-shadow scroll-y flex-column` })`
  background: ${lo.background};
  height: 90%;
  width: 90%;
  max-width: 1200px;
  border-radius: 7px;
  color: ${X.White};
  font-family: ${Ct.ProductSans};
`,
  To = {
    savedOriginalGameOptions: `original-saved-game-options-v1`,
    joinInLateOption: `join-in-late-option`,
  },
  Eo = (function (e) {
    return (e.time = `time`), (e.race = `race`), (e.allIn = `allIn`), e;
  })({}),
  Do = 0xde0b6b3a7640000,
  Oo = [
    {
      goal: `time`,
      name: `Time`,
      icon: nt,
      description: `All #s try to earn as much money as they can before the time runs out.`,
      label: `Minute`,
      defaultValue: 10,
      constraints: { min: 1, max: 59 },
    },
    {
      goal: `race`,
      name: `Race`,
      icon: tt,
      description: `All #s race to be the first one to reach the cash goal.`,
      label: `Dollar`,
      defaultValue: 25e4,
      constraints: { min: 10, max: Do },
    },
    {
      goal: `allIn`,
      name: `All In`,
      icon: dt,
      description: `The game ends when the collective balance of all #s reaches the cash goal.`,
      label: `Dollar`,
      defaultValue: 5e6,
      constraints: { min: 10, max: Do },
    },
  ],
  ko = { difficulty: `medium` },
  Ao = {
    options: {
      playersPerTeam: {
        render: (e) =>
          (0, $.jsx)(tn, {
            title: `Mode Difficulty`,
            options: jo,
            value: e.options.modeOptions.difficulty,
            onValueChanged: (t) => (e.options.modeOptions.difficulty = t),
          }),
      },
    },
    defaultOptions: ko,
  },
  jo = [
    { value: `easy`, name: `Easy` },
    { value: `medium`, name: `Normal` },
    { value: `hard`, name: `Hard` },
    { value: `veryHard`, name: `Ludicrous` },
    { value: `veryVeryHard`, name: `Gimpossible` },
  ],
  Mo = {
    modeOptions: ko,
    gameGoal: { goal: Eo.time, value: 10 },
    startingCash: 0,
    music: !0,
    clapping: !0,
    cleanPowerupsOnly: !1,
    currency: `$`,
    language: `en`,
    allowGoogleTranslate: !1,
  },
  No = [`gameGoal`, `startingCash`, `music`, `clapping`, `cleanPowerupsOnly`],
  Po = () => {
    let e = { ...Mo },
      t = localStorage.getItem(To.savedOriginalGameOptions);
    if (t) {
      let n = JSON.parse(t);
      Object.keys(n).forEach((t) => {
        No.includes(t) && (e[t] = n[t]);
      });
    }
    return e;
  },
  Fo = (e) => {
    let t = {};
    Object.keys(e).forEach((n) => {
      No.includes(n) && (t[n] = e[n]);
    }),
      localStorage.setItem(To.savedOriginalGameOptions, JSON.stringify(t));
  },
  Io = (e) =>
    (0, $.jsx)(nn, {
      emoji: e.emoji,
      title: e.title,
      description: e.description,
      children: (0, $.jsx)(ft, {
        checked: e.value,
        style: { transform: `scale(1.1)`, transformOrigin: `top right` },
        onChange: (t) => {
          e.onValueChanged(t);
        },
      }),
    }),
  Lo = Rt(),
  Ro = e(pt()),
  zo = 20,
  Bo =
    `Ant.Bear.Butterfly.Cat.Caterpillar.Crab.Dinosaur.Dog.Dolphin.Elephant.Flamingo.Fox.Frog.Giraffe.Goldfish.Gorilla.Grasshopper.Hamster.Hippopotamus.Horse.Jellyfish.Kangaroo.Lion.Monkey.Moose.Octopus.Owl.Penguin.Pig.Pigeon.Rabbit.Rhino.Shark.Snail.Snake.Spider.Squid.Squirrel.Tiger.Turkey.Turtle.Whale.Wolf.Worm.Zebra`.split(
      `.`
    ),
  Vo = [
    `Milk`,
    `Bread`,
    `Cheese`,
    `Eggs`,
    `Pizza`,
    `Soup`,
    `Chips`,
    `Chocolate`,
    `Sandwich`,
    `Pretzel`,
    `Muffin`,
    `Waffle`,
    `Popcorn`,
    `Taco`,
    `Smoothie`,
    `Apple`,
    `Strawberry`,
    `Corn`,
    `Ice Cream`,
    `Gravy`,
    `Salad`,
    `Spinach`,
    `Carrot`,
  ],
  Ho = [
    `Cup`,
    `Ghost`,
    `Flower`,
    `Book`,
    `Socks`,
    `Shoe`,
    `Ocean`,
    `Skateboard`,
    `Star`,
    `Shirt`,
    `Door`,
    `Computer`,
    `Baseball`,
    `Light Bulb`,
    `Camera`,
    `School`,
    `Television`,
    `Mail`,
    `Flashlight`,
    `Cell Phone`,
    `Truck`,
    `Mask`,
    `Table`,
  ],
  Uo = (e) => {
    let t = e.game,
      [n, r] = Z.useState([]),
      [i, a] = Z.useState(`initialAsk`),
      [s, l] = Z.useState(`list`);
    Z.useEffect(() => {
      e.setTerms(n);
    }, [n.length]),
      Z.useEffect(() => {
        let t = S(),
          n = g();
        if (t.length < 3 || n.length < 3) {
          a(`manager`);
          let t = 0;
          _(!0, (n) => {
            (t += n),
              t < 3 &&
                C(!0, (n) => {
                  (t += n), t < 3 && e.open();
                });
          });
        } else e.open();
      }, []);
    let u = (e) => {
        if (!e) return `No term provided.`;
        let t = e.trim();
        return t
          ? t.length < 1
            ? `Term must be at least 1 character.`
            : t.length > zo
            ? `Term must be less than ${zo} characters.`
            : n.map((e) => e.term.toLowerCase()).includes(t.toLowerCase())
            ? `Term is already on the list!`
            : t.includes(`?`)
            ? `Term includes a question mark.`
            : null
          : `No term provided.`;
      },
      d = (e) => {
        let t = (0, Lo.uniqBy)(
          e.map((e) => ({
            original: e.trim(),
            lowercase: e.trim().toLowerCase(),
          })),
          `lowercase`
        )
          .map((e) => e.original)
          .filter((e) => !u(e))
          .map((e) => ({ id: c(), term: e }));
        return r((e) => [...t, ...e]), t.length;
      },
      f = (e, t) => {
        let n = u(e);
        n ? be.error(n) : (d([e]), t());
      },
      p = (e) => {
        r((t) => t.filter((t) => t.id !== e));
      },
      m = () => {
        r([]);
      },
      h = (e) => {
        e && be.success(`${e} ${o(`term`, e)} added!`);
      },
      g = () => {
        let e = [];
        return (
          t.questions.forEach((t) => {
            t.answers.forEach((t) => {
              t.text && t.correct && !u(t.text) && e.push(t.text);
            });
          }),
          e
        );
      },
      _ = (e, t) => {
        let n = g(),
          r = d(n);
        e || (r || be.error(`No terms to add!`), h(r)), t && t(r);
      },
      v = (e) => {
        let n = [];
        t.questions.forEach((e) => {
          e.answers.forEach((e) => {
            e.text && !e.correct && !u(e.text) && n.push(e.text);
          });
        });
        let r = d(n);
        e || (r || be.error(`No terms to add!`), h(r));
      },
      y = () => l(`list`),
      b = () => l(`import`),
      x = () => l(`export`),
      S = () => {
        let e = [];
        return (
          t.questions.forEach((t) => {
            t.text && !u(t.text) && e.push(t.text);
          }),
          e
        );
      },
      C = (e, t) => {
        let n = S(),
          r = d(n);
        e || (r || be.error(`No terms to add!`), h(r)), t && t(r);
      },
      w = () =>
        s === `list`
          ? (0, $.jsx)(Qo, {
              title: `Term List`,
              description: `Make the list of terms students will draw during the game!`,
            })
          : s === `import`
          ? (0, $.jsx)(Qo, {
              title: `Import Terms`,
              description: `One term per line.`,
            })
          : s === `export`
          ? (0, $.jsx)(Qo, {
              title: `Export Terms`,
              description: `Copy your list for future use!`,
            })
          : null,
      T = () =>
        s === `list`
          ? (0, $.jsx)(is, {
              close: e.close,
              terms: n,
              removeTerm: p,
              addTerm: f,
              addTerms: d,
              addTermsFromCorrectAnswers: _,
              addTermsFromIncorrectAnswers: v,
              addTermsFromQuestions: C,
              setToImportScreen: b,
              setToExportScreen: x,
              removeAllTerms: m,
            })
          : s === `import`
          ? (0, $.jsx)(ps, {
              errorWithTerm: u,
              setToListScreen: y,
              addTerms: d,
            })
          : s === `export`
          ? (0, $.jsx)(hs, { terms: n.map((e) => e.term), setToListScreen: y })
          : null;
    return t
      ? (0, $.jsx)(xe, {
          width: 800,
          open: e.visible,
          closable: !1,
          onCancel: e.close,
          style: { top: 30 },
          bodyStyle: { height: `calc(100vh - 60px)`, padding: 0 },
          footer: null,
          children: (0, $.jsx)(Wo, {
            children: (() => {
              if (i === `initialAsk`) {
                let t = S(),
                  n = g();
                return (0, $.jsxs)(Ko, {
                  children: [
                    (0, $.jsx)(qo, {
                      children: `What would you like students to guess/draw?`,
                    }),
                    (0, $.jsxs)(Jo, {
                      children: [
                        (0, $.jsxs)(Yo, {
                          onClick: () => {
                            e.close(),
                              setTimeout(() => {
                                C(!0), a(`manager`);
                              }, 100);
                          },
                          children: [
                            (0, $.jsx)(Xo, { children: `Kit Questions` }),
                            t.map((e, t) =>
                              t < 3
                                ? (0, $.jsx)(
                                    Zo,
                                    { children: e },
                                    `sample-question-${t}`
                                  )
                                : null
                            ),
                          ],
                        }),
                        (0, $.jsxs)(Yo, {
                          onClick: () => {
                            e.close(),
                              setTimeout(() => {
                                _(!0), a(`manager`);
                              }, 100);
                          },
                          children: [
                            (0, $.jsx)(Xo, { children: `Kit Answers` }),
                            n.map((e, t) =>
                              t < 3
                                ? (0, $.jsx)(
                                    Zo,
                                    { children: e },
                                    `sample-answer-${t}`
                                  )
                                : null
                            ),
                          ],
                        }),
                      ],
                    }),
                  ],
                });
              }
              return (0, $.jsxs)($.Fragment, { children: [w(), T()] });
            })(),
          }),
        })
      : null;
  },
  Wo = Y.div.attrs({ className: `flex maxWidth maxHeight flex-column` })`
  font-family: ${rt.fontFamilyName};
  background: ${X.Snow};
  color: ${X.Black};
  overflow: hidden;
  border-radius: 4px;
`,
  Go = Y.div.attrs({ className: `flex` })`
  flex: 1;
  overflow: hidden;
`,
  Ko = Y.div.attrs({ className: `maxWidth maxHeight flex flex-column hc vc` })`
  padding: 25px;
`,
  qo = Y.div`
  font-size: 26px;
  font-weight: ${Et.Bold};
  margin-bottom: 15px;
  text-align: center;
`,
  Jo = Y.div.attrs({ className: `flex vc maxWidth` })``,
  Yo = Y.div.attrs({ className: `flex flex-column vc` })`
  padding: 30px;
  background: ${X.White};
  border-radius: 5px;
  border-style: solid;
  border-color: ${X.BorderGray};
  transition: border-color 0.3s;
  cursor: pointer;
  margin: 5px;
  width: calc(50% - 10px);
  &:hover {
    border-color: #66bb6a;
  }
`,
  Xo = Y.div`
  font-size: 22px;
  font-weight: ${Et.Bold};
  margin-bottom: 10px;
`,
  Zo = Y.div.attrs({ className: `maxWidth` })`
  padding: 8px 14px;
  color: #37474f;
  border: 2px solid ${X.BorderGray};
  border-radius: 4px;
  margin-bottom: 5px;
  font-size: 15px;
  &:last-child {
    margin-bottom: 0px;
  }
`,
  Qo = (e) =>
    (0, $.jsxs)($o, {
      children: [
        (0, $.jsx)(es, { children: e.title }),
        (0, $.jsx)(ts, { children: e.description }),
      ],
    }),
  $o = Y.div.attrs({ className: `maxWidth flex-column vc` })`
  padding: 25px;
  text-align: center;
  border-bottom: 2px solid ${X.BorderGray};
`,
  es = Y.div`
  font-size: 34px;
  font-weight: bold;
`,
  ts = Y.div`
  font-size: 20px;
`,
  ns = Y.div.attrs({ className: `maxWidth flex hc vc` })`
  border-top: 2px solid ${X.BorderGray};
  padding: 20px;
  flex-shrink: 0;
`,
  rs = (e) =>
    (0, $.jsxs)(cs, {
      children: [
        (0, $.jsx)(`div`, { children: e.term.term }),
        (0, $.jsx)(`div`, {
          children: (0, $.jsx)(_e, {
            title: `Remove`,
            children: (0, $.jsx)(ct, {
              style: { cursor: `pointer` },
              onClick: e.removeTerm,
            }),
          }),
        }),
      ],
    }),
  is = (e) => {
    let [t, n] = Z.useState(``),
      r = (e) => {
        n(e.target.value);
      },
      i = () => {
        t && e.addTerm(t, () => n(``));
      },
      a = Z.useMemo(
        () =>
          e.terms.map((t) =>
            (0, $.jsx)(
              rs,
              { term: t, removeTerm: () => e.removeTerm(t.id) },
              t.id
            )
          ),
        [e.terms.length]
      );
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsx)(Go, {
          children: (0, $.jsxs)(as, {
            children: [
              (0, $.jsxs)(os, {
                children: [
                  (0, $.jsxs)(`div`, {
                    className: `flex vc`,
                    children: [
                      (0, $.jsx)(He, {
                        size: `large`,
                        placeholder: `New term...`,
                        style: { marginRight: 10, height: 48 },
                        maxLength: zo,
                        value: t,
                        onChange: r,
                        onPressEnter: i,
                      }),
                      (0, $.jsx)(q, {
                        size: `large`,
                        style: { height: 48 },
                        onClick: i,
                        children: `Add`,
                      }),
                    ],
                  }),
                  (0, $.jsx)(Ot, { style: { margin: `20px 0px` } }),
                  a.length
                    ? a
                    : (0, $.jsxs)(ls, {
                        children: [
                          (0, $.jsx)(us, {
                            children: `You have no terms yet!`,
                          }),
                          (0, $.jsx)(ds, {
                            children: `Add some of your own, or try a game with a sample list.`,
                          }),
                          (0, $.jsxs)(`div`, {
                            className: `flex flex-column`,
                            style: { marginTop: 12 },
                            children: [
                              (0, $.jsx)(fs, {
                                onClick: () => e.addTerms((0, Lo.shuffle)(Bo)),
                                children: `Animals`,
                              }),
                              (0, $.jsx)(fs, {
                                onClick: () => e.addTerms((0, Lo.shuffle)(Vo)),
                                children: `Food and Drink`,
                              }),
                              (0, $.jsx)(fs, {
                                onClick: () => e.addTerms((0, Lo.shuffle)(Ho)),
                                children: `Objects`,
                              }),
                            ],
                          }),
                        ],
                      }),
                ],
              }),
              (0, $.jsxs)(ss, {
                children: [
                  (0, $.jsxs)(`div`, {
                    className: `maxWidth`,
                    children: [
                      (0, $.jsx)(Ce, {
                        overlay: (0, $.jsxs)(Se, {
                          children: [
                            (0, $.jsxs)(Se.Item, {
                              onClick: () => e.addTermsFromCorrectAnswers(),
                              children: [
                                (0, $.jsx)(Ye, {}),
                                ` Add From Correct Answers`,
                              ],
                            }),
                            (0, $.jsxs)(Se.Item, {
                              onClick: () => e.addTermsFromIncorrectAnswers(),
                              children: [
                                (0, $.jsx)(Ye, {}),
                                ` Add From Incorrect Answers`,
                              ],
                            }),
                            (0, $.jsxs)(Se.Item, {
                              onClick: () => e.addTermsFromQuestions(),
                              children: [
                                (0, $.jsx)(Ye, {}),
                                ` Add From Questions`,
                              ],
                            }),
                          ],
                        }),
                        children: (0, $.jsx)(q, {
                          block: !0,
                          size: `large`,
                          icon: (0, $.jsx)(Ye, {}),
                          type: `primary`,
                          style: { marginBottom: 10 },
                          children: `Add Terms`,
                        }),
                      }),
                      (0, $.jsx)(q, {
                        block: !0,
                        size: `large`,
                        icon: (0, $.jsx)(Ja, {}),
                        type: `primary`,
                        style: { marginBottom: 10 },
                        onClick: e.setToImportScreen,
                        children: `Import Terms`,
                      }),
                      e.terms.length
                        ? (0, $.jsx)(q, {
                            block: !0,
                            size: `large`,
                            icon: (0, $.jsx)(et, {}),
                            type: `primary`,
                            onClick: e.setToExportScreen,
                            children: `Export Terms`,
                          })
                        : null,
                    ],
                  }),
                  e.terms.length
                    ? (0, $.jsx)(`div`, {
                        className: `maxWidth flex hc`,
                        style: {
                          fontSize: 17,
                          textDecoration: `underline`,
                          color: `rgba(0,0,0,0.7)`,
                          cursor: `pointer`,
                          marginTop: 20,
                        },
                        onClick: e.removeAllTerms,
                        children: `Clear all terms`,
                      })
                    : null,
                ],
              }),
            ],
          }),
        }),
        (0, $.jsx)(ns, {
          children: (0, $.jsx)(q, {
            onClick: e.close,
            type: `primary`,
            size: `large`,
            children: `All Done!`,
          }),
        }),
      ],
    });
  },
  as = Y.div.attrs({ className: `flex` })`
  flex: 1;
  overflow: hidden;
`,
  os = Y.div.attrs({ className: `maxHeight scroll-y` })`
  flex: 1;
  padding: 20px;
`,
  ss = Y.div.attrs({ className: `maxHeight scroll-y flex flex-column` })`
  flex-shrink: 0;
  width: 250px;
  padding: 20px;
  border-left: 2px solid ${X.BorderGray};
  justify-content: space-between;
`,
  cs = Y.div.attrs({ className: `maxWidth flex vc` })`
  background: ${X.White};
  border: 1px solid ${X.BorderGray};
  border-radius: 5px;
  font-size: 18px;
  padding: 14px 17px;
  margin-bottom: 10px;
  line-height: 1;
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
  justify-content: space-between;
`,
  ls = Y.div.attrs({ className: `maxWidth flex vc flex-column` })``,
  us = Y.div`
  font-size: 24px;
  font-weight: bold;
`,
  ds = Y.div`
  font-size: 18px;
`,
  fs = Y(kt)`
  font-size: 18px;
  text-decoration: underline;
  &:hover {
    text-decoration: underline;
  }
`,
  ps = (e) => {
    let [t, n] = Z.useState(``),
      r = (e) => {
        n(e.target.value);
      },
      i = Z.useMemo(
        () =>
          t
            .split(
              `
`
            )
            .filter((t) => t && !e.errorWithTerm(t)),
        [t]
      );
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsx)(Go, {
          children: (0, $.jsx)(ms, {
            children: (0, $.jsx)(He.TextArea, {
              style: { fontSize: 18, flex: 1, resize: `none` },
              value: t,
              onChange: r,
              placeholder: `Term 1
Term 2
Term 3`,
            }),
          }),
        }),
        (0, $.jsxs)(ns, {
          children: [
            (0, $.jsx)(q, {
              type: `link`,
              size: `large`,
              icon: (0, $.jsx)(Ka, {}),
              style: { marginRight: 10 },
              onClick: e.setToListScreen,
              children: `Go Back`,
            }),
            (0, $.jsx)(q, {
              disabled: !i.length,
              type: `primary`,
              size: `large`,
              onClick: () => {
                e.addTerms(i), e.setToListScreen();
              },
              children: `Import Terms`,
            }),
          ],
        }),
      ],
    });
  },
  ms = Y.div.attrs({ className: `maxWidth maxHeight flex` })`
  padding: 20px;
`,
  hs = (e) => {
    let t = Z.useMemo(() => {
      let t = ``;
      return (
        e.terms.forEach((n, r) => {
          (t += n),
            r + 1 !== e.terms.length &&
              (t += `
`);
        }),
        t
      );
    }, [e.terms.length]);
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsx)(Go, {
          children: (0, $.jsx)(ms, {
            children: (0, $.jsx)(He.TextArea, {
              style: { fontSize: 18, flex: 1, resize: `none` },
              value: t,
              readOnly: !0,
            }),
          }),
        }),
        (0, $.jsxs)(ns, {
          children: [
            (0, $.jsx)(q, {
              type: `link`,
              size: `large`,
              icon: (0, $.jsx)(Ka, {}),
              style: { marginRight: 10 },
              onClick: e.setToListScreen,
              children: `Go Back`,
            }),
            (0, $.jsx)(q, {
              type: `primary`,
              size: `large`,
              onClick: () => {
                (0, Ro.default)(t), be.success(`Terms copied to clipboard!`);
              },
              children: `Copy Terms`,
            }),
          ],
        }),
      ],
    });
  },
  gs = { render: (e) => (0, $.jsx)(_s, { ...e }) },
  _s = (e) => {
    let [t, n, r] = i(!1);
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsxs)(on, {
          children: [
            (0, $.jsxs)(`div`, {
              children: [
                (0, $.jsxs)(Qt, {
                  children: [
                    `Terms (`,
                    e.options.modeOptions.terms.length,
                    `)`,
                  ],
                }),
                (0, $.jsx)(an, {
                  children: `Terms students will draw during the game.`,
                }),
              ],
            }),
            (0, $.jsx)(sn, {
              children: (0, $.jsx)(q, {
                size: `large`,
                type: `primary`,
                icon: (0, $.jsx)(lt, {}),
                onClick: n,
                children: `Manage Terms`,
              }),
            }),
          ],
        }),
        (0, $.jsx)(Uo, {
          visible: t,
          open: n,
          close: r,
          game: e.game,
          setTerms: (t) => (e.options.modeOptions.terms = t),
        }),
      ],
    });
  },
  vs = {
    options: {
      terms: gs,
      roundDuration: {
        render: (e) =>
          (0, $.jsx)(tn, {
            customWidth: 270,
            title: `Round Duration`,
            options: [
              { value: `short`, name: `Short (40 seconds)` },
              { value: `normal`, name: `Normal (60 seconds)` },
              { value: `long`, name: `Long (90 seconds)` },
            ],
            value: e.options.modeOptions.roundDuration,
            onValueChanged: (t) => (e.options.modeOptions.roundDuration = t),
          }),
      },
      termReveal: {
        render: (e) =>
          (0, $.jsx)(tn, {
            customWidth: 270,
            title: `Term Reveal`,
            description: `Letters revealed as round progresses.`,
            value: e.options.modeOptions.termReveal,
            onValueChanged: (t) => (e.options.modeOptions.termReveal = t),
            options: [
              { value: `blank`, name: `Blank (Nothing Shown At All)` },
              { value: `none`, name: `None (No Letters Revealed)` },
              { value: `singleLetter`, name: `Only One Letter Revealed` },
              {
                value: `firstAndLast`,
                name: `First And Last Letters Revealed`,
              },
              { value: `fiftyPercent`, name: `50% Of Letters Revealed` },
              { value: `seventyFivePercent`, name: `75% of Letters Revealed` },
            ],
          }),
      },
      guessFeed: {
        render: (e) =>
          (0, $.jsx)(Io, {
            title: `Guess Feed`,
            description: `Shows guesses students are making in real-time.`,
            value: e.options.modeOptions.guessFeedEnabled,
            onValueChanged: (t) => (e.options.modeOptions.guessFeedEnabled = t),
          }),
      },
      speedBonus: {
        render: (e) =>
          (0, $.jsx)(Io, {
            title: `Speed Bonus`,
            description: `Award students who guess the correct answer faster.`,
            value: e.options.modeOptions.speedBonusEnabled,
            onValueChanged: (t) =>
              (e.options.modeOptions.speedBonusEnabled = t),
          }),
      },
      symbolKeyboardEnabled: {
        render: (e) =>
          (0, $.jsx)(Io, {
            title: `Symbol Buttons`,
            description: `Show buttons for quick entry of non A-Z characters.`,
            value: e.options.modeOptions.symbolKeyboardEnabled,
            onValueChanged: (t) =>
              (e.options.modeOptions.symbolKeyboardEnabled = t),
          }),
      },
    },
    defaultOptions: {
      terms: [],
      roundDuration: `normal`,
      termReveal: `fiftyPercent`,
      guessFeedEnabled: !0,
      speedBonusEnabled: !0,
      symbolKeyboardEnabled: !0,
    },
    errorMessage: (e) => {
      let { modeOptions: t } = e;
      return t.terms.length < 3
        ? `You'll need at least 3 terms to start a game. Add some by clicking 'Manage Terms' below!`
        : null;
    },
  },
  ys = {
    options: {
      playersPerTeam: {
        render: (e) =>
          (0, $.jsx)(en, {
            title: `Players Per Team`,
            value: e.options.modeOptions.playersPerTeam,
            onValueChanged: (t) => (e.options.modeOptions.playersPerTeam = t),
            min: 2,
            max: 8,
            step: 1,
          }),
      },
    },
    defaultOptions: { playersPerTeam: 4 },
  },
  bs = [
    { value: `nearPerfect`, name: `Almost Perfect` },
    { value: `accurate`, name: `Very Reliable` },
    { value: `normal`, name: `Normal` },
    { value: `inconsistent`, name: `Inconsistent` },
    { value: `terrible`, name: `Not Even Worth It` },
  ],
  xs = {
    options: {
      numberOfImposters: {
        render: (e) =>
          (0, $.jsx)(en, {
            value: e.options.modeOptions.numberOfImposters,
            title: `Number of Impostors`,
            description: `More impostors can lead to longer games`,
            onValueChanged: (t) =>
              (e.options.modeOptions.numberOfImposters = t),
            min: 1,
            max: 12,
            step: 1,
            customWidth: 120,
          }),
      },
      investigationsPerPerson: {
        render: (e) =>
          (0, $.jsx)(en, {
            value: e.options.modeOptions.investigationsPerPerson,
            title: `Investigations Per Crewmate`,
            description: `More investigations makes games longer, but easier for crewmates`,
            onValueChanged: (t) =>
              (e.options.modeOptions.investigationsPerPerson = t),
            min: 2,
            max: 30,
            step: 1,
            customWidth: 120,
          }),
      },
      investigationValidResultProbability: {
        render: (e) =>
          (0, $.jsx)(tn, {
            title: `Investigation Reliability`,
            description: `The more reliable, the easier it is for crewmates to win`,
            value: e.options.modeOptions.investigationValidResultProbability,
            options: bs,
            onValueChanged: (t) =>
              (e.options.modeOptions.investigationValidResultProbability = t),
          }),
      },
      allowPublicInvestigations: {
        render: (e) =>
          (0, $.jsx)(Io, {
            title: `Public Investigations`,
            description: `Investigations that allow crewmates to appear on the clear list`,
            value: e.options.modeOptions.allowPublicInvestigations,
            onValueChanged: (t) =>
              (e.options.modeOptions.allowPublicInvestigations = t),
          }),
      },
      allowStudentMeetings: {
        render: (e) =>
          (0, $.jsx)(Io, {
            title: `Student-Called Meetings`,
            description: `Allow student crewmates to call meetings`,
            value: e.options.modeOptions.allowStudentMeetings,
            onValueChanged: (t) =>
              (e.options.modeOptions.allowStudentMeetings = t),
          }),
      },
    },
    defaultOptions: {
      numberOfImposters: 2,
      investigationsPerPerson: 10,
      investigationValidResultProbability: `normal`,
      allowPublicInvestigations: !0,
      allowStudentMeetings: !0,
    },
  },
  Ss = (e) =>
    (0, $.jsxs)(xe, {
      open: e.visible,
      width: 800,
      footer: null,
      closable: !1,
      style: { top: 35 },
      bodyStyle: { padding: 25 },
      onCancel: e.close,
      children: [
        (0, $.jsxs)(Cs, {
          children: [
            `Select a question for`,
            ` `,
            (0, $.jsx)(`span`, {
              style: { fontWeight: Et.UltraBold },
              children: `The Finale!`,
            }),
          ],
        }),
        e.game.questions.map((t) =>
          (0, $.jsx)(
            st,
            {
              question: t,
              customStyle: { width: `100%`, marginBottom: 10 },
              customRightComponent: (0, $.jsx)(q, {
                style: { marginLeft: 15 },
                type: `primary`,
                onClick: (n) => {
                  n.stopPropagation(), e.onQuestionSelected(t._id);
                },
                children: `Select`,
              }),
            },
            t._id
          )
        ),
      ],
    }),
  Cs = Y.div.attrs({ className: `maxWidth` })`
  font-family: ${Ct.SFPro};
  color: ${X.Black};
  font-weight: ${Et.Bold};
  font-size: 32px;
  line-height: 1;
  text-align: center;
  margin-top: 15px;
  margin-bottom: 30px;
`,
  ws = { render: (e) => (0, $.jsx)(Ts, { ...e }) },
  Ts = (e) => {
    let [t, n, r] = i(!1);
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsx)(tn, {
          value: e.options.modeOptions.customFinaleQuestionId
            ? `Custom`
            : `Random`,
          title: `Finale Question`,
          description: `Question used during The Finale`,
          options: [
            { value: `Random`, name: `Random Question` },
            { value: `Custom`, name: `Specific Question` },
          ],
          onValueChanged: (t) => {
            t === `Custom`
              ? n()
              : (e.options.modeOptions.customFinaleQuestionId = ``);
          },
        }),
        (0, $.jsx)(Ss, {
          visible: t,
          close: r,
          game: e.game,
          onQuestionSelected: (t) => {
            (e.options.modeOptions.customFinaleQuestionId = t), r();
          },
        }),
      ],
    });
  },
  Es = {
    sections: 3,
    questionDuration: 20,
    powers: !0,
    customFinaleQuestionId: ``,
  },
  Ds = [2, 3, 4, 5],
  Os = [10, 15, 20, 25, 30, 45, 60],
  ks = {
    options: {
      sections: {
        render: (e) =>
          (0, $.jsx)(tn, {
            title: `Categories`,
            description: `Each category contains 5 questions`,
            value: e.options.modeOptions.sections,
            onValueChanged: (t) => (e.options.modeOptions.sections = t),
            options: Ds.map((e) => ({ value: e, name: e.toString() })),
          }),
      },
      customFinaleQuestionId: ws,
      questionDuration: {
        render: (e) =>
          (0, $.jsx)(tn, {
            title: `Time To Answer`,
            description: `How long do students have to answer each question?`,
            value: e.options.modeOptions.questionDuration,
            onValueChanged: (t) => (e.options.modeOptions.questionDuration = t),
            options: Os.map((e) => ({ value: e, name: `${e} seconds` })),
          }),
      },
      powers: {
        render: (e) =>
          (0, $.jsx)(Io, {
            value: e.options.modeOptions.powers,
            onValueChanged: (t) => (e.options.modeOptions.powers = t),
            title: `Powers`,
            description: `Special abilities that increase the fun, while decreasing the likelihood of a tie`,
          }),
      },
    },
    defaultOptions: Es,
    errorMessage: (e) =>
      e && e.game && e.game.questions && e.game.questions.length < 2
        ? `This mode requires a kit to have at least two questions. Try adding some more questions or use another kit.`
        : null,
  },
  As = { [dn]: xs, [hn]: Ao, [fn]: ys, [_n]: ks, [gn]: vs },
  js = (e) => {
    let t = As[e.originalId],
      n = JSON.stringify(e.options.modeOptions),
      r = Z.useMemo(
        () =>
          t && t.errorMessage
            ? t.errorMessage({
                game: e.metadata.game,
                modeOptions: e.options.modeOptions,
              })
            : null,
        [n]
      );
    if (
      (Z.useEffect(() => {
        e.callbacks.setErrorMessage(r);
      }, [r]),
      !t)
    )
      return null;
    let i = {
      originalId: e.originalId,
      options: e.options,
      game: e.metadata.game,
    };
    if (!Object.keys(t.options).length) return null;
    let a = Object.keys(t.options).filter((e) => {
      let n = t.options[e];
      return !(n.disabled && n.disabled(i));
    });
    return a.length
      ? (0, $.jsx)($.Fragment, {
          children: a.map((e, n) =>
            (0, $.jsxs)(
              Z.Fragment,
              {
                children: [
                  t.options[e].render(i),
                  n + 1 === a.length
                    ? (0, $.jsx)(Ot, {})
                    : (0, $.jsx)(`div`, { style: { height: 10 } }),
                ],
              },
              e
            )
          ),
        })
      : null;
  },
  Ms = { render: (e) => (0, $.jsx)(js, { ...e }), hiddenBody: !0 },
  Ns = (e) => [fn, pn, vn].includes(e),
  Ps = (e, t) => e.replace(`#`, Ns(t) ? `team` : `player`),
  Fs = (e) => {
    let [t, n] = Z.useState(e.goal || Eo.time),
      [r, i] = Z.useState(0),
      a = Z.useRef(!1),
      s = Z.useMemo(() => Oo.find((e) => e.goal === t), [t]);
    Z.useEffect(() => {
      (!a && ((a.current = !0), e.value)) || i(s.defaultValue);
    }, [s.name]),
      Z.useEffect(() => {
        e.goal && n(e.goal);
      }, [e.goal]),
      Z.useEffect(() => {
        e.value && i(e.value);
      }, [e.value]),
      Z.useEffect(() => {
        e.onGoalChanged(t);
      }, [t]),
      Z.useEffect(() => {
        e.onValueChanged(r);
      }, [r]);
    let c = Z.useCallback(
        (e) => {
          let t = Math.round(e);
          return (
            t < s.constraints.min
              ? (t = s.constraints.min)
              : t > s.constraints.max && (t = s.constraints.max),
            t
          );
        },
        [s.name]
      ),
      l = (e) => {
        e !== t && n(e);
      };
    return (0, $.jsx)(on, {
      children: (0, $.jsxs)(`div`, {
        className: `maxWidth`,
        children: [
          (0, $.jsx)(Qt, { children: `Game Goal` }),
          (0, $.jsxs)(Is, {
            children: [
              (0, $.jsx)(Ls, {
                children: Oo.map((e, n) =>
                  (0, $.jsx)(
                    q,
                    {
                      type: t === e.goal ? `primary` : `default`,
                      onClick: () => l(e.goal),
                      style: { marginBottom: n + 1 === Oo.length ? 0 : 6 },
                      icon: (0, $.jsx)(e.icon, {}),
                      children: e.name,
                    },
                    e.goal
                  )
                ),
              }),
              (0, $.jsxs)(Rs, {
                children: [
                  (0, $.jsx)(s.icon, {
                    style: { fontSize: 20, marginBottom: 10 },
                  }),
                  Ps(s.description, e.originalId),
                ],
              }),
              (0, $.jsxs)(zs, {
                children: [
                  (0, $.jsx)(Qe, {
                    size: `large`,
                    value: r,
                    onChange: (e) => {
                      i(c(e));
                    },
                    step: 1,
                    max: s.constraints.max,
                    min: s.constraints.min,
                    formatter: un,
                    style: { width: `100%` },
                  }),
                  (0, $.jsx)(Bs, { children: o(s.label, r) }),
                ],
              }),
            ],
          }),
        ],
      }),
    });
  },
  Is = Y.div.attrs({ className: `flex vc` })`
  margin-top: 5px;
`,
  Ls = Y.div.attrs({ className: `flex-column` })``,
  Rs = Y.div.attrs({ className: `flex-center flex-column` })`
  border: 1px solid ${X.BorderGray};
  padding: 0px 20px;
  border-radius: 5px;
  margin-left: 10px;
  text-align: center;
  font-size: 14px;
  height: 110px;
  overflow: hidden;
`,
  zs = Y(Rs)`
  width: 180px;
  flex-shrink: 0;
`,
  Bs = Y.div`
  margin-top: 5px;
  color: rgba(0, 0, 0, 0.8);
  font-size: 14px;
`,
  Vs = [mn, hn, pn, dn, gn, _n],
  Hs = {
    render: (e) =>
      (0, $.jsx)(Fs, {
        originalId: e.originalId,
        goal: e.options.gameGoal.goal,
        value: e.options.gameGoal.value,
        onGoalChanged: (t) => (e.options.gameGoal.goal = t),
        onValueChanged: (t) => (e.options.gameGoal.value = t),
      }),
    disabled: (e) => Vs.includes(e.originalId),
  },
  Us = {
    render: (e) =>
      (0, $.jsx)(tn, {
        title: `Class`,
        emoji: `👥`,
        value: e.matchmakerOptions.group,
        onValueChanged: (t) => (e.matchmakerOptions.group = t),
        options: [
          { value: ``, name: `No Class (Players Enter Name)` },
          ...e.metadata.groups.map((e) => ({ value: e._id, name: e.name })),
        ],
        customWidth: 300,
      }),
    disabled: (e) => !e.metadata.groups.length,
  },
  Ws = [_n, gn, dn],
  Gs = {
    render: (e) =>
      (0, $.jsx)(en, {
        title: `Starting Cash`,
        emoji: `💰`,
        max: e.originalId === `LAVA` ? 1e4 : 999999999,
        value: e.options.startingCash,
        onValueChanged: (t) => (e.options.startingCash = t),
        step: 1,
      }),
    disabled: (e) => Ws.includes(e.originalId),
  },
  Ks = [mn],
  qs = {
    render: (e) =>
      (0, $.jsx)(Io, {
        title: `Music`,
        emoji: `🎶`,
        value: e.options.music,
        onValueChanged: (t) => (e.options.music = t),
      }),
    disabled: (e) => Ks.includes(e.originalId),
  },
  Js = [mn, dn],
  Ys = {
    render: (e) =>
      (0, $.jsx)(Io, {
        title: `Clapping`,
        emoji: `👏`,
        value: e.options.clapping,
        onValueChanged: (t) => (e.options.clapping = t),
      }),
    disabled: (e) => Js.includes(e.originalId),
  },
  Xs = [dn, hn, _n, gn],
  Zs = {
    render: (e) =>
      (0, $.jsx)(Io, {
        title: `Clean Powerups Only`,
        description: Ps(
          `Only allow powerups that don't hurt other #s`,
          e.originalId
        ),
        emoji: `✨`,
        value: e.options.cleanPowerupsOnly,
        onValueChanged: (t) => (e.options.cleanPowerupsOnly = t),
      }),
    disabled: (e) => Xs.includes(e.originalId),
  },
  Qs = { render: (e) => (0, $.jsx)($s, { ...e }) },
  $s = jt(
    (e) => (
      Z.useEffect(() => {
        localStorage.getItem(To.joinInLateOption) &&
          (e.matchmakerOptions.joinInLate = !1);
      }, []),
      (0, $.jsx)(Io, {
        title: `Join In Late`,
        description: `Players can join in after the game starts`,
        emoji: `🎲`,
        value: e.matchmakerOptions.joinInLate,
        onValueChanged: (t) => {
          t
            ? localStorage.removeItem(To.joinInLateOption)
            : localStorage.setItem(To.joinInLateOption, `disabled`),
            (e.matchmakerOptions.joinInLate = t);
        },
      })
    )
  ),
  ec = `gimkit-game-currency`,
  tc = { render: (e) => (0, $.jsx)(nc, { ...e }), hiddenBody: !0 },
  nc = (e) => (
    Z.useEffect(() => {
      localStorage.getItem(ec) &&
        (e.options.currency = localStorage.getItem(ec));
    }, []),
    null
  ),
  rc = `gimkit-3.0-game-language`,
  ic = { render: (e) => (0, $.jsx)(ac, { ...e }), hiddenBody: !0 },
  ac = (e) => (
    Z.useEffect(() => {
      localStorage.getItem(rc) &&
        (e.options.language = localStorage.getItem(rc));
    }, []),
    null
  ),
  oc = `gimkit-google-translate-allowed`,
  sc = { render: (e) => (0, $.jsx)(cc, { ...e }), hiddenBody: !0 },
  cc = (e) => (
    Z.useEffect(() => {
      localStorage.getItem(oc) && (e.options.allowGoogleTranslate = !0);
    }, []),
    null
  ),
  lc = {
    render: (e) => (0, $.jsx)(uc, { ...e }),
    disabled: (e) => !!e.matchmakerOptions.group,
  },
  uc = jt((e) =>
    (0, $.jsx)(Io, {
      title: `Use Nickname Generator`,
      description: `Players are forced to use automatically generated friendly nicknames`,
      emoji: `🎰`,
      value: e.matchmakerOptions.useRandomNamePicker,
      onValueChanged: (t) => {
        e.matchmakerOptions.useRandomNamePicker = t;
      },
    })
  ),
  dc = {
    modeOptions: Ms,
    gameGoal: Hs,
    group: Us,
    startingCash: Gs,
    music: qs,
    clapping: Ys,
    cleanPowerupsOnly: Zs,
    randomNamePicker: lc,
    joinInLate: Qs,
    currency: tc,
    language: ic,
    allowGoogleTranslate: sc,
  },
  fc = (e) => {
    let t = As[e];
    return { ...Po(), modeOptions: t ? t.defaultOptions : {} };
  },
  pc = jt(
    Z.forwardRef((e, t) => {
      let [n] = Z.useState(() => vt(fc(e.selectedItem.originalId))),
        r = {
          originalId: e.selectedItem.originalId,
          options: n,
          matchmakerOptions: e.matchmakerOptions,
          metadata: { game: e.game, groups: e.groups },
          callbacks: { setErrorMessage: e.setErrorMessage },
        },
        i = _t(n),
        a = () => i;
      return (
        Z.useImperativeHandle(t, () => ({ getOptions: a })),
        (0, $.jsx)($.Fragment, {
          children: Object.keys(dc).map((e) => {
            let t = dc[e];
            return !t.render || (t.disabled && t.disabled(r))
              ? null
              : (0, $.jsxs)(
                  Z.Fragment,
                  {
                    children: [
                      t.render(r),
                      t.hiddenBody
                        ? null
                        : (0, $.jsx)(`div`, { style: { height: 10 } }),
                    ],
                  },
                  e
                );
          }),
        })
      );
    })
  ),
  mc = {
    render: (e) =>
      (0, $.jsx)(tn, {
        title: `Class`,
        emoji: `👥`,
        value: e.matchmakerOptions.group,
        onValueChanged: (t) => (e.matchmakerOptions.group = t),
        options: [
          { value: ``, name: `No Class (Players Enter Name)` },
          ...e.metadata.groups.map((e) => ({ value: e._id, name: e.name })),
        ],
        customWidth: 300,
      }),
    disabled: (e) =>
      e.metadata.experiencePickerMode === Xa.assignment ||
      !e.metadata.groups.length,
  },
  hc = {
    render: (e) => (0, $.jsx)(gc, { ...e }),
    disabled: (e) => e.metadata.experiencePickerMode === Xa.assignment,
  },
  gc = jt(
    (e) => (
      Z.useEffect(() => {
        localStorage.getItem(To.joinInLateOption) &&
          (e.matchmakerOptions.joinInLate = !1);
      }, []),
      (0, $.jsx)(Io, {
        title: `Join In Late`,
        description: `Players can join in after the game starts`,
        emoji: `🎲`,
        value: e.matchmakerOptions.joinInLate,
        onValueChanged: (t) => {
          t
            ? localStorage.removeItem(To.joinInLateOption)
            : localStorage.setItem(To.joinInLateOption, `disabled`),
            (e.matchmakerOptions.joinInLate = t);
        },
      })
    )
  ),
  _c = {
    render: (e) => (0, $.jsx)(vc, { ...e }),
    disabled: (e) =>
      e.metadata.experiencePickerMode === Xa.assignment ||
      !!e.matchmakerOptions.group,
  },
  vc = jt((e) =>
    (0, $.jsx)(Io, {
      title: `Use Nickname Generator`,
      description: `Players are forced to use automatically generated friendly nicknames`,
      emoji: `🎰`,
      value: e.matchmakerOptions.useRandomNamePicker,
      onValueChanged: (t) => {
        e.matchmakerOptions.useRandomNamePicker = t;
      },
    })
  ),
  yc = { group: mc, randomNamePicker: _c, joinInLate: hc },
  bc = 90,
  xc = (e) => {
    let [t, n] = Z.useState(
        On.default
          .unix(e.defaultDueDate)
          .set(`hour`, 0)
          .set(`minute`, 0)
          .set(`second`, 0)
          .set(`millisecond`, 0)
      ),
      [r, i] = Z.useState(On.default.unix(e.defaultDueDate).hour());
    Z.useEffect(() => {
      let n = t
        .set(`hour`, r)
        .set(`minute`, 0)
        .set(`second`, 0)
        .set(`millisecond`, 0);
      e.onChange(n.unix());
    }, [t, r]);
    let a = (e) => {
        n(e);
      },
      o = (e) => {
        i(e);
      },
      s = Z.useMemo(() => (0, On.default)().add(bc, `days`), []),
      c = (e) =>
        !!(
          (0, On.default)()
            .set(`hour`, 23)
            .set(`minute`, 59)
            .set(`second`, 59)
            .isAfter(e) || e.isAfter(s)
        ),
      l = Z.useMemo(
        () =>
          Array.from({ length: 24 }, (e, t) =>
            (0, On.default)().set(`hour`, t).format(`h A`)
          ).map((e, t) => ({ time: e, index: t })),
        []
      );
    return (0, $.jsxs)($.Fragment, {
      children: [
        (0, $.jsx)(Sc, {}),
        (0, $.jsxs)(on, {
          children: [
            (0, $.jsx)(rn, {
              children: (0, $.jsxs)(`div`, {
                children: [
                  (0, $.jsx)(Qt, { children: `Due Date` }),
                  (0, $.jsx)(an, {
                    children: `The last day students can complete the assignment.`,
                  }),
                ],
              }),
            }),
            (0, $.jsxs)(`div`, {
              className: `flex vc`,
              children: [
                (0, $.jsx)(Wa, {
                  size: `large`,
                  value: t,
                  onChange: a,
                  format: `MMM Do`,
                  style: { width: 150 },
                  disabledDate: c,
                  allowClear: !1,
                  showToday: !1,
                }),
                (0, $.jsx)(Fe, {
                  size: `large`,
                  value: r,
                  style: { width: 100, marginLeft: 10 },
                  onChange: o,
                  children: l.map(({ time: e, index: t }) =>
                    (0, $.jsx)(
                      Fe.Option,
                      { value: t, children: e },
                      e + `-time-option`
                    )
                  ),
                }),
              ],
            }),
          ],
        }),
      ],
    });
  },
  Sc = Dt`
  .ant-picker-header-super-prev-btn, .ant-picker-header-super-next-btn {
    display: none;
  }
`,
  Cc = 6,
  wc = (e, t) =>
    t.props.children.props.children[1].props.children
      .toLowerCase()
      .indexOf(e.toLowerCase()) >= 0,
  Tc = (e) => {
    let [t, n] = Z.useState([]);
    return (
      Z.useEffect(() => {
        e.onChange(t);
      }, [t]),
      (0, $.jsxs)(on, {
        style: { marginTop: 10 },
        children: [
          (0, $.jsx)(rn, {
            children: (0, $.jsxs)(`div`, {
              children: [
                (0, $.jsx)(Qt, { children: `Class` }),
                (0, $.jsx)(an, {
                  children: `Which classes should complete this assignment?`,
                }),
              ],
            }),
          }),
          (0, $.jsx)(Fe, {
            mode: `multiple`,
            style: { width: 260 },
            placeholder: `Select some classes`,
            size: `large`,
            filterOption: wc,
            value: t,
            onChange: (e) => {
              e.length > Cc &&
                xe.error({
                  title: `You cannot assign to more than ${Cc} classes.`,
                }),
                n((0, Lo.take)(e, Cc));
            },
            children: e.groups.map((e) =>
              (0, $.jsx)(
                Fe.Option,
                {
                  value: e._id,
                  children: (0, $.jsxs)(`div`, {
                    className: `flex vc`,
                    children: [
                      (0, $.jsx)(Ec, { color: e.color }),
                      (0, $.jsx)(Dc, { children: e.name }),
                    ],
                  }),
                },
                e._id
              )
            ),
          }),
        ],
      })
    );
  },
  Ec = Y.div`
  height: 22px;
  width: 22px;
  background-color: ${(e) => e.color};
  border-radius: 4px;
  margin-right: 4px;
`,
  Dc = Y.span`
  font-family: ${Ct.ProductSans};
`,
  Oc = (e) => {
    let t = Z.useMemo(
        () => (0, On.default)().add(14, `days`).set(`hour`, 12).unix(),
        []
      ),
      [n, r] = Z.useState(t),
      [i, a] = Z.useState([]);
    return (
      Z.useEffect(() => {
        e.setAssignmentOptions({ dueDate: n, groups: i });
      }, [n, i]),
      (0, $.jsxs)($.Fragment, {
        children: [
          (0, $.jsx)(xc, { defaultDueDate: t, onChange: r }),
          e.groups.length
            ? (0, $.jsx)(Tc, { groups: e.groups, onChange: a })
            : null,
        ],
      })
    );
  },
  kc = (e) => {
    let { options: t, experienceId: n, hooks: r } = e;
    if (!r) return;
    let i = JSON.parse(localStorage.getItem(bn.hookSavedOptions) || `{}`);
    i[n] = {};
    let a = !1;
    Object.keys(t).forEach((e) => {
      let o = r.hooks.find((t) => t.key === e);
      if (o) {
        let r;
        o.type === yn.number
          ? (r = o.options.defaultValue)
          : o.type === yn.selectBox &&
            (r = o.options.defaultOption || o.options.options[0]),
          !(0, Lo.isNil)(r) && t[e] !== r && ((i[n][e] = t[e]), (a = !0));
      }
    }),
      a && localStorage.setItem(bn.hookSavedOptions, JSON.stringify(i));
  },
  Ac = jt(
    Z.forwardRef((e, t) => {
      let [r] = Z.useState(() => vt({})),
        i = Z.useRef(),
        [a, o] = Z.useState(),
        [s, c] = Z.useState(),
        [l, u] = Z.useState(!0),
        d = (t) => {
          Object.keys(t).forEach((e) => {
            r[e] = t[e];
          }),
            kc({ options: t, hooks: s, experienceId: e.selectedItem._id });
        };
      Z.useEffect(() => {
        n({
          url: `/api/experience/map/hooks`,
          data: { experience: e.selectedItem._id },
          cacheKey: `EXPERIENCE_HOOKS`,
          success: (t) => {
            let n = cn({
              hookJSON: t,
              experienceId: e.selectedItem._id,
              kitId: e.game._id,
            });
            (i.current = n), d(n), c(t), u(!1);
          },
          error: () => {
            xe.error({
              title: `Error fetching options for this mode`,
              content: `There was an error fetching the customizable options for this mode. Try again and if the issue persists, please contact support.`,
              onOk: () => {
                e.close();
              },
            });
          },
        });
      }, []);
      let f = {
          mapId: e.selectedItem.mapId,
          options: r,
          matchmakerOptions: e.matchmakerOptions,
          metadata: {
            game: e.game,
            groups: e.groups,
            experienceName: e.selectedItem.name,
            experiencePickerMode: e.experiencePickerMode,
          },
          callbacks: { setErrorMessage: e.setErrorMessage },
        },
        p = _t(r),
        m = () => ({
          hookOptions: p,
          cosmosBlocked: !!localStorage.getItem(bn.cosmosBlockedInGame),
          allowGoogleTranslate: !!localStorage.getItem(bn.allowGoogleTranslate),
        });
      return (
        Z.useImperativeHandle(t, () => ({
          getOptions: m,
          getAssignmentOptions: () => a,
          isLoadingOptions: () => l,
        })),
        l || !s
          ? null
          : (0, $.jsxs)(`div`, {
              className: `maxWidth`,
              children: [
                e.experiencePickerMode === Xa.assignment
                  ? (0, $.jsx)(Oc, {
                      setAssignmentOptions: o,
                      groups: e.groups,
                    })
                  : null,
                (0, $.jsx)(ln, {
                  hooks: s,
                  defaultState: i.current,
                  modeType: e.modeType,
                  location: $t.experiencePicker,
                  onStateChange: d,
                  header: (t) =>
                    e.experiencePickerMode === Xa.assignment && t > 0
                      ? (0, $.jsx)(Ot, {})
                      : null,
                  footer: (e) =>
                    (0, $.jsxs)($.Fragment, {
                      children: [
                        (0, $.jsx)(`div`, {
                          style: { height: e === 0 ? 0 : 10 },
                        }),
                        Object.keys(yc).map((e) => {
                          let t = yc[e];
                          return !t.render || (t.disabled && t.disabled(f))
                            ? null
                            : (0, $.jsxs)(
                                Z.Fragment,
                                {
                                  children: [
                                    t.render(f),
                                    t.hiddenBody
                                      ? null
                                      : (0, $.jsx)(`div`, {
                                          style: { height: 10 },
                                        }),
                                  ],
                                },
                                e
                              );
                        }),
                      ],
                    }),
                }),
              ],
            })
      );
    })
  ),
  jc = (e) => !s(e),
  Mc = [`free-plan-games-hosted`],
  Nc = () =>
    xt({
      queryKey: [Mc],
      queryFn: () => p({ url: `/api/user/games-hosted-in-period` }),
      enabled: Yt() === Wt.limitedGames && jc(),
    }),
  Pc = `#fff3e0`,
  Fc = `#ef6c00`,
  Ic = (e) => {
    let { data: t } = Nc(),
      n = Yt(),
      r = Xt(),
      i = Z.useMemo(
        () =>
          n === Wt.limitedGames
            ? `This game is limited to 5 players.`
            : `This mode is limited to 5 players.`,
        [n]
      ),
      a = Z.useMemo(
        () =>
          n === Wt.limitedGames
            ? (0, $.jsxs)($.Fragment, {
                children: [
                  `While on the free plan, you can host `,
                  r,
                  ` games per month. All games will be capped at 5 players until`,
                  ` `,
                  (t == null ? void 0 : t.resetDate) ?? `the end of the month`,
                  `.`,
                  (0, $.jsx)(`br`, {}),
                  (0, $.jsx)(`br`, {}),
                  (0, $.jsx)(`b`, {
                    children: `To host unlimited games with more players, upgrade to Gimkit Pro!`,
                  }),
                ],
              })
            : (0, $.jsxs)($.Fragment, {
                children: [
                  `This is a Gimkit Pro Exclusive mode. While on our free plan, you can only play Gimkit Pro Exclusives with 5 players.`,
                  ` `,
                  (0, $.jsx)(`b`, {
                    children: `To remove this limit, upgrade to Gimkit Pro!`,
                  }),
                ],
              }),
        [n, t]
      );
    return (n === Wt.limitedModes && !e.isProExperience) ||
      s() ||
      f() ||
      e.gameSource === `pear-deck` ||
      (n === Wt.limitedGames && (!t || (t == null ? void 0 : t.count) < r))
      ? null
      : (0, $.jsxs)($.Fragment, {
          children: [
            (0, $.jsxs)(Lc, {
              children: [
                (0, $.jsx)(Rc, {}),
                (0, $.jsx)(zc, { children: i }),
                (0, $.jsxs)(Bc, {
                  children: [
                    a,
                    (0, $.jsx)(kt, {
                      to: gt,
                      style: { fontWeight: Et.Bold },
                      children: (0, $.jsx)(q, {
                        size: `large`,
                        type: `primary`,
                        block: !0,
                        style: { marginTop: 20, height: 70 },
                        icon: (0, $.jsx)(ut, {}),
                        children: `Upgrade To Gimkit Pro`,
                      }),
                    }),
                    Pt()
                      ? (0, $.jsxs)(Vc, {
                          children: [
                            It({ simple: !0, roundUp: !0 }),
                            ` a year - works out to `,
                            Ft({ simple: !0 }),
                            ` a month`,
                          ],
                        })
                      : null,
                  ],
                }),
              ],
            }),
            (0, $.jsx)(Ot, {}),
          ],
        });
  },
  Lc = Y.div.attrs({ className: `flex-column flex-center` })`
  padding: 25px;
  text-align: center;
  background: ${Pc};
  border: 2px solid #ef6c00;
  border-radius: 5px;
`,
  Rc = Y.i.attrs({ className: `fas fa-exclamation-circle` })`
  color: ${Fc};
  font-size: 30px;
  margin-bottom: 10px;
`,
  zc = Y.div`
  font-size: 24px;
  font-weight: ${Et.Bold};
`,
  Bc = Y.div`
  font-size: 16px;
  margin-top: 10px;
`,
  Vc = Y.div`
  font-size: 14px;
  color: rgba(0, 0, 0, 0.8);
  margin-top: 12px;
`,
  Hc = Z.forwardRef((e, t) => {
    let n = Z.useRef(),
      r = Z.useRef(),
      [i] = Z.useState(() => vt({ group: ``, joinInLate: !0 })),
      a = () => {
        var t;
        return {
          matchmakerOptions: i,
          assignmentOptions:
            r == null || (t = r.current) == null
              ? void 0
              : t.getAssignmentOptions(),
          options:
            e.selectedItem.source === Vt.original
              ? n.current.getOptions()
              : r.current.getOptions(),
        };
      };
    return (
      Z.useImperativeHandle(t, () => ({
        getOptions: a,
        isLoadingOptions: () =>
          e.selectedItem.source !== Vt.original && r.current.isLoadingOptions(),
      })),
      (0, $.jsxs)(Uc, {
        children: [
          (0, $.jsx)(`div`, { style: { height: 40, flexShrink: 0 } }),
          (0, $.jsxs)(Wc, {
            children: [
              (0, $.jsx)(Ic, {
                isProExperience: e.selectedItem.isPremiumExperience,
                gameSource: e.game.originalSource,
              }),
              (() => {
                if (e.selectedItem.source === Vt.map) {
                  let t =
                    e.experiencePickerMode === Xa.assignment
                      ? Bt.assignment
                      : Bt.liveGame;
                  return (0, $.jsx)(Ac, {
                    ref: r,
                    game: e.game,
                    groups: e.groups,
                    modeType: t,
                    matchmakerOptions: i,
                    experiencePickerMode: e.experiencePickerMode,
                    selectedItem: e.selectedItem,
                    setErrorMessage: e.setErrorMessage,
                    close: e.close,
                  });
                }
                return (0, $.jsx)(pc, {
                  ref: n,
                  game: e.game,
                  groups: e.groups,
                  matchmakerOptions: i,
                  selectedItem: e.selectedItem,
                  setErrorMessage: e.setErrorMessage,
                });
              })(),
            ],
          }),
        ],
      })
    );
  }),
  Uc = Y.div.attrs({ className: `maxWidth flex-center flex-column` })`
  flex: 1;
`,
  Wc = Y.div`
  width: 90%;
  max-width: 730px;
  background: ${X.White};
  color: ${X.Black};
  box-shadow: 0px 4px 33px -6px rgba(0, 0, 0, 0.46);
  height: 100%;
  border-top-left-radius: 7px;
  border-top-right-radius: 7px;
  padding: 30px;
`,
  Gc = (e) =>
    (0, $.jsx)(Kc, {
      children: (0, $.jsxs)(qc, {
        children: [
          (0, $.jsxs)(Jc, {
            children: [
              `This kit does not contain any questions.`,
              (0, $.jsx)(`br`, {}),
              `Add questions, or`,
              ` `,
              e.mode === Xa.assignment ? `assign` : `host`,
              ` `,
              `a game with another kit.`,
            ],
          }),
          (0, $.jsx)(q, {
            block: !0,
            size: `large`,
            type: `primary`,
            style: { marginTop: 20 },
            onClick: e.close,
            children: `Close`,
          }),
        ],
      }),
    }),
  Kc = Y.div.attrs({ className: `maxAll flex-center` })``,
  qc = Y.div.attrs({ className: `animated fadeIn` })`
  padding: 40px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 5px;
`,
  Jc = Y.div`
  font-size: 24px;
`,
  Yc = (e) => {
    let {
        item: t,
        gameId: r,
        options: i,
        matchmakerOptions: a,
        maxPlayerLimitOverride: o,
        onSuccess: s,
        onError: c,
        onBoth: l,
      } = e,
      u = t.source === Vt.original,
      d = {
        id: t._id,
        name: t.name,
        source: t.source,
        isPremiumGame: t.isPremiumExperience,
      };
    Nt({ event: `game_hosted`, properties: d }),
      n(
        u
          ? {
              url: `/api/matchmaker/intent/live-game/create`,
              data: {
                gameId: r,
                experienceId: t._id,
                gameOptions: i,
                matchmakerOptions: a,
                maxPlayerLimitOverride: o,
              },
              success: (e) => {
                Fo(i), s && s(e);
              },
              error: (e) => {
                c && c(e);
              },
              both: () => {
                l && l();
              },
            }
          : {
              url: `/api/matchmaker/intent/map/play/create`,
              data: {
                experienceId: t._id,
                matchmakerOptions: a,
                options: i,
                maxPlayerLimitOverride: o,
              },
              success: (e) => {
                s && s(e);
              },
              error: (e) => {
                c && c(e);
              },
              both: () => {
                l && l();
              },
            }
      );
  },
  Xc = (e) => {
    let t = (t) => e.setSelectedItemId(t);
    return (0, $.jsxs)(`div`, {
      className: `maxWidth ${Ya.CONTENT_ANIMATION_CLASSNAME}`,
      style: { animationDuration: `${Ya.CONTENT_ANIMATION_DURATION}s` },
      children: [
        (0, $.jsx)(`div`, { style: { height: 40, flexShrink: 0 } }),
        e.lists.map((n) =>
          (0, $.jsxs)(
            Z.Fragment,
            {
              children: [
                (0, $.jsx)(Kt, {
                  list: n,
                  currentlySelectedExperienceId: e.selectedItemId,
                  onExperienceSelected: t,
                  verticalList: !0,
                  hideListName: e.mode === Xa.assignment,
                }),
                (0, $.jsx)(`div`, { style: { height: 50, flexShrink: 0 } }),
              ],
            },
            n._id
          )
        ),
      ],
    });
  },
  Zc = Y.div.attrs({ className: `flex between maxWidth vc` })`
  margin: 35px 0px;
`,
  Qc = Y.div`
  font-size: 58px;
  font-weight: ${Et.UltraBold};
  line-height: 1;
`,
  $c = (e) =>
    (0, $.jsxs)(Zc, {
      children: [
        (0, $.jsxs)(`div`, {
          style: { marginRight: 35 },
          children: [
            (0, $.jsx)(Qc, { children: e.title }),
            e.customUnderTitleComponent ? e.customUnderTitleComponent : null,
          ],
        }),
        e.hideButton
          ? null
          : e.customRightComponent
          ? e.customRightComponent
          : (0, $.jsx)(kt, {
              to: e.buttonLink,
              onClick: e.buttonOnClick,
              children: (0, $.jsx)(q, {
                size: `large`,
                type: `primary`,
                icon: e.buttonIcon,
                children: e.buttonText,
              }),
            }),
      ],
    }),
  el = (e) => {
    let {
      image: t,
      title: n,
      description: r,
      button: i,
      onClick: a,
      hideButton: o,
    } = e;
    return (0, $.jsx)(tl, {
      children: (0, $.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          alignItems: `center`,
          maxWidth: e.customMaxWidth || 540,
        },
        children: [
          (0, $.jsx)(`img`, {
            src: `/client/img/dashboard/${t}.svg`,
            style: { height: 140 },
          }),
          (0, $.jsx)(`div`, {
            style: { fontWeight: Et.UltraBold, fontSize: 60, marginBottom: -8 },
            children: n,
          }),
          (0, $.jsx)(`div`, {
            style: { fontSize: 19, marginBottom: 12 },
            children: r,
          }),
          !o &&
            (0, $.jsx)(q, {
              onClick: a,
              style: { zoom: 1.2 },
              type: `primary`,
              size: `large`,
              icon: (0, $.jsx)(ot, {}),
              children: i,
            }),
        ],
      }),
    });
  },
  tl = Y.div.attrs({ className: `flex-center maxHeight` })`
  flex: 1;
  text-align: center;
  padding: 40px 20px;
`,
  nl = (e) => {
    let [t, i] = Z.useState(!1),
      { assignment: a } = e,
      o = () =>
        (0, $.jsx)(Se, {
          children: (0, $.jsxs)(
            Se.Item,
            {
              onClick: s,
              children: [
                (0, $.jsx)(ct, { style: { marginRight: 7 } }),
                `Delete`,
              ],
            },
            `delete`
          ),
        }),
      s = (t) => {
        t.domEvent.stopPropagation(),
          xe.confirm({
            title: `Are you sure you want to delete this assignment?`,
            cancelText: `No`,
            okText: `Yes`,
            onOk: () => {
              n({
                url: `/api/map-assignment/delete`,
                data: { id: e.assignment._id },
                success: () => {
                  i(!0), l(kl);
                },
                error: (e) =>
                  r({ e, default: { title: `Error deleting assignment` } }),
              });
            },
          });
      };
    if (t)
      return (0, $.jsx)(Xe, {
        bodyStyle: { padding: 30, color: X.Black },
        children: `Deleted assignment`,
      });
    let c = (0, On.default)().isAfter((0, On.default)(a.dueDate));
    return (0, $.jsx)(kt, {
      to: `/assignment/${a._id}`,
      style: { textDecoration: `none` },
      children: (0, $.jsx)(Xe, {
        hoverable: !0,
        bodyStyle: { padding: 30 },
        children: (0, $.jsxs)(rl, {
          children: [
            (0, $.jsxs)(il, {
              children: [
                (0, $.jsx)(al, {
                  style: { color: c ? `#ff6f00` : `#4caf50` },
                  children: (0, $.jsx)(`i`, { className: `fad fa-file-alt` }),
                }),
                (0, $.jsxs)(ol, {
                  children: [
                    (0, $.jsx)(sl, { children: a.title }),
                    (0, $.jsxs)(cl, {
                      children: [
                        `Due `,
                        (0, On.default)(a.dueDate).format(`MMMM Do`),
                      ],
                    }),
                  ],
                }),
              ],
            }),
            (0, $.jsx)(ll, {
              children: (0, $.jsx)(Ce, {
                overlay: o(),
                children: (0, $.jsx)(q, {
                  onClick: (e) => e.preventDefault(),
                  shape: `circle`,
                  icon: (0, $.jsx)(qe, {}),
                }),
              }),
            }),
          ],
        }),
      }),
    });
  },
  rl = Y.div.attrs({ className: `maxWidth between flex vc` })`
  line-height: 1;
  color: ${X.Black};
`,
  il = Y.div.attrs({ className: `flex vc` })``,
  al = Y.div`
  margin-right: 30px;
  font-size: 26px;
`,
  ol = Y.div``,
  sl = Y.div`
  font-weight: ${Et.Bold};
  font-size: 23px;
`,
  cl = Y.div`
  font-size: 15px;
  margin-top: 8px;
  color: rgba(0, 0, 0, 0.9);
`,
  ll = Y.div``,
  ul = [`dashboard-kits`],
  dl = () =>
    xt(ul, () => p({ url: `/api/games/summary/me` }), { staleTime: 1e4 }),
  fl = () => Tt.invalidateQueries(ul),
  pl = (0, $.jsx)($.Fragment, { children: `Create assignments with Pro` }),
  ml = (0, $.jsxs)($.Fragment, {
    children: [
      `Turn your kits into homework so students can play on their own anytime!`,
      ` `,
      (0, $.jsxs)(`b`, {
        children: [`To create an assignment, upgrade to `, mt, ` Pro.`],
      }),
    ],
  }),
  hl = (e) => {
    let [t, n] = Z.useState(`kitSelection`),
      [r, i] = Z.useState(),
      { data: a, isLoading: o } = dl();
    Z.useEffect(() => {
      e.open || n(`kitSelection`);
    }, [e.open]);
    let s = (e) => {
      i(e), n(`experiencePicker`);
    };
    return f()
      ? t === `kitSelection`
        ? (0, $.jsx)(xe, {
            open: e.open,
            onCancel: e.close,
            closable: !0,
            footer: null,
            style: { top: 30, maxWidth: 1e3 },
            width: `90%`,
            children: (() => {
              var e;
              if (o)
                return (0, $.jsx)(`div`, {
                  className: `maxWidth flex-center`,
                  style: { minHeight: 200 },
                  children: (0, $.jsx)(Ze, { size: `large` }),
                });
              let t =
                a == null || (e = a.games) == null
                  ? void 0
                  : e.filter((e) => !e.isArchived);
              return t.length
                ? (0, $.jsxs)(_l, {
                    children: [
                      (0, $.jsx)(xl, {
                        children: `Choose a kit for this assignment...`,
                      }),
                      t.map((e, n) =>
                        (0, $.jsxs)(
                          Z.Fragment,
                          {
                            children: [
                              (0, $.jsx)(gl, {
                                game: e,
                                onSelect: () => s(e._id),
                              }),
                              n !== t.length - 1 &&
                                (0, $.jsx)(`div`, { style: { height: 15 } }),
                            ],
                          },
                          `preview-${e._id}`
                        )
                      ),
                    ],
                  })
                : (0, $.jsxs)(_l, {
                    children: [
                      (0, $.jsx)(vl, {}),
                      (0, $.jsx)(yl, { children: `Create a kit first!` }),
                      (0, $.jsx)(bl, {
                        children: `Use kits to assign sets of questions to your students as homework.`,
                      }),
                      (0, $.jsx)(kt, {
                        to: ht,
                        children: (0, $.jsx)(q, {
                          size: `large`,
                          type: `primary`,
                          style: { width: 300, height: 60, marginTop: 25 },
                          children: `Create A Kit`,
                        }),
                      }),
                    ],
                  });
            })(),
          })
        : e.open && t === `experiencePicker` && r
        ? (0, $.jsx)(Fl, { gameId: r, close: e.close, mode: Xa.assignment })
        : null
      : (0, $.jsx)(Jt, {
          id: `assignment creation`,
          visible: e.open,
          copy: { title: pl, description: ml },
          close: e.close,
        });
  },
  gl = (e) => {
    let { game: t } = e;
    return (0, $.jsx)(Xe, {
      className: `maxWidth`,
      hoverable: !0,
      onClick: e.onSelect,
      children: (0, $.jsxs)(Sl, {
        children: [
          (0, $.jsx)(Ht, { image: t.gif, size: 56, blockModalOpen: !0 }),
          (0, $.jsx)(Cl, { children: t.title }),
        ],
      }),
    });
  },
  _l = Y.div.attrs({ className: `flex-column flex-center` })`
  color: ${X.Black};
  font-family: ${Ct.SFPro};
  padding: 20px 15px;
  text-align: center;
`,
  vl = Y.img.attrs({ src: `/client/img/dashboard/kit.svg` })`
  height: 100px;
`,
  yl = Y.div`
  font-size: 36px;
  font-weight: ${Et.UltraBold};
  margin-top: 20px;
`,
  bl = Y.div`
  font-size: 18px;
  color: rgba(0, 0, 0, 0.9);
`,
  xl = Y.div`
  font-size: 32px;
  font-weight: ${Et.UltraBold};
  margin-bottom: 22px;
`,
  Sl = Y.div.attrs({ className: `flex vc` })`
  color: rgba(0, 0, 0, 0.84);
`,
  Cl = Y.div`
  font-size: 22px;
  font-weight: ${Et.Bold};
  margin-left: 20px;
`,
  wl = `90%`,
  Tl = (e) =>
    (0, $.jsxs)(El, {
      children: [
        (0, $.jsx)(Dl, { children: e.header }),
        (0, $.jsx)(Ol, { style: e.contentStyle, children: e.children }),
      ],
    }),
  El = Y.div.attrs({ className: `flex-column vc` })`
  flex: 1;
`,
  Dl = Y.div`
  width: ${wl};
`,
  Ol = Y(At)`
  flex: 1;
  padding: 35px;
  border-radius: 9px;
  border-bottom-left-radius: 0px;
  border-bottom-right-radius: 0px;
  width: ${wl};
  overflow: visible;
`,
  kl = `assignment-list`,
  Al = () => {
    let [e, t, n] = i(!1),
      [r, a] = Z.useState(!0),
      [o, s] = Z.useState(0);
    return (
      St(() => {
        wt() && Sn();
      }),
      (0, $.jsxs)($.Fragment, {
        children: [
          (0, $.jsx)(u, { title: `Assignments` }),
          !o && !r
            ? (0, $.jsx)(el, {
                image: `homework`,
                title: `Assignments`,
                description: `Turn your kits into fun independent study activities that are graded automatically! Assignments are perfect for homework, extra credit opportunities, and remote education.`,
                button: `New Assignment`,
                onClick: t,
              })
            : (0, $.jsx)(Tl, {
                header: (0, $.jsx)($c, {
                  title: `Assignments`,
                  buttonText: `New Assignment`,
                  buttonIcon: (0, $.jsx)(ot, {}),
                  buttonOnClick: t,
                }),
                children: (0, $.jsx)(jl, {
                  style: { opacity: +!r },
                  children: (0, $.jsx)(xn, {
                    url: `/api/map-assignment/all`,
                    cacheKey: kl,
                    limit: 20,
                    defaultPage: 1,
                    scrollStyle: { width: `100%`, overflow: `visible` },
                    toRender: (e) =>
                      (0, $.jsxs)(
                        Z.Fragment,
                        {
                          children: [
                            (0, $.jsx)(nl, { assignment: e }),
                            (0, $.jsx)(`div`, { style: { height: 15 } }),
                          ],
                        },
                        `assignment-${e._id}`
                      ),
                    onTotalItems: (e) => {
                      s(e), a(!1);
                    },
                    loader: (0, $.jsx)(`div`, {
                      className: `maxWidth flex hc`,
                      style: { marginTop: 20 },
                      children: (0, $.jsx)(Ze, { size: `large` }),
                    }),
                  }),
                }),
              }),
          (0, $.jsx)(hl, { open: e, close: n }),
        ],
      })
    );
  },
  jl = Y.div.attrs({ className: `flex maxWidth maxHeight flex-column` })``,
  Ml = (e) => {
    let {
        item: t,
        game: r,
        options: i,
        assignmentOptions: a,
        onSuccess: o,
        onError: s,
        onBoth: c,
      } = e,
      u;
    r && (u = r.title + ` - ` + t.name),
      Nt({
        event: `assignment_created`,
        properties: { id: t._id, name: t.name },
      }),
      n({
        url: `/api/map-assignment/create`,
        data: {
          experienceId: t._id,
          dueDate: a.dueDate,
          groups: a.groups,
          customTitle: u,
          hooks:
            i && i != null && i.hookOptions
              ? JSON.stringify(i.hookOptions)
              : void 0,
        },
        success: (e) => {
          l(kl), o && o(e);
        },
        error: (e) => {
          s && s(e);
        },
        both: () => {
          c && c();
        },
      });
  },
  Nl = () => {
    let e = window.open(``);
    return {
      openTab: (t) => {
        e ? (e.location.href = t) : (window.location.href = t);
      },
      closeTab: () => {
        e && e.close();
      },
    };
  },
  Pl = `EXPERIENCE_GROUP_CACHE`,
  Fl = (e) => {
    let t = Z.useRef(),
      a = Z.useRef(),
      [o, c] = i(!1),
      [l, u] = Z.useState(``),
      [p, h] = Z.useState([]),
      [g, _] = Z.useState([]),
      [v, y] = Z.useState(),
      [b, x] = Z.useState([]),
      [S, C] = Z.useState(``),
      [w, T] = Z.useState(!1),
      [E, D] = i(!1),
      { data: O } = Nc(),
      k = Yt(),
      A = Xt(),
      j = f(),
      M = s(),
      N = Z.useMemo(() => p.find((e) => e._id === l), [l, p.length]),
      P = Z.useMemo(() => {
        if (!(j || M) && k === Wt.limitedGames && O)
          return (O == null ? void 0 : O.count) >= A;
      }, [k, O, A, j, M]);
    Z.useEffect(() => {
      N &&
        N._id &&
        N.source === Vt.map &&
        n({
          url: `/api/experience/map/hooks`,
          data: { experience: N._id },
          cacheKey: `EXPERIENCE_HOOKS`,
        });
    }, [N == null ? void 0 : N._id]),
      Z.useEffect(() => {
        n({
          url: `/api/games/fetch/${e.gameId}`,
          cacheKey: `EXPERIENCE_GAME_CACHE`,
          success: (e) => {
            y(e.kit);
          },
        }),
          n({ url: `/api/v1/groups`, cacheKey: Pl, success: (e) => x(e) });
      }, []),
      Z.useEffect(() => {
        _([]),
          h([]),
          n({
            url: `/api/experiences`,
            data: {
              mode: e.mode === Xa.assignment ? `assignment` : `liveGame`,
              forceUpgradedExperiences: Yt() !== Wt.limitedModes,
            },
            cacheKey: `EXPERIENCES`,
            success: (e) => {
              let t = ``,
                n = [];
              e &&
                e.length &&
                (e.forEach((e) => {
                  e.items.forEach((e) => {
                    t || (t = e._id),
                      n.map((e) => e._id).includes(e._id) || n.push(e);
                  });
                }),
                h(n),
                u(t),
                _(e));
            },
          });
      }, [e.mode]),
      Z.useEffect(() => {
        m(`https://fonts.googleapis.com/css2?family=Fugaz+One&display=swap`);
      }, []),
      Z.useEffect(() => {
        let e = window.setTimeout(() => {
          D();
        }, 800);
        return () => window.clearTimeout(e);
      }, []);
    let F = (e) => h(e),
      I = (e) => u(e),
      L = () => {
        t.current && t.current.scrollTo({ top: 0, behavior: `smooth` });
      };
    return (0, $.jsx)(So, {
      ref: t,
      close: e.close,
      children: (0, $.jsx)(W, {
        theme: { token: { fontFamily: Ct.ProductSans } },
        children:
          !v || !g.length || !E
            ? (0, $.jsxs)(`div`, {
                className: `flex-center maxAll`,
                children: [
                  (0, $.jsx)(Lt, {}),
                  (0, $.jsx)(`div`, {
                    style: { fontFamily: qt.titleFont, fontSize: 0 },
                    children: `L`,
                  }),
                  (0, $.jsx)(`div`, {
                    style: { fontFamily: Ct.ProductSans, fontSize: 0 },
                    children: `L`,
                  }),
                ],
              })
            : v.questions.length
            ? (0, $.jsxs)($.Fragment, {
                children: [
                  N
                    ? (0, $.jsx)(yo, {
                        title: N.name,
                        description: N.tagline,
                        labels: N.labels,
                        onContinue: () => {
                          if (!o) c(), L();
                          else {
                            if (w || !a.current || a.current.isLoadingOptions())
                              return;
                            T(!0);
                            let t = a.current.getOptions();
                            if (e.mode === Xa.assignment)
                              Ml({
                                item: N,
                                game: v,
                                options: t.options,
                                assignmentOptions: t.assignmentOptions,
                                onSuccess: (e) => {
                                  Mt(`/assignment/${e}`);
                                },
                                onError: (e) => {
                                  r({
                                    e,
                                    default: {
                                      title: `Error creating assignment`,
                                    },
                                  });
                                },
                                onBoth: () => {
                                  T(!1);
                                },
                              });
                            else if (e.mode === Xa.liveGame) {
                              let { openTab: n, closeTab: i } = Nl();
                              Yc({
                                item: N,
                                gameId: e.gameId,
                                options: t.options,
                                matchmakerOptions: t.matchmakerOptions,
                                maxPlayerLimitOverride: P,
                                onSuccess: (t) => {
                                  let r = `${d()}/host?id=${t}`;
                                  e.close(), n(r);
                                },
                                onError: (e) => {
                                  r({
                                    e,
                                    default: {
                                      title: `There was an error starting your game.`,
                                      content: `If the issue persists, please contact support.`,
                                    },
                                  }),
                                    i(),
                                    T(!1);
                                },
                              });
                            }
                          }
                        },
                        pageId: N.pageId,
                        errorMessage: S,
                        loading: w,
                        noReportErrorMessage:
                          N.originalId === `DRAW` && o
                            ? `We don't generate reports for this mode. To get a report, play a kit you own with a mode that supports reports.`
                            : null,
                        mode: e.mode,
                      })
                    : null,
                  o
                    ? (0, $.jsx)(Hc, {
                        ref: a,
                        game: v,
                        groups: b,
                        experiencePickerMode: e.mode,
                        selectedItem: N,
                        setErrorMessage: C,
                        close: e.close,
                      })
                    : (0, $.jsx)(Xc, {
                        lists: g,
                        selectedItemId: l,
                        setItems: F,
                        setSelectedItemId: I,
                        mode: e.mode,
                      }),
                ],
              })
            : (0, $.jsx)(Gc, { close: e.close, mode: e.mode }),
      }),
    });
  };
export {
  ml as a,
  dl as c,
  Nc as d,
  jc as f,
  Tl as i,
  el as l,
  Ja as m,
  Fl as n,
  pl as o,
  Xa as p,
  Al as r,
  fl as s,
  Pl as t,
  $c as u,
};
