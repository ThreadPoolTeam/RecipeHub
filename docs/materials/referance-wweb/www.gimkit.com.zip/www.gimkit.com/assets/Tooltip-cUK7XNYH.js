import { n as e, o as t } from "./rolldown-runtime-C0FnF6B9.js";
import { n, t as r } from "./dist-Cmw-iXzl.js";
import { t as i } from "./react-IpA8Qn9U.js";
import { c as a, l as o, s } from "./assertThisInitialized-DqpgQyeg.js";
import {
  It as c,
  Lt as l,
  it as u,
  lt as d,
  nt as f,
  rt as p,
  tt as m,
  ut as h,
} from "./Compact-CRRKXVA1.js";
import { n as g, t as _ } from "./inheritsLoose-BimZ4dLJ.js";
import {
  J as v,
  K as y,
  W as b,
  a as x,
  c as S,
  i as C,
  l as w,
  m as T,
  n as E,
  o as D,
  q as O,
  r as ee,
  s as k,
  t as A,
} from "./clsx.m-Cobbdkh4.js";
var te = t(o());
a(), h(), u(), f(), g(), w();
var j = t(i());
S();
function ne() {
  return T() || k;
}
function re() {
  return [...arguments].reduce(
    function (e, t) {
      return t == null
        ? e
        : function () {
            var n = [...arguments];
            e.apply(this, n), t.apply(this, n);
          };
    },
    function () {}
  );
}
var M = e(() => {});
function N(e, t) {
  typeof e == `function` ? e(t) : e && (e.current = t);
}
var P = e(() => {});
function ie(e) {
  var t = e.controlled,
    n = e.default;
  e.name, e.state;
  var r = F.useRef(t !== void 0).current,
    i = F.useState(n),
    a = i[0],
    o = i[1];
  return [
    r ? t : a,
    F.useCallback(function (e) {
      r || o(e);
    }, []),
  ];
}
var F,
  ae = e(() => {
    F = t(i());
  });
function I(e, t) {
  return oe.useMemo(
    function () {
      return e == null && t == null
        ? null
        : function (n) {
            N(e, n), N(t, n);
          };
    },
    [e, t]
  );
}
var oe,
  L = e(() => {
    (oe = t(i())), P();
  });
function se(e) {
  var t = ce.useState(e),
    n = t[0],
    r = t[1],
    i = e || n;
  return (
    ce.useEffect(
      function () {
        n ?? r(`mui-${Math.round(Math.random() * 1e5)}`);
      },
      [n]
    ),
    i
  );
}
var ce,
  le = e(() => {
    ce = t(i());
  });
function ue(e) {
  var t = e.type,
    n = e.tagName;
  return !!(
    (n === `INPUT` && ve[t] && !e.readOnly) ||
    (n === `TEXTAREA` && !e.readOnly) ||
    e.isContentEditable
  );
}
function de(e) {
  e.metaKey || e.altKey || e.ctrlKey || (z = !0);
}
function fe() {
  z = !1;
}
function pe() {
  this.visibilityState === `hidden` && B && (z = !0);
}
function R(e) {
  e.addEventListener(`keydown`, de, !0),
    e.addEventListener(`mousedown`, fe, !0),
    e.addEventListener(`pointerdown`, fe, !0),
    e.addEventListener(`touchstart`, fe, !0),
    e.addEventListener(`visibilitychange`, pe, !0);
}
function me(e) {
  var t = e.target;
  try {
    return t.matches(`:focus-visible`);
  } catch {}
  return z || ue(t);
}
function he() {
  (B = !0),
    window.clearTimeout(V),
    (V = window.setTimeout(function () {
      B = !1;
    }, 100));
}
function ge() {
  return {
    isFocusVisible: me,
    onBlurVisible: he,
    ref: _e.useCallback(function (e) {
      var t = te.findDOMNode(e);
      t != null && R(t.ownerDocument);
    }, []),
  };
}
var _e,
  z,
  B,
  V,
  ve,
  H = e(() => {
    (_e = t(i())),
      (z = !0),
      (B = !1),
      (V = null),
      (ve = {
        text: !0,
        search: !0,
        url: !0,
        tel: !0,
        email: !0,
        password: !0,
        number: !0,
        date: !0,
        month: !0,
        week: !0,
        time: !0,
        datetime: !0,
        "datetime-local": !0,
      });
  }),
  ye = { disabled: !1 },
  be = j.createContext(null),
  xe = function (e) {
    return e.scrollTop;
  },
  U = t(o()),
  Se = `unmounted`,
  W = `exited`,
  G = `entering`,
  Ce = `entered`,
  we = `exiting`,
  K = (function (e) {
    _(t, e);
    function t(t, n) {
      var r = e.call(this, t, n) || this,
        i = n,
        a = i && !i.isMounting ? t.enter : t.appear,
        o;
      return (
        (r.appearStatus = null),
        t.in
          ? a
            ? ((o = W), (r.appearStatus = G))
            : (o = Ce)
          : (o = t.unmountOnExit || t.mountOnEnter ? Se : W),
        (r.state = { status: o }),
        (r.nextCallback = null),
        r
      );
    }
    t.getDerivedStateFromProps = function (e, t) {
      return e.in && t.status === `unmounted` ? { status: W } : null;
    };
    var n = t.prototype;
    return (
      (n.componentDidMount = function () {
        this.updateStatus(!0, this.appearStatus);
      }),
      (n.componentDidUpdate = function (e) {
        var t = null;
        if (e !== this.props) {
          var n = this.state.status;
          this.props.in
            ? n !== `entering` && n !== `entered` && (t = G)
            : (n === `entering` || n === `entered`) && (t = we);
        }
        this.updateStatus(!1, t);
      }),
      (n.componentWillUnmount = function () {
        this.cancelNextCallback();
      }),
      (n.getTimeouts = function () {
        var e = this.props.timeout,
          t = (n = r = e),
          n,
          r;
        return (
          e != null &&
            typeof e != `number` &&
            ((t = e.exit),
            (n = e.enter),
            (r = e.appear === void 0 ? n : e.appear)),
          { exit: t, enter: n, appear: r }
        );
      }),
      (n.updateStatus = function (e, t) {
        if ((e === void 0 && (e = !1), t !== null)) {
          if ((this.cancelNextCallback(), t === `entering`)) {
            if (this.props.unmountOnExit || this.props.mountOnEnter) {
              var n = this.props.nodeRef
                ? this.props.nodeRef.current
                : U.findDOMNode(this);
              n && xe(n);
            }
            this.performEnter(e);
          } else this.performExit();
        } else
          this.props.unmountOnExit &&
            this.state.status === `exited` &&
            this.setState({ status: Se });
      }),
      (n.performEnter = function (e) {
        var t = this,
          n = this.props.enter,
          r = this.context ? this.context.isMounting : e,
          i = this.props.nodeRef ? [r] : [U.findDOMNode(this), r],
          a = i[0],
          o = i[1],
          s = this.getTimeouts(),
          c = r ? s.appear : s.enter;
        (!e && !n) || ye.disabled
          ? this.safeSetState({ status: Ce }, function () {
              t.props.onEntered(a);
            })
          : (this.props.onEnter(a, o),
            this.safeSetState({ status: G }, function () {
              t.props.onEntering(a, o),
                t.onTransitionEnd(c, function () {
                  t.safeSetState({ status: Ce }, function () {
                    t.props.onEntered(a, o);
                  });
                });
            }));
      }),
      (n.performExit = function () {
        var e = this,
          t = this.props.exit,
          n = this.getTimeouts(),
          r = this.props.nodeRef ? void 0 : U.findDOMNode(this);
        !t || ye.disabled
          ? this.safeSetState({ status: W }, function () {
              e.props.onExited(r);
            })
          : (this.props.onExit(r),
            this.safeSetState({ status: we }, function () {
              e.props.onExiting(r),
                e.onTransitionEnd(n.exit, function () {
                  e.safeSetState({ status: W }, function () {
                    e.props.onExited(r);
                  });
                });
            }));
      }),
      (n.cancelNextCallback = function () {
        this.nextCallback !== null &&
          (this.nextCallback.cancel(), (this.nextCallback = null));
      }),
      (n.safeSetState = function (e, t) {
        (t = this.setNextCallback(t)), this.setState(e, t);
      }),
      (n.setNextCallback = function (e) {
        var t = this,
          n = !0;
        return (
          (this.nextCallback = function (r) {
            n && ((n = !1), (t.nextCallback = null), e(r));
          }),
          (this.nextCallback.cancel = function () {
            n = !1;
          }),
          this.nextCallback
        );
      }),
      (n.onTransitionEnd = function (e, t) {
        this.setNextCallback(t);
        var n = this.props.nodeRef
            ? this.props.nodeRef.current
            : U.findDOMNode(this),
          r = e == null && !this.props.addEndListener;
        if (!n || r) setTimeout(this.nextCallback, 0);
        else {
          if (this.props.addEndListener) {
            var i = this.props.nodeRef
                ? [this.nextCallback]
                : [n, this.nextCallback],
              a = i[0],
              o = i[1];
            this.props.addEndListener(a, o);
          }
          e != null && setTimeout(this.nextCallback, e);
        }
      }),
      (n.render = function () {
        var e = this.state.status;
        if (e === `unmounted`) return null;
        var t = this.props,
          n = t.children;
        t.in,
          t.mountOnEnter,
          t.unmountOnExit,
          t.appear,
          t.enter,
          t.exit,
          t.timeout,
          t.addEndListener,
          t.onEnter,
          t.onEntering,
          t.onEntered,
          t.onExit,
          t.onExiting,
          t.onExited,
          t.nodeRef;
        var r = p(t, [
          `children`,
          `in`,
          `mountOnEnter`,
          `unmountOnExit`,
          `appear`,
          `enter`,
          `exit`,
          `timeout`,
          `addEndListener`,
          `onEnter`,
          `onEntering`,
          `onEntered`,
          `onExit`,
          `onExiting`,
          `onExited`,
          `nodeRef`,
        ]);
        return j.createElement(
          be.Provider,
          { value: null },
          typeof n == `function`
            ? n(e, r)
            : j.cloneElement(j.Children.only(n), r)
        );
      }),
      t
    );
  })(j.Component);
(K.contextType = be), (K.propTypes = {});
function q() {}
(K.defaultProps = {
  in: !1,
  mountOnEnter: !1,
  unmountOnExit: !1,
  appear: !1,
  enter: !0,
  exit: !0,
  onEnter: q,
  onEntering: q,
  onEntered: q,
  onExit: q,
  onExiting: q,
  onExited: q,
}),
  (K.UNMOUNTED = Se),
  (K.EXITED = W),
  (K.ENTERING = G),
  (K.ENTERED = Ce),
  (K.EXITING = we),
  L();
var Te = function (e) {
  return e.scrollTop;
};
function Ee(e, t) {
  var n = e.timeout,
    r = e.style,
    i = r === void 0 ? {} : r;
  return {
    duration: i.transitionDuration || typeof n == `number` ? n : n[t.mode] || 0,
    delay: i.transitionDelay,
  };
}
P();
function De(e) {
  return (e = typeof e == `function` ? e() : e), U.findDOMNode(e);
}
var Oe = typeof window < `u` ? j.useLayoutEffect : j.useEffect,
  ke = j.forwardRef(function (e, t) {
    var n = e.children,
      r = e.container,
      i = e.disablePortal,
      a = i !== void 0 && i,
      o = e.onRendered,
      s = j.useState(null),
      c = s[0],
      l = s[1],
      u = I(j.isValidElement(n) ? n.ref : null, t);
    return (
      Oe(
        function () {
          a || l(De(r) || document.body);
        },
        [r, a]
      ),
      Oe(
        function () {
          if (c && !a)
            return (
              N(t, c),
              function () {
                N(t, null);
              }
            );
        },
        [t, c, a]
      ),
      Oe(
        function () {
          o && (c || a) && o();
        },
        [o, c, a]
      ),
      a
        ? j.isValidElement(n)
          ? j.cloneElement(n, { ref: u })
          : n
        : c && U.createPortal(n, c)
    );
  });
L();
function Ae(e) {
  return `scale(${e}, ${e ** 2})`;
}
var je = {
    entering: { opacity: 1, transform: Ae(1) },
    entered: { opacity: 1, transform: `none` },
  },
  Me = j.forwardRef(function (e, t) {
    var n = e.children,
      r = e.disableStrictModeCompat,
      i = r !== void 0 && r,
      a = e.in,
      o = e.onEnter,
      c = e.onEntered,
      l = e.onEntering,
      u = e.onExit,
      f = e.onExited,
      p = e.onExiting,
      h = e.style,
      g = e.timeout,
      _ = g === void 0 ? `auto` : g,
      v = e.TransitionComponent,
      y = v === void 0 ? K : v,
      b = m(e, [
        `children`,
        `disableStrictModeCompat`,
        `in`,
        `onEnter`,
        `onEntered`,
        `onEntering`,
        `onExit`,
        `onExited`,
        `onExiting`,
        `style`,
        `timeout`,
        `TransitionComponent`,
      ]),
      x = j.useRef(),
      S = j.useRef(),
      C = ne(),
      w = C.unstable_strictMode && !i,
      T = j.useRef(null),
      E = I(n.ref, t),
      D = I(w ? T : void 0, E),
      O = function (e) {
        return function (t, n) {
          if (e) {
            var r = w ? [T.current, t] : [t, n],
              i = d(r, 2),
              a = i[0],
              o = i[1];
            o === void 0 ? e(a) : e(a, o);
          }
        };
      },
      ee = O(l),
      k = O(function (e, t) {
        Te(e);
        var n = Ee({ style: h, timeout: _ }, { mode: `enter` }),
          r = n.duration,
          i = n.delay,
          a;
        _ === `auto`
          ? ((a = C.transitions.getAutoHeightDuration(e.clientHeight)),
            (S.current = a))
          : (a = r),
          (e.style.transition = [
            C.transitions.create(`opacity`, { duration: a, delay: i }),
            C.transitions.create(`transform`, {
              duration: a * 0.666,
              delay: i,
            }),
          ].join(`,`)),
          o && o(e, t);
      }),
      A = O(c),
      te = O(p),
      re = O(function (e) {
        var t = Ee({ style: h, timeout: _ }, { mode: `exit` }),
          n = t.duration,
          r = t.delay,
          i;
        _ === `auto`
          ? ((i = C.transitions.getAutoHeightDuration(e.clientHeight)),
            (S.current = i))
          : (i = n),
          (e.style.transition = [
            C.transitions.create(`opacity`, { duration: i, delay: r }),
            C.transitions.create(`transform`, {
              duration: i * 0.666,
              delay: r || i * 0.333,
            }),
          ].join(`,`)),
          (e.style.opacity = `0`),
          (e.style.transform = Ae(0.75)),
          u && u(e);
      }),
      M = O(f);
    return (
      j.useEffect(function () {
        return function () {
          clearTimeout(x.current);
        };
      }, []),
      j.createElement(
        y,
        s(
          {
            appear: !0,
            in: a,
            nodeRef: w ? T : void 0,
            onEnter: k,
            onEntered: A,
            onEntering: ee,
            onExit: re,
            onExited: M,
            onExiting: te,
            addEndListener: function (e, t) {
              _ === `auto` &&
                (x.current = setTimeout(w ? e : t, S.current || 0));
            },
            timeout: _ === `auto` ? null : _,
          },
          b
        ),
        function (e, t) {
          return j.cloneElement(
            n,
            s(
              {
                style: s(
                  {
                    opacity: 0,
                    transform: Ae(0.75),
                    visibility: e === `exited` && !a ? `hidden` : void 0,
                  },
                  je[e],
                  h,
                  n.props.style
                ),
                ref: D,
              },
              t
            )
          );
        }
      )
    );
  });
(Me.muiSupportAuto = !0), n();
var J = typeof window < `u` && typeof document < `u` && typeof navigator < `u`,
  Ne = (function () {
    for (var e = [`Edge`, `Trident`, `Firefox`], t = 0; t < e.length; t += 1)
      if (J && navigator.userAgent.indexOf(e[t]) >= 0) return 1;
    return 0;
  })();
function Pe(e) {
  var t = !1;
  return function () {
    t ||
      ((t = !0),
      window.Promise.resolve().then(function () {
        (t = !1), e();
      }));
  };
}
function Fe(e) {
  var t = !1;
  return function () {
    t ||
      ((t = !0),
      setTimeout(function () {
        (t = !1), e();
      }, Ne));
  };
}
var Ie = J && window.Promise ? Pe : Fe;
function Le(e) {
  return e && {}.toString.call(e) === `[object Function]`;
}
function Y(e, t) {
  if (e.nodeType !== 1) return [];
  var n = e.ownerDocument.defaultView.getComputedStyle(e, null);
  return t ? n[t] : n;
}
function Re(e) {
  return e.nodeName === `HTML` ? e : e.parentNode || e.host;
}
function ze(e) {
  if (!e) return document.body;
  switch (e.nodeName) {
    case `HTML`:
    case `BODY`:
      return e.ownerDocument.body;
    case `#document`:
      return e.body;
  }
  var t = Y(e),
    n = t.overflow,
    r = t.overflowX,
    i = t.overflowY;
  return /(auto|scroll|overlay)/.test(n + i + r) ? e : ze(Re(e));
}
function X(e) {
  return e && e.referenceNode ? e.referenceNode : e;
}
var Z = J && !!(window.MSInputMethodContext && document.documentMode),
  Be = J && /MSIE 10/.test(navigator.userAgent);
function Ve(e) {
  return e === 11 ? Z : e === 10 ? Be : Z || Be;
}
function He(e) {
  if (!e) return document.documentElement;
  for (
    var t = Ve(10) ? document.body : null, n = e.offsetParent || null;
    n === t && e.nextElementSibling;

  )
    n = (e = e.nextElementSibling).offsetParent;
  var r = n && n.nodeName;
  return !r || r === `BODY` || r === `HTML`
    ? e
      ? e.ownerDocument.documentElement
      : document.documentElement
    : [`TH`, `TD`, `TABLE`].indexOf(n.nodeName) !== -1 &&
      Y(n, `position`) === `static`
    ? He(n)
    : n;
}
function Ue(e) {
  var t = e.nodeName;
  return t === `BODY` ? !1 : t === `HTML` || He(e.firstElementChild) === e;
}
function We(e) {
  return e.parentNode === null ? e : We(e.parentNode);
}
function Ge(e, t) {
  if (!e || !e.nodeType || !t || !t.nodeType) return document.documentElement;
  var n = e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING,
    r = n ? e : t,
    i = n ? t : e,
    a = document.createRange();
  a.setStart(r, 0), a.setEnd(i, 0);
  var o = a.commonAncestorContainer;
  if ((e !== o && t !== o) || r.contains(i)) return Ue(o) ? o : He(o);
  var s = We(e);
  return s.host ? Ge(s.host, t) : Ge(e, We(t).host);
}
function Ke(e) {
  var t =
      (arguments.length > 1 && arguments[1] !== void 0
        ? arguments[1]
        : `top`) === `top`
        ? `scrollTop`
        : `scrollLeft`,
    n = e.nodeName;
  if (n === `BODY` || n === `HTML`) {
    var r = e.ownerDocument.documentElement;
    return (e.ownerDocument.scrollingElement || r)[t];
  }
  return e[t];
}
function qe(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2],
    r = Ke(t, `top`),
    i = Ke(t, `left`),
    a = n ? -1 : 1;
  return (
    (e.top += r * a),
    (e.bottom += r * a),
    (e.left += i * a),
    (e.right += i * a),
    e
  );
}
function Je(e, t) {
  var n = t === `x` ? `Left` : `Top`,
    r = n === `Left` ? `Right` : `Bottom`;
  return (
    parseFloat(e[`border` + n + `Width`]) +
    parseFloat(e[`border` + r + `Width`])
  );
}
function Ye(e, t, n, r) {
  return Math.max(
    t[`offset` + e],
    t[`scroll` + e],
    n[`client` + e],
    n[`offset` + e],
    n[`scroll` + e],
    Ve(10)
      ? parseInt(n[`offset` + e]) +
          parseInt(r[`margin` + (e === `Height` ? `Top` : `Left`)]) +
          parseInt(r[`margin` + (e === `Height` ? `Bottom` : `Right`)])
      : 0
  );
}
function Xe(e) {
  var t = e.body,
    n = e.documentElement,
    r = Ve(10) && getComputedStyle(n);
  return { height: Ye(`Height`, t, n, r), width: Ye(`Width`, t, n, r) };
}
var Ze = function (e, t) {
    if (!(e instanceof t)) throw TypeError(`Cannot call a class as a function`);
  },
  Qe = (function () {
    function e(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        (r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          `value` in r && (r.writable = !0),
          Object.defineProperty(e, r.key, r);
      }
    }
    return function (t, n, r) {
      return n && e(t.prototype, n), r && e(t, r), t;
    };
  })(),
  $e = function (e, t, n) {
    return (
      t in e
        ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0,
          })
        : (e[t] = n),
      e
    );
  },
  Q =
    Object.assign ||
    function (e) {
      for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n)
          Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
      }
      return e;
    };
function $(e) {
  return Q({}, e, { right: e.left + e.width, bottom: e.top + e.height });
}
function et(e) {
  var t = {};
  try {
    if (Ve(10)) {
      t = e.getBoundingClientRect();
      var n = Ke(e, `top`),
        r = Ke(e, `left`);
      (t.top += n), (t.left += r), (t.bottom += n), (t.right += r);
    } else t = e.getBoundingClientRect();
  } catch {}
  var i = {
      left: t.left,
      top: t.top,
      width: t.right - t.left,
      height: t.bottom - t.top,
    },
    a = e.nodeName === `HTML` ? Xe(e.ownerDocument) : {},
    o = a.width || e.clientWidth || i.width,
    s = a.height || e.clientHeight || i.height,
    c = e.offsetWidth - o,
    l = e.offsetHeight - s;
  if (c || l) {
    var u = Y(e);
    (c -= Je(u, `x`)), (l -= Je(u, `y`)), (i.width -= c), (i.height -= l);
  }
  return $(i);
}
function tt(e, t) {
  var n = arguments.length > 2 && arguments[2] !== void 0 && arguments[2],
    r = Ve(10),
    i = t.nodeName === `HTML`,
    a = et(e),
    o = et(t),
    s = ze(e),
    c = Y(t),
    l = parseFloat(c.borderTopWidth),
    u = parseFloat(c.borderLeftWidth);
  n && i && ((o.top = Math.max(o.top, 0)), (o.left = Math.max(o.left, 0)));
  var d = $({
    top: a.top - o.top - l,
    left: a.left - o.left - u,
    width: a.width,
    height: a.height,
  });
  if (((d.marginTop = 0), (d.marginLeft = 0), !r && i)) {
    var f = parseFloat(c.marginTop),
      p = parseFloat(c.marginLeft);
    (d.top -= l - f),
      (d.bottom -= l - f),
      (d.left -= u - p),
      (d.right -= u - p),
      (d.marginTop = f),
      (d.marginLeft = p);
  }
  return (
    (r && !n ? t.contains(s) : t === s && s.nodeName !== `BODY`) &&
      (d = qe(d, t)),
    d
  );
}
function nt(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
    n = e.ownerDocument.documentElement,
    r = tt(e, n),
    i = Math.max(n.clientWidth, window.innerWidth || 0),
    a = Math.max(n.clientHeight, window.innerHeight || 0),
    o = t ? 0 : Ke(n),
    s = t ? 0 : Ke(n, `left`);
  return $({
    top: o - r.top + r.marginTop,
    left: s - r.left + r.marginLeft,
    width: i,
    height: a,
  });
}
function rt(e) {
  var t = e.nodeName;
  if (t === `BODY` || t === `HTML`) return !1;
  if (Y(e, `position`) === `fixed`) return !0;
  var n = Re(e);
  return n ? rt(n) : !1;
}
function it(e) {
  if (!e || !e.parentElement || Ve()) return document.documentElement;
  for (var t = e.parentElement; t && Y(t, `transform`) === `none`; )
    t = t.parentElement;
  return t || document.documentElement;
}
function at(e, t, n, r) {
  var i = arguments.length > 4 && arguments[4] !== void 0 && arguments[4],
    a = { top: 0, left: 0 },
    o = i ? it(e) : Ge(e, X(t));
  if (r === `viewport`) a = nt(o, i);
  else {
    var s = void 0;
    r === `scrollParent`
      ? ((s = ze(Re(t))),
        s.nodeName === `BODY` && (s = e.ownerDocument.documentElement))
      : (s = r === `window` ? e.ownerDocument.documentElement : r);
    var c = tt(s, o, i);
    if (s.nodeName === `HTML` && !rt(o)) {
      var l = Xe(e.ownerDocument),
        u = l.height,
        d = l.width;
      (a.top += c.top - c.marginTop),
        (a.bottom = u + c.top),
        (a.left += c.left - c.marginLeft),
        (a.right = d + c.left);
    } else a = c;
  }
  n = n || 0;
  var f = typeof n == `number`;
  return (
    (a.left += f ? n : n.left || 0),
    (a.top += f ? n : n.top || 0),
    (a.right -= f ? n : n.right || 0),
    (a.bottom -= f ? n : n.bottom || 0),
    a
  );
}
function ot(e) {
  return e.width * e.height;
}
function st(e, t, n, r, i) {
  var a = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : 0;
  if (e.indexOf(`auto`) === -1) return e;
  var o = at(n, r, a, i),
    s = {
      top: { width: o.width, height: t.top - o.top },
      right: { width: o.right - t.right, height: o.height },
      bottom: { width: o.width, height: o.bottom - t.bottom },
      left: { width: t.left - o.left, height: o.height },
    },
    c = Object.keys(s)
      .map(function (e) {
        return Q({ key: e }, s[e], { area: ot(s[e]) });
      })
      .sort(function (e, t) {
        return t.area - e.area;
      }),
    l = c.filter(function (e) {
      var t = e.width,
        r = e.height;
      return t >= n.clientWidth && r >= n.clientHeight;
    }),
    u = l.length > 0 ? l[0].key : c[0].key,
    d = e.split(`-`)[1];
  return u + (d ? `-` + d : ``);
}
function ct(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : null;
  return tt(n, r ? it(t) : Ge(t, X(n)), r);
}
function lt(e) {
  var t = e.ownerDocument.defaultView.getComputedStyle(e),
    n = parseFloat(t.marginTop || 0) + parseFloat(t.marginBottom || 0),
    r = parseFloat(t.marginLeft || 0) + parseFloat(t.marginRight || 0);
  return { width: e.offsetWidth + r, height: e.offsetHeight + n };
}
function ut(e) {
  var t = { left: `right`, right: `left`, bottom: `top`, top: `bottom` };
  return e.replace(/left|right|bottom|top/g, function (e) {
    return t[e];
  });
}
function dt(e, t, n) {
  n = n.split(`-`)[0];
  var r = lt(e),
    i = { width: r.width, height: r.height },
    a = [`right`, `left`].indexOf(n) !== -1,
    o = a ? `top` : `left`,
    s = a ? `left` : `top`,
    c = a ? `height` : `width`,
    l = a ? `width` : `height`;
  return (
    (i[o] = t[o] + t[c] / 2 - r[c] / 2),
    (i[s] = n === s ? t[s] - r[l] : t[ut(s)]),
    i
  );
}
function ft(e, t) {
  return Array.prototype.find ? e.find(t) : e.filter(t)[0];
}
function pt(e, t, n) {
  if (Array.prototype.findIndex)
    return e.findIndex(function (e) {
      return e[t] === n;
    });
  var r = ft(e, function (e) {
    return e[t] === n;
  });
  return e.indexOf(r);
}
function mt(e, t, n) {
  return (
    (n === void 0 ? e : e.slice(0, pt(e, `name`, n))).forEach(function (e) {
      e.function &&
        console.warn("`modifier.function` is deprecated, use `modifier.fn`!");
      var n = e.function || e.fn;
      e.enabled &&
        Le(n) &&
        ((t.offsets.popper = $(t.offsets.popper)),
        (t.offsets.reference = $(t.offsets.reference)),
        (t = n(t, e)));
    }),
    t
  );
}
function ht() {
  if (!this.state.isDestroyed) {
    var e = {
      instance: this,
      styles: {},
      arrowStyles: {},
      attributes: {},
      flipped: !1,
      offsets: {},
    };
    (e.offsets.reference = ct(
      this.state,
      this.popper,
      this.reference,
      this.options.positionFixed
    )),
      (e.placement = st(
        this.options.placement,
        e.offsets.reference,
        this.popper,
        this.reference,
        this.options.modifiers.flip.boundariesElement,
        this.options.modifiers.flip.padding
      )),
      (e.originalPlacement = e.placement),
      (e.positionFixed = this.options.positionFixed),
      (e.offsets.popper = dt(this.popper, e.offsets.reference, e.placement)),
      (e.offsets.popper.position = this.options.positionFixed
        ? `fixed`
        : `absolute`),
      (e = mt(this.modifiers, e)),
      this.state.isCreated
        ? this.options.onUpdate(e)
        : ((this.state.isCreated = !0), this.options.onCreate(e));
  }
}
function gt(e, t) {
  return e.some(function (e) {
    var n = e.name;
    return e.enabled && n === t;
  });
}
function _t(e) {
  for (
    var t = [!1, `ms`, `Webkit`, `Moz`, `O`],
      n = e.charAt(0).toUpperCase() + e.slice(1),
      r = 0;
    r < t.length;
    r++
  ) {
    var i = t[r],
      a = i ? `` + i + n : e;
    if (document.body.style[a] !== void 0) return a;
  }
  return null;
}
function vt() {
  return (
    (this.state.isDestroyed = !0),
    gt(this.modifiers, `applyStyle`) &&
      (this.popper.removeAttribute(`x-placement`),
      (this.popper.style.position = ``),
      (this.popper.style.top = ``),
      (this.popper.style.left = ``),
      (this.popper.style.right = ``),
      (this.popper.style.bottom = ``),
      (this.popper.style.willChange = ``),
      (this.popper.style[_t(`transform`)] = ``)),
    this.disableEventListeners(),
    this.options.removeOnDestroy &&
      this.popper.parentNode.removeChild(this.popper),
    this
  );
}
function yt(e) {
  var t = e.ownerDocument;
  return t ? t.defaultView : window;
}
function bt(e, t, n, r) {
  var i = e.nodeName === `BODY`,
    a = i ? e.ownerDocument.defaultView : e;
  a.addEventListener(t, n, { passive: !0 }),
    i || bt(ze(a.parentNode), t, n, r),
    r.push(a);
}
function xt(e, t, n, r) {
  (n.updateBound = r),
    yt(e).addEventListener(`resize`, n.updateBound, { passive: !0 });
  var i = ze(e);
  return (
    bt(i, `scroll`, n.updateBound, n.scrollParents),
    (n.scrollElement = i),
    (n.eventsEnabled = !0),
    n
  );
}
function St() {
  this.state.eventsEnabled ||
    (this.state = xt(
      this.reference,
      this.options,
      this.state,
      this.scheduleUpdate
    ));
}
function Ct(e, t) {
  return (
    yt(e).removeEventListener(`resize`, t.updateBound),
    t.scrollParents.forEach(function (e) {
      e.removeEventListener(`scroll`, t.updateBound);
    }),
    (t.updateBound = null),
    (t.scrollParents = []),
    (t.scrollElement = null),
    (t.eventsEnabled = !1),
    t
  );
}
function wt() {
  this.state.eventsEnabled &&
    (cancelAnimationFrame(this.scheduleUpdate),
    (this.state = Ct(this.reference, this.state)));
}
function Tt(e) {
  return e !== `` && !isNaN(parseFloat(e)) && isFinite(e);
}
function Et(e, t) {
  Object.keys(t).forEach(function (n) {
    var r = ``;
    [`width`, `height`, `top`, `right`, `bottom`, `left`].indexOf(n) !== -1 &&
      Tt(t[n]) &&
      (r = `px`),
      (e.style[n] = t[n] + r);
  });
}
function Dt(e, t) {
  Object.keys(t).forEach(function (n) {
    t[n] === !1 ? e.removeAttribute(n) : e.setAttribute(n, t[n]);
  });
}
function Ot(e) {
  return (
    Et(e.instance.popper, e.styles),
    Dt(e.instance.popper, e.attributes),
    e.arrowElement &&
      Object.keys(e.arrowStyles).length &&
      Et(e.arrowElement, e.arrowStyles),
    e
  );
}
function kt(e, t, n, r, i) {
  var a = ct(i, t, e, n.positionFixed),
    o = st(
      n.placement,
      a,
      t,
      e,
      n.modifiers.flip.boundariesElement,
      n.modifiers.flip.padding
    );
  return (
    t.setAttribute(`x-placement`, o),
    Et(t, { position: n.positionFixed ? `fixed` : `absolute` }),
    n
  );
}
function At(e, t) {
  var n = e.offsets,
    r = n.popper,
    i = n.reference,
    a = Math.round,
    o = Math.floor,
    s = function (e) {
      return e;
    },
    c = a(i.width),
    l = a(r.width),
    u = [`left`, `right`].indexOf(e.placement) !== -1,
    d = e.placement.indexOf(`-`) !== -1,
    f = c % 2 == l % 2,
    p = c % 2 == 1 && l % 2 == 1,
    m = t ? (u || d || f ? a : o) : s,
    h = t ? a : s;
  return {
    left: m(p && !d && t ? r.left - 1 : r.left),
    top: h(r.top),
    bottom: h(r.bottom),
    right: m(r.right),
  };
}
var jt = J && /Firefox/i.test(navigator.userAgent);
function Mt(e, t) {
  var n = t.x,
    r = t.y,
    i = e.offsets.popper,
    a = ft(e.instance.modifiers, function (e) {
      return e.name === `applyStyle`;
    }).gpuAcceleration;
  a !== void 0 &&
    console.warn(
      "WARNING: `gpuAcceleration` option moved to `computeStyle` modifier and will not be supported in future versions of Popper.js!"
    );
  var o = a === void 0 ? t.gpuAcceleration : a,
    s = He(e.instance.popper),
    c = et(s),
    l = { position: i.position },
    u = At(e, window.devicePixelRatio < 2 || !jt),
    d = n === `bottom` ? `top` : `bottom`,
    f = r === `right` ? `left` : `right`,
    p = _t(`transform`),
    m = void 0,
    h = void 0;
  if (
    ((h =
      d === `bottom`
        ? s.nodeName === `HTML`
          ? -s.clientHeight + u.bottom
          : -c.height + u.bottom
        : u.top),
    (m =
      f === `right`
        ? s.nodeName === `HTML`
          ? -s.clientWidth + u.right
          : -c.width + u.right
        : u.left),
    o && p)
  )
    (l[p] = `translate3d(` + m + `px, ` + h + `px, 0)`),
      (l[d] = 0),
      (l[f] = 0),
      (l.willChange = `transform`);
  else {
    var g = d === `bottom` ? -1 : 1,
      _ = f === `right` ? -1 : 1;
    (l[d] = h * g), (l[f] = m * _), (l.willChange = d + `, ` + f);
  }
  return (
    (e.attributes = Q({}, { "x-placement": e.placement }, e.attributes)),
    (e.styles = Q({}, l, e.styles)),
    (e.arrowStyles = Q({}, e.offsets.arrow, e.arrowStyles)),
    e
  );
}
function Nt(e, t, n) {
  var r = ft(e, function (e) {
      return e.name === t;
    }),
    i =
      !!r &&
      e.some(function (e) {
        return e.name === n && e.enabled && e.order < r.order;
      });
  if (!i) {
    var a = "`" + t + "`",
      o = "`" + n + "`";
    console.warn(
      o +
        ` modifier is required by ` +
        a +
        ` modifier in order to work, be sure to include it before ` +
        a +
        `!`
    );
  }
  return i;
}
function Pt(e, t) {
  var n;
  if (!Nt(e.instance.modifiers, `arrow`, `keepTogether`)) return e;
  var r = t.element;
  if (typeof r == `string`) {
    if (((r = e.instance.popper.querySelector(r)), !r)) return e;
  } else if (!e.instance.popper.contains(r))
    return (
      console.warn(
        "WARNING: `arrow.element` must be child of its popper element!"
      ),
      e
    );
  var i = e.placement.split(`-`)[0],
    a = e.offsets,
    o = a.popper,
    s = a.reference,
    c = [`left`, `right`].indexOf(i) !== -1,
    l = c ? `height` : `width`,
    u = c ? `Top` : `Left`,
    d = u.toLowerCase(),
    f = c ? `left` : `top`,
    p = c ? `bottom` : `right`,
    m = lt(r)[l];
  s[p] - m < o[d] && (e.offsets.popper[d] -= o[d] - (s[p] - m)),
    s[d] + m > o[p] && (e.offsets.popper[d] += s[d] + m - o[p]),
    (e.offsets.popper = $(e.offsets.popper));
  var h = s[d] + s[l] / 2 - m / 2,
    g = Y(e.instance.popper),
    _ = parseFloat(g[`margin` + u]),
    v = parseFloat(g[`border` + u + `Width`]),
    y = h - e.offsets.popper[d] - _ - v;
  return (
    (y = Math.max(Math.min(o[l] - m, y), 0)),
    (e.arrowElement = r),
    (e.offsets.arrow = ((n = {}), $e(n, d, Math.round(y)), $e(n, f, ``), n)),
    e
  );
}
function Ft(e) {
  return e === `end` ? `start` : e === `start` ? `end` : e;
}
var It = [
    `auto-start`,
    `auto`,
    `auto-end`,
    `top-start`,
    `top`,
    `top-end`,
    `right-start`,
    `right`,
    `right-end`,
    `bottom-end`,
    `bottom`,
    `bottom-start`,
    `left-end`,
    `left`,
    `left-start`,
  ],
  Lt = It.slice(3);
function Rt(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 && arguments[1],
    n = Lt.indexOf(e),
    r = Lt.slice(n + 1).concat(Lt.slice(0, n));
  return t ? r.reverse() : r;
}
var zt = {
  FLIP: `flip`,
  CLOCKWISE: `clockwise`,
  COUNTERCLOCKWISE: `counterclockwise`,
};
function Bt(e, t) {
  if (
    gt(e.instance.modifiers, `inner`) ||
    (e.flipped && e.placement === e.originalPlacement)
  )
    return e;
  var n = at(
      e.instance.popper,
      e.instance.reference,
      t.padding,
      t.boundariesElement,
      e.positionFixed
    ),
    r = e.placement.split(`-`)[0],
    i = ut(r),
    a = e.placement.split(`-`)[1] || ``,
    o = [];
  switch (t.behavior) {
    case zt.FLIP:
      o = [r, i];
      break;
    case zt.CLOCKWISE:
      o = Rt(r);
      break;
    case zt.COUNTERCLOCKWISE:
      o = Rt(r, !0);
      break;
    default:
      o = t.behavior;
  }
  return (
    o.forEach(function (s, c) {
      if (r !== s || o.length === c + 1) return e;
      (r = e.placement.split(`-`)[0]), (i = ut(r));
      var l = e.offsets.popper,
        u = e.offsets.reference,
        d = Math.floor,
        f =
          (r === `left` && d(l.right) > d(u.left)) ||
          (r === `right` && d(l.left) < d(u.right)) ||
          (r === `top` && d(l.bottom) > d(u.top)) ||
          (r === `bottom` && d(l.top) < d(u.bottom)),
        p = d(l.left) < d(n.left),
        m = d(l.right) > d(n.right),
        h = d(l.top) < d(n.top),
        g = d(l.bottom) > d(n.bottom),
        _ =
          (r === `left` && p) ||
          (r === `right` && m) ||
          (r === `top` && h) ||
          (r === `bottom` && g),
        v = [`top`, `bottom`].indexOf(r) !== -1,
        y =
          !!t.flipVariations &&
          ((v && a === `start` && p) ||
            (v && a === `end` && m) ||
            (!v && a === `start` && h) ||
            (!v && a === `end` && g)),
        b =
          !!t.flipVariationsByContent &&
          ((v && a === `start` && m) ||
            (v && a === `end` && p) ||
            (!v && a === `start` && g) ||
            (!v && a === `end` && h)),
        x = y || b;
      (f || _ || x) &&
        ((e.flipped = !0),
        (f || _) && (r = o[c + 1]),
        x && (a = Ft(a)),
        (e.placement = r + (a ? `-` + a : ``)),
        (e.offsets.popper = Q(
          {},
          e.offsets.popper,
          dt(e.instance.popper, e.offsets.reference, e.placement)
        )),
        (e = mt(e.instance.modifiers, e, `flip`)));
    }),
    e
  );
}
function Vt(e) {
  var t = e.offsets,
    n = t.popper,
    r = t.reference,
    i = e.placement.split(`-`)[0],
    a = Math.floor,
    o = [`top`, `bottom`].indexOf(i) !== -1,
    s = o ? `right` : `bottom`,
    c = o ? `left` : `top`,
    l = o ? `width` : `height`;
  return (
    n[s] < a(r[c]) && (e.offsets.popper[c] = a(r[c]) - n[l]),
    n[c] > a(r[s]) && (e.offsets.popper[c] = a(r[s])),
    e
  );
}
function Ht(e, t, n, r) {
  var i = e.match(/((?:\-|\+)?\d*\.?\d*)(.*)/),
    a = +i[1],
    o = i[2];
  if (!a) return e;
  if (o.indexOf(`%`) === 0) {
    var s = void 0;
    switch (o) {
      case `%p`:
        s = n;
        break;
      default:
        s = r;
    }
    return ($(s)[t] / 100) * a;
  }
  if (o === `vh` || o === `vw`) {
    var c = void 0;
    return (
      (c =
        o === `vh`
          ? Math.max(
              document.documentElement.clientHeight,
              window.innerHeight || 0
            )
          : Math.max(
              document.documentElement.clientWidth,
              window.innerWidth || 0
            )),
      (c / 100) * a
    );
  }
  return a;
}
function Ut(e, t, n, r) {
  var i = [0, 0],
    a = [`right`, `left`].indexOf(r) !== -1,
    o = e.split(/(\+|\-)/).map(function (e) {
      return e.trim();
    }),
    s = o.indexOf(
      ft(o, function (e) {
        return e.search(/,|\s/) !== -1;
      })
    );
  o[s] &&
    o[s].indexOf(`,`) === -1 &&
    console.warn(
      `Offsets separated by white space(s) are deprecated, use a comma (,) instead.`
    );
  var c = /\s*,\s*|\s+/,
    l =
      s === -1
        ? [o]
        : [
            o.slice(0, s).concat([o[s].split(c)[0]]),
            [o[s].split(c)[1]].concat(o.slice(s + 1)),
          ];
  return (
    (l = l.map(function (e, r) {
      var i = (r === 1 ? !a : a) ? `height` : `width`,
        o = !1;
      return e
        .reduce(function (e, t) {
          return e[e.length - 1] === `` && [`+`, `-`].indexOf(t) !== -1
            ? ((e[e.length - 1] = t), (o = !0), e)
            : o
            ? ((e[e.length - 1] += t), (o = !1), e)
            : e.concat(t);
        }, [])
        .map(function (e) {
          return Ht(e, i, t, n);
        });
    })),
    l.forEach(function (e, t) {
      e.forEach(function (n, r) {
        Tt(n) && (i[t] += n * (e[r - 1] === `-` ? -1 : 1));
      });
    }),
    i
  );
}
function Wt(e, t) {
  var n = t.offset,
    r = e.placement,
    i = e.offsets,
    a = i.popper,
    o = i.reference,
    s = r.split(`-`)[0],
    c = void 0;
  return (
    (c = Tt(+n) ? [+n, 0] : Ut(n, a, o, s)),
    s === `left`
      ? ((a.top += c[0]), (a.left -= c[1]))
      : s === `right`
      ? ((a.top += c[0]), (a.left += c[1]))
      : s === `top`
      ? ((a.left += c[0]), (a.top -= c[1]))
      : s === `bottom` && ((a.left += c[0]), (a.top += c[1])),
    (e.popper = a),
    e
  );
}
function Gt(e, t) {
  var n = t.boundariesElement || He(e.instance.popper);
  e.instance.reference === n && (n = He(n));
  var r = _t(`transform`),
    i = e.instance.popper.style,
    a = i.top,
    o = i.left,
    s = i[r];
  (i.top = ``), (i.left = ``), (i[r] = ``);
  var c = at(
    e.instance.popper,
    e.instance.reference,
    t.padding,
    n,
    e.positionFixed
  );
  (i.top = a), (i.left = o), (i[r] = s), (t.boundaries = c);
  var l = t.priority,
    u = e.offsets.popper,
    d = {
      primary: function (e) {
        var n = u[e];
        return (
          u[e] < c[e] && !t.escapeWithReference && (n = Math.max(u[e], c[e])),
          $e({}, e, n)
        );
      },
      secondary: function (e) {
        var n = e === `right` ? `left` : `top`,
          r = u[n];
        return (
          u[e] > c[e] &&
            !t.escapeWithReference &&
            (r = Math.min(u[n], c[e] - (e === `right` ? u.width : u.height))),
          $e({}, n, r)
        );
      },
    };
  return (
    l.forEach(function (e) {
      var t = [`left`, `top`].indexOf(e) === -1 ? `secondary` : `primary`;
      u = Q({}, u, d[t](e));
    }),
    (e.offsets.popper = u),
    e
  );
}
function Kt(e) {
  var t = e.placement,
    n = t.split(`-`)[0],
    r = t.split(`-`)[1];
  if (r) {
    var i = e.offsets,
      a = i.reference,
      o = i.popper,
      s = [`bottom`, `top`].indexOf(n) !== -1,
      c = s ? `left` : `top`,
      l = s ? `width` : `height`,
      u = { start: $e({}, c, a[c]), end: $e({}, c, a[c] + a[l] - o[l]) };
    e.offsets.popper = Q({}, o, u[r]);
  }
  return e;
}
function qt(e) {
  if (!Nt(e.instance.modifiers, `hide`, `preventOverflow`)) return e;
  var t = e.offsets.reference,
    n = ft(e.instance.modifiers, function (e) {
      return e.name === `preventOverflow`;
    }).boundaries;
  if (
    t.bottom < n.top ||
    t.left > n.right ||
    t.top > n.bottom ||
    t.right < n.left
  ) {
    if (e.hide === !0) return e;
    (e.hide = !0), (e.attributes[`x-out-of-boundaries`] = ``);
  } else {
    if (e.hide === !1) return e;
    (e.hide = !1), (e.attributes[`x-out-of-boundaries`] = !1);
  }
  return e;
}
function Jt(e) {
  var t = e.placement,
    n = t.split(`-`)[0],
    r = e.offsets,
    i = r.popper,
    a = r.reference,
    o = [`left`, `right`].indexOf(n) !== -1,
    s = [`top`, `left`].indexOf(n) === -1;
  return (
    (i[o ? `left` : `top`] = a[n] - (s ? i[o ? `width` : `height`] : 0)),
    (e.placement = ut(t)),
    (e.offsets.popper = $(i)),
    e
  );
}
var Yt = {
    placement: `bottom`,
    positionFixed: !1,
    eventsEnabled: !0,
    removeOnDestroy: !1,
    onCreate: function () {},
    onUpdate: function () {},
    modifiers: {
      shift: { order: 100, enabled: !0, fn: Kt },
      offset: { order: 200, enabled: !0, fn: Wt, offset: 0 },
      preventOverflow: {
        order: 300,
        enabled: !0,
        fn: Gt,
        priority: [`left`, `right`, `top`, `bottom`],
        padding: 5,
        boundariesElement: `scrollParent`,
      },
      keepTogether: { order: 400, enabled: !0, fn: Vt },
      arrow: { order: 500, enabled: !0, fn: Pt, element: `[x-arrow]` },
      flip: {
        order: 600,
        enabled: !0,
        fn: Bt,
        behavior: `flip`,
        padding: 5,
        boundariesElement: `viewport`,
        flipVariations: !1,
        flipVariationsByContent: !1,
      },
      inner: { order: 700, enabled: !1, fn: Jt },
      hide: { order: 800, enabled: !0, fn: qt },
      computeStyle: {
        order: 850,
        enabled: !0,
        fn: Mt,
        gpuAcceleration: !0,
        x: `bottom`,
        y: `right`,
      },
      applyStyle: {
        order: 900,
        enabled: !0,
        fn: Ot,
        onLoad: kt,
        gpuAcceleration: void 0,
      },
    },
  },
  Xt = (function () {
    function e(t, n) {
      var r = this,
        i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      Ze(this, e),
        (this.scheduleUpdate = function () {
          return requestAnimationFrame(r.update);
        }),
        (this.update = Ie(this.update.bind(this))),
        (this.options = Q({}, e.Defaults, i)),
        (this.state = { isDestroyed: !1, isCreated: !1, scrollParents: [] }),
        (this.reference = t && t.jquery ? t[0] : t),
        (this.popper = n && n.jquery ? n[0] : n),
        (this.options.modifiers = {}),
        Object.keys(Q({}, e.Defaults.modifiers, i.modifiers)).forEach(function (
          t
        ) {
          r.options.modifiers[t] = Q(
            {},
            e.Defaults.modifiers[t] || {},
            i.modifiers ? i.modifiers[t] : {}
          );
        }),
        (this.modifiers = Object.keys(this.options.modifiers)
          .map(function (e) {
            return Q({ name: e }, r.options.modifiers[e]);
          })
          .sort(function (e, t) {
            return e.order - t.order;
          })),
        this.modifiers.forEach(function (e) {
          e.enabled &&
            Le(e.onLoad) &&
            e.onLoad(r.reference, r.popper, r.options, e, r.state);
        }),
        this.update();
      var a = this.options.eventsEnabled;
      a && this.enableEventListeners(), (this.state.eventsEnabled = a);
    }
    return (
      Qe(e, [
        {
          key: `update`,
          value: function () {
            return ht.call(this);
          },
        },
        {
          key: `destroy`,
          value: function () {
            return vt.call(this);
          },
        },
        {
          key: `enableEventListeners`,
          value: function () {
            return St.call(this);
          },
        },
        {
          key: `disableEventListeners`,
          value: function () {
            return wt.call(this);
          },
        },
      ]),
      e
    );
  })();
(Xt.Utils = (typeof window < `u` ? window : r).PopperUtils),
  (Xt.placements = It),
  (Xt.Defaults = Yt),
  a(),
  f(),
  w(),
  M(),
  P(),
  L();
function Zt(e, t) {
  if (((t && t.direction) || `ltr`) === `ltr`) return e;
  switch (e) {
    case `bottom-end`:
      return `bottom-start`;
    case `bottom-start`:
      return `bottom-end`;
    case `top-end`:
      return `top-start`;
    case `top-start`:
      return `top-end`;
    default:
      return e;
  }
}
function Qt(e) {
  return typeof e == `function` ? e() : e;
}
var $t = typeof window < `u` ? j.useLayoutEffect : j.useEffect,
  en = {},
  tn = j.forwardRef(function (e, t) {
    var n = e.anchorEl,
      r = e.children,
      i = e.container,
      a = e.disablePortal,
      o = a !== void 0 && a,
      c = e.keepMounted,
      l = c !== void 0 && c,
      u = e.modifiers,
      d = e.open,
      f = e.placement,
      p = f === void 0 ? `bottom` : f,
      h = e.popperOptions,
      g = h === void 0 ? en : h,
      _ = e.popperRef,
      v = e.style,
      y = e.transition,
      b = y !== void 0 && y,
      x = m(e, [
        `anchorEl`,
        `children`,
        `container`,
        `disablePortal`,
        `keepMounted`,
        `modifiers`,
        `open`,
        `placement`,
        `popperOptions`,
        `popperRef`,
        `style`,
        `transition`,
      ]),
      S = j.useRef(null),
      C = I(S, t),
      w = j.useRef(null),
      E = I(w, _),
      D = j.useRef(E);
    $t(
      function () {
        D.current = E;
      },
      [E]
    ),
      j.useImperativeHandle(
        _,
        function () {
          return w.current;
        },
        []
      );
    var O = j.useState(!0),
      ee = O[0],
      k = O[1],
      A = Zt(p, T()),
      te = j.useState(A),
      ne = te[0],
      M = te[1];
    j.useEffect(function () {
      w.current && w.current.update();
    });
    var P = j.useCallback(
        function () {
          if (S.current && n && d) {
            w.current && (w.current.destroy(), D.current(null));
            var e = function (e) {
              M(e.placement);
            };
            Qt(n);
            var t = new Xt(
              Qt(n),
              S.current,
              s({ placement: A }, g, {
                modifiers: s(
                  {},
                  o ? {} : { preventOverflow: { boundariesElement: `window` } },
                  u,
                  g.modifiers
                ),
                onCreate: re(e, g.onCreate),
                onUpdate: re(e, g.onUpdate),
              })
            );
            D.current(t);
          }
        },
        [n, o, u, d, A, g]
      ),
      ie = j.useCallback(
        function (e) {
          N(C, e), P();
        },
        [C, P]
      ),
      F = function () {
        k(!1);
      },
      ae = function () {
        w.current && (w.current.destroy(), D.current(null));
      },
      oe = function () {
        k(!0), ae();
      };
    if (
      (j.useEffect(function () {
        return function () {
          ae();
        };
      }, []),
      j.useEffect(
        function () {
          !d && !b && ae();
        },
        [d, b]
      ),
      !l && !d && (!b || ee))
    )
      return null;
    var L = { placement: ne };
    return (
      b && (L.TransitionProps = { in: d, onEnter: F, onExited: oe }),
      j.createElement(
        ke,
        { disablePortal: o, container: i },
        j.createElement(
          `div`,
          s({ ref: ie, role: `tooltip` }, x, {
            style: s(
              {
                position: `fixed`,
                top: 0,
                left: 0,
                display: !d && l && !b ? `none` : null,
              },
              v
            ),
          }),
          typeof r == `function` ? r(L) : r
        )
      )
    );
  });
a(), h(), f(), l(), E(), O(), y(), x(), C(), L(), le(), P(), H(), ae();
function nn(e) {
  return Math.round(e * 1e5) / 1e5;
}
function rn() {
  return {
    '&[x-placement*="bottom"] $arrow': {
      top: 0,
      left: 0,
      marginTop: `-0.71em`,
      marginLeft: 4,
      marginRight: 4,
      "&::before": { transformOrigin: `0 100%` },
    },
    '&[x-placement*="top"] $arrow': {
      bottom: 0,
      left: 0,
      marginBottom: `-0.71em`,
      marginLeft: 4,
      marginRight: 4,
      "&::before": { transformOrigin: `100% 0` },
    },
    '&[x-placement*="right"] $arrow': {
      left: 0,
      marginLeft: `-0.71em`,
      height: `1em`,
      width: `0.71em`,
      marginTop: 4,
      marginBottom: 4,
      "&::before": { transformOrigin: `100% 100%` },
    },
    '&[x-placement*="left"] $arrow': {
      right: 0,
      marginRight: `-0.71em`,
      height: `1em`,
      width: `0.71em`,
      marginTop: 4,
      marginBottom: 4,
      "&::before": { transformOrigin: `0 0` },
    },
  };
}
var an = function (e) {
    return {
      popper: { zIndex: e.zIndex.tooltip, pointerEvents: `none` },
      popperInteractive: { pointerEvents: `auto` },
      popperArrow: rn(),
      tooltip: {
        backgroundColor: b(e.palette.grey[700], 0.9),
        borderRadius: e.shape.borderRadius,
        color: e.palette.common.white,
        fontFamily: e.typography.fontFamily,
        padding: `4px 8px`,
        fontSize: e.typography.pxToRem(10),
        lineHeight: `${nn(14 / 10)}em`,
        maxWidth: 300,
        wordWrap: `break-word`,
        fontWeight: e.typography.fontWeightMedium,
      },
      tooltipArrow: { position: `relative`, margin: `0` },
      arrow: {
        overflow: `hidden`,
        position: `absolute`,
        width: `1em`,
        height: `0.71em`,
        boxSizing: `border-box`,
        color: b(e.palette.grey[700], 0.9),
        "&::before": {
          content: `""`,
          margin: `auto`,
          display: `block`,
          width: `100%`,
          height: `100%`,
          backgroundColor: `currentColor`,
          transform: `rotate(45deg)`,
        },
      },
      touch: {
        padding: `8px 16px`,
        fontSize: e.typography.pxToRem(14),
        lineHeight: `${nn(16 / 14)}em`,
        fontWeight: e.typography.fontWeightRegular,
      },
      tooltipPlacementLeft: c(
        { transformOrigin: `right center`, margin: `0 24px ` },
        e.breakpoints.up(`sm`),
        { margin: `0 14px` }
      ),
      tooltipPlacementRight: c(
        { transformOrigin: `left center`, margin: `0 24px` },
        e.breakpoints.up(`sm`),
        { margin: `0 14px` }
      ),
      tooltipPlacementTop: c(
        { transformOrigin: `center bottom`, margin: `24px 0` },
        e.breakpoints.up(`sm`),
        { margin: `14px 0` }
      ),
      tooltipPlacementBottom: c(
        { transformOrigin: `center top`, margin: `24px 0` },
        e.breakpoints.up(`sm`),
        { margin: `14px 0` }
      ),
    };
  },
  on = !1,
  sn = null,
  cn = j.forwardRef(function (e, t) {
    var n = e.arrow,
      r = n !== void 0 && n,
      i = e.children,
      a = e.classes,
      o = e.disableFocusListener,
      c = o !== void 0 && o,
      l = e.disableHoverListener,
      u = l !== void 0 && l,
      f = e.disableTouchListener,
      p = f !== void 0 && f,
      h = e.enterDelay,
      g = h === void 0 ? 100 : h,
      _ = e.enterNextDelay,
      y = _ === void 0 ? 0 : _,
      b = e.enterTouchDelay,
      x = b === void 0 ? 700 : b,
      S = e.id,
      C = e.interactive,
      w = C !== void 0 && C,
      T = e.leaveDelay,
      E = T === void 0 ? 0 : T,
      D = e.leaveTouchDelay,
      O = D === void 0 ? 1500 : D,
      k = e.onClose,
      te = e.onOpen,
      re = e.open,
      M = e.placement,
      P = M === void 0 ? `bottom` : M,
      F = e.PopperComponent,
      ae = F === void 0 ? tn : F,
      oe = e.PopperProps,
      L = e.title,
      ce = e.TransitionComponent,
      le = ce === void 0 ? Me : ce,
      ue = e.TransitionProps,
      de = m(e, [
        `arrow`,
        `children`,
        `classes`,
        `disableFocusListener`,
        `disableHoverListener`,
        `disableTouchListener`,
        `enterDelay`,
        `enterNextDelay`,
        `enterTouchDelay`,
        `id`,
        `interactive`,
        `leaveDelay`,
        `leaveTouchDelay`,
        `onClose`,
        `onOpen`,
        `open`,
        `placement`,
        `PopperComponent`,
        `PopperProps`,
        `title`,
        `TransitionComponent`,
        `TransitionProps`,
      ]),
      fe = ne(),
      pe = j.useState(),
      R = pe[0],
      me = pe[1],
      he = j.useState(null),
      _e = he[0],
      z = he[1],
      B = j.useRef(!1),
      V = j.useRef(),
      ve = j.useRef(),
      H = j.useRef(),
      ye = j.useRef(),
      be = ie({ controlled: re, default: !1, name: `Tooltip`, state: `open` }),
      xe = d(be, 2),
      Se = xe[0],
      W = xe[1],
      G = Se,
      Ce = se(S);
    j.useEffect(function () {
      return function () {
        clearTimeout(V.current),
          clearTimeout(ve.current),
          clearTimeout(H.current),
          clearTimeout(ye.current);
      };
    }, []);
    var we = function (e) {
        clearTimeout(sn), (on = !0), W(!0), te && te(e);
      },
      K = function () {
        var e =
          arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
        return function (t) {
          var n = i.props;
          t.type === `mouseover` && n.onMouseOver && e && n.onMouseOver(t),
            !(B.current && t.type !== `touchstart`) &&
              (R && R.removeAttribute(`title`),
              clearTimeout(ve.current),
              clearTimeout(H.current),
              g || (on && y)
                ? (t.persist(),
                  (ve.current = setTimeout(
                    function () {
                      we(t);
                    },
                    on ? y : g
                  )))
                : we(t));
        };
      },
      q = ge(),
      Te = q.isFocusVisible,
      Ee = q.onBlurVisible,
      De = q.ref,
      Oe = j.useState(!1),
      ke = Oe[0],
      Ae = Oe[1],
      je = function () {
        ke && (Ae(!1), Ee());
      },
      J = function () {
        var e =
          arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
        return function (t) {
          R || me(t.currentTarget), Te(t) && (Ae(!0), K()(t));
          var n = i.props;
          n.onFocus && e && n.onFocus(t);
        };
      },
      Ne = function (e) {
        clearTimeout(sn),
          (sn = setTimeout(function () {
            on = !1;
          }, 800 + E)),
          W(!1),
          k && k(e),
          clearTimeout(V.current),
          (V.current = setTimeout(function () {
            B.current = !1;
          }, fe.transitions.duration.shortest));
      },
      Pe = function () {
        var e =
          arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
        return function (t) {
          var n = i.props;
          t.type === `blur` && (n.onBlur && e && n.onBlur(t), je()),
            t.type === `mouseleave` &&
              n.onMouseLeave &&
              t.currentTarget === R &&
              n.onMouseLeave(t),
            clearTimeout(ve.current),
            clearTimeout(H.current),
            t.persist(),
            (H.current = setTimeout(function () {
              Ne(t);
            }, E));
        };
      },
      Fe = function (e) {
        B.current = !0;
        var t = i.props;
        t.onTouchStart && t.onTouchStart(e);
      },
      Ie = function (e) {
        Fe(e),
          clearTimeout(H.current),
          clearTimeout(V.current),
          clearTimeout(ye.current),
          e.persist(),
          (ye.current = setTimeout(function () {
            K()(e);
          }, x));
      },
      Le = function (e) {
        i.props.onTouchEnd && i.props.onTouchEnd(e),
          clearTimeout(ye.current),
          clearTimeout(H.current),
          e.persist(),
          (H.current = setTimeout(function () {
            Ne(e);
          }, O));
      },
      Y = I(De, I(me, t)),
      Re = j.useCallback(
        function (e) {
          N(Y, U.findDOMNode(e));
        },
        [Y]
      ),
      ze = I(i.ref, Re);
    L === `` && (G = !1);
    var X = s(
        {
          "aria-describedby": G ? Ce : null,
          title: !G && !u && typeof L == `string` ? L : null,
        },
        de,
        i.props,
        {
          className: A(de.className, i.props.className),
          onTouchStart: Fe,
          ref: ze,
        }
      ),
      Z = {};
    p || ((X.onTouchStart = Ie), (X.onTouchEnd = Le)),
      u ||
        ((X.onMouseOver = K()),
        (X.onMouseLeave = Pe()),
        w && ((Z.onMouseOver = K(!1)), (Z.onMouseLeave = Pe(!1)))),
      c ||
        ((X.onFocus = J()),
        (X.onBlur = Pe()),
        w && ((Z.onFocus = J(!1)), (Z.onBlur = Pe(!1))));
    var Be = j.useMemo(
      function () {
        return v(
          {
            popperOptions: {
              modifiers: { arrow: { enabled: !!_e, element: _e } },
            },
          },
          oe
        );
      },
      [_e, oe]
    );
    return j.createElement(
      j.Fragment,
      null,
      j.cloneElement(i, X),
      j.createElement(
        ae,
        s(
          {
            className: A(
              a.popper,
              w && a.popperInteractive,
              r && a.popperArrow
            ),
            placement: P,
            anchorEl: R,
            open: R ? G : !1,
            id: X[`aria-describedby`],
            transition: !0,
          },
          Z,
          Be
        ),
        function (e) {
          var t = e.placement,
            n = e.TransitionProps;
          return j.createElement(
            le,
            s({ timeout: fe.transitions.duration.shorter }, n, ue),
            j.createElement(
              `div`,
              {
                className: A(
                  a.tooltip,
                  a[`tooltipPlacement${ee(t.split(`-`)[0])}`],
                  B.current && a.touch,
                  r && a.tooltipArrow
                ),
              },
              L,
              r ? j.createElement(`span`, { className: a.arrow, ref: z }) : null
            )
          );
        }
      )
    );
  }),
  ln = D(an, { name: `MuiTooltip`, flip: !1 })(cn);
export {
  re as _,
  K as a,
  ge as c,
  L as d,
  I as f,
  N as g,
  P as h,
  Te as i,
  le as l,
  ie as m,
  ke as n,
  be as o,
  ae as p,
  Ee as r,
  H as s,
  ln as t,
  se as u,
  M as v,
  ne as y,
};
