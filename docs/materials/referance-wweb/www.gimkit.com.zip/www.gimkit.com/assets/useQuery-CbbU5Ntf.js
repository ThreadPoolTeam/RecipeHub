import { o as e, t } from "./rolldown-runtime-C0FnF6B9.js";
import { t as n } from "./react-IpA8Qn9U.js";
import {
  C as r,
  S as i,
  _ as a,
  c as o,
  i as s,
  m as c,
  n as l,
  o as u,
  p as d,
  r as f,
  w as p,
  x as m,
  y as h,
} from "./QueryClientProvider-Cv8zTiWk.js";
var g = class extends p {
  constructor(e, t) {
    super(),
      (this.client = e),
      (this.options = t),
      (this.trackedProps = new Set()),
      (this.selectError = null),
      this.bindMethods(),
      this.setOptions(t);
  }
  bindMethods() {
    (this.remove = this.remove.bind(this)),
      (this.refetch = this.refetch.bind(this));
  }
  onSubscribe() {
    this.listeners.size === 1 &&
      (this.currentQuery.addObserver(this),
      v(this.currentQuery, this.options) && this.executeFetch(),
      this.updateTimers());
  }
  onUnsubscribe() {
    this.hasListeners() || this.destroy();
  }
  shouldFetchOnReconnect() {
    return y(this.currentQuery, this.options, this.options.refetchOnReconnect);
  }
  shouldFetchOnWindowFocus() {
    return y(
      this.currentQuery,
      this.options,
      this.options.refetchOnWindowFocus
    );
  }
  destroy() {
    (this.listeners = new Set()),
      this.clearStaleTimeout(),
      this.clearRefetchInterval(),
      this.currentQuery.removeObserver(this);
  }
  setOptions(e, t) {
    let n = this.options,
      r = this.currentQuery;
    if (
      ((this.options = this.client.defaultQueryOptions(e)),
      i(n, this.options) ||
        this.client
          .getQueryCache()
          .notify({
            type: `observerOptionsUpdated`,
            query: this.currentQuery,
            observer: this,
          }),
      this.options.enabled !== void 0 &&
        typeof this.options.enabled != `boolean`)
    )
      throw Error(`Expected enabled to be a boolean`);
    this.options.queryKey || (this.options.queryKey = n.queryKey),
      this.updateQuery();
    let a = this.hasListeners();
    a && b(this.currentQuery, r, this.options, n) && this.executeFetch(),
      this.updateResult(t),
      a &&
        (this.currentQuery !== r ||
          this.options.enabled !== n.enabled ||
          this.options.staleTime !== n.staleTime) &&
        this.updateStaleTimeout();
    let o = this.computeRefetchInterval();
    a &&
      (this.currentQuery !== r ||
        this.options.enabled !== n.enabled ||
        o !== this.currentRefetchInterval) &&
      this.updateRefetchInterval(o);
  }
  getOptimisticResult(e) {
    let t = this.client.getQueryCache().build(this.client, e),
      n = this.createResult(t, e);
    return (
      S(this, n, e) &&
        ((this.currentResult = n),
        (this.currentResultOptions = this.options),
        (this.currentResultState = this.currentQuery.state)),
      n
    );
  }
  getCurrentResult() {
    return this.currentResult;
  }
  trackResult(e) {
    let t = {};
    return (
      Object.keys(e).forEach((n) => {
        Object.defineProperty(t, n, {
          configurable: !1,
          enumerable: !0,
          get: () => (this.trackedProps.add(n), e[n]),
        });
      }),
      t
    );
  }
  getCurrentQuery() {
    return this.currentQuery;
  }
  remove() {
    this.client.getQueryCache().remove(this.currentQuery);
  }
  refetch({ refetchPage: e, ...t } = {}) {
    return this.fetch({ ...t, meta: { refetchPage: e } });
  }
  fetchOptimistic(e) {
    let t = this.client.defaultQueryOptions(e),
      n = this.client.getQueryCache().build(this.client, t);
    return (
      (n.isFetchingOptimistic = !0),
      n.fetch().then(() => this.createResult(n, t))
    );
  }
  fetch(e) {
    return this.executeFetch({
      ...e,
      cancelRefetch: e.cancelRefetch ?? !0,
    }).then(() => (this.updateResult(), this.currentResult));
  }
  executeFetch(e) {
    this.updateQuery();
    let t = this.currentQuery.fetch(this.options, e);
    return (e != null && e.throwOnError) || (t = t.catch(a)), t;
  }
  updateStaleTimeout() {
    if (
      (this.clearStaleTimeout(),
      d || this.currentResult.isStale || !c(this.options.staleTime))
    )
      return;
    let e = r(this.currentResult.dataUpdatedAt, this.options.staleTime) + 1;
    this.staleTimeoutId = setTimeout(() => {
      this.currentResult.isStale || this.updateResult();
    }, e);
  }
  computeRefetchInterval() {
    return typeof this.options.refetchInterval == `function`
      ? this.options.refetchInterval(this.currentResult.data, this.currentQuery)
      : this.options.refetchInterval ?? !1;
  }
  updateRefetchInterval(e) {
    this.clearRefetchInterval(),
      (this.currentRefetchInterval = e),
      !d &&
        this.options.enabled !== !1 &&
        c(this.currentRefetchInterval) &&
        this.currentRefetchInterval !== 0 &&
        (this.refetchIntervalId = setInterval(() => {
          (this.options.refetchIntervalInBackground || o.isFocused()) &&
            this.executeFetch();
        }, this.currentRefetchInterval));
  }
  updateTimers() {
    this.updateStaleTimeout(),
      this.updateRefetchInterval(this.computeRefetchInterval());
  }
  clearStaleTimeout() {
    this.staleTimeoutId &&
      (clearTimeout(this.staleTimeoutId), (this.staleTimeoutId = void 0));
  }
  clearRefetchInterval() {
    this.refetchIntervalId &&
      (clearInterval(this.refetchIntervalId),
      (this.refetchIntervalId = void 0));
  }
  createResult(e, t) {
    let n = this.currentQuery,
      r = this.options,
      i = this.currentResult,
      a = this.currentResultState,
      o = this.currentResultOptions,
      c = e !== n,
      l = c ? e.state : this.currentQueryInitialState,
      u = c ? this.currentResult : this.previousQueryResult,
      { state: d } = e,
      {
        dataUpdatedAt: f,
        error: p,
        errorUpdatedAt: h,
        fetchStatus: g,
        status: _,
      } = d,
      y = !1,
      S = !1,
      C;
    if (t._optimisticResults) {
      let i = this.hasListeners(),
        a = !i && v(e, t),
        o = i && b(e, n, t, r);
      (a || o) &&
        ((g = s(e.options.networkMode) ? `fetching` : `paused`),
        f || (_ = `loading`)),
        t._optimisticResults === `isRestoring` && (g = `idle`);
    }
    if (
      t.keepPreviousData &&
      !d.dataUpdatedAt &&
      u != null &&
      u.isSuccess &&
      _ !== `error`
    )
      (C = u.data), (f = u.dataUpdatedAt), (_ = u.status), (y = !0);
    else if (t.select && d.data !== void 0) {
      if (
        i &&
        d.data === (a == null ? void 0 : a.data) &&
        t.select === this.selectFn
      )
        C = this.selectResult;
      else
        try {
          (this.selectFn = t.select),
            (C = t.select(d.data)),
            (C = m(i == null ? void 0 : i.data, C, t)),
            (this.selectResult = C),
            (this.selectError = null);
        } catch (e) {
          this.selectError = e;
        }
    } else C = d.data;
    if (t.placeholderData !== void 0 && C === void 0 && _ === `loading`) {
      let e;
      if (
        i != null &&
        i.isPlaceholderData &&
        t.placeholderData === (o == null ? void 0 : o.placeholderData)
      )
        e = i.data;
      else if (
        ((e =
          typeof t.placeholderData == `function`
            ? t.placeholderData()
            : t.placeholderData),
        t.select && e !== void 0)
      )
        try {
          (e = t.select(e)), (this.selectError = null);
        } catch (e) {
          this.selectError = e;
        }
      e !== void 0 &&
        ((_ = `success`), (C = m(i == null ? void 0 : i.data, e, t)), (S = !0));
    }
    this.selectError &&
      ((p = this.selectError),
      (C = this.selectResult),
      (h = Date.now()),
      (_ = `error`));
    let w = g === `fetching`,
      T = _ === `loading`,
      E = _ === `error`;
    return {
      status: _,
      fetchStatus: g,
      isLoading: T,
      isSuccess: _ === `success`,
      isError: E,
      isInitialLoading: T && w,
      data: C,
      dataUpdatedAt: f,
      error: p,
      errorUpdatedAt: h,
      failureCount: d.fetchFailureCount,
      failureReason: d.fetchFailureReason,
      errorUpdateCount: d.errorUpdateCount,
      isFetched: d.dataUpdateCount > 0 || d.errorUpdateCount > 0,
      isFetchedAfterMount:
        d.dataUpdateCount > l.dataUpdateCount ||
        d.errorUpdateCount > l.errorUpdateCount,
      isFetching: w,
      isRefetching: w && !T,
      isLoadingError: E && d.dataUpdatedAt === 0,
      isPaused: g === `paused`,
      isPlaceholderData: S,
      isPreviousData: y,
      isRefetchError: E && d.dataUpdatedAt !== 0,
      isStale: x(e, t),
      refetch: this.refetch,
      remove: this.remove,
    };
  }
  updateResult(e) {
    let t = this.currentResult,
      n = this.createResult(this.currentQuery, this.options);
    if (
      ((this.currentResultState = this.currentQuery.state),
      (this.currentResultOptions = this.options),
      i(n, t))
    )
      return;
    this.currentResult = n;
    let r = { cache: !0 };
    (e == null ? void 0 : e.listeners) !== !1 &&
      (() => {
        if (!t) return !0;
        let { notifyOnChangeProps: e } = this.options,
          n = typeof e == `function` ? e() : e;
        if (n === `all` || (!n && !this.trackedProps.size)) return !0;
        let r = new Set(n ?? this.trackedProps);
        return (
          this.options.useErrorBoundary && r.add(`error`),
          Object.keys(this.currentResult).some((e) => {
            let n = e;
            return this.currentResult[n] !== t[n] && r.has(n);
          })
        );
      })() &&
      (r.listeners = !0),
      this.notify({ ...r, ...e });
  }
  updateQuery() {
    let e = this.client.getQueryCache().build(this.client, this.options);
    if (e === this.currentQuery) return;
    let t = this.currentQuery;
    (this.currentQuery = e),
      (this.currentQueryInitialState = e.state),
      (this.previousQueryResult = this.currentResult),
      this.hasListeners() &&
        (t == null || t.removeObserver(this), e.addObserver(this));
  }
  onQueryUpdate(e) {
    let t = {};
    e.type === `success`
      ? (t.onSuccess = !e.manual)
      : e.type === `error` && !u(e.error) && (t.onError = !0),
      this.updateResult(t),
      this.hasListeners() && this.updateTimers();
  }
  notify(e) {
    f.batch(() => {
      if (e.onSuccess) {
        var t, n, r, i;
        (t = (n = this.options).onSuccess) == null ||
          t.call(n, this.currentResult.data),
          (r = (i = this.options).onSettled) == null ||
            r.call(i, this.currentResult.data, null);
      } else if (e.onError) {
        var a, o, s, c;
        (a = (o = this.options).onError) == null ||
          a.call(o, this.currentResult.error),
          (s = (c = this.options).onSettled) == null ||
            s.call(c, void 0, this.currentResult.error);
      }
      e.listeners &&
        this.listeners.forEach(({ listener: e }) => {
          e(this.currentResult);
        }),
        e.cache &&
          this.client
            .getQueryCache()
            .notify({
              query: this.currentQuery,
              type: `observerResultsUpdated`,
            });
    });
  }
};
function _(e, t) {
  return (
    t.enabled !== !1 &&
    !e.state.dataUpdatedAt &&
    (e.state.status !== `error` || t.retryOnMount !== !1)
  );
}
function v(e, t) {
  return _(e, t) || (e.state.dataUpdatedAt > 0 && y(e, t, t.refetchOnMount));
}
function y(e, t, n) {
  if (t.enabled !== !1) {
    let r = typeof n == `function` ? n(e) : n;
    return r === `always` || (r !== !1 && x(e, t));
  }
  return !1;
}
function b(e, t, n, r) {
  return (
    n.enabled !== !1 &&
    (e !== t || r.enabled === !1) &&
    (!n.suspense || e.state.status !== `error`) &&
    x(e, n)
  );
}
function x(e, t) {
  return e.isStaleByTime(t.staleTime);
}
function S(e, t, n) {
  return n.keepPreviousData
    ? !1
    : n.placeholderData === void 0
    ? !i(e.getCurrentResult(), t)
    : t.isPlaceholderData;
}
var C = t((e) => {
    var t = n();
    function r(e, t) {
      return (e === t && (e !== 0 || 1 / e == 1 / t)) || (e !== e && t !== t);
    }
    var i = typeof Object.is == `function` ? Object.is : r,
      a = t.useState,
      o = t.useEffect,
      s = t.useLayoutEffect,
      c = t.useDebugValue;
    function l(e, t) {
      var n = t(),
        r = a({ inst: { value: n, getSnapshot: t } }),
        i = r[0].inst,
        l = r[1];
      return (
        s(
          function () {
            (i.value = n), (i.getSnapshot = t), u(i) && l({ inst: i });
          },
          [e, n, t]
        ),
        o(
          function () {
            return (
              u(i) && l({ inst: i }),
              e(function () {
                u(i) && l({ inst: i });
              })
            );
          },
          [e]
        ),
        c(n),
        n
      );
    }
    function u(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var n = t();
        return !i(e, n);
      } catch {
        return !0;
      }
    }
    function d(e, t) {
      return t();
    }
    var f =
      typeof window > `u` ||
      window.document === void 0 ||
      window.document.createElement === void 0
        ? d
        : l;
    e.useSyncExternalStore =
      t.useSyncExternalStore === void 0 ? f : t.useSyncExternalStore;
  }),
  w = t((e, t) => {
    t.exports = C();
  }),
  T = e(n(), 1),
  E = w().useSyncExternalStore,
  D = T.createContext(!1),
  O = () => T.useContext(D);
D.Provider;
function k() {
  let e = !1;
  return {
    clearReset: () => {
      e = !1;
    },
    reset: () => {
      e = !0;
    },
    isReset: () => e,
  };
}
var A = T.createContext(k()),
  j = () => T.useContext(A);
function M(e, t) {
  return typeof e == `function` ? e(...t) : !!e;
}
var N = (e, t) => {
    (e.suspense || e.useErrorBoundary) &&
      (t.isReset() || (e.retryOnMount = !1));
  },
  P = (e) => {
    T.useEffect(() => {
      e.clearReset();
    }, [e]);
  },
  F = ({ result: e, errorResetBoundary: t, useErrorBoundary: n, query: r }) =>
    e.isError && !t.isReset() && !e.isFetching && M(n, [e.error, r]),
  I = (e) => {
    e.suspense && typeof e.staleTime != `number` && (e.staleTime = 1e3);
  },
  L = (e, t) => e.isLoading && e.isFetching && !t,
  R = (e, t, n) => (e == null ? void 0 : e.suspense) && L(t, n),
  z = (e, t, n) =>
    t
      .fetchOptimistic(e)
      .then(({ data: t }) => {
        e.onSuccess == null || e.onSuccess(t),
          e.onSettled == null || e.onSettled(t, null);
      })
      .catch((t) => {
        n.clearReset(),
          e.onError == null || e.onError(t),
          e.onSettled == null || e.onSettled(void 0, t);
      });
function B(e, t) {
  let n = l({ context: e.context }),
    r = O(),
    i = j(),
    a = n.defaultQueryOptions(e);
  (a._optimisticResults = r ? `isRestoring` : `optimistic`),
    a.onError && (a.onError = f.batchCalls(a.onError)),
    a.onSuccess && (a.onSuccess = f.batchCalls(a.onSuccess)),
    a.onSettled && (a.onSettled = f.batchCalls(a.onSettled)),
    I(a),
    N(a, i),
    P(i);
  let [o] = T.useState(() => new t(n, a)),
    s = o.getOptimisticResult(a);
  if (
    (E(
      T.useCallback(
        (e) => {
          let t = r ? () => void 0 : o.subscribe(f.batchCalls(e));
          return o.updateResult(), t;
        },
        [o, r]
      ),
      () => o.getCurrentResult(),
      () => o.getCurrentResult()
    ),
    T.useEffect(() => {
      o.setOptions(a, { listeners: !1 });
    }, [a, o]),
    R(a, s, r))
  )
    throw z(a, o, i);
  if (
    F({
      result: s,
      errorResetBoundary: i,
      useErrorBoundary: a.useErrorBoundary,
      query: o.getCurrentQuery(),
    })
  )
    throw s.error;
  return a.notifyOnChangeProps ? s : o.trackResult(s);
}
function V(e, t, n) {
  return B(h(e, t, n), g);
}
export { B as n, g as r, V as t };
