import { t as e } from "./howler-B0_Qgrar.js";
var t = e(),
  n = `map-settings`,
  r = new Set(),
  i = (e) => (
    r.add(e),
    () => {
      r.delete(e);
    }
  ),
  a = {
    renderingQuality: null,
    simpleCharacters: !1,
    otherPlayerTrails: !0,
    muted: !1,
    musicVolume: 1,
    soundEffectVolume: 1,
    teamSymbol: !1,
    lexend: !1,
    highContrast: !1,
    largeFontMode: !1,
    readToMe: !1,
  },
  o = Object.keys(a),
  s = (() => {
    let e = {};
    try {
      let t = localStorage.getItem(n);
      if (t === null) {
        let t = (e) => {
          let t = Number(localStorage.getItem(e) ?? 1);
          return Number.isFinite(t) ? Math.max(0, Math.min(1, t)) : 1;
        };
        e = {
          musicVolume: t(`map-music-volume`),
          soundEffectVolume: t(`map-sound-effect-volume`),
          readToMe: !!localStorage.getItem(`read-to-me`),
        };
      } else {
        let n = JSON.parse(t);
        n && typeof n == `object` && !Array.isArray(n) && (e = n);
      }
    } catch {}
    let t = { ...a };
    return (
      o.forEach((n) => {
        let r = e[n];
        ((typeof r == `boolean` && typeof a[n] == `boolean`) ||
          (typeof r == `number` &&
            Number.isFinite(r) &&
            (n === `renderingQuality` || typeof a[n] == `number`))) &&
          Object.assign(t, { [n]: r });
      }),
      t
    );
  })(),
  c = () => {
    try {
      localStorage.setItem(n, JSON.stringify(s));
    } catch {}
  };
c();
var l = () => s,
  u = (e) => s[e],
  d = (e, t) => {
    s[e] !== t && ((s = { ...s, [e]: t }), c(), r.forEach((e) => e()));
  },
  f = () => o.some((e) => s[e] !== a[e]),
  p = () => {
    (s = { ...a }), c(), r.forEach((e) => e());
  },
  m = new Set();
i(() => {
  let e = u(`muted`);
  m.forEach((t) => t.mute(e));
});
var h = class extends t.Howl {
  constructor(e) {
    super({ ...e, mute: u(`muted`) }), m.add(this);
  }
  unload() {
    return m.delete(this), super.unload();
  }
};
export { p as a, f as i, u as n, d as o, l as r, i as s, h as t };
