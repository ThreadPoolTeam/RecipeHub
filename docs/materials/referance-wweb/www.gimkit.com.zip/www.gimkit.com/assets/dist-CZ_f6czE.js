import { n as e } from "./rolldown-runtime-C0FnF6B9.js";
function t(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, `default`)
    ? e.default
    : e;
}
function n() {
  throw Error(`setTimeout has not been defined`);
}
function r() {
  throw Error(`clearTimeout has not been defined`);
}
function i(e) {
  if (f === setTimeout) return setTimeout(e, 0);
  if ((f === n || !f) && setTimeout) return (f = setTimeout), setTimeout(e, 0);
  try {
    return f(e, 0);
  } catch {
    try {
      return f.call(null, e, 0);
    } catch {
      return f.call(this, e, 0);
    }
  }
}
function a(e) {
  if (p === clearTimeout) return clearTimeout(e);
  if ((p === r || !p) && clearTimeout)
    return (p = clearTimeout), clearTimeout(e);
  try {
    return p(e);
  } catch {
    try {
      return p.call(null, e);
    } catch {
      return p.call(this, e);
    }
  }
}
function o() {
  h &&
    g &&
    ((h = !1), g.length ? (m = g.concat(m)) : (_ = -1), m.length && s());
}
function s() {
  if (!h) {
    var e = i(o);
    h = !0;
    for (var t = m.length; t; ) {
      for (g = m, m = []; ++_ < t; ) g && g[_].run();
      (_ = -1), (t = m.length);
    }
    (g = null), (h = !1), a(e);
  }
}
function c(e, t) {
  (this.fun = e), (this.array = t);
}
function l() {}
var u,
  d,
  f,
  p,
  m,
  h,
  g,
  _,
  v,
  y,
  b = e(() => {
    (u = { exports: {} }),
      (d = u.exports = {}),
      (function () {
        try {
          f = typeof setTimeout == `function` ? setTimeout : n;
        } catch {
          f = n;
        }
        try {
          p = typeof clearTimeout == `function` ? clearTimeout : r;
        } catch {
          p = r;
        }
      })(),
      (m = []),
      (h = !1),
      (_ = -1),
      (d.nextTick = function (e) {
        var t = Array(arguments.length - 1);
        if (arguments.length > 1)
          for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
        m.push(new c(e, t)), m.length === 1 && !h && i(s);
      }),
      (c.prototype.run = function () {
        this.fun.apply(null, this.array);
      }),
      (d.title = `browser`),
      (d.browser = !0),
      (d.env = {}),
      (d.argv = []),
      (d.version = ``),
      (d.versions = {}),
      (d.on = l),
      (d.addListener = l),
      (d.once = l),
      (d.off = l),
      (d.removeListener = l),
      (d.removeAllListeners = l),
      (d.emit = l),
      (d.prependListener = l),
      (d.prependOnceListener = l),
      (d.listeners = function (e) {
        return [];
      }),
      (d.binding = function (e) {
        throw Error(`process.binding is not supported`);
      }),
      (d.cwd = function () {
        return `/`;
      }),
      (d.chdir = function (e) {
        throw Error(`process.chdir is not supported`);
      }),
      (d.umask = function () {
        return 0;
      }),
      (v = u.exports),
      (y = t(v));
  });
export { y as n, b as t };
