import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import {
  E as n,
  Ut as r,
  b as i,
  gt as a,
  ht as o,
  m as s,
  s as c,
} from "./Compact-CRRKXVA1.js";
import { _ as l } from "./color-Dzrzfp-h.js";
import { n as u } from "./compact-item-BOjQ1zv3.js";
import { A as d, T as f } from "./ContextIsolator-D7w7V6rn.js";
import {
  a as p,
  i as m,
  n as h,
  o as g,
  r as _,
  t as v,
} from "./InfoCircleFilled-C11bHdqb.js";
import { n as y, t as b } from "./useCSSVarCls-7-ltqzGc.js";
import { i as x, n as S, r as C, t as w } from "./context-BtBbAhyZ.js";
import { a as T } from "./button-Cpfts2Ff.js";
var E = e(t()),
  D = e(r());
a();
var O = (e) => {
    let {
        componentCls: t,
        iconCls: n,
        boxShadow: r,
        colorText: i,
        colorSuccess: a,
        colorError: o,
        colorWarning: c,
        colorInfo: u,
        fontSizeLG: d,
        motionEaseInOutCirc: f,
        motionDurationSlow: p,
        marginXS: m,
        paddingXS: h,
        borderRadiusLG: g,
        zIndexPopup: _,
        contentPadding: v,
        contentBg: y,
      } = e,
      b = `${t}-notice`,
      x = new l(`MessageMoveIn`, {
        "0%": { padding: 0, transform: `translateY(-100%)`, opacity: 0 },
        "100%": { padding: h, transform: `translateY(0)`, opacity: 1 },
      }),
      S = new l(`MessageMoveOut`, {
        "0%": { maxHeight: e.height, padding: h, opacity: 1 },
        "100%": { maxHeight: 0, padding: 0, opacity: 0 },
      }),
      C = {
        padding: h,
        textAlign: `center`,
        [`${t}-custom-content`]: { display: `flex`, alignItems: `center` },
        [`${t}-custom-content > ${n}`]: { marginInlineEnd: m, fontSize: d },
        [`${b}-content`]: {
          display: `inline-block`,
          padding: v,
          background: y,
          borderRadius: g,
          boxShadow: r,
          pointerEvents: `all`,
        },
        [`${t}-success > ${n}`]: { color: a },
        [`${t}-error > ${n}`]: { color: o },
        [`${t}-warning > ${n}`]: { color: c },
        [`${t}-info > ${n},
      ${t}-loading > ${n}`]: { color: u },
      };
    return [
      {
        [t]: Object.assign(Object.assign({}, s(e)), {
          color: i,
          position: `fixed`,
          top: m,
          width: `100%`,
          pointerEvents: `none`,
          zIndex: _,
          [`${t}-move-up`]: { animationFillMode: `forwards` },
          [`
        ${t}-move-up-appear,
        ${t}-move-up-enter
      `]: {
            animationName: x,
            animationDuration: p,
            animationPlayState: `paused`,
            animationTimingFunction: f,
          },
          [`
        ${t}-move-up-appear${t}-move-up-appear-active,
        ${t}-move-up-enter${t}-move-up-enter-active
      `]: { animationPlayState: `running` },
          [`${t}-move-up-leave`]: {
            animationName: S,
            animationDuration: p,
            animationPlayState: `paused`,
            animationTimingFunction: f,
          },
          [`${t}-move-up-leave${t}-move-up-leave-active`]: {
            animationPlayState: `running`,
          },
          "&-rtl": { direction: `rtl`, span: { direction: `rtl` } },
        }),
      },
      { [t]: { [`${b}-wrapper`]: Object.assign({}, C) } },
      {
        [`${t}-notice-pure-panel`]: Object.assign(Object.assign({}, C), {
          padding: 0,
          textAlign: `start`,
        }),
      },
    ];
  },
  k = c(
    `Message`,
    (e) => O(i(e, { height: 150 })),
    (e) => ({
      zIndexPopup: e.zIndexPopupBase + f + 10,
      contentBg: e.colorBgElevated,
      contentPadding: `${
        (e.controlHeightLG - e.fontSize * e.lineHeight) / 2
      }px ${e.paddingSM}px`,
    })
  ),
  A = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  j = {
    info: E.createElement(v, null),
    success: E.createElement(m, null),
    error: E.createElement(y, null),
    warning: E.createElement(h, null),
    loading: E.createElement(u, null),
  },
  M = ({ prefixCls: e, type: t, icon: n, children: r }) =>
    E.createElement(
      `div`,
      { className: (0, D.default)(`${e}-custom-content`, `${e}-${t}`) },
      n || j[t],
      E.createElement(`span`, null, r)
    ),
  N = (e) => {
    let { prefixCls: t, className: r, type: i, icon: a, content: o } = e,
      s = A(e, [`prefixCls`, `className`, `type`, `icon`, `content`]),
      { getPrefixCls: c } = E.useContext(n),
      l = t || c(`message`),
      u = b(l),
      [d, f, p] = k(l, u);
    return d(
      E.createElement(
        x,
        Object.assign({}, s, {
          prefixCls: l,
          className: (0, D.default)(r, f, `${l}-notice-pure-panel`, p, u),
          eventKey: `pure`,
          duration: null,
          content: E.createElement(M, { prefixCls: l, type: i, icon: a }, o),
        })
      )
    );
  };
function P(e, t) {
  return { motionName: t ?? `${e}-move-up` };
}
function F(e) {
  let t,
    n = new Promise((n) => {
      t = e(() => {
        n(!0);
      });
    }),
    r = () => {
      t == null || t();
    };
  return (r.then = (e, t) => n.then(e, t)), (r.promise = n), r;
}
var I = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  L = 8,
  R = 3,
  z = ({ children: e, prefixCls: t }) => {
    let n = b(t),
      [r, i, a] = k(t, n);
    return r(
      E.createElement(C, { classNames: { list: (0, D.default)(i, a, n) } }, e)
    );
  },
  B = (e, { prefixCls: t, key: n }) =>
    E.createElement(z, { prefixCls: t, key: n }, e),
  V = E.forwardRef((e, t) => {
    let {
        top: r,
        prefixCls: i,
        getContainer: a,
        maxCount: o,
        duration: s = R,
        rtl: c,
        transitionName: l,
        onAllRemoved: u,
      } = e,
      {
        getPrefixCls: d,
        getPopupContainer: f,
        message: p,
        direction: m,
      } = E.useContext(n),
      h = i || d(`message`),
      g = () => ({ left: `50%`, transform: `translateX(-50%)`, top: r ?? L }),
      v = () => (0, D.default)({ [`${h}-rtl`]: c ?? m === `rtl` }),
      y = () => P(h, l),
      b = E.createElement(
        `span`,
        { className: `${h}-close-x` },
        E.createElement(_, { className: `${h}-close-icon` })
      ),
      [x, C] = S({
        prefixCls: h,
        style: g,
        className: v,
        motion: y,
        closable: !1,
        closeIcon: b,
        duration: s,
        getContainer: () =>
          (a == null ? void 0 : a()) ||
          (f == null ? void 0 : f()) ||
          document.body,
        maxCount: o,
        onAllRemoved: u,
        renderNotifications: B,
      });
    return (
      E.useImperativeHandle(t, () =>
        Object.assign(Object.assign({}, x), { prefixCls: h, message: p })
      ),
      C
    );
  }),
  H = 0;
function U(e) {
  let t = E.useRef(null);
  return (
    d(`Message`),
    [
      E.useMemo(() => {
        let e = (e) => {
            var n;
            (n = t.current) == null || n.close(e);
          },
          n = (n) => {
            if (!t.current) {
              let e = () => {};
              return (e.then = () => {}), e;
            }
            let { open: r, prefixCls: i, message: a } = t.current,
              o = `${i}-notice`,
              {
                content: s,
                icon: c,
                type: l,
                key: u,
                className: d,
                style: f,
                onClose: p,
              } = n,
              m = I(n, [
                `content`,
                `icon`,
                `type`,
                `key`,
                `className`,
                `style`,
                `onClose`,
              ]),
              h = u;
            return (
              h ?? ((H += 1), (h = `antd-message-${H}`)),
              F(
                (t) => (
                  r(
                    Object.assign(Object.assign({}, m), {
                      key: h,
                      content: E.createElement(
                        M,
                        { prefixCls: i, type: l, icon: c },
                        s
                      ),
                      placement: `top`,
                      className: (0, D.default)(
                        l && `${o}-${l}`,
                        d,
                        a == null ? void 0 : a.className
                      ),
                      style: Object.assign(
                        Object.assign({}, a == null ? void 0 : a.style),
                        f
                      ),
                      onClose: () => {
                        p == null || p(), t();
                      },
                    })
                  ),
                  () => {
                    e(h);
                  }
                )
              )
            );
          },
          r = {
            open: n,
            destroy: (n) => {
              var r;
              n === void 0 ? (r = t.current) == null || r.destroy() : e(n);
            },
          };
        return (
          [`info`, `success`, `warning`, `error`, `loading`].forEach((e) => {
            r[e] = (t, r, i) => {
              let a;
              a =
                t && typeof t == `object` && `content` in t
                  ? t
                  : { content: t };
              let o, s;
              typeof r == `function` ? (s = r) : ((o = r), (s = i));
              let c = Object.assign(
                Object.assign({ onClose: s, duration: o }, a),
                { type: e }
              );
              return n(c);
            };
          }),
          r
        );
      }, []),
      E.createElement(
        V,
        Object.assign({ key: `message-holder` }, e, { ref: t })
      ),
    ]
  );
}
function W(e) {
  return U(e);
}
var G = null,
  K = (e) => e(),
  q = [],
  J = {};
function Y() {
  let { getContainer: e, duration: t, rtl: n, maxCount: r, top: i } = J,
    a = (e == null ? void 0 : e()) || document.body;
  return { getContainer: () => a, duration: t, rtl: n, maxCount: r, top: i };
}
var X = E.forwardRef((e, t) => {
    let { messageConfig: r, sync: i } = e,
      { getPrefixCls: a } = (0, E.useContext)(n),
      o = J.prefixCls || a(`message`),
      s = (0, E.useContext)(w),
      [c, l] = U(
        Object.assign(
          Object.assign(Object.assign({}, r), { prefixCls: o }),
          s.message
        )
      );
    return (
      E.useImperativeHandle(t, () => {
        let e = Object.assign({}, c);
        return (
          Object.keys(e).forEach((t) => {
            e[t] = (...e) => (i(), c[t].apply(c, e));
          }),
          { instance: e, sync: i }
        );
      }),
      l
    );
  }),
  Z = E.forwardRef((e, t) => {
    let [n, r] = E.useState(Y),
      i = () => {
        r(Y);
      };
    E.useEffect(i, []);
    let a = g(),
      o = a.getRootPrefixCls(),
      s = a.getIconPrefixCls(),
      c = a.getTheme(),
      l = E.createElement(X, { ref: t, sync: i, messageConfig: n });
    return E.createElement(
      p,
      { prefixCls: o, iconPrefixCls: s, theme: c },
      a.holderRender ? a.holderRender(l) : l
    );
  }),
  Q = () => {
    if (G)
      G.instance &&
        (q.forEach((e) => {
          let { type: t, skipped: n } = e;
          if (!n)
            switch (t) {
              case `open`:
                K(() => {
                  let t = G.instance.open(
                    Object.assign(Object.assign({}, J), e.config)
                  );
                  t == null || t.then(e.resolve), e.setCloseFn(t);
                });
                break;
              case `destroy`:
                K(() => {
                  G == null || G.instance.destroy(e.key);
                });
                break;
              default:
                K(() => {
                  var n;
                  let r = (n = G.instance)[t].apply(n, o(e.args));
                  r == null || r.then(e.resolve), e.setCloseFn(r);
                });
            }
        }),
        (q = []));
    else {
      let e = document.createDocumentFragment(),
        t = { fragment: e };
      (G = t),
        K(() => {
          T()(
            E.createElement(Z, {
              ref: (e) => {
                let { instance: n, sync: r } = e || {};
                Promise.resolve().then(() => {
                  !t.instance && n && ((t.instance = n), (t.sync = r), Q());
                });
              },
            }),
            e
          );
        });
    }
  };
function ee(e) {
  (J = Object.assign(Object.assign({}, J), e)),
    K(() => {
      var e;
      (e = G == null ? void 0 : G.sync) == null || e.call(G);
    });
}
function te(e) {
  let t = F((t) => {
    let n,
      r = {
        type: `open`,
        config: e,
        resolve: t,
        setCloseFn: (e) => {
          n = e;
        },
      };
    return (
      q.push(r),
      () => {
        n
          ? K(() => {
              n();
            })
          : (r.skipped = !0);
      }
    );
  });
  return Q(), t;
}
function ne(e, t) {
  g();
  let n = F((n) => {
    let r,
      i = {
        type: e,
        args: t,
        resolve: n,
        setCloseFn: (e) => {
          r = e;
        },
      };
    return (
      q.push(i),
      () => {
        r
          ? K(() => {
              r();
            })
          : (i.skipped = !0);
      }
    );
  });
  return Q(), n;
}
var re = (e) => {
    q.push({ type: `destroy`, key: e }), Q();
  },
  ie = [`success`, `info`, `warning`, `error`, `loading`],
  $ = {
    open: te,
    destroy: re,
    config: ee,
    useMessage: W,
    _InternalPanelDoNotUseOrYouWillBeFired: N,
  };
ie.forEach((e) => {
  $[e] = (...t) => ne(e, t);
});
export { $ as t };
