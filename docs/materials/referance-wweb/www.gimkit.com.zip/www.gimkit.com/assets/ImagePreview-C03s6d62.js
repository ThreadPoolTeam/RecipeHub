import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { t as n } from "./modal-Ch5Fwjpt.js";
import { t as r } from "./jsx-runtime-CA2T8_y1.js";
import { l as i, n as a } from "./index-DG2EaUNY.js";
import { t as o } from "./getCloudinaryUrl-CR7quWSQ.js";
var s = e(t()),
  c = r(),
  l = i.img.attrs((e) => ({ src: e.image }))`
  cursor: pointer;
  height: ${(e) => e.size}px;
  width: ${(e) => e.size}px;
  margin-right: ${(e) => (e.customRightMargin ? e.customRightMargin : 0)}px;
  border-radius: 5px;
  ${(e) => e.showBorder && `border: solid ${a.Black} 1px;`}
  flex-shrink: 0;
  object-fit: cover;
`,
  u = (e) => {
    let [t, r] = s.useState(!1),
      i = (t) => {
        t.stopPropagation(),
          e.onClick && e.onClick(),
          e.blockModalOpen || r(!0);
      };
    return (0, c.jsxs)(c.Fragment, {
      children: [
        (0, c.jsx)(l, { ...e, onClick: i }),
        (0, c.jsx)(n, {
          open: t,
          onCancel: (e) => {
            e.stopPropagation(), r(!1);
          },
          footer: null,
          closable: !1,
          children: (0, c.jsx)(`img`, {
            src: o(e.image),
            style: { width: `100%` },
          }),
        }),
      ],
    });
  };
export { u as t };
