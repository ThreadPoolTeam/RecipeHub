import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { c as n, s as r } from "./assertThisInitialized-DqpgQyeg.js";
import {
  Dt as i,
  E as a,
  Et as o,
  H as s,
  Ht as c,
  It as l,
  J as u,
  Lt as d,
  Ot as f,
  Tt as p,
  Ut as m,
  Vt as h,
  X as g,
  Y as _,
  a as v,
  b as y,
  h as ee,
  lt as b,
  m as x,
  nt as S,
  r as te,
  s as ne,
  tt as C,
  ut as w,
  wt as T,
  zt as E,
} from "./Compact-CRRKXVA1.js";
import { h as D, v as O } from "./color-Dzrzfp-h.js";
import { r as k, t as re } from "./compact-item-BOjQ1zv3.js";
import { r as ie, t as ae } from "./ContextIsolator-D7w7V6rn.js";
import { a as A } from "./InfoCircleFilled-C11bHdqb.js";
import { t as oe } from "./useCSSVarCls-7-ltqzGc.js";
import { n as se } from "./es-C_Dx0dL1.js";
import {
  C as ce,
  S as le,
  _ as j,
  a as ue,
  b as M,
  c as N,
  f as de,
  g as P,
  h as F,
  m as I,
  o as fe,
  s as L,
  u as R,
  v as pe,
  y as me,
} from "./input-CWNNlK6u.js";
import { t as z } from "./useVariants-Bm4HVCER.js";
import { t as B } from "./DownOutlined-DbiyjNvG.js";
var V = e(t());
n();
var he = {
    icon: {
      tag: `svg`,
      attrs: { viewBox: `64 64 896 896`, focusable: `false` },
      children: [
        {
          tag: `path`,
          attrs: {
            d: `M890.5 755.3L537.9 269.2c-12.8-17.6-39-17.6-51.7 0L133.5 755.3A8 8 0 00140 768h75c5.1 0 9.9-2.5 12.9-6.6L512 369.8l284.1 391.6c3 4.1 7.8 6.6 12.9 6.6h75c6.5 0 10.3-7.4 6.5-12.7z`,
          },
        },
      ],
    },
    name: `up`,
    theme: `outlined`,
  },
  ge = V.forwardRef(function (e, t) {
    return V.createElement(k, r({}, e, { ref: t, icon: he }));
  }),
  H = e(m());
c(), d(), i(), p(), w(), S();
function _e() {
  return typeof BigInt == `function`;
}
function U(e) {
  return (!e && e !== 0 && !Number.isNaN(e)) || !String(e).trim();
}
function W(e) {
  var t = e.trim(),
    n = t.startsWith(`-`);
  n && (t = t.slice(1)),
    (t = t
      .replace(/(\.\d*[^0])0*$/, `$1`)
      .replace(/\.0*$/, ``)
      .replace(/^0+/, ``)),
    t.startsWith(`.`) && (t = `0${t}`);
  var r = t || `0`,
    i = r.split(`.`),
    a = i[0] || `0`,
    o = i[1] || `0`;
  a === `0` && o === `0` && (n = !1);
  var s = n ? `-` : ``;
  return {
    negative: n,
    negativeStr: s,
    trimStr: r,
    integerStr: a,
    decimalStr: o,
    fullStr: `${s}${r}`,
  };
}
function G(e) {
  var t = String(e);
  return !Number.isNaN(Number(t)) && t.includes(`e`);
}
function K(e) {
  var t = String(e);
  if (G(e)) {
    var n = Number(t.slice(t.indexOf(`e-`) + 2)),
      r = t.match(/\.(\d+)/);
    return r != null && r[1] && (n += r[1].length), n;
  }
  return t.includes(`.`) && ye(t) ? t.length - t.indexOf(`.`) - 1 : 0;
}
function ve(e) {
  var t = String(e);
  if (G(e)) {
    if (e > 2 ** 53 - 1)
      return String(_e() ? BigInt(e).toString() : 2 ** 53 - 1);
    if (e < -(2 ** 53 - 1))
      return String(_e() ? BigInt(e).toString() : -(2 ** 53 - 1));
    t = e.toFixed(K(t));
  }
  return W(t).fullStr;
}
function ye(e) {
  return typeof e == `number`
    ? !Number.isNaN(e)
    : e
    ? /^\s*-?\d+(\.\d+)?\s*$/.test(e) ||
      /^\s*-?\d+\.\s*$/.test(e) ||
      /^\s*-?\.\d+\s*$/.test(e)
    : !1;
}
var q = (function () {
  function e(t) {
    if (
      (o(this, e),
      l(this, `origin`, ``),
      l(this, `negative`, void 0),
      l(this, `integer`, void 0),
      l(this, `decimal`, void 0),
      l(this, `decimalLen`, void 0),
      l(this, `empty`, void 0),
      l(this, `nan`, void 0),
      U(t))
    )
      this.empty = !0;
    else if (((this.origin = String(t)), t === `-` || Number.isNaN(t)))
      this.nan = !0;
    else {
      var n = t;
      if (
        (G(n) && (n = Number(n)), (n = typeof n == `string` ? n : ve(n)), ye(n))
      ) {
        var r = W(n);
        this.negative = r.negative;
        var i = r.trimStr.split(`.`);
        this.integer = BigInt(i[0]);
        var a = i[1] || `0`;
        (this.decimal = BigInt(a)), (this.decimalLen = a.length);
      } else this.nan = !0;
    }
  }
  return (
    T(e, [
      {
        key: `getMark`,
        value: function () {
          return this.negative ? `-` : ``;
        },
      },
      {
        key: `getIntegerStr`,
        value: function () {
          return this.integer.toString();
        },
      },
      {
        key: `getDecimalStr`,
        value: function () {
          return this.decimal.toString().padStart(this.decimalLen, `0`);
        },
      },
      {
        key: `alignDecimal`,
        value: function (e) {
          var t = `${this.getMark()}${this.getIntegerStr()}${this.getDecimalStr().padEnd(
            e,
            `0`
          )}`;
          return BigInt(t);
        },
      },
      {
        key: `negate`,
        value: function () {
          var t = new e(this.toString());
          return (t.negative = !t.negative), t;
        },
      },
      {
        key: `cal`,
        value: function (t, n, r) {
          var i = Math.max(
              this.getDecimalStr().length,
              t.getDecimalStr().length
            ),
            a = n(this.alignDecimal(i), t.alignDecimal(i)).toString(),
            o = r(i),
            s = W(a),
            c = `${s.negativeStr}${s.trimStr.padStart(o + 1, `0`)}`;
          return new e(`${c.slice(0, -o)}.${c.slice(-o)}`);
        },
      },
      {
        key: `add`,
        value: function (t) {
          if (this.isInvalidate()) return new e(t);
          var n = new e(t);
          return n.isInvalidate()
            ? this
            : this.cal(
                n,
                function (e, t) {
                  return e + t;
                },
                function (e) {
                  return e;
                }
              );
        },
      },
      {
        key: `multi`,
        value: function (t) {
          var n = new e(t);
          return this.isInvalidate() || n.isInvalidate()
            ? new e(NaN)
            : this.cal(
                n,
                function (e, t) {
                  return e * t;
                },
                function (e) {
                  return e * 2;
                }
              );
        },
      },
      {
        key: `isEmpty`,
        value: function () {
          return this.empty;
        },
      },
      {
        key: `isNaN`,
        value: function () {
          return this.nan;
        },
      },
      {
        key: `isInvalidate`,
        value: function () {
          return this.isEmpty() || this.isNaN();
        },
      },
      {
        key: `equals`,
        value: function (e) {
          return this.toString() === (e == null ? void 0 : e.toString());
        },
      },
      {
        key: `lessEquals`,
        value: function (e) {
          return this.add(e.negate().toString()).toNumber() <= 0;
        },
      },
      {
        key: `toNumber`,
        value: function () {
          return this.isNaN() ? NaN : Number(this.toString());
        },
      },
      {
        key: `toString`,
        value: function () {
          return arguments.length > 0 &&
            arguments[0] !== void 0 &&
            !arguments[0]
            ? this.origin
            : this.isInvalidate()
            ? ``
            : W(
                `${this.getMark()}${this.getIntegerStr()}.${this.getDecimalStr()}`
              ).fullStr;
        },
      },
    ]),
    e
  );
})();
i(), p(), d();
var J = (function () {
  function e(t) {
    o(this, e),
      l(this, `origin`, ``),
      l(this, `number`, void 0),
      l(this, `empty`, void 0),
      U(t)
        ? (this.empty = !0)
        : ((this.origin = String(t)), (this.number = Number(t)));
  }
  return (
    T(e, [
      {
        key: `negate`,
        value: function () {
          return new e(-this.toNumber());
        },
      },
      {
        key: `add`,
        value: function (t) {
          if (this.isInvalidate()) return new e(t);
          var n = Number(t);
          if (Number.isNaN(n)) return this;
          var r = this.number + n;
          if (r > 2 ** 53 - 1) return new e(2 ** 53 - 1);
          if (r < -(2 ** 53 - 1)) return new e(-(2 ** 53 - 1));
          var i = Math.max(K(this.number), K(n));
          return new e(r.toFixed(i));
        },
      },
      {
        key: `multi`,
        value: function (t) {
          var n = Number(t);
          if (this.isInvalidate() || Number.isNaN(n)) return new e(NaN);
          var r = this.number * n;
          if (r > 2 ** 53 - 1) return new e(2 ** 53 - 1);
          if (r < -(2 ** 53 - 1)) return new e(-(2 ** 53 - 1));
          var i = Math.max(K(this.number), K(n));
          return new e(r.toFixed(i));
        },
      },
      {
        key: `isEmpty`,
        value: function () {
          return this.empty;
        },
      },
      {
        key: `isNaN`,
        value: function () {
          return Number.isNaN(this.number);
        },
      },
      {
        key: `isInvalidate`,
        value: function () {
          return this.isEmpty() || this.isNaN();
        },
      },
      {
        key: `equals`,
        value: function (e) {
          return this.toNumber() === (e == null ? void 0 : e.toNumber());
        },
      },
      {
        key: `lessEquals`,
        value: function (e) {
          return this.add(e.negate().toString()).toNumber() <= 0;
        },
      },
      {
        key: `toNumber`,
        value: function () {
          return this.number;
        },
      },
      {
        key: `toString`,
        value: function () {
          return arguments.length > 0 &&
            arguments[0] !== void 0 &&
            !arguments[0]
            ? this.origin
            : this.isInvalidate()
            ? ``
            : ve(this.number);
        },
      },
    ]),
    e
  );
})();
function Y(e) {
  return _e() ? new q(e) : new J(e);
}
function be(e, t, n) {
  var r = arguments.length > 3 && arguments[3] !== void 0 && arguments[3];
  if (e === ``) return ``;
  var i = W(e),
    a = i.negativeStr,
    o = i.integerStr,
    s = i.decimalStr,
    c = `${t}${s}`,
    l = `${a}${o}`;
  if (n >= 0) {
    var u = Number(s[n]);
    return u >= 5 && !r
      ? be(
          Y(e)
            .add(`${a}0.${`0`.repeat(n)}${10 - u}`)
            .toString(),
          t,
          n,
          r
        )
      : n === 0
      ? l
      : `${l}${t}${s.padEnd(n, `0`).slice(0, n)}`;
  }
  return c === `.0` ? l : `${l}${c}`;
}
var X = Y;
function xe(e, t) {
  return typeof Proxy < `u` && e
    ? new Proxy(e, {
        get: function (e, n) {
          if (t[n]) return t[n];
          var r = e[n];
          return typeof r == `function` ? r.bind(e) : r;
        },
      })
    : e;
}
function Se(e, t) {
  var n = (0, V.useRef)(null);
  function r() {
    try {
      var t = e.selectionStart,
        r = e.selectionEnd,
        i = e.value;
      n.current = {
        start: t,
        end: r,
        value: i,
        beforeTxt: i.substring(0, t),
        afterTxt: i.substring(r),
      };
    } catch {}
  }
  function i() {
    if (e && n.current && t)
      try {
        var r = e.value,
          i = n.current,
          a = i.beforeTxt,
          o = i.afterTxt,
          s = i.start,
          c = r.length;
        if (r.startsWith(a)) c = a.length;
        else if (r.endsWith(o)) c = r.length - n.current.afterTxt.length;
        else {
          var l = a[s - 1],
            u = r.indexOf(l, s - 1);
          u !== -1 && (c = u + 1);
        }
        e.setSelectionRange(c, c);
      } catch (e) {
        E(
          !1,
          `Something warning of cursor restore. Please fire issue about this: ${e.message}`
        );
      }
  }
  return [r, i];
}
var Ce = function () {
  var e = (0, V.useState)(!1),
    t = b(e, 2),
    n = t[0],
    r = t[1];
  return (
    u(function () {
      r(se());
    }, []),
    n
  );
};
n(), d();
var we = 200,
  Te = 600;
function Ee(e) {
  var t = e.prefixCls,
    n = e.upNode,
    i = e.downNode,
    a = e.upDisabled,
    o = e.downDisabled,
    s = e.onStep,
    c = V.useRef(),
    u = V.useRef([]),
    d = V.useRef();
  d.current = s;
  var f = function () {
      clearTimeout(c.current);
    },
    p = function (e, t) {
      e.preventDefault(), f(), d.current(t);
      function n() {
        d.current(t), (c.current = setTimeout(n, we));
      }
      c.current = setTimeout(n, Te);
    };
  if (
    (V.useEffect(function () {
      return function () {
        f(),
          u.current.forEach(function (e) {
            return O.cancel(e);
          });
      };
    }, []),
    Ce())
  )
    return null;
  var m = `${t}-handler`,
    h = (0, H.default)(m, `${m}-up`, l({}, `${m}-up-disabled`, a)),
    g = (0, H.default)(m, `${m}-down`, l({}, `${m}-down-disabled`, o)),
    _ = function () {
      return u.current.push(O(f));
    },
    v = { unselectable: `on`, role: `button`, onMouseUp: _, onMouseLeave: _ };
  return V.createElement(
    `div`,
    { className: `${m}-wrap` },
    V.createElement(
      `span`,
      r({}, v, {
        onMouseDown: function (e) {
          p(e, !0);
        },
        "aria-label": `Increase Value`,
        "aria-disabled": a,
        className: h,
      }),
      n ||
        V.createElement(`span`, {
          unselectable: `on`,
          className: `${t}-handler-up-inner`,
        })
    ),
    V.createElement(
      `span`,
      r({}, v, {
        onMouseDown: function (e) {
          p(e, !1);
        },
        "aria-label": `Decrease Value`,
        "aria-disabled": o,
        className: g,
      }),
      i ||
        V.createElement(`span`, {
          unselectable: `on`,
          className: `${t}-handler-down-inner`,
        })
    )
  );
}
function De(e) {
  var t = typeof e == `number` ? ve(e) : W(e).fullStr;
  return t.includes(`.`)
    ? W(t.replace(/(\d)\.(\d)/g, `$1$2.`)).fullStr
    : e + `0`;
}
var Oe = function () {
  var e = (0, V.useRef)(0),
    t = function () {
      O.cancel(e.current);
    };
  return (
    (0, V.useEffect)(function () {
      return t;
    }, []),
    function (n) {
      t(),
        (e.current = O(function () {
          n();
        }));
    }
  );
};
n(), d(), w();
var ke =
    `prefixCls.className.style.min.max.step.defaultValue.value.disabled.readOnly.upHandler.downHandler.keyboard.changeOnWheel.controls.classNames.stringMode.parser.formatter.precision.decimalSeparator.onChange.onInput.onPressEnter.onStep.changeOnBlur.domRef`.split(
      `.`
    ),
  Ae = [
    `disabled`,
    `style`,
    `prefixCls`,
    `value`,
    `prefix`,
    `suffix`,
    `addonBefore`,
    `addonAfter`,
    `className`,
    `classNames`,
  ],
  je = function (e, t) {
    return e || t.isEmpty() ? t.toString() : t.toNumber();
  },
  Me = function (e) {
    var t = X(e);
    return t.isInvalidate() ? null : t;
  },
  Ne = V.forwardRef(function (e, t) {
    var n = e.prefixCls,
      i = e.className,
      a = e.style,
      o = e.min,
      s = e.max,
      c = e.step,
      u = c === void 0 ? 1 : c,
      d = e.defaultValue,
      p = e.value,
      m = e.disabled,
      g = e.readOnly,
      v = e.upHandler,
      y = e.downHandler,
      ee = e.keyboard,
      x = e.changeOnWheel,
      S = x !== void 0 && x,
      te = e.controls,
      ne = te === void 0 || te;
    e.classNames;
    var w = e.stringMode,
      T = e.parser,
      E = e.formatter,
      D = e.precision,
      O = e.decimalSeparator,
      k = e.onChange,
      re = e.onInput,
      ie = e.onPressEnter,
      ae = e.onStep,
      A = e.changeOnBlur,
      oe = A === void 0 || A,
      se = e.domRef,
      ce = C(e, ke),
      le = `${n}-input`,
      j = V.useRef(null),
      ue = V.useState(!1),
      M = b(ue, 2),
      N = M[0],
      de = M[1],
      P = V.useRef(!1),
      F = V.useRef(!1),
      I = V.useRef(!1),
      fe = V.useState(function () {
        return X(p ?? d);
      }),
      L = b(fe, 2),
      R = L[0],
      pe = L[1];
    function me(e) {
      p === void 0 && pe(e);
    }
    var z = V.useCallback(
        function (e, t) {
          if (!t) return D >= 0 ? D : Math.max(K(e), K(u));
        },
        [D, u]
      ),
      B = V.useCallback(
        function (e) {
          var t = String(e);
          if (T) return T(t);
          var n = t;
          return O && (n = n.replace(O, `.`)), n.replace(/[^\w.-]+/g, ``);
        },
        [T, O]
      ),
      he = V.useRef(``),
      ge = V.useCallback(
        function (e, t) {
          if (E) return E(e, { userTyping: t, input: String(he.current) });
          var n = typeof e == `number` ? ve(e) : e;
          if (!t) {
            var r = z(n, t);
            ye(n) && (O || r >= 0) && (n = be(n, O || `.`, r));
          }
          return n;
        },
        [E, z, O]
      ),
      _e = V.useState(function () {
        var e = d ?? p;
        return R.isInvalidate() && [`string`, `number`].includes(h(e))
          ? Number.isNaN(e)
            ? ``
            : e
          : ge(R.toString(), !1);
      }),
      U = b(_e, 2),
      W = U[0],
      G = U[1];
    he.current = W;
    function q(e, t) {
      G(ge(e.isInvalidate() ? e.toString(!1) : e.toString(!t), t));
    }
    var J = V.useMemo(
        function () {
          return Me(s);
        },
        [s, D]
      ),
      Y = V.useMemo(
        function () {
          return Me(o);
        },
        [o, D]
      ),
      xe = V.useMemo(
        function () {
          return !J || !R || R.isInvalidate() ? !1 : J.lessEquals(R);
        },
        [J, R]
      ),
      Ce = V.useMemo(
        function () {
          return !Y || !R || R.isInvalidate() ? !1 : R.lessEquals(Y);
        },
        [Y, R]
      ),
      we = Se(j.current, N),
      Te = b(we, 2),
      Ae = Te[0],
      Ne = Te[1],
      Pe = function (e) {
        return J && !e.lessEquals(J) ? J : Y && !Y.lessEquals(e) ? Y : null;
      },
      Z = function (e) {
        return !Pe(e);
      },
      Q = function (e, t) {
        var n = e,
          r = Z(n) || n.isEmpty();
        if (
          (!n.isEmpty() && !t && ((n = Pe(n) || n), (r = !0)), !g && !m && r)
        ) {
          var i = n.toString(),
            a = z(i, t);
          return (
            a >= 0 &&
              ((n = X(be(i, `.`, a))), Z(n) || (n = X(be(i, `.`, a, !0)))),
            n.equals(R) ||
              (me(n),
              k == null || k(n.isEmpty() ? null : je(w, n)),
              p === void 0 && q(n, t)),
            n
          );
        }
        return R;
      },
      Fe = Oe(),
      Ie = function e(t) {
        if ((Ae(), (he.current = t), G(t), !F.current)) {
          var n = X(B(t));
          n.isNaN() || Q(n, !0);
        }
        re == null || re(t),
          Fe(function () {
            var n = t;
            T || (n = t.replace(/。/g, `.`)), n !== t && e(n);
          });
      },
      Le = function () {
        F.current = !0;
      },
      Re = function () {
        (F.current = !1), Ie(j.current.value);
      },
      ze = function (e) {
        Ie(e.target.value);
      },
      $ = function (e) {
        var t;
        if (!((e && xe) || (!e && Ce))) {
          P.current = !1;
          var n = X(I.current ? De(u) : u);
          e || (n = n.negate());
          var r = Q((R || X(0)).add(n.toString()), !1);
          ae == null ||
            ae(je(w, r), {
              offset: I.current ? De(u) : u,
              type: e ? `up` : `down`,
            }),
            (t = j.current) == null || t.focus();
        }
      },
      Be = function (e) {
        var t = X(B(W)),
          n = t.isNaN() ? Q(R, e) : Q(t, e);
        p === void 0 ? n.isNaN() || q(n, !1) : q(R, !1);
      };
    return (
      V.useEffect(function () {
        if (S && N) {
          var e = function (e) {
              $(e.deltaY < 0), e.preventDefault();
            },
            t = j.current;
          if (t)
            return (
              t.addEventListener(`wheel`, e, { passive: !1 }),
              function () {
                return t.removeEventListener(`wheel`, e);
              }
            );
        }
      }),
      _(
        function () {
          R.isInvalidate() || q(R, !1);
        },
        [D, E]
      ),
      _(
        function () {
          var e = X(p);
          pe(e);
          var t = X(B(W));
          (!e.equals(t) || !P.current || E) && q(e, P.current);
        },
        [p]
      ),
      _(
        function () {
          E && Ne();
        },
        [W]
      ),
      V.createElement(
        `div`,
        {
          ref: se,
          className: (0, H.default)(
            n,
            i,
            l(
              l(
                l(
                  l(l({}, `${n}-focused`, N), `${n}-disabled`, m),
                  `${n}-readonly`,
                  g
                ),
                `${n}-not-a-number`,
                R.isNaN()
              ),
              `${n}-out-of-range`,
              !R.isInvalidate() && !Z(R)
            )
          ),
          style: a,
          onFocus: function () {
            de(!0);
          },
          onBlur: function () {
            oe && Be(!1), de(!1), (P.current = !1);
          },
          onKeyDown: function (e) {
            var t = e.key,
              n = e.shiftKey;
            (P.current = !0),
              (I.current = n),
              t === `Enter` &&
                (F.current || (P.current = !1), Be(!1), ie == null || ie(e)),
              ee !== !1 &&
                !F.current &&
                [`Up`, `ArrowUp`, `Down`, `ArrowDown`].includes(t) &&
                ($(t === `Up` || t === `ArrowUp`), e.preventDefault());
          },
          onKeyUp: function () {
            (P.current = !1), (I.current = !1);
          },
          onCompositionStart: Le,
          onCompositionEnd: Re,
          onBeforeInput: function () {
            P.current = !0;
          },
        },
        ne &&
          V.createElement(Ee, {
            prefixCls: n,
            upNode: v,
            downNode: y,
            upDisabled: xe,
            downDisabled: Ce,
            onStep: $,
          }),
        V.createElement(
          `div`,
          { className: `${le}-wrap` },
          V.createElement(
            `input`,
            r(
              {
                autoComplete: `off`,
                role: `spinbutton`,
                "aria-valuemin": o,
                "aria-valuemax": s,
                "aria-valuenow": R.isInvalidate() ? null : R.toString(),
                step: u,
              },
              ce,
              {
                ref: f(j, t),
                className: le,
                value: W,
                onChange: ze,
                disabled: m,
                readOnly: g,
              }
            )
          )
        )
      )
    );
  }),
  Pe = V.forwardRef(function (e, t) {
    var n = e.disabled,
      i = e.style,
      a = e.prefixCls,
      o = a === void 0 ? `rc-input-number` : a,
      s = e.value,
      c = e.prefix,
      l = e.suffix,
      u = e.addonBefore,
      d = e.addonAfter,
      f = e.className,
      p = e.classNames,
      m = C(e, Ae),
      h = V.useRef(null),
      g = V.useRef(null),
      _ = V.useRef(null),
      v = function (e) {
        _.current && fe(_.current, e);
      };
    return (
      V.useImperativeHandle(t, function () {
        return xe(_.current, {
          focus: v,
          nativeElement: h.current.nativeElement || g.current,
        });
      }),
      V.createElement(
        ue,
        {
          className: f,
          triggerFocus: v,
          prefixCls: o,
          value: s,
          disabled: n,
          style: i,
          prefix: c,
          suffix: l,
          addonAfter: d,
          addonBefore: u,
          classNames: p,
          components: {
            affixWrapper: `div`,
            groupWrapper: `div`,
            wrapper: `div`,
            groupAddon: `div`,
          },
          ref: h,
        },
        V.createElement(
          Ne,
          r(
            {
              prefixCls: o,
              disabled: n,
              ref: _,
              domRef: g,
              className: p == null ? void 0 : p.input,
            },
            m
          )
        )
      )
    );
  }),
  Z = (e) => {
    let t = e.handleVisible ?? `auto`,
      n = e.controlHeightSM - e.lineWidth * 2;
    return Object.assign(Object.assign({}, me(e)), {
      controlWidth: 90,
      handleWidth: n,
      handleFontSize: e.fontSize / 2,
      handleVisible: t,
      handleActiveBg: e.colorFillAlter,
      handleBg: e.colorBgContainer,
      filledHandleBg: new s(e.colorFillSecondary)
        .onBackground(e.colorBgContainer)
        .toHexString(),
      handleHoverColor: e.colorPrimary,
      handleBorderColor: e.colorBorder,
      handleOpacity: +(t === !0),
      handleVisibleWidth: t === !0 ? n : 0,
    });
  },
  Q = ({ componentCls: e, borderRadiusSM: t, borderRadiusLG: n }, r) => {
    let i = r === `lg` ? n : t;
    return {
      [`&-${r}`]: {
        [`${e}-handler-wrap`]: {
          borderStartEndRadius: i,
          borderEndEndRadius: i,
        },
        [`${e}-handler-up`]: { borderStartEndRadius: i },
        [`${e}-handler-down`]: { borderEndEndRadius: i },
      },
    };
  },
  Fe = (e) => {
    let {
      componentCls: t,
      lineWidth: n,
      lineType: r,
      borderRadius: i,
      inputFontSizeSM: a,
      inputFontSizeLG: o,
      controlHeightLG: s,
      controlHeightSM: c,
      colorError: l,
      paddingInlineSM: u,
      paddingBlockSM: d,
      paddingBlockLG: f,
      paddingInlineLG: p,
      colorIcon: m,
      motionDurationMid: h,
      handleHoverColor: _,
      handleOpacity: v,
      paddingInline: y,
      paddingBlock: b,
      handleBg: S,
      handleActiveBg: te,
      colorTextDisabled: ne,
      borderRadiusSM: C,
      borderRadiusLG: w,
      controlWidth: T,
      handleBorderColor: E,
      filledHandleBg: D,
      lineHeightLG: O,
      calc: k,
    } = e;
    return [
      {
        [t]: Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(Object.assign(Object.assign({}, x(e)), L(e)), {
                    display: `inline-block`,
                    width: T,
                    margin: 0,
                    padding: 0,
                    borderRadius: i,
                  }),
                  j(e, {
                    [`${t}-handler-wrap`]: {
                      background: S,
                      [`${t}-handler-down`]: {
                        borderBlockStart: `${g(n)} ${r} ${E}`,
                      },
                    },
                  })
                ),
                F(e, {
                  [`${t}-handler-wrap`]: {
                    background: D,
                    [`${t}-handler-down`]: {
                      borderBlockStart: `${g(n)} ${r} ${E}`,
                    },
                  },
                  "&:focus-within": {
                    [`${t}-handler-wrap`]: { background: S },
                  },
                })
              ),
              pe(e, {
                [`${t}-handler-wrap`]: {
                  background: S,
                  [`${t}-handler-down`]: {
                    borderBlockStart: `${g(n)} ${r} ${E}`,
                  },
                },
              })
            ),
            de(e)
          ),
          {
            "&-rtl": { direction: `rtl`, [`${t}-input`]: { direction: `rtl` } },
            "&-lg": {
              padding: 0,
              fontSize: o,
              lineHeight: O,
              borderRadius: w,
              [`input${t}-input`]: {
                height: k(s).sub(k(n).mul(2)).equal(),
                padding: `${g(f)} ${g(p)}`,
              },
            },
            "&-sm": {
              padding: 0,
              fontSize: a,
              borderRadius: C,
              [`input${t}-input`]: {
                height: k(c).sub(k(n).mul(2)).equal(),
                padding: `${g(d)} ${g(u)}`,
              },
            },
            "&-out-of-range": { [`${t}-input-wrap`]: { input: { color: l } } },
            "&-group": Object.assign(
              Object.assign(Object.assign({}, x(e)), N(e)),
              {
                "&-wrapper": Object.assign(
                  Object.assign(
                    Object.assign(
                      {
                        display: `inline-block`,
                        textAlign: `start`,
                        verticalAlign: `top`,
                        [`${t}-affix-wrapper`]: { width: `100%` },
                        "&-lg": {
                          [`${t}-group-addon`]: {
                            borderRadius: w,
                            fontSize: e.fontSizeLG,
                          },
                        },
                        "&-sm": { [`${t}-group-addon`]: { borderRadius: C } },
                      },
                      P(e)
                    ),
                    I(e)
                  ),
                  {
                    [`&:not(${t}-compact-first-item):not(${t}-compact-last-item)${t}-compact-item`]:
                      { [`${t}, ${t}-group-addon`]: { borderRadius: 0 } },
                    [`&:not(${t}-compact-last-item)${t}-compact-first-item`]: {
                      [`${t}, ${t}-group-addon`]: {
                        borderStartEndRadius: 0,
                        borderEndEndRadius: 0,
                      },
                    },
                    [`&:not(${t}-compact-first-item)${t}-compact-last-item`]: {
                      [`${t}, ${t}-group-addon`]: {
                        borderStartStartRadius: 0,
                        borderEndStartRadius: 0,
                      },
                    },
                  }
                ),
              }
            ),
            [`&-disabled ${t}-input`]: { cursor: `not-allowed` },
            [t]: {
              "&-input": Object.assign(
                Object.assign(
                  Object.assign(Object.assign({}, x(e)), {
                    width: `100%`,
                    padding: `${g(b)} ${g(y)}`,
                    textAlign: `start`,
                    backgroundColor: `transparent`,
                    border: 0,
                    borderRadius: i,
                    outline: 0,
                    transition: `all ${h} linear`,
                    appearance: `textfield`,
                    fontSize: `inherit`,
                  }),
                  R(e.colorTextPlaceholder)
                ),
                {
                  '&[type="number"]::-webkit-inner-spin-button, &[type="number"]::-webkit-outer-spin-button':
                    { margin: 0, appearance: `none` },
                }
              ),
            },
            [`&:hover ${t}-handler-wrap, &-focused ${t}-handler-wrap`]: {
              width: e.handleWidth,
              opacity: 1,
            },
          }
        ),
      },
      {
        [t]: Object.assign(
          Object.assign(
            Object.assign(
              {
                [`${t}-handler-wrap`]: {
                  position: `absolute`,
                  insetBlockStart: 0,
                  insetInlineEnd: 0,
                  width: e.handleVisibleWidth,
                  opacity: v,
                  height: `100%`,
                  borderStartStartRadius: 0,
                  borderStartEndRadius: i,
                  borderEndEndRadius: i,
                  borderEndStartRadius: 0,
                  display: `flex`,
                  flexDirection: `column`,
                  alignItems: `stretch`,
                  transition: `all ${h}`,
                  overflow: `hidden`,
                  [`${t}-handler`]: {
                    display: `flex`,
                    alignItems: `center`,
                    justifyContent: `center`,
                    flex: `auto`,
                    height: `40%`,
                    [`
              ${t}-handler-up-inner,
              ${t}-handler-down-inner
            `]: { marginInlineEnd: 0, fontSize: e.handleFontSize },
                  },
                },
                [`${t}-handler`]: {
                  height: `50%`,
                  overflow: `hidden`,
                  color: m,
                  fontWeight: `bold`,
                  lineHeight: 0,
                  textAlign: `center`,
                  cursor: `pointer`,
                  borderInlineStart: `${g(n)} ${r} ${E}`,
                  transition: `all ${h} linear`,
                  "&:active": { background: te },
                  "&:hover": {
                    height: `60%`,
                    [`
              ${t}-handler-up-inner,
              ${t}-handler-down-inner
            `]: { color: _ },
                  },
                  "&-up-inner, &-down-inner": Object.assign(
                    Object.assign({}, ee()),
                    {
                      color: m,
                      transition: `all ${h} linear`,
                      userSelect: `none`,
                    }
                  ),
                },
                [`${t}-handler-up`]: { borderStartEndRadius: i },
                [`${t}-handler-down`]: { borderEndEndRadius: i },
              },
              Q(e, `lg`)
            ),
            Q(e, `sm`)
          ),
          {
            "&-disabled, &-readonly": {
              [`${t}-handler-wrap`]: { display: `none` },
              [`${t}-input`]: { color: `inherit` },
            },
            [`
          ${t}-handler-up-disabled,
          ${t}-handler-down-disabled
        `]: { cursor: `not-allowed` },
            [`
          ${t}-handler-up-disabled:hover &-handler-up-inner,
          ${t}-handler-down-disabled:hover &-handler-down-inner
        `]: { color: ne },
          }
        ),
      },
    ];
  },
  Ie = (e) => {
    let {
      componentCls: t,
      paddingBlock: n,
      paddingInline: r,
      inputAffixPadding: i,
      controlWidth: a,
      borderRadiusLG: o,
      borderRadiusSM: s,
      paddingInlineLG: c,
      paddingInlineSM: l,
      paddingBlockLG: u,
      paddingBlockSM: d,
      motionDurationMid: f,
    } = e;
    return {
      [`${t}-affix-wrapper`]: Object.assign(
        Object.assign({ [`input${t}-input`]: { padding: `${g(n)} 0` } }, L(e)),
        {
          position: `relative`,
          display: `inline-flex`,
          alignItems: `center`,
          width: a,
          padding: 0,
          paddingInlineStart: r,
          "&-lg": {
            borderRadius: o,
            paddingInlineStart: c,
            [`input${t}-input`]: { padding: `${g(u)} 0` },
          },
          "&-sm": {
            borderRadius: s,
            paddingInlineStart: l,
            [`input${t}-input`]: { padding: `${g(d)} 0` },
          },
          [`&:not(${t}-disabled):hover`]: { zIndex: 1 },
          "&-focused, &:focus": { zIndex: 1 },
          [`&-disabled > ${t}-disabled`]: { background: `transparent` },
          [`> div${t}`]: {
            width: `100%`,
            border: `none`,
            outline: `none`,
            [`&${t}-focused`]: { boxShadow: `none !important` },
          },
          "&::before": {
            display: `inline-block`,
            width: 0,
            visibility: `hidden`,
            content: `"\\a0"`,
          },
          [`${t}-handler-wrap`]: { zIndex: 2 },
          [t]: {
            position: `static`,
            color: `inherit`,
            "&-prefix, &-suffix": {
              display: `flex`,
              flex: `none`,
              alignItems: `center`,
              pointerEvents: `none`,
            },
            "&-prefix": { marginInlineEnd: i },
            "&-suffix": {
              insetBlockStart: 0,
              insetInlineEnd: 0,
              height: `100%`,
              marginInlineEnd: r,
              marginInlineStart: i,
              transition: `margin ${f}`,
            },
          },
          [`&:hover ${t}-handler-wrap, &-focused ${t}-handler-wrap`]: {
            width: e.handleWidth,
            opacity: 1,
          },
          [`&:not(${t}-affix-wrapper-without-controls):hover ${t}-suffix`]: {
            marginInlineEnd: e.calc(e.handleWidth).add(r).equal(),
          },
        }
      ),
      [`${t}-underlined`]: { borderRadius: 0 },
    };
  },
  Le = ne(
    `InputNumber`,
    (e) => {
      let t = y(e, M(e));
      return [Fe(t), Ie(t), re(t)];
    },
    Z,
    { unitless: { handleOpacity: !0 }, resetFont: !1 }
  ),
  Re = function (e, t) {
    var n = {};
    for (var r in e)
      Object.prototype.hasOwnProperty.call(e, r) &&
        t.indexOf(r) < 0 &&
        (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
      for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++)
        t.indexOf(r[i]) < 0 &&
          Object.prototype.propertyIsEnumerable.call(e, r[i]) &&
          (n[r[i]] = e[r[i]]);
    return n;
  },
  ze = V.forwardRef((e, t) => {
    let { getPrefixCls: n, direction: r } = V.useContext(a),
      i = V.useRef(null);
    V.useImperativeHandle(t, () => i.current);
    let {
        className: o,
        rootClassName: s,
        size: c,
        disabled: l,
        prefixCls: u,
        addonBefore: d,
        addonAfter: f,
        prefix: p,
        suffix: m,
        bordered: h,
        readOnly: g,
        status: _,
        controls: y,
        variant: ee,
      } = e,
      b = Re(e, [
        `className`,
        `rootClassName`,
        `size`,
        `disabled`,
        `prefixCls`,
        `addonBefore`,
        `addonAfter`,
        `prefix`,
        `suffix`,
        `bordered`,
        `readOnly`,
        `status`,
        `controls`,
        `variant`,
      ]),
      x = n(`input-number`, u),
      S = oe(x),
      [ne, C, w] = Le(x, S),
      { compactSize: T, compactItemClassnames: E } = te(x, r),
      O = V.createElement(ge, { className: `${x}-handler-up-inner` }),
      k = V.createElement(B, { className: `${x}-handler-down-inner` }),
      re = typeof y == `boolean` ? y : void 0;
    typeof y == `object` &&
      ((O =
        y.upIcon === void 0
          ? O
          : V.createElement(
              `span`,
              { className: `${x}-handler-up-inner` },
              y.upIcon
            )),
      (k =
        y.downIcon === void 0
          ? k
          : V.createElement(
              `span`,
              { className: `${x}-handler-down-inner` },
              y.downIcon
            )));
    let {
        hasFeedback: A,
        status: se,
        isFormItemInput: j,
        feedbackIcon: ue,
      } = V.useContext(ie),
      M = le(se, _),
      N = v((e) => c ?? T ?? e),
      de = V.useContext(D),
      P = l ?? de,
      [F, I] = z(`inputNumber`, ee, h),
      fe = A && V.createElement(V.Fragment, null, ue),
      L = (0, H.default)(
        {
          [`${x}-lg`]: N === `large`,
          [`${x}-sm`]: N === `small`,
          [`${x}-rtl`]: r === `rtl`,
          [`${x}-in-form-item`]: j,
        },
        C
      ),
      R = `${x}-group`;
    return ne(
      V.createElement(
        Pe,
        Object.assign(
          {
            ref: i,
            disabled: P,
            className: (0, H.default)(w, S, o, s, E),
            upHandler: O,
            downHandler: k,
            prefixCls: x,
            readOnly: g,
            controls: re,
            prefix: p,
            suffix: fe || m,
            addonBefore: d && V.createElement(ae, { form: !0, space: !0 }, d),
            addonAfter: f && V.createElement(ae, { form: !0, space: !0 }, f),
            classNames: {
              input: L,
              variant: (0, H.default)({ [`${x}-${F}`]: I }, ce(x, M, A)),
              affixWrapper: (0, H.default)(
                {
                  [`${x}-affix-wrapper-sm`]: N === `small`,
                  [`${x}-affix-wrapper-lg`]: N === `large`,
                  [`${x}-affix-wrapper-rtl`]: r === `rtl`,
                  [`${x}-affix-wrapper-without-controls`]: y === !1 || P || g,
                },
                C
              ),
              wrapper: (0, H.default)({ [`${R}-rtl`]: r === `rtl` }, C),
              groupWrapper: (0, H.default)(
                {
                  [`${x}-group-wrapper-sm`]: N === `small`,
                  [`${x}-group-wrapper-lg`]: N === `large`,
                  [`${x}-group-wrapper-rtl`]: r === `rtl`,
                  [`${x}-group-wrapper-${F}`]: I,
                },
                ce(`${x}-group-wrapper`, M, A),
                C
              ),
            },
          },
          b
        )
      )
    );
  }),
  $ = ze;
$._InternalPanelDoNotUseOrYouWillBeFired = (e) =>
  V.createElement(
    A,
    { theme: { components: { InputNumber: { handleVisible: !0 } } } },
    V.createElement(ze, Object.assign({}, e))
  );
export { $ as t };
