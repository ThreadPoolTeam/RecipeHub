import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { t } from "./react-IpA8Qn9U.js";
import { t as n } from "./jsx-runtime-CA2T8_y1.js";
import { c as r } from "./index-DG2EaUNY.js";
import { f as i } from "./Text-YthWi8mb.js";
import { t as a } from "./lodash-QVF93A2Q.js";
import { a as o, t as s } from "./GimkitLiveQuestion-C1_bMw3L.js";
import { t as c } from "./sounds-Ds3FtXr-.js";
var l = a(),
  u = e(t()),
  d = n(),
  f = (e) => {
    let [t, n] = u.useState((0, l.shuffle)(e.questions.map((e) => e._id))),
      [a, f] = u.useState(0),
      [p, m] = u.useState({
        ...e.questions.find((e) => e._id === t[a]),
        answers: (0, l.shuffle)(
          e.questions.find((e) => e._id === t[a]).answers
        ),
      }),
      [h, g] = u.useState(),
      [_, v] = u.useState(!1);
    u.useEffect(() => {
      t.length - 1 === a && n((0, l.shuffle)(e.questions.map((e) => e._id)));
    }, [t.length, a]),
      u.useEffect(() => {
        c.correct.load(), c.incorrect.load(), c.click.load();
      }, []);
    let y = u.useMemo(() => {
      var e;
      return (
        (h == null || (e = h.answers) == null
          ? void 0
          : e.find((e) => e.correct)) || {
          _id: `no_correct`,
          text: `No Correct Answer`,
          correct: !0,
        }
      );
    }, [h]);
    return (0, d.jsx)(`div`, {
      className: `maxAll`,
      style: {
        fontFamily: r.ProductSans,
        background: `#303f9f`,
        userSelect: `none`,
        overflow: `hidden`,
      },
      children: (0, d.jsx)(s, {
        ecc: o(p, p._id),
        lastQuestion: h,
        lastQuestionCorrectAnswer: y,
        lastQuestionAnsweredCorrect: _,
        onQuestionAnswered: (n) => {
          g(p);
          let r = a + 1;
          r >= t.length && (r = 0), f(r);
          let o = e.questions.find((e) => e._id === t[r]);
          m({ ...o, answers: (0, l.shuffle)(o.answers) });
          let s = i(p, n);
          return v(s), s;
        },
        correctSound: c.correct,
        incorrectSound: c.incorrect,
        onActionSound: c.click,
        textShownWhenAnsweringCorrectly: `Correct!`,
        textShownWhenAnsweringIncorrectly: `Incorrect!`,
        customCorrectTextAnimation: {
          className: `animated slideInDown`,
          duration: 0.4,
        },
      }),
    });
  };
export { f as default };
