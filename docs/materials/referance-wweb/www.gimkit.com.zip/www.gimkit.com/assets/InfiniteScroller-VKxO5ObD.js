import { o as e } from "./rolldown-runtime-C0FnF6B9.js";
import { C as t } from "./utils-CV9JYz4f.js";
import { t as n } from "./react-IpA8Qn9U.js";
import { t as r } from "./jsx-runtime-CA2T8_y1.js";
import { t as i } from "./index.es-D5OUGrAM.js";
var a = e(n()),
  o = r(),
  s = (e) => {
    let [n, r] = a.useState([]),
      [s] = a.useState(e.limit),
      [c, l] = a.useState(e.defaultPage),
      [u, d] = a.useState(!0),
      [f, p] = a.useState([]),
      [m, h] = a.useState(!1),
      g = a.useMemo(
        () =>
          (e.modifyItems ? e.modifyItems(f) : f).map((t, n) =>
            e.toRender(t, n)
          ),
        [f.length, e.toRender]
      ),
      _ = () => {
        if (n.includes(c)) return;
        r((e) => [...e, c]);
        let i = { page: c, limit: s };
        t({
          url: e.url,
          method: `post`,
          cacheKey: e.cacheKey,
          data: e.modifyBody ? e.modifyBody(i) : i,
          success: (t, n) => {
            e.onTotalItems && !m && (e.onTotalItems(t.totalItems), h(!0)),
              t.items.forEach((t) => {
                e.onItemFetched && e.onItemFetched(t, n);
              }),
              p((e) => [...e, ...t.items]),
              d(t.hasNextPage),
              l(t.nextPage);
          },
          error: () => {
            e.onTotalItems && !m && (e.onTotalItems(0), h(!0)), d(!1);
          },
          both: () => r((e) => e.filter((e) => e !== i.page)),
        });
      };
    return (
      a.useEffect(_, []),
      (!u && e.forceEmptyMessage) || (!u && f.length === 0 && e.emptyMessage)
        ? e.emptyMessage(f)
        : (0, o.jsxs)(i, {
            dataLength: f.length,
            hasMore: u,
            style: e.scrollStyle,
            next: _,
            loader: e.loader || (0, o.jsx)(`div`, {}),
            scrollThreshold: e.scrollThreshold,
            endMessage: e.endMessage ? e.endMessage(f) : null,
            scrollableTarget: e.scrollableTarget,
            children: [e.prefix ? e.prefix() : null, g],
          })
    );
  };
export { s as t };
